# Bilan mensuel marketing (Fatima)

**Schedule cron Hermes (standard 5 champs) :** `30 8 5 * *`  (Le 5 de chaque mois, 08:30 UTC)
**Deliver :** origin (canal où l'Expert Fatima est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Fatima) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Bilan mensuel marketing (Fatima) », schedule `30 8 5 * *`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Fatima. Produis le bilan du mois écoulé pour la direction.

1. **Ce qui était prévu, ce qui a été fait.** Les contenus produits, les campagnes menées, les
   opérations terrain tenues.
2. **Les résultats aux trois étages**, exposition, intérêt, résultat, canal par canal, avec la
   mention explicite des canaux non instrumentés. Ne comble jamais un trou par une estimation.
3. **Le coût**, en incluant le temps interne quand il est connu, et le coût par résultat obtenu
   là où il est calculable.
4. **Ce qu'on propose d'arrêter, de garder, de renforcer**, avec la raison de chaque proposition.

Termine par la décision attendue de la direction, s'il y en a une.

Applique `controle-qualite-5-passes` avant l'envoi. Aucun chiffre non issu des données de
l'entreprise ne figure dans ce bilan.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
