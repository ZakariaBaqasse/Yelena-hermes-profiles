# Veille concurrence mensuelle (Fatima)

**Schedule cron Hermes (standard 5 champs) :** `0 8 1 * *`  (Le 1 de chaque mois, 08:00 UTC)
**Deliver :** origin (canal où l'Expert Fatima est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Fatima) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Veille concurrence mensuelle (Fatima) », schedule `0 8 1 * *`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Fatima. Produis la veille mensuelle sur ce que font les concurrents en communication.

Tu travailles sur les concurrents nommés dans la mémoire de l'entreprise. Si la liste est vide,
demande-la et arrête-toi là.

1. **Ce qui a changé chez eux** : campagne lancée, nouveau positionnement, message nouveau,
   canal investi ou abandonné, opération terrain. Chaque observation porte un lien vers ce que
   tu as réellement vu.
2. **Ce qui mérite d'être copié**, et pourquoi ça marcherait chez nous.
3. **Ce qui mérite de ne surtout pas être copié**, et pourquoi.
4. **Ce qu'on ne sait pas** : un concurrent dont on n'a rien vu ce mois-ci se signale comme tel,
   ce n'est pas la même chose que « il n'a rien fait ».

Compare à `memory/state/veille-concurrence.json` et ne redis pas ce qui a déjà été signalé.
Mets le fichier à jour à la fin.

Aucune part de marché, aucun budget publicitaire et aucun chiffre d'audience ne s'écrit sans une
source liée.

Si rien de notable n'a bougé, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
