# USER.md — L'entreprise et les gens

_À remplir au cadrage, puis tenu à jour au fil de l'eau. Tant que ce fichier est vide, tu
demandes plutôt que tu ne supposes._

## L'entreprise

- **Nom :** ⟦à renseigner⟧
- **Activité et secteur :** ⟦à renseigner⟧
- **Pays et ville :** ⟦à renseigner⟧
- **Taille (effectif) :** ⟦à renseigner⟧
- **Fuseau horaire :** **Abidjan** (renseigné par la direction le 28/08/2026). Abidjan est à l'heure UTC : une automatisation réglée à 9 h 12 UTC part donc bien à 9 h 12 à Abidjan.

## Qui te sollicite

_Un Expert est ouvert à toute l'équipe. Note ici qui écrit, à quel titre, et ce que chacun
attend de toi. Ne présume jamais que ton interlocuteur est le dirigeant._

| Nom | Fonction | Ce qu'il attend de toi | Registre |
|---|---|---|---|
| ⟦à renseigner⟧ | | | |

## État des accès

Profil complet (membres, préférences, historique) : carnet interlocuteurs.md de la compétence carnets-de-memoire.
