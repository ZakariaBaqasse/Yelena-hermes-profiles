# TOOLS.md - notes propres à cette installation

Les compétences disent *comment* les outils marchent. Ici, ce qui est **spécifique à cette
machine** : les chemins, les comptes, les paquets présents ou absents. Une compétence qui
renvoie au « TOOLS.md du poste » renvoie à ce fichier.

## Fabriquer un document : l'interpréteur et les bibliothèques

⚠ Le Python du système **ne porte aucune bibliothèque bureautique**. L'appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est le mauvais interpréteur.

| Ce que je fabrique | Avec quoi |
|---|---|
| Word, présentation, tableur, PDF, lecture d'un document | `~/.venv-office/bin/python` |
| il porte | `docx` · `pptx` · `openpyxl` · `pandas` · `pypdf` · `weasyprint` · `markitdown` |
| Word ou deck côté Node (`docx-js`, `pptxgenjs`) | `NODE_PATH=~/.claude/outils-communs/node/node_modules node …` |
| Figer un document bureautique en PDF | `soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>` |

⛔ **`pandoc` n'est pas installé sur cette machine.** Toute recette qui en dépend est à écarter.
Lire un `.docx` : `markitdown` ou `python-docx`. Convertir en PDF : `soffice`, ci-dessus.

ℹ LibreOffice porte Calc, Draw et Impress, et Writer depuis le 22/09/2026. Si `soffice` répond
« source file could not be loaded », vérifier d'abord le paquet installé (`dpkg -l | grep
libreoffice`), pas le fichier.

⚠ **Sur une autre installation, rien de ceci n'est garanti.** Je vérifie avant d'affirmer, et
je dis franchement qu'un format ne se produit pas ici plutôt que de le remplacer en silence.

## Outils communs à tous les experts

- `outils/deposer-livrable.py` : dépose un livrable dans mon Drive, le nomme et l'inscrit à l'index.
- `outils/relire-sans-tics.py` : compte les marqueurs d'écriture de machine. Il signale, il ne corrige pas.
- `outils/ligne-etat.py` : la ligne d'état, tenue hors de mon tour.
- `outils/statut-livrable.py` : dit si un livrable est BLOQUÉ, PRÊT SOUS RÉSERVE ou PRÊT.

## Mes outils de création (`outils/`)

Tous se lancent avec `~/.venv-office/bin/python`. Principe commun : le logo, l'emballage et
les couleurs viennent des **fichiers de la marque**, jamais redessinés ni inventés.

| Famille | Scripts |
|---|---|
| Relever une marque | `relever-marque.py`, `palette-de-marque.py`, `planche-validation-marque.py`, `relever-contacts.py`, `detourer.py` |
| Visuels réseaux | `carre-social.py`, `carrousel.py`, `carrousel-pdf.py`, `carte-citation.py`, `visuel-scene.py`, `bandeau-graphique.py`, `icones-reseaux.py` |
| Publicité et affichage | `composer.py`, `mise-en-page-panneau.py`, `mise-en-page-panneau-b.py`, `mise-en-page-intl.py`, `flyer-a5.py`, `drapeau.py` |
| Identité | `logo-mot.py`, `planche-logos.py`, `tableau-vote-noms.py`, `svg-en-png.py` |
| Stratégie et suivi | `planche-strategie.py`, `entonnoir.py`, `tableau-de-bord-reseaux.py`, `fiche-meilleur-pire.py`, `fiche-choix.py` |
| Présentations et pages | `deck-brande.py`, `page-de-vente.py`, `tableur.py` (xlsx sans dépendance) |
| Vidéo sans crédit de génération | `animer-plans.py`, `video-cartes.py`, `video-textes-animes.py`, `ecran-anime.py`, `monter-vertical.py`, `monter-pub.py`, `monter-film.py` |
| Génération facturée | `magnific-lot.py`, `magnific-refs.py`, `video-lot.py`, `voix-off.py`, `avatar-parlant.py` : consomment des crédits, jamais sans accord |
| Briques partagées | `plaque.py` (contrôle de la plaque de logo), `typo.py` (substitutions de signes) |

ℹ Les scripts et briefs JSON propres à une campagne client (séries de panneaux, spots) restent
dans `outils/` mais ne sont pas des outils génériques.

## Services branchés (`integrations/`)

Figma (et son serveur MCP), Canva, Magnific, Higgsfield, OpenAI (images et transcription),
Frames (pages publiées), Google Drive, Tally, Unipile, sources publiques (web public, Banque
mondiale, data.gouv.ci, UN Comtrade, Open-Meteo, RDAP), Brave Search et Apify (facturés).
Chaque dossier porte son `README.md` et son `check.py`.
