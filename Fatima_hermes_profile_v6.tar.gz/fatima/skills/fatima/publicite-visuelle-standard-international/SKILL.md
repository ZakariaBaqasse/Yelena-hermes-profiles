---
id: Y0588
name: publicite-visuelle-standard-international
description: Produire des publicités visuelles finies au standard international pour n'importe quelle marque — affiche, réseau social, panneau, presse. Couvre la chaîne complète : récupérer les fichiers officiels de la marque, fabriquer le décor par génération, incruster l'emballage réel, poser la typographie, contrôler, livrer. À charger dès qu'on demande des visuels publicitaires, des « pubs », des créations, une montée en gamme d'une communication existante, ou un lot de visuels produits.
version: 1
maj: 2026-08-19
---

# Publicité visuelle au standard international

Cette compétence est **indépendante de la marque**. Elle porte la méthode ; le dossier de
marque porte les valeurs. Ce qui est écrit ici a été appris en production réelle, chaque
règle au prix d'une erreur.

## La règle qui commande toutes les autres

**Un générateur n'invente jamais un élément de marque.** Ni un emballage, ni un logo, ni une
étiquette, ni un mot imprimé sur un produit.

Ce n'est pas une précaution de style. Essai réel, 13/08/2026 : un moteur laissé libre a
redessiné des emballages **et inventé des marques concurrentes**, dont une qui appartenait à
un tiers réel. Un visuel qui porte une marque inventée est indéfendable.

Il y a **deux chaînes**, et c'est la destination qui choisit — pas le confort.

**Chaîne 1 — l'emballage officiel en RÉFÉRENCE (écran, réseaux, présentation).**
Le générateur reçoit le fichier de l'emballage détouré comme image de référence, construit la
scène autour et le pose lui-même. C'est la chaîne qui rend le mieux : le paquet est éclairé
par la lumière de la scène, il a son ombre de contact, il ne lit jamais comme un autocollant.
Validée en production le 13/08/2026 sur 40 panneaux, et retenue par le client.
⚠️ **Sa limite décide de son usage** : le modèle **redessine** le paquet, il ne le copie pas.
Le grand titre sort juste, les petits textes du dos se déforment (« Suner Mentol » pour
« Super Mentol », « MINTHOL SWEES » pour « MENTHOL SWEETS »), et il lui arrive de changer le
format du conditionnement — un sachet devenu bonbon unitaire. Donc : **écran oui, impression
non**, et **on lit chaque mot de chaque paquet** avant de livrer.

**Chaîne 2 — l'incrustation du fichier officiel (impression, bon à tirer, tout ce qui engage).**
Le générateur fabrique le décor **seul** — sans produit, sans texte, sans logo, avec une zone
libre réellement éclairée et une surface d'appui. J'incruste ensuite l'emballage officiel
détouré, puis je pose la typographie avec l'atelier local. Le paquet est alors exact au pixel.

Dans les deux cas, la typographie de l'accroche vient de l'atelier local, **jamais** du
générateur.

Conséquence sur les consignes : en chaîne 2, chaque consigne se termine par la liste des
interdits — *no packaging, no jar, no bottle, no label, no logo, no text, no lettering, no
watermark* — et décrit **où** se trouve la zone libre. En chaîne 1, on interdit tout **autre**
emballage que celui de la référence, et on exige un seul exemplaire, rien qui le recouvre.

## Le décor sort du PRODUIT, jamais d'un lieu

C'est la règle qui a coûté le plus cher à apprendre, en trois séries refusées. Elle remplace
une règle antérieure — « plante le lieu » — qui était juste et insuffisante.

Un brief qui donne le produit, l'idée et la couleur **sans lieu** produit de l'image de mode :
mer turquoise, falaise de glace, silhouette dans l'herbe. C'est beau, ça ne vend rien. Mais un
brief qui plante un **beau lieu quelconque** — vestiaire de salle de sport, salle de réunion,
photomaton, bureau de veilleur de nuit — produit exactement le même échec sous une autre forme,
et c'est le mot du client qui le dit le mieux : *« le fond des images ne colle pas avec les
images »*.

**La règle** : le décor est fait de **la matière dont le produit est fait** et du **moment où
on le consomme**. Une sucette aux fruits se joue dans les fruits coupés d'un étal. Un caramel
dans le caramel qui coule d'une cuillère. Une menthe dans la menthe fraîche et la glace pilée.
Une mayonnaise dans une table servie. Un beau lieu vide est un échec, même bien photographié.

La formule qui tient, en tête de consigne :

> THIS IS A ⟦SECTEUR⟧ ADVERTISEMENT. The photograph has to make the mouth water. It is built
> out of the product's OWN WORLD — the raw matter it is made of and the moment it is eaten —
> never out of a pretty empty place. A beautiful location with nothing to do with the product
> is a failed image.

Transposition hors alimentaire, même principe : la matière première, le geste d'usage, le lieu
où l'objet sert vraiment. Ce qui compte est que quelqu'un qui verrait la photo **sans le
produit** devine quand même de quel rayon on parle.

## Étape 0 — l'enquête, et elle n'est pas facultative

**Aucun visuel ne se produit avant cette étape.** C'est ce qui sépare une création d'agence
d'un joli fichier : la forme se décide sur des observations, jamais sur du goût.

Trois lectures, dans cet ordre, et chacune s'écrit avec sa date :

1. **Ce que fait la marque elle-même.** Ouvrir son site, ses sous-pages produit, ses comptes.
   Relever sa grammaire réelle : format, champ de couleur, place du produit, place du
   personnage, type d'accroche, ponctuation, signature. Puis nommer **ce qui lui manque** —
   c'est là qu'est le travail. Une marque qui annonce un catalogue ne raconte aucun moment ;
   une marque qui empile cinq produits n'a jamais une seule idée par image.
2. **Ce que font les comparables.** Extraire les publications récentes de marques
   internationales du même rayon (robot d'extraction sur les réseaux, pages de campagne,
   presse professionnelle). Mesurer, ne pas supposer : combien de produits par image, combien
   de mots, quels ornements, où est le logo. **Écrire ce qui n'a pas répondu** — une marque
   qui ne renvoie rien est une limite du relevé, pas un résultat.
3. **La norme du support.** Formats, marges de sécurité, limites de caractères, mentions
   obligatoires du secteur et du pays. Se vérifier à la source de la plateforme ou du
   régulateur, pas de mémoire : ces valeurs changent, et un chiffre plausible est le plus
   dangereux de tous.

Ce que produit l'enquête : une **grille écrite** — la liste des règles observées, avec le
nombre d'éléments observés et la date. Elle se sert au client avec ses limites (« une seule
marque a répondu, c'est une limite à dire »), et elle devient la référence du lot.

Ce qui est interdit à cette étape : servir comme observation ce qu'on croit savoir d'un
marché, d'un usage ou d'un ordre de grandeur. Si on ne peut pas dire **où** on l'a lu, ça
ne s'écrit pas.

## Étape 1 — le dossier de marque

Avant toute production, remplir `references/marque.exemple.json` pour la marque concernée
(le garder dans l'espace de la marque, pas ici). Rien ne se produit avec des valeurs devinées.

Ce qui doit y figurer, et ce qui arrive s'il manque :

| Élément | S'il manque |
|---|---|
| Champ de couleur (code exact) | On le relève sur les fichiers officiels et on écrit qu'il est **relevé, non fourni** |
| Logo vectoriel ou PNG à fond transparent | On prend le meilleur fichier public et on demande le vectoriel |
| Emballages officiels par référence | **On ne produit pas ce produit**, on le dit |
| Marché et pays de diffusion | Bloquant pour le casting et la langue, on demande |
| Site et mentions du pied de page | On ne met que ce qui est vérifié |
| Prix, promesses, allégations | **Elles ne s'écrivent pas.** Emplacement à remplir, jamais valeur plausible |

Où chercher les fichiers officiels : le site de la marque, **sous-pages produit d'abord**
(la page d'accueil n'a presque jamais les emballages), puis les **sites frères** de la même
maison — une marque sœur porte souvent les emballages isolés que le site principal n'a pas.
Ne jamais reconstituer une adresse : ou bien on l'ouvre et on la cite, ou bien on nomme
l'organisme et on écrit que le lien reste à vérifier.

## Les sept règles de forme

Relevées le 13/08/2026 sur **12 publications d'une seule marque internationale de grande
consommation** (extraction Apify, robot `apify/instagram-scraper`). Une seule marque
observée : c'est une limite à dire au client, pas un référentiel universel. Trois autres
marques essayées n'ont rien renvoyé.

1. **Un seul champ de couleur**, celui de la marque, occupé en plein, travaillé — matière,
   grain, dégradé, profondeur. Jamais un aplat mort.
2. **Un seul produit**, très grand, une seule zone focale.
3. **Quatre à sept mots.** Le texte reste plus petit que le produit.
4. **Aucun ornement** : ni confetti, ni étoile, ni point d'exclamation, ni contour.
5. **Le logo n'est pas posé à côté du produit** — il est porté par l'emballage. Un rappel
   discret suffit en signature.
6. **Un pied de page sobre** : l'adresse du site et l'origine, rien d'autre.
7. **Une idée par image**, et la même image doit tenir du panneau au fil d'actualité.

**La montée en gamme consiste à retirer, pas à ajouter.** Quand une marque empile cinq
produits, un personnage, une accroche et une pastille, le travail n'est pas d'améliorer
l'empilement : c'est de tout enlever sauf une chose.

## Le registre du très haut standing

Quand le client demande le niveau des agences internationales, les sept règles ne suffisent
pas : elles disent ce qu'il faut retirer, pas ce qu'il faut montrer.

1. **La matière est le sujet, pas l'emballage.** Le produit lui-même, agrandi et éclairé
   comme un objet précieux : une quenelle sculptée, un ruban figé en chute, une vague, une
   trace de spatule en lumière rasante, un éclat, une coupe. L'emballage vient **signer**.
2. **Un seul geste par image**, tenu jusqu'au bout : la goutte à l'instant exact où elle
   perce la surface, l'ingrédient suspendu, la couronne d'éclaboussure.
3. **La lumière fait le prix.** Clair-obscur de nature morte, lumière rasante pour la
   texture, contre-jour spéculaire pour le brillant, une seule source dominante.
4. **Le texte se retire** : quatre à six mots, l'image porte l'argument.
5. **Le format suit l'usage** : 4:5 pour le fil, 1:1 pour le partage, paysage pour la presse
   professionnelle et l'affichage.

Transposition hors alimentaire — même principe, autre matière : le tissu et sa tombée, le
grain d'un cuir, la mousse d'une boisson, la trace d'un pneu, la coupe d'un matériau, le
mouvement d'une machine. Ce qui compte est qu'on montre **la substance**, pas le contenant.

## Casting — règle dure

Les générateurs produisent par défaut des personnes blanches. **Toute personne visible dans
le visuel appartient au marché du client**, et la consigne le dit **en toutes lettres, pour
chaque personne du cadre** — y compris les silhouettes floues d'arrière-plan et les mains
coupées au cadre. Ça ne se déduit jamais d'un contexte géographique décrit dans la consigne.

Vérifié en production : une consigne muette sur ce point a produit une technicienne blanche
dans une scène explicitement située en Afrique de l'Ouest.

Contrôle avant livraison : regarder **chaque visage et chaque main** du visuel fini,
arrière-plans compris.

## Les six causes de basse qualité, et leurs correctifs

Mesurées sur une série réelle de 32 publicités, le 13/08/2026. Elles se vérifient avant
de lancer un lot, pas après.

1. **La définition de l'emballage source.** C'est le plafond, et il explique la moitié des
   visuels mous. Un emballage de 100 à 390 px agrandi de 1,2 à 5,8 fois sur le visuel fini
   ne sera jamais net — et les plus nets d'une série sont exactement ceux dont le fichier
   source est le plus grand. *Correctif* : agrandissement qualité impression avant montage,
   en **mode fidèle** et avec contrôle visuel du texte imprimé sur l'emballage — un
   agrandisseur créatif réécrit une étiquette ; ou demander les fichiers haute définition
   à la marque.
2. **Le décor généré sous la taille de livraison.** Tout est agrandi avant même le montage.
   *Correctif* : générer au-dessus du format livré, toujours. Et ne jamais conclure sur la
   qualité d'un générateur sans comparer les dimensions rendues — la netteté attribuée au
   moteur vient souvent de là.
3. **La place du produit décidée avant d'avoir vu le décor.** Le modèle éclaire une zone
   libre à droite, la recette pose le produit au centre : composition trouée, produit sur
   du décor chargé. *Correctif* : lire la zone réellement libre, puis placer.
4. **La zone libre demandée sans plan d'appui.** « Zone vide éclairée » ne suffit pas :
   l'emballage flotte. *Correctif* : exiger une **surface** avec ombre de contact.
5. **La lumière du décor et celle de l'emballage qui ne coïncident pas.** Les fichiers
   produit sont éclairés à plat, en lumière de catalogue ; dans un décor à forte lumière
   latérale ils lisent comme un autocollant. *Correctif* : rééclairer, ou choisir un décor
   à lumière frontale douce.
6. **Deux sujets dans une même consigne**, ou **un champ de couleur choisi par concept
   plutôt que par marque**. Deux zones focales, ou une série dont la couleur change à chaque
   visuel : dans les deux cas ce n'est plus une campagne.

## La grille de mise en page — non-chevauchement par construction

Le titre ne se place pas « à peu près en haut ». Il occupe une **bande réservée**, et la
signature de marque occupe **toujours la bande opposée**. Le centre du produit est borné à
la bande centrale. Titre, logo et produit ne peuvent donc plus se rencontrer, quelles que
soient les valeurs passées — c'est la seule manière de tenir un lot de vingt visuels sans
relire chacun à l'œil.

Valeurs par défaut, en fraction de la hauteur :

- bande de titre haute `0,045 – 0,225` · bande de titre basse `0,700 – 0,880`
- centre du produit borné à `0,30 – 0,62`
- pied de page à `0,948`, avec son propre filet

**Garde de lisibilité** : mesurer la luminance moyenne et l'écart-type de la bande du titre.
Une bande claire et calme (moyenne ≥ 158, écart-type ≤ 30) garde un texte sombre. Sinon on
ajoute un voile **confiné à la bande** tant que la moyenne dépasse 92 ou l'écart-type 38.
C'est ce qui rattrape les décors chargés — marché, cuisine, confettis — sans assombrir toute
l'image. `scripts/mise_en_page.py` fait tout cela.

## Le gabarit à bandeau — quand le chevauchement doit devenir impossible

La grille à bandes réservées ci-dessus tient un lot, mais tout le travail consiste à empêcher
trois objets de se toucher, et chaque décor nouveau rouvre le problème. Il existe un gabarit
qui supprime la question :

**La photo occupe toute la surface utile. L'accroche descend dans une bande pleine en pied**,
à la couleur de la marque, avec le logo à l'autre bout et l'adresse du site en bas à gauche de
la photo.

Ce qu'il apporte, et pourquoi il est devenu mon gabarit par défaut pour l'affichage :

- **Contraste maximal** — le texte est sur un aplat, jamais sur une image. C'est la
  recommandation la plus constante de l'affichage extérieur.
- **L'image est libre** de toute réserve typographique, donc le décor peut être plein.
- **Le chevauchement devient impossible par construction** : le texte et l'image ne partagent
  aucun pixel. C'est le défaut qui revenait le plus, il disparaît.

Trois points de fabrication, chacun appris au prix d'une erreur :

1. **Générer les décors en 21:9**, pas en 16:9 : la bande mange le bas, et un décor au format
   de livraison se retrouve rogné.
2. **La couleur de la bande se MESURE sur le fichier de logo officiel**, elle ne se choisit
   pas — couleur dominante saturée du PNG. Tant que la charte n'est pas transmise, c'est la
   seule valeur défendable, et on écrit qu'elle est **relevée, non fournie**.
3. ⚠️ **Ne jamais mesurer l'agitation du décor sur le panneau entier.** La bande est un aplat
   d'écart-type nul : mêlée à la mesure, elle effondre le seuil de calme et le produit finit
   minuscule. On mesure sur **la photo seule**, puis on recolle.

## Détourage des emballages

Les fichiers produit des sites de marque portent presque toujours **un liseré clair de 1 à
3 px sur le bord du canevas** de la vignette. Recadré au cadre alpha, ce liseré ressort en
rectangle blanc autour de l'emballage sur le visuel fini. Défaut très visible, et facile à
laisser passer sur un lot.

La méthode, dans cet ordre :

1. **Si la source porte déjà son alpha** (plus de 15 % de pixels transparents), on ne
   re-détoure pas : on reprend l'alpha d'origine. Un keying sur le blanc mange les parties
   blanches du produit — un couvercle, un bâton de sucette, une étiquette claire.
2. **Rogner 1,8 % du plus petit côté** pour supprimer le liseré de vignette.
3. Durcir l'alpha (seuil 150), adoucir d'un demi-pixel, recadrer au cadre alpha.

**Contrôle obligatoire** : proportion de pixels opaques sur le pourtour du fichier détouré.
Au-dessus de 20 %, le détourage a échoué. `scripts/detourer.py` fait les deux.

## Les générateurs — lequel pour quoi

- **Magnific (Pikaso)** — le meilleur pour un décor destiné à recevoir une incrustation :
  il rend une zone libre réellement exploitable, avec l'ombre de contact. Le meilleur aussi
  pour le détourage et l'agrandissement qualité impression.
- **Higgsfield** — le meilleur dès qu'il faut une personne en action, une expression, un geste.
- **L'atelier local** (bibliothèque d'imagerie) fait l'incrustation et la typographie.

🚨 **Un moteur qui tient la consigne n'est pas forcément un moteur PHOTORÉALISTE, et c'est
l'erreur qui coûte une série entière.** Le moteur retenu pour sa docilité — celui qui ne
déforme pas un emballage et n'ajoute pas de texte — était, d'après sa propre fiche dans le
service, destiné aux mises en page, aux infographies et aux visuels **non photoréalistes**.
Il a donc rendu quarante-huit photographies obéissantes et visiblement fabriquées, jusqu'au
« les images ne sont pas réalistes » du client. **La fiche du moteur se lit avant de le
choisir** : la plupart des services indiquent à quoi chaque moteur sert. Un moteur de mise en
page pour une affiche, un moteur photographique pour une scène jouée par des personnes. Et
l'essai comparatif se fait sur **le plan le plus dur** — un visage en gros plan — pas sur un
décor vide, parce que c'est le visage qui trahit.

⚠️ **Les moteurs photoréalistes ont un défaut symétrique : ils remplissent le cadre de
marques.** Sur la même scène, sans référence d'emballage, l'un a posé un pot inventé de toutes
pièces avec son étiquette, l'autre un pot d'une **marque concurrente réelle**. D'où deux
clauses obligatoires dès qu'on quitte le moteur docile : *aucun autre emballage de marque dans
le cadre, ni inventé ni réel*, et la référence de l'emballage officiel sur **tout** plan où un
emballage peut entrer — même un plan où on n'en veut pas.

⚠️ **Et un emballage bien reproduit peut quand même avoir l'air COLLÉ.** Sur un plan large, le
pot est sorti plus net, plus clair et sans ombre de contact : une découpe posée sur la photo.
La consigne qui le règle : *présent physiquement dans la scène, éclairé par la même lumière que
ce qui l'entoure, même douceur, ombre de contact et reflet, pas une découpe, pas plus lumineux
que le reste du cadre.*

**Le moteur décide si la consigne tient — ce n'est pas qu'une affaire de style.** Un moteur
qui désobéit se remplace ; on ne réécrit pas le brief une quatrième fois. Mesuré le
13/08/2026 sur les mêmes scènes : le moteur par défaut de Magnific a dessiné des emballages
inventés et des mots en gros malgré une interdiction répétée trois fois et durcie deux fois ;
`gpt-2` en 2k tient la consigne, sort 2688×1520 et coûte 30 crédits ; `imagen-nano-banana-2`
glisse encore des objets et des coutures, à 75. Ces noms et ces prix vieilliront : ce qui ne
vieillit pas, c'est **d'essayer deux moteurs sur la même scène avant d'accuser le brief**.

**Quatre essais avant quarante images.** Un lot complet sur une direction non validée, c'est
la dépense doublée et le temps perdu deux fois. On montre un essai par famille de produit, on
fait valider, on lance. Cette règle a été enfreinte trois fois et a coûté trois séries.

**Discipline de dépense.** Ces services facturent à l'appel. Avant tout lot : chiffrer
gratuitement quand l'outil le permet (`simulate_cost`), lire le solde, annoncer le coût, et
n'engager la dépense que sur demande explicite. Un script de production porte un drapeau
`--je-paie` obligatoire. Ordres de grandeur relevés le 13/08/2026, à revérifier : environ
100 crédits une image, 3 un détourage, 90 à 1 080 un agrandissement.

## La vidéo — ce qui la sépare d'une image qui bouge

Premier lot vidéo, 17/08/2026, refusé par le client en une phrase : *« trop simple et pas
dynamique »*. Il avait raison, et la cause était nette — j'avais animé des photographies au
lieu de tourner une publicité.

**Les standards du métier, relevés à la source** — [BestBoy Media, production de publicités
boisson](https://bestboymedia.com/blog/beverage-commercial-production-los-angeles.html),
page ouverte et lue le 17/08/2026 :

- **Quatre plans canoniques** : le versement héros, l'éclaboussure, le révélé macro sur la
  condensation, l'ouverture du produit. Transposés à la confiserie : les bonbons qui
  dégringolent, la couronne de gouttes de jus, le macro en contre-jour sur le bonbon
  translucide, le sachet qui s'ouvre.
- **Le ralenti extrême est la norme** : 300 images par seconde pour une matière dense,
  60 à 120 pour un produit énergique, 24 seulement quand on cherche le réalisme.
- **« La lumière se place AUTOUR du verre, pas dessus »** : contre-jour pour l'effet éclairé
  de l'intérieur, lumière latérale pour les halos, drapeaux noirs pour creuser les contours,
  et une petite source dédiée uniquement à l'étiquette — jamais de face.
- **Macro à f/8 – f/11** sur les surfaces courbes.
- **Les mouvements sont nommés** : angle bas de face puis arc vers le côté ; plongée qui
  bascule en oblique.
- **Le jeu de livrables standard** : 30 secondes, coupe 15 secondes, bumper 6 secondes,
  deux à quatre versions verticales, versions en boucle, photogrammes. Le vertical n'est pas
  une option, il est dans le standard.

⚠️ Ce que je n'ai **pas** trouvé et que je ne sers donc pas : une cadence de montage chiffrée
(nombre de plans par spot). Deux pages la promettaient, ouvertes, elles ne la donnent pas.

**Ce qui vaut pour la génération, en propre :**

1. **Un plan = une idée.** Un plan qui contient la chute, l'éclaboussure et le produit ne
   contient rien. Quatre plans de 4 secondes battent un plan de 16.
2. **Le plan où le produit apparaît part d'une image déjà validée** (image de départ) : c'est
   ce qui protège l'emballage. Les plans de matière — chute, éclaboussure, macro — se
   génèrent librement, sans emballage et sans texte dans le cadre.
3. **Le décor de départ n'a pas de bandeau de marque** : un texte incrusté se déforme en
   animation, alors que l'emballage photographié tient.
4. **Recadrer les décors au format du moteur avant d'envoyer** (16:9 ou 9:16), sinon il rogne
   où il veut.
5. **Le contrôle se fait image par image avec `ffmpeg`**, pas sur la vignette : on extrait des
   images au milieu et à la fin de chaque plan, parce qu'un emballage peut dériver après la
   première seconde, et une figuration peut apparaître en cours de plan.

### Le film raconte un MOMENT, il n'énumère pas un produit

Appris en production le 17/08/2026, sur une deuxième série commandée parce que la première
ne suffisait pas. La première suivait une logique de catalogue — la matière, le paquet, la
macro, le point de vente. Techniquement propre, et c'est exactement le reproche qu'on fait
aux bannières des marques : **elles annoncent un produit, aucune ne raconte un moment**.

La grammaire qui tient, en sept plans de trente secondes :

| Plan | Ce qu'on voit |
|---|---|
| 1 · le moment | la vie **avant** le produit — l'ennui, la fatigue, la chaleur, la soif |
| 2 · le geste | la main qui prend, qui déballe. Le produit entre ici, pas avant |
| 3 · la matière | le produit lui-même, en très gros plan, ralenti extrême |
| 4 · la réaction | le visage qui bascule. C'est le plan qui paie le plan 1 |
| 5 · le partage | le produit passe à quelqu'un d'autre |
| 6 · le monde | le lieu, la vie qui reprend, le produit dedans |
| 7 · le carton | le produit seul, composé en local |

Six plans de 4 secondes et un carton de 6 : trente secondes exactement. Chaque produit a
son moment propre — un chauffeur de taxi à l'aube, une bande de copains au coin de la rue,
un maquis à midi, une coureuse au bord de l'eau. C'est le moment qui change d'un film à
l'autre, pas la structure.

### La continuité des visages — la faute qui trahit une série fabriquée

Chaque plan est généré séparément : sans rien faire, le film s'ouvre sur quelqu'un et la
réaction montre une autre personne. Trois visages en trente secondes, et le spectateur le
voit immédiatement — c'est ce qui sépare un film d'un diaporama.

**Le correctif tient en une ligne : on repasse la photographie du PREMIER PLAN comme image
de référence** au moment de fabriquer le plan de réaction (et le plan de partage), avec la
consigne explicite « c'est la même personne : même visage, même âge, mêmes cheveux, mêmes
vêtements ». Vérifié le 17/08/2026 sur huit films — ça marche, et ça coûte le prix d'une
image.

### Le petit texte d'un emballage doit devenir ILLISIBLE, jamais approximatif

Corollaire dur de la règle qui commande tout. Quand le procédé ne sait pas reproduire les
petites mentions d'un paquet, il ne faut pas le laisser essayer : il invente. Relevé réel
le 17/08/2026 — « WORLD WORLD SELLING », « VITAMINE C », des poids nets fantaisistes, sur
un sachet qui porte une vraie pastille d'allégation. Une mention inventée condamne le
visuel ; une **allégation de santé** inventée le condamne deux fois.

La consigne qui règle ça, à ajouter au brief : *le paquet est cadré et éclairé pour que
SEULES les grandes lettres de marque soient lisibles ; le bas du sachet — pastilles, petit
texte, ligne de poids — tombe hors mise au point ou dans l'ombre.*

### Les défauts d'animation viennent presque tous du même geste

Reproche reçu mot pour mot : « les gens ne sont pas assez dynamiques et il y a des bugs ».
Le dépouillement des plans **image par image** — pas la vignette, quatre extractions par
plan — a montré que les défauts n'étaient pas dispersés : ils sortaient tous d'une seule
famille de gestes. Un bras qui **entre** dans le cadre pour servir se dédouble. Une cuillère
qui **sort** du cadre disparaît et ne revient pas. Un objet **passé d'une main à l'autre**
est tenu par un bras qui se déforme. Un liquide qui coule **depuis hors cadre** arrive sans
source visible, comme un filet en l'air.

Un modèle d'animation tient très bien ce qui est déjà dans l'image et se déplace ; il
échoue sur ce qui apparaît, disparaît ou change de main. Donc on **change l'action**, pas
seulement la consigne :

| Au lieu de | On filme |
|---|---|
| un objet passé de main en main | quelqu'un qui **verse** au-dessus de l'assiette que l'autre tend |
| un bras qui entre pour servir | les mains déjà sur le plat au premier instant du plan |
| une cuillère qui sort du cadre | la cuillère qui reste dans le cadre du début à la fin |
| un liquide venu de hors champ | la matière **déjà posée** qui s'étale et prend la lumière |

Et la clause qui va avec, mot pour mot dans chaque plan : *toute main, tout bras et tout
objet visible sur la première image reste entier et présent pendant tout le plan ; rien
n'entre ni ne sort du cadre ; rien ne passe d'une main à l'autre ; aucun liquide ne coule
d'une source invisible ; pas de doigt en trop, pas de membre dupliqué ; si l'action ne peut
pas s'achever en quatre secondes, elle se joue plus lentement plutôt que de se téléporter.*

### « Pas assez dynamique » se règle au montage autant qu'au plan

Deux leviers, et le premier est gratuit :

1. **Plus de plans, plus courts.** Huit plans de trois secondes valent mieux que six de
   quatre : le film respire plus vite sans qu'un seul rendu change. On garde la meilleure
   moitié de chaque plan — le début, où l'action est nette — et on coupe avant que le
   modèle ne s'essouffle : les fins de plan sont presque toujours molles.
2. **Des gestes forts et nommés.** Un plat brûlant posé d'un coup, un rire de table qui part
   d'un seul mouvement, une main qui claque le bois, un taxi-moto qui traverse le premier
   plan. « La scène respire » ne produit rien ; « elle rejette la tête en arrière et ses
   épaules tremblent » produit un plan.

### Le contrôle des photographies passe AVANT l'animation

Une correction sur une photographie coûte le prix d'une image ; la même correction après
animation coûte le plan entier. On regarde donc les 6 photographies de chaque film avant
d'en commander un seul plan, et on cherche trois choses précises :

1. **Un produit inventé dans le cadre** — une bouteille de boisson avec son étiquette, un
   paquet reconstitué. Relevé deux fois en une seule série.
2. **Une marque tierce** — une bouteille d'huile de marque réelle posée sur la table du
   décor. Indéfendable, et personne ne la cherche à cet endroit.
3. **Le mauvais produit de la gamme** — un bonbon de la mauvaise couleur, une sucette du
   mauvais parfum, un berlingot rayé à la place du bonbon de la marque. Ce n'est pas
   inventé, c'est *faux*, et ça se voit du premier coup d'œil chez le client.

Et une quatrième, de cohérence : la figuration du plan de partage doit être celle du film.
Des adultes dans un film qui raconte des enfants, ça se remarque.

### Le son ne se fabrique pas dans les plans

C'est le point qui sépare un enchaînement de clips d'un film. Un générateur sait mettre une
voix et une musique dans un plan, mais **chaque plan repart avec les siennes** : recollés, on
entend autant de comédiens et de musiques que de plans. Et l'outil d'assemblage en ligne ne
sait pas poser un son extérieur.

Donc, systématiquement :

1. **La consigne de chaque plan dit « ambiance seule, aucune musique, aucun jingle »**, et le
   son rendu est jeté au montage.
2. **La voix off s'enregistre à part**, une seule voix pour tout le film, avec un outil de
   synthèse vocale. Elle se pose au chronomètre sur le film monté.
3. **Un seul lit musical continu** court sous toute la durée, baissé d'environ 17 décibels
   sous la voix, avec un fondu d'entrée et de sortie.
4. 🚨 **Une musique par film, jamais un lit musical partagé entre plusieurs films.** C'est
   l'erreur qui a rendu une série de huit films audiblement industrielle : les images étaient
   différentes, la bande son était la même, et c'est la bande son qu'on reconnaît. Un score
   dédié se commande à un générateur de musique pour le prix d'un plan de quatre secondes —
   c'est le meilleur rapport qualité-prix de toute la chaîne dès qu'un film doit paraître
   « grand format ». On le compose sur les instruments du marché visé, avec les mouvements
   demandés au bon moment : la percussion qui entre quand le produit entre, la montée sur le
   plan de partage.
   ⚠️ **Un générateur de musique rend souvent un peu moins que la durée demandée** — quelques
   dixièmes de seconde. On complète le lit en silence vers une durée plus longue que le film
   avant de monter, sinon la fin du film n'a plus de musique et rien ne le signale.
5. 🚨 **Chaque ligne de voix se vérifie par transcription**, avant montage et sur le film
   monté. C'est le seul moyen de lire ce qui est réellement prononcé : c'est ce contrôle qui
   attrape une date fausse ou un nom de marque écorché. Une ligne qui se transcrit mal se
   refait — c'est ce qu'il y a de moins cher dans toute la chaîne.
6. **La durée de la voix décide de la durée du plan**, jamais l'inverse. On mesure le fichier
   rendu ; une ligne trop longue fait passer le plan à la durée supérieure, ou se raccourcit.
7. **Un nom de marque se teste en plusieurs graphies** dans le texte donné à la synthèse : un
   nom en deux mots sort parfois déformé là où le même nom collé sort juste.

### « Ça fait trop artificiel » — trois leviers, et le timbre est le dernier

Reproche reçu mot pour mot d'un client le 17/08/2026, sur des films par ailleurs corrects.
La réaction naturelle — changer de voix — ne règle qu'un tiers du problème.

1. **Le réglage.** Une voix de synthèse laissée à ses valeurs par défaut *lit*. Ce qui la
   fait *parler* : **stabilité basse** (0,35 à 0,45 — plus haut, elle devient plate),
   **débit ralenti** (0,94 à 0,96), ressemblance moyenne (0,5 à 0,6). Ce sont les valeurs
   retenues en production, pas des valeurs de doctrine : elles se revérifient à l'oreille du
   client.
2. **L'écriture.** Une accroche qui a l'air d'un slogan sonne récitée. « Ah… ça, c'est la
   fraîcheur qui réveille » s'entend comme une phrase ; « Il y a des fraîcheurs qui
   réveillent » s'entend comme une affiche. On écrit des phrases qui se **disent**, avec des
   suspensions et des respirations écrites dans la ponctuation.
3. **Le jeu.** Les modèles récents lisent des **balises de jeu écrites dans le texte** —
   `[warm]`, `[excited]` — sans les prononcer. Une indication en début de ligne, comme sur un
   plateau, change tout le rendu.

🚨 **Une voix écartée comme « trop artificielle » se réessaie réglée avant d'être enterrée.**
C'est l'erreur symétrique de la précédente, et elle coûte le seul atout qu'on avait : la voix
de la région du client a été jugée sur une prise aux valeurs par défaut, écartée pour cette
raison, remplacée par un timbre à l'accent étranger au marché — puis reprise avec les trois
leviers ci-dessus, elle tenait parfaitement. Ce n'était pas le timbre, c'était le réglage et
l'écriture. Donc aucune voix ne se déclare inutilisable avant d'avoir été entendue réglée.

🚨 **Un timbre ne se choisit pas à ma place : je ne peux pas l'entendre.** On envoie au
client **trois à cinq essais de trois secondes** sur les deux mêmes phrases, étiquetés A, B,
C… Il répond par une lettre. C'est la seule méthode honnête, et elle prend cinq minutes.

⚠️ **L'arbitrage qui compte n'est pas « humaine ou pas », c'est l'accent.** Le catalogue peut
ne contenir qu'**une seule** voix de la région du client. Les autres sonnent souvent plus
vivantes, avec un accent qui n'est pas celui du marché. Pour une marque locale qui diffuse
dans plusieurs pays, ce n'est pas un détail de production : ça se dit au client **avant** de
monter, et c'est lui qui tranche.

⚠️ **La transcription de contrôle juge MAL les noms de marque.** Les clôtures de films
sortent en « Criminaux, une marque Tommy » ou « Sauce A, une marque Unifood » alors que la
prise est bonne. On ne refait donc une prise que si un mot **ordinaire** est faux — « la mode
noire » pour « la menthe noire », « pression maximale » pour « fraîcheur maximale ». Sans
cette distinction, on refait indéfiniment des prises correctes.

⚠️ **Une clé de fichier de voix déjà utilisée ne se régénère pas** : l'outil saute ce qui
existe et on monte, sans s'en apercevoir, la prise d'un essai antérieur. Clés neuves à chaque
film.

### Le montage — quatre pièges qui ne préviennent pas

Chacun laisse sortir un film d'apparence normale. C'est pour ça qu'ils coûtent cher.

1. **Le carton de fin ne se fait pas générer, il se compose.** Un générateur redessine les
   petits textes et abîme l'adresse du site ou une mention. On compose le carton en image
   avec le gabarit à bandeau, puis on l'anime en local — un zoom très lent suffit. Il faut
   le sortir à la **même cadence d'images** que les plans, sinon le collage boite.
2. **Recoller des fichiers sans ré-encoder perd des images** quand les plans n'ont pas la
   même base de temps : un film de trente secondes peut sortir à vingt-six, sans erreur et
   sans avertissement, une ligne de voix envolée avec. On ré-encode le collage, et **on
   vérifie la durée du fichier livré**.
3. **Jamais de boucle de musique dans le graphe de montage.** La mémoire enfle et rien ne
   s'écrit. On prépare un lit musical fini, plus long que le film, avant le montage.
4. **Un seul montage à la fois.** Deux assemblages en parallèle se privent mutuellement de
   processeur et aucun n'aboutit — on croit à une panne alors que c'est un embouteillage.

5. **Une coupe dans un plan raccourcit le film de deux ou trois centièmes**, et sur huit
   plans ça fait deux dixièmes de moins que la somme annoncée. Trois choses à savoir : demander
   à un plan plus que sa durée réelle ne rallonge rien ; **le carton de fin est fabriqué chez
   soi, donc c'est lui qui porte la différence** — un zoom lent se ralentit de quelques
   centièmes sans que personne le voie ; et la coupe à la durée exacte se fait **au dernier
   encodage**, pas en recopie, une recopie s'arrêtant sur une frontière d'image.

La vérification qui rattrape les quatre : **la durée du fichier livré est celle annoncée**,
et la transcription du film monté contient **toutes** les lignes de voix.

### Le meilleur montage pille les séries précédentes

Quand une deuxième série remplace une première, les plans de la première **restent payés**.
Sur une refonte, le plan de matière de l'ancienne version s'est révélé meilleur que celui de
la nouvelle, qui était construite sur les visages : le film livré mélange les deux, la table
et le geste de la seconde série, la matière de la première. Ça ne coûte que le temps du
collage, et c'est souvent le vrai saut de qualité — donc avant de relancer des rendus pour un
film « grand format », on rouvre ce qui existe déjà et on compare plan par plan.

### Le jeu de durées se tire du même matériel

Le 30 secondes, la coupe 15 secondes et le bumper 6 secondes se montent depuis les **mêmes
plans**, en les raccourcissant — pas en relançant des rendus. La coupe courte n'est pas un
résumé de la longue : elle porte sa propre accroche et sa propre chute, donc son propre
ordre de plans et ses propres lignes de voix. Le vertical, lui, se **refait** : un 16/9
recadré perd le produit sur le côté du cadre.

## Le contrôle avant livraison

Sur **chaque** visuel du lot, dans cet ordre. Un lot de vingt ne se relit pas « globalement ».

1. Aucun texte, aucun logo, aucune marque **inventés par le générateur**.
2. **Chaque mot de chaque emballage se lit**, y compris les petites lignes du bas et le
   format du conditionnement. C'est le contrôle qui attrape « Suner Mentol », un sachet
   devenu bonbon unitaire, un couvercle qui porte deux fois le nom de la marque. Une mention
   réglementaire déformée — taux, composition, absence d'un ingrédient — condamne le visuel
   sans discussion.
3. Aucun liseré ni rectangle clair autour d'un emballage incrusté.
4. Titre, signature et produit dans leurs bandes ; rien qui se chevauche.
5. Titre lisible sur son fond.
6. Le produit **repose** sur une surface et porte son ombre de contact — il ne flotte pas.
7. Chaque personne du cadre correspond au marché du client, arrière-plans compris.
8. L'accroche dit bien ce que l'emballage annonce. Un paquet qui promet « deux fois plus
   gros » et une accroche qui dit « deux fois plus longtemps », c'est une promesse fabriquée.
9. Le pied de page ne porte que des mentions **vérifiées**. Un numéro de téléphone au format
   périmé ne s'imprime pas : l'emplacement reste vide et on le signale.
10. Aucune allégation non sourcée dans l'accroche — ni composition, ni rang, ni performance,
   ni usage professionnel. Et une **image** peut affirmer autant qu'une phrase : un ingrédient
   montré suggère une composition, et cela se fait valider comme un texte.

## Ce qui ne part jamais sans accord écrit

Publier, diffuser, envoyer à l'impression, signer un bon à tirer, engager une dépense
d'espace. Un lot de visuels se **prépare** et se **pose sur la table**. Et sans mandat écrit
de la marque, rien ne se publie, même si le travail est bon.

## Les outils fournis

- `scripts/composer.py` — primitives d'incrustation : ombre portée, pose, voile, découpe.
- `scripts/mise_en_page.py` — la grille à bandes réservées, le garde de lisibilité, le pied
  de page, la signature. Paramétrable par marque.
- `scripts/detourer.py` — détourage des emballages + contrôle du pourtour.
- `scripts/generer_decors.py` — production d'un lot de décors depuis un brief JSON.
- `scripts/generer_lot_images.py` — un lot de photographies fixes depuis un brief JSON.
  Accepte **plusieurs références par image** (`packs`), et des **références brutes**
  (`refs_brutes`) : c'est ce qui permet de repasser la photographie du premier plan pour
  garder le même visage.
- `scripts/generer_lot_plans.py` — un lot de plans animés, chacun démarré sur sa
  photographie. Chiffre le lot avant de lancer. Par lots de neuf : au-delà d'une dizaine
  de plans simultanés, le service refuse.
- `scripts/voix_off.py` — les lignes de voix off. Porte les réglages qui enlèvent le côté
  mécanique (stabilité, débit, ressemblance) et accepte les balises de jeu dans le texte.
- `scripts/monter_pub.py` — montage d'un film : plans bout à bout, voix off posée au
  chronomètre, lit musical continu, coupes courtes tirées du même matériel. Demande
  `ffmpeg` (binaire statique dans `~/.local/bin` si le système n'en fournit pas).
  Variables : `REENCODER=1` (obligatoire dès que les plans n'ont pas la même base de
  temps), `PRESET`, `CRF`.
- `references/marque.exemple.json` — le dossier de marque à remplir.
- `references/consignes-decor.md` — comment écrire une consigne de décor qui laisse une zone
  libre exploitable, avec des exemples.
