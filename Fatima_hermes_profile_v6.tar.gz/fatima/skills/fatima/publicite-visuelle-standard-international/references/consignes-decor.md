# Écrire une consigne de décor

Un décor est une image **sans produit, sans logo, sans texte**, qui porte une zone libre
réellement éclairée où l'emballage officiel sera incrusté ensuite. C'est la seule façon
d'obtenir un visuel de marque sans qu'un générateur redessine la marque.

## Encadrer une créativité, ne pas dicter une exécution

🚨 **La faute qui vide le travail de son sens**, commise le 13/08/2026 : à qui demandait la
même série chez un second générateur, redonner les consignes de décor **mot pour mot**. On
obtient des jumelles — seul le rendu du moteur varie, il ne reste rien à créer, et le client
le voit tout de suite.

**Chaque modèle génère son propre décor.** Ce qui reste constant d'un modèle à l'autre, c'est
la méthode ; la création, non. Le brief ne décrit donc pas la scène : il donne l'intention et
le cadre, et laisse le modèle inventer la composition, le décor, la matière, le geste et la
caméra.

Le gabarit, tel qu'il tourne :

> You are the art director of an international advertising agency. Invent an ORIGINAL
> advertising scene — the composition, the setting, the material, the gesture and the camera
> are yours to choose. Do not default to the obvious.
>
> **BRIEF**
> · Product this image will advertise (it will be added later, do NOT draw it): ⟦produit⟧.
> · The single idea the image must carry: ⟦l'idée, en une phrase⟧.
> · Colour field: ⟦champ de couleur⟧. One single colour field, occupied in full, worked with
> material, grain and depth — never a dead flat background.
>
> **NON-NEGOTIABLE CONSTRAINTS**
> 1. ONE subject, ONE focal zone, ONE idea. Nothing decorative.
> 2. Leave a GENEROUS EMPTY AREA, clean and evenly lit, sized for a product to be composited
> later, with a credible contact shadow or resting surface. **You choose where it sits**; it
> must be obvious and usable.
> 3. NO product, NO packaging, NO label, NO logo, NO brand mark, NO text, NO lettering, NO
> numbers, NO watermark anywhere.
> 4. One dominant light source. Premium advertising photography, cinematic depth, controlled
> falloff, high end commercial retouching, 8k.
> 5. If any person appears — including blurred background silhouettes and hands cropped by the
> edge — EVERY person is ⟦appartenance du marché du client, en toutes lettres⟧. State it for
> each person. No exception.

L'idée unique est la seule pièce vraiment difficile à écrire : « il tient, il ne coule pas »,
« la taille des petites mains », « cinq fruits dans une seule sucette ». C'est elle qui fait
la publicité — le reste n'est que discipline.

Ce qui suit reste utile quand on veut, à l'inverse, **verrouiller** une scène précise : une
déclinaison à l'identique dans une autre langue, un rattrapage, une reprise de gabarit.

## L'ossature, dans cet ordre

1. **Le registre** — « editorial food advertising photograph, museum quality »,
   « cinematic photograph », « dark still life in the style of a Dutch master painting ».
2. **Le sujet, c'est la matière** — la substance du produit, agrandie, sculptée, en
   mouvement figé. Pas le contenant.
3. **Le champ de couleur** — celui de la marque, nommé et décrit comme travaillé
   (« seamless deep emerald green studio background », « rich saturated single colour field »).
4. **La lumière**, en une phrase : d'où elle vient, ce qu'elle fait.
5. **La zone libre**, décrite par sa position et son état : *« Generous empty evenly-lit
   green space on the right two fifths of the frame, completely clear, reserved for a
   product to be added later. »* Sans cette phrase, le générateur remplit tout le cadre et
   il ne reste nulle part où poser l'emballage.
6. **Le casting, en toutes lettres**, pour chaque personne du cadre, arrière-plans compris.
   Recopier la phrase du dossier de marque, en majuscules pour qu'elle porte.
7. **La liste des interdits**, toujours la même : *no packaging, no jar, no bottle, no
   label, no logo, no text, no lettering, no watermark* — plus tout objet de marque
   spécifique au secteur.
8. **La technique** — appareil, focale, ouverture, niveau de retouche.

## Deux exemples qui ont fonctionné

**Matière seule, zone libre à droite**

> Editorial food advertising photograph, museum quality. A single sculpted quenelle of thick
> glossy pale-ivory cream, sharp peak and smooth spoon facets, on a seamless deep emerald green
> studio background. Extreme detail on the micro-texture and specular sheen. One large soft key
> light from top left, subtle rim light, soft contact shadow underneath. Rich saturated single
> colour field, shallow depth of field. **Generous empty evenly-lit green space on the right two
> fifths of the frame, completely clear, reserved for a product to be added later.** Absolutely
> no product packaging, no jar, no bottle, no label, no logo, no text, no lettering, no watermark.
> Medium format, 100mm macro, f8, high end commercial retouching.

**Avec une personne, casting explicite**

> Premium brand portrait. **A BLACK AFRICAN woman chef in her thirties with deep dark brown skin
> and short natural hair**, immaculate white chef jacket, looking straight into the camera with a
> calm proud half smile. **Every person in the frame is Black African with dark brown skin.** Deep
> emerald green seamless studio backdrop, beauty dish key from the front left, gentle rim light.
> She is placed on the right third. **The left half of the frame is empty evenly lit green
> backdrop, reserved for a product to be added later.** No packaging, no jar, no label, no logo,
> no text, no lettering, no apron writing, no watermark. Editorial fashion food crossover, medium
> format, flawless commercial retouching.

## Ce qui rate

- **Pas de zone libre décrite** → le cadre est plein, l'emballage se pose sur le sujet.
- **Casting muet** → personnes blanches par défaut, quel que soit le pays décrit.
- **Emballages donnés en référence** → le générateur les redessine et invente des marques.
  Il ne voit jamais les emballages : ils sont incrustés après.
- **Interdits oubliés** → du faux texte apparaît sur les surfaces, illisible et disqualifiant.
- **Deux sujets dans une consigne** → deux zones focales, la règle 2 tombe.
