#!/usr/bin/env python3
"""Fait produire un lot de vidéos par Magnific, puis les récupère.

Usage : python3 video-lot.py <fichier_json> <dossier_sortie> --je-paie

⚠️ COÛTE DES CRÉDITS, et la vidéo coûte dix fois l'image : relevé le 17/08/2026 au
simulateur gratuit — 140 crédits un plan de 5 s en 720p chez Kling 2.5, 325 en 1080p,
320 un plan de 8 s chez Veo 3.1 lite (même prix en 720p et en 1080p, donc on prend 1080p).
Le simulateur donne ces valeurs comme exactes ; elles se revérifient avant chaque lot.

Chaque tâche du JSON :
  {"cle": "...", "slug": "...", "duree": 8, "definition": "1080p", "format": "16:9",
   "consigne": "...", "image_depart": "<identifiant de création>"}
"""
import json, os, sys, time, urllib.request

sys.path.insert(0, "/home/openclaw/agents/fatima/integrations/magnific")
from appeler import rpc

if len(sys.argv) < 4 or "--je-paie" not in sys.argv:
    print(__doc__, file=sys.stderr); sys.exit(2)
taches = json.load(open(sys.argv[1]))
sortie = sys.argv[2]
os.makedirs(sortie, exist_ok=True)

rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "fatima", "version": "1"}})


def texte(r):
    return "".join(c.get("text", "") for c in r.get("content", []))


# On chiffre AVANT de lancer, et on annonce. Le simulateur est gratuit.
total = 0
for t in taches:
    a = {"slug": t["slug"], "duration": t["duree"], "prompt": t["consigne"],
         "aspectRatio": t.get("format", "16:9"), "resolution": t.get("definition", "1080p")}
    try:
        d = json.loads(texte(rpc("tools/call", {"name": "simulate_cost",
                                                "arguments": {"tool": "video_generate",
                                                              "arguments": a}})))
        total += d.get("credits", 0)
    except Exception as ex:
        print(f"chiffrage impossible pour {t['cle']} : {ex}", file=sys.stderr)
print(f"coût annoncé du lot : {total} crédits", flush=True)

attente = {}
for t in taches:
    dest = os.path.join(sortie, f"{t['cle']}.mp4")
    if os.path.exists(dest):
        print(f"{t['cle']} déjà là"); continue
    clip = {"slug": t["slug"], "duration": t["duree"], "prompt": t["consigne"],
            "aspectRatio": t.get("format", "16:9"),
            "resolution": t.get("definition", "1080p")}
    if t.get("image_depart"):
        clip["keyframes"] = {"start": {"type": "image", "url": t["image_depart"]}}
    r = None
    for essai in range(4):
        try:
            r = rpc("tools/call", {"name": "video_generate",
                                   "arguments": {"video": {"clips": [clip]}}})
            break
        except Exception as ex:
            if essai == 3:
                print(f"{t['cle']} ÉCHEC : {ex}", file=sys.stderr)
            else:
                time.sleep(20 * (essai + 1))
    if r is None:
        continue
    tx = texte(r)
    ids = []
    if '{"creations"' in tx:
        ids = [c["identifier"]
               for c in json.loads(tx[tx.index('{"creations"'):])["creations"]]
    if not ids:
        print(f"{t['cle']} ÉCHEC : {tx[:200]}", file=sys.stderr); continue
    attente[ids[0]] = t["cle"]
    print(f"{t['cle']} en file ({ids[0]})", flush=True)

restants = list(attente)
while restants:
    lot = restants[:8]
    r = rpc("tools/call", {"name": "creations_wait",
                           "arguments": {"identifiers": lot, "timeoutSeconds": 25}})
    d = json.loads(texte(r))
    fini = []
    for e in d.get("results", []):
        if e.get("status") == "completed":
            url = e["results"]["url"]
            dest = os.path.join(sortie, f"{attente[e['identifier']]}.mp4")
            with urllib.request.urlopen(url, timeout=600) as rep:
                open(dest, "wb").write(rep.read())
            # la vignette sert de contrôle : sans lecteur vidéo ici, c'est la seule image
            vign = e["results"].get("thumbnailUrl") or e["results"].get("previewUrl")
            if vign:
                try:
                    with urllib.request.urlopen(vign, timeout=120) as rep:
                        open(dest.replace(".mp4", "-vignette.jpg"), "wb").write(rep.read())
                except Exception:
                    pass
            print(f"{attente[e['identifier']]} ok", flush=True)
            fini.append(e["identifier"])
        elif e.get("status") in ("failed", "error"):
            print(f"{attente[e['identifier']]} ÉCHEC", file=sys.stderr)
            fini.append(e["identifier"])
    restants = [i for i in restants if i not in fini]
    if restants and not fini:
        time.sleep(15)
