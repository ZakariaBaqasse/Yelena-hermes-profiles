#!/usr/bin/env python3
"""Fait produire un lot de décors par Magnific, puis les récupère.

Un décor NE CONTIENT JAMAIS le produit, le logo ni le texte : il porte une zone
libre éclairée où l'emballage officiel sera incrusté ensuite. Voir
references/consignes-decor.md.

Usage : python3 magnific-lot.py <fichier_json> <dossier_sortie> --je-paie

⚠️ COÛTE DES CRÉDITS : environ 100 par image (vérifié le 13/08/2026 avec
simulate_cost). Le solde se lit gratuitement avec account_balance.
"""
import json, os, sys, time, urllib.request
sys.path.insert(0, "/home/openclaw/agents/fatima/integrations/magnific")
from appeler import rpc

if len(sys.argv) < 4 or "--je-paie" not in sys.argv:
    print(__doc__, file=sys.stderr); sys.exit(2)
taches = json.load(open(sys.argv[1]))
sortie = sys.argv[2]
os.makedirs(sortie, exist_ok=True)

rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "fatima", "version": "1"}})

attente = {}
for t in taches:
    dest = os.path.join(sortie, f"{t['cle']}.png")
    if os.path.exists(dest):
        print(f"{t['cle']} déjà là"); continue
    r = rpc("tools/call", {"name": "images_generate", "arguments": {
        "prompt": t["consigne"], "numImages": 1,
        "aspectRatio": t.get("ratio", "4:5")}})
    texte = "".join(c.get("text", "") for c in r.get("content", []))
    ids = [c["identifier"] for c in json.loads(texte[texte.index("{\"creations\""):])["creations"]] \
        if "{\"creations\"" in texte else []
    if not ids:
        print(f"{t['cle']} ÉCHEC : {texte[:160]}", file=sys.stderr); continue
    attente[ids[0]] = t["cle"]
    print(f"{t['cle']} en file ({ids[0]})", flush=True)

restants = list(attente)
while restants:
    lot = restants[:8]
    r = rpc("tools/call", {"name": "creations_wait",
                           "arguments": {"identifiers": lot, "timeoutSeconds": 25}})
    texte = "".join(c.get("text", "") for c in r.get("content", []))
    d = json.loads(texte)
    fini = []
    for e in d.get("results", []):
        if e.get("status") == "completed":
            url = e["results"]["url"]
            dest = os.path.join(sortie, f"{attente[e['identifier']]}.png")
            with urllib.request.urlopen(url, timeout=300) as rep:
                open(dest, "wb").write(rep.read())
            print(f"{attente[e['identifier']]} ok", flush=True)
            fini.append(e["identifier"])
        elif e.get("status") in ("failed", "error"):
            print(f"{attente[e['identifier']]} ÉCHEC", file=sys.stderr)
            fini.append(e["identifier"])
    restants = [i for i in restants if i not in fini]
    if restants and not fini:
        time.sleep(10)
