#!/usr/bin/env python3
"""Grille de mise en page au standard international — indépendante de la marque.

Le titre occupe une bande réservée, la signature de marque occupe la bande opposée,
le centre du produit est borné à la bande centrale : rien ne peut se chevaucher,
quelles que soient les valeurs passées. Un garde de lisibilité mesure la bande du
titre et y confine le voile nécessaire.

Les valeurs propres à la marque (site, origine, téléphone) se chargent avec
charger_marque(). Elles ne sont jamais codées ici.
"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from composer import POLICES, ombre, ouvrir, recadrer, enregistrer
from PIL import Image, ImageDraw, ImageFilter, ImageFont

# Polices par défaut — remplaçables par celles de la charte du client.
POLICES["intl"] = "/home/openclaw/.local/share/fonts/poppins/Poppins-SemiBold.ttf"
POLICES["intl_gras"] = "/home/openclaw/.local/share/fonts/poppins/Poppins-ExtraBold.ttf"
POLICES["pied"] = "/home/openclaw/.local/share/fonts/poppins/Poppins-Medium.ttf"

# Valeurs de marque — à charger depuis le dossier de marque, jamais codées en dur ici.
SITE = ""
ORIGINE = ""
TEL = ""


def charger_marque(chemin):
    """Charge le dossier de marque (JSON) : site, origine, téléphone du pied de page."""
    import json
    global SITE, ORIGINE, TEL
    d = json.load(open(chemin))
    pied = d.get("pied_de_page", {})
    SITE = pied.get("site", "")
    ORIGINE = pied.get("origine", "")
    TEL = pied.get("telephone", "")
    return d


def _decouper(texte, police, largeur, d):
    lignes, cur = [], ""
    for mot in texte.split():
        essai = (cur + " " + mot).strip()
        if d.textlength(essai, font=police) <= largeur:
            cur = essai
        else:
            if cur:
                lignes.append(cur)
            cur = mot
    if cur:
        lignes.append(cur)
    return lignes


def produit(scene, chemin, centre, hauteur, rotation=0, flou_ombre=26, opacite=135):
    obj = Image.open(chemin).convert("RGBA")
    h = int(scene.height * hauteur)
    obj = obj.resize((max(1, int(obj.width * h / obj.height)), h), Image.LANCZOS)
    if rotation:
        obj = obj.rotate(rotation, expand=True, resample=Image.BICUBIC)
    x = int(scene.width * centre[0] - obj.width / 2)
    y = int(scene.height * centre[1] - obj.height / 2)
    om = ombre(obj, flou=flou_ombre, opacite=opacite, decalage=(6, int(obj.height * .06)))
    scene.alpha_composite(om, (x - 40, y - 40))
    scene.alpha_composite(obj, (x, y))
    return scene


# Bandes réservées, en fraction de la hauteur. Rien ne les traverse.
BANDE_TITRE_HAUT = (.045, .225)
BANDE_TITRE_BAS = (.700, .880)


def titre(scene, texte, haut=True, taille=.052, couleur=(255, 255, 255), marge=.072):
    """Le titre reste dans sa bande. Rien d'autre n'y entre."""
    d = ImageDraw.Draw(scene)
    f = ImageFont.truetype(POLICES["intl_gras"], int(scene.height * taille))
    lignes = _decouper(texte, f, scene.width * (1 - 2 * marge) * .82, d)
    pas = int(scene.height * taille * 1.16)
    y0, y1 = BANDE_TITRE_HAUT if haut else BANDE_TITRE_BAS
    y = int(scene.height * y0) if haut else int(scene.height * y1) - pas * len(lignes)
    for l in lignes:
        d.text((int(scene.width * marge), y), l, font=f, fill=couleur)
        y += pas
    return scene


def pied(scene, couleur=(255, 255, 255), avec_tel=True, opacite_trait=70):
    """Bande de pied : filet fin, adresse du site à gauche, origine à droite."""
    d = ImageDraw.Draw(scene, "RGBA")
    m = int(scene.width * .072)
    yb = int(scene.height * (1 - .052))
    d.line([(m, yb - int(scene.height * .028)), (scene.width - m, yb - int(scene.height * .028))],
           fill=couleur + (opacite_trait,), width=max(1, int(scene.height * .0016)))
    f = ImageFont.truetype(POLICES["pied"], int(scene.height * .0205))
    gauche = SITE + ("   ·   " + TEL if (avec_tel and TEL) else "")
    y = yb - int(scene.height * .012)
    d.text((m, y), gauche, font=f, fill=couleur + (235,))
    dispo = scene.width - 2 * m - d.textlength(gauche, font=f) - int(scene.width * .04)
    droite = ORIGINE
    if d.textlength(droite, font=f) > dispo:
        droite = "Abidjan · Lomé · depuis 1994"
    if d.textlength(droite, font=f) > dispo:
        droite = "depuis 1994"
    if d.textlength(droite, font=f) <= dispo:
        d.text((scene.width - m - d.textlength(droite, font=f), y), droite,
               font=f, fill=couleur + (185,))
    return scene


def signature(scene, chemin_logo, hauteur=.052, titre_en_haut=True, marge=.072):
    """Rappel de marque discret, toujours dans la bande OPPOSÉE au titre, à droite.

    Le logo principal reste porté par l'emballage : celui-ci n'est qu'une signature.
    Il ne peut jamais rencontrer le titre, puisqu'il occupe l'autre bande.
    """
    logo = Image.open(chemin_logo).convert("RGBA")
    h = int(scene.height * hauteur)
    logo = logo.resize((max(1, int(logo.width * h / logo.height)), h), Image.LANCZOS)
    x = scene.width - logo.width - int(scene.width * marge)
    y = int(scene.height * BANDE_TITRE_BAS[1]) - logo.height if titre_en_haut \
        else int(scene.height * BANDE_TITRE_HAUT[0])
    scene.alpha_composite(logo, (x, y))
    return scene


def _voile_bande(scene, haut, force=90, marge_fondu=.075):
    """Voile sombre confiné à la bande du titre, fondu doux au-delà."""
    w, h = scene.width, scene.height
    y0, y1 = BANDE_TITRE_HAUT if haut else BANDE_TITRE_BAS
    a, b = int(h * y0), int(h * y1)
    fondu = max(1, int(h * marge_fondu))
    v = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(v)
    depart = 0 if haut else b + fondu
    fin = a - fondu if haut else h
    d.rectangle([0, min(depart, a), w, max(b, fin)], fill=0)
    d.rectangle([0, 0 if haut else a, w, b if haut else h], fill=force)
    for i in range(fondu):                       # fondu du côté de l'image
        y = b + i if haut else a - 1 - i
        if 0 <= y < h:
            d.line([(0, y), (w, y)], fill=int(force * ((fondu - i) / fondu) ** 1.5))
    noir = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    noir.putalpha(v)
    scene.alpha_composite(noir)
    return scene


def garde_titre(scene, haut=True, marge=.072):
    """Mesure la bande du titre et y ajoute le voile nécessaire.

    Renvoie la couleur de texte à employer. Une bande claire et calme garde un
    texte sombre ; toute bande agitée est assombrie jusqu'à ce que le blanc tienne.
    """
    y0, y1 = BANDE_TITRE_HAUT if haut else BANDE_TITRE_BAS

    def stats():
        z = scene.convert("RGB").crop((int(scene.width * marge * .5), int(scene.height * (y0 - .01)),
                                       int(scene.width * (1 - marge * .5)), int(scene.height * (y1 + .01))))
        px = [.299 * r + .587 * g + .114 * b for r, g, b in z.resize((44, 18)).getdata()]
        moy = sum(px) / len(px)
        return moy, (sum((v - moy) ** 2 for v in px) / len(px)) ** .5

    moy, ec = stats()
    if moy >= 158 and ec <= 30:
        return (16, 18, 22)
    for _ in range(6):
        moy, ec = stats()
        if moy <= 92 and ec <= 38:
            break
        _voile_bande(scene, haut, force=80)
    return (255, 255, 255)


def assombrir(scene, cote="bas", part=.34, force=150):
    h, w = scene.height, scene.width
    v = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(v)
    n = int(h * part)
    for i in range(n):
        a = int(force * ((n - i) / n) ** 1.7)
        d.line([(0, h - 1 - i), (w, h - 1 - i)] if cote == "bas" else [(0, i), (w, i)], fill=a)
    noir = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    noir.putalpha(v)
    scene.alpha_composite(noir)
    return scene
