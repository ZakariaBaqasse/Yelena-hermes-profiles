#!/usr/bin/env python3
"""Monte une publicité : plans bout à bout, voix off posée au chronomètre, lit musical.

Pourquoi le son se refait ici. Le générateur sait mettre une voix dans un plan, mais
chaque plan repart avec sa propre voix et sa propre musique : recollés, on entend sept
comédiens et sept musiques. Un montage publicitaire, c'est l'inverse — UNE voix, UN lit
musical continu, et des plans qui ne portent que leur image. On jette donc le son des
plans, on pose les lignes de voix aux minutages voulus, et une seule musique dessous.

Le fichier de montage (JSON) :

  {"plans": [{"fichier": "M1.mp4"}, {"fichier": "M2.mp4"}],
   "voix":  [{"fichier": "L1.mp3", "a": 0.4}, {"fichier": "L2.mp3", "a": 6.4}],
   "musique": "musique.mp3", "musique_db": -16}

`a` est la seconde de départ de la ligne dans le film fini.

Usage : python3 monter-pub.py <montage.json> <sortie.mp4>
"""
import json, os, subprocess, sys

FFMPEG = os.path.expanduser("~/.local/bin/ffmpeg")


def duree(chemin):
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", chemin], capture_output=True, text=True)
    for l in r.stderr.splitlines():
        if "Duration:" in l:
            h, m, s = l.split("Duration:")[1].split(",")[0].strip().split(":")
            return int(h) * 3600 + int(m) * 60 + float(s)
    raise RuntimeError(f"durée illisible : {chemin}")


def monter(m, sortie):
    """Trois passes légères plutôt qu'un seul gros passage.

    ⚠️ Assembler l'image ET le son en une seule commande fait décoder sept flux 1080p en
    même temps que le mixage : la mémoire monte à près d'un gigaoctet et le montage n'écrit
    jamais rien (constaté le 17/08/2026, plusieurs fois de suite). On sépare donc :
    1. les images bout à bout, sans son ;
    2. la bande son seule — voix posées au chronomètre et lit musical ;
    3. on colle les deux sans ré-encoder, c'est instantané.
    """
    plans = [p["fichier"] for p in m["plans"]]
    voix = m.get("voix", [])
    musique = m.get("musique")
    db = m.get("musique_db", -16)
    total = sum(p.get("duree") or (duree(p["fichier"]) - p.get("debut", 0))
                for p in m["plans"])

    base = os.path.splitext(sortie)[0]
    muet, bande = base + "-image.mp4", base + "-son.m4a"
    n = len(plans)

    # ---- passe 1 : les images, sans son
    # Si aucun plan n'est raccourci et que tous ont le même format, on recolle SANS
    # ré-encoder : c'est instantané, là où un ré-encodage de sept plans en pleine
    # définition demande plusieurs minutes et sature la machine.
    if os.environ.get("REENCODER") != "1" and \
            not any(p.get("debut") or p.get("duree") for p in m["plans"]):
        # ⚠️ On passe par des fichiers de transport (.ts) intermédiaires. Recoller
        # directement des .mp4 « bout à bout » perd des images quand les plans n'ont pas
        # exactement la même base de temps : le film sort quatre secondes trop court sans
        # que rien ne signale l'erreur (constaté le 17/08/2026). Le remultiplexage en .ts
        # est instantané et conserve toutes les images.
        temps = []
        for k, p in enumerate(plans):
            t = f"{base}-{k:02d}.ts"
            subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", p,
                            "-c", "copy", "-bsf:v", "h264_mp4toannexb",
                            "-f", "mpegts", t], check=True)
            temps.append(t)
        liste = base + "-liste.txt"
        with open(liste, "w") as fl:
            for t in temps:
                fl.write("file '%s'\n" % t.replace("'", r"'\''"))
        subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
                        "-i", liste, "-map", "0:v:0", "-c", "copy",
                        "-fflags", "+genpts", muet], check=True)
        os.remove(liste)
        for t in temps:
            os.remove(t)
    else:
        entrees, f, etiq = [], [], []
        for p in plans:
            entrees += ["-i", p]
        # un plan peut être raccourci (« debut » / « duree ») : c'est ce qui permet de
        # tirer une coupe courte du même matériel sans relancer un rendu
        for i, p in enumerate(m["plans"]):
            if p.get("debut") or p.get("duree"):
                a = p.get("debut", 0)
                b = a + p["duree"] if p.get("duree") else duree(p["fichier"])
                f.append(f"[{i}:v]trim={a}:{b},setpts=PTS-STARTPTS[c{i}]")
                etiq.append(f"[c{i}]")
            else:
                etiq.append(f"[{i}:v]")
        f.append("".join(etiq) + f"concat=n={n}:v=1:a=0[v]")
        subprocess.run([FFMPEG, "-y", "-loglevel", "error", *entrees,
                        "-filter_complex", ";".join(f), "-map", "[v]",
                        "-c:v", "libx264", "-preset", os.environ.get("PRESET", "medium"),
                        "-crf", os.environ.get("CRF", "18"), "-pix_fmt", "yuv420p",
                        "-an", muet], check=True)

    # ---- passe 2 : la bande son seule
    entrees, f, pistes = [], [], []
    for k, v in enumerate(voix):
        entrees += ["-i", v["fichier"]]
        # la voix est posée au chronomètre : adelay travaille en millisecondes
        f.append(f"[{k}:a]adelay={int(v['a'] * 1000)}|{int(v['a'] * 1000)},"
                 f"volume={v.get('db', 0)}dB[vx{k}]")
        pistes.append(f"[vx{k}]")
    if musique:
        # ⚠️ le lit musical doit être un fichier FINI, déjà assez long pour le film.
        # Ni `aloop`, ni `-stream_loop -1` : les deux font boucler une source sans fin dans
        # le graphe et le montage gonfle en mémoire sans rien écrire.
        entrees += ["-i", musique]
        i = len(voix)
        f.append(f"[{i}:a]atrim=0:{total:.3f},asetpts=N/SR/TB,"
                 f"volume={db}dB,afade=t=in:st=0:d=0.8,"
                 f"afade=t=out:st={max(0, total - 1.2):.3f}:d=1.2[lit]")
        pistes.append("[lit]")
    f.append("".join(pistes) + f"amix=inputs={len(pistes)}:duration=longest:normalize=0,"
             f"atrim=0:{total:.3f},alimiter=limit=0.95[a]")
    subprocess.run([FFMPEG, "-y", "-loglevel", "error", *entrees,
                    "-filter_complex", ";".join(f), "-map", "[a]",
                    "-c:a", "aac", "-b:a", "256k", bande], check=True)

    # ---- passe 3 : on colle, sans ré-encoder
    subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", muet, "-i", bande,
                    "-c", "copy", "-shortest", "-movflags", "+faststart", sortie], check=True)
    for x in (muet, bande):
        os.remove(x)
    print(f"{sortie} — {total:.1f} s, {n} plans, {len(voix)} lignes de voix")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__, file=sys.stderr); sys.exit(2)
    monter(json.load(open(sys.argv[1])), sys.argv[2])
