#!/usr/bin/env python3
"""Détourage des emballages officiels, et contrôle du résultat.

Usage :
  python3 detourer.py <dossier_source> <dossier_sortie>      # détoure tout
  python3 detourer.py --controle <dossier>                   # contrôle seul

La faute qui revient : les fichiers produit des sites de marque portent un liseré
clair de 1 à 3 px sur le bord du canevas de la vignette. Recadré au cadre alpha, il
ressort en rectangle blanc autour de l'emballage sur le visuel fini.

Et un keying sur le blanc n'est PAS la solution : il mange les parties blanches du
produit — couvercle, bâton de sucette, étiquette claire. Quand la source porte déjà
son alpha, on le reprend.
"""
import glob, os, sys
from PIL import Image, ImageFilter

SEUIL_ALPHA = 150        # au-dessous, le pixel est du liseré ou du fond
ROGNAGE = .018           # part du plus petit côté rognée pour tuer le liseré
PART_TRANSPARENTE = .15  # au-dessus, la source porte déjà un détourage exploitable
POURTOUR_MAX = .20       # au-dessus, le détourage a échoué


def detourer(src, dst):
    im = Image.open(src).convert("RGBA")
    a0 = im.split()[3]
    h = a0.histogram()
    tot = sum(h) or 1
    if sum(h[:32]) / tot <= PART_TRANSPARENTE:
        return f"{os.path.basename(src)} — pas d'alpha exploitable à la source, à détourer autrement"
    m = max(3, int(min(im.size) * ROGNAGE))
    im = im.crop((m, m, im.width - m, im.height - m))
    a = im.split()[3].point(lambda v: 0 if v < SEUIL_ALPHA else 255)
    a = a.filter(ImageFilter.GaussianBlur(.7)).point(lambda v: 0 if v < 90 else v)
    im.putalpha(a)
    bb = a.getbbox()
    if bb:
        im = im.crop(bb)
    im.save(dst)
    return f"{os.path.basename(src)} — {im.size[0]}×{im.size[1]}"


def cotes_opaques(chemin):
    """Part de pixels opaques sur chacun des quatre côtés du fichier détouré.

    On regarde côté par côté, et non le pourtour dans son ensemble : un produit qui
    touche légitimement un bord — bâtons de sucettes, forme allongée — fait monter un
    seul côté, alors qu'un liseré de vignette resté en place les fait monter tous les
    quatre. C'est la signature du rectangle qu'on cherche, pas le contact.
    """
    a = Image.open(chemin).convert("RGBA").split()[3]
    w, h = a.size
    cotes = [[a.getpixel((x, 0)) for x in range(0, w, 4)],
             [a.getpixel((x, h - 1)) for x in range(0, w, 4)],
             [a.getpixel((0, y)) for y in range(0, h, 4)],
             [a.getpixel((w - 1, y)) for y in range(0, h, 4)]]
    return [sum(1 for v in c if v > 40) / max(1, len(c)) for c in cotes]


def controler(dossier):
    mauvais = []
    for f in sorted(glob.glob(os.path.join(dossier, "*.png"))):
        c = cotes_opaques(f)
        charges = sum(1 for v in c if v > POURTOUR_MAX)
        rate = charges >= 3                       # trois côtés chargés = liseré resté en place
        if rate:
            mauvais.append(f)
        print(f"{os.path.basename(f):50s} côtés={' '.join(f'{v:4.0%}' for v in c)}"
              f"  {'ÉCHEC — liseré resté en place' if rate else 'ok'}")
    return mauvais


if __name__ == "__main__":
    if "--controle" in sys.argv:
        rates = controler(sys.argv[sys.argv.index("--controle") + 1])
        sys.exit(1 if rates else 0)
    if len(sys.argv) < 3:
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    source, sortie = sys.argv[1], sys.argv[2]
    os.makedirs(sortie, exist_ok=True)
    for f in sorted(glob.glob(os.path.join(source, "*.png"))):
        print(detourer(f, os.path.join(sortie, os.path.basename(f))))
    print("\n— contrôle du pourtour —")
    sys.exit(1 if controler(sortie) else 0)
