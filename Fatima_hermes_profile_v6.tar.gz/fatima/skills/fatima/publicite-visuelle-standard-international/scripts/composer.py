#!/usr/bin/env python3
"""Compose une publicité finie : décor + emballage réel + logo réel + accroche.

Le décor vient d'une génération d'image ; l'emballage et le logo viennent des
fichiers officiels de la marque. Rien de ce qui porte la marque n'est redessiné.
"""
import os
from PIL import Image, ImageDraw, ImageFilter, ImageFont

POLICES = {
    "maison": "/home/openclaw/.local/share/fonts/poppins/Poppins-ExtraBold.ttf",
    "titre": "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "etroit": "/usr/share/fonts/truetype/liberation/LiberationSansNarrow-Bold.ttf",
    "texte": "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
}


def ombre(objet, flou=18, opacite=120, decalage=(10, 16)):
    """Fabrique l'ombre portée d'un objet détouré."""
    a = objet.split()[3]
    o = Image.new("RGBA", objet.size, (0, 0, 0, 0))
    o.putalpha(a.point(lambda v: int(v * opacite / 255)))
    o = o.filter(ImageFilter.GaussianBlur(flou))
    fond = Image.new("RGBA", (objet.width + 80, objet.height + 80), (0, 0, 0, 0))
    fond.paste(o, (40 + decalage[0], 40 + decalage[1]), o)
    return fond


def poser(scene, chemin_objet, centre, hauteur, avec_ombre=True, rotation=0):
    """Pose un emballage réel sur le décor. centre et hauteur en fraction de l'image."""
    obj = Image.open(chemin_objet).convert("RGBA")
    h = int(scene.height * hauteur)
    obj = obj.resize((max(1, int(obj.width * h / obj.height)), h), Image.LANCZOS)
    if rotation:
        obj = obj.rotate(rotation, expand=True, resample=Image.BICUBIC)
    x = int(scene.width * centre[0] - obj.width / 2)
    y = int(scene.height * centre[1] - obj.height / 2)
    if avec_ombre:
        om = ombre(obj)
        scene.alpha_composite(om, (x - 40, y - 40))
    scene.alpha_composite(obj, (x, y))
    return scene


def voile(scene, cote="bas", part=0.42, force=205):
    """Assombrit un bord pour que le texte reste lisible sans masquer le décor."""
    h, w = scene.height, scene.width
    v = Image.new("L", (w, h), 0); d = ImageDraw.Draw(v)
    n = int(h * part) if cote in ("bas", "haut") else int(w * part)
    for i in range(n):
        a = int(force * ((n - i) / n) ** 1.6)
        if cote == "bas":
            d.line([(0, h - 1 - i), (w, h - 1 - i)], fill=a)
        elif cote == "haut":
            d.line([(0, i), (w, i)], fill=a)
    noir = Image.new("RGBA", (w, h), (0, 0, 0, 255)); noir.putalpha(v)
    scene.alpha_composite(noir)
    return scene


def decouper(texte, police, largeur, dessin):
    lignes, courante = [], ""
    for mot in texte.split():
        essai = (courante + " " + mot).strip()
        if dessin.textlength(essai, font=police) <= largeur:
            courante = essai
        else:
            if courante:
                lignes.append(courante)
            courante = mot
    if courante:
        lignes.append(courante)
    return lignes


def accroche_maison(scene, texte, taille=.085, y=.80, gauche=.06, couleur=(255, 255, 255),
                    contour=(28, 28, 40), epaisseur=None, centre=False):
    """Accroche dans le registre de la maison : grasse, arrondie, cernée."""
    d = ImageDraw.Draw(scene)
    f = ImageFont.truetype(POLICES["maison"], int(scene.height * taille))
    ep = epaisseur if epaisseur is not None else max(3, int(scene.height * taille * .07))
    lignes = decouper(texte, f, scene.width * (1 - 2 * gauche), d)
    pas = int(scene.height * taille * 1.14)
    yy = int(scene.height * y)
    for l in lignes:
        x = int((scene.width - d.textlength(l, font=f)) / 2) if centre else int(scene.width * gauche)
        d.text((x, yy), l, font=f, fill=couleur, stroke_width=ep, stroke_fill=contour)
        yy += pas
    return scene


def accroche(scene, texte, taille=0.062, bas=0.09, gauche=0.07, couleur=(255, 255, 255),
             police="titre", interligne=1.12):
    d = ImageDraw.Draw(scene)
    f = ImageFont.truetype(POLICES[police], int(scene.height * taille))
    lignes = decouper(texte, f, scene.width * (1 - 2 * gauche), d)
    pas = int(scene.height * taille * interligne)
    y = int(scene.height * (1 - bas)) - pas * len(lignes)
    for l in lignes:
        d.text((int(scene.width * gauche), y), l, font=f, fill=couleur)
        y += pas
    return scene


def cartouche(scene, chemin_logo, coin="bd", hauteur=0.085, marge=0.045):
    logo = Image.open(chemin_logo).convert("RGBA")
    h = int(scene.height * hauteur)
    logo = logo.resize((max(1, int(logo.width * h / logo.height)), h), Image.LANCZOS)
    mx, my = int(scene.width * marge * 0.6), int(scene.height * marge * 0.6)
    x = scene.width - logo.width - mx if coin[1] == "d" else mx
    y = scene.height - logo.height - my if coin[0] == "b" else my
    scene.alpha_composite(logo, (x, y))
    return scene


def ouvrir(chemin, format_cible=None):
    im = Image.open(chemin).convert("RGBA")
    if format_cible and im.size != format_cible:
        im = recadrer(im, format_cible)
    return im


def recadrer(im, cible):
    """Recadre au centre puis redimensionne, sans déformer."""
    cw, ch = cible
    r_src, r_cible = im.width / im.height, cw / ch
    if r_src > r_cible:
        n = int(im.height * r_cible)
        im = im.crop(((im.width - n) // 2, 0, (im.width + n) // 2, im.height))
    else:
        n = int(im.width / r_cible)
        im = im.crop((0, (im.height - n) // 2, im.width, (im.height + n) // 2))
    return im.resize((cw, ch), Image.LANCZOS)


def enregistrer(scene, chemin):
    os.makedirs(os.path.dirname(chemin), exist_ok=True)
    scene.convert("RGB").save(chemin, quality=94)
    return chemin
