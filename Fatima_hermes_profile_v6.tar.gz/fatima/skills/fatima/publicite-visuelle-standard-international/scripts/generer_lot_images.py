#!/usr/bin/env python3
"""Fait produire un lot de décors par Magnific, puis les récupère.

Usage : python3 magnific-lot.py <fichier_json> <dossier_sortie> --je-paie

⚠️ COÛTE DES CRÉDITS : environ 100 par image (vérifié le 13/08/2026 avec
simulate_cost). Le solde se lit gratuitement avec account_balance.
"""
import json, os, sys, time, urllib.request
sys.path.insert(0, "/home/openclaw/agents/fatima/integrations/magnific")
from appeler import rpc

if len(sys.argv) < 4 or "--je-paie" not in sys.argv:
    print(__doc__, file=sys.stderr); sys.exit(2)
taches = json.load(open(sys.argv[1]))
sortie = sys.argv[2]
os.makedirs(sortie, exist_ok=True)

_carte = os.path.join(os.path.dirname(os.path.abspath(__file__)), "refs-magnific.json")
REFS = json.load(open(_carte)) if os.path.exists(_carte) else {}

rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "fatima", "version": "1"}})

attente = {}
for t in taches:
    dest = os.path.join(sortie, f"{t['cle']}.png")
    if os.path.exists(dest):
        print(f"{t['cle']} déjà là"); continue
    r = None
    for essai in range(4):                      # le service rend parfois un 500 passager
        try:
            args = {"prompt": t["consigne"], "numImages": 1,
                    "aspectRatio": t.get("ratio", "4:5")}
            if t.get("modele"):                 # un moteur nommé tient mieux la consigne
                args["mode"] = t["modele"]
            if t.get("definition"):             # 2k / 4k : on ne génère jamais sous la livraison
                args["resolution"] = t["definition"]
            # l'emballage officiel en référence — un seul (« pack ») ou plusieurs
            # (« packs ») quand la scène doit montrer le sachet ET les bonbons unitaires
            packs = t.get("packs") or ([t["pack"]] if t.get("pack") else [])
            refs = [{"type": "image", "identifier": REFS[p]} for p in packs if p in REFS]
            # une référence peut aussi être une image déjà produite, donnée par son
            # identifiant : c'est ce qui permet de garder le MÊME VISAGE d'un plan à
            # l'autre en repassant la photo du premier plan
            refs += [{"type": "image", "identifier": i} for i in t.get("refs_brutes", [])]
            if refs:
                args["references"] = refs
            r = rpc("tools/call", {"name": "images_generate", "arguments": args})
            break
        except Exception as ex:
            if essai == 3:
                print(f"{t['cle']} ÉCHEC réseau : {ex}", file=sys.stderr)
                continue
            time.sleep(15 * (essai + 1))
    if r is None:
        continue
    texte = "".join(c.get("text", "") for c in r.get("content", []))
    ids = [c["identifier"] for c in json.loads(texte[texte.index("{\"creations\""):])["creations"]] \
        if "{\"creations\"" in texte else []
    if not ids:
        print(f"{t['cle']} ÉCHEC : {texte[:160]}", file=sys.stderr); continue
    attente[ids[0]] = t["cle"]
    print(f"{t['cle']} en file ({ids[0]})", flush=True)

restants = list(attente)
while restants:
    lot = restants[:8]
    r = rpc("tools/call", {"name": "creations_wait",
                           "arguments": {"identifiers": lot, "timeoutSeconds": 25}})
    texte = "".join(c.get("text", "") for c in r.get("content", []))
    d = json.loads(texte)
    fini = []
    for e in d.get("results", []):
        if e.get("status") == "completed":
            url = e["results"]["url"]
            dest = os.path.join(sortie, f"{attente[e['identifier']]}.png")
            with urllib.request.urlopen(url, timeout=300) as rep:
                open(dest, "wb").write(rep.read())
            print(f"{attente[e['identifier']]} ok", flush=True)
            fini.append(e["identifier"])
        elif e.get("status") in ("failed", "error"):
            print(f"{attente[e['identifier']]} ÉCHEC", file=sys.stderr)
            fini.append(e["identifier"])
    restants = [i for i in restants if i not in fini]
    if restants and not fini:
        time.sleep(10)
