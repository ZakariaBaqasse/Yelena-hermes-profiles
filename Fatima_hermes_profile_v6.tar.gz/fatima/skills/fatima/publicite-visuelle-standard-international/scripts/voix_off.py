#!/usr/bin/env python3
"""Fait dire les lignes de voix off, puis les récupère.

Une seule voix pour tout un film : la voix se pose au montage, jamais dans les plans.
Voix retenue — la seule voix française africaine du catalogue au 17/08/2026 :
Aïssatou Diallo, identifiant 805, femme.

⚠️ Chaque ligne rendue se vérifie ensuite par transcription. Le générateur avale parfois
la première syllabe, et il écorche les noms de marque : un nom de marque ne se met donc
jamais en tête de ligne sans contrôle.

Fichier d'entrée (JSON) : [{"cle": "T1", "texte": "…"}, …]
Usage : python3 voix-off.py <lignes.json> <dossier_sortie> --je-paie
"""
import json, os, sys, time, urllib.request

sys.path.insert(0, "/home/openclaw/agents/fatima/integrations/magnific")
from appeler import rpc

VOIX = 805
MODELE = "eleven_v3"

if len(sys.argv) < 4 or "--je-paie" not in sys.argv:
    print(__doc__, file=sys.stderr); sys.exit(2)
lignes = json.load(open(sys.argv[1]))
sortie = sys.argv[2]
os.makedirs(sortie, exist_ok=True)

rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                   "clientInfo": {"name": "fatima", "version": "1"}})


def texte(r):
    return "".join(c.get("text", "") for c in r.get("content", []))


attente = {}
for l in lignes:
    dest = os.path.join(sortie, f"{l['cle']}.mp3")
    if os.path.exists(dest):
        print(f"{l['cle']} déjà là"); continue
    args = {"text": l["texte"], "voiceId": l.get("voix", VOIX),
            "model": l.get("modele", MODELE),
            "stability": l.get("stabilite", 0.45)}
    # Ce qui décide du « pas robotique » : une stabilité basse laisse la voix jouer,
    # la vitesse casse la lecture métronomique, et le modèle v3 accepte des balises
    # de jeu écrites dans le texte ([warm], [excited], …).
    for cle, nom in (("vitesse", "speed"), ("ressemblance", "similarityBoost"),
                     ("renfort", "useSpeakerBoost")):
        if cle in l:
            args[nom] = l[cle]
    r = rpc("tools/call", {"name": "audio_tts", "arguments": args})
    tx = texte(r)
    # ⚠️ la charge utile est précédée d'un rappel système, et la clé est « creation »
    # au singulier — c'est le piège qui fait échouer la lecture de la réponse
    i = tx.find('{"creation')
    if i < 0:
        print(f"{l['cle']} ÉCHEC : {tx[:200]}", file=sys.stderr); continue
    d = json.loads(tx[i:])
    ident = d.get("creation", {}).get("identifier") or d["creations"][0]["identifier"]
    attente[ident] = l["cle"]
    print(f"{l['cle']} en file ({ident})", flush=True)

restants = list(attente)
while restants:
    r = rpc("tools/call", {"name": "creations_wait",
                           "arguments": {"identifiers": restants[:8], "timeoutSeconds": 25}})
    d = json.loads(texte(r))
    fini = []
    for e in d.get("results", []):
        if e.get("status") == "completed":
            dest = os.path.join(sortie, f"{attente[e['identifier']]}.mp3")
            with urllib.request.urlopen(e["results"]["url"], timeout=300) as rep:
                open(dest, "wb").write(rep.read())
            print(f"{attente[e['identifier']]} ok", flush=True)
            fini.append(e["identifier"])
        elif e.get("status") in ("failed", "error"):
            print(f"{attente[e['identifier']]} ÉCHEC", file=sys.stderr)
            fini.append(e["identifier"])
    restants = [i for i in restants if i not in fini]
    if restants and not fini:
        time.sleep(8)
