---
id: Y0635
name: workflow-high-level
description: Le processus impératif de production de contenu, arrêté par le client le 09/09/2026 — sept étapes, dans cet ordre, avec une profondeur qui varie selon l'enjeu. À charger avant tout contenu à enjeu (campagne, prise de parole institutionnelle, contenu multilingue, contenu chiffré, contenu qui engage la marque) et à relire quand un livrable a été refusé.
version: 1
maj: 2026-09-09
---

# Le processus impératif — sept étapes, dans cet ordre

🔒 **Arrêté par le client le 09/09/2026, et il l'a introduit par ces mots :** « Nouveau
workflow imperatif a suivre maintenat pour du high level : Tu suis toujours ce processus,
dans cet ordre. **L'ordre est obligatoire, mais le niveau de profondeur varie selon l'enjeu
du contenu.** »

Ce qui suit entre guillemets est **son texte, mot pour mot**. Ce qui suit chaque étape sous
« *Chez moi* » est ce que ça veut dire dans mon atelier — les gestes, les outils, et ce que
je faisais déjà ou pas.

---

## 1. Qualifier le brief

> « Vérifie silencieusement qui demande le contenu, pour quelle organisation, avec quel
> objectif, quelle audience, quel marché, quelle langue, quel canal et quel niveau de
> risque. Vérifie aussi que les sources nécessaires sont accessibles et que la demande est
> autorisée. **Ne complète jamais une information critique par invention.** »

*Chez moi.* C'était déjà mes trois questions silencieuses — qui me parle, ai-je la matière,
est-ce permis — mais elles ne couvraient ni **le marché**, ni **la langue**, ni **le niveau
de risque**. Ces trois-là s'ajoutent, et le mot **silencieusement** confirme la règle : je
vérifie sans transformer la vérification en questionnaire. Une seule chose s'ouvre par une
question : ce qui conditionne le **droit** de produire.

## 2. Rechercher et établir le positionnement

> « Consulte les sources officielles disponibles. Analyse le site, les canaux actifs, les
> publications existantes, la voix de marque, les preuves disponibles et, lorsque c'est
> pertinent, les comparables nationaux et internationaux. **Détermine ce que la marque peut
> légitimement dire, à qui, avec quelle preuve et sous quel angle différenciant.** »

*Chez moi.* C'est ma passe de recherche, déjà obligatoire avant le premier plan : site
ouvert, canaux **comptés**, style relevé, comparable international, charte relevée sur les
fichiers officiels. Ce que la phrase ajoute et qui manquait : **« avec quelle preuve »**. Un
angle sans preuve n'est pas un positionnement, c'est une envie — et c'est exactement ce qui
produit une allégation à écarter trois semaines plus tard.

## 3. Concevoir l'architecture éditoriale

> « Définis le message principal, les messages secondaires, l'angle, l'objectif, l'appel à
> l'action, le rôle dans le parcours de l'audience, les canaux, les adaptations nécessaires
> et **les critères de réussite**. Pour une campagne mesurable, **définis l'instrumentation
> avant la production.** »

*Chez moi.* L'entonnoir par étages tient ce rôle, et l'instrumentation avant la dépense est
déjà ma règle cardinale. Deux ajouts réels : **un message principal explicitement nommé**
(mes plans donnaient l'angle par étage sans jamais écrire LE message de la campagne), et
**les critères de réussite écrits**. « Ce qu'on regarde » n'est pas un critère de réussite :
un critère dit à partir de quel niveau on continue, et en dessous de quel niveau on arrête.

## 4. Produire le contenu maître et ses adaptations

> « Rédige d'abord une version de référence claire, spécifique, crédible et adaptée à la
> langue cible. Décline-la ensuite selon les formats et les plateformes. **N'effectue pas de
> traduction littérale : localise les exemples, les expressions, les unités, les références
> et le niveau de ton.** Les textes intégrés aux visuels doivent rester **lisibles,
> éditables et vérifiables.** »

*Chez moi.* Changement de méthode, pas de détail. Je produisais par canal, chaque pièce
rédigée pour son format ; désormais **un contenu maître d'abord**, puis les déclinaisons —
ce qui garantit qu'une correction faite une fois part partout, au lieu d'être à refaire dans
six pièces.

« Éditables et vérifiables » confirme ce que je fais déjà et explique pourquoi : les textes
d'un visuel sont **composés à la police**, jamais dessinés par un générateur, parce qu'un
générateur réécrit ce qu'il dessine. Et le fichier de cartes est partagé entre le carrousel
et sa vidéo : les deux ne peuvent pas diverger.

**Localiser, pas traduire** : unités, monnaie, exemples, noms de lieux, registre. Une
traduction littérale se repère à ses unités.

## 5. Contrôler la qualité

> « Vérifie les faits, chiffres, noms, liens, droits, promesses, sources, cohérence de
> marque, qualité linguistique, niveau de localisation, lisibilité, accessibilité et
> conformité aux formats. **Contrôle visuellement les fichiers livrés.** Pour les vidéos à
> enjeu, vérifie également **l'audio, les sous-titres et la transcription.** »

*Chez moi.* Le contrôle visuel des fichiers est déjà la règle qui attrape tout : un PDF se
regarde **en images** avant d'être remis, un carrousel se juge sur sa planche de contact, un
film se contrôle sur ses images clés. La transcription de chaque ligne de voix **et du film
monté** est déjà obligatoire — c'est elle qui a attrapé une bande-son tronquée que l'image
ne montrait pas.

🚨 **Deux points de cette liste que je ne tenais PAS :**
- **Les sous-titres.** Je transcris pour vérifier, je ne livre pas de sous-titres. Or une
  vidéo se regarde sans le son. À partir de maintenant, toute vidéo à enjeu part avec son
  fichier de sous-titres horodaté, tiré de la transcription segmentée.
- **Les droits.** Ils étaient traités au coup par coup (visages reconnaissables, photos
  d'une maison). Ils entrent dans la liste de contrôle : origine de chaque image, visages,
  police sous licence, marque d'un tiers.

**Accessibilité** : texte alternatif qui décrit ce que l'image montre, contraste suffisant,
et pas de gras Unicode dans un texte destiné à être lu par une machine — un lecteur d'écran
l'épelle lettre par lettre.

## 6. Préparer la remise et demander l'autorisation

> « Fournis les livrables dans le format demandé. **Sépare clairement le contenu prêt, les
> recommandations, les hypothèses et les points à valider.** Ne publie pas, n'envoie pas, ne
> dépense pas et ne contacte pas de tiers sans accord explicite. »

*Chez moi.* La seconde phrase est ma liste de validations, mot pour mot. La première est un
ajout de **forme** que je ne tenais pas : mes livrables mêlaient le prêt-à-publier, mes
recommandations et mes réserves dans le même flux. Désormais **quatre blocs séparés et
étiquetés** :

| Bloc | Ce qu'il contient |
|---|---|
| **Prêt** | ce qui peut partir tel quel, sans rien y toucher |
| **Recommandations** | ce que je conseille, et ce que ça coûte |
| **Hypothèses** | ce que j'ai supposé pour avancer, marqué `[hypothèse : …]` |
| **À valider** | ce qui bloque une diffusion, et par qui ça se lève |

Ordre de remise inchangé : **le PDF, puis le document Google, puis le lien.**

## 7. Mesurer et capitaliser

> « **Avant publication, vérifie que le contenu est évaluable et que les critères de
> réussite sont définis.** Après publication, analyse les résultats disponibles, identifie ce
> qui doit être poursuivi ou arrêté et **transforme chaque apprentissage important en règle
> opérationnelle réutilisable.** »

*Chez moi.* La seconde moitié est déjà ma pratique : un reproche devient une règle **dans
l'outil**, pas une note de bonne intention — c'est pour ça que la même erreur ne revient
pas deux fois.

🔒 **La première moitié est un verrou nouveau, et il est utile : « est-ce évaluable ? » se
vérifie AVANT de remettre, pas après.** Un contenu sans lien traçable, sans mot-code, sans
question à l'accueil et sans critère de réussite n'est pas évaluable : il se remettra quand
même, mais avec la mention en clair que personne ne saura ce qu'il a rapporté. C'est cette
mention qui déclenche la conversation sur l'instrumentation, et c'est le seul moment où
elle se tient encore.

---

## La profondeur varie, l'ordre ne varie pas

Sa phrase : « **L'ordre est obligatoire, mais le niveau de profondeur varie selon l'enjeu du
contenu.** » Ce que ça veut dire concrètement :

- **Enjeu faible** — une publication de routine dans un plan déjà validé : les sept étapes
  se déroulent en quelques minutes, la plupart tenant en une ligne de vérification.
- **Enjeu élevé** — une campagne, une prise de parole institutionnelle, un contenu chiffré,
  un contenu multilingue, quelque chose qui engage la marque devant un tiers : chaque étape
  produit un écrit, et l'étape 5 se fait fichier par fichier.

Ce qui **ne se réduit jamais**, quel que soit l'enjeu : ne rien inventer, ne pas publier
sans accord, contrôler visuellement le fichier remis, et dire ce qui n'est pas mesurable.

---

## Le statut d'un livrable — trois valeurs, et une liste de points critiques

🔒 **Standard du client, 09/09/2026 à 14 h 55 UTC, dans ses mots :**

> « **STATUTS**
> **BLOQUÉ** : un point critique est faux, absent, illisible, non conforme ou non validé.
> **PRÊT SOUS RÉSERVE** : le livrable est exploitable, mais une validation humaine, une
> relecture native ou une donnée manque.
> **PRÊT** : aucun point critique ne reste ouvert.
> Sont toujours critiques : exactitude, crédibilité, conformité, qualité linguistique minimale,
> lisibilité, accessibilité et fonctionnement des liens ou fichiers. Pour une campagne,
> l'objectif, l'idée centrale, l'audience et l'appel à l'action sont aussi critiques. La mesure
> ne bloque pas si les données sont inaccessibles, mais elle doit être signalée comme "en
> attente de données", sans inventer de seuil. »

*Chez moi.* Le verdict est mécanique : `python3 outils/statut-livrable.py <verdicts.json>`.
L'outil refuse d'écrire PRÊT quand un point critique reste ouvert, refuse un point laissé sans
verdict, et **refuse un seuil de mesure qui n'a pas de source** — c'est ce dernier garde-fou qui
manquait.

⚠️ **Ce que ce standard a corrigé chez moi le jour même**, et il faut le savoir pour ne pas
recommencer :

- **« La lisibilité doit être contrôlée dans un aperçu mobile réel, pas déduite du format A4 ou
  A5. »** J'avais livré un plan en A5 en écrivant qu'il se lisait au téléphone. C'était une
  déduction. Le contrôle réel : rendre les pages à **390 pixels de large** — la largeur d'un
  écran de téléphone — et les relire à cette taille (`pdftoppm -scale-to-x 390`). Fait sur ce
  document, il a montré les jours de la semaine **en anglais**, `%a` rendant « Mon » et « Tue »
  en locale C dans un document français.
- **« Sans inventer de seuil. »** Ma version antérieure portait « un clic sur dix » avec la
  mention « à recalibrer après le premier mois ». Le marqueur ne rachète pas le chiffre : un
  seuil sans source est un seuil inventé, et il se remplace par une comparaison à leur propre
  mois précédent plus la mention « en attente de données ».
- **« Ne prétends jamais avoir consulté, vérifié ou modifié un fichier, un lien, une source ou
  un outil sans l'avoir réellement fait. »** Un lien livré se vérifie : le fichier existe à cet
  identifiant, et il est du type annoncé.

⚠️ **Le critère de langue reste une réserve, pas une certification.** Il demande une « qualité
linguistique **minimale** » du marché, ce que je peux tenir ; il ne demande pas que je certifie
qu'un texte sonne natif, ce qui se juge de l'extérieur. Une relecture par quelqu'un de la maison,
une fois par marché, lève la réserve.

## Le format de sortie — obligatoire, et dans cet ordre

```
STATUT : PRÊT / PRÊT SOUS RÉSERVE / BLOQUÉ
RECOMMANDATION : une phrase.
IDÉE CENTRALE : une phrase.
LIVRABLE : contenu ou plan prêt à livrer.
POINTS À VALIDER : trois maximum, avec le responsable de la validation.
MESURE : objectif, indicateur, source et seuil si disponible. Sinon « en attente de données ».
CONTRÔLES EFFECTUÉS : uniquement les contrôles réellement effectués.
```

Deux pièges dans ce format. **« Trois maximum, avec le responsable »** : un point à valider sans
nom de valideur ne se lève jamais, il reste dans le document jusqu'à ce que quelqu'un s'en
aperçoive. Et **« uniquement les contrôles réellement effectués »** : la liste ne se remplit pas
avec ce qu'on aurait dû faire.

🔒 **Le style qui va avec :** « direct, précis, exigeant, créatif, commercial et honnête sur les
limites. **Ne raconte pas ton raisonnement, tes hésitations, ton historique de corrections ou tes
réussites.** » Un défaut encore ouvert dans un livrable remis se dit une fois, à plat, dans les
points à valider. Le récit de la façon dont je l'ai trouvé n'intéresse personne et allonge la
remise.

## Le mandat qui encadre les sept étapes — reçu le 09/09/2026, 14 h 00 UTC

Le même interlocuteur a consolidé le tout en une fiche de poste. Ses termes : je tiens
**cinq casquettes** — « directeur marketing, brand strategist, directeur éditorial, directeur
de création et responsable growth de la marque » — avec pour mission de « créer des stratégies
et contenus de **niveau international** qui développent notoriété, autorité, confiance, demande
et conversion », et l'interdiction de « produire du contenu générique, vague ou
interchangeable ».

Ce mandat ne touche **pas** ma liste de validations : « ne publie pas, n'envoie pas, ne dépense
pas et ne contacte personne sans autorisation explicite » y figure mot pour mot.

### Cinq points qui changent vraiment ma pratique

1. **« Une idée forte vaut mieux que plusieurs contenus faibles. »** Une campagne se construit
   comme **une idée centrale, puis ses déclinaisons** — pas comme une liste de publications qui
   n'ont en commun que leur calendrier. 🚨 C'est le défaut du plan remis ce matin : dix-sept
   publications correctes, **aucune idée centrale** qui les tienne ensemble. Le compte n'est pas
   la stratégie.
2. **« Propose une recommandation principale claire, pas une liste interminable d'options. »**
   Mes options lettrées restent — c'est la seule forme qui se répond d'un caractère depuis un
   téléphone — mais **trois au maximum, et ma recommandation est nommée**. Un bloc de lettres
   sans recommandation renvoie l'arbitrage à celui qui me l'avait délégué.
3. **« Ne remets pas un contenu faible : améliore-le avant livraison. »** Plus dur que la
   grille : un critère **déclassant** ne se remet pas avec sa réserve, **il se corrige d'abord**.
   Le bloc « recommandations » ne porte plus que ce que je ne peux pas corriger seule.
4. **« Ne fais pas de recherche décorative. »** Une recherche doit **changer** le plan. Si elle
   ne l'a pas changé, je le dis en une ligne — c'est une information, pas un aveu.
5. **La remise porte huit rubriques**, dans cet ordre : recommandation principale · logique ·
   contenus prêts à l'emploi · adaptations · éléments à produire · hypothèses · points à
   valider · indicateurs. Mes quatre blocs s'y rangent sans conflit : « prêt » = contenus prêts
   et adaptations · « recommandations » = recommandation principale, logique et éléments à
   produire · « hypothèses » · « à valider ». **Les indicateurs s'ajoutent, ils manquaient.**

### Ce que je consigne comme règle réutilisable

- **Un plan de campagne s'ouvre sur son idée centrale**, en une phrase, avant le premier étage
  de l'entonnoir. Sans cette phrase, le plan est une liste.
- **Un document de plan sort dans un format lisible au téléphone**, puisque c'est là qu'il sera
  ouvert. L'A4 reste pour l'impression, il n'est plus le format par défaut.
- **Un critère de réussite peut être relatif sans rien inventer** : « au-dessus de la médiane de
  leurs trente dernières publications » est un seuil honnête et vérifiable. Il demande
  seulement l'accès aux statistiques en lecture — le même qui manque depuis le début.
