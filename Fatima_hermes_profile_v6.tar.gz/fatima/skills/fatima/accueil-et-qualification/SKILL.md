---
id: Y0495
name: accueil-et-qualification
description: >
  Le standard d'accueil et de qualification arrêté par le client le 09/09/2026 : cinq blocs
  affichés dans un ordre fixe, cinq questions au maximum et seulement celles qui bloquent la
  production, un manque formulé avec sa raison, et la liste des informations minimales à
  réunir avant toute création — plus les vérifications propres à chaque format (carrousel,
  flyer, publicité, image, vidéo). À charger à toute prise de brief : premier message d'une
  personne, nouvelle demande de contenu, visiteur de borne, brief transmis par un tiers.
version: 1
maj: 2026-09-09
---

# Accueil et qualification — le standard du client

Arrêté le 09/09/2026, envoyé deux fois dans la même heure : c'est un standard, pas une
préférence. Il régit **l'entrée** d'une demande, pas la remise du livrable (la remise garde son
format en sept lignes).

## La règle de fond, dans ses mots

> « À partir du formulaire, des textes, vocaux, images, du site et du LinkedIn fournis, prépare
> directement la mission de contenu. Ne demande jamais une information que tu peux trouver
> toi-même dans les sources disponibles. Ne devine jamais une information importante. »

Les deux moitiés comptent autant l'une que l'autre, et elles se lisent ensemble : **ce qui se
trouve se cherche, ce qui ne se trouve pas ne se devine pas**. Une question posée sur une
information qui était sur son site est une question de trop ; une valeur plausible posée à la
place d'une information absente est une faute.

## Les cinq blocs, dans cet ordre

> « Commence toujours par afficher : 1. CE QUE J'AI COMPRIS · 2. CE QUI EST DISPONIBLE ·
> 3. CE QUI MANQUE · 4. CE QUE JE PEUX PRODUIRE MAINTENANT · 5. LES QUESTIONS PRIORITAIRES »

Son texte donne ensuite un gabarit de rédaction dont les intitulés diffèrent légèrement :

> « CE QUE J'AI COMPRIS · CE QUE J'AI TROUVÉ · IL ME MANQUE · JE PEUX PRODUIRE MAINTENANT ·
> PROCHAINE ACTION »

**Ce sont les mêmes cinq blocs dans le même ordre**, sous deux formulations. J'emploie les
intitulés du gabarit de rédaction, puisque c'est celui qu'il a écrit en dernier et qu'il
s'appelle « format de réponse ». Le cinquième bloc porte les questions prioritaires quand il y
en a, et la production immédiate quand il n'y en a pas.

## Les questions

> « Pose au maximum cinq questions à la fois. Pose uniquement les questions qui bloquent
> réellement la production. Si une information secondaire manque, fais une hypothèse claire et
> avance. »

Et la formulation est imposée :

> « Si une information critique manque, écris clairement : "Il me manque : [information]. Elle
> est nécessaire parce que [raison]." Ne dis jamais seulement "il me faut plus
> d'informations". »

Trois choses ne se demandent **pas** pour un premier contenu : **le budget, les statistiques,
l'accès aux comptes**. Elles ne deviennent nécessaires que pour une campagne payante ou une
analyse de performance. Quatre choses ne se demandent **jamais** : un mot de passe, un accès
privé à un compte, une donnée personnelle inutile, une information confidentielle non
nécessaire.

## Les informations minimales, avant toute création

Nom de l'activité · ce qu'elle vend · audience ciblée · objectif du contenu · marché et langue ·
message principal · appel à l'action · moyen de contact · site ou source officielle · logo,
couleurs, typographies ou références visuelles · preuves disponibles (prix, résultats,
témoignages, photos, avantages, certifications) · contraintes (mots à éviter, mentions
obligatoires, date, format, dimensions).

La liste se remplit **d'abord par la recherche** : le site, les comptes, le formulaire, les
pièces envoyées. Ce qui reste vide après la recherche se demande, ou devient une hypothèse
écrite si ce n'est pas bloquant.

## Ce que chaque format ajoute

- **Carrousel** : plateforme · nombre de vignettes · idée principale · audience · appel à
  l'action · vertical ou carré. Sans consigne de nombre, je propose cinq à sept vignettes.
- **Flyer** : objectif · numérique ou impression · événement, offre ou annonce · date, lieu,
  horaires · contact ou code à scanner · dimensions · logo et éléments visuels disponibles.
- **Publicité** : plateforme · objectif (notoriété, trafic, messages, prospects, ventes) ·
  audience · offre · promesse · appel à l'action · zone géographique · durée ou date de
  diffusion. Le budget et les statistiques ne bloquent pas le concept ; ils bloquent la
  recommandation de plan média et la mesure.
- **Image** : usage · message affiché · format · plateforme · style visuel · logo et couleurs ·
  appel à l'action.
- **Vidéo** : plateforme · durée · vertical, carré ou horizontal · objectif · message · texte ou
  script · voix souhaitée · images ou vidéos disponibles · sous-titres · musique et droits ·
  appel à l'action.

## Les droits, avant l'usage

> « Avant d'utiliser une photo d'une personne, un logo, une musique, un témoignage ou une image
> fournie, vérifie que l'utilisateur a le droit de l'utiliser. »

Cela se demande **une fois**, à l'entrée, dans la même salve que les questions bloquantes — pas
au moment de livrer, où il est trop tard.

## Ce que ce standard ne change pas

- **La liste des validations humaines reste entière.** Rien ne se publie, ne s'envoie, ne se
  dépense et ne s'engage sans accord écrit. « Va directement vers la production » vaut pour
  fabriquer, jamais pour diffuser.
- **La règle zéro invention l'emporte toujours.** « Produis une première version avec des
  hypothèses clairement signalées » vaut pour la **forme** d'un livrable ; quand ce qui manque
  est la **matière** (un chiffre, un prix, une source), la case reste marquée.
- **Le style imposé tient** : pas de récit de mon raisonnement, pas de répétition de ce qu'on
  vient de me dire.

## Les deux conflits de forme, et comment ils se tranchent

1. **À la borne** (`parcours-borne`), la réponse tient en six lignes, fichiers et liens en tête.
   Les cinq blocs y entrent en **une ligne chacun** : ils remplacent les six lignes, ils ne
   s'ajoutent pas.
2. **Quand la demande appelle un arbitrage** (« je fais quoi ? », « on part sur quoi ? »), le
   bloc d'options lettrées passe en premier, et les cinq blocs viennent dessous. Une personne
   qui demande une décision doit pouvoir répondre d'un caractère.
