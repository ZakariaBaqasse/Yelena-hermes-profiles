---
id: Y0504
name: avatar-parlant
description: Fabriquer une vidéo de porte-parole à partir d'une image fixe d'avatar et d'un texte à dire — voix off maison, lèvres synchronisées, un seul plan. À charger dès qu'on demande une vidéo d'un avatar, d'un personnage, d'un porte-parole ou d'un présentateur qui parle.
version: 1
maj: 2026-09-01
---

# Avatar parlant — un porte-parole sans tournage

Moteur : `integrations/higgsfield/avatar-parlant.py` (`wan3_0_prime`). Image fixe + une piste de
voix → lèvres synchronisées, **la voix reste la nôtre**. ≈ **7,7 crédits la seconde** en 1080p 9:16.

## L'ordre des opérations — il ne se réarrange pas

1. **La grande image, avant tout.** La résolution de départ décide de ce que le 1080p révèle. Une
   photo compressée de messagerie (≈ 700 px de large) rend un film mou. On demande le grand
   fichier **avant** de lancer : un rendu payé puis annulé pour cette raison a déjà coûté une
   centaine de crédits.
2. **Le texte se découpe en phrases de 7 à 10 s**, chacune enregistrée à part. 🚨 Au-delà d'une
   vingtaine de secondes, une prise unique **dérive** (« les renouvellements » sorti en
   « l'embauchement »).
3. **Chaque ligne se transcrit** (`integrations/openai-transcription/transcrire.py`), et la piste
   assemblée aussi. Les homophones ne justifient pas une reprise (« relation client » et
   « relations clients » sonnent pareil) ; un mot ordinaire faux, oui.
4. **Le débit s'applique AVANT le rendu.** Le moteur cale les lèvres sur le fichier exact qu'on lui
   passe : accélérer après le rendu casse la synchro. Assemblage : segments + silences courts
   (0,12 s), puis `atempo`.
5. **Durée : on reste à 15 s ou moins.** Le plafond n'est pas fixe — le 31/08/2026, 16 s est
   passée à 14 h et a **échoué trois fois** vers 18 h, avant que 15 s passe dans la minute, à
   image, consigne et moteur identiques. Le refus est **instantané** (moins de 45 s, contre cinq
   minutes pour un vrai rendu), **sans message d'erreur** même via `generate get`, et **sans
   débit** — donc le pari asymétrique est permis. *Une recette qui accepte n'est pas un travail
   qui passe*, et une durée qui a marché ce matin ne prouve rien ce soir.
   Pour tenir 15 s sans toucher au texte du client : silences entre segments à 0,02 s (les prises
   portent leur propre respiration), pauses internes trop longues raccourcies, et en dernier
   recours un cran de débit en plus — annoncé, et prouvé par la transcription.
6. **Rendu**, puis **montage local** de la voix sur le muet.
7. **Deux contrôles obligatoires** : la transcription du film monté, **et la mesure de
   synchronisation** (voir plus bas).

## 🚨 La synchronisation labiale se mesure

Un film rendu sur la piste exacte qui a servi au montage peut être décalé quand même : **320 ms de
retard mesurés le 31/08/2026**, cinq fois le seuil du visible (≈ 60 ms). Le moteur pose
l'articulation en retard sur la piste qu'on lui donne. Ni la transcription ni les durées ne voient
ce défaut.

    python3 outils/mesurer-synchro.py <film.mp4> --zone <x> <y> <l> <h>

- La zone de la bouche se repère **à l'œil**, une fois : `ffmpeg -ss 6 -i film -vf
  "crop=iw:ih*0.22:0:0,scale=540:-1"` donne la bande de la tête, on y lit la position.
- 🚨 **Le repérage automatique n'est pas fiable** — les mains bougent plus que les lèvres, et le
  front corrèle presque aussi bien. Une correction posée sur un repérage automatique a **dégradé**
  un film qui allait bien.
- 🚨 **Ce qui autorise une correction, c'est la CONCORDANCE, pas la corrélation.** `--balayage`
  mesure sur cinq cadrages autour de la bouche : si les cinq donnent la même valeur à une image
  près, elle est exploitable **même sous 0,20** ; si elles se dispersent, on ne corrige rien.
  Une corrélation basse dit que le témoin est petit, **pas** que le décalage est nul — l'ancienne
  règle « sous 0,20 on ne corrige pas » a fait livrer quatre films décalés, dont un que le client
  a dû signaler lui-même.
- **Le sens du décalage commande la manœuvre** : lèvres en RETARD → on retarde la VOIX
  (`adelay`) ; lèvres en AVANCE → on retarde l'IMAGE (`tpad=start_mode=clone`, première image
  tenue), parce qu'avancer la voix reviendrait à couper le début de la phrase.
- ⚠️ **Un plan avec un GESTE de bras n'est pas mesurable** par ce témoin : le mouvement du bras
  noie celui des lèvres et les valeurs partent dans tous les sens. Dans ce cas on livre les deux
  versions — brute et corrigée de la valeur trouvée sur le plan sans geste — et c'est l'œil du
  client qui tranche. Les deux montages sont gratuits.
- La correction est **gratuite** et se fait sur le rendu **MUET** d'origine, jamais sur le film déjà
  monté (coupé à la longueur de l'ancienne piste, donc la fin serait amputée).

## Le texte affiché dans le cadre — hiérarchie des parades, mesurée

Le générateur **réécrit** tout texte lisible qu'il voit. Trois niveaux, du plus sûr au plus faible :

1. **Aucun texte lisible dans l'image de départ** — la seule garantie.
2. **Objet porteur de texte IMMOBILISÉ** avec un critère vérifiable image par image, et présentation
   confiée à un objet sans texte (un stylet, un index). Plus de charabia, mais des altérations de
   lettres passent encore (« CONTRAT » sorti « CONTRAIT »).
3. **Une simple interdiction** (« ne l'incline pas ») — ne tient pas du tout.

La vraie variable est la **stabilité du support** : un texte sur un vêtement survit (un badge
nominatif est ressorti intact), un texte sur un objet tenu en main reste exposé.

🚨 **Et au niveau 2, l'objet porté CONTRE LE CORPS est un cas à part.** Une tablette tenue devant
le buste à deux mains donne un charabia **stable**, qui passe à l'écran. Une étiquette sur un
porte-documents serré sous le bras donne un texte qui **change à chaque instant du plan** — trois
relevés, trois charabias différents — parce que l'objet respire avec la cage thoracique. Aucune
formulation ne peut immobiliser ce que la respiration déplace : soit l'image de départ ne porte
aucun texte lisible là, soit on accepte un texte mouvant.

⚠️ Contrôle qui en découle : **un texte dans le cadre se relève à TROIS moments du plan**. Un
relevé unique conclut « charabia stable » et passe à côté du vrai défaut.

## Les verrous à écrire dans CHAQUE consigne

- **Cadrage**, avec un critère vérifiable image par image : « ses chaussures restent entièrement
  visibles au bas du cadre dans CHAQUE image », « le cadrage de la DERNIÈRE image est identique à
  celui de la PREMIÈRE ». Et on retire toute formule qui invite au mouvement. « Pas de zoom » seul
  ne suffit pas — un rendu payé a été perdu faute de ce verrou.
- **Aucun logo ajouté** : le générateur en invente (une marque de constructeur est apparue au dos
  d'une tablette qui n'en portait pas). Deux cas, deux réponses — ajouté par le générateur → verrou
  dans la consigne et nouveau rendu ; déjà dans l'image de départ → c'est la banque d'avatars qu'on
  corrige, pas la vidéo.
- **Regard** : une pose aux yeux baissés se corrige par la consigne — « il lève les yeux vers
  l'objectif dès le premier instant et garde le contact ».
- **Ce qui manque dans l'image ne s'invente pas** : mains vides = aucun accessoire à montrer. Des
  objets déjà en main, en revanche, se montrent très bien.

## Argent

- 🔒 **Tout script qui lance un travail payant doit savoir le REPRENDRE** (`--reprendre`) : trois
  travaux facturés ont échappé à leur sortie en une semaine, et relancer paie deux fois.
- **Aucune commande d'annulation n'existe** chez le fournisseur. La seule fenêtre pour annuler est
  **avant** le lancement.
- Le solde se **lit** (gratuit), jamais ne se calcule, et se lit **APRÈS** le travail.

## Voix

Deux voix, pas plus pas moins, gravées par le client : **478 Olivier Gagnon** (homme, et défaut
quand rien n'est précisé) · **805 Aïssatou Diallo** (femme). Défauts posés dans
`outils/voix-off.py`. Aucune ne bouge de ma propre initiative.
