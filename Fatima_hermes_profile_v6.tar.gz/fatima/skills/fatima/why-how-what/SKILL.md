---
id: Y0279
name: why-how-what
description: "Articule le Why/How/What d'une startup selon le Golden Circle de Simon Sinek — la vision de la BOÎTE, pas celle du fondateur — à partir de ses sources internes réelles (dataroom, branding, personas, traction), jamais depuis l'intuition seule. Trois modes de sortie : one-pager de vision (vision_1pager), slide de pitch (pitch_slide), doc d'alignement d'équipe (team_alignment_doc)."
bucket: C
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Why How What

## Ce qu'il faut avoir sous la main
1. **Nom de la startup**
2. **Mode de sortie souhaité** (optionnel, sinon je pars sur le one-pager) : `vision_1pager` / `pitch_slide` / `team_alignment_doc`
3. *(si ta startup n'est pas déjà connue de moi)* un lien vers ton pitch deck / dataroom, pour que je puisse ancrer ma proposition sur du réel plutôt que d'improviser

## Process
Pour la startup ciblée, charge en parallèle :

1. **Dataroom** — `[datasource à brancher : dataroom du client — pitch deck, customer discovery, verbatims clients]`
2. **Branding déjà acté** — `[datasource à brancher : base branding du client — positionnement, tagline existante, éléments déjà validés]`
3. **Personas** — `[datasource à brancher : base personas du client — qui sert-on, quel besoin profond]`
4. **Traction** — `[datasource à brancher : suivi de traction du client — KPIs réels, pour ancrer le WHAT]`

Si une brick critique manque (ex : pas de pitch deck), demande à l'utilisateur de pointer vers la source.

### Étape 2 — Analyse comparative (auto)

Identifie **3 à 6 startups comparables** à partir du pitch deck (slide concurrence/inspirations) ou de la dataroom. Si rien d'explicite, propose des comparables pertinents pour le marché cible via `[connecteur à brancher : recherche web]` (ex : pour une fintech UEMOA → Wave, Flutterwave, M-Pesa, OPay, Yellow Card, Chipper Cash).

Pour chaque comparable, articule en 1 ligne WHY/HOW/WHAT — pas une fiche complète, juste les patterns. Si l'utilisateur veut une matrice détaillée, propose-la en option.

### Étape 3 — ADN fondateurs (depuis la dataroom)

Récupère le profil cofondateurs depuis le pitch deck (slide team) ou la fiche projet. Extrais :
- Background pertinent (industrie, géo, expertise)
- Lien personnel au problème (le "founder-market fit")
- Avantages naturels (réseau, accès, expérience)

Tu n'as PAS besoin de re-saisir cette info via template — tu la lis depuis la source.

### Étape 4 — Articulation Why/How/What

Croise (1) patterns gagnants des comparables, (2) ADN founder, (3) verbatims customers/personas, (4) positionnement marché. Formule selon Sinek : WHY → HOW → WHAT.

Chaque proposition doit être **falsifiable** — si elle peut s'appliquer à n'importe quelle startup du secteur, elle est trop vague. Force la spécificité (référence verbatim, contrainte marché, ADN unique).

### Étape 5 — Output selon le mode choisi

### Mode `vision_1pager`
```
🎯 [NomStartup] — Golden Circle

🔥 WHY
[1-2 phrases, croyance profonde, ancrée dans le marché émergent]

⚙️ HOW
[3 principes opérationnels distinctifs, 1 ligne chacun]

📦 WHAT
[Produit/service concret en 1 phrase + 2-3 mécaniques clés]

---
DIFFÉRENCIATEURS
• [Avantage 1 — ancré ADN founder]
• [Avantage 2 — ancré contexte marché]
• [Avantage 3 — vs références sectorielles]

POSITIONNEMENT
[1 phrase : où on se place vs les comparables, et pourquoi c'est tenable]
```

### Mode `pitch_slide`
Output au format slide (vertical 1080×1350 ou paysage 16:9), WHY en titre hero, HOW en sous-titre avec 3 pills, WHAT en bullet liste, footer avec 3 différenciateurs. Précise les couleurs HEX et la typo à partir de la base branding du client.

### Mode `team_alignment_doc`
Doc 3-5 pages structuré :
1. Why/How/What proposé (1 page)
2. Rationale (analyse comparables condensée + verbatims customers + ancrage ADN founder)
3. Décisions à acter en équipe (checklist)
4. Risques d'incohérence (ex : "WHAT actuel pas aligné avec WHY proposé — ajustement produit nécessaire")
5. Completion criteria pour valider l'adoption

---

# Persistance

À chaque livraison validée :
- Écris le Why/How/What final dans `[datasource à brancher : base branding du client — écriture d'une entrée Type=Vision_GoldenCircle, Approved=false]`
- Référence le pitch deck source et la version

Le board / l'équipe dirigeante du client valide avant de faire passer l'entrée à Approved=true.

---

# Chaînage avec une skill de storytelling fondateur

Quand le WHY de la boîte est articulé, une skill complémentaire — `[skill à brancher : founder-storytelling]` — peut prendre le relais pour articuler pourquoi CE fondateur porte CE WHY (founder-mission fit, story arc personnel). Mentionne cette possibilité en fin de livraison si l'utilisateur prépare un pitch fundraising, une keynote ou un personal brand asset.

---

# Règles transversales

- **Toujours en français** sauf si l'utilisateur écrit en anglais
- **Spécificité > généricité** — chaque ligne doit être falsifiable
- **Verbatims customers > intuitions** — si la dataroom contient des quotes, utilise-les pour ancrer le WHY
- **Pas de jargon marketing** — un WHY se reconnaît parce qu'il est exprimable par un employé sans préparation
- **Ne JAMAIS** inventer le métier d'une startup — toujours sourcer depuis la dataroom/les documents fournis. Si la source est ambiguë, demande.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution des sources startup

> **Première instance — le programme.** Pour une startup du portefeuille du programme (l'entreprise), résous ses ressources via `[datasource à brancher : registre central des startups (« Registry ») — répertorie, pour chaque startup, les liens vers sa dataroom, sa base branding (Brand Memory), sa base personas et son suivi de traction (KPI Snapshot)]`. Filtre sur le nom exact de la startup, extrait les liens/IDs des bases utiles, utilise-les pour la collecte de l'Étape 1.
>
> Pour un autre déploiement (client hors portefeuille du programme), ce registre est remplacé par les sources propres au client — voir « Startups hors portefeuille » ci-dessous. Le reste de la méthode est inchangé.

### Startups hors portefeuille

Si la startup n'est pas dans un registre connu (client Yelema quelconque), ne bloque pas. Demande à l'utilisateur :
1. Un lien vers son pitch deck / sa dataroom (ou les documents qu'il peut partager)
2. Si elle existe déjà, sa charte de marque / positionnement déjà acté
3. Ses personas / profils clients, s'ils sont documentés

Travaille ensuite avec ces sources comme vérité de référence.

### Onboarding

1. **Quelle startup ?** — Si le nom n'est pas explicite, demande puis résous ses sources (registre ou documents fournis).
2. **Quel mode de sortie ?** — Propose :
   - `vision_1pager` (par défaut) — un one-pager Golden Circle synthétique, prêt à imprimer/partager équipe
   - `pitch_slide` — slide vision de pitch deck (WHY en hero, HOW + WHAT en sous-blocs, différenciateurs en footer)
   - `team_alignment_doc` — doc plus long avec rationale + références comparables + ADN fondateurs + completion criteria pour ateliers d'alignement
3. **Itération vs création ?** — Si la base branding du client contient déjà un WHY/HOW/WHAT, tu pars de l'existant et tu raffines. Sinon tu pars de zéro.

---

# Le framework Sinek (rappel)

Sinek dit : *People don't buy what you do, they buy why you do it.* L'ordre d'exécution est **WHY → HOW → WHAT** (de l'intérieur vers l'extérieur).

- **🔥 WHY — Pourquoi nous existons.** La cause profonde, la croyance. Pas un slogan marketing — une conviction que les fondateurs porteraient même sans cette startup.
- **⚙️ HOW — Comment nous l'incarnons.** Les principes opérationnels qui distinguent. Pas la stack technique, mais l'approche (ex : "by-design inclusive", "africain-first", "data-led trust").
- **📦 WHAT — Ce que nous faisons concrètement.** Les produits, services, mécaniques business. C'est le plus facile à articuler mais le moins important.

⚠️ **Erreurs à éviter** :
- WHY confondu avec mission marketing ("être leader sur..."). Le vrai WHY est une croyance, pas une ambition.
- HOW confondu avec WHAT (lister les features au lieu des principes).
- WHY/HOW/WHAT déconnectés des références du marché et de l'ADN founder.

---

# Workflow
