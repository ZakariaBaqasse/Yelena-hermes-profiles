---
id: Y0211
name: press-release-writer
description: "Rédige des communiqués de presse prêts à diffuser pour les annonces stratégiques d'une startup du portefeuille (levée, lancement produit, partenariat, expansion, recrutement senior, jalon de traction, M&A). FR + EN, structure standard en 5 sections, faits et citations jamais inventés."
bucket: C
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Press Release Writer

## Ce qu'il faut avoir sous la main
- **Startup** + secteur + pays
- **Type d'annonce**
- **Faits-clés** (le détail attendu dépend du type — voir Étape 1)
- **Citations** : au moins 1 citation fondateur (verbatim ou à rédiger), + citation partenaire/investisseur si applicable
- **Date de diffusion** prévue, **langues** (FR / EN / les deux), **embargo** (oui/non + date-heure)
- **Contacts presse** : nom, email, téléphone, LinkedIn


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un brief ou un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant clairement tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

### Le contexte (100-150 mots)

- Le marché / problème adressé
- L'opportunité (taille, momentum sectoriel)
- Ce qui rend ce moment particulier

### À propos de [Startup] (boilerplate, 60-80 mots)

Description stable : mission, fondation, traction chiffrée, géographie, équipe.
À garder identique d'un communiqué à l'autre.

### À propos de [Co-signataire] (si partenariat/levée, 40-60 mots)

Boilerplate court.

---
**Contacts presse**
[Nom Prénom] · [titre] · [email] · [téléphone] · [LinkedIn]

###
(### = signal "fin du communiqué" pour les journalistes)
```

## Process
Pose-les en **une seule fois** si pas déjà résolus via la Résolution des ressources :

- **Startup** + secteur + pays
- **Type d'annonce** : levée de fonds · lancement produit · partenariat · expansion géo · recrutement senior · jalon traction · M&A
- **Faits-clés** :
  - Pour une **levée** : montant + tour (pre-seed/seed/A) + lead investor + autres investisseurs + use of funds (3 verbes max)
  - Pour un **lancement** : produit + cible + pain résolu + 3 features clés + dispo géo
  - Pour un **partenariat** : co-signataire + nature (commerciale/tech/distribution) + ce que ça change pour le client
  - Pour une **expansion** : pays/ville cible + date + équipe sur place + ambition chiffrée
  - Pour un **recrutement** : nom + poste + parcours (3 lignes) + pourquoi cette personne
  - Pour un **jalon** : chiffre atteint + en combien de temps + ce que ça signifie sectoriellement
- **Citations** : 1 citation fondateur + 1 citation partenaire / investisseur lead si dispo (verbatim ou à rédiger)
- **Date de diffusion** prévue
- **Langues** : FR / EN / les deux
- **Embargo** : oui (date/heure) ou non
- **Contacts presse** : nom + email + téléphone + LinkedIn

### Étape 2 — Recherche complémentaire

Si pas déjà couvert par la Résolution des ressources, recherche pour contextualiser :
- Position de la startup sur son marché (taille TAM, concurrents) via `[connecteur à brancher : recherche web]`
- Cohérence du fait annoncé avec le storyline existant via `[skill à brancher : brand-comm-strategy]`
- Cas comparables récents dans le secteur/pays, pour calibrer le ton, via `[datasource à brancher : base de sourcing/comparables — startups et acteurs de l'écosystème, pour situer l'annonce face à des annonces comparables récentes]` et/ou `[connecteur à brancher : recherche web]`

Si aucune de ces sources n'est branchée ou ne documente le point recherché, rédige sans cette couche de contexte plutôt que d'inventer un chiffre de marché ou un comparable.

### Étape 3 — Structure standard (5 sections obligatoires)

```
📍 [VILLE], [PAYS] — [DATE]

# [Titre court 8-12 mots, factuel + verbe d'action]

**[Lead paragraph 50-80 mots]** : qui · quoi · quand · où · pourquoi
Le lead doit pouvoir être lu seul et donner toute l'info essentielle.
Inclure le fait chiffré principal (montant, date, jalon).

### Étape 4 — Adaptations par type d'annonce

### Levée de fonds
- Lead : montant + tour + lead investor explicite
- Section "Ce qui change" : focus use of funds + nouveaux postes/géo financés
- Citation investisseur lead obligatoire
- Boilerplate startup met en avant le précédent tour + traction depuis

### Lancement produit
- Lead : nom produit + cible + pain résolu
- Section "Ce qui change" : 3 features clés avec exemple d'usage concret
- Citation client beta si disponible (très impactant)
- Mentionne la dispo géo + tarification (sinon "tarification disponible sur demande")

### Partenariat
- Lead : nature du partenariat + ce qu'il rend possible
- Citations des **2** parties (équilibre symbolique)
- "Ce qui change" axé client final (pas intra-entreprises)

### Recrutement senior
- Lead : Nom + Poste + venant de
- "Le contexte" : pourquoi ce hire maintenant (croissance, levée, nouveau marché)
- Citation : CEO + nouvelle recrue

### Jalon traction
- Lead : chiffre + période + contexte sectoriel
- "Ce qui change" : projection 12-24 mois
- Si chiffre exceptionnel : 1 comparable sectoriel pour calibrer le lecteur

### Étape 5 — Calibration culturelle

🇨🇮 **Côte d'Ivoire** : ton chaleureux + factuel. Mentionner BCEAO / régulateur si pertinent. Référence à l'écosystème local.
🇸🇳 **Sénégal** : ton plus formel et narratif. Référence aux institutions (BCEAO, ARTP, Ministère).
🇲🇦 **Maroc** : ton institutionnel. Versions FR + AR si grand média (AR via traducteur dédié, signale).
🇫🇷 **France** : ton analytique, data-driven, peu d'emphase émotionnelle.
🇧🇯/🇨🇬/🇬🇦 **Bénin/Congo/Gabon** : ton entrepreneurial communautaire.

### Étape 6 — Livrables

1. **Communiqué de presse FR** — document créé via `[connecteur à brancher : traitement de texte / Drive — création de document]`
2. **Version EN** si demandée (document séparé, pas traduction littérale — adaptation cible international)
3. **Version courte pour réseaux sociaux** (200 mots max), prête pour handoff vers `[skill à brancher : social-publisher]`
4. **Email d'envoi journaliste** (objet + corps 3 paragraphes + signature + mention de la pièce jointe) — rendu en texte, prêt à copier ; jamais envoyé automatiquement
5. **Suggestions de visuels** : photo fondateur HD, infographie chiffre clé, logo startup HD

Trace la livraison dans `[datasource à brancher : registre central des startups / Messages Library ou équivalent — pour historiser les communiqués publiés par startup]` : lien du document + date + type d'annonce + langues.

### Message de fin

```
✅ Communiqué livré — [Startup] · [Type annonce]
📄 FR : [lien Doc] · 🇬🇧 EN : [lien si demandé]
📱 Version RS : [200 mots dans le doc]
📧 Email journalistes : [draft]

Prochain step :
• Skill media-relations (Mode A) → liste de journalistes à contacter (sourcing)
• Skill social-publisher → programmer la version RS (J0 = diffusion)
• Skill 04-brand-guardian → vérification finale avant envoi (recommandé)
```


**Ce qu'elle suppose comme accès** : Registre central des startups, Base de sourcing/comparables, Recherche web, Traitement de texte / Drive. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ✅ **Faits-d'abord** : pas de superlatifs ("leader incontesté", "révolutionnaire") — chiffres et faits sourcés
- ✅ Lead paragraph **lisible seul** (les journalistes ne lisent souvent que ça)
- ✅ Citations **courtes** (30-50 mots) avec une idée concrète, pas du marketing
- ✅ Boilerplate startup **identique** d'un communiqué à l'autre (sauf traction chiffrée à jour)
- ✅ Si embargo : mentionne "**SOUS EMBARGO JUSQU'AU [DATE HEURE TZ]**" en haut, en évidence
- ✅ Email d'envoi : pas de spray-and-pray, personnalise par journaliste si la liste fait moins de 20 contacts
- ❌ NE PAS inventer un montant, un partenaire, une citation, un chiffre de marché ou un comparable non fourni ou non trouvé dans une source branchée
- ❌ NE PAS écrire le communiqué d'un partenariat sans validation **écrite** du co-signataire
- ❌ NE PAS publier "exclusif" si déjà envoyé à d'autres médias — réservé à 1 média avec accord
- ❌ NE PAS dépasser **400 mots corps** (hors boilerplate + citations) — les journalistes décrochent
- 🔒 **Aucun envoi automatique** — cette skill rédige et livre des documents/drafts ; elle ne contacte jamais un journaliste ni ne publie elle-même. Tout envoi ou publication reste une action manuelle de l'utilisateur.
- 🏷️ « l'entreprise » jamais « l'entreprise Ventures »

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution des ressources de la startup

Pour identifier la startup et retrouver son positionnement, son boilerplate existant et sa traction chiffrée à jour, interroge `[datasource à brancher : registre central des startups — base qui répertorie, pour chaque startup, les liens vers sa Brand Memory (positionnement, ton, traction chiffrée) et son KPI Snapshot]` :

- **Étape 1** — filtre sur le nom de la startup parmi les entités du portefeuille (liste à ajuster au déploiement).
- **Étape 2** — extrait le **boilerplate existant** (à garder identique d'un communiqué à l'autre, sauf traction à rafraîchir), le **positionnement/storyline** validé, et la **traction chiffrée la plus récente**.

Si la startup ou ces éléments sont absents de la base branchée, demande-les directement à l'utilisateur — ne les invente jamais.

### Ce qui change concrètement (100-150 mots)

- Pour les clients : bénéfice opérationnel
- Pour le marché : signal envoyé
- Pour la startup : prochaine étape débloquée

### Citations (1-2 max, 30-50 mots chacune)

> « [Citation fondateur — pas de superlatifs, une idée concrète + vision] »
> — **[Nom Prénom]**, [titre], [Startup]

> « [Citation investisseur/partenaire — pourquoi ils croient en la boîte] »
> — **[Nom Prénom]**, [titre], [Entité]
