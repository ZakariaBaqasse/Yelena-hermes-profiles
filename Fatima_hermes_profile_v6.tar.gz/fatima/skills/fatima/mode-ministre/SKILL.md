---
id: Y0566
name: mode-ministre
description: >
  MODE DÉMONSTRATION MINISTÉRIELLE — produire vite des concepts visuels de niveau
  international pour une démonstration institutionnelle. À charger sur la commande
  « /ministre » (toutes graphies), et AUSSI sans elle dès qu'apparaissent les termes
  « démonstration ministérielle », « 700 services publics numériques », « IA au service du
  citoyen », « Infrastructure Publique Numérique », ou une demande de concept pour un
  ministre, un ministère ou une institution publique. Priorité : vitesse, clarté, élégance,
  impact visuel.
version: 1
maj: 2026-09-10
---

# Mode démonstration ministérielle

Standard arrêté par le client le 09/09/2026 à 22 h 32 UTC, dans le fil marketing.
Ses mots : « **si demain je te dis /ministre tu dois penser a ca** », et
« **ou sis j'oublie de dire /ministre mais je parle de ces termes :: garde ca en tete et en
memoire :: infos de tres haute importance** ».

Donc : **le mode se déclenche sur les TERMES autant que sur la commande.** Attendre la barre
oblique est la faute à ne pas commettre.

## Ce que le mode impose

Produire **rapidement** des concepts visuels de niveau international pour des démonstrations
institutionnelles. La priorité est la vitesse, la clarté, l'élégance et l'impact visuel.

Le formulaire contient généralement : **thème · nom de la personne · entreprise ou institution ·
format demandé**. Ses mots : « **Ces informations suffisent pour lancer une première version.
Ne pose pas de questionnaire supplémentaire.** » Au maximum **une** question, et seulement si
elle bloque réellement la création. Sinon, hypothèses raisonnables, **indiquées après** la
génération.

Pour chaque thème : une **idée centrale forte**, une **accroche**, un **message court**, un
**appel à l'action**, une **direction visuelle**.

## Les trois thèmes, et leur interprétation

| Thème | Ce qu'il faut mettre en scène | La limite à ne pas franchir |
|---|---|---|
| **700 services publics numériques** | la simplification de l'accès aux services publics, la centralisation, la proximité, l'efficacité | — |
| **IA au service du citoyen** | une IA qui oriente, explique, facilite l'accès à l'information et rapproche le citoyen du service public | « **Ne promets jamais une capacité qui n'est pas confirmée.** » |
| **Infrastructure Publique Numérique** | des infrastructures communes, sécurisées, interconnectées, capables de soutenir plusieurs services publics | « **N'invente aucune architecture technique.** » |

## Direction artistique

Esthétique **institutionnelle, moderne, premium, internationale** : composition claire,
hiérarchie forte, **peu de texte**, contraste élevé, lisibilité immédiate, tenue au mobile
comme au grand écran, éléments visuels liés au citoyen, au numérique, aux réseaux et au
service public.

🔒 **Drapeau, emblème et logos officiels UNIQUEMENT à partir des fichiers fournis.** On ne
déforme, on ne recolore et on ne recrée **jamais** un emblème officiel. **Aucun partenaire ni
logo non fourni.** (Cette règle rejoint la mienne : un logo officiel se pose sans retouche,
avec une plaque claire sur fond d'encre.)

## Formats par défaut

- **Vidéo** : verticale 9:16, 15 à 30 s, **sous-titres inclus**.
- **Billboard** : 16:9, un message principal, lisible à distance.
- **Flyer** : vertical, lisible sur mobile et imprimable.
- **Carrousel** : cinq diapositives au maximum.
- **Publicité mobile** : image forte, accroche courte, appel à l'action visible.

## Règles de rapidité

Commencer immédiatement avec les informations du formulaire. **Pas de recherche longue pendant
la démonstration** : on se sert des modèles, logos, couleurs, images et éléments **préchargés**
(voir le kit ci-dessous). Si une donnée factuelle manque, **formulation institutionnelle
prudente** plutôt qu'un chiffre ou une promesse inventée.

🔒 Les noms et institutions fournis servent à **personnaliser** la démonstration. Ne jamais
présenter leur présence comme une approbation, un témoignage ou une validation officielle.

🔒 Chaque rendu se présente comme : « **Concept de démonstration, à valider avant usage
officiel.** » La mention se pose **dans le fichier**, pas seulement dans le message : un
visuel qui circule seul doit la porter.

## Format de réponse imposé

```
THÈME :
DESTINATAIRE :
IDÉE CENTRALE :
ACCROCHE :
MESSAGE :
FORMAT PRODUIT :
CONTENU OU SCRIPT :
ÉLÉMENTS VISUELS :
HYPOTHÈSES :
POINT UNIQUE À VALIDER :
```

« **Ne raconte pas ton raisonnement. Génère d'abord le concept et le rendu. Les améliorations
viennent après la première version.** »

Ce format **remplace** mon format de sortie général dans ce mode — il porte déjà les
hypothèses et le point à valider. Ce qui ne se réduit jamais reste : rien d'inventé, rien de
publié ni de dépensé sans accord, et **contrôle visuel du fichier remis**.

## Le kit préchargé — ce qui rend le mode rapide

Vérifié le 10/09/2026, tout est composé à la police et **ne coûte aucun crédit**.

| Pièce | Où |
|---|---|
| Logo officiel du MTNIT, **il porte les armoiries de la République** | `banque-images/mtnit/logo-mtnit-officiel.jpg` (JPEG 1741 × 517) |
| Couleurs **relevées** dans leur feuille de style | encre `#023A05` · vert clair `#3FA535` · orange `#EF7D00` · fond `#f7f6f1` |
| Gabarits de cartes prêts, un par thème | `.claude/skills/mode-ministre/gabarits/` |

⚠️ **Le logo n'existe ici qu'en JPEG** : tout rendu est bon pour l'écran, **aucun ne part à
l'impression** avant le fichier vectoriel. Les couleurs sont relevées, **non fournies** — même
conséquence, et ça s'écrit sur le livrable.

## Les commandes, toutes gratuites

```bash
# cartes : "paysage" 1920×1080 (billboard) · "vertical" 1080×1920 · "portrait" 1080×1350 · "carre"
python3 outils/carrousel.py <cartes.json> <dossier_sortie>

# vidéo 9:16 à textes animés — le texte à l'écran EST le sous-titre quand il n'y a pas de voix
python3 outils/video-textes-animes.py <cartes.json> <sortie.mp4> [--durees …] [--voix piste.mp3]

# carrousel en PDF (une page = une carte), pour LinkedIn ou la messagerie
python3 outils/carrousel-pdf.py …

# flyer A5 imprimable
python3 outils/flyer-a5.py …
```

**Voix off = PAYANT** (16 crédits la ligne, `outils/voix-off.py … --je-paie`, voix d'homme 478
par défaut). Une demande de rapidité **n'est pas** un accord de dépense : en démonstration, on
sort muet, et la voix se propose avec son coût.

⚠️ Quand un film porte une voix, **l'image suit la voix** (`--durees`), et les fondus mangent
du temps : avec `n` cartes et un fondu de 0,5 s, la somme des durées doit dépasser la piste de
`(n-1) × 0,5` s, sinon la bande-son se fait tronquer. Constaté le 10/09/2026 : 23,36 s de film
pour 25,76 s de voix.

## Deux pièges du format paysage, corrigés le 10/09/2026

Le format `paysage` a été ajouté à `carrousel.py` ce jour-là, et son premier essai a montré
deux défauts — d'où la règle : **on regarde le fichier avant de le remettre.**

1. Le titre **mordait sur le bandeau de marque** (texte parti trop haut). Le bloc démarre
   maintenant sous le logo.
2. Le numéro de carte **mordait sur la bande d'appel**. Il ne se dessine plus sur une carte
   seule, où il ne servait à rien.
