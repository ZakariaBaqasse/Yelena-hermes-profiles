---
id: Y0518
name: caption-hashtag-optimizer
description: "Optimise captions + hashtags par plateforme : accroche scroll-stop, jeux de hashtags calibrés, variantes A/B."
bucket: A
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# Caption Hashtag Optimizer

## Ce qu'il faut avoir sous la main
- Obligatoires : le contenu ou l'angle à publier, la/les plateforme(s) cible(s) (Instagram, TikTok, LinkedIn, Facebook, X…), la marque et son audience.
- Optionnelles : ton, langue, mots-clés/SEO social, objectif (notoriété/engagement/conversion), brand kit.


**Ce qu'elle suppose comme accès** : Recherche web, Génération de visuel interactif (Frame), LinkedIn. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. Reformuler l'accroche (1ère ligne) pour le scroll-stop, native à chaque plateforme (longueur, emojis, ton).
2. Adapter le corps au format natif (césures, listes, retours à la ligne).
3. Générer des hashtags par plateforme : mix large / niche / marque, quantité calibrée (IG ~8-15, TikTok ~3-5, LinkedIn ~3, X ~2). Aucun hashtag inventé pour une tendance non vérifiée.
4. Proposer 2 variantes d'accroche pour A/B et un CTA adapté à l'objectif.

## Format de sortie

Termine TOUJOURS par un **Frame interactif** présentant le livrable de façon soignée, aux couleurs du brand kit fourni (sinon une palette neutre). Si la visualisation n'est pas disponible, produis un livrable structuré prêt à l'emploi.

## Règles

- Zéro invention : tout fait, chiffre, citation ou tendance repose sur une source vérifiable (données fournies, connecteur, recherche web sourcée). Une donnée absente est signalée « à confirmer », jamais inventée. Aucune fausse citation ni faux témoignage.
- Validation humaine : tout contenu destiné à être publié ou envoyé est présenté « à valider avant publication » ; aucune publication automatique.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

À partir d'un post, d'un visuel ou d'un angle, produire la caption optimisée (accroche + corps + CTA) et un jeu de hashtags calibré, pour chaque plateforme demandée.
