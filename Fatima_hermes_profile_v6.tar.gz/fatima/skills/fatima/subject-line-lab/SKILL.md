---
id: Y0248
name: subject-line-lab
description: "Génère et score des objets d'email + pré-en-têtes qui font ouvrir, par style, avec recommandation A/B."
bucket: A
tags: [Design]
version: 1
maj: 2026-08-10
---

# Subject Line Lab

## Ce qu'il faut avoir sous la main
1. Le **corps** de l'e-mail (ou une phrase qui le décrit) ;
2. **Audience** + relation (froid / chaud / client) · **objectif** (ouverture / réponse / clic) · **langue** (FR/EN) · **ton** ;
3. *(optionnel)* une **voix de marque** (ton, vocabulaire, exemples) — sinon je travaille sur l'e-mail fourni.

## Process
Produis **12-15 objets** répartis par style, chacun avec un **pré-en-tête** assorti :
- 🔍 **Curiosité** (ouvre une boucle)
- 🎯 **Bénéfice direct** (la valeur en clair)
- ❓ **Question** (engage)
- 👤 **Personnalisé** (`{{first_name}}` / `{{company}}` / déclencheur)
- ⏰ **Timing / échéance** (sans fausse urgence)
- 🏆 **Preuve sociale / chiffre** (uniquement si fourni — jamais inventé)
- ⚡ **Pattern-interrupt** (inattendu)
- ✂️ **Ultra-court** (1-3 mots)

### Étape 2 — Scoring

Tableau : Objet · Style · Longueur (car. / mots) · Lisible mobile (✅ ≤ ~40 car. / ~6 mots) · Risque spam (🟢/🟡/🔴) · Note d'ouverture estimée. Signale les objets trop longs (coupés sur mobile) ou à mots déclencheurs de spam.

### Étape 3 — Recommandation

- **Top 3** à utiliser + pourquoi.
- **1 paire A/B** à tester (2 angles différents, ex. curiosité vs bénéfice).
- Rappel : l'objet doit tenir la promesse du corps (pas de clickbait trompeur).

## Format de sortie
- **Livrable** : le livrable produit par « Subject Line Lab ».
- **Structure** : Markdown clair — titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] » — jamais présentée comme réelle.

## Règles
- ❌ Pas de clickbait mensonger ; pas de chiffre/fait inventé (placeholders sinon).
- 📱 Mobile-first : viser ≤ 40 caractères / ~6 mots pour les meilleurs.
- 🚫 Éviter MAJUSCULES, excès d'emojis, mots déclencheurs de spam (« gratuit », « gagnez », « urgent !!! »).
- 🌍 FR ou EN selon l'audience.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
