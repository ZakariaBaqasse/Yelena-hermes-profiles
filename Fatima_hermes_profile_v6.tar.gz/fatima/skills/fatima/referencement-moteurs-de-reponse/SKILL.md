---
id: Y0462
name: referencement-moteurs-de-reponse
description: "Rend un site trouvable par Google ET citable par les moteurs de réponse (ChatGPT, Claude, Perplexity, Gemini) : mesure l'état de départ page par page, réécrit les titres et les descriptions au format réellement affiché, pose le balisage de données structurées, autorise nommément les robots des moteurs de réponse dans robots.txt, produit un llms.txt et un llms-full.txt, puis remesure avec le même programme pour prouver l'écart, sans jamais promettre une position ni annoncer un gain avant la mise en ligne."
bucket: B
tags: [Marketing, Web, Horizontal, Nouveau]
version: 1
maj: 2026-09-02
---

# Référencement sur les moteurs de réponse : être trouvé, et être cité

## Ce qu'il faut avoir sous la main
- **L'adresse du site**, et s'il existe une version de travail pas encore en ligne.
- **Ce que l'entreprise vend**, à qui, et dans quelle ville ou quel pays.
- **Les trois questions** qu'un client se pose avant d'acheter, dans ses mots à lui.
- **Qui peut modifier le site** et avec quel outil, ou si personne ne peut y toucher pour l'instant.
- **Les fichiers du site** si tu les as, sinon l'adresse suffit pour la mesure.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), et tu ne redemandes que ce qui est réellement indispensable.

## Process

### Étape 1 : mesurer avant de toucher quoi que ce soit
Écris **un seul programme** de mesure, et fais-le passer sur la version d'avant comme sur la version d'après. Deux relevés faits avec deux outils différents ne comparent que les outils. Le relevé note, page par page :
- longueur du titre et de la description, présence du lien canonique, présence de données structurées ;
- nombre de titres de premier niveau, et tout saut dans la hiérarchie des titres ;
- images sans dimensions déclarées, sans texte de remplacement, jamais affichées ;
- présence d'une page 404, d'un plan du site, sa date, et les robots nommés dans robots.txt.

**Vérifie ce que voit un robot, pas ce que voit ton navigateur.** Demande la page en te présentant comme chacun des robots des moteurs de réponse et regarde ce qui revient. Un site peut servir une page complète à un humain et une page vide, ou un refus d'indexation, à un robot. C'est invisible autrement.

### Étape 2 : les titres et les descriptions
Un titre au-delà d'une soixantaine de signes est coupé en plein milieu dans les résultats, une description au-delà d'environ cent soixante aussi. Une description trop courte ne dit rien et laisse le moteur en écrire une à ta place.
- Le titre affiché en haut de la page et le titre envoyé au moteur peuvent être **deux textes différents**. Sur un article long, garde le titre riche pour le lecteur et écris un titre court distinct pour l'onglet et le résultat de recherche.
- Écris la description comme une réponse, pas comme un slogan : elle doit contenir la question du client et le début de la réponse.
- Les pages qu'on oublie toujours : mentions légales, confidentialité, page de contact, page de conversion. Elles sont indexables, elles méritent une description écrite.

### Étape 3 : parler aux robots des moteurs de réponse
- **robots.txt nomme les agents**, en deux familles séparées, parce que les conséquences ne sont pas les mêmes : ceux qui **citent** une page dans une réponse, et ceux qui **collectent** pour entraîner un modèle. Refuser la première famille, c'est disparaître des réponses. Refuser la seconde est un choix légitime que le client doit prendre en connaissance de cause. Écris un commentaire dans le fichier qui explique comment refuser une famille sans toucher à l'autre.
- **`llms.txt`** : le plan du site en texte clair, une ligne par page avec son adresse et son résumé.
- **`llms-full.txt`** : le contenu intégral du site en texte, pour qu'un modèle réponde juste sans avoir à parcourir chaque page.
- **Les données structurées** décrivent l'entreprise, ses pages et surtout ses questions fréquentes. Le format questions-réponses est celui que les moteurs de réponse reprennent le plus volontiers, parce qu'il leur donne une réponse déjà rédigée.
- Si le site est derrière un service de protection, vérifie ses réglages : certains bloquent les robots d'intelligence artificielle **avant** que robots.txt ne soit lu, et tout le travail ci-dessus reste alors sans effet.

### Étape 4 : remesurer et livrer
Repasse le programme de l'étape 1 sur la version corrigée, et livre un tableau à trois colonnes : ce qui a été mesuré, avant, après. C'est la seule preuve qui vaut. Ajoute ce qui reste à faire chez le client, écrit pas à pas, sinon personne ne l'exécutera.

## Format de sortie
Un récapitulatif court, en trois parties :
1. **Le tableau avant et après**, une ligne par chose mesurée.
2. **Ce qui a été corrigé**, en puces, chaque puce disant ce qui n'allait pas et pourquoi ça coûtait quelque chose.
3. **Ce qui reste à faire chez le client**, numéroté, chaque étape formulée comme une action exécutable par quelqu'un qui n'a pas suivi le chantier.

Les fichiers produits accompagnent le récapitulatif : le site corrigé, `robots.txt`, `llms.txt`, `llms-full.txt`.

## Règles
- **Ne promets jamais une position ni un volume de trafic.** Tu corriges ce qui empêche d'être lu et cité. Le classement dépend de facteurs que personne ne contrôle.
- **Rien ne produit d'effet avant la mise en ligne.** Dis-le à chaque livraison, en clair. Tant que la version corrigée n'est pas déployée, les moteurs continuent de lire l'ancienne, et le client croira que le travail n'a servi à rien.
- **N'invente aucun chiffre du métier du client** pour remplir une description ou une question fréquente. Une affirmation qui n'a pas de source sortie du client ne s'écrit pas.
- **Une absence de résultat n'est pas une preuve d'absence.** Une recherche qui ne rend rien, un fichier qui ne répond pas, un outil qui refuse peuvent tous ressembler à « il n'y a rien ». Vérifie avant de conclure.
- **Teste chaque lien avant de le mettre dans un livrable.** Une adresse morte dans un document envoyé ne se rattrape pas.
- **Un aperçu de travail se sert en interdiction d'indexation.** Une version de démonstration indexée entre en concurrence avec le vrai site du client dans les résultats.

## Cas limites
- **Le site est construit par un outil que tu ne peux pas modifier** (constructeur en ligne, thème verrouillé). Livre alors la liste exacte des textes à coller, champ par champ, écran par écran, plutôt qu'un fichier que personne ne pourra installer.
- **Le client refuse la collecte pour l'entraînement.** Parfaitement recevable. Bascule le second bloc de robots.txt en refus, garde le premier en autorisation, et explique-lui qu'il reste citable.
- **Le site n'a qu'une seule page.** `llms.txt` garde son sens, `llms-full.txt` aussi : ce sont eux qui donnent le contenu en texte à un robot qui ne lit pas le JavaScript.
- **Deux versions du site circulent** et tu ne sais pas laquelle fait foi. Celle qui fait foi est celle qui a été **envoyée ou mise en ligne**, pas celle du dossier qui porte le bon nom. Fais trancher avant d'écrire dessus.
- **Le site est en plusieurs langues.** Chaque langue a ses titres, ses descriptions et son entrée dans le plan du site. Ne traduis pas une description mot à mot, la question que se pose le client n'est pas formulée pareil.
