---
id: Y0150
name: event-comms
description: "Construit un plan de communication événementielle en 3 phases (pré-event / live / post-event), multi-canaux et multi-audiences, pour un événement organisé par l'organisation, par une startup de son portefeuille, ou pour une intervention d'un·e fondateur·rice/dirigeant·e en tant que speaker : posts prêts à programmer par canal, liste de contacts à inviter, tracker de suivi, et brief speaker délégué."
bucket: C
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Event Comms

## Ce qu'il faut avoir sous la main
Je vérifie d'abord silencieusement :
1. `[datasource à brancher : mémoire d'exécution de la skill — événement déjà traité, historique de comms pour cet event (posts déjà livrés, contacts déjà identifiés)]`. Si un historique est retrouvé, je te le rappelle et te propose de continuer plutôt que de repartir de zéro.
2. Si tu mentionnes une **startup du portefeuille**, je charge automatiquement `[datasource à brancher : fiche Mémoire Startup — brand kit, ton de voix, historique de comms]` et je te confirme ce que j'ai trouvé avant de lancer le plan.

Si rien de tout ça n'existe, donne-moi **en un seul message** :
- **Type d'event** : tu organises · une startup de ton portefeuille organise · speaker invité externe · participation passive (booth, networking)
- **Nom de l'event** + organisateur + ville/pays + dates
- **Format** : conférence · panel · talk · workshop · podcast live · launch event · pitch competition
- **Audience cible** de l'event (estimée par l'organisateur + audience qu'on veut atteindre via la diffusion)
- **Notre place** : speaker · panéliste · MC · sponsor · participant
- **Sujet** : si speaker → angle de la prise de parole, message clé
- **Objectif comm** : notoriété · lead gen · recrutement · investor signaling · partenariat
- **Calendrier** : date event + nombre de semaines avant (le plan se cale en J-X / J / J+X)
- **Assets disponibles** : visuels orga, logo, photo du/de la speaker, replay vidéo si dispo après

### Résolution du contexte (startup du portefeuille)

Si l'événement concerne une startup du portefeuille (elle organise l'event, ou son/sa fondateur·rice y intervient comme speaker), résous ses ressources via `[datasource à brancher : registre central des startups — répertorie pour chaque startup les liens vers Brand Memory, Content Calendar, dossier logos/branding, sub-hub de rattachement]` :

1. Filtre sur le nom exact de la startup.
2. Extrait le ton de voix, la charte graphique et le calendrier éditorial déjà en place, pour aligner le plan event dessus.
3. Utilise le sub-hub résolu comme emplacement pour toute création de page (voir règle ci-dessous).

Si la startup n'est pas dans le registre (l'organisation elle-même, ou un client hors portefeuille), continue directement avec les infos données par l'utilisateur·ice — ne bloque jamais sur un registre absent.

## Process
Produis le plan complet structuré en **3 phases** :

### 📅 PHASE PRÉ-EVENT (J-21 → J-1)

**Adaptations selon objectif** :

- Notoriété → ratio 80% top of funnel, hashtags larges
- Lead gen → CTA inscription/booth/démo
- Recrutement → mention « on recrute » en filigrane
- Investor signaling → posts plus institutionnels, tagger partenaires/investisseurs

### 🎤 PHASE LIVE (J0)

**Logistique** :

- Désigner **1 personne** dédiée au live posting (sinon ça ne se fait pas)
- Pré-écrire 5-10 tweets/posts « à publier pendant » — il suffit de remplir les blancs
- Si livestream : épingler le lien dans tous les canaux

### 🎬 PHASE POST-EVENT (J+1 → J+30)

**Maximisation ROI** :

- Demander à l'organisateur le **replay vidéo** dans les 24h (sinon souvent perdu)
- Demander la **photo HD** professionnelle (sinon récupérer photos audience)
- Capitaliser les **idées du talk** en 3+ contenus longue traîne (article + carrousel + clip vidéo)

### Étape 2 — Posts pré-rédigés (livrables exécutables)

Pour chaque canal × moment du plan, **drafte le post** prêt à publier :

- Texte natif au canal (cf `[skill à brancher : social-publisher]` pour les contraintes)
- Suggestions visuelles (1-2 par post)
- Hashtags pertinents (event tag officiel + thématiques)
- Tag des comptes pertinents (orga + co-speakers + partenaires)
- UTM tracking si lien sortant

Output : `[connecteur à brancher : Google Docs]` structuré (1 onglet/section par phase) + tableau `[datasource à brancher : Notion — tableau de suivi des posts]` avec colonnes (Date · Canal · Texte · Asset · Status).

### Étape 3 — Tracker comms

Crée une page `[connecteur à brancher : Notion]` **« Event Comms — [Nom Event] »** avec :

- Plan complet (timeline)
- Posts drafts (prêts à programmer)
- Liste de contacts à inviter (warm + cold) — `[datasource à brancher : carnet de contacts / CRM — réseau existant (warm) et contacts à identifier via recherche (cold)]`
- Liste de journalistes pertinents (sourcing via `[skill à brancher : media-relations]` Mode A)
- KPIs à suivre : reach pré-event, audience live, vues replay, leads générés

### Étape 4 — Brief speaker (si un·e fondateur·rice/dirigeant·e intervient)

Délègue à `[skill à brancher : media-relations]` (Mode B) la préparation de l'intervention elle-même (questions probables, messages clés, simulation). Ton scope reste **l'amplification autour de l'intervention**, pas la prise de parole en elle-même.

### Étape 5 — Message de fin

```
✅ Plan Event Comms livré · [Nom Event] (J-X)
📄 Tracker → [lien]
📅 Posts programmables : {N} (pré: A · live: B · post: C)
📧 Contacts à inviter : {M} warm + {P} cold
🎤 Brief speaker délégué à media-relations (Mode B)

Prochains steps :
• 04-brand-guardian pour la QA des posts drafts
• social-publisher pour programmer (timing optimal)
• press-release-writer si event = announce majeur
• media-relations (Mode A) pour la liste de journalistes
```

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
Quand tu crées une page ou un document pour cet événement :

1. Si l'événement concerne une startup du portefeuille, résous son sub-hub depuis le registre (voir ci-dessus) et crée la page **sous ce sub-hub**.
2. Si l'événement concerne l'organisation elle-même ou une entité hors registre, crée la page à l'emplacement dédié aux événements de l'organisation.
3. Ne crée **jamais** de page standalone ni dans un espace non désigné.
4. Si l'emplacement est introuvable ou ambigu, demande à l'utilisateur·ice où créer la page — n'invente jamais un emplacement.

- ✅ Plan **toujours en 3 phases** (pré / live / post) — pas de event sans phase post
- ✅ Phase post = **50% de la valeur** : c'est là qu'on capitalise le talk en contenu evergreen
- ✅ Désigner explicitement le **live poster** (sinon rien ne se passe en live)
- ✅ Capter **replay + photo HD** dans les 24h post-event
- ✅ UTM tracking sur **tous** les liens
- ❌ NE PAS over-promise : si l'organisation n'a pas la bandwidth pour 9 posts pré-event, propose un plan à 3 posts
- ❌ NE PAS programmer en J0 sans backup humain (si bug : pas de live posting)
- ❌ NE PAS oublier de **tagger** l'organisateur et les co-speakers
- ❌ NE PAS recycler le même post sur 5 canaux — adapte au format natif

> **Première instance — l'entreprise / le programme.** Cette skill est déployée pour le portefeuille de l'entreprise : « l'entreprise » toujours écrit ainsi, jamais une variante étendue. Startups du portefeuille : plusieurs entités du portefeuille. Pour un autre déploiement (client hors portefeuille), retire cette convention de nommage et adapte-la à la charte du client — le reste de la skill (plan 3 phases, posts pré-rédigés, tracker, brief speaker) est inchangé.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
