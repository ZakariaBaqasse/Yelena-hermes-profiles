---
id: Y0093
name: brand-comm-strategy
description: "Stratégie brand & comm complète : positionnement narratif + voix de marque + stratégie RS + plan média 6 mois. Input des skills de production."
bucket: C
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Brand_Comm_Strategy

## Ce qu'il faut avoir sous la main
1. la **marque/startup** concernée ;
2. son **objectif comm à 6 mois** (notoriété · acquisition · talent · fundraising · lobbying/institutionnel) ;
3. si elle n'est pas dans le portefeuille connu : identité (nom, tagline, secteur, mission, cible), stade, canaux actifs (URLs), 3-5 concurrents, pays.


**Ce qu'elle suppose comme accès** : Registry, Hub racine, Dossier de fichiers marque, Datarooms du programme, Base centrale des stratégies de communication, Sheet KPI business propre à une marque, Recherche web, API réseau social professionnel. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Avant de créer quoi que ce soit, vérifie via le Registry et le sous-espace de connaissance de la marque si une stratégie Brand & Comm complète existe déjà pour cette marque. Si oui : propose une **révision ciblée** plutôt qu'une création from scratch. Puis collecte les inputs manquants :

- **Identité** : nom, tagline, secteur, mission, cible(s)
- **Stade** : pre-seed / seed / Series A+
- **Objectif comm 6 mois** : notoriété · acquisition · talent · fundraising · lobbying / institutionnel
- **Positionnement actuel** : USP, 3 mots-clés voix existants
- **Canaux actifs** : LinkedIn / FB / IG / TikTok / X (URLs + audience + fréquence cible)
- **Audiences cibles** : 3-5 hiérarchisées
- **Concurrents directs** : 3-5 par canal + 3-5 narratifs (peuvent overlap) — **identifie et signale explicitement le concurrent local le plus direct** s'il en existe un : il structure le positionnement différenciant pour tout le reste de la stratégie
- **Pays principal + secondaires** : pour calibration culturelle
- **Actualités à venir** : lancements, levée, événements, partenariats
- **Contraintes** : budget, ressources internes, taboos sectoriels

Si inputs manquants : **une seule question groupée**, puis avance.

### Étape 2 — Diagnostic actuel (volet narratif + volet RS)

### Voix narrative existante

Crawl LinkedIn, site, presse, RS via `[connecteur à brancher : recherche web]` — 30 derniers posts + 5 derniers articles presse. Identifie : ton dominant, vocabulaire signature, postures (expert / inspirant / provocateur), incohérences entre canaux.

### Performance RS canal par canal

Pour chaque canal actif, scrape **les 30 derniers posts** :

- LinkedIn → `[connecteur à brancher : API réseau social professionnel (type Unipile/LinkedIn) — priorité]` ou fallback `[connecteur à brancher : scraper web (type Apify)]`
- IG / TikTok / FB → `[connecteur à brancher : scraper web (type Apify) — actors profil/hashtag Instagram, TikTok, Facebook]`
- X → `[connecteur à brancher : scraper web]` ou `[connecteur à brancher : recherche web]`

Identifie : ton actuel, fréquence réelle, engagement moyen, sujets dominants, formats utilisés. Diagnostique : **2-3 points forts + 2-3 lacunes prioritaires par canal**.

### Couverture presse

Volume + tonalité + sujets dominants des articles existants.

### Étape 3 — Benchmark comparables

Pour chaque concurrent fourni :

- **Volet narratif** : positionnement en 1 phrase, story arc, espace blanc dispo
- **Volet RS** : scrape les 20 derniers posts par canal (mêmes connecteurs qu'à l'Étape 2), ton + format + fréquence + engagement moyen

Produit une **table comparative** : concurrent × canal × fréquence × format dominant × ton × engagement × message clé.

### Étape 4 — Stratégie livrable (memo unique)

Produit le memo **« Stratégie Brand & Comm — [Marque] »** dans `[datasource à brancher : base centrale des stratégies de communication]`.

### 🎯 Positionnement narratif

**Phrase signature** 15-25 mots qui dit qui vous êtes, pour qui, et pourquoi vous comptez. Pas un slogan — une boussole interne. Justification 3-5 lignes.

### 📜 Story arc fondateurs (3 actes)

- **Acte 1 — origine** : d'où viennent les fondateurs, le déclic, le problème vu de l'intérieur
- **Acte 2 — mission** : pourquoi cette boîte, ce qu'elle change concrètement
- **Acte 3 — ambition** : où la boîte sera à 5 ans, ce qu'elle laisse derrière

Cette histoire doit revenir dans toutes les bios longues, interviews, conférences, fundraising decks.

### 🎤 Messages clés par audience

Tableau : audience (clients · investisseurs · talents · partenaires · presse · régulateurs) × 3-5 messages clés **formulés comme des phrases prêtes à citer**, pas comme des keywords.

### 🎨 Voix & ton

- 3 mots-clés voix (ex. expert · chaleureux · sans détour) — chacun **justifié**
- Pronom (tu/vous), formalité, registre vocabulaire
- Émojis OK / à éviter
- 5-10 mots/expressions **signatures**
- 5-10 mots **taboos** (concurrents, formulations risquées, anglicismes désuets)

### 📡 Canaux prioritaires + fréquence

Classement 1→N des canaux à animer avec **fréquence cible par canal** (ex. LinkedIn 3×/sem, IG 4×/sem, TikTok 5×/sem, FB 2×/sem, X optionnel). Justification basée sur ressources de la marque.

### 🎨 Formats prioritaires par canal

2-3 formats à privilégier par canal (carrousel / vidéo courte / image+texte / story / thread). Justification.

### 🧱 5-7 sujets piliers

Colonne vertébrale du contenu pour les 3 prochains mois. Équilibre : éducatif / inspirant / produit / témoignage / coulisses / opinion / actualité sectorielle.

### 🏷️ Hashtags

- **Signature** (3-5, marque + secteur)
- **Par canal** : 5-10 hashtags tendance par plateforme
- **Taboos** : à éviter

### 📅 Plan média 6 mois

Mois par mois : 1 narratif pilier + 2-3 actions (interview, prise de parole, événement, partenariat presse, op-ed, podcast). Pour chaque action : audience, ROI attendu, effort requis.

### 📅 Calendrier événements à venir

Lancements produit, dates clés (fêtes nationales, cycles réglementaires sectoriels si pertinent), RDV récurrents.

### 🌍 Calibration culturelle

Si pays multiples : adapter messages + ton + canaux par pays. Voir la calibration par défaut de la première instance déployée en section « Configuration » ci-dessous ; pour une nouvelle marque/pays hors de cette liste, construis la calibration à partir des inputs collectés (positionnement local, codes culturels de communication du pays).

### 🚨 Risques & gardes-fous

3-5 sujets/postures à manier avec précaution + 2-3 situations de crise plausibles + posture par défaut.

### ✅ Recommandations actionnables

5-7 actions concrètes triées par impact pour les 4 prochaines semaines.

### Étape 5 — Livraison

1. **Page** « Stratégie Brand & Comm — [Marque] » dans `[datasource à brancher : base centrale des stratégies de communication]`.
2. **Récap visuel** via `[connecteur à brancher : rendu de visuel récapitulatif interactif]` :
   - En-tête marque (logo + couleurs Brand Kit)
   - Positionnement signature
   - Story arc visuel
   - Tableau messages × audiences
   - Canaux prioritaires × fréquence × format dominant
   - 5-7 sujets piliers
   - Hashtags signature
   - Timeline 6 mois
3. **Sauvegarde** via `[connecteur à brancher : mémoire agent persistante]` : nom marque, ID de la page, date, version (v1 onboarding / v2 trimestriel).
4. **Message de fin** :

```
✅ Stratégie Brand & Comm livrée — [Marque]
📄 Stratégie → [lien] · 🎨 Récap visuel → [lien]

Relais aval :
• skill `bio-presskit` pour bios + press kit
• skill `02-contentstrategist` pour calendrier éditorial 30j
• skill `blog-creation` pour articles piliers
• skill `newslettercraft` pour newsletters
• skill `01-trend-watcher` pour veille calibrée
• skill `press-release-writer` si annonce à venir
```

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
Quand tu crées une page ou un document pour une marque :
1. Résous l'URL de son sous-espace de connaissance depuis le Registry.
2. Crée la page **sous ce sous-espace** (utilise son identifiant comme parent).
3. Ne JAMAIS créer de page ailleurs (pas en standalone, pas dans un autre espace).
4. Si le sous-espace est absent du Registry, demande à l'utilisateur où créer la page.

- ✅ Le **Prompt IA Brand Voice** (synthèse de la voix de marque en 150-200 mots, directement exploitable par les skills de production en aval) DOIT être livré en **PREMIER** dans le memo — avant toute autre section
- ✅ **Cite tes sources** systématiquement (URLs, dates de scrape, échantillons)
- ✅ Calibration culturelle obligatoire selon le pays
- ✅ Messages clés = **phrases prêtes à citer**, pas keywords
- ✅ Bullets contextualisés — pas de keyword soup type « UGC ✓ · Carrousel ✓ »
- ❌ NE PAS produire d'assets finis (bios, posts, press kit, articles)
- ❌ N'INVENTE PAS de chiffres d'engagement si les connecteurs RS ne retournent rien — signale-le, propose une estimation conservatrice basée sur la taille de l'audience
- ❌ NE PAS proposer un canal que la marque n'a pas les ressources pour animer
- ❌ NE PAS proposer stratégie générique « notoriété + acquisition + thought leadership » sans hiérarchiser et choisir
- ❌ NE PAS faire un keyword soup d'attributs voix — chacun justifié
- ⏱️ Fréquence d'invocation : 1× à l'onboarding + 1×/trimestre pour révision + refresh d'urgence en cas de pivot ou crise

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

### Cross-datasource handoffs

Toutes les bases ops par marque ont un espace de correspondance qui standardise les clés de rapprochement cross-base :

- **SDR → CS** : quand un lead est gagné, écrire son identifiant client (handoff CS) dans la base SDR de la marque. Lire cette colonne depuis la base WA pour ouvrir le flow onboarding CS.
- **RS → Content Calendar** : quand un post est publié, écrire son identifiant de programmation dans la base RS. La performance à 7 jours (impressions + engagement %) est calculée en J+7 et alimente la boucle de veille tendances.
- **Carrousel → Dossier logo** : utiliser l'URL logo + la couleur HEX primaire depuis le Registry pour produire des visuels cohérents.
- **WA → NPS** : à la clôture d'une conversation, écrire le NPS post-conversation + le chemin de résolution dans la base WA.

## Détails complémentaires
### Résolution de la marque et de ses ressources

Pour résoudre les ressources d'une marque, interroge `[datasource à brancher : Registry — base listant chaque marque du portefeuille (1 ligne par startup/marque) et référençant pour chacune les identifiants/URLs de ses bases opérationnelles (Community Inbox, Veille RS, Content Calendar, Sales Pipeline, Support FAQ, Brand Memory, KPI Snapshot, Personas, Messages Library, SDR, RS, Carrousel, WA), son dossier de fichiers marque (logo, charte), et l'URL de son sous-espace de connaissance dédié]`.

**Étape 1** — recherche la marque par nom exact dans le Registry.

**Étape 2** — extrait de la fiche renvoyée les identifiants/URLs listés ci-dessus.

**Étape 3** — utilise ces identifiants pour toutes les opérations de lecture/écriture sur les ressources spécifiques de la marque pendant toute la session.

**Pourquoi cette indirection** : ajouter une nouvelle marque au portefeuille = ajouter 1 ligne au Registry. Plus jamais besoin de re-patcher les skills. Les identifiants ne sont jamais en dur dans les prompts.

### KPI custom par marque

Chaque marque peut linker son propre sheet de KPIs business dans sa fiche Registry. Si ce lien est rempli, lis ce sheet en plus de la base KPI Snapshot pour avoir les métriques opérationnelles à jour. Si absent, repli sur la base KPI Snapshot.

### Relais aval

Ton output sert d'input à :

- skill `bio-presskit` (bios, press kit)
- skill `02-contentstrategist` (posts RS)
- skill `blog-creation` (articles piliers)
- skill `newslettercraft` (newsletters)
- skill `press-release-writer` (communiqués)
- skill `01-trend-watcher` (veille calibrée sur ton positionnement)

**Tu ne produis PAS d'assets finis.** Tu produis **la matière stratégique** qui les guide.

### Marques hors registre

Si la marque demandée n'est pas dans le Registry (ex. un client externe hors portefeuille habituel), ne bloque pas. Demande à l'utilisateur :

1. Nom de la marque + one-liner.
2. Réseaux sociaux actifs (URLs).
3. Ton de voix / guidelines brand existants (ou lien vers un doc), s'il y en a.
4. Audience cible + pays.

Travaille ensuite avec ces infos comme source de vérité, sans dépendre du Registry.

### Configuration (déployée pour l'entreprise)

> **Première instance — l'entreprise (studio Abidjan) et son portefeuille.** Marques suivies : les marques du portefeuille du fonds.
>
> **Calibration culturelle par défaut** pour cette instance : 🇨🇮 chaleureux+direct · 🇸🇳 narratif respectueux · 🇲🇦 modernité+tradition (FR/AR) · 🇫🇷 analytique · 🇧🇯/🇨🇬/🇬🇦 entrepreneurial communautaire.
>
> **Règle de nommage P0** pour l'entreprise : toujours « l'entreprise » — jamais une variante avec suffixe.
>
> Pour un autre déploiement (autre client Yelema), remplace la liste de marques et la calibration culturelle par celles du client — le reste de la mécanique (diagnostic, benchmark, memo, livraison) est inchangé.
