---
id: Y0055
name: 15-traction-channel
description: "Identifie les 3 canaux d'acquisition prioritaires d'une startup via le Traction Channels Framework (19 canaux, scoring Impact/Coût/Facilité/Timeline) et le Bull's Eye Framework, avec recommandations tactiques ancrées sur les comparables et plan d'action 30 jours."
bucket: C
tags: [Business & Strategy]
version: 1
maj: 2026-09-09
---

# Traction Channel

## Ce qu'il faut avoir sous la main
1. **Ton business en une ligne** → *"Qu'est-ce que tu fais ? Comment ? Pour qui ?"* (ex. *"Plateforme SaaS de gestion de projets avec IA pour PME du secteur tech"*)
2. **2 à 5 entreprises comparables** → tes concurrents ou des modèles inspirants (ex. *"Asana, Monday.com, Notion"*)
3. **Ta géographie cible** → pays/régions visés (ex. *"France, Benelux, puis DACH"*)

Je ne te demande **pas** de business model détaillé, de budget, ni d'objectifs chiffrés, pas nécessaire pour cette analyse.


**Ce qu'elle suppose comme accès** : Corpus indexé de signaux d'embauche/LinkedIn des comparables, Recherche web, Notion (ou équivalent espace de travail client). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
- Identifie le type de produit/service (B2B/B2C, PLG, Sales-led, etc.) à partir du one-liner.
- Analyse les canaux réellement utilisés par les comparables cités, va chercher du concret via [connecteur à brancher : recherche web, benchmarker les stratégies d'acquisition réelles des comparables (articles, case studies, offres d'emploi révélant les priorités growth, interviews fondateurs)]. En complément, si disponible : [datasource à brancher : corpus indexé de signaux d'embauche/LinkedIn des comparables, objective les canaux réellement activés (ex. poste "Growth/SEO" ouvert = signal content/SEO actif, poste "SDR" ouvert = signal sales outbound actif)].
- Considère les spécificités géographiques de la zone cible (maturité du marché, concurrence, sensibilités réglementaires connues).

⚠️ Tout élément chiffré ou toute anecdote citée sur un comparable (« X a converti 15% de ses leads via Y ») doit provenir d'un résultat réel du connecteur de recherche, jamais de la mémoire du modèle. Si rien de vérifiable n'a été trouvé sur un comparable, dis-le et raisonne par analogie sectorielle explicitement signalée comme telle.

### Étape 2 : Évaluation des canaux (Traction Channels)

Pour chaque canal pertinent parmi les **19 canaux standards** (liste en fin de skill, tu n'évalues que ceux pertinents pour le contexte donné, pas nécessairement les 19), évalue selon 4 critères, chacun noté 1-10 :

- **Impact** : potentiel de volume/qualité d'acquisition
- **Coût** : efficacité économique (10 = très économique)
- **Facilité** : rapidité de mise en œuvre et de maîtrise
- **Timeline** : vitesse d'obtention des résultats (10 = immédiat)

**Score Total** = moyenne des 4 critères.

### Étape 3 : Bull's Eye Framework

Classe les canaux évalués en 3 cercles selon leur Score Total :

- 🎯 **Cercle Intérieur** (Inner Ring) : score **≥ 7.0**, TOP 3 canaux à tester en priorité (0-3 mois)
- 🔵 **Cercle Intermédiaire** (Middle Ring) : score **5.0 à 6.9**, 4-6 canaux prometteurs à préparer/considérer (6-12 mois)
- ⚪ **Cercle Extérieur** (Outer Ring) : score **< 5.0**, canaux non prioritaires ou non pertinents

### Étape 4 : Livraison

- Rends toujours l'analyse complète dans la conversation.
- Écris ensuite le playbook d'acquisition (canaux prioritaires, actions, métriques) dans [connecteur à brancher : Notion (ou équivalent espace de travail du client), page dédiée à la startup/l'organisation cliente concernée, sur la plateforme mutualisée Yelema]. Ne prétends jamais l'avoir fait si le connecteur n'est pas branché, dis-le.

## Format de sortie
Livre l'analyse dans cet ordre :

### 📊 Analyse rapide
2-3 phrases : contexte business + insights clés tirés des comparables.

### 🎯 Bull's Eye Framework : visualisation
Un diagramme à 3 cercles concentriques (texte/ASCII) plaçant les canaux Inner/Middle/Outer, avec le score de chaque canal du Cercle Intérieur.

### 📈 Canaux prioritaires : détail & scoring
Un tableau à 7 colonnes, dans cet ordre exact :

| Canal | Impact | Coût | Facilité | Timeline | Score | Rationale |
|-------|--------|------|----------|----------|-------|-----------|

### 💡 Recommandations tactiques
Pour chacun des 3 canaux du Cercle Intérieur : une action immédiate concrète + un exemple réel basé sur un comparable (sourcé, cf. garde-fou anti-invention).

### 🌍 Considérations géographiques
Si plusieurs zones cibles sont données, une sous-section par zone (pas une synthèse générique fusionnée) : spécificités de marché, maturité, concurrence.

### 🎯 Plan d'action : 30 prochains jours
Pour chacun des 3 canaux prioritaires (🥇🥈🥉) :
- **Quick Win (Semaine 1)** : 2 actions concrètes immédiates
- **Setup (Semaine 2-4)** : 2 actions d'infrastructure/configuration

Puis :
- **📊 Métriques à tracker** : 1 métrique par canal + objectif chiffré (présenté comme cible à valider, pas comme un fait acquis, voir garde-fous)
- **⚠️ Ressources minimales requises** : budget estimé (fourchette), temps équipe (h/semaine), compétences clés
- **🔄 Prochain checkpoint** : calcule la **date réelle** à J+30 à partir d'aujourd'hui (jamais un exemple placeholder) + objectif du checkpoint (« avoir testé les 3 canaux et identifier le winner »)

## Règles
- 🎯 **Pragmatisme** : privilégie les canaux actionnables immédiatement avec les ressources limitées d'une startup early-stage.
- 🔎 **Data-informed, pas invention** : base tes recommandations sur ce qui fonctionne réellement pour les comparables (résultats de recherche réels), jamais sur un cas fabriqué qui a l'air plausible.
- 🎯 **Spécificité** : adapte au contexte exact (secteur, stade, géographie), pas de réponse générique copiable d'une startup à l'autre.
- ✂️ **Concision** : va à l'essentiel, évite le jargon superflu.
- ⚡ **Actionnabilité** : chaque recommandation du plan 30 jours doit pouvoir être lancée dans la semaine.
- 📅 **Date réelle** : le prochain checkpoint est toujours calculé à partir de la date du jour, jamais recopié d'un exemple.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle, une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Référence : les 19 Traction Channels

1. Viral Marketing
2. Public Relations (PR)
3. Unconventional PR
4. Search Engine Marketing (SEM)
5. Social & Display Ads
6. Offline Ads
7. Search Engine Optimization (SEO)
8. Content Marketing
9. Email Marketing
10. Engineering as Marketing
11. Target Blogs
12. Business Development
13. Sales
14. Affiliate Programs
15. Existing Platforms
16. Trade Shows
17. Offline Events
18. Speaking Engagements
19. Community Building
