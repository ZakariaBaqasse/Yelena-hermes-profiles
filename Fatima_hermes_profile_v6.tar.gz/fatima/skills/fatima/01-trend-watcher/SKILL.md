---
id: Y0014
name: 01-trend-watcher
description: "Veille tendances réseaux sociaux par plateforme × pays + radar des posts concurrents les plus performants, pour le portefeuille ou une startup ciblée. Sortie : base de veille + briefing + récap visuel."
bucket: D
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# 01_Trend_Watcher

## Ce qu'il faut avoir sous la main
- **périmètre** : tout le portefeuille OU une startup / pays / plateforme précis
- **fenêtre** : par défaut les **7 derniers jours**

Je scanne et je te rends un briefing + la base de veille + un récap visuel. (Pour une startup hors portefeuille : donne-moi nom + one-liner, réseaux actifs, ton/guidelines, audience/pays.)

> Conçu à l'origine pour tourner automatiquement chaque lundi ; ici, **lancé à l'invocation** en mode pull sur la fenêtre demandée.


**Ce qu'elle suppose comme accès** : Registre du portefeuille, Base de veille RS, État d'exécution, Scraping réseaux sociaux, Recherche web, Accès LinkedIn, Rendu de tableau de bord/visuel. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Plateformes : **TikTok, Instagram (Reels + Feed), Facebook, X/Twitter, LinkedIn**. Marchés africains : vérifier séparément **WhatsApp Commerce** (dépasse souvent Instagram en CI). Pays prioritaires : 🇨🇮 · 🇸🇳 · 🇲🇦 · 🇧🇯 · 🇨🇬 · 🇬🇦 · 🇹🇬 · 🇫🇷 (diaspora). Si une startup n'a qu'un canal, ne pas inventer une présence sur les autres. Fenêtre : 7 derniers jours.

### Étape 2 — Capture des tendances par plateforme

`[connecteur à brancher : scraping réseaux sociaux]` (Instagram, Facebook, X — hashtags viraux, sons, posts performants par pays). Pour TikTok, **2 sous-étapes distinctes non substituables** : (1) tendances globales (scraping + sources de trends TikTok, formats/hooks recyclables) ; (2) TikTok natif [pays/secteur] via recherche web `site:tiktok.com [secteur] [ville] [pays]`. `[connecteur à brancher : recherche web]` (Google Trends, actualités, mèmes locaux). `[connecteur à brancher : accès LinkedIn]` (tendances B2B).

Pour chaque plateforme × pays : 5-10 tendances natives (sons, formats POV/before-after/day-in-the-life/thread, hooks) · 10-15 hashtags classés Niche (<10K) / Moyen (10-100K) / Large (>100K) · sujets émergents locaux.

### Étape 3 — Radar concurrents performants

Récupérer 3-5 concurrents directs par startup. Si < 3 en mémoire OU secteur dense (fintech/paiement/e-commerce) → recherche web complémentaire. 🏦 **Règle fintech/paiement CI** : inclure systématiquement Orange Money CI, MTN MoMo CI, Wave CI. Pour chaque concurrent : scraper les 20 derniers posts par canal · identifier les posts surperformants (engagement > 3× la moyenne du compte OU > 1 000 likes/7j pour comptes > 10K) · noter URL, plateforme, format, hook, engagement, pourquoi ça performe · **présence TikTok obligatoire** (Oui/Non/Inconnu + format dominant).

### Étape 4 — Écriture base de veille

Écrire dans `[datasource à brancher : base de veille RS]`. **Ne jamais créer la base en autonomie** : introuvable → STOP + alerter l'opérateur ; base connue mais écriture en erreur → continuer le run, sauver en état d'exécution + alerte technique. ⏱️ **Circuit-breaker** : ne s'active qu'après ≥ 3 recherches (tendances globales + TikTok natif + concurrents) ; si < 5 tendances trouvées alors, synthétiser avec ce qu'on a. **Append uniquement**, jamais réécrire.
Colonnes : Titre · Type (Tendance native/Hook/Hashtag/Post viral concurrent) · Plateforme · Pays · Concurrent (+URL) · URL exemple · Engagement · Audio viral · Pourquoi ça marche · Startups concernées · Idée d'activation · Statut (À utiliser/En cours/Utilisé/Écarté) · Date veille · Semaine ISO.

### Étape 5 — Briefing

« Veille RS — Semaine du JJ/MM au JJ/MM » :
- 🔥 **Top 5 tendances** (tous canaux, par potentiel d'activation) : plateforme · pays · pourquoi ça monte · startups concernées.
- 🎣 **Top 5 hooks à recycler** (avec exemples sourcés).
- 🏷️ **Hashtags du moment** par plateforme (Niche/Moyen/Large).
- 🔍 **Radar concurrent local** : ≥ 3 acteurs locaux · plateforme · **faille exploitable** · avantage pour une startup + posts surperformants (URL/format/hook/engagement/pourquoi).
- 🎯 **5 idées d'activation immédiate** : « @Startup → format X sur canal Y, inspiré de [source] ».
- 📅 **À surveiller la semaine prochaine** (OBLIGATOIRE, ≥ 3 items).

### Étape 6 — Livraison

1. Récap visuel `[connecteur à brancher : rendu de tableau de bord/visuel]` — dashboard filtres (plateforme × pays × startup).
2. Lien base de veille filtré sur la semaine.
3. Message de fin :
```
✅ Veille RS livrée — Semaine du JJ/MM au JJ/MM
📊 Base → [lien] · 🎨 Récap → [lien]
Prochain step : skill ContentStrategist pour transformer ces insights en posts.
```
4. `[datasource à brancher : état d'exécution]` — dernière semaine, périmètre, nouveaux concurrents (nom · secteur · RS actifs · faille).

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ✅ TOUJOURS citer la source (URL) de chaque tendance / post viral.
- ✅ Fenêtre = 7 derniers jours. Comptes < 10K followers → seuil viral 200 likes/7j.
- ✅ Calibration culturelle par pays.
- ❌ N'invente JAMAIS une tendance si le scraping ne retourne rien — signaler + proposer le pays culturellement le plus proche.
- ❌ Pas de post concurrent non surperformant dans le radar.
- ❌ Append uniquement, jamais réécrire une page existante.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
