---
id: Y0395
name: publicite-radio-television
description: "Produit une campagne radio ou télévision prête à diffuser : script du spot dans ses formats réels, brief de production, plan de diffusion par station et créneau, négociation de la grille, dispositif de mesure posé avant le lancement — sans jamais inventer un tarif, une audience ou une couverture."
bucket: B
tags: [Marketing, Média, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Radio et télévision — le média qui parle à ceux qui ne sont pas en ligne

## Ce qu'il faut avoir sous la main
- **Le produit ou le message** à faire passer, et l'objectif de la campagne (notoriété, vente immédiate, recrutement, événement).
- **L'audience visée** : où elle vit, dans quelle langue elle écoute au quotidien, à quel moment tu penses la toucher (trajet, marché, soir à la maison).
- **La zone géographique** — un quartier, une ville, une région, tout le territoire.
- **Ce que tu as déjà** : un budget, des stations déjà envisagées, un précédent spot, une contrainte de secteur (santé, finance, alcool, jeux).
- **Ce que tu attends de moi** : juste le script, ou tout le dossier jusqu'à la négociation.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Reformuler l'objectif et l'audience réelle

Avant d'écrire un mot, fixe ce que la campagne doit produire concrètement : un appel, une visite en boutique, un passage en caisse, une inscription. Un spot qui vise « la notoriété » sans action attendue ne se mesure jamais — pousse vers une action nommée.

Décris ensuite l'auditeur dans sa situation d'écoute réelle : dans un taxi, en préparant le repas, en tenant boutique, dans un salon de coiffure. Cette situation dicte tout ce qui suit — un message qui demande de noter quelque chose échoue si l'auditeur a les mains prises.

### Étape 2 — Écrire pour l'oreille, pas pour l'œil

C'est le piège du métier : rédiger un script qui se lit bien et se dit mal. Une phrase radio se construit courte, avec un seul repère à retenir par passage. Ce qui compte se répète au moins deux fois dans le spot — nom, offre, lieu. Ce qui doit être noté (un numéro, un code) s'épelle lentement, jamais énoncé une seule fois à vitesse normale.

Écris trois formats réels :
- une version courte qui frappe un seul point (l'accroche ou le rappel),
- une version longue qui raconte une situation reconnaissable avant d'arriver au message,
- la mention finale obligatoire quand le secteur ou le format l'impose (conditions, mise en garde, mention légale) — laissée `⟦à renseigner⟧` tant que le texte exact n'est pas fourni par le secteur concerné.

Remplace toute adresse postale ou URL complexe par un repère que l'auditeur possède déjà : un carrefour connu, un marché, un nom de quartier, plutôt qu'un numéro de lot ou un chemin d'accès.

### Étape 3 — Signaler l'adaptation en langue locale, sans la produire

Une part de l'audience visée écoute en dioula, en baoulé, en bété ou dans une autre langue selon la zone — cela dépend entièrement de la zone de chalandise donnée en intake. Un spot traduit mot à mot depuis le français sonne faux et perd l'auditeur en quelques secondes.

Tu ne traduis pas toi-même : tu marques dans le livrable que le script doit être **adapté** (pas traduit) par un locuteur natif de la langue et de la zone visées, avec liberté de reformuler les images et les tournures. Tu listes les langues à couvrir selon la zone donnée, et tu marques `[à confirmer avec l'équipe locale]` si la répartition linguistique de l'audience n'a pas été précisée.

### Étape 4 — Le brief de production

Distingue ce qui se **lit** — une voix off professionnelle qui porte le message principal, choisie pour un ton (autorité, proximité, humour) — de ce qui se **joue** — une scène, un dialogue, des voix de personnages, une ambiance sonore (marché, cour, taxi) qui plante le décor en quelques secondes sans dialogue.

Précise pour la production : le nombre de voix, la langue de chaque voix, l'ambiance ou la musique attendue, la durée exacte de chaque format, et les mentions qui doivent être dites mot pour mot (obligatoires ou négociées avec l'annonceur). Ce brief part chez un studio ou un prestataire local — tu ne produis pas l'audio toi-même.

### Étape 5 — Choisir les stations pour l'audience, pas pour la notoriété

Une radio de proximité en langue locale sur une zone de chalandise précise touche un auditoire fidèle et concentré ; une station nationale en français touche plus large mais plus dilué, et coûte différemment. Le prix ne dit jamais laquelle des deux sert l'objectif fixé à l'étape 1 — seule l'audience réellement atteinte le dit.

Pour chaque station envisagée, documente : la zone de couverture réelle, la ou les langues de diffusion, le profil d'auditeur qu'elle revendique, et le créneau proposé (trajet du matin, pause de midi, soirée à la maison) en fonction de la situation d'écoute décrite à l'étape 1. Toute donnée d'audience, de couverture ou de part de marché citée doit venir de la station, de la régie ou d'un institut de mesure et être marquée comme telle — jamais estimée.

### Étape 6 — Préparer la négociation de la grille

Une grille tarifaire se négocie, elle ne se subit pas. Prépare les leviers à faire valoir : le volume de passages sur la durée de la campagne, la durée d'engagement proposée, le positionnement dans la grille (créneau de forte écoute contre créneau creux), et tout échange de visibilité possible (mention croisée, jeu-concours, présence à un événement de la station).

Documente ce qui a été obtenu une fois la négociation menée par l'entreprise — tarif, nombre de passages, créneaux fixés — sans jamais estimer ce chiffre à l'avance : la négociation elle-même est une action humaine, tu la prépares, tu ne la mènes pas.

### Étape 7 — Poser le dispositif de mesure avant l'achat

C'est le troisième piège : acheter de l'espace sans savoir ensuite ce qu'il a rapporté. Une campagne radio sans numéro dédié, sans code à mentionner en boutique ou en caisse, et sans consigne donnée à l'accueil ou au vendeur ne se mesure pas — elle sera coupée au premier arbitrage budgétaire faute de preuve.

Avant tout lancement, fixe : un numéro dédié à la campagne (y compris un numéro mobile money ou un canal WhatsApp si l'action attendue est un contact), un code ou un mot à mentionner pour identifier l'origine de l'appel ou de la visite, et la consigne donnée à quiconque reçoit ce contact pour qu'il soit compté. Cette instrumentation se décide avant l'achat d'espace, jamais après.

### Étape 8 — Lister les vérifications réglementaires, sans inventer la règle

Certains secteurs (santé, finance, alcool, jeux d'argent, produits pour enfants) sont encadrés dans ce qu'ils peuvent dire en publicité, et la diffusion audiovisuelle relève d'une autorité de régulation du secteur de la communication audiovisuelle à identifier selon le pays de diffusion. Tu ne cites ni règle ni interdiction précise de mémoire : tu listes les points à faire vérifier (mentions obligatoires, horaires autorisés, public visé) et tu nommes l'interlocuteur à consulter avant diffusion — l'autorité de régulation compétente, ou le service juridique de l'annonceur.

## Format de sortie
- **Livrable** : dossier de campagne — script du spot dans ses formats (court, long, mention finale), brief de production, plan de diffusion par station et créneau avec justification d'audience, points de négociation, dispositif de mesure, liste des vérifications réglementaires avec interlocuteur nommé.
- **Structure** : Markdown clair — answer-first (le script et le plan de diffusion d'abord, le détail ensuite) ; tableaux pour le plan station/créneau et pour la grille de négociation.
- **Longueur** : proportionnée à la demande, sans remplissage. Un dossier complet tient en quelques pages ; un script seul tient en une demi-page par format.
- **Toute donnée d'audience, de tarif ou de couverture** citée est marquée comme fournie par la station, la régie ou une source vérifiée — jamais comme une estimation de la compétence.
- **Règle 0 invention** : aucun tarif, aucune audience, aucune part de marché, aucune règle réglementaire chiffrée n'est produite sans être fournie ou sourcée. `⟦à renseigner⟧` sinon.

## Règles
1. **On écrit pour l'oreille, pas pour l'œil.** Un script qui se lit bien à l'écran et se dit mal à l'antenne est un script à refaire. Ce qui compte se répète, ce qui doit être noté s'épelle, l'adresse devient un repère connu.
2. **La langue n'est pas un détail.** Toute adaptation en langue locale est signalée comme nécessaire et confiée à un locuteur natif — jamais traduite littéralement, jamais produite par la compétence elle-même.
3. **Le choix de station répond à l'audience, pas au prestige.** Une station se choisit pour la zone, la langue et le profil qu'elle touche réellement, pas pour son nom ou son tarif seul.
4. **0 chiffre inventé.** Aucun tarif, aucune audience, aucun coût pour mille, aucune part de marché n'est produit sans être fourni par l'entreprise ou sourcé par un lien vérifié. `⟦à renseigner⟧` sinon.
5. **La mesure se décide avant l'achat.** Numéro dédié, code à mentionner, consigne à l'accueil : sans ces trois éléments posés avant diffusion, la campagne ne se défendra pas au bilan.
6. **Les obligations réglementaires se vérifient, ne se devinent pas.** Tu nommes l'autorité ou l'interlocuteur à consulter, tu ne cites jamais une règle, un article ou une interdiction précise de mémoire.
7. **Le contexte local n'est pas un décor.** Situation d'écoute réelle, langues effectivement parlées dans la zone, moyens de contact réellement accessibles (mobile money, WhatsApp, numéro fixe en boutique) : un dispositif pensé pour un public tout connecté ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter une station, réserver un créneau, valider une adaptation en langue locale ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une campagne ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Répartition linguistique de l'audience inconnue** — tu produis le script en français, tu signales explicitement la ou les langues probables selon la zone donnée, et tu marques la nécessité d'une adaptation native avant diffusion.
- **Secteur réglementé annoncé** (santé, finance, alcool, jeux) — tu listes les points à vérifier et tu nommes l'interlocuteur à consulter, tu ne rends jamais un script prêt à diffuser sans ce garde-fou signalé.
- **Tarifs ou audiences annoncés mais non fournis** (« la station dit qu'elle touche tout le monde ») — tu marques la donnée comme non sourcée et tu demandes le chiffre réel de la station ou de la régie.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné.
- **Campagne déjà diffusée** (une première vague existe) — tu t'appuies sur les résultats mesurés de cette vague plutôt que sur des hypothèses d'audience, et tu le dis.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (plan média digital, budget marketing global, identité de marque).
- **Action sortante demandée** (réservation d'un créneau, envoi du script à une station, paiement d'un acompte) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux stations annoncent la même zone de couverture) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
