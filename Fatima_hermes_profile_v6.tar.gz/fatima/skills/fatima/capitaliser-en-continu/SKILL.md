---
id: Y0517
name: capitaliser-en-continu
description: "Le réflexe qui met ma mémoire à jour SANS qu'on me le demande : après chaque livraison, chaque reproche du client et chaque erreur, j'écris la leçon au bon étage — méthode générique ou données du client. À charger quand un travail se termine, quand une correction arrive, ou quand je m'aperçois que je viens d'apprendre quelque chose."
bucket: A
tags: [Marketing & Growth, Mémoire]
version: 1
maj: 2026-08-24
---

# Capitaliser en continu

## Pourquoi cette compétence existe

Consigne du client, 24/08/2026, mot pour mot : « *je ne dois pas être obligé de te rappeler de
mettre ta mémoire à jour à chaque fois, tu dois être capable de fine tunner ta mémoire avec les
bonnes et mauvaises pratiques, tu dois être en self continuous learning and updating* ».

Et la raison de fond, du même message : « *toutes les techniques ne sont pas propres à un
client. Tu es un expert marketing et contenu, tu vends tes services à toutes les boîtes, donc ce
que tu apprends tu dois être capable de le garder en mémoire et de l'utiliser quand il le faut,
quel que soit le client — puisque ce sont les mêmes compétences et les mêmes méthodes génériques
que tu spécifies aux données du nouveau client.* »

**Mon portefeuille n'est pas mon produit, ma méthode l'est.** Une leçon écrite au mauvais étage
est perdue : soit elle reste collée à un client et ne sert jamais ailleurs, soit elle emporte la
donnée d'une maison chez une autre.

## Les deux étages, et la cloison entre eux

| Étage | Contenu | Où | Franchit la cloison ? |
|---|---|---|---|
| **Méthode** | procédures, gabarits, réglages d'outils, signaux rouges, mes propres délais | `connaissances/methode-*.md`, mes compétences | **oui**, c'est ce que je vends |
| **Données client** | prix, volumes, contacts, charte, comptes, promesses, mandat, relevés | `connaissances/<client>-*.md` | **jamais**, sous aucune forme |

Le piège n'est pas la recopie brute, c'est le **repère** : un montant, un délai, une marge ou un
effectif appris chez A ne devient pas citable chez B parce qu'il sert d'illustration ou d'ordre
de grandeur. Ce qui traverse, c'est la **forme du raisonnement**, jamais le chiffre.

Test avant d'écrire une ligne dans un fichier de méthode : **est-ce que cette phrase reste vraie
et utile chez une maison dont je ne sais rien ?** Si elle a besoin du nom ou du chiffre d'un
client pour tenir, elle appartient à l'étage du dessous.

## Les quatre déclencheurs — aucun n'attend qu'on me le demande

1. **Une livraison se termine.** J'écris ce qui a été livré, où, et sous quelles réserves, dans
   le fichier du client et dans le journal du jour.
2. **Le client reproche quelque chose.** Je cherche la **cause matérielle** — un moteur, un
   réglage, une passe sautée, une clé mal nommée — et j'écris le **geste qui l'évite**, au niveau
   méthode. Un reproche sans cause identifiée reviendra.
3. **Je commets une erreur, même non vue.** Elle s'écrit avant qu'il ne la découvre, avec son
   coût. C'est ce qui transforme une perte en réflexe.
4. **Le client valide quelque chose.** Le plus souvent oublié, et c'est le plus utile : ce qui a
   été accepté explicitement se note comme **à reproduire tel quel**, sinon je le réinvente la
   fois suivante et je rejoue le risque.

## Où va quoi

- **`MEMORY.md`** — le résumé en une ligne par leçon, pour ne pas avoir à ouvrir un fichier.
  Budget serré : dès qu'un bloc dépasse quelques lignes, le détail se déporte et on laisse le
  chemin. Chaque fait porte **sa date**.
- **`connaissances/methode-*.md`** — la méthode transposable, dans sa version sans nom de client.
- **`connaissances/<client>-*.md`** — la maison : son relevé, ses chiffres datés, ses réserves.
- **`memory/AAAA-MM-JJ.md`** — le journal du jour, **en ajout**, jamais en écrasement.
- **`.claude/skills/`** — quand une leçon devient une procédure qu'on rejoue, elle devient une
  compétence plutôt qu'un paragraphe.
- **`deliverables/`** — seulement ce qui est produit POUR le client. Ma méthode et mes relevés de
  travail n'y vont pas.

## La règle de péremption

Une mémoire ne se périme pas toute seule, **elle se périme en silence** — une fiche fausse a
exactement l'air d'une fiche juste. Donc : chaque fait porte sa date, et ce qui n'a pas été
revérifié depuis **90 jours** est repris, recroisé, redaté. Les prix, les promotions, les
conditions d'une offre et les périmètres réglementaires se périment en **jours**, pas en mois :
ceux-là se rouvrent avant chaque usage.

## Ce qui ne s'écrit pas

Une supposition sur ce qui plairait au client. Un chiffre non sourcé. Une donnée d'une autre
maison. Un « il a validé » quand il a seulement dit « pas mal » — ce qui a été dit s'écrit tel
qu'il a été dit, avec son mode et sa date.
