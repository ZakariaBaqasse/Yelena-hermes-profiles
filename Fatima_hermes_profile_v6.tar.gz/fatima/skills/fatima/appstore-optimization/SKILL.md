---
id: Y0078
name: appstore-optimization
description: "Génère les métadonnées ASO d'une application mobile (titre, sous-titre, description longue, mots-clés) optimisées pour le ranking et la conversion sur l'App Store et Google Play, avec analyse KEI et 3 variantes validées à chaque étape."
bucket: C
tags: [Design]
version: 1
maj: 2026-09-09
---

# ASO : Optimisation App Store & Google Play

## Ce qu'il faut avoir sous la main
- **Nom de la startup / application**
- **One-liner**, que fait l'app en une phrase (*ex. "Plateforme de gestion tout-en-un pour restaurateurs"*)
- **Cible utilisateur**, à qui s'adresse l'app (*ex. "Propriétaires de restaurants et food trucks en Côte d'Ivoire"*)
- (optionnel) **Site internet**, **2-3 applications comparables**, **3-5 fonctionnalités clés**

### Résolution du contexte startup (si applicable)

Si l'app appartient à une startup/un client déjà suivi, résous son contexte avant de démarrer via `[datasource à brancher : registre des startups/clients (Notion ou équivalent), pour chaque entité, mémoire de marque (positionnement, ton de voix, cible), emplacement où livrer le document]`. Si un corpus produit existe pour cette entité (`[datasource à brancher : dataroom ou corpus produit de l'entreprise, pitch deck, customer discovery, verbatims utilisateurs]`), utilise-le pour ancrer la description longue (Étape 4) sur des bénéfices et une preuve sociale réels plutôt que génériques.

Si aucune de ces sources n'est branchée ou ne renvoie rien pour l'entité demandée, continue avec les seules informations fournies par l'utilisateur (Étape 1), ne jamais inventer de positionnement, de ton de voix ou de témoignage pour combler le manque.


**Ce qu'elle suppose comme accès** : Registre des startups/clients, Corpus produit / dataroom de la startup, Recherche web. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Objectif : rassembler le contexte nécessaire pour générer du contenu ASO pertinent.

**Informations requises :**
- **Nom de la startup / application** (critique)
- **One-liner** (critique), que fait l'app en une phrase
- **Cible utilisateur** (critique), à qui s'adresse l'app
- **Site internet** (optionnel), permet d'analyser le positionnement existant
- **Applications comparables** (optionnel, 2-3 exemples), benchmark concurrentiel pour identifier les mots-clés performants
- **Fonctionnalités clés** (optionnel, 3-5), affine la description et identifie des mots-clés fonctionnels

**Comportement :**
- Présenter brièvement l'objectif : optimiser la visibilité et le taux de conversion sur les stores.
- Demander les informations progressivement si elles n'arrivent pas toutes d'un coup (ne pas submerger).
- Si des infos optionnelles manquent, proposer de continuer avec ce qui est disponible et d'affiner ensuite.

### Étape 2 : Titre de l'application

**Contraintes techniques :** 30 caractères maximum, App Store et Google Play.

**Bonnes pratiques :**
- Format recommandé : **[Nom de marque] : [Mot-clé principal à fort volume]**.
- Le titre est le facteur de ranking n°1 → y placer le mot-clé au meilleur KEI (voir Étape 5 pour le calcul).
- Éviter les mots génériques faibles ("app", "application", "mobile").

**Méthode :**
1. Analyser les mots-clés pertinents pour la catégorie d'application.
2. Identifier le mot-clé avec le meilleur équilibre Volume/Difficulté (KEI élevé).
3. Construire 3 variantes : orientée problème (**[Marque] : [Action/Bénéfice]**), orientée métier (**[Marque] : [Catégorie/Cible]**), orientée solution (**[Marque] : [Outil/Plateforme]**).
4. Présenter les 3 options avec analyse du potentiel de chacune.
5. Valider avec l'utilisateur avant de passer au sous-titre.

**Format de réponse :**
```
### 🏆 PROPOSITION DE TITRE

**Option 1** (Recommandée) : [TITRE]
- **Longueur** : X/30 caractères
- **Mot-clé principal** : [KEYWORD] (Volume : X, Difficulté : X, KEI : X)
- **Rationale** : [Explication du choix]

**Option 2** : [TITRE]
[Structure identique]

**Option 3** : [TITRE]
[Structure identique]

💬 Quelle option préférez-vous ? Ou souhaitez-vous que j'explore d'autres directions ?
```

### Étape 3 : Sous-titres

**Contraintes techniques :**
- App Store, champ *Subtitle* : 30 caractères maximum, impact ranking moyen-élevé.
- Google Play, champ *Short Description* : 80 caractères maximum, impact ranking moyen.

**Bonnes pratiques :**
- Expliquer ce que fait l'app en incluant le maximum de mots-clés pertinents.
- Se rappeler qu'il s'agit d'une startup dans les propositions.
- Compléter le titre avec des mots-clés secondaires à fort potentiel.
- Privilégier la clarté et la valeur ajoutée immédiate.

**Méthode :**
1. Identifier 5-8 mots-clés secondaires pertinents (KEI élevé, non utilisés dans le titre).
2. Construire 3 variantes pour CHAQUE store (les contraintes diffèrent).
3. Optimiser la densité de mots-clés sans sacrifier la fluidité.
4. Valider la conformité aux limites de caractères.

**Format de réponse :**
```
### 📌 PROPOSITION DE SOUS-TITRES

#### 🍎 APP STORE (30 caractères max)
**Option 1** : [SOUS-TITRE]
- **Longueur** : X/30 caractères
- **Mots-clés intégrés** : [KW1], [KW2], [KW3]
- **Rationale** : [Explication]
**Option 2 / 3** : [Structure identique]

#### 🤖 GOOGLE PLAY (80 caractères max)
**Option 1** : [SHORT DESCRIPTION]
- **Longueur** : X/80 caractères
- **Mots-clés intégrés** : [Liste étendue]
- **Rationale** : [Explication]
**Option 2 / 3** : [Structure identique]

💬 Validez vos choix ou demandez des ajustements !
```

### Étape 4 : Description longue

**Contraintes techniques :**
- App Store : 4000 caractères maximum, impact ranking faible mais impact fort sur la conversion. L'App Store a aussi un champ Keywords invisible (100 caractères, voir Étape 5) pour le ranking.
- Google Play : 4000 caractères maximum, impact ranking élevé (3e facteur de ranking après titre et short description).

**Bonnes pratiques :**
- Intégrer naturellement un maximum de mots-clés pertinents (densité optimale : 2-3% par mot-clé majeur).
- Structurer en sections claires avec émojis pour faciliter la lecture.
- Inclure : problème résolu, fonctionnalités clés, bénéfices utilisateurs, appel à l'action.
- Pour Google Play : saturer davantage en mots-clés (ranking direct).
- Pour App Store : privilégier la conversion (le ranking mots-clés se fait via le champ invisible de l'Étape 5).

**Structure recommandée (5 paragraphes) :**
1. **Hook**, présenter la valeur ajoutée unique et le problème résolu.
2. **Fonctionnalités**, lister 3-5 fonctionnalités clés avec bénéfices associés.
3. **Différenciation**, ce qui rend l'app unique vs concurrents.
4. **Social proof / public cible**, pour qui c'est conçu, témoignages **si fournis par l'utilisateur ou présents dans une datasource branchée** ; sinon, omettre ce sous-bloc plutôt que d'en inventer un.
5. **Call-to-action**, invitation à télécharger et essayer.

**Méthode :**
1. Lister 15-20 mots-clés pertinents avec leur KEI.
2. Rédiger une version App Store (focus conversion + lisibilité).
3. Rédiger une version Google Play (focus ranking + densité mots-clés).
4. Calculer la densité des mots-clés principaux.
5. Optimiser pour atteindre 2-3% de densité sur les top mots-clés.
6. Présenter les deux versions avec analyse.

**Format de réponse :**
```
### 📝 DESCRIPTION LONGUE

#### 🍎 VERSION APP STORE (Focus Conversion)
[TEXTE COMPLET DE LA DESCRIPTION]
**📊 Analyse :**
- **Longueur** : X/4000 caractères
- **Densité mots-clés principaux** : [Keyword 1] X% (Y occ.) · [Keyword 2] X% (Y occ.) · [Keyword 3] X% (Y occ.)

#### 🤖 VERSION GOOGLE PLAY (Focus Ranking)
[TEXTE COMPLET DE LA DESCRIPTION - Version optimisée SEO]
**📊 Analyse :** [Structure identique]

💬 Ces descriptions vous conviennent-elles ou souhaitez-vous ajuster le ton / mettre en avant d'autres fonctionnalités ?
```

### Étape 5 : Mots-clés (App Store uniquement)

**Contraintes techniques :** champ *Keywords* invisible pour les utilisateurs (utilisé uniquement par l'algorithme), 100 caractères maximum, impact très élevé sur le ranking App Store.

**Bonnes pratiques :**
- Ne PAS répéter les mots déjà présents dans le titre ou le sous-titre (Apple les indexe automatiquement).
- Utiliser des virgules pour séparer, sans espaces inutiles.
- Privilégier les singuliers (Apple génère les pluriels automatiquement).
- Ne pas inclure le nom de la marque/app.
- Maximiser le KEI : mots-clés à fort volume et faible difficulté.

**Méthode :**
1. Brainstormer une liste de 30-50 mots-clés pertinents via l'analyse de la concurrence, les suggestions automatiques des stores, un `[connecteur à brancher : outil de recherche de mots-clés, type AppTweak, Google Keyword Planner]` si disponible, les problèmes résolus par l'app, les synonymes et termes associés.
2. Calculer le KEI pour chaque mot-clé : **KEI = Volume de recherche² / Difficulté**.
3. Éliminer les mots-clés déjà présents dans Titre + Sous-titre.
4. Sélectionner les 15-20 meilleurs mots-clés par KEI.
5. Optimiser pour tenir en 100 caractères.
6. Présenter la liste finale avec tableau d'analyse.

**Format de réponse :**
```
### 🔑 KEYWORDS APP STORE (100 caractères max)

**Liste optimisée :**
keyword1,keyword2,keyword3,keyword4,keyword5,keyword6,keyword7,keyword8,keyword9,keyword10

**Longueur** : X/100 caractères

**📊 Tableau d'analyse :**
| Keyword | Volume | Difficulté | KEI | Rationale |
|---|---|---|---|---|
| [KW1] | X | X | X | [Pourquoi inclus] |

**🔄 Keywords écartés :**
- [Keyword X] : Déjà dans le titre
- [Keyword Y] : KEI trop faible (difficulté élevée)

💬 Souhaitez-vous que j'explore d'autres pistes de mots-clés ?
```

### Étape 6 : Recommandations complémentaires

- **Screenshots**, impact majeur sur la conversion (40%+ selon les études). Montrer la value proposition, les fonctionnalités clés et le bénéfice utilisateur avec du texte overlay. 5-8 screenshots par store.
- **Icône**, premier élément visuel vu par l'utilisateur. Simple, reconnaissable, reflet de la catégorie d'app. Tester 2 versions (A/B) et mesurer l'impact après 1 mois minimum.
- **Reviews & ratings**, facteur de ranking + preuve sociale. Demander un avis après un "happy moment" dans l'app. Objectif : maintenir une note > 4.5.
- **Optimisation continue**, revoir les métadonnées tous les 3 mois (optimisation trimestrielle). Métriques à suivre : visiteurs de la fiche store, taux de conversion, positions de ranking des mots-clés, téléchargements organiques. Outils recommandés : console App Store Connect, console Google Play, outil ASO type AppTweak.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
1. **Collecter en un seul message** les informations critiques (nom, one-liner, cible) avant de démarrer ; si les infos optionnelles (site, comparables, fonctionnalités) manquent, continuer avec ce qui est disponible et proposer de les affiner ensuite.
2. **Respecter strictement les contraintes de caractères** par store et par champ (titre 30/30 · sous-titre App Store 30 / short description Google Play 80 · description longue 4000/4000 · keywords App Store 100) et **toujours afficher la longueur X/limite** de chaque proposition.
3. **Produire systématiquement 3 variantes** par champ généré (titre, sous-titres) avec le rationale de chacune, et **valider avec l'utilisateur avant de passer à l'étape suivante**, jamais imposer une seule option sans validation.
4. **Ancrer chaque mot-clé sur une analyse explicite** (Volume, Difficulté, KEI = Volume² / Difficulté) et sur le contexte réel de l'app (one-liner, cible, comparables) ; si le volume/la difficulté d'un mot-clé n'est pas mesuré via un outil réel de recherche de mots-clés, le signaler comme **estimation**, jamais comme une donnée exacte mesurée.
5. **Ne jamais inventer de contenu produit** : fonctionnalités, bénéfices, preuve sociale (témoignages, métriques de satisfaction) ou applications comparables utilisés dans les livrables doivent venir des inputs utilisateur ou d'une datasource branchée, jamais fabriqués pour combler un paragraphe ou une liste vide.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Concurrents inconnus**, l'utilisateur ne connaît pas ses concurrents : proposer une recherche via `[connecteur à brancher : recherche web]` basée sur la catégorie et le marché cible, suggérer 3-5 apps similaires réellement identifiées (jamais inventées) sur les stores, offrir d'analyser leurs metadata pour en extraire des insights mots-clés.
- **Contrainte de branding forte**, le nom de la startup est très long ou ne contient pas de mots-clés : privilégier le format "[NomMarque] - [Mot-clé]" avec tiret pour gagner de l'espace, proposer une abréviation si pertinente, compenser dans le sous-titre avec des mots-clés forts.
- **Multi-fonctionnalités**, l'app fait beaucoup de choses différentes (risque de dilution mots-clés) : identifier la fonctionnalité CORE la plus recherchée, construire le titre/sous-titre autour de cette fonction principale, mentionner les fonctions secondaires dans la description.
- **Demande d'ajustement**, l'utilisateur n'est pas satisfait d'une proposition : demander précisément ce qui ne convient pas (ton, mots-clés, structure, longueur), proposer 2-3 alternatives ajustées, expliquer les trade-offs (ex. « si on retire ce mot-clé, on perd en potentiel de ranking mais on gagne en clarté »).

## Détails complémentaires
### Livraison

Une fois les quatre blocs validés (titre, sous-titres, description, mots-clés) :

1. Livre l'ensemble en réponse chat.
2. Pour enregistrer le livrable dans l'espace de la startup/du client : résous l'emplacement de destination via `[datasource à brancher : registre des startups/clients, résout l'emplacement (sub-hub/espace dédié) où livrer le document par entité]`.
3. Crée le document **sous cet espace dédié**, jamais en standalone, jamais dans l'espace d'une autre entité.
4. Si cet emplacement n'est pas résolu (registre absent ou entité non trouvée), demande explicitement à l'utilisateur où enregistrer le document plutôt que de le placer par défaut ailleurs.
