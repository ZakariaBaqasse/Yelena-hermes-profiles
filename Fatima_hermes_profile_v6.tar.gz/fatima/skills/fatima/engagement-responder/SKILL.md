---
id: Y0148
name: engagement-responder
description: "Community management INBOUND des startups : détecte les commentaires/réactions/mentions reçus sur leurs propres posts, drafts des réponses dans le ton exact de chaque marque, fait valider par un humain, publie et journalise."
bucket: C
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# Engagement Responder

## Ce qu'il faut avoir sous la main
1. La **marque/startup** concernée ;
2. Le **mode** : scan hebdo (tous les posts récents) ou ciblé (un post/canal précis — donne l'URL) ;
3. *(si tu l'as sous la main)* le **brand kit** de la marque, si je ne l'ai pas déjà en mémoire.


**Ce qu'elle suppose comme accès** : Registre des marques/startups, Community Inbox DB, Brand Memory DB, Messages Library DB, Personas DB, Support FAQ DB, Sales Pipeline DB, RS DB. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Deux modes :

### Mode scan (batch hebdo)

Pour chaque marque du portefeuille suivi :

1. **Récupère les posts récents** (7 derniers jours) via `[connecteur à brancher : outil de programmation multi-canal (type Buffer) — liste des posts déjà publiés]` + `[connecteur à brancher : recherche/lecture LinkedIn (type Unipile) — engagement LinkedIn]` + `[connecteur à brancher : scraping social (type Apify) — engagement IG/FB/TikTok/X]`.
2. **Scrape les commentaires** sur chaque post.
3. **Filtre** : ne garde que les commentaires sans réponse de la marque.
4. **Classe** par priorité :
   - 🔴 **Urgent** : question client, plainte, bug report, prospect chaud.
   - 🟡 **Important** : compliment à remercier, question secteur, tag d'un influenceur.
   - 🟢 **Nice-to-have** : emoji seul, commentaire générique, spam.

### Mode ciblé

Si l'utilisateur donne une URL de post ou un canal spécifique, restreins le scan à celui-ci.

### Étape 2 — Chargement du contexte brand

Avant de rédiger, charge :

1. `[datasource à brancher : Brand Memory DB]` → ton de voix, vocabulaire signature, taboos, persona fondateur.
2. `[datasource à brancher : Messages Library DB]` → patterns de réponses déjà validés par le passé.
3. `[datasource à brancher : Personas DB]` → qui est l'audience type (pour adapter le registre de langue).
4. `[datasource à brancher : Support FAQ DB]` → si le commentaire est une question, vérifier si la réponse existe déjà.

### Étape 3 — Draft des réponses

Pour chaque commentaire filtré, génère un draft de réponse.

### Règles de rédaction

- **Ton** : calquer exactement la voix de la marque (Brand Memory). Pas de ton générique — chaque marque a SA voix.
- **Longueur** : commentaire = réponse courte (1-3 phrases max). DM = réponse plus développée si nécessaire.
- **Personnalisation** : utiliser le prénom du commentateur quand visible. Référencer le contenu spécifique du commentaire.
- **CTA discret** : si pertinent, orienter vers le site/app/démo sans être pushy.
- **Pas de promesse** : ne jamais engager la marque sur un délai, un prix ou une feature non confirmée.
- **Langue** : répondre dans la langue du commentaire (FR/EN/autre).

### Format de livraison par commentaire

```
📱 [Marque] — [Canal] — [Post titre/extrait]
💬 Commentaire de @[pseudo] : « [texte] »
🏷️ Priorité : 🔴/🟡/🟢
✍️ Draft réponse : « [réponse proposée] »
📋 Source ton : [référence Brand Memory]
```

### Étape 4 — Validation humaine

**Règle absolue : JAMAIS de publication sans validation.**

Présente tous les drafts groupés par marque, par priorité décroissante. L'utilisateur peut :

- ✅ Valider tel quel
- ✏️ Modifier puis valider
- ❌ Rejeter (avec raison → log pour améliorer les futurs drafts)

### Étape 5 — Publication & log

Pour chaque réponse validée :

1. **Publie** via `[connecteur à brancher : réseau social concerné — LinkedIn type Unipile pour LinkedIn, scraping/action social type Apify pour IG/FB/TikTok/X — publication de la réponse]`.
2. **Log dans** `[datasource à brancher : Community Inbox DB (Notion ou équivalent) — journal des réponses publiées par marque]` :
   - Date/heure réponse
   - Canal + URL post
   - Commentaire original
   - Réponse publiée
   - Statut : ✅ Publié
   - Auteur : « Engagement Responder + [validateur] »
3. **Mets à jour** `[datasource à brancher : RS DB (tableur de suivi RS) — compteur d'interactions par post]`.

### Étape 6 — Insights post-engagement

Après chaque run, génère un mini-brief :

- Nombre de commentaires traités par marque.
- % questions vs compliments vs plaintes.
- Sujets récurrents → à remonter à `[skill à brancher : 01-trend-watcher]` et `[skill à brancher : 02-contentstrategist]` comme idées de contenu.
- Commentateurs fréquents → à flaguer comme ambassadeurs potentiels dans `[datasource à brancher : Sales Pipeline DB]`.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ✅ TOUJOURS charger le Brand Memory avant de rédiger.
- ✅ TOUJOURS soumettre pour validation avant publication.
- ✅ Logger chaque interaction dans la Community Inbox DB.
- ✅ Répondre dans la langue du commentaire.
- ❌ JAMAIS publier sans validation humaine.
- ❌ JAMAIS promettre un délai, un prix ou une feature.
- ❌ JAMAIS répondre à du spam ou des trolls (ignorer + log).
- ⏱️ Fréquence : 2-3× par semaine ou à la demande.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution de la startup et de ses bases

Avant de collecter l'engagement, résous le contexte de la marque demandée :

1. Identifie la marque/startup concernée.
2. Récupère ses bases de référence via `[datasource à brancher : registre des marques/startups (Notion ou équivalent) — pour chaque marque, résout les emplacements de : Community Inbox DB, Brand Memory DB, Messages Library DB, Personas DB, Support FAQ DB, Sales Pipeline DB, RS DB (tableur de suivi)]`.
3. Si ces bases ont déjà été chargées plus tôt dans la conversation (ex. par une étape précédente d'un pipeline de contenu), réutilise-les directement plutôt que de re-requêter.

### Marques hors registre

Si la marque demandée n'est pas dans le registre, demande : nom, réseaux sociaux actifs (URLs), ton de voix, audience cible + pays. Travaille ensuite avec ces infos comme source de vérité.

### Handoffs

- **Commentaire = question support** → escalade à `[skill à brancher : 03-helpdoc-generator]` si la réponse n'est pas dans la FAQ, ou renvoie directement vers le lien FAQ existant.
- **Commentaire = prospect chaud** (demande de démo, prix, partenariat) → flag dans `[datasource à brancher : Sales Pipeline DB]` + alerte `[skill à brancher : conversion-tracker]`.
- **Commentateur récurrent positif** → suggérer à l'utilisateur de l'ajouter comme ambassadeur.
- **Insights contenu** → feed `[skill à brancher : 01-trend-watcher]` et `[skill à brancher : 02-contentstrategist]` avec les sujets qui génèrent le plus d'engagement.

### Configuration (déployée pour l'entreprise)

> **Première instance — l'entreprise (le programme) et son portefeuille.** Marques suivies : les marques du portefeuille du client.
>
> « l'entreprise » jamais « l'entreprise Ventures ».
>
> Pour un autre déploiement (autre client Yelema), remplace la liste de marques par celle du client — le reste de la mécanique (collecte, ton par marque, validation, log) est inchangé.
