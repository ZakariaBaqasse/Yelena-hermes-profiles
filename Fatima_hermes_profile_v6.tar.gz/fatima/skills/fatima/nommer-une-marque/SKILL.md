---
id: Y0567
name: nommer-une-marque
description: "Trouver un nom de marque et prouver qu'il est disponible — sens relevé au dictionnaire et jamais de mémoire, graphie justifiée par la prononciation, contrôle des domaines par RDAP, et le test témoin qui empêche de livrer un faux « libre ». À charger dès qu'un client cherche un nom, un renommage, une gamme à nommer, ou demande si un nom est libre."
bucket: A
tags: [Marketing & Growth, Marque]
version: 1
maj: 2026-09-04
---

# Nommer une marque, et prouver que le nom est libre

**La méthode complète, avec les chiffres sourcés et les pièges chiffrés :
`connaissances/methode-nommage-et-disponibilite.md`.** Cette compétence est la version courte,
celle qui doit tenir sous les yeux pendant le travail.

## L'ordre des gestes

1. **Le prix d'abord.** Un sac à 25 000 F et un sac à 250 000 F ne portent pas le même nom. Sans
   la fourchette de prix, je ne propose pas de nom : je demande la fourchette, en options
   lettrées.
2. **Relever, jamais se souvenir.** Chaque mot en langue étrangère porte, dans le livrable, le
   lien du dictionnaire où je l'ai lu. Un mot sans entrée lisible va dans un bloc
   « non proposés — aucun sens affirmé ».
3. **Ne pas composer.** Assembler deux mots vérifiés ne donne pas un mot vérifié. Un composé sort
   seulement si un locuteur de la maison confirme qu'il existe et se dit.
4. **La graphie se justifie par la prononciation notée**, et s'annonce comme *notre* orthographe,
   pas comme une entrée de dictionnaire.
5. **Vérifier avant de recommander**, avec la route qui marche pour de vrai (ci-dessous).
6. **Livrer des noms vérifiables, jamais « validés ».** Le dépôt appartient au juriste et à
   l'office.

## Le contrôle de disponibilité, ce qui marche depuis ce poste

```bash
# état d'un domaine au registre : 200 = pris (status + date de création dans le JSON),
# 404 = absent du registre. Gratuit.
curl -sL -o /tmp/r.json -w "%{http_code}\n" https://rdap.org/domain/<domaine>
```

🚨 **Avant de croire un test, le passer sur un cas dont je connais la réponse.** Deux faux
positifs attrapés ainsi, qui auraient été livrés comme des résultats :

- **`.ci`** — pas de RDAP public au registre ivoirien : tout `.ci` répond `404`, donc « libre ».
  Témoin : `orange.ci` ressort « libre ». **Aucun résultat `.ci` par cette route.**
- **Instagram** — `instagram.com/<pseudo>` répond `200` pour tout, y compris un pseudonyme
  inventé. **Un `200` ne prouve pas qu'un compte existe.**

Ce que je livre alors : le résultat pour ce qui est réellement vérifiable, et **l'angle mort écrit
en clair**. Un faux « libre » se paie au dépôt, pas à la livraison.

## Le livrable

Un tableau — en **image** si le client lit sur un téléphone, en tableur s'il doit voter et
compter — avec, par nom : le **sens relevé** et son lien, le **compte de syllabes**, et **ce que
le nom apporte et ce qu'il coûte** en une ligne. Puis deux blocs qui font la crédibilité du
premier : **écartés après vérification** avec la raison, et **non proposés faute de source**.

Le vote se pondère (1 = 3 points, 2 = 2, 3 = 1) et la règle est écrite sur le document, sinon
chacun vote dans un barème différent.

## L'amorçage, en questions fermées

Des questions **à lettres**, auxquelles on répond « 1B 2A 3C » depuis un téléphone ; le **prix en
première** ; et un **seuil de démarrage** annoncé (« si tu ne réponds qu'aux trois premières, je
démarre »).

🚨 **Avant d'envoyer le questionnaire, relire ce que la maison a déjà dit** et ne garder que ce
qui est ouvert. Un questionnaire impeccable qui redemande le déjà-dit fait retravailler le client
et annule le bénéfice de la mémoire — c'est la faute qui a coûté un reproche le 28/08/2026.


## 🚨 Quand le client insiste sur le logo (leçon du 04/09/2026)

Le logo, la charte et les déclinaisons sont le métier de **Koffi**. Cette limite compte comme un
refus et ne devient pas négociable sous l'insistance : sinon elle ne vaut rien, puisque tout client
insiste une fois.

Mais la répéter deux fois sans rien faire avancer rend l'Expert inutile. La progression juste :

1. **Première demande** : nommer Koffi, et livrer ce qui EST de mon métier — le brief de création,
   et les **directions de signe** rédigées avec leur coût. « Ce que le logo doit raconter » est de
   la plateforme de marque ; « le tracé » ne l'est pas.
2. **Deuxième insistance** : on arrête d'expliquer la frontière. On livre le **message prêt à
   coller** dans le fil du bon Expert, en bloc de code, contenant tout ce qu'il lui faut (cadrage,
   directions, contraintes techniques, réserves juridiques et réglementaires).
3. **Poster soi-même dans le fil d'un autre** ne se fait **jamais sans feu vert explicite** : on le
   propose en une ligne, on attend.

⚠️ Et si le client dit que la marque **vend déjà**, ce n'est pas une création de logo mais une
**refonte** : il existe une identité que des clientes reconnaissent, et un logo neuf leur coûte
cette reconnaissance. Photos de ce qui sert aujourd'hui, puis arbitrage « garder le fil » ou
« repartir à zéro », avant qu'un trait soit posé.
