---
name: referentiel-local
description: >
  Les corpus de référence du poste, constitués à partir de données ivoiriennes réelles et
  vérifiées, et non de souvenirs ou d'exemples importés. À charger avant tout conseil de présence sur les réseaux, tout calendrier éditorial et toute promesse de résultat,
  et chaque fois qu'une recommandation gagnerait à s'appuyer sur ce qui se pratique
  réellement en Côte d'Ivoire plutôt que sur une norme générale.
version: 1
maj: 2026-09-06
---

# Référentiel local — marketing et contenu

Ces fichiers vivent dans le poste. Ils ont été établis à partir de collectes datées, dont
la méthode et les limites sont écrites en tête de chaque document.

### `memory/reference/reseaux-marques-ci.md`

Ce que publient vraiment les grandes marques ivoiriennes — **132 publications mesurées le
06/09/2026** sur onze comptes : sept marques ivoiriennes, plus Wave, un grand groupe
agroalimentaire, Unilever monde et Unilever Nigeria.

**Quand le lire** : avant de conseiller une cadence de publication, de promettre une
audience, de composer une légende ou de choisir des mots-dièse.

**Le chiffre à ne jamais oublier** : sur dix des onze comptes, le taux d'interaction est
inférieur à 0,2 % des abonnés. Un objectif exprimé en nombre d'abonnés n'engage à rien.

**La règle de citation** : je donne le taux, pas le nombre brut. « 34 mentions pour 102 409
abonnés, soit 0,03 % » se discute ; « 34 mentions » ne se discute pas.

## Comment m'en servir

**Je les lis avant de recommander, pas après.** Un conseil aligné sur une norme générale se
repère immédiatement chez un client ivoirien, et il coûte la crédibilité de tout le reste.

**Je cite le chiffre et sa date.** « Sur 4 136 offres relevées en août 2026 » vaut mieux que
« généralement ». Le chiffre daté se vérifie ; le « généralement » ne se vérifie pas.

**Je ne dépasse pas ce que le corpus couvre.** Chaque document porte une section sur ce
qu'il ne dit pas. Quand la question tombe dans cet angle mort, je le dis et je cherche
ailleurs plutôt que d'extrapoler.

**Ils vieillissent.** Chaque document indique la commande qui le rafraîchit. Un chiffre de
plus de trois mois s'annonce comme tel.
