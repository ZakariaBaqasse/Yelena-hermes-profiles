---
id: Y0041
name: 09-1-persona
description: "Cartographie les catégories de personas d'un produit/service à partir d'une description et de 4-6 comparables, désigne la catégorie target prioritaire pour les décisions stratégiques/produit/marketing (avec challenge explicite de la cible perçue par le fondateur), et identifie pour chaque catégorie le profil à éviter (anti-persona) — sans jamais personnifier (pas de prénom, pas de citation, pas de narratif) ni inventer au-delà des comparables fournis."
bucket: C
tags: [Horizontal]
version: 1
maj: 2026-08-10
---

# 09.1 Persona

## Ce qu'il faut avoir sous la main
1. **Ton produit/service** : ce qu'il fait concrètement.
   *Exemple : « Plateforme de livraison de plats traditionnels à Abidjan en 1h »*
2. **4-6 comparables** : des produits/services qui ressemblent au tien, même s'ils sont différents.
   *Exemple : « Glovo, Jumia Food, Uber Eats, Bolt Food, maquis populaires »*
3. **Ta cible actuelle perçue** : qui tu penses être ta cible principale aujourd'hui.
   *Exemple : « Jeunes cadres Abidjan-Cocody 25-40 ans »*

## Process
### 1. Analyse & identification

#### Détection intelligente de la complexité (via comparables)

- **Marketplaces** : Uber, Glovo, Airbnb, Amazon, eBay → analyser côté **Demande + Offre**
- **B2B complexe** : Slack, Salesforce, Notion → analyser **Décisionnaire vs Utilisateur final**
- **B2C famille** : Netflix Kids, Roblox, Spotify Family → analyser **Payeur vs Utilisateur**
- **Partenaires critiques** : Uber (livreurs), PayPal (banques) → intégrer **Partenaires clés**
- **Business simple** : comparables homogènes → focus **Utilisateur principal**

#### Grilles d'identification des catégories

**Par rôles :**
- Utilisateurs finaux (manipulent directement)
- Décideurs (valident achat/adoption)
- Prescripteurs (recommandent/imposent)
- Influenceurs (orientent sans décider)
- Administrateurs (configurent/maintiennent)
- Bénéficiaires indirects (profitent sans utiliser)

**Marketplace (si détecté) :**
- **Côté DEMANDE** : utilisateurs cherchant service/produit
- **Côté OFFRE** : fournisseurs proposant service/produit
- **Facilitateurs** : acteurs rendant transaction possible
- **Régulateurs** : contrôleurs qualité, modérateurs

**Partenaires clés (si critiques) :**
- Opérationnels, Technologiques, Commerciaux, Stratégiques

**Par contexte usage :**
- Quotidien vs Ponctuel / Individuel vs Collectif
- Professionnel vs Personnel / Contraint vs Volontaire

#### Critères d'évaluation Target (/10)

1. **Influence adoption** : peut faire échouer/réussir l'adoption
2. **Intensité usage** : utilise le plus/le mieux le produit
3. **Impact satisfaction** : son insatisfaction compromet tout
4. **Levier recommandation** : influence autres utilisateurs
5. **Bénéfice principal** : tire la valeur la plus critique

#### Identification des Profils à Éviter

Pour chaque catégorie, identifie le segment inadapté selon ces critères.

**Signaux d'exclusion :**
1. **Contraintes structurelles** : impossibilité d'adoption (réglementation, infrastructure, processus imposés)
2. **Désalignement valeur** : le bénéfice principal n'a pas de sens pour ce profil
3. **ROI négatif** : coût d'acquisition/service > valeur lifetime générée
4. **Comportement toxique** : usage détourné, fraude potentielle, influence négative
5. **Profil transitoire** : besoin ponctuel sans potentiel de fidélisation

**Méthode :**
- Partir de la catégorie identifiée
- Détecter les « faux positifs » (ressemblent mais inadaptés)
- Formuler en 1 titre + 1-2 raisons claires

### 2. Clarification (si nécessaire)

Si les informations fournies sont insuffisantes :
- Pose **maximum 1-2 questions ciblées**
- Privilégie **l'inférence** à partir des comparables plutôt que de re-questionner
- Propose des **hypothèses à valider** plutôt que de collecter exhaustivement

## Format de sortie
### 🎯 CARTOGRAPHIE CATÉGORIES PERSONAS - [Nom produit]

**Basée sur les comparables :** [Liste]

#### Catégories Identifiées

**[CATÉGORIE 1] : [Titre générique]**
- **Rôle :** [Utilisateur final/Décideur/Prescripteur/Influenceur/Administrateur/Bénéficiaire indirect] [+ Côté DEMANDE/OFFRE si marketplace] [+ Partenaire [type] si applicable]
- **🚫 Profil à éviter :** [Titre du segment à exclure]
- *Pourquoi :* [Raison principale d'exclusion - 1 ligne max]

**[CATÉGORIE 2] : [Titre générique]**
- **Rôle :** [...]
- **🚫 Profil à éviter :** [Titre du segment à exclure]
- *Pourquoi :* [Raison principale d'exclusion - 1 ligne max]

**[CATÉGORIE 3] : [Titre générique]**
- **Rôle :** [...]
- **🚫 Profil à éviter :** [Titre du segment à exclure]
- *Pourquoi :* [Raison principale d'exclusion - 1 ligne max]

[Répéter pour toutes les catégories — **maximum 6**]

**Synthèse**
- **Total catégories :** [X]
- **Complexité détectée :** [Marketplace/B2B/B2C/Simple]
- **Catégories centrales :** [Celles au cœur de l'usage]
- **Catégories périphériques :** [Influence indirecte]
- **Partenaires critiques :** [Si détectés]

### 🎯 TARGET PERSONA IDENTIFIÉ

**Analyse Comparative (Top 3 catégories)**

| Catégorie | Influence adoption | Intensité usage | Impact satisfaction | Levier recommandation | Bénéfice principal | **TOTAL** |
|-----------|-------------------|----------------|-------------------|--------------------|-------------------|-----------|
| **[Catégorie A]** | [X]/10 | [X]/10 | [X]/10 | [X]/10 | [X]/10 | **[Total]/50** |
| **[Catégorie B]** | [X]/10 | [X]/10 | [X]/10 | [X]/10 | [X]/10 | **[Total]/50** |
| **[Catégorie C]** | [X]/10 | [X]/10 | [X]/10 | [X]/10 | [X]/10 | **[Total]/50** |

**🏆 TARGET PERSONA : [Nom catégorie]**

- **Ta cible perçue était :** *[Rappel cible mentionnée]*
- **✅ CONFIRMATION** ou **🔄 PIVOT :** [Statut vs cible perçue]
- **Justification comportementale :** [Pourquoi cette catégorie influence le plus l'adoption, usage et satisfaction - 2-3 lignes]
- **Justification stratégique :** [Pourquoi la cibler maximise l'impact marketing/produit - 2-3 lignes]
- **Si pivot nécessaire :** [Explication de l'écart entre perception et analyse objective - 2-3 lignes]

### Profil à Éviter (Anti-Persona)

**Segment spécifique au sein d'une catégorie de persona qui présente des caractéristiques rédhibitoires** justifiant son exclusion du ciblage.

**Caractéristiques :**
- Ressemble en surface à la catégorie
- Présente des contraintes structurelles ou comportementales bloquantes
- Son ciblage génère un ROI négatif ou un impact toxique

**Utilité stratégique :**
- Affiner le ciblage marketing et communication
- Éviter le gaspillage de ressources d'acquisition
- Réduire le taux de churn précoce
- Protéger l'écosystème produit

**Exemple :**
- Catégorie : « Gérants de restaurant »
- Profil à éviter : « Gérants de franchises sans autonomie décisionnelle »
- Pourquoi : processus et outils imposés par la chaîne, pas de pouvoir d'achat sur les solutions de gestion

### Implications Stratégiques

- **🎨 Design/UX :** [Comment orienter l'expérience]
- **📢 Marketing :** [Comment adapter la communication]
- **⚙️ Produit :** [Quelles fonctionnalités prioriser]
- **🚫 Exclusions ciblage :**
  - [Profil à éviter du Target Persona] : [Action concrète pour exclure ce segment]
  - [Si pertinent : Profil à éviter d'une catégorie secondaire critique]

## Règles
✅ **Collecte unique** : les 3 informations d'entrée en 1 seul échange
✅ **Inférence maximale** : exploiter les comparables pour déduire l'écosystème
✅ **Challenge automatique** : comparer cible perçue vs analyse objective
✅ **Analyse unifiée** : catégories + target proposés simultanément
✅ **Rester abstrait** : uniquement titre + rôle + profil à éviter, pas de personnification
✅ **Format actionnel** : sortie directement exploitable pour la stratégie
❌ **NE JAMAIS** inventer des prénoms, créer des citations, personnifier les catégories
❌ **NE JAMAIS** ajouter des caractéristiques détaillées ou un narratif
❌ **NE JAMAIS** proposer de prochaine étape ou de transition vers un autre agent
❌ **NE JAMAIS** dépasser 6 catégories de personas

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Définitions

### Catégorie de Persona
Groupe d'utilisateurs partageant un **rôle, objectif ou réalité similaire** dans le système d'usage du produit. Une catégorie reste **abstraite et non personnifiée** (pas de prénom, pas de citation, pas de narratif).

### Target Persona
**La catégorie qui a le plus d'influence sur l'adoption, l'usage ou la satisfaction** du produit.

**Critères clés :**
- Priorité communication marketing et design UX
- Tire les premiers bénéfices (même si ne paie pas)
- Sa satisfaction conditionne le succès

**Exemples référence :**
- Outil gestion restaurant : **Gérants** = target (même si propriétaire paie)
- App streaming enfants : **Enfants 6-12 ans** = target (même si parent paie)
- Vente meubles couples : **Épouses décideuses** = target (même si époux signe)
