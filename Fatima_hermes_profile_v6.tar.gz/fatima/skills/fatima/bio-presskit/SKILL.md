---
id: Y0084
name: bio-presskit
description: "Bios pro, press kits complets et pitchs élévateur pour une personne ou une entreprise — finis, prêts à diffuser, FR + EN si demandé."
bucket: C
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# Bio & Press Kit

## Ce qu'il faut avoir sous la main
1. **Sujet** : une personne (nom, fonction, parcours) ou une entreprise (nom, mission, traction, équipe)
2. **Type de livrable** souhaité — bio courte/moyenne/longue, press kit complet, assets conférence (voir le menu ci-dessous si tu hésites)
3. **Langue(s)** : FR, EN, ou les deux
4. **Ton souhaité** : analytique · narratif · inspirant · institutionnel · entrepreneurial
5. **Contexte d'usage** : LinkedIn, site web, conférence, pitch deck, presse, partenariats
6. Si une note de positionnement / stratégie de communication existe déjà pour ce sujet, dis-le-moi — je la prends comme matière première


**Ce qu'elle suppose comme accès** : Base profil sujets, Base branding par sujet, Notes internes / retours d'expérience / convictions, Stockage de fichiers, Espace documentaire des notes de positionnement / stratégie de comm, LinkedIn, Recherche web, Traitement de texte partagé. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
- Charge le **profil du sujet** (historique, contacts, financements/traction) depuis [datasource à brancher : base profil sujets (Notion/CRM interne) — fiche par personne ou entreprise avec historique, contacts, financements/traction, tenue à jour].
- Charge la **charte de marque du sujet** (couleurs HEX, typographies, logo, tagline) depuis [datasource à brancher : base branding par sujet — identité visuelle si le sujet est une entreprise établie].
- Si aucune des deux sources n'a d'entrée pour ce sujet, demande directement au client : qui est le sujet, sa fonction/mission, sa traction/son parcours.

### Étape 1 — Inputs requis

- Sujet : personne (nom, fonction, parcours) OU entreprise (nom, mission, traction, équipe)
- Type de livrable demandé (cf. menu §2)
- Langues : FR / EN / les deux
- Ton souhaité : analytique · narratif · inspirant · institutionnel · entrepreneurial
- Contexte d'usage : LinkedIn · site web · conférence · pitch deck · presse · partenariats
- Si une stratégie de comm/note de positionnement existe déjà pour ce sujet → va la chercher dans [datasource à brancher : espace documentaire où sont rangées les notes de positionnement / stratégie de comm produites en amont, si ce travail existe]

### Étape 2 — Menu de livrables

📝 **Bios personne** :

- **Bio courte** (1 phrase, 200 caractères max) — pour signature email, intervention conférence
- **Bio moyenne** (50-80 mots) — pour LinkedIn « À propos », bio podcast
- **Bio longue** (150-250 mots) — pour press kit, page équipe site, programme événement
- **Pitch élévateur** (30 secondes parlé, 60-80 mots) — pour intro réseau
- **Bio narrative** (300-500 mots) — pour interviews longues, profils presse

🏢 **Press kit entreprise complet** :

- **Boilerplate** (50-100 mots, FR + EN) — à la fin de chaque communiqué de presse
- **Fact sheet** : fondation, fondateurs, mission, produit, traction (KPIs), levée, marchés, équipe — 1 page max
- **FAQ presse** : 10-15 Q/R standards (qui, quoi, pourquoi, comment, combien)
- **Bios fondateurs** (moyenne ou longue selon contexte)
- **Photos HD** : portraits fondateurs + logo + captures produit
- **Citations clés** : 5-7 phrases prêtes à citer par les journalistes
- **Coordonnées presse** : email + téléphone du responsable communication

🎤 **Assets conférence** :

- Bio speaker (50 + 150 mots)
- Titre d'intervention + abstract (2 versions A/B)
- Photo HD recommandée
- 3 lignes pour l'annonce LinkedIn de l'événement

### Étape 3 — Production

1. **Lance les recherches sources** AVANT de rédiger :
   - [connecteur à brancher : LinkedIn — recherche du profil de la personne ou de l'entreprise]
   - Site web officiel du sujet
   - [connecteur à brancher : recherche web — articles de presse existants sur le sujet]
   - [datasource à brancher : notes internes / retours d'expérience / convictions sur le sujet (Notion ou équivalent)]
   - [datasource à brancher : Drive — photos HD, charte graphique, fact sheets déjà produits pour ce sujet]
   - Si une note de positionnement existe (cf. Étape 0/1) → la charger en priorité (positionnement, messages clés, ton déjà calibré)
2. **Calibre le ton** au marché/pays visé (adapte longueur, vocabulaire, registre culturel — un ton chaleureux et direct ne convient pas au même contexte qu'un ton institutionnel et analytique ; ajuste selon la géographie et l'audience indiquées par le client).
3. **Rédige tous les livrables demandés en une fois** (pas par groupes).
4. **FR + EN** : si bilingue demandé, traduis en garantissant l'équivalence stylistique (jamais une traduction littérale).

### Étape 4 — Livraison

1. Produit le livrable dans [connecteur à brancher : traitement de texte partagé (Google Docs ou équivalent) — un document dédié par sujet], structuré :
   - H1 : `Bio & Press Kit — [Sujet]`
   - H2 par livrable (Bio courte, Bio moyenne, Press kit, etc.)
   - Versions FR et EN dans des H3 séparés
   - Range le document dans l'espace dédié à ce sujet, jamais en vrac
2. **Photos HD** : [connecteur à brancher : stockage de fichiers (Google Drive ou équivalent) — copier dans un dossier dédié au sujet, ou pointer vers les originaux]
3. **Media kit web léger** (optionnel) : si l'outil est disponible, génère une page simple type media kit (bios + photos + citations + coordonnées) via [connecteur à brancher : générateur de page web simple, si disponible]
4. **Message de fin** :

> ✅ Press kit livré — [Sujet]
> 📄 Document → [lien] · 🖼️ Photos HD → [dossier] · 🎨 Media kit web → [lien si généré]
> Si le positionnement évolue, redemande une note de comm à jour, puis reviens pour rafraîchir les bios.

5. Garde une trace du sujet traité, du lien du livrable et de la date de dernière mise à jour dans [connecteur à brancher : tracker de suivi des livrables (sheet ou base), optionnel] — pour pouvoir le retrouver et le rafraîchir plus tard.

## Format de sortie
- **Livrable** : Bios pro, press kits complets et pitchs élévateur pour une personne ou une entreprise — finis, prêts à diffuser, FR + EN si demandé.
- **Structure** : Markdown clair — titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] » — jamais présentée comme réelle.

## Règles
- ✅ TOUJOURS confirmer les chiffres (traction, levée, équipe) avec la source (LinkedIn / site officiel / note de positionnement) — pas d'invention.
- ✅ FR + EN équivalents en qualité — pas de traduction littérale.
- ✅ Bio courte respecte 200 caractères STRICTS · moyenne 50-80 mots · longue 150-250 mots · narrative 300-500 mots.
- ✅ Boilerplate FR + EN à chaque press kit.
- ❌ NE PAS faire de stratégie/positionnement — hors scope, c'est un travail en amont.
- ❌ NE PAS écrire de posts LinkedIn ou de newsletter — hors scope (relève d'un travail de création de contenu dédié).
- ❌ NE PAS produire de communiqué de presse complet — hors scope (relève d'un outil/travail presse dédié, à créer ou à faire réaliser par un humain).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
