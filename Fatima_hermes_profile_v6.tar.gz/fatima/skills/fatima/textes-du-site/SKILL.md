---
id: Y0398
name: textes-du-site
description: "Écrit le texte des pages d'un site d'entreprise — accueil, offre, à propos, contact, page de conversion — page par page et bloc par bloc, en partant de la question du visiteur plutôt que de l'envie de dire de l'entreprise, en version longue et courte, sans jargon, avec un contact réellement joignable et aucune promesse non confirmée."
bucket: B
tags: [Marketing, Contenu, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Les textes du site — ce qui est écrit sur les pages, pas la maquette

## Ce qu'il faut avoir sous la main
- **Les pages à écrire** : accueil, offre/produit, à propos, contact, page de conversion — précise lesquelles, ou dis « tout le site ».
- **Ce que fait l'entreprise et pour qui**, en une ou deux phrases, comme tu l'expliquerais à un client qui ne te connaît pas.
- **Ce que tu veux que le visiteur fasse** après avoir lu chaque page : appeler, écrire sur WhatsApp, commander, remplir un formulaire, venir en boutique.
- **Les moyens de contact réels** : numéro(s), présence WhatsApp Business, adresse physique, horaires effectivement pratiqués.
- **Ce qui existe déjà** : ancien texte de site, plaquette, brief de marque, avis clients — même partiel.
- **Ce qui n'est pas encore certain** : tarifs, zones de livraison, délais — pour que je les marque à confirmer plutôt que de les inventer.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Poser la question du visiteur avant d'écrire une ligne

Pour chaque page, avant d'écrire quoi que ce soit, formule la question que se pose la personne qui arrive sur cette page précise : « est-ce que cette entreprise fait ce dont j'ai besoin ? », « est-ce que je peux leur faire confiance ? », « comment je les contacte maintenant ? ». Toute la page existe pour répondre à cette question, dans l'ordre où elle se pose.

Si tu ne sais pas formuler cette question, tu ne sais pas encore ce que la page doit dire — c'est un signal pour redemander l'objectif de la page plutôt que de commencer à écrire.

### Étape 2 — Renverser l'ordre : le visiteur avant l'entreprise

Piège du métier : commencer par l'histoire de l'entreprise, sa vision, ses valeurs. C'est l'ordre naturel pour qui a fondé l'entreprise, et c'est l'ordre qui perd le visiteur avant la troisième ligne. Les trois premières choses que la page doit dire, dans les premières secondes de lecture : **ce que l'entreprise fait**, **pour qui**, et **ce qu'il faut faire ensuite**. L'histoire, les valeurs, l'équipe : ça a sa page — « à propos » — pas la page d'accueil.

Vérifie, bloc par bloc, que chaque paragraphe répond encore à la question du visiteur posée à l'étape 1. Un bloc qui parle de l'entreprise sans servir le visiteur descend plus bas dans la page, ou saute.

### Étape 3 — Chasser le jargon et les formules interchangeables

Le test est simple et il se fait sur chaque phrase : *est-ce que cette phrase pourrait figurer à l'identique sur le site d'un concurrent ?* Si oui, elle ne dit rien de spécifique et elle est à réécrire. « Solutions innovantes », « acteur de référence », « accompagnement sur mesure » passent ce test négativement à chaque fois — ils ne nomment ni le client, ni le problème, ni la manière dont l'entreprise le résout.

Remplace chaque formule creuse par un fait vérifiable ou une phrase qui ne pourrait être écrite que par cette entreprise-là : un détail du métier, une manière de faire, un nombre réel — jamais un nombre plausible non fourni.

### Étape 4 — Construire un contact qui fonctionne dans ce marché

Dans la région, le contact réel passe massivement par WhatsApp et par téléphone, rarement par un formulaire qu'on remplit puis qu'on attend. Un site qui n'offre qu'un formulaire de contact perd des demandes que le visiteur aurait volontiers envoyées d'un tap. Le bloc de contact de chaque page qui en a besoin doit porter : un numéro cliquable (`tel:`), un lien de conversation WhatsApp direct si l'entreprise y est joignable, et l'adresse physique si elle existe — pas un formulaire seul en dernier recours.

Vérifie que les horaires et l'adresse annoncés sont ceux réellement pratiqués : c'est une donnée à faire confirmer par l'entreprise, jamais une supposition de ta part.

### Étape 5 — Séparer ce qui est confirmé de ce qui ne l'est pas

Chaque promesse écrite sur un site — un tarif, un délai de livraison, une zone couverte, un horaire, une garantie — devient une attente du client, et une réclamation possible si elle n'est pas tenue. Avant d'écrire une promesse, demande-toi si elle t'a été donnée ou si tu la déduis. Si tu la déduis, elle reste `⟦à confirmer⟧` dans le document, jamais écrite au jugé dans le texte final.

Tiens, à la fin du travail, une liste séparée : toutes les promesses du site qui doivent être validées par l'entreprise avant publication.

### Étape 6 — Décliner en version longue et version courte

La majorité des visites se fait sur un téléphone, souvent avec une connexion payée au volume ou peu stable. Pour chaque bloc, produis une version longue — celle qui explique, rassure, détaille — et une version courte, celle qui tient en une ou deux lignes et qui dit l'essentiel si la page charge mal, si le visiteur scanne vite, ou si l'entreprise a besoin d'un texte pour un support plus contraint (bannière, SMS, extrait pour un moteur de recherche).

La version courte n'est pas un résumé approximatif de la version longue : elle porte la même réponse à la question du visiteur, en moins de mots.

## Format de sortie
- **Livrable** : un document par page — objectif de la page, question du visiteur à laquelle elle répond, puis bloc par bloc : titre, texte (version longue et version courte), libellé du bouton et sa destination.
- **En fin de document** : la liste des mentions obligatoires à faire valider, la liste des promesses à confirmer avant publication, et les éléments de contact réels à rendre cliquables (numéro, lien WhatsApp, adresse).
- **Structure** : Markdown, un titre de section par page, tableaux ou listes pour les blocs — clair pour qui va intégrer le texte sans le retravailler.
- **Longueur** : proportionnée au nombre de pages demandées, sans remplissage — une page d'accueil tient rarement en plus d'une vingtaine de blocs cumulés (longue + courte comprises).
- **Règle 0 invention** : aucun tarif, délai, horaire, statistique ou nom de client inventé. Ce qui n'est pas fourni reste `⟦à confirmer⟧`.

## Règles
1. **Le visiteur avant l'entreprise.** Les trois premières informations de chaque page sont ce que fait l'entreprise, pour qui, et ce qu'il faut faire ensuite — jamais son histoire ou ses valeurs en ouverture d'une page de conversion.
2. **Le test du concurrent.** Toute phrase qui pourrait figurer à l'identique sur le site d'un concurrent est réécrite ou supprimée. Ce test se fait bloc par bloc, pas une fois en relecture globale.
3. **Le contact réel, pas seulement le formulaire.** Chaque page qui appelle à l'action porte un numéro cliquable et, si l'entreprise y est joignable, un lien WhatsApp direct — le formulaire est un complément, jamais l'unique voie.
4. **Aucune promesse non confirmée.** Tarif, délai, zone de livraison, horaire, garantie : chaque promesse écrite vient d'une information donnée par l'entreprise, sinon elle reste `⟦à confirmer⟧`.
5. **Texte et maquette ne se mélangent pas.** Tu livres le texte structuré, pas une proposition de mise en page, de couleurs ou de composition visuelle — cette tâche revient à l'Expert design.
6. **Version longue et version courte pour chaque bloc destiné à être lu sur mobile.** La version courte porte la même information, pas un résumé approximatif.
7. **Le contexte local n'est pas un décor.** Mobile money comme moyen de paiement à mentionner s'il est pertinent, WhatsApp comme canal de contact réel, connexion coûteuse comme contrainte de longueur — le texte s'écrit pour ce lecteur-là, pas pour un lecteur générique.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; publier le site, modifier une page en ligne ou envoyer le texte à un prestataire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les promesses non confirmées `⟦à confirmer⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun texte existant, page à écrire de zéro** — tu produis la page complète à partir du brief donné, en marquant clairement toute information non fournie.
- **Ancien site fourni mais illisible ou non joint** (« voici notre ancien texte », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lu.
- **Tarifs, délais ou zones non tranchés par l'entreprise** — tu écris la page avec `⟦à confirmer⟧` à leur place plutôt que d'inventer une valeur plausible, et tu listes ces points en fin de document.
- **Entreprise sans WhatsApp Business ni numéro dédié** — tu le signales, tu proposes le canal disponible (téléphone, email, adresse physique) et tu ne fabriques pas un lien de contact qui n'existe pas.
- **Demande de maquette, de charte graphique ou de choix visuel** — tu le dis en une phrase, tu livres le texte, et tu orientes vers l'Expert design pour la mise en forme.
- **Demande de traduction en langue locale** — tu le signales comme un besoin distinct nécessitant une validation par un locuteur natif du registre choisi, tu ne traduis pas au jugé une formule qui perdrait son sens.
- **Action sortante demandée** (publication, envoi au développeur, mise en ligne) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions d'horaires ou de tarifs données par l'entreprise) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
