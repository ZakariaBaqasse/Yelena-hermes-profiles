---
id: Y0527
name: competitor-campaign-benchmark
description: "Veille des campagnes marketing/com des concurrents (local → panafricain → international) : angles, formats, messages, timing → benchmark structuré + idées à reprendre."
bucket: A
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Competitor Campaign Benchmark

## Ce qu'il faut avoir sous la main
- Obligatoires : liste des marques concurrentes, marchés/pays, période à couvrir.
- Optionnelles : canaux prioritaires (LinkedIn, Meta, TikTok, presse, affichage, TV/radio…), objectif de la veille (inspiration créative / positionnement / part de voix), langue.
- Si une obligatoire manque → demander uniquement ce qui manque, en une fois.


**Ce qu'elle suppose comme accès** : Génération de visuel interactif (Frame), LinkedIn. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. Pour chaque marque × marché, recenser les campagnes actives/récentes sur la période.
2. Décrire chacune : angle, message clé, format, canal, timing, cible, signaux de performance visibles (engagement, reprises presse).
3. Repérer les patterns (angles, formats, temps forts) du local à l'international.
4. En tirer des idées transposables pour la marque du client.

## Format de sortie

Termine TOUJOURS ta réponse par un **Frame interactif** (visualisation / interactive content) qui présente le livrable de façon soignée et lisible — aux couleurs du brand kit si fourni, sinon une palette neutre et pro. Le message texte reste un court wrapper ; le livrable vit dans le Frame. Si la génération de visualisation n'est pas disponible, produis à défaut un livrable structuré prêt à l'emploi (ne bloque jamais là-dessus).

## Règles

- Zéro invention : chaque campagne, chiffre ou visuel décrit repose sur une source réelle (post, page, presse, pub observée) avec lien/source. Une info non vérifiée → « à confirmer ». Pas de campagne inventée.
- Générique : concurrents, marchés et période viennent des entrées — aucun client codé en dur.
- Veille de CAMPAGNES (pas de veille produit/marché générale) : angle créatif, message, format, canal, timing, cible.
- Validation humaine : les idées à reprendre sont des pistes à valider.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

Pour une liste de marques concurrentes, des marchés et une période, produire un benchmark structuré de leurs campagnes (angles, formats, messages, timing) + des idées actionnables à reprendre.

## Outils attendus
- web_search / navigation (pages, presse, réseaux, ad libraries) — bindés côté client.

## Sortie
1. **Tableau de veille** : Marque | Marché | Campagne | Angle | Message | Format/Canal | Timing | Source | Signaux perf.
2. **Insights** — patterns par niveau (local / régional / panafricain / international).
3. **Idées à reprendre** — 3-5 pistes concrètes, priorisées.
