---
id: Y0085
name: blog-creation
description: "Génère 5 articles de blog thought leadership différenciés (800-1000 mots chacun) pour une startup, ancrés sur son site web, sa cible et ses comparables, avec ordre de publication recommandé et argumenté."
bucket: C
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# Blog Creation

## Ce qu'il faut avoir sous la main
1. **Nom de la startup**
2. **Site web** (URL) — je l'analyse pour positionnement, ton, différenciateurs
3. **One-liner** — description en une phrase
4. **Cible** — persona + secteur (B2B/B2C) + niveau d'expertise (ex. « CTO B2B experts », « CMO B2C niveau intermédiaire »)
5. **4-6 comparables** — concurrents ou leaders du secteur

Si la startup est déjà connue (portefeuille), je résous automatiquement nom, site, one-liner, cible et comparables via `[datasource à brancher]` et te les confirme avant de continuer.

## Process
1. **Crawler le site web** via `[connecteur à brancher : recherche web — analyser positionnement, solutions, ton de marque, différenciateurs, problématiques clients]`. Si le site n'est pas accessible, signale-le et demande un résumé à l'utilisateur.
2. **Étudier les comparables** via ce même connecteur : standards éditoriaux du secteur + opportunités de différenciation.
3. **Calibrer la cible** : niveau technique, vocabulaire, exemples, ton.

### Étape 2 — Structure éditoriale (5 angles obligatoires, non redondants)

Génère exactement ces 5 angles dans cet ordre :

1. **Tendance de marché** — analyse d'une tendance clé du secteur (data + chiffres), startup positionnée comme acteur de ce changement. Angle : prospectif.
2. **Cas d'usage client** — scénario détaillé ou histoire client (avant/après, ROI mesurable). Si pas de cas réel disponible (via l'utilisateur ou la datasource), demande avant de rédiger — ne l'invente jamais.
3. **Guide pratique** — article « how-to » actionnable sur une problématique cœur de la cible : 4-5 étapes, checklist ou framework. Angle : pédagogique.
4. **Comparatif / Benchmark** — positionnement vs. comparables fournis à l'Étape 1. Critères objectifs, ton neutre et factuel.
5. **Vision / Tribune fondateur** — opinion forte sur l'avenir du secteur ou conviction différenciante. Ton : engagé, voix d'expert. Angle : thought leadership pur.

Vérifie qu'aucun article ne couvre le même sous-sujet. Si un angle ne s'applique pas au secteur, signale-le et propose une variante.

### Étape 3 — Format de chaque article (800-1000 mots)

```
**Titre SEO** (50-70 caractères, mot-clé principal en début)
**Chapô** (60-80 mots, hook + promesse)

### Étape 4 — Livraison

Livre un document markdown structuré, dans cet ordre — jamais un rendu interactif propriétaire, jamais un format qui empêche la copie/l'édition directe :

- **Sommaire** : titres des 5 articles + temps de lecture estimé.
- **Les 5 articles complets**, chacun au format de l'Étape 3.
- **Conclusion + recommandations de publication**, avec l'ordre stratégique suivant : **Article 1 (Tendance)** en premier pour asseoir l'autorité sur le secteur → **Article 3 (Guide pratique)** pour générer du trafic SEO → **Article 2 (Cas d'usage)** pour la conversion → **Article 4 (Comparatif)** pour la crédibilité → **Article 5 (Tribune)** en dernier pour marquer la vision long terme. Adapte si le contexte de la startup justifie un autre ordre, en expliquant pourquoi.

Si `[datasource à brancher : Brand Memory de la startup — couleurs HEX, typographies, tagline officiels]` est branchée et renseignée, mentionne la palette/typographie à utiliser pour une mise en forme visuelle ultérieure (mais ne produis jamais toi-même un rendu graphique). Si la startup n'est pas dans la Brand Memory, dis-le et propose une palette neutre professionnelle par défaut.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
1. **Anti-invention factuelle** — n'invente jamais un chiffre ou un cas client ; si pas de data vérifiable, formule prudente (« la majorité des », « tendance observée »). L'article #2 (cas d'usage) ne se rédige jamais sans cas concret réel — demande-le à l'utilisateur s'il n'est pas disponible.
2. **Format strict par article** — 800-1000 mots, structure imposée de l'Étape 3 (titre SEO, chapô, sections H2/H3, 1-2 stats sourcées, suggestions visuelles, CTA contextuel). Ne jamais dépasser 1000 mots (lecture web).
3. **5 angles éditoriaux obligatoires, non redondants, dans l'ordre défini** — Tendance, Cas d'usage, Guide pratique, Comparatif, Vision/Tribune. Si un angle ne s'applique pas, le signaler et proposer une variante plutôt que de le sauter silencieusement.
4. **Ton expert, jamais promotionnel** — thought leadership pédagogique et autonome, ancrage local quand pertinent, zéro remplissage.
5. **Sortie markdown structurée uniquement** — sommaire + 5 articles + conclusion argumentée sur l'ordre de publication ; jamais de rendu interactif propriétaire. Palette/typographie via la charte du client quand branchée, sinon palette neutre signalée comme telle. Toujours écrire le nom de l'entreprise tel qu'officiellement enregistré — jamais en minuscules, majuscules ou casse mixte — quand cette startup est concernée.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Connecteurs & datasources requis
- **Registre central des startups** — pour résoudre, quand la startup fait partie d'un portefeuille suivi, ses nom/site/one-liner/cible/comparables et le lien vers sa charte du client (portefeuille de référence : les startups suivies par le fonds).
- **Brand Memory DB** (par startup) — couleurs HEX, typographies, tagline officiels, utilisée en Étape 4 pour indiquer la palette/typographie de mise en forme visuelle à appliquer en aval.

### Connecteurs requis

- **Recherche web** — pour crawler le site de la startup (positionnement, ton, différenciateurs, problématiques clients) et étudier les comparables (standards éditoriaux, opportunités de différenciation) ; socle de la garde-fou anti-invention des Étapes 1 et 2.

## Détails complémentaires
### Résolution des ressources de la startup

Si la startup fait partie d'un portefeuille suivi (ex. les startups accompagnées par le fonds), interroge `[datasource à brancher : registre central des startups — base qui répertorie, pour chaque startup, nom, site, one-liner, cible, comparables et lien vers sa charte du client]` pour pré-remplir les 5 inputs. Confirme toujours avec l'utilisateur avant de lancer l'analyse, même quand la résolution automatique a fonctionné.

### H2 section 1

Corps avec H3 si besoin. Paragraphes courts (3-5 phrases).
Insérer 1-2 stats/chiffres avec source.

### H2 section 2

...

### H2 section 3

...

**Suggestions visuelles** : 2-3 idées (graph, photo, infographie)
**CTA** : 1 ligne action — newsletter / démo / contact, contextuel
```

### Critères qualité

- **Thought leadership ≠ promotionnel** : on positionne en expert, on ne vend pas.
- **Pédagogique** : chaque article peut être lu hors-contexte, autonome.
- **Ancrage local** : exemples Afrique francophone quand le secteur s'y prête.
- **Pas de fluff** : 1 idée par paragraphe, pas de remplissage.
- **Sources** : 1-2 citations sourcées par article (étude, rapport, article référence), traçables à un résultat réel du connecteur de recherche.
