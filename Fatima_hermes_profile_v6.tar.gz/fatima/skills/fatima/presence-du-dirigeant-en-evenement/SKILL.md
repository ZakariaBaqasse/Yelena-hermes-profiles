---
id: Y0470
name: presence-du-dirigeant-en-evenement
description: "Traite une intervention du dirigeant en dehors de l'entreprise (conférence, panel, remise de prix, salon) comme une séquence complète : annonce avant, publications pendant, retour d'expérience après, commentaires sous les publications des organisateurs et des autres intervenants, remerciements nominatifs, chaque compte étant vérifié un par un avant d'être cité et chaque contenu recyclant l'apparition sans jamais répéter le même texte ni identifier un compte non vérifié."
bucket: B
tags: [Marketing, Réseaux sociaux, Nouveau]
version: 1
maj: 2026-09-07
---

# La séquence complète autour d'une prise de parole du dirigeant

## Ce qu'il faut avoir sous la main
- **L'événement** : nom, organisateur, date, lieu, format (présentiel, en ligne, hybride).
- **Le rôle exact du dirigeant** : intervenant sur un sujet précis, membre d'un panel, modérateur, remise de prix, ou simple présence dans la salle. Pas d'arrondi, ça se vérifie plus tard contre ce qui a réellement été dit.
- **Le statut de la confirmation** : verrouillée par l'organisateur, ou encore en discussion.
- **Ce dont il sera question** : le thème, l'angle retenu, ce que le dirigeant veut faire passer à cette occasion.
- **Les comptes à envisager d'identifier** : organisateur, co-intervenants, partenaires, avec les liens de profil si tu les as déjà.
- **Ce qui est prévu en photo ou captation**, et ce que le règlement de la salle ou de l'organisateur autorise à ce sujet.
- **Les réseaux visés** et toute contrainte connue (charte de marque, langue, format déjà utilisé par l'entreprise).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `[à confirmer]` ce qui manque, en particulier tout compte que tu ne peux pas vérifier toi-même. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 1 : Verrouiller la confirmation avant d'écrire quoi que ce soit
Rien ne s'annonce tant que la participation n'est pas confirmée par l'organisateur lui-même, pas par une invitation reçue trois mois plus tôt et jamais reconfirmée. Si le statut donné en intake est « en discussion » ou « probable », tu produis quand même la structure de la séquence, mais tu marques l'ensemble **provisoire** et tu ne libères aucun texte pour publication tant que la confirmation n'arrive pas. Une annonce publiée puis démentie fait plus de dégâts que pas d'annonce.

### Étape 2 : Fixer le rôle exact et la fenêtre de la séquence
Écris en une phrase ce que le dirigeant fait réellement à cet événement, sans l'enjoliver : assister n'est pas intervenir, intervenir dans un panel n'est pas le présider, être cité en tant que partenaire n'est pas être orateur. Chaque contenu de la séquence devra pouvoir être lu par quelqu'un d'assis dans la salle sans que celui-ci fronce les sourcils.

Cale ensuite les dates : l'annonce se publie assez tôt pour donner envie de venir ou de suivre, ce qui se publie pendant reste dans la fenêtre de l'événement, et le retour d'expérience sort dans les jours qui suivent, pas trois semaines plus tard quand plus personne ne se souvient du sujet traité. Cette fenêtre courte est la colonne vertébrale du calendrier.

### Étape 3 : L'annonce, ce qui la rend utile à relayer
Une annonce qui ne dit que la date, le lieu et un logo n'a aucune raison d'être partagée : elle informe, elle ne convainc de rien. L'annonce correcte dit de quoi il sera question, pourquoi ce sujet compte pour qui la lit, et ce que ça change d'y assister ou d'y suivre le dirigeant. Si l'intake ne donne pas d'angle exploitable au-delà de la logistique, tu le signales plutôt que de remplir avec du vide.

### Étape 4 : Vérifier chaque compte à identifier, un par un
Aucun compte n'est cité sans avoir été ouvert et regardé : la photo correspond à la personne, la fonction affichée correspond à celle annoncée dans l'intake, l'activité récente montre que le compte est vivant, et surtout, il ne s'agit pas d'une page d'entreprise prise pour le compte personnel du dirigeant qu'on veut identifier, ni d'un homonyme qui porte le même nom mais pas la même fonction. Une identification fausse notifie un inconnu et reste visible publiquement, c'est pire que pas d'identification du tout.

Pour chaque compte, tu notes ce qui a été vérifié et ce qui ne l'a pas pu être. Un compte que tu ne peux pas ouvrir toi-même (accès restreint, lien manquant) reste `[à confirmer]` et ne part pas dans le livrable final tant que l'entreprise ne l'a pas validé de son côté.

### Étape 5 : Ce qui se publie pendant, et la question de la photo
Ce qui sort pendant l'événement reste sobre et court : un extrait de ce qui vient d'être dit, une photo si elle est autorisée. Avant toute photo montrant des personnes reconnaissables, tu vérifies deux choses : l'accord des personnes visibles à l'image, et ce que le règlement de la salle ou l'organisateur autorise en matière de captation. Une salle où la captation est interdite ou un intervenant qui n'a pas donné son accord transforment une bonne intention en incident réel.

Chaque réseau reçoit un texte pensé pour lui, pas une copie collée : un format plus long et posé pour un réseau professionnel, un format court et visuel pour une story, un ton différent pour un réseau grand public. Le même texte publié à l'identique partout se repère immédiatement et ne sert aucun des deux publics.

### Étape 6 : Le retour d'expérience, le fond plutôt que la présence
Une même apparition se recycle en plusieurs contenus qui ne racontent pas la même chose : l'annonce a dit le sujet, le direct a montré le moment, le retour d'expérience dit ce qui a été dit sur le fond, et il peut se doubler d'une observation rapportée de la salle (une question posée, une réaction du public, un point de désaccord soulevé). Ces contenus se distinguent nettement les uns des autres, faute de quoi la séquence entière se résume à répéter « j'y étais » sous des formes différentes.

Le retour d'expérience reste tenu par la même exigence qu'à l'étape 2 : ce qui est écrit doit résister à quelqu'un qui était dans la salle. Une reformulation flatteuse d'une question difficile, ou un rôle présenté plus important qu'il ne l'était, se voit et se corrige avant publication, pas après.

### Étape 7 : Les remerciements nominatifs
Une liste de sept noms alignés ne remercie personne, elle coche une case. Chaque nom retenu dans le remerciement est accompagné de ce que cette personne a concrètement apporté (une invitation, une mise en relation, une organisation réussie, une question qui a fait avancer le débat). Si tu ne peux pas dire ce qu'une personne a apporté, elle ne figure pas dans le remerciement nominatif, elle peut au mieux figurer dans une identification plus générale sur l'événement.

### Étape 8 : Les commentaires sous les publications des organisateurs et des autres intervenants
Pour chaque publication visée (celle de l'organisateur, celle d'un co-intervenant), le commentaire reprend un point précis échangé ce jour-là, pas une formule générique du type « merci pour l'invitation, super moment ». Tu notes le lien de la publication visée : sans lien fourni ou retrouvé, le commentaire reste en attente et n'est pas inventé de mémoire. Le timing compte autant que le texte : un commentaire posté sous une publication qui a déjà cessé d'être commentée par d'autres arrive trop tard pour être vu.

## Format de sortie
- **Calendrier de la séquence** : tableau avec date, réseau, objet en une ligne, pour chaque contenu (annonce, pendant, retour d'expérience, remerciement, commentaires).
- **Textes prêts à publier**, un par contenu et par réseau, dans le format propre à chaque réseau.
- **Liste des comptes à identifier**, chacun avec le lien de son profil vérifié, la mention de ce qui a été confirmé, et le statut `[à confirmer]` pour tout ce qui ne l'a pas été.
- **Relevé des commentaires à poster**, avec le lien de la publication visée et le texte proposé.
- **Note sur les photos** : lesquelles sont utilisables telles quelles, lesquelles demandent un accord avant publication, et ce que le règlement de la salle autorise.
- **Règle 0 invention** : aucun nom, aucun lien de profil ou de publication, aucune citation n'est produit sans avoir été fourni ou vérifié. Ce qui manque reste `[à confirmer]`.

## Règles
1. **Une identification vérifiée, ou pas d'identification.** Aucun compte n'est cité sans avoir été ouvert et contrôlé un par un contre la fonction et la personne annoncées.
2. **L'annonce dit le sujet, pas seulement la présence.** Une date, un lieu et un logo ne constituent pas une annonce exploitable.
3. **Le remerciement nomme la contribution.** Un nom sans ce qu'il a apporté ne figure pas dans le remerciement nominatif.
4. **La fenêtre est courte et calée à l'avance.** Le retour d'expérience sort dans les jours qui suivent l'événement, pas des semaines après.
5. **Aucune photo publiée sans accord des personnes reconnaissables ni sans respect du règlement de captation de la salle.**
6. **Chaque réseau reçoit son texte.** Un même texte copié à l'identique sur plusieurs réseaux n'est pas un livrable correct.
7. **Le rôle écrit résiste à un témoin.** Ce qui est dit sur la fonction du dirigeant à l'événement doit tenir devant quelqu'un qui y était.
8. **Rien ne s'annonce avant confirmation de l'organisateur.** Une participation « probable » reste provisoire et hors publication.

**Garde-fous durs**

- **0 invention.** Aucun nom, lien de profil, lien de publication ou citation fabriqués. Toute donnée non reçue ou non vérifiable reste `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Un compte, une citation ou un fait ne sont jamais présentés comme vérifiés sans l'avoir été réellement. Si un lien ou un compte est inaccessible, tu le dis et tu poursuis avec ce que tu as.
- **Produis, ne bloque pas.** Avec le contexte disponible, tu livres la séquence en étiquetant tes hypothèses plutôt que de t'arrêter pour tout réclamer d'un coup.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des textes, une liste d'identifications et un relevé de commentaires prêts ; publier, identifier réellement quelqu'un, ou poster un commentaire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends sur un événement ou une personne identifiée ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Compte introuvable ou incertain** : tu ne l'identifies pas, tu le signales en `[à confirmer]` et tu proposes le texte sans identification en attendant.
- **Participation non confirmée** : tu produis le squelette complet de la séquence, tu le marques **provisoire**, et rien n'est libéré pour publication tant que la confirmation n'arrive pas.
- **Photo sans accord établi** : elle figure dans la note comme nécessitant un accord, elle n'entre pas dans les textes prêts à publier.
- **Rôle ambigu** (présence non active, invitation informelle) : tu le traites comme une simple présence, sans le gonfler en intervention.
- **Publication de l'organisateur pas encore parue** : le commentaire correspondant reste en attente, tu ne le publies pas sous une publication qui n'existe pas encore.
- **Retour d'expérience demandé au-delà de la fenêtre courte** (plusieurs semaines après l'événement) : tu le produis quand même si demandé, mais tu signales que l'écho attendu est réduit.
- **Réseaux multiples avec chartes différentes** : tu adaptes chaque texte et tu signales toute contrainte de charte que tu ne connais pas.
- **Action sortante demandée** (publier, identifier réellement, envoyer un commentaire) : tu prépares le livrable complet et tu t'arrêtes pour validation humaine avant toute diffusion.
- **Sources contradictoires** (deux versions du rôle exact du dirigeant, par exemple) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
