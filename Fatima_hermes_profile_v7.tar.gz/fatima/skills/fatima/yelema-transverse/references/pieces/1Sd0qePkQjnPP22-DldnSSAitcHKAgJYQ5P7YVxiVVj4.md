# 260922_Encaisser en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 21 lignes non vides =====

# Encaisser en Côte d'Ivoire
Constituée le 22/09/2026. Elle sert une règle simple et souvent oubliée : le moyen d'encaissement décide de la vente plus souvent qu'on ne le croit. Un client convaincu qui ne peut pas payer comme il en a l'habitude ne conclut pas.
## Le paysage, et ce qu'on n'en dira pas
Le mobile money domine les paiements des particuliers. Quatre opérateurs reviennent partout : Orange Money, MTN MoMo, Wave, Moov Money.

⛔ Aucune part de marché n'est écrite ici, et c'est un choix. Les sources publiques disponibles sont des comparateurs commerciaux qui se contredisent frontalement : l'un donne Wave à 40 %, l'autre Orange à 55 % et Wave à 35 %. Ils vendent des passerelles de paiement. La source qui ferait autorité est la BCEAO, pas un blog. ⟦à récupérer : les statistiques de monnaie électronique de la BCEAO⟧

Pour les entreprises, le virement reste le canal des montants importants, et le chèque survit. ⟦à mesurer sur des affaires réelles⟧
## Le cadre : ce sont des établissements réglementés
Les opérateurs de mobile money sont des établissements de monnaie électronique, soumis au contrôle de la Commission bancaire de l'UMOA. Conséquence pratique, qui surprend souvent : un incident de mobile money se réclame comme un incident bancaire, avec un délai de réponse d'un mois, un traitement gratuit, puis un recours devant la Commission bancaire. Le circuit complet est dans droit-consommation-ci/RECLAMATIONS-FINANCIERES.md.
## Avant de promettre un lien de paiement dans un devis
Un encaissement en ligne n'est pas une case à cocher. Ce qu'il faut avoir vérifié : l'encaissement lui-même, les liens de paiement, le paiement en boutique, les transferts, et les webhooks qui confirment la transaction à votre système.

⛔ Avertissement à ne pas perdre, relevé sur un prestataire ivoirien d'encaissement (integrations/[entreprise cliente]/) : il n'a aucun environnement d'essai. Chaque appel à son interface de production déplace de l'argent réel. On lit la documentation, on n'exécute aucun appel de paiement pour « voir ». Cette règle vaut par défaut pour tout prestataire local tant qu'un environnement de test n'est pas démontré.
## Ce que ça change pour une campagne
- Le tunnel s'arrête au moyen de paiement, pas au message. Une campagne qui pousse vers un paiement par carte dans un pays de mobile money perd à la dernière marche.
- Le montant décide du canal : mobile money pour les petits montants des particuliers, virement au-delà.
- Ne pas annoncer un mode de paiement avant de l'avoir branché, et ne pas le brancher en jouant avec l'argent réel d'un client.
## Ce que cette base ne contient pas
- Les parts de marché, voir plus haut.
- Les frais des opérateurs, qui varient par palier et par usage. ⟦à relever⟧
- Les plafonds réglementaires par compte de monnaie électronique. ⟦à chercher chez la BCEAO⟧
- Les délais de paiement entre entreprises, qui sont un autre sujet : voir marches-publics-ci/DELAIS-DE-PAIEMENT.md pour le secteur public.

À recontrôler le 22/03/2027.
