# 260922_Foires, salons et manifestations promotionnelles en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 26 lignes non vides =====

# Foires, salons et manifestations promotionnelles
Constituée le 22/09/2026. ⛔ Organiser une manifestation promotionnelle en Côte d'Ivoire n'est pas libre : elle est soumise à autorisation et à agrément. C'est une information de calendrier autant que de conformité, et elle se perd si on ne regarde que la liste des événements.
## Le texte et l'organe
Décret n° 2018-546 du 6 juin 2018 portant définition et organisation des manifestations promotionnelles à caractère commercial, industriel et artisanal en Côte d'Ivoire. Il abroge le décret 95-387 du 13 avril 1995. ⟦à récupérer : le décret lui-même n'est pas sur le disque⟧

Le Service des manifestations promotionnelles (SMP), rattaché au cabinet du ministère du Commerce, de l'Industrie et de l'Artisanat :

- reçoit et traite les demandes d'autorisations et d'agréments pour organiser une manifestation promotionnelle ;
- apporte l'appui institutionnel aux manifestations initiées par des pays étrangers ;
- élabore et publie le calendrier annuel ;
- veille à l'application des dispositions réglementaires sur tout le territoire.

Contacts : SMP, Abidjan Cocody Riviera IV, cité World City, +225 27 22 42 88 79 · 01 02 02 86 66 · 05 45 11 43 17 · info@commerce.gouv.ci. Cabinet du ministère : Abidjan Plateau, immeuble Postel 2001, 23e étage, +225 27 20 21 81 36.
## Le calendrier officiel
agenda-foires-et-salons-2026-min-commerce.pdf, édition 2026, 77 pages, avec son texte extrait. Publication officielle du ministère, distribuée aux organisateurs, entreprises, municipalités, chambres de commerce, structures publiques et privées, consulats et ambassades, et hors du pays aux ministères des Affaires étrangères.

ℹ Correction d'une note antérieure : nous avions écrit le 17/09 que l'édition 2026 n'était pas publiée. Elle l'est, et c'est elle qui se trouve à l'adresse que nous avions relevée comme étant celle de 2025.

⚠ Le fichier pèse 20 Mo, au-delà du plafond par défaut de notre outil de téléchargement. Il se récupère avec --plafond 40.

Les manifestations y sont classées par secteur, et les secteurs couverts disent ce que le pays met en avant : agro-alimentation et agro-transformation · architecture, construction et décoration · commerce et tourisme · culture et tourisme · digitalisation et économie numérique · écologie, industrie et développement durable · économie et management · éducation, formation et recherche · intelligence artificielle · inventions et innovations · promotion du genre · propriété intellectuelle · protection sociale et droit du travail.

On y trouve aussi bien des salons d'Abidjan que des foires régionales, Kani Expo, Boundiali Expo, foire régionale de Man, exposition d'Assinie, festivals Porlahla et Mandé N'ko.
## Ce que ça change pour un plan de communication
- La date d'un salon n'est pas une information de presse, c'est une publication officielle. On la lit dans l'agenda, pas dans un article.
- Un client qui veut organiser son propre événement a une formalité à faire, pas seulement un lieu à réserver. Le délai d'instruction n'est pas connu ici. ⟦à demander au SMP⟧
- Les foires régionales existent et sont nombreuses. Un plan qui ne prévoit qu'Abidjan passe à côté, comme pour la radio (voir medias-ci/).
## Ce que cette base ne contient pas
- Le décret 2018-546 lui-même, ses conditions d'agrément, ses délais et ses coûts.
- Les tarifs de stand et les conditions d'exposition, qui se demandent aux organisateurs.
- Les compléments privés : la CGECI (cgeci.com) et le CEPICI (cepici.ci, ⚠ le domaine cepici.gouv.ci redirige) annoncent des rencontres qui ne sont pas toutes dans l'agenda.
- Le bilan d'une édition passée : fréquentation, exposants. Aucun n'a été trouvé.

Édition 2026 relevée le 22/09/2026. À reprendre à la parution de l'édition 2027.
