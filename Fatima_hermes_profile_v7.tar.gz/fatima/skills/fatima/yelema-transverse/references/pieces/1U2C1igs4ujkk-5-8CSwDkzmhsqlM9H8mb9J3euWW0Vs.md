# 260922_Medias ivoiriens - releve des repertoires HACA et ANP

===== onglet t.0 · Tab 1 · 43 lignes non vides =====

# Les médias ivoiriens, comptés sur les répertoires des régulateurs
Constituée le 22/09/2026 en relevant les répertoires publics de la HACA (audiovisuel) et de l'ANP (presse). Ce ne sont pas des estimations : ce sont les listes d'opérateurs autorisés, relevées ligne à ligne le 22/09/2026. Les relevés bruts sont dans releves/, avec les deux scripts qui les ont produits.

⛔ Ce que le relevé apprend, et qui change un plan média : la Côte d'Ivoire compte 381 radios autorisées, dont 8 commerciales. Une campagne qui achète de l'espace radio ne choisit pas parmi 381 stations, elle choisit parmi une poignée. Le reste du paysage est associatif, confessionnel, scolaire ou de proximité, et ne se traite pas comme un support publicitaire ordinaire.
## La radio, 381 stations
| Type | Nombre |
| Proximité | 303 |
| Confessionnelle | 35 |
| École | 14 |
| Non nationale (RFI, BBC, Medi 1…) | 9 |
| Commerciale | 8 |
| Rurale | 7 |
| Institutionnelle | 3 |
| Publique | 2 |

114 localités desservies. 85 stations dans le grand Abidjan, soit 22 % : autrement dit 78 % des radios autorisées émettent hors d'Abidjan, ce qui en fait le média de la couverture nationale, là où la télévision et la presse sont abidjanaises.

Les localités les mieux dotées hors Abidjan : Bouaké 18 · Korhogo 16 · Yamoussoukro 9 · Adzopé 8 · Aboisso 8 · Gagnoa 6 · Sinématiali 6 · San Pedro 6 · Agboville 5 · Daoukro 5 · Grand-Bassam 5 · Man 5. Puis une longue traîne de localités à trois ou quatre stations.

Dans Abidjan : Cocody 24 · Yopougon 14 · Abobo 9 · Plateau 9 · Treichville 7 · Adjamé 5 · Marcory 5.

Le fichier releves/haca-radio.json porte pour chaque station son nom, sa fréquence, son type, le titulaire de l'autorisation et sa localité. Le titulaire compte : beaucoup de stations de proximité appartiennent à une association ou à une collectivité, et l'accès publicitaire n'y est pas le même que chez un opérateur commercial.
## La télévision, sept chaînes
| Chaîne | Titulaire | Type |
| RTI 1 · RTI 2 · RTI Bouaké | Groupe RTI | service public |
| Life TV | Life TV | commerciale |
| 7 Info | Optimum Media CI | commerciale |
| A+ Ivoire | Société audiovisuelle de CI | commerciale |
| NCI | Sorano-CI | commerciale |

⚠ Un écart à signaler : une note interne de la flotte citait un ordre officiel de chaînes comportant « La 3 », issu d'une décision HACA de 2023. Le répertoire des opérateurs télé de la HACA, relevé le 22/09/2026, ne porte pas cette chaîne. Ne pas citer « La 3 » sans l'avoir revérifiée à la source.

Neuf distributeurs : Canal+ Côte d'Ivoire, StarTimes Media, Akwaba Télé, TV-Com Côte d'Ivoire, TNT Sat, Sat Ivoire, plus deux bouquets de multiplex payants de la TNT, « Easy TV » de Telenum et « Classic » de StarTimes.
## Le web, et sa surprise
11 web radios autorisées, dont 8 d'informations religieuses, et 11 web TV. Les listes portent le responsable et son contact. C'est peu, et c'est une information en soi : le web audiovisuel déclaré est marginal, alors que l'audience numérique ne l'est pas. Un projet de web radio ou de web TV passe par une autorisation de la HACA comme les autres.
## La presse
L'Autorité nationale de la presse a été créée par la loi n° 2017-867 du 27 décembre 2017 portant régime juridique de la presse. C'est un texte en vigueur, à la différence du projet de loi sur la communication publicitaire, voir publicite-ci/.

Trois périodicités sont distinguées par le répertoire : quotidien, hebdomadaire, mensuel.

Presse numérique : la page publique sert 20 éditeurs, avec périodicité, adresse, site et directeur général. Relevé dans releves/anp-numerique.json. On y trouve notamment Fraternité Matin, Alerte Info, Le Débat Ivoirien, Tembo.

⛔ La presse imprimée n'a pas pu être relevée : sa liste n'est servie qu'après envoi d'un formulaire en POST avec jeton anti-rejeu, ce que notre outil de téléchargement public ne fait pas et ne doit pas faire (il ne porte ni cookie ni session, c'est sa limite assumée). Le nombre d'éditeurs imprimés reste donc indéterminé, et il ne faut pas le déduire du chiffre du numérique. ⟦à obtenir : demander la liste à l'ANP, contact@anp.ci, +225 27 22 52 04 52⟧

⚠ L'ANP suspend des titres, et ça se lit sur son site. Sa page « Décisions » porte des décisions de suspension nominatives, dont deux du 30 octobre 2025. Avant de recommander un support de presse, vérifier qu'il n'est pas sous le coup d'une décision.
## Ce que cette base ne contient pas
- ⛔ Les audiences. Aucun chiffre d'audience n'est publié par la HACA ni par l'ANP dans ces répertoires. La HACA annonce des rubriques « Statistiques Radio » et « Statistiques Télé » qui n'ont pas été relevées. ⟦à ouvrir⟧ Une liste d'opérateurs n'est pas une mesure d'audience, et ne s'y substitue jamais dans un plan média.
- Les tarifs d'espace publicitaire, qui ne sont pas publics et se demandent aux régies.
- Le nombre d'éditeurs de presse imprimée, voir plus haut.
- La diffusion réelle des titres : pas d'OJD local identifié.
- Pour les règles applicables à un message publicitaire et le circuit de validation, voir publicite-ci/. Pour l'audience des plateformes numériques, voir numerique-ci/.
## Comment rafraîchir
releves/haca.py et releves/anp.py rejouent le relevé. Tous leurs appels réseau passent par integrations/web-public/telecharger.py. Le répertoire radio est paginé par cinquante, la boucle s'arrête d'elle-même quand une page répète la précédente.

Relevé du 22/09/2026. À rejouer le 22/03/2027 : les autorisations se délivrent et se retirent en continu.
