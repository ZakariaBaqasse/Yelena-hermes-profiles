# Couche locale : Fatima · Marketing et contenu

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-FATIMA-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci/
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Note à fabriquer : qui décide quoi, centrée sur les 4 régulateurs qui peuvent arrêter une campagne (CSP, HACA, ANP, Autorité de protection des données). Remplace presidence.ci en colonne H : ce dernier filtre les scripts et sa chaîne de certificat est incomplète. Il reste valable au navigateur. ✅ 17/09, balayage de la flotte : LA PIÈCE EXISTE DÉJÀ. memory/reference/gouvernement-2026.md chez LOKOLI donne la composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 » (1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués), relevée le 10/09 sur le portail officiel, avec la réserve : rouvrir la page avant de citer un ministre. À reprendre plutôt qu'à refaire. Et pour savoir quelle source fait foi quand deux divergent, watchlist-sources-ci.md chez BENKAN, YIRIWA et LOKOLI porte une hiérarchie de fiabilité (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, INS, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA). ⚠ Les trois versions diffèrent.

### CL-FATIMA-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021. Un écart à ne pas lisser : ce jeu dit 31 régions et 201 communes, les sources encyclopédiques disent 197 communes, 14 districts, 111 départements, 510 sous-préfectures (loi 2014-451). On dépose l'officiel et on note l'écart. MISE À JOUR DU 18/09, ET CE JEU EST ANTÉRIEUR AU CHANGEMENT : le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026 (référence établie sur le recensement mensuel d'Ivoire-Juriste, cohérence vérifiée contre son récapitulatif de janvier). La presse ne l'a relevé que le 18/03. L'écart noté plus haut sur les districts est donc tranché : UN LIVRABLE ÉCRIT DEUX DISTRICTS AUTONOMES, JAMAIS DOUZE NI QUATORZE. L'écart sur les communes, 201 contre 197, reste ouvert. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-FATIMA-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://fr.wikipedia.org/wiki/F%C3%AAtes_et_jours_f%C3%A9ri%C3%A9s_en_C%C3%B4te_d'Ivoire
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Base légale réelle, à substituer à Wikipédia : article 24.2 du Code du travail (loi 2015-532) et décret 96-205 du 07/03/1996 modifié par le décret 2011-371. Point non intuitif : seuls le 1er mai et le 7 août sont chômés ET payés pour tous. Saisons : sodexam.com. Le calendrier des fêtes UEMOA demandé le 14/09 entre ici. Textes non ouverts, à confirmer au Journal officiel.

## Zone UEMOA

### CL-FATIMA-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Note à fabriquer : régional ou national, pour chaque règle que Fatima est susceptible de citer. uemoa.int répond mais sa chaîne de certificat est incomplète, les scripts tombent et le navigateur passe (déjà constaté le 14/09).

### CL-FATIMA-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Source identifiée, aucun chiffre relevé : ni SMIG ni panier moyen. Écrire un montant non lu sur une source officielle est exactement ce que cette couche locale existe pour empêcher. Les montants se relèvent à la passe de remplissage. MISE À JOUR DU 18/09 : les chiffres de base sont désormais relevés sur bceao.int, huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. LE SMIG RESTE NON RELEVÉ, c'est un manque transverse distinct et il n'est pas comblé par cette mise à jour.

## Droit des affaires

### CL-FATIMA-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/actes-uniformes/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Deux actes seulement, pas dix-sept : droit commercial général (adopté le 15/12/2010, en vigueur le 15/05/2011) et sociétés commerciales. À écrire noir sur blanc dans la fiche : l'OHADA ne régit PAS la publicité, qui est nationale. Miroir : ohada.com/textes-ohada/actes-uniformes.html

## Langue

### CL-FATIMA-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Déjà chez elle : compétence parler-ivoirien (Y0487), liée depuis le 14/09, trois registres et 122 mots nouchis. Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due.

## Canaux

### CL-FATIMA-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. La pièce primaire est l'enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, conduite avec le cabinet Axes Marketing (échantillon stratifié, 7 474 189 ménages, 27 216 065 individus de 5 ans et plus, face à face sur tablette, 33 districts et régions). Elle est sur disque et lisible par Fatima, et une note d'usage en a été tirée : memory/reference/numerique-ci/notes/audience-plateformes-ci.md. CE QUE LA NOTE AJOUTE AU PDF, et c'est la raison d'être de l'intégration : la base de calcul. Les parts de plateformes sont données dans le chapitre « Usages d'Internet », leur base est donc les INTERNAUTES, qui ne sont que 41,4 % des individus de 5 ans et plus. WhatsApp 92,8 %, Facebook 82,1 %, TikTok 81,5 %, Messenger 36,6 %, YouTube 35,0 %, Instagram 19,0 %, Telegram 11,0 %, X 2,0 %, LinkedIn 1,3 %, Ayoba 0,9 %, Skype 0,9 %. Un livrable écrit « des internautes », jamais « des Ivoiriens » : l'écart vaut un facteur 2,4. Rappel de cadrage utile au même endroit : mobile 72,4 % mais smartphone 42,4 % seulement, ordinateur 9,6 %. L'enquête ne porte ni heures d'audience, ni engagement, ni tarifs : les lignes 12, 16 et 27 restent ouvertes et ne sont pas couvertes par celle-ci.

### CL-FATIMA-22 · Le paiement, parce que c'est lui qui termine la campagne
- **Pourquoi** : Une campagne qui ne dit pas comment on paie ne convertit pas
- **Où chercher** : BCEAO, rapport sur les services financiers numériques
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1Sd0qePkQjnPP22-DldnSSAitcHKAgJYQ5P7YVxiVVj4.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Base neuve bases-locales/paiement-ci/, et sa règle de fond est celle qui manquait à la ligne : LE MOYEN D'ENCAISSEMENT DÉCIDE DE LA VENTE PLUS SOUVENT QU'ON NE LE CROIT, un client convaincu qui ne peut pas payer comme il en a l'habitude ne conclut pas. Le mobile money domine les paiements des particuliers, quatre opérateurs reviennent partout, Orange Money, MTN MoMo, Wave et Moov Money. ⛔ AUCUNE PART DE MARCHÉ N'EST ÉCRITE, ET C'EST UN CHOIX ASSUMÉ : les sources disponibles sont des comparateurs commerciaux qui VENDENT DES PASSERELLES DE PAIEMENT et se contredisent frontalement, l'un donnant Wave à 40 %, l'autre Orange à 55 % et Wave à 35 %. La source qui ferait autorité est la BCEAO, à récupérer. CE QUE LA NOTE APPORTE EN PLUS : les opérateurs de mobile money sont des ÉTABLISSEMENTS DE MONNAIE ÉLECTRONIQUE soumis au contrôle de la Commission bancaire de l'UMOA, donc un incident de mobile money SE RÉCLAME COMME UN INCIDENT BANCAIRE, réponse due en un mois, traitement gratuit, puis recours devant la Commission bancaire ; le circuit complet est dans droit-consommation-ci/RECLAMATIONS-FINANCIERES.md. ⛔ AVERTISSEMENT À NE PAS PERDRE AVANT DE PROMETTRE UN LIEN DE PAIEMENT DANS UN DEVIS : le prestataire ivoirien d'encaissement que nous avons documenté n'a AUCUN ENVIRONNEMENT D'ESSAI, chaque appel à son interface de production DÉPLACE DE L'ARGENT RÉEL. On lit la documentation, on n'exécute aucun appel de paiement pour voir, et cette règle vaut par défaut pour tout prestataire local tant qu'un environnement de test n'est pas démontré. POUR UNE CAMPAGNE : le tunnel s'arrête au moyen de paiement et non au message, une campagne qui pousse vers un paiement par carte dans un pays de mobile money perd à la dernière marche. ⛔ RESTENT DUS : les frais par palier, les plafonds réglementaires par compte de monnaie électronique, et les statistiques de monnaie électronique de la BCEAO.

## Audience

### CL-FATIMA-11 · Ce que les marques ivoiriennes publient, et ce que ça donne vraiment
- **Pourquoi** : Copier une stratégie américaine sur un public qui n'interagit pas
- **Où chercher** : Corpus déjà constitué sur les comptes de marques locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || Déjà chez elle, et c'est du mesuré : memory/reference/reseaux-marques-ci.md, relevé du 06/09/2026, 132 publications réelles sur 11 comptes, données brutes en JSON. Le constat : six comptes sur sept ont beaucoup d'abonnés et presque aucune interaction (MTN CI, 352 062 abonnés, entre 1 et 235 j'aime). Orange fait exception, jusqu'à 11 935. ℹ Cette cellule avait été vidée en cours de journée pendant une édition simultanée du tableur : restaurée le 17/09 au soir.

### CL-FATIMA-12 · Les heures et les jours où l'audience est là
- **Pourquoi** : Publier à l'heure de Paris
- **Où chercher** : Statistiques des comptes de la maison et des clients
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : ACCÈS VÉRIFIÉ LE 18/09, ET LA RÉPONSE EST NON : les statistiques d'audience ne sont pas atteignables, pour une raison qui n'est pas un problème de droits. La liste des comptes réellement connectés à Unipile, relevée par integrations/unipile/comptes.py, donne QUATRE comptes : trois WhatsApp et un LinkedIn (la direction de Yelema). AUCUN COMPTE INSTAGRAM NI FACEBOOK N'EST CONNECTÉ. Or la question des heures et des jours où l'audience est là se pose sur ces deux plateformes. Il n'y a donc rien à lire, et ouvrir un droit de lecture n'y changerait rien tant qu'aucun compte n'est raccordé. ⚠ À SIGNALER AU PASSAGE : l'un des trois comptes WhatsApp (22597714432) est en statut CREDENTIALS, c'est-à-dire déconnecté. Il demande une reconnexion par un humain. CE QUI EXISTE EN REVANCHE, et qui ne répond pas à la ligne : memory/reference/donnees/ porte deux relevés Instagram de marques ivoiriennes du 06/09, mais ce sont des comptes TIERS observés de l'extérieur, sans statistiques d'audience, et l'audience d'une autre marque n'est pas la nôtre. POUR DÉBLOQUER : raccorder un compte Instagram ou Facebook de la maison, puis relire. Sans cela la ligne reste ouverte.

### CL-FATIMA-21 · La langue de l'audience et son niveau de lecture
- **Pourquoi** : Un visuel qui repose sur du texte écrit exclut une partie du pays
- **Où chercher** : Agence nationale de la statistique, RGPH
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.anstat.ci/
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/09/2027
- **Commentaire** : INTÉGRÉ LE 21/09, par l'intégration banque-mondiale. Note d'usage neuve : memory/reference/bases-locales/socle-local-ci/alphabetisation-et-niveau-de-lecture.md. ⛔ LE CHIFFRE EST PLUS BAS QU'ON NE CROIT : alphabétisation des adultes 50,0 % en 2021, hommes 60,2 %, femmes 40,3 %, jeunes de 15 à 24 ans 66,8 %. Le triplet 2021 est cohérent, sa moyenne retombe sur le total. ⚠ LA SÉRIE EST INSTABLE entre millésimes (56,96 % en 2019, 50,0 % en 2021, hommes 67,6 en 2019, 60,2 en 2021, 68,05 en 2022) : ce n'est pas un phénomène, ce sont des changements d'enquête. On cite le triplet 2021 en entier avec son année, et on ne compare pas deux millésimes. CE QUE ÇA COMMANDE : un adulte sur deux ne lit pas couramment, le pictogramme n'est donc pas une coquetterie mais le seul canal qui franchit la barrière, et la radio (99,3 % des ménages selon la MSI 2024) est le seul média qui ne demande pas de savoir lire. ⛔ NON COUVERT : le niveau de lecture par région et par langue, qui changerait un plan de diffusion. || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || Ajout du 17/09. C'est un choix de format, pas une note de bas de page. RGPH 2014 : plus de la moitié de la population de 15 ans et plus ne lit ni n'écrit dans aucune langue, avec un écart énorme entre territoires (30,1 % à Abidjan contre 84,7 % dans le Folon). Le dioula est parlé par une large part du pays. Chiffres de 2014, à réactualiser sur le RGPH 2021. anstat.ci filtre les scripts en 403, il s'ouvre au navigateur.

## Médias

### CL-FATIMA-13 · La presse locale : titres, audiences, qui traite quoi
- **Pourquoi** : Envoyer un communiqué au mauvais titre
- **Où chercher** : Corpus annuaire presse déjà constitué
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.haca.ci/annuaires/repertoire-des-operateurs-radio
- **Pièce, ici** : references/pieces/1U2C1igs4ujkk-5-8CSwDkzmhsqlM9H8mb9J3euWW0Vs.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, avec un manque nommé. Base neuve bases-locales/medias-ci/, relevée ligne à ligne sur les répertoires des régulateurs, pas estimée. CE QUI EST ACQUIS : l'Autorité nationale de la presse est créée par la LOI N° 2017-867 DU 27 DÉCEMBRE 2017 portant régime juridique de la presse, texte en vigueur, à la différence du projet de loi sur la publicité. Trois périodicités distinguées : quotidien, hebdomadaire, mensuel. La presse NUMÉRIQUE est relevée : 20 éditeurs servis par la page publique, avec périodicité, adresse, site et directeur général, dans releves/anp-numerique.json (Fraternité Matin, Alerte Info, Le Débat Ivoirien, Tembo, entre autres). ⚠ L'ANP SUSPEND DES TITRES et ses décisions sont publiques, dont deux suspensions du 30 octobre 2025 : avant de recommander un support de presse, vérifier qu'il n'est pas sous le coup d'une décision. ⛔ CE QUI N'A PAS PU ÊTRE RELEVÉ, ET POURQUOI : la liste de la presse IMPRIMÉE n'est servie qu'après envoi d'un formulaire en POST avec jeton anti-rejeu. Notre outil de téléchargement public ne porte ni cookie ni session, c'est sa limite assumée, et je ne l'ai pas franchie pour une liste. Le nombre d'éditeurs imprimés reste donc indéterminé et NE SE DÉDUIT PAS du chiffre du numérique. Il se demande à contact@anp.ci ou au +225 27 22 52 04 52. ⛔ ET LES AUDIENCES NE SONT PAS LÀ : aucun chiffre d'audience n'est publié dans ces répertoires, aucun équivalent local de l'OJD n'a été identifié. Une liste d'éditeurs n'est pas une mesure d'audience et ne s'y substitue pas dans un plan média.

### CL-FATIMA-14 · Radios et télévisions qui comptent hors d'Abidjan
- **Pourquoi** : Le hors-réseaux se touche par la radio, pas par LinkedIn
- **Où chercher** : HACA, grilles des stations
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.haca.ci/annuaires/repertoire-des-operateurs-radio
- **Pièce, ici** : references/pieces/1U2C1igs4ujkk-5-8CSwDkzmhsqlM9H8mb9J3euWW0Vs.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, et le relevé répond exactement à la question de la ligne. Base neuve bases-locales/medias-ci/, comptée sur le répertoire de la HACA le 22/09, données brutes dans releves/haca-radio.json avec nom, fréquence, type, titulaire de l'autorisation et localité. ⛔ LE CHIFFRE QUI CHANGE UN PLAN MÉDIA : 381 RADIOS AUTORISÉES, DONT 8 COMMERCIALES. Le reste se répartit en 303 stations de proximité, 35 confessionnelles, 14 scolaires, 9 non nationales (RFI, BBC, Medi 1), 7 rurales, 3 institutionnelles et 2 publiques. Acheter de l'espace radio ne veut donc pas dire choisir parmi 381 supports, et une station de proximité appartenant à une association ou à une collectivité ne s'aborde pas comme une régie commerciale : le titulaire figure dans le relevé, il se regarde. HORS D'ABIDJAN, QUI EST LE CŒUR DE LA LIGNE : 114 localités desservies, et 85 stations seulement dans le grand Abidjan, soit 22 %. AUTREMENT DIT 78 % DES RADIOS AUTORISÉES ÉMETTENT HORS D'ABIDJAN, ce qui fait de la radio le média de la couverture nationale là où la télévision et la presse sont abidjanaises. Les mieux dotées : Bouaké 18, Korhogo 16, Yamoussoukro 9, Adzopé 8, Aboisso 8, Gagnoa 6, Sinématiali 6, San Pedro 6, Agboville 5, Daoukro 5, Grand-Bassam 5, Man 5. TÉLÉVISION : sept chaînes seulement, trois de service public du groupe RTI (RTI 1, RTI 2, RTI Bouaké) et quatre commerciales (Life TV, 7 Info d'Optimum Media, A+ Ivoire, NCI de Sorano-CI), plus neuf distributeurs dont Canal+, StarTimes, Akwaba Télé, TV-Com, TNT Sat, Sat Ivoire et deux bouquets TNT. ⚠ ÉCART SIGNALÉ : une note interne citait un ordre officiel de chaînes comportant « La 3 » d'après une décision HACA de 2023. Le répertoire relevé le 22/09 NE LA PORTE PAS. Ne pas la citer sans revérification. WEB : 11 web radios, dont 8 d'informations religieuses, et 11 web TV. ⛔ CE QUI MANQUE : aucune audience n'est publiée dans ces répertoires. Les rubriques « Statistiques Radio » et « Statistiques Télé » de la HACA n'ont pas encore été ouvertes, c'est la prochaine marche.

### CL-FATIMA-27 · Les tarifs médias : insertion presse, spot radio, panneau
- **Pourquoi** : Sans eux un plan média sort avec un ordre de grandeur, pas un budget
- **Où chercher** : Régies publicitaires, directement
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Introuvable en ligne : ça se demande aux régies, une par une. C'est ce qui manque le plus pour qu'un plan média soit crédible. Les régies se trouvent par la liste agréée du CSP (CL-FATIMA-26).

## Événements

### CL-FATIMA-15 · Le calendrier des salons et rencontres du secteur
- **Pourquoi** : Arriver après la date limite d'inscription
- **Où chercher** : Organisateurs, CEPICI, fédérations
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.commerce.gouv.ci/uploads/publications/177383243159.pdf
- **Pièce, ici** : references/pieces/1DYJE7LxCC2voiV23H7mc2m66P5zB6IM1TRRBv9lgbBo.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 31/01/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET UNE ERREUR DE MA NOTE DU 17/09 EST CORRIGÉE. Base neuve bases-locales/evenements-ci/ avec l'agenda officiel sur disque. ℹ J'avais écrit que l'édition 2026 n'était pas publiée : ELLE L'EST, et c'est elle qui se trouve à l'adresse que j'avais relevée comme étant celle de 2025. Le fichier fait 77 pages et 20 Mo, au-delà du plafond de notre outil de téléchargement, il se récupère avec --plafond 40 (option ajoutée ce jour à l'intégration). ⛔ CE QUE L'AGENDA APPREND ET QUI DÉPASSE LE CALENDRIER : organiser une manifestation promotionnelle en Côte d'Ivoire N'EST PAS LIBRE. Le décret n° 2018-546 du 6 juin 2018, qui abroge le décret 95-387 de 1995, organise le secteur, et le SERVICE DES MANIFESTATIONS PROMOTIONNELLES rattaché au cabinet du ministère du Commerce REÇOIT ET TRAITE LES DEMANDES D'AUTORISATIONS ET D'AGRÉMENTS, publie le calendrier annuel et veille à l'application de la réglementation. Un client qui veut monter son propre événement a donc une formalité à faire, pas seulement un lieu à réserver. Contacts du SMP : +225 27 22 42 88 79, 01 02 02 86 66, 05 45 11 43 17, info@commerce.gouv.ci. LE CALENDRIER est une publication officielle distribuée aux organisateurs, entreprises, municipalités, chambres de commerce, consulats et ambassades. Les manifestations y sont classées par secteur, et la liste des secteurs dit ce que le pays met en avant : agro-alimentation et agro-transformation, construction et décoration, commerce et tourisme, digitalisation et économie numérique, écologie et développement durable, éducation et recherche, INTELLIGENCE ARTIFICIELLE, inventions et innovations, promotion du genre, propriété intellectuelle, protection sociale et droit du travail. ⚠ ON Y TROUVE AUTANT DE FOIRES RÉGIONALES QUE DE SALONS ABIDJANAIS, Kani Expo, Boundiali Expo, foire régionale de Man, exposition d'Assinie : un plan qui ne prévoit qu'Abidjan passe à côté, exactement comme pour la radio. ⛔ RESTENT DUS : le décret 2018-546 lui-même avec ses conditions, délais et coûts d'agrément, les tarifs de stand, et le bilan chiffré d'une édition passée, introuvable.

## Contenu

### CL-FATIMA-16 · Les formats qui passent en bas débit et sur petits écrans
- **Pourquoi** : Une vidéo lourde ne se regarde pas
- **Où chercher** : Relevés de consommation réelle
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/RAPPORT_ARTCI_T1_2026_010626v3.pdf
- **Mis à jour** : 17/09/2026
- **Commentaire** : Cette pièce ne se trouve pas, elle se construit : partir de la répartition des technologies et de la couverture du rapport ARTCI, poser une règle de poids de page, puis l'éprouver. Aucune mesure ivoirienne de débit réel ni de poids acceptable n'existe en ligne. Petit chantier, pas une recherche.

### CL-FATIMA-24 · L'étiquetage et les mentions produit
- **Pourquoi** : Ce qui peut figurer sur un packaging décide de ce qu'on a le droit d'écrire dessus
- **Où chercher** : Codinorm, normes ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.codinorm.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Loi n° 2016-412 sur la consommation, Livre 1 « Information des consommateurs et formation des contrats » : 7 occurrences d'« étiquet » relevées le 20/09. ⚠ Version consolidée par un éditeur privé, le JO fait foi sur un point contesté. ⛔ Les normes CODINORM ne sont PAS dans la base : pour une mention normative de produit, la loi ne suffit pas. || Ajout du 17/09. Directement utile pour une cliente cosmétique comme Beauty Ivoire : les mentions obligatoires et les allégations autorisées se lisent dans la norme, pas dans l'usage.

## Droit

### CL-FATIMA-17 · Ce qui s'annonce et ce qui ne s'annonce pas : publicité et mentions
- **Pourquoi** : Une promesse chiffrée sans base expose le client
- **Où chercher** : Textes sur la publicité, autorité de régulation
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://csp.communication.gouv.ci/
- **Pièce, ici** : references/pieces/1ndBUjTXyl8nGUaNPq9eG1rI0mfbQrvHkhUUgpxw4DsM.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Base neuve bases-locales/publicite-ci/, lisible par les quinze postes. ⛔ LE POINT QUI SURPREND, et il est de circuit avant d'être de contenu : en Côte d'Ivoire un message publicitaire est validé AVANT diffusion, quel que soit le support, et les quatre métiers de la publicité s'exercent sous agrément (agence-conseil dans SIX catégories distinctes, régie, courtier, éditeur). Une agence agréée « en communication » n'existe pas, elle est agréée dans une catégorie. Trois régulateurs à ne pas confondre : le CSP pour la publicité, la HACA pour l'audiovisuel, l'ANP pour la presse. ⛔ ET L'ÉTAT DU DROIT EST INCERTAIN, C'EST ÉCRIT EN TÊTE DE LA NOTE : le texte le plus complet accessible, 121 articles hébergés par l'Assemblée nationale, est un PROJET DE LOI (son propre article premier dit « au sens du présent projet de loi »), adopté en commission le 9 décembre 2019, qui crée une Autorité de la communication publicitaire en remplacement du CSP. Sa promulgation n'a pas pu être établie, et le domaine acp-csp.com lié depuis le site du CSP NE RÉSOUT PLUS (vérifié le 22/09). Il se cite donc comme carte du terrain, jamais comme règle opposable à un client. Les pages « didacticiel » et « manquements aux obligations » du guichet sont des coquilles vides : ni tarif ni délai officiel n'en sort. Ce qui circule dans la presse (validation en 24 à 72 h, seuil de 25 000 abonnés pour les influenceurs, 157 axes et 2 000 emplacements réorganisés, décret 2007-676 sur l'affichage, CSP devenant Service de la communication publicitaire) est rangé dans une section « non vérifié », à confirmer au guichet avant tout usage. POUR CETTE LIGNE EN PROPRE : les interdits de contenu sont nommés article par article dans la note, dont ceux qu'aucune formation européenne ne donne : image et voix des personnalités politiques interdites, activités des partis interdites hors période électorale, symbole de l'État interdit sans autorisation ÉCRITE, représentation d'une personne interdite sans son autorisation préalable, et une liste de discrimination qui vise nommément l'ethnie, le clan, la tribu et la région. Secteurs fermés : tabac et ses substituts y compris cigarette électronique et narghilé, armes à feu et explosifs, établissements sanitaires, morgues et effets mortuaires. Alcool et médicaments sont renvoyés à décret. ⚠ L'ANNONCEUR EST RESPONSABLE de l'infraction commise dans la publicité diffusée pour son compte, et le délit de publicité mensongère est constitué dès lors que la publicité est faite, reçue OU PERÇUE en Côte d'Ivoire.

### CL-FATIMA-19 · Données personnelles : ce qu'il faut AVANT de constituer un fichier
- **Pourquoi** : Une campagne qui collecte des adresses sans autorisation expose le client, pas l'agence
- **Où chercher** : Autorité de protection des données, loi 2013-450
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.autoritedeprotection.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base données personnelles sur disque : loi n° 2013-450 du 19/06/2013 telle que publiée au Journal officiel du 08/08/2013 (p. 474 à 482), plus une seconde numérisation, la loi 2013-451 cybercriminalité et la loi 2013-546 transactions électroniques. La compétence donnees-personnelles-ci (Y0676) en est le mode d'emploi. ⛔ CES PDF N'ONT PAS DE COUCHE TEXTE : ce sont des numérisations du JO, il faut les LIRE, l'extraction ne rend rien. || Ajout du 17/09, validé par l'équipe. À placer avant plusieurs des 18. Loi 2013-450 du 19/06/2013 : tout traitement de données personnelles est soumis à déclaration ou autorisation préalable, ce qui vise explicitement les fichiers de clientèle, et le traitement ne peut commencer qu'après réception de l'autorisation. Une Autorité de protection dédiée recense les responsables de traitement et les correspondants. PRÉCISION DU 18/09, la formulation précédente était imprécise et la nuance change la charge : le régime GÉNÉRAL de la loi n°2013-450 du 19/06/2013 est la DÉCLARATION PRÉALABLE de tout traitement de données personnelles à l'ARTCI avant sa mise en œuvre, l'AUTORISATION ne visant que certaines catégories de traitements. L'ARTCI, autorité administrative indépendante et autorité de protection au titre de cette loi, statue dans un délai d'UN MOIS à compter de la réception, prorogeable d'un mois par décision motivée. Elle a un pouvoir de sanction, et les manquements sont aussi punis au titre du code pénal. ⚠ TEXTE PRIMAIRE NON RAPATRIÉ : le lien du PDF sur le site de l'ARTCI renvoie une page « non trouvée » depuis sa restructuration, et les miroirs habituels ne le portent pas. Ce qui précède vient de sources secondaires concordantes. LU SUR LE TEXTE LE 18/09 : la loi est désormais sur la machine (~/.claude/outils-communs/donnees-personnelles-ci/, Journal officiel du 08/08/2013, p. 474 à 482) et lue article par article. Ce qui change par rapport à ce qui précède. (1) ART. 11, LE SILENCE VAUT REJET : l'ARTCI statue en un mois, prorogeable d'un mois par décision motivée, et l'ABSENCE DE REPONSE dans ce délai vaut REJET de la déclaration ou de la demande, pas acceptation ; recours devant la juridiction compétente. (2) ART. 7, SIX CATEGORIES SOUS AUTORISATION et non déclaration : données génétiques ou médicales et recherche scientifique ; infractions et condamnations ; NUMERO NATIONAL D'IDENTIFICATION OU TOUT IDENTIFIANT DE MEME NATURE, Y COMPRIS LES NUMEROS DE TELEPHONE ; données biométriques ; traitement d'intérêt public à fins historiques, statistiques ou scientifiques ; TRANSFERT VERS UN PAYS TIERS. (3) ART. 6, QUATRE DISPENSES de déclaration, dont la désignation d'un correspondant à la protection des données (art. 12), dispense qui TOMBE dès qu'un transfert hors du pays est envisagé. (4) ART. 26, tout transfert hors de Côte d'Ivoire suppose un pays au niveau de protection suffisant ET l'autorisation préalable de l'ARTCI : un hébergement ou un outil de gestion client à l'étranger est un transfert. (5) ART. 51, SANCTIONS : après mise en demeure, retrait d'autorisation et sanction pécuniaire plafonnée à 10 000 000 FCFA, portée en cas de récidive dans les cinq ans à 100 000 000 FCFA ou, pour une entreprise, 5 % du chiffre d'affaires hors taxes du dernier exercice clos dans la limite de 500 000 000 FCFA, sans préjudice du pénal. (6) ART. 46, l'autorité de protection EST l'ARTCI, il n'y a pas d'autorité distincte. (7) ART. 28 à 38, droits des personnes : information au plus tard à la collecte, accès, opposition gratuite à la prospection, rectification, effacement sans délai (art. 35), portabilité. COMPETENCE ECRITE LE 18/09 : donnees-personnelles-ci (Y0676), au catalogue, adossée à ces articles. ART. 22, LE POINT QUI EXPOSE LE PLUS : la prospection directe par tout moyen de communication, en utilisant les données d'une personne physique QUI N'A PAS EXPRIME SON CONSENTEMENT PREALABLE à recevoir des prospections, est punie d'UN AN D'EMPRISONNEMENT et de 1 000 000 à 10 000 000 FCFA d'amende. Une base de numéros achetée, collectée en salon, aspirée d'un annuaire ou extraite d'un groupe de messagerie ne porte aucun consentement. La question à poser avant d'écrire une séquence n'est pas quel message, mais d'où vient ce numéro et qu'a accepté son titulaire. ART. 21 : les données révélant l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses ou philosophiques, l'appartenance syndicale, la vie sexuelle ou l'état de santé sont interdites, sous peine d'UN A CINQ ANS d'emprisonnement et de 20 à 40 millions FCFA.

### CL-FATIMA-20 · Le CSP comme circuit : qui dépose, quelles pièces, quel délai, quel coût
- **Pourquoi** : Une règle qu'on connaît sans savoir l'appliquer ne sert à rien
- **Où chercher** : Guichet en ligne du Conseil Supérieur de la Publicité
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://csp.communication.gouv.ci/
- **Pièce, ici** : references/pieces/1ndBUjTXyl8nGUaNPq9eG1rI0mfbQrvHkhUUgpxw4DsM.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, avec une réserve nommée. Base neuve bases-locales/publicite-ci/, lisible par les quinze postes. ⛔ LE POINT QUI SURPREND, et il est de circuit avant d'être de contenu : en Côte d'Ivoire un message publicitaire est validé AVANT diffusion, quel que soit le support, et les quatre métiers de la publicité s'exercent sous agrément (agence-conseil dans SIX catégories distinctes, régie, courtier, éditeur). Une agence agréée « en communication » n'existe pas, elle est agréée dans une catégorie. Trois régulateurs à ne pas confondre : le CSP pour la publicité, la HACA pour l'audiovisuel, l'ANP pour la presse. ⛔ ET L'ÉTAT DU DROIT EST INCERTAIN, C'EST ÉCRIT EN TÊTE DE LA NOTE : le texte le plus complet accessible, 121 articles hébergés par l'Assemblée nationale, est un PROJET DE LOI (son propre article premier dit « au sens du présent projet de loi »), adopté en commission le 9 décembre 2019, qui crée une Autorité de la communication publicitaire en remplacement du CSP. Sa promulgation n'a pas pu être établie, et le domaine acp-csp.com lié depuis le site du CSP NE RÉSOUT PLUS (vérifié le 22/09). Il se cite donc comme carte du terrain, jamais comme règle opposable à un client. Les pages « didacticiel » et « manquements aux obligations » du guichet sont des coquilles vides : ni tarif ni délai officiel n'en sort. Ce qui circule dans la presse (validation en 24 à 72 h, seuil de 25 000 abonnés pour les influenceurs, 157 axes et 2 000 emplacements réorganisés, décret 2007-676 sur l'affichage, CSP devenant Service de la communication publicitaire) est rangé dans une section « non vérifié », à confirmer au guichet avant tout usage. POUR CETTE LIGNE EN PROPRE, qui demandait la PROCÉDURE : ce que le guichet expose est acquis (quatre professions, six catégories d'agence, trois objets déposables que sont le message, le support et l'agrément, plus la pige, et les coordonnées info.csp@communication.gouv.ci et trois lignes téléphoniques). CE QUI MANQUE ET QUI N'EST PAS DE MA MAIN : les pièces exactes du dossier, le délai officiel et le coût ne sont publiés nulle part. Les pages prévues pour ça sur le site sont vides. Les 24 à 72 heures viennent de la presse et sont marquées comme telles. La suite n'est pas une recherche, c'est un appel au guichet.

### CL-FATIMA-23 · La marque avant la campagne : le dépôt OAPI
- **Pourquoi** : Un nom n'est pas retenu tant qu'il n'est pas libre
- **Où chercher** : Organisation africaine de la propriété intellectuelle
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://oapi.int/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OAPI sur disque. Le point qui commande tout : en Côte d'Ivoire IL N'EXISTE PAS de droit national des marques et des brevets à côté de l'Accord de Bangui, dont l'article 5 dit que l'Accord et ses Annexes « tiennent lieu de lois relatives aux matières qu'ils visent ». Un dépôt OAPI vaut pour les DIX-SEPT États membres, il n'y a pas de dépôt ivoirien séparé : conseiller « un dépôt national puis un dépôt régional » est une erreur de fait. ⚠ Exception : l'Annexe VII, propriété littéraire et artistique, n'est qu'un cadre minimal, le droit d'auteur reste pour partie national. || Ajout du 17/09. Le dépôt coûte 360 000 FCFA hors honoraires, chiffre déjà mesuré sur le chantier de la marque malgache où il représentait 72 % du budget branding annoncé. Lancer une campagne sur un nom non déposé, c'est payer deux fois. AJOUT DU 18/09 : LE TEXTE EST MAINTENANT SUR LA MACHINE, ~/.claude/outils-communs/oapi/, Accord de Bangui révisé le 14/12/2015 à Bamako avec ses dix annexes, et règlement d'application du 08/12/2020 pris sur oapi.int. Ce qui était dit de seconde main se cite désormais par article. Trois points à reprendre de la fiche : l'article 5 dit que l'Accord et ses annexes TIENNENT LIEU DE LOIS dans les États membres, donc pas de dépôt ivoirien séparé ; la marque se conserve sans limitation de durée par renouvellements TOUS LES DIX ANS, demandés au cours de la dernière année ; la révision de 2015 n'est en vigueur que DEPUIS LE 14 NOVEMBRE 2020, un titre antérieur relève de l'Acte de 1999. Le barème des taxes n'est pas dans le texte et se vérifie sur oapi.int avant tout chiffrage.

### CL-FATIMA-25 · La fiscalité de la publicité
- **Pourquoi** : Un budget média annoncé hors taxe est un budget faux
- **Où chercher** : Direction générale des impôts, code général des impôts
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dgi.gouv.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base fiscale sur disque : Code général des impôts édition 2025 de la DGI (9 762 paragraphes), annexe fiscale à la loi de finances 2025-987 du 19/12/2025 pour le budget 2026 (41 mesures), et deux synthèses DGI. ⚠ Chercher dans cgi-2025-recolle.txt (césures de colonnes recollées), citer depuis cgi-2025.txt. TVA 18 %, taux réduit 9 %. La publicité y est traitée : 12 occurrences relevées le 20/09 dans le CGI recollé. ⛔ Lire l'article avant de chiffrer une taxe publicitaire. || Ajout du 17/09. Le code général des impôts comprend des taxes sur la publicité et l'affichage. C'est le client qui découvre la différence si elle n'est pas dite au devis.

### CL-FATIMA-29 · Le droit à l'image : publier la photo d'une personne
- **Pourquoi** : Publier un visage sans consentement conforme expose le client, donc la maison
- **Où chercher** : Loi 2013-450, Journal officiel du 8 août 2013 ; code pénal pour la vie privée
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/images/stories/pdf/lois/loi_2013_450.pdf
- **Pièce, ici** : references/pieces/180zr1uHf3xoHciq3UzSAOS-E1yWLVK6dk2N0d4ErWls.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : AJOUTÉ ET INTÉGRÉ LE 22/09, sujet qui ne figurait dans AUCUN onglet alors qu'il porte un risque juridique direct. ⛔ IL N'Y A PAS DE LOI IVOIRIENNE DU DROIT À L'IMAGE : le régime a deux étages. (1) La loi 2013-450 du 19/06/2013 range en son article premier « le son et l'image relative à une personne physique identifiable » dans les DONNÉES À CARACTÈRE PERSONNEL : photographier quelqu'un d'identifiable, c'est traiter une donnée personnelle. (2) Son article 24 réserve expressément le CODE PÉNAL et le droit de la presse pour les atteintes à la vie privée et à la réputation. LE CONSENTEMENT EST DÉFINI À L'ARTICLE PREMIER : manifestation de volonté EXPRESSE, NON ÉQUIVOQUE, LIBRE, SPÉCIFIQUE ET INFORMÉE. Donc un accord tacite ne vaut rien, un accord général « pour la communication » n'est pas spécifique, et un accord donné sans savoir à quoi servira l'image n'est pas informé. ⛔ DEUX PEINES À CONNAÎTRE : art. 21, données révélant l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses, l'appartenance syndicale, la vie sexuelle, les données génétiques ou l'état de santé = 10 À 20 ANS et 20 à 40 MILLIONS FCFA. Cela vise directement le travail d'image : un reportage dans un lieu de culte ou un visuel illustrant une communauté tombe dans les données sensibles. Art. 22, prospection directe sans consentement préalable = 1 À 5 ANS et 1 à 10 millions FCFA. ⚠ CORRECTION : une réponse antérieure de la maison annonçait « 1 an » pour l'article 22 ; le texte dit UN À CINQ ANS, vérifié à l'œil sur la page du Journal officiel du 8 août 2013 p. 478. ⚠ L'ARTICLE 16 EST CELUI QU'ON OUBLIE : finalités déterminées. Une image prise pour un reportage interne NE SE RÉEMPLOIE PAS dans une campagne : changement de finalité, donc nouveau consentement. ⛔ L'EXCEPTION DE L'ARTICLE 23 NE COUVRE PAS LA PUBLICITÉ : elle vise le journalisme, la recherche et l'expression artistique ou littéraire, AUX SEULES FINS de celles-ci. Une campagne de marque n'est ni du journalisme ni de l'art. ⛔ CE QUE LA PIÈCE NE COUVRE PAS : le code pénal ivoirien n'est pas sur disque, donc les peines d'atteinte à la vie privée que l'art. 24 réserve ne sont pas chiffrées ; la loi sur la presse n'est pas rapatriée ; les formalités déclaratives à l'Autorité de protection des données ne sont pas relevées article par article ; aucune décision de justice ivoirienne n'a été consultée, c'est le texte et non son application.

## Références

### CL-FATIMA-18 · Les campagnes locales qui ont marqué, et pourquoi
- **Pourquoi** : Inventer un exemple faute d'en connaître un vrai
- **Où chercher** : Presse, archives des agences
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://csp.communication.gouv.ci/publicite/agence-conseil
- **Mis à jour** : 17/09/2026
- **Commentaire** : Le point le plus faible des 18, dit comme tel plutôt que rempli de mémoire. Deux pistes : le Grand Jury de la Publicité Africaine (7e édition le 15 juin à Abidjan, organisée par Odyssée Pub), un palmarès étant une liste datée et jugée ; et surtout la liste des agences-conseil agréées du CSP, les agences agréées étant les auteurs des campagnes. Ni palmarès complet ni archive de campagnes en ligne.

### CL-FATIMA-26 · Le paysage des agences locales
- **Pourquoi** : Savoir contre qui on se compare avant de proposer un prix ou un parti pris
- **Où chercher** : Liste des agences-conseil agréées du CSP
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://csp.communication.gouv.ci/
- **Pièce, ici** : references/pieces/1ndBUjTXyl8nGUaNPq9eG1rI0mfbQrvHkhUUgpxw4DsM.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, avec une réserve nommée. Base neuve bases-locales/publicite-ci/, lisible par les quinze postes. ⛔ LE POINT QUI SURPREND, et il est de circuit avant d'être de contenu : en Côte d'Ivoire un message publicitaire est validé AVANT diffusion, quel que soit le support, et les quatre métiers de la publicité s'exercent sous agrément (agence-conseil dans SIX catégories distinctes, régie, courtier, éditeur). Une agence agréée « en communication » n'existe pas, elle est agréée dans une catégorie. Trois régulateurs à ne pas confondre : le CSP pour la publicité, la HACA pour l'audiovisuel, l'ANP pour la presse. ⛔ ET L'ÉTAT DU DROIT EST INCERTAIN, C'EST ÉCRIT EN TÊTE DE LA NOTE : le texte le plus complet accessible, 121 articles hébergés par l'Assemblée nationale, est un PROJET DE LOI (son propre article premier dit « au sens du présent projet de loi »), adopté en commission le 9 décembre 2019, qui crée une Autorité de la communication publicitaire en remplacement du CSP. Sa promulgation n'a pas pu être établie, et le domaine acp-csp.com lié depuis le site du CSP NE RÉSOUT PLUS (vérifié le 22/09). Il se cite donc comme carte du terrain, jamais comme règle opposable à un client. Les pages « didacticiel » et « manquements aux obligations » du guichet sont des coquilles vides : ni tarif ni délai officiel n'en sort. Ce qui circule dans la presse (validation en 24 à 72 h, seuil de 25 000 abonnés pour les influenceurs, 157 axes et 2 000 emplacements réorganisés, décret 2007-676 sur l'affichage, CSP devenant Service de la communication publicitaire) est rangé dans une section « non vérifié », à confirmer au guichet avant tout usage. POUR CETTE LIGNE EN PROPRE, qui demandait le PAYSAGE DES AGENCES : la nomenclature officielle est acquise et c'est elle qui structure le marché, six catégories d'agence-conseil qui ne font pas le même métier. ⛔ EN REVANCHE LA LISTE NOMINATIVE DES AGENCES AGRÉÉES N'EST PAS ACCESSIBLE SANS COMPTE sur le guichet, vérifié le 22/09 : la page publique ne sert que la nomenclature. L'avantage annoncé le 17/09, « une liste officielle plutôt qu'un classement d'annuaire payant », n'est donc pas disponible en l'état. Pour un benchmark, la catégorie d'agrément d'un concurrent se demande au CSP ou se lit sur ses propres publications.

## Marque et identité

### CL-FATIMA-28 · Carte des design systems de l'espace Figma Yelema
- **Pourquoi** : Un contenu produit aux mauvaises couleurs signale au lecteur qu'il vient de l'extérieur. La carte dit quel fichier porte l'identité réelle de la marque.
- **Où chercher** : Espace Figma de l'équipe Yelema, relevé par integrations/figma/lister.py
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **Commentaire** : Demandé par la direction le 22/09/2026. Carte engendrée, régénérable.
