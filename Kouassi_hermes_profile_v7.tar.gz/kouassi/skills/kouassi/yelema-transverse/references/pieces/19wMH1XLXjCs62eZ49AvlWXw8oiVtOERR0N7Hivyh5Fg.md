# 260922_Qui signe, qui approuve, qui paie dans un achat public ivoirien

===== onglet t.0 · Tab 1 · 40 lignes non vides =====

# Qui signe, qui approuve, qui paie dans un achat public ivoirien
Écrite le 22/09/2026 sur le Code des marchés publics, loi 2019-679, présent dans cette base. Elle sert une question commerciale : à qui parle-t-on, et à quel moment ?

⛔ La faute la plus coûteuse est de traiter le signataire comme le décideur. Ici, celui qui signe et celui qui approuve ne peuvent jamais être la même personne (art. 18.1), et un marché non approuvé est nul (art. 18.2.7). Un contrat signé et non approuvé ne vaut rien, et la facture qui va avec non plus.
## Les cinq rôles, et qui les tient
| Rôle | Qui | Article |
| Coordonne la chaîne | la personne responsable des marchés, désignée parmi les directeurs de Cabinet du ministre | art. 12 |
| Prépare, planifie, suit | la cellule de passation des marchés, placée sous l'autorité de la personne responsable | art. 13 |
| Choisit l'attributaire | la commission d'ouverture des plis et de jugement des offres, auprès de l'autorité contractante | art. 14 |
| Signe | l'autorité qui a qualité pour représenter la personne morale | art. 18.1 |
| Approuve | une autre autorité, qui dépend du montant et de la nature de l'acheteur | art. 18.2 |
| Paie | le comptable assignataire, qui émet le titre de règlement | art. 139, 142 |

⚠ Le fait le plus opérationnel de cette fiche : dans un ministère, la personne responsable des marchés est le directeur de Cabinet. Le poste est au sommet du cabinet, pas dans un service technique.
## Qui siège à la commission qui attribue
Pour une administration centrale, un service à compétence nationale, un établissement public national ou un projet (art. 14.1.1) :

- le responsable de la cellule de passation des marchés, qui préside ;
- un représentant de l'unité de gestion administrative, du maître d'ouvrage ou du maître d'ouvrage délégué ;
- le spécialiste en passation des marchés, pour les projets ;
- un représentant du maître d'œuvre, s'il existe ;
- un représentant de chacun des services utilisateurs ;
- un représentant du ministère exerçant la tutelle sur l'objet de la dépense ;
- le contrôleur financier ou budgétaire placé auprès de l'autorité contractante.

⚠ Le service utilisateur est représenté, mais il ne décide pas seul. Convaincre l'utilisateur final et ignorer la cellule de passation revient à gagner une voix sur sept. ⚠ Le contrôleur financier est dans la salle dès l'attribution, pas seulement au paiement.
## Qui approuve, selon le montant et l'acheteur
| Acheteur et montant | Autorité approbatrice | Article |
| État ou établissement public, montant ≥ seuil de validation de la structure de contrôle | ministre chargé des Marchés publics | 18.2.1 |
| Services centraux ou établissements publics, montant < ce seuil | ministre de tutelle de l'unité de gestion administrative | 18.2.2 |
| Services extérieurs, établissements publics nationaux et projets situés en région | le préfet du département | 18.2.3 |
| Sociétés d'État et personnes morales de l'article 2 | le Conseil d'administration | 18.2.4 |

Délégation possible (18.2.6) : chaque autorité approbatrice peut déléguer par arrêté ou décision, et un Conseil d'administration peut déléguer au directeur général dans les limites d'un seuil qu'il fixe par délibération. ⚠ Avant de viser un directeur général de société d'État, vérifier jusqu'à quel montant il a reçu délégation.
## Le calendrier de l'approbation
Le dossier remonte accompagné de l'avis de la structure administrative chargée du contrôle des marchés publics. L'autorité approbatrice dispose alors de sept jours au maximum à compter de la réception du dossier, puis l'approbation est notifiée à l'unité de gestion administrative dans un délai de trois jours (art. 83.1 à 83.4).

ℹ Le texte est rédigé ainsi : dans ce délai, « s'il ne prend pas une décision de refus d'approbation », l'autorité approuve. ⚠ Ne pas en faire une approbation tacite : c'est un délai pour agir, et le Code ne dit pas ce qui se passe au-delà. Non tranché ici.
## Et l'argent
Détail complet dans DELAIS-DE-PAIEMENT.md, de la même base. En bref : 90 jours au maximum pour les acomptes et le solde (art. 139), 45 jours pour le paiement d'une avance (art. 132), et des intérêts moratoires au taux légal majoré d'un point, qui courent jusqu'à l'émission du titre de règlement par le comptable assignataire mais ne sont dus que sur demande motivée (art. 142).

⚠ Le chemin de l'argent suit le sien. On peut avoir convaincu tout le monde et attendre le comptable.
## Ce que cette fiche ne couvre pas, et c'est délibéré
⛔ Le circuit de décision dans une entreprise PRIVÉE ivoirienne n'est publié nulle part. Aucune source officielle, aucune étude accessible. Ce que nous en savons vient de nos propres missions : cela vit dans maison-et-clients/ et ne se cite pas comme un fait sur le pays. La distinction est le cœur du sujet : ce qui est ici est opposable, ce qui est là-bas est de l'expérience.

- Les seuils chiffrés de passation et de validation : fixés par décret, pas par le Code. ⟦à chercher⟧
- Les marchés des collectivités territoriales, qui ont leurs propres autorités.

À revérifier le 22/03/2027.
