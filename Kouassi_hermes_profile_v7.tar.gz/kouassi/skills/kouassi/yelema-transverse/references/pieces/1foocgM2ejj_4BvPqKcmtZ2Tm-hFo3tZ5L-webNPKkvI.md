# 260922_Quels secteurs font vraiment des affaires en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 55 lignes non vides =====

# Quels secteurs font vraiment des affaires ici
Écrite le 22/09/2026, sur des séries publiques rapatriées de data.gouv.ci le même jour et rangées dans jeux-data-gouv-ci/. Elle sert une question de prospection : où va-t-on frapper, et sur quoi fonde-t-on ce choix ?
## ⛔ Le piège de cette fiche, à lire avant les chiffres
Les deux séries de chiffre d'affaires ci-dessous sont des indices en base 100. Un indice dit comment un secteur a évolué par rapport à lui-même, jamais quelle est sa taille. Un indice à 301 n'est pas trois fois plus gros qu'un indice à 100 : il a triplé par rapport à sa propre base. Classer des secteurs par leur indice pour dire lequel est le plus gros est faux, et l'erreur est invisible à la relecture.

Pour la taille, il faut une valeur ajoutée en francs, qui n'est pas dans ces fichiers. ⟦à chercher : la comptabilité nationale de l'ANStat, dont l'accès est décrit dans le LISEZ-MOI.md de cette base⟧
## Ce qui a le plus accéléré dans l'industrie
jeux-data-gouv-ci/ica-industrie-par-type.csv, indice mensuel du chiffre d'affaires, mars 2021 à mars 2022, nomenclature NAEMA rév. 1. Moyenne de l'indice sur la période :

| Secteur | Indice moyen |
| Collecte, traitement et élimination des déchets, récupération | 301,2 |
| Industries environnementales | 280,2 |
| Autres activités extractives | 274,8 |
| Extraction de minerais métalliques | 229,0 |
| Produits à base de tabac | 210,2 |
| Équipements électriques | 207,1 |
| Travail du bois hors meubles | 195,5 |
| Produits chimiques | 187,5 |
| Métallurgie | 178,2 |

À l'autre bout, en repli : fabrication d'autres matériels de transport (41,3), cuir et chaussures (68,7), produits pharmaceutiques (91,0), réparation et installation de machines (94,5), activités de soutien aux industries extractives (99,5).

⚠ Trois défauts de ce fichier qu'il faut connaître avant de s'en servir.

- Agrégats et sous-secteurs sont mélangés dans la même colonne. « Industries électroniques, informatiques, électriques et de machines » et « Fabrication d'équipements électriques » portent exactement le même indice, 207,1. Les additionner compte deux fois.
- Certaines séries sont trop volatiles pour dire quoi que ce soit : la fabrication d'articles d'habillement va de 6,1 à 463,3 sur treize mois, ce qui signale une base minuscule plutôt qu'une industrie qui s'effondre puis explose. Ne pas la citer.
- La série s'arrête en mars 2022. Elle ne dit rien de 2026.
## Le commerce, et une rupture de nomenclature
jeux-data-gouv-ci/ica-commerce-par-division.csv, indice trimestriel, 2015 à 2020, base 100 en 2015. Évolution sur la période :

| Sous-division | 2015 | 2020 | Évolution |
| Commerce de gros de produits intermédiaires non agricoles | 100 | 273,3 | +173 % |
| Entretien et réparation de véhicules automobiles | 100 | 198,7 | +99 % |
| Commerce de gros de biens de consommation non alimentaires | 100 | 166,9 | +67 % |
| Commerce de véhicules automobiles | 100 | 160,0 | +60 % |
| Pièces détachées et accessoires automobiles | 100 | 123,9 | +24 % |
| Commerce de gros de produits agricoles bruts et alimentaires | 100 | 116,0 | +16 % |
| Commerce de gros non spécialisé | 100 | 65,9 | -34 % |

⛔ Le libellé change d'orthographe entre 2015 et 2020 (« detail » devient « détail », « reparation » devient « réparation »). Un rapprochement fait sur le libellé perd trois séries en silence et en invente trois autres. Rapprocher sur le code NAEMA, jamais sur le texte.
## Le tissu réel d'Abidjan, compté
jeux-data-gouv-ci/petits-commerces-abidjan.csv : 2 761 petits commerces et services géolocalisés. C'est un relevé de terrain, sans prétention de représentativité, et il vaut pour ce qu'il montre.

| Catégorie | Points |  | Catégorie | Points |
| Accessoires de beauté | 392 |  | Cosmétiques | 192 |
| Coiffeurs et coiffeuses | 309 |  | Réparation de voitures | 178 |
| Transfert d'argent | 283 |  | Artisanat | 146 |
| Quincaillerie | 224 |  | Accessoires téléphones | 118 |
| Nettoyage à sec | 209 |  | Lavage de voitures | 100 |

L'enseignement : parmi les activités nommées une à une, les trois premières marques du relevé sont des agents de transfert d'argent, Mobil Money 49, Orange Money 39, Mobile Money 28, soit 116 points à elles seules, devant le garbadrome 47 et le vulcanisateur 44. Un commerce de rue sur dix à Abidjan est un point de paiement. Voir paiement-ci/.
## Un secteur mesuré en francs, et un seul : les télécommunications
numerique-ci/releves/operateurs-investissements-ca.csv, déclarations des opérateurs. Chiffre d'affaires hors taxes, en milliards de FCFA :

| Opérateur | CA 2023 | CA 2024 | Investissement 2024 |
| Orange | 778,2 | 839,1 | 101,7 |
| MTN | 431,7 | 414,0 | 46,2 |
| Moov | 311,9 | 340,0 | 51,0 |
| GVA | 4,2 | 6,6 | 4,9 |
| VipNet | 4,6 | 3,0 | 0,5 |

Par service en 2024 : téléphonie mobile 975,2 · Internet mobile 473,4 · téléphonie fixe 87,2 · Internet fixe 70,0.

⛔ 2025 n'est qu'un trimestre dans ce fichier. Ne jamais le comparer à une année pleine. ⚠ Orange pèse à lui seul plus que MTN et Moov réunis, et investit deux fois plus que MTN. ⚠ L'Internet fixe reste marginal, 70 contre 473 pour le mobile : cohérent avec le parc d'appareils décrit dans numerique-ci/PARC-ECRANS-ET-APPAREILS.md.
## Sur le cycle de décision
La moitié publique est documentée et opposable : marches-publics-ci/QUI-SIGNE-QUI-APPROUVE-QUI-PAIE.md. Le cycle de décision d'une entreprise privée ivoirienne n'est publié nulle part ; ce que nous en savons vient de nos missions et vit dans maison-et-clients/, qui n'est pas une source sur le pays.

Séries rapatriées le 22/09/2026. À revérifier le 22/03/2027.
