# 260922_Trouver et verifier une entreprise ivoirienne

===== onglet t.0 · Tab 1 · 32 lignes non vides =====

# Trouver et vérifier une entreprise ivoirienne
Écrite le 22/09/2026. Elle répond à une question de prospection : cette entreprise existe-t-elle vraiment, et comment s'appelle-t-elle en droit ? Une liste de prospects qui ne passe pas par là est une liste inventée.
## L'annuaire public, et il est réel
https://www.idu.ci/annuaire-entreprise.xhtml — « Consulter l'annuaire des entreprises ». Ouvert, sans compte, cherchable par numéro IDU, par dénomination sociale et par secteur d'activité.

Pour chaque entreprise trouvée, la fiche rend :

| Champ | Ce qu'il sert à faire |
| Dénomination sociale et nom commercial | écrire le bon nom dans un contrat, qui n'est presque jamais le nom d'enseigne |
| Numéro IDU | la clé d'identification unique instituée par l'ordonnance 2015-182 du 24/03/2015, modifiée par l'ordonnance 2018-644 du 1er août 2018 |
| Forme juridique et montant du capital social | jauger la taille et savoir qui engage la société |
| N° RCCM et date d'immatriculation | l'ancienneté réelle, pas celle du site web |
| N° compte contribuable et date | l'entreprise est connue de l'impôt |
| N° CNPS et date | l'entreprise déclare des salariés |

⚠ Trois dates d'immatriculation coexistent sur la fiche, une par registre. Elles ne sont pas toujours les mêmes, et c'est instructif : une société immatriculée au RCCM depuis des années mais sans numéro CNPS n'emploie personne officiellement.
## Ce que l'annuaire ne permet pas, et pourquoi
⛔ Aucune extraction en masse. Le formulaire est une page JSF / PrimeFaces : la recherche part en POST avec un jeton de vue, et notre outil public est volontairement sans compte, sans cookie et sans session. On interroge une entreprise à la fois, à la main. Ce n'est pas une panne, c'est la limite de l'outil, et il ne sera pas contourné.

⛔ On ne peut donc pas en tirer une liste par secteur. L'annuaire vérifie un nom qu'on a déjà ; il ne fabrique pas un fichier de prospection.
## Les autres portes, et ce qu'elles donnent vraiment
| Porte | État au 22/09/2026 |
| CEPICI | immatricule, n'édite pas d'annuaire. cepici.gouv.ci redirige vers cepici.ci, qui répond 307 sans cible depuis cette machine |
| annuaire.cci.ci, Chambre de commerce | le sous-domaine existe et répond 403 Forbidden, à l'outil comme au navigateur. Corps Apache nu, aucun marqueur Cloudflare : c'est un refus du serveur, pas une épreuve. Rien à contourner de notre côté |
| data.gouv.ci | ✅ l'API répond, mais pas sur les chemins usuels : le bon est data-fair/api/v1/datasets?q=<mot> (les chemins udata et CKAN rendent 404, et j'ai d'abord conclu à tort qu'il n'y avait pas d'API). Aucun registre d'entreprises, mais un relevé de terrain utile : smallbusinessabidjan, 2 761 petits commerces et services géolocalisés d'Abidjan, avec catégorie et nom d'activité, rapatrié dans statistiques-ci/jeux-data-gouv-ci/petits-commerces-abidjan.csv. ⚠ Relevé de terrain, sans prétention de représentativité, et sans nom légal ni identifiant : il repère un tissu, il ne remplace pas idu.ci |
| BRVM | ✅ la seule liste publique, nominative et complète que nous détenions : les 47 sociétés cotées, dans financement-ci/BRVM.md. Ce sont les plus grandes maisons de la place et de l'UEMOA |
## Comment s'en servir pour prospecter
- Construire la liste ailleurs : presse économique, cotation BRVM, annonces de recrutement, salons du ministère du Commerce (evenements-ci/).
- Vérifier chaque nom sur idu.ci avant de l'appeler : nom légal, forme, capital, ancienneté, présence à la CNPS.
- Écrire le nom légal dans le contrat, jamais l'enseigne.

⚠ Le portail data.gouv.ci est une instance mutualisée : sur 526 jeux de données annoncés, 256 seulement sont ivoiriens, le reste appartient à Enedis, EDF, l'ADEME, Grand Poitiers. Une recherche naïve y rend des données françaises. Détail dans statistiques-ci/LISEZ-MOI.md.
## Ce qui reste dû
- ⟦à chercher⟧ Une source qui donne une liste par secteur. Trois portes essayées et écartées ci-dessus ; la piste non essayée est le fichier des adhérents des groupements professionnels, qui se demande, il ne se télécharge pas.
- Le poids économique par secteur, qui est une autre question, traitée dans statistiques-ci/.

ℹ Les listes nominatives de prospects de la maison ne sont pas ici. Elles existent, elles vivent dans maison-et-clients/, et elles ne remplacent pas un annuaire public : elles disent qui nous visons, pas qui existe.

À revérifier le 22/03/2027.
