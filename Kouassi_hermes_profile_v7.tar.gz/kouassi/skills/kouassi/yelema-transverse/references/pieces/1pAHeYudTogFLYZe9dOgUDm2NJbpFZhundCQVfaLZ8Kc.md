# 260922_Delais de paiement de l'Etat ivoirien - Code des marches publics et realite

===== onglet t.0 · Tab 1 · 32 lignes non vides =====

# Se faire payer par l'État ivoirien : ce que dit le Code, et ce qui se passe
Écrite le 22/09/2026. Elle sert une question commerciale, pas juridique : combien de temps entre la livraison et l'argent, et que promettre à un client qui vend à l'État.

⛔ Le délai de 90 jours est dans le Code, pas dans la coutume. Il était jusqu'ici cité chez nous d'après une source de second rang ; il vient du Code des marchés publics de 2019, présent dans cette base, et il s'accompagne d'intérêts moratoires automatiques.
## Ce que le Code impose
| Situation | Délai | Article |
| Acomptes et solde dus par l'autorité contractante | ne peut dépasser 90 jours, mais un délai plus long peut être fixé pour le solde | art. 139 |
| Paiement d'une avance, à compter de la réception de la garantie | 45 jours maximum | art. 132 |
| Paiement des intérêts moratoires, après demande | 60 jours maximum après réception de la demande | art. 142 |
| Acheminement par le titulaire d'une demande de paiement d'un sous-traitant | 10 jours maximum, sauf refus motivé | art. 137 |

Des délais plus courts peuvent être accordés aux petites et moyennes entreprises, ou dans le cadre de projets spécifiques, au vu de leur urgence ou de leur caractère social (art. 139). C'est une disposition à connaître : elle se demande, elle ne s'obtient pas d'office.
## Les intérêts moratoires, article 142
- Le retard ouvre droit au versement d'intérêts moratoires au titulaire.
- Taux : l'intérêt légal en vigueur, majoré d'un point. Calcul en jours calendaires, sur des années de 365 jours.
- Ils courent du jour suivant l'expiration des délais des articles 132 et 139, jusqu'au jour où le comptable assignataire émet le titre de règlement.
- ⛔ Ils ne sont pas automatiques en pratique : ils sont dus sur demande motivée et chiffrée du titulaire. Un fournisseur qui ne demande rien ne reçoit rien.
- Ils se capitalisent un an après la date à laquelle leur paiement était échu, sauf stipulation contraire du marché.
- Aucun avenant n'est nécessaire pour les payer.
- ⚠ Deux exclusions : ils ne portent que sur les sommes dues au titre des prestations réalisées, et le retard de paiement des avances n'est pas sanctionné par des intérêts moratoires. Attendre une avance ne se monnaie pas.
- Si le titulaire est débiteur de droits et taxes sur son chiffre d'affaires au moment de l'encaissement, les intérêts se calculent déduction faite de ces taxes.
## Ce que disent les chiffres, et ce que dit le contre-chiffre
Les deux se citent ensemble, parce que c'est l'écart qui porte l'information commerciale.

| Source | Ce qu'elle dit |
| Direction générale du Trésor | 1 556,8 Md FCFA payés à 6 721 fournisseurs au 31/12/2025 ; 416,98 Md à 2 870 fournisseurs au premier semestre 2026 |
| SYNAFECI, syndicat des fournisseurs de l'État | plus de 39,04 Md d'impayés réclamés en juillet 2025, dont le Trésor ne reconnaissait que 1,8 Md ; un sit-in annoncé puis reporté |

⚠ Ces deux blocs sont des sources de second rang : l'un est l'institution qui produit la donnée et la publie elle-même, l'autre est une partie au litige relayée par la presse. Aucun n'efface l'autre, et aucun ne se cite seul.

Ce qu'on en tire, et qui est un argument de conseil : promettre à un client une trésorerie à 90 jours parce qu'il vend à l'État est imprudent. Le dire, et faire chiffrer les intérêts moratoires dans le plan de trésorerie, vaut mieux qu'une hypothèse optimiste.
## Ce que cette fiche ne couvre pas
- ⛔ Le secteur privé. Aucun relevé de délai de paiement réel entre entreprises n'existe sur cette machine, et aucune source publique ivoirienne n'a été identifiée. Ne pas transposer les 90 jours publics au privé, où le marché fixe ses propres usages. ⟦à constituer sur les affaires réelles⟧
- Le taux de l'intérêt légal en vigueur, qui est la base de calcul et n'est pas dans le Code des marchés publics. ⟦à récupérer⟧
- Le délai réel constaté, par opposition au délai réglementaire. Les chiffres du Trésor donnent des volumes payés, pas des durées.

⚠ Piège d'extraction : ce Code est mis en page sur trois colonnes. L'extraction texte mélange les colonnes et décale les numéros d'articles ; le fichier -flux.txt fait apparaître un « Art. 140 » qui parle de défense nationale. Toute citation d'article se vérifie dans le PDF, pas dans le texte extrait.

À recontrôler le 22/03/2027.
