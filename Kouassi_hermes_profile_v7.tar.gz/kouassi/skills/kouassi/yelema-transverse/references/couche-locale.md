# Couche locale : Kouassi · Vente et développement commercial

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-KOUASSI-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères ; gouvernement-2026.md déjà relevé chez LOKOLI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Pièce déjà sur cette machine, aucune recherche à mener : ~/agents/lokoli/memory/reference/gouvernement-2026.md, composition du gouvernement Mambé du 23/01/2026, relevée le 10/09. Un lien symbolique suffit. La hiérarchie de fiabilité des sources ivoiriennes est dans watchlist-sources-ci.md (rang 1 = Journal officiel, SGG, presidence.ci ; une biographie n'établit jamais un statut, seul l'acte le fait).

### CL-KOUASSI-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Journal officiel et SGG (web.sgg.gouv.ci) ; le portail gratuit s'arrête en 2012, le JO récent demande un code au service JO du SGG
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-KOUASSI-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-KOUASSI-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-KOUASSI-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-KOUASSI-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/en/uniform-acts/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Établi sur ohada.org : dix actes uniformes en vigueur, droit commercial général, sociétés commerciales et GIE, sûretés, procédures collectives, recouvrement et voies d'exécution, arbitrage, médiation, comptabilité (SYSCOHADA), sociétés coopératives, transport de marchandises par route. Le fait qui compte pour un commercial : le droit des sociétés de ses prospects est régional et non ivoirien, et la cour commune, la CCJA, siège à Abidjan. Réserve du site lui-même : seule la version publiée au journal officiel de l'organisation fait foi, se méfier des versions non officielles qui circulent.

### CL-KOUASSI-23 · Ce que la loi 2013-450 impose avant de constituer un fichier de prospects
- **Pourquoi** : Charger une liste de prospects sans déclaration préalable expose la maison
- **Où chercher** : Loi 2013-450 sur la protection des données à caractère personnel, ARTCI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base données personnelles sur disque : loi n° 2013-450 du 19/06/2013 telle que publiée au Journal officiel du 08/08/2013 (p. 474 à 482), plus une seconde numérisation, la loi 2013-451 cybercriminalité et la loi 2013-546 transactions électroniques. La compétence donnees-personnelles-ci (Y0676) en est le mode d'emploi. ⛔ CES PDF N'ONT PAS DE COUCHE TEXTE : ce sont des numérisations du JO, il faut les LIRE, l'extraction ne rend rien. || Proposé le 17/09, trouvé en travaillant sur Fatima. La loi ivoirienne exige une AUTORISATION PRÉALABLE avant la constitution d'un fichier de clients. Un commercial qui charge une liste de prospects dans un outil est le premier concerné, et c'est aujourd'hui la seule ligne de cet onglet qui expose juridiquement la maison. Elle n'y figurait pas. PRÉCISION DU 18/09, ma formulation était imprécise et la nuance change la charge : le régime GÉNÉRAL de la loi n°2013-450 du 19/06/2013 est la DÉCLARATION PRÉALABLE de tout traitement de données personnelles à l'ARTCI avant sa mise en œuvre, l'AUTORISATION ne visant que certaines catégories. L'ARTCI, autorité administrative indépendante et autorité de protection au titre de cette loi, statue dans un délai d'UN MOIS à compter de la réception, prorogeable d'un mois par décision motivée ; elle a un pouvoir de sanction et les manquements sont aussi punis au titre du code pénal. ⚠ TEXTE PRIMAIRE NON RAPATRIÉ : le PDF du site de l'ARTCI renvoie une page « non trouvée » depuis sa restructuration et les miroirs habituels ne le portent pas. Sources secondaires concordantes uniquement. LU SUR LE TEXTE LE 18/09 : la loi est désormais sur la machine (~/.claude/outils-communs/donnees-personnelles-ci/, Journal officiel du 08/08/2013, p. 474 à 482) et lue article par article. Ce qui change par rapport à ce qui précède. (1) ART. 11, LE SILENCE VAUT REJET : l'ARTCI statue en un mois, prorogeable d'un mois par décision motivée, et l'ABSENCE DE REPONSE dans ce délai vaut REJET de la déclaration ou de la demande, pas acceptation ; recours devant la juridiction compétente. (2) ART. 7, SIX CATEGORIES SOUS AUTORISATION et non déclaration : données génétiques ou médicales et recherche scientifique ; infractions et condamnations ; NUMERO NATIONAL D'IDENTIFICATION OU TOUT IDENTIFIANT DE MEME NATURE, Y COMPRIS LES NUMEROS DE TELEPHONE ; données biométriques ; traitement d'intérêt public à fins historiques, statistiques ou scientifiques ; TRANSFERT VERS UN PAYS TIERS. (3) ART. 6, QUATRE DISPENSES de déclaration, dont la désignation d'un correspondant à la protection des données (art. 12), dispense qui TOMBE dès qu'un transfert hors du pays est envisagé. (4) ART. 26, tout transfert hors de Côte d'Ivoire suppose un pays au niveau de protection suffisant ET l'autorisation préalable de l'ARTCI : un hébergement ou un outil de gestion client à l'étranger est un transfert. (5) ART. 51, SANCTIONS : après mise en demeure, retrait d'autorisation et sanction pécuniaire plafonnée à 10 000 000 FCFA, portée en cas de récidive dans les cinq ans à 100 000 000 FCFA ou, pour une entreprise, 5 % du chiffre d'affaires hors taxes du dernier exercice clos dans la limite de 500 000 000 FCFA, sans préjudice du pénal. (6) ART. 46, l'autorité de protection EST l'ARTCI, il n'y a pas d'autorité distincte. (7) ART. 28 à 38, droits des personnes : information au plus tard à la collecte, accès, opposition gratuite à la prospection, rectification, effacement sans délai (art. 35), portabilité. COMPETENCE ECRITE LE 18/09 : donnees-personnelles-ci (Y0676), au catalogue, adossée à ces articles. ART. 22, LE POINT QUI EXPOSE LE PLUS : la prospection directe par tout moyen de communication, en utilisant les données d'une personne physique QUI N'A PAS EXPRIME SON CONSENTEMENT PREALABLE à recevoir des prospections, est punie d'UN AN D'EMPRISONNEMENT et de 1 000 000 à 10 000 000 FCFA d'amende. Une base de numéros achetée, collectée en salon, aspirée d'un annuaire ou extraite d'un groupe de messagerie ne porte aucun consentement. La question à poser avant d'écrire une séquence n'est pas quel message, mais d'où vient ce numéro et qu'a accepté son titulaire. ART. 21 : les données révélant l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses ou philosophiques, l'appartenance syndicale, la vie sexuelle ou l'état de santé sont interdites, sous peine d'UN A CINQ ANS d'emprisonnement et de 20 à 40 millions FCFA.

## Langue

### CL-KOUASSI-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Déjà chez lui : compétence parler-ivoirien liée, vérifiée neutre. Son corpus ajoute la règle de registre : le premier contact reste formel ici, on vouvoie, et l'urgence fabriquée est lue comme de la pression.

## Canaux

### CL-KOUASSI-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : Établi, et c'est le point qui change tout le reste : WhatsApp est utilisé par plus de 90 % des possesseurs de téléphone intelligent et constitue le premier canal, devant le SMS et le courriel. Réserve écrite par Kouassi lui-même et à conserver : les deux sources sont des éditeurs de solutions WhatsApp, donc intéressés au chiffre ; il retient la pénétration, cohérente d'une source à l'autre, et REJETTE explicitement leurs 91 % de taux d'ouverture et 380 % de retour sur investissement, arguments commerciaux sans méthode publiée. Complément disponible chez Fatima : memory/reference/reseaux-marques-ci.md. ⚡ MIS À NIVEAU LE 18/09, ET LA RÉSERVE EST LEVÉE : la mesure existe chez le RÉGULATEUR, enquête Mesure de la Société de l'Information 2024 de l'ARTCI avec le cabinet Axes Marketing, méthode publiée (échantillon stratifié, 7 474 189 ménages, 27 216 065 individus de 5 ans et plus, face à face sur tablette, 33 districts et régions). Elle remplace les deux éditeurs de solutions WhatsApp, qui étaient intéressés au chiffre. WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LinkedIn 1,3 %. La pénétration de WhatsApp que Kouassi retenait est CONFIRMÉE, et le classement complet est désormais connu. ⛔ LinkedIn à 1,3 % : à ne plus proposer comme canal de prospection de masse ici. Sur disque : ~/.claude/outils-communs/numerique-ci/artci/.

## Marché

### CL-KOUASSI-11 · Les secteurs qui achètent vraiment ici, et leur cycle de décision
- **Pourquoi** : Prospecter au hasard brûle la liste
- **Où chercher** : Presse économique, CEPICI, chambres consulaires
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/data-fair/api/v1/datasets
- **Pièce, ici** : references/pieces/1foocgM2ejj_4BvPqKcmtZ2Tm-hFo3tZ5L-webNPKkvI.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : FAIT le 22/09/2026. Fiche statistiques-ci/SECTEURS-ET-ACTIVITE.md, adossée à quatre séries publiques rapatriées le même jour de data.gouv.ci et rangées dans jeux-data-gouv-ci.

LE PIEGE A LIRE AVANT TOUT CHIFFRE : les indices de chiffre d'affaires disent COMMENT un secteur a évolué par rapport à lui-même, JAMAIS quelle est sa taille. Classer des secteurs par leur indice pour dire lequel est le plus gros est faux, et l'erreur est invisible à la relecture. Pour la taille il faut une valeur ajoutée en francs, absente de ces fichiers ; elle est à chercher dans la comptabilité nationale de l'ANStat.

CE QUI A LE PLUS ACCELERE DANS L'INDUSTRIE, indice mensuel mars 2021 à mars 2022, moyenne : déchets et récupération 301,2 ; industries environnementales 280,2 ; autres activités extractives 274,8 ; minerais métalliques 229,0 ; tabac 210,2 ; équipements électriques 207,1 ; bois 195,5 ; produits chimiques 187,5. En repli : autres matériels de transport 41,3 ; cuir et chaussures 68,7 ; produits pharmaceutiques 91,0.

LE COMMERCE, indice trimestriel 2015 à 2020, base 100 en 2015 : commerce de gros de produits intermédiaires non agricoles +173 %, entretien et réparation automobile +99 %, gros de biens de consommation non alimentaires +67 %, véhicules automobiles +60 %, et le commerce de gros non spécialisé RECULE de 34 %.

LE TISSU REEL D'ABIDJAN, 2 761 petits commerces géolocalisés : accessoires de beauté 392, coiffeurs 309, TRANSFERT D'ARGENT 283, quincaillerie 224, nettoyage à sec 209. Parmi les activités nommées une à une, les trois premières enseignes du relevé sont des agents de paiement : Mobil Money 49, Orange Money 39, Mobile Money 28, soit 116 points, devant le garbadrome 47 et le vulcanisateur 44.

UN SEUL SECTEUR MESURE EN FRANCS, les télécoms, déclarations des opérateurs. CA hors taxes 2024 en milliards FCFA : Orange 839,1 ; MTN 414,0 ; Moov 340,0 ; GVA 6,6 ; VipNet 3,0. Orange pèse plus que MTN et Moov réunis et investit deux fois plus que MTN (101,7 contre 46,2). Par service en 2024 : mobile 975,2, Internet mobile 473,4, fixe 87,2, Internet fixe 70,0.

TROIS DEFAUTS DES FICHIERS A CONNAITRE AVANT DE LES REUTILISER. 1) Dans l'indice industrie, agrégats et sous-secteurs sont mélangés dans la même colonne et portent le même indice : les additionner compte deux fois. 2) Certaines séries sont trop volatiles pour dire quoi que ce soit, l'habillement va de 6,1 à 463,3 en treize mois, base minuscule, à ne pas citer. 3) Dans l'indice commerce, l'orthographe des libellés change entre 2015 et 2020 : rapprocher sur le code NAEMA, jamais sur le texte, sinon trois séries disparaissent en silence. Et 2025 n'est qu'un trimestre dans le fichier télécoms, à ne jamais comparer à une année pleine.

AU PASSAGE, une correction de méthode : data.gouv.ci EXPOSE bien une API, sur data-fair/api/v1/datasets, pas sur les chemins udata ou CKAN qui rendent 404. J'avais d'abord conclu à tort qu'il n'y en avait pas ; la réponse était déjà écrite dans statistiques-ci/LISEZ-MOI.md. Attention, l'instance est mutualisée : 256 jeux ivoiriens sur 526, le reste est français.

LE CYCLE DE DECISION : la moitié publique est dans marches-publics-ci/QUI-SIGNE-QUI-APPROUVE-QUI-PAIE.md (voir CL-KOUASSI-13). Le cycle d'une entreprise privée ivoirienne n'est publié nulle part ; ce que nous en savons vient de nos missions et vit dans maison-et-clients, qui n'est pas une source sur le pays.

### CL-KOUASSI-12 · Annuaire des entreprises et groupes de la place
- **Pourquoi** : Une prospection sans annuaire réel n'est qu'une liste inventée
- **Où chercher** : idu.ci, annuaire public cherchable par raison sociale ou par secteur ; le CEPICI immatricule et n'édite pas d'annuaire
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.idu.ci/annuaire-entreprise.xhtml
- **Pièce, ici** : references/pieces/1uaqNqgVG06o4NZfimIk5TDAYpxXgEpS_V-9cAIZ8Z48.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : FAIT le 22/09/2026. Base neuve entreprises-ci, liée au carrefour bases-locales, donc lisible par les quinze.

L'ANNUAIRE PUBLIC EXISTE ET IL EST REEL : https://www.idu.ci/annuaire-entreprise.xhtml, sans compte, cherchable par numéro IDU, par dénomination sociale et par secteur d'activité. La fiche rend la dénomination sociale ET le nom commercial (qui diffèrent presque toujours), la forme juridique, le montant du capital social, le N° RCCM, le N° de compte contribuable, le N° CNPS, et une date d'immatriculation PAR registre. Les trois dates ne coïncident pas toujours, et l'écart instruit : une société au RCCM depuis des années sans numéro CNPS n'emploie personne officiellement. Le numéro IDU tient de l'ordonnance 2015-182 du 24/03/2015, modifiée par l'ordonnance 2018-644 du 1er août 2018.

CE QU'IL NE PERMET PAS, ET C'EST LA LIMITE A CONNAITRE : aucune extraction en masse. Le formulaire est une page JSF/PrimeFaces, la recherche part en POST avec un jeton de vue, et notre outil public est volontairement sans compte, sans cookie et sans session. On interroge une entreprise à la fois, à la main. Donc l'annuaire VERIFIE un nom qu'on a déjà, il ne FABRIQUE pas un fichier de prospection. La ligne reste utile telle quelle : le geste de prospection est de construire la liste ailleurs, puis de vérifier chaque nom ici avant d'appeler, et d'écrire le nom légal dans le contrat.

TROIS AUTRES PORTES ESSAYEES ET ECARTEES, avec leur état. CEPICI immatricule et n'édite pas d'annuaire (cepici.gouv.ci redirige vers cepici.ci qui répond 307 sans cible). annuaire.cci.ci, Chambre de commerce : le sous-domaine existe et rend 403 Forbidden à l'outil comme au navigateur, corps Apache nu, AUCUN marqueur Cloudflare, donc un refus du serveur et rien à contourner. data.gouv.ci : aucun jeu de données sur les entreprises, et l'API répond 404 sur tous les chemins usuels.

LA SEULE LISTE NOMINATIVE PUBLIQUE ET COMPLETE que nous détenions reste les 47 sociétés cotées à la BRVM, dans financement-ci/BRVM.md.

RESTE DU : une source qui donne une liste PAR SECTEUR. Piste non essayée, les fichiers d'adhérents des groupements professionnels, qui se demandent et ne se téléchargent pas. Les listes de prospects de la maison existent mais vivent dans maison-et-clients : elles disent qui nous visons, pas qui existe.

### CL-KOUASSI-21 · Le calendrier budgétaire de l'État et des grandes maisons
- **Pourquoi** : Un cycle commercial B2G mal calé arrive toujours d'un trimestre en retard
- **Où chercher** : Loi de finances, calendrier de la DGBF, exercices des grandes entreprises
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Proposé le 17/09. Quand un budget se vote, quand il s'exécute, quand il est trop tard pour l'année. Le corpus couvre les fériés et les saisons, pas le cycle budgétaire.

### CL-KOUASSI-22 · Où l'on rencontre les décideurs
- **Pourquoi** : Sur un marché petit où les gens se connaissent, savoir où ils se croisent vaut une liste de contacts
- **Où chercher** : CGECI, chambres consulaires, fédérations sectorielles, rendez-vous annuels
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Proposé le 17/09, toujours à faire. PRÉCISION DU 18/09 tirée de la note GTM : le canal qui compte ici n'est pas seulement l'événement, c'est LE PRESCRIPTEUR, et il diffère par métier. Cabinets comptables SYSCOHADA pour la finance, cabinets d'avocats d'affaires OHADA pour le juridique, cabinets de paie externalisés pour la RH. La note pose aussi le principe qui explique pourquoi : UN PAIR NE CROIT QU'UN AUTRE PAIR, un DAF ne se laisse convaincre que par un autre DAF. La liste des groupements professionnels reste à constituer, mais elle vient après la liste des prescripteurs.

## Vente

### CL-KOUASSI-13 · Le circuit de décision type : qui signe, qui influence, qui paie
- **Pourquoi** : Parler au mauvais interlocuteur fait perdre un trimestre
- **Où chercher** : Retours de missions, entretiens clients
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://budget.gouv.ci/doc/loi/Code-Marches-Publics-Ordonnance-n-2019-679-du-24-juillet-2019.pdf
- **Pièce, ici** : references/pieces/19wMH1XLXjCs62eZ49AvlWXw8oiVtOERR0N7Hivyh5Fg.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : FAIT le 22/09/2026, et la ligne se ferme en deux moitiés qu'il ne faut pas confondre.

MOITIE PUBLIQUE, opposable, tirée du Code des marchés publics 2019-679 que nous détenons. Cinq rôles distincts. Coordonne : la personne responsable des marchés, désignée PARMI LES DIRECTEURS DE CABINET DU MINISTRE (art. 12) ; c'est le fait le plus opérationnel de la fiche, l'achat public se coordonne au sommet du cabinet, pas dans un service technique. Prépare et suit : la cellule de passation, sous son autorité (art. 13). Choisit l'attributaire : la commission d'ouverture des plis et de jugement des offres, présidée par le responsable de la cellule de passation, où siègent un représentant de chaque service utilisateur ET le contrôleur financier (art. 14.1.1). Signe : celui qui a qualité pour représenter la personne morale (art. 18.1). Approuve : UNE AUTRE AUTORITE, jamais la même (art. 18.1), variable selon le montant et l'acheteur (art. 18.2.1 à 18.2.4 : ministre chargé des Marchés publics au-dessus du seuil de validation, ministre de tutelle en dessous, préfet en région, Conseil d'administration pour les sociétés d'Etat). Paie : le comptable assignataire.

DEUX PIEGES A CONNAITRE. 1) Un marché non approuvé est NUL (art. 18.2.7) : un contrat signé sans approbation ne vaut rien, ni la facture qui va avec. 2) Avant de viser un directeur général de société d'Etat, vérifier jusqu'à quel montant son Conseil lui a délégué l'approbation (art. 18.2.6). Calendrier : 7 jours maximum pour approuver après réception du dossier accompagné de l'avis de la structure de contrôle, puis 3 jours pour notifier (art. 83.1 à 83.4). Le texte dit « s'il ne prend pas une décision de refus, il approuve » : ce n'est PAS une approbation tacite établie, c'est un délai pour agir, et le Code ne dit pas ce qui suit. Non tranché, ne pas l'affirmer. L'argent suit son propre chemin : 90 jours pour les acomptes et le solde, 45 pour une avance, intérêts moratoires au taux légal majoré d'un point mais dus sur demande motivée seulement (DELAIS-DE-PAIEMENT.md).

MOITIE PRIVEE, et c'est un trou assumé : le circuit de décision dans une entreprise privée ivoirienne n'est publié NULLE PART. Aucune source officielle, aucune étude accessible. Ce que nous en savons vient de nos propres missions et vit dans maison-et-clients. Cela ne se cite pas comme un fait sur le pays. La distinction est le coeur de la ligne : ce qui vient du Code est opposable, ce qui vient de nos missions est de l'expérience.

RESTE DU : les seuils chiffrés de passation et de validation, fixés par décret et non par le Code ; les marchés des collectivités territoriales, qui ont leurs propres autorités.

### CL-KOUASSI-14 · Les modes de paiement pratiqués : virement, mobile money, chèque, espèces
- **Pourquoi** : Une offre impayable est une offre refusée
- **Où chercher** : BCEAO, opérateurs de mobile money
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || Deux pièces en place. Son corpus pose la règle de fond : le moyen d'encaissement décide de la vente plus souvent qu'on ne le croit, un client qui ne peut pas payer comme il en a l'habitude ne conclut pas, même convaincu. Et l'intégration integrations/[entreprise cliente]/ documente ce qu'un lien de paiement exige techniquement avant qu'on le promette dans un devis : encaissement en ligne, liens de paiement, paiement en boutique, transferts, webhooks. AVERTISSEMENT À NE PAS PERDRE : [entreprise cliente] n'a aucun environnement d'essai, chaque appel à leur API de production déplace de l'argent réel ; on lit la documentation, on n'exécute aucun appel de paiement. Non renseigné volontairement : les parts de marché du mobile money, les sources publiques se contredisent franchement (Wave 40 % chez l'une, Orange 55 % et Wave 35 % chez l'autre). La ligne demande ce qui se pratique, pas des parts de marché.

### CL-KOUASSI-15 · Les délais de paiement observés, secteur public et secteur privé
- **Pourquoi** : Promettre une trésorerie sur des délais théoriques
- **Où chercher** : Retours de missions, service financier de la maison
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://tresor.gouv.ci/tres/
- **Pièce, ici** : references/pieces/1pAHeYudTogFLYZe9dOgUDm2NJbpFZhundCQVfaLZ8Kc.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, et le chiffre change de rang. Note neuve bases-locales/marches-publics-ci/DELAIS-DE-PAIEMENT.md. ⛔ LE DÉLAI DE 90 JOURS N'EST PLUS UNE SOURCE DE SECOND RANG : il est à l'ARTICLE 139 DU CODE DES MARCHÉS PUBLICS DE 2019, que nous détenons. L'autorité contractante est tenue de payer acomptes et solde dans un délai QUI NE PEUT DÉPASSER QUATRE-VINGT-DIX JOURS, avec deux nuances qui comptent : un délai PLUS LONG peut être fixé POUR LE SOLDE, et des délais PLUS COURTS peuvent être accordés aux PME ou pour des projets urgents ou à caractère social, ce qui se demande et ne s'obtient pas d'office. AUTRES DÉLAIS DU CODE : 45 jours maximum pour payer une avance à compter de la réception de la garantie (art. 132), 60 jours maximum pour payer les intérêts moratoires après demande, 10 jours maximum pour que le titulaire achemine la demande de paiement d'un sous-traitant (art. 137). INTÉRÊTS MORATOIRES, art. 142 : taux de l'INTÉRÊT LÉGAL MAJORÉ D'UN POINT, jours calendaires, années de 365 jours, courant du jour suivant l'expiration du délai jusqu'à l'émission du titre de règlement, capitalisés un an après l'échéance, et SANS AVENANT. ⛔ MAIS ILS NE SONT PAS AUTOMATIQUES EN PRATIQUE : ils sont dus SUR DEMANDE MOTIVÉE ET CHIFFRÉE du titulaire. Un fournisseur qui ne demande rien ne reçoit rien. Et deux exclusions : rien sur les prestations non réalisées, et LE RETARD DE PAIEMENT DES AVANCES N'EST PAS SANCTIONNÉ. LE CHIFFRE ET SON CONTRE-CHIFFRE RESTENT CITÉS ENSEMBLE, tous deux de rang 2 : Trésor, 1 556,8 Md FCFA payés à 6 721 fournisseurs au 31/12/2025 et 416,98 Md à 2 870 au premier semestre 2026 ; SYNAFECI, plus de 39,04 Md d'impayés réclamés en juillet 2025 dont le Trésor ne reconnaissait que 1,8 Md. C'est l'écart qui porte l'information commerciale. ⛔ CE QUI MANQUE, ET IL FAUT LE DIRE : le secteur privé, où aucun relevé de délai réel n'existe et où les 90 jours publics ne se transposent pas ; le taux de l'intérêt légal en vigueur, qui est la base de calcul ; et le délai RÉEL constaté, les chiffres du Trésor donnant des volumes, pas des durées. ⚠ PIÈGE D'EXTRACTION signalé dans la note : ce Code est en trois colonnes, l'extraction texte décale les numéros d'articles, toute citation se vérifie dans le PDF.

## Concurrence

### CL-KOUASSI-16 · Qui vend la même chose ici, à quel prix affiché
- **Pourquoi** : Se positionner sans comparable
- **Où chercher** : Sites et documents commerciaux publics des concurrents, relevés un par un ; pricing-advisor ne charge aucune source
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Toujours AUCUN PRIX de concurrent relevé, et le pointeur de pricing-advisor reste creux : sa description annonce un « benchmark UEMOA sourcé », son corps dit « charger depuis la mémoire de marque de la startup », mémoire qui n'existe nulle part. Sa règle, elle, est la bonne : ne jamais inventer un benchmark, uniquement des prix publiés ou confirmés, source tracée. AJOUT DU 18/09, les CONCURRENTS sont nommés même si leurs prix ne le sont pas. La note GTM les classe en deux familles : les verticaux purs, Harvey en juridique, Hippocratic en santé, Unique en finance, qui gagnent parce que le corpus métier fait le moat mais restent mono-secteur ; et les horizontaux purs, Writer, Ema, Kore.ai, qui landent par fonction mais s'appuient sur du self-service et un marché mûr, ce qui les dilue sur un marché où la confiance est rare. UN CONCURRENT FRONTAL EST DOCUMENTÉ SUR UN COMPTE RÉEL : Copilot est déjà déployé au niveau groupe chez un prospect bancaire, ce qui impose de vendre la conception et non la publication. Ce qui manque reste le prix affiché : à relever un par un sur les sites des concurrents.

## Appels d'offres

### CL-KOUASSI-17 · Comment se passe une consultation publique en Côte d'Ivoire
- **Pourquoi** : Rater une pièce administrative disqualifie tout le dossier
- **Où chercher** : marchespublics.ci (DGMP) pour les avis ; arcop.ci pour le code, les décisions et les audits (ex-ANRMP)
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.marchespublics.ci/appel_offre
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Ordonnance n° 2019-679 du 24/07/2019, Code des marchés publics, sur disque. ⛔ Lire le fichier -flux.txt, pas -layout.txt. ⛔ LES SEUILS N'Y SONT PAS : art. 5.1, ils sont fixés par décret en Conseil des ministres et varient selon l'autorité contractante. Un achat public passé hors procédure est annulable, et l'annulation arrive après la livraison. || La colonne « où chercher » a été corrigée : l'ANRMP n'existe plus sous ce nom, c'est l'ARCOP, Autorité de régulation de la commande publique (la date exacte du changement ne figure pas sur sa page d'accueil, elle reste à établir sur le texte). Deux adresses, deux usages, les deux en accès libre et testées à 200 le 17/09 : marchespublics.ci, portail de la DGMP, publie les avis d'appel d'offres en cours, plusieurs centaines en ligne avec objet, autorité contractante, dates de publication et date limite ; arcop.ci publie le code des marchés publics, les décisions de recours et de sanction, les rapports d'audit et les guides méthodologiques. Cadre : ordonnance 2019-679 du 24/07/2019 portant code des marchés publics, renforcée par sept décrets d'application adoptés en Conseil des ministres les 15 et 22/12/2021. AUCUN SEUIL N'EST RELEVÉ ICI, volontairement : sa compétence appel-d-offres-et-soumission impose de construire la liste des pièces à partir du dossier de consultation lui-même, sans jamais citer de mémoire un seuil de procédure, un montant de caution ou un délai légal absent du dossier.

## Références

### CL-KOUASSI-18 · Les arguments qui marchent ici, et ceux qui font fuir
- **Pourquoi** : Un argumentaire importé sonne faux dès la deuxième phrase
- **Où chercher** : Relevés d'échanges commerciaux réels
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || memory/reference/vendre-en-cote-d-ivoire.md reste la pièce maîtresse : ce qui ne se transpose pas des manuels américains, le premier message en quatre éléments et moins de cent mots, le plafond de trois contacts, et la règle qui tue les relances creuses. AJOUT DU 18/09, l'argumentaire terrain a été ouvert et il apporte une MÉTHODE réutilisable, pas seulement des réponses. Sa force est sa source : ses douze objections ne sont pas imaginées, elles sont tirées de 530 avis classés, écrits publiquement par des commerçants ivoiriens sur les applications qu'ils utilisent déjà. Trois principes transposables tels quels. 1) NE PAS ARGUMENTER SUR LE PRIX quand on n'est pas le moins cher, cela se vérifie en trente secondes : basculer sur ce qui se compare vraiment. 2) NE PAS PROMETTRE LE ZÉRO PROBLÈME, personne n'y croit : dire ce qui se passe quand ça arrive, qui appeler et sous combien de temps on répond. 3) Face à « je vais réfléchir », NE PAS INSISTER et proposer la plus petite marche possible, un essai réel valant mieux qu'un argumentaire. S'y ajoutent trois questions de qualification posées AVANT de vendre quoi que ce soit, et une section « ce qu'on ne dit jamais » qui écarte les chiffres du site non vérifiés en interne. RÈGLE DE CLOISON : ce document appartient à une autre maison du portefeuille. On en reprend la MÉTHODE, jamais les chiffres ni les tarifs, qui ne valent que pour elle.
