---
id: Y0427
name: reclamation-et-geste-commercial
description: "Traite une réclamation client de bout en bout : reçoit sans se défendre, établit les faits à partir des traces disponibles, distingue ce qui est établi de ce qui reste allégué, qualifie la cause et la responsabilité, construit l'échelle des gestes possibles (excuse, geste sur la prochaine commande, avoir, remplacement, remboursement) avec ce que chacun engage, vérifie la faisabilité avant de promettre, puis prépare la réponse écrite et orale et la ligne d'enregistrement du geste accordé, sans jamais citer un droit du consommateur ou un délai légal de mémoire."
bucket: B
tags: [Support, Réclamation, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# La réclamation, établir les faits, réparer, et savoir ce que ça coûte

## Ce qu'il faut avoir sous la main
- **La réclamation telle qu'elle t'est arrivée** : le message du client, mot pour mot si possible (WhatsApp, appel, passage en boutique).
- **Les traces dont tu disposes** : bon de livraison, échange de messages, enregistrement de la commande, photo du produit reçu, témoin. Même partielles, donne-les.
- **Ce que tu sais du client** : première commande ou client régulier, montant habituel, canal de contact préféré.
- **Ton échelle de gestes déjà en place**, si elle existe : jusqu'où tu peux aller seul, à partir de quel montant il faut un accord au-dessus de toi.
- **Ce qui est réellement faisable maintenant** : stock disponible pour un remplacement, trésorerie et mode de paiement d'origine pour un remboursement (mobile money, cash, virement).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte donné est partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1, Recevoir sans se défendre

Note la réclamation telle qu'elle est formulée, sans la reformuler pour l'atténuer et sans répondre tout de suite. La première erreur d'un débutant est de contester ou de se justifier avant d'avoir vérifié quoi que ce soit : cela ferme la conversation et enferme l'entreprise dans une position qu'elle devra parfois défaire.

Distingue déjà, à ce stade, ce que le client **décrit comme fait** (« le produit est arrivé cassé ») de ce qu'il **interprète** (« vous ne faites pas attention à vos livraisons »). Les deux comptent, mais pas de la même façon plus loin.

### Étape 2, Établir les faits à partir des traces disponibles

Liste ce qui est vérifiable : bon de livraison, échange de messages WhatsApp, enregistrement de commande, photo envoyée par le client ou prise à la livraison, témoin. Pour chaque élément de la réclamation, indique s'il est **établi** (une trace le confirme), **allégué** (seule la parole du client l'affirme, aucune trace pour ou contre) ou **contredit** (une trace dit autre chose).

Le piège à ce stade : présenter un allégué comme un établi, dans un sens ou dans l'autre, parce que ça arrange la réponse qu'on veut donner. La fiche garde les deux colonnes visibles et séparées, y compris quand une bonne partie du dossier repose sur du déclaratif : beaucoup de commandes se passent par appel ou par message vocal sans trace écrite, et cela n'invalide pas la réclamation, cela veut juste dire qu'une partie du dossier reste allégué.

### Étape 3, Qualifier la cause et la responsabilité

Range la réclamation dans une catégorie de cause : défaut du produit, erreur de préparation, erreur de livraison, dommage en transport, mauvaise utilisation par le client, malentendu sur la commande, tiers impliqué (transporteur, revendeur intermédiaire). Cette catégorie n'est pas un détail administratif : c'est elle qui, agrégée sur plusieurs fiches, révèle un motif récurrent qu'aucun dossier isolé ne montre.

Détermine ensuite qui porte la responsabilité, en te fondant sur ce qui est établi à l'étape 2, pas sur ce qui est allégué. Une responsabilité partagée ou incertaine se dit comme telle : ce n'est pas un dossier raté, c'est un dossier honnête.

### Étape 4, Construire l'échelle des gestes possibles

Pose l'échelle disponible, du plus léger au plus engageant : excuse et explication seules, geste sur la prochaine commande (remise, produit offert), avoir, remplacement du produit, remboursement. Pour chaque échelon, précise ce qu'il coûte réellement (une remise différée n'est pas gratuite, elle coûte au moment où elle sera consommée) et ce qu'il engage pour l'entreprise (un avoir suppose que le client revienne, un remboursement ne le suppose pas).

Le geste proposé doit être **proportionné** à la responsabilité établie, pas au ton du client ni à sa capacité à insister. Un client calme avec un tort avéré mérite plus qu'un client agressif avec un tort incertain : la fiche note le motif du geste, pas l'ambiance de l'échange.

### Étape 5, Vérifier la faisabilité avant de formuler la promesse

Avant d'écrire quoi que ce soit au client, vérifie que le geste envisagé est réellement possible. Un remplacement dépend du stock disponible et du délai de livraison réel jusqu'au client, qui peut s'allonger avec les embouteillages ou la distance en dehors d'Abidjan. Un remboursement dépend de la trésorerie disponible et du mode de paiement d'origine : un paiement reçu en mobile money se rembourse en mobile money, un paiement en espèces suppose une remise en espèces ou un autre arrangement, un virement suit ses propres délais bancaires. Promettre un remboursement sous un délai qu'on ne maîtrise pas soi-même transforme une réclamation en deuxième réclamation.

Si le geste idéal n'est pas faisable maintenant, prépare une alternative crédible plutôt que de laisser la promesse en suspens.

### Étape 6, Rédiger la réponse et clore

Prépare deux versions : la réponse écrite (message WhatsApp ou email) et la version à dire au téléphone ou en boutique, qui ne porte pas les mêmes mots. Dans les deux, le fait corrigé (s'il doit l'être) se dit sans agressivité et le ton reste réparateur même quand l'entreprise a raison sur le fond : la façon de le dire, surtout par écrit et surtout si l'échange peut être montré à d'autres, décide de ce qui reste de la relation après.

La réponse dit clairement ce qui est accordé, sous quelle forme, et sous quel délai. Elle se termine par une clôture explicite : le client doit savoir que le dossier est réglé, pas deviner s'il peut encore relancer.

### Étape 7, Enregistrer pour le suivi

Consigne une ligne : date, catégorie de cause, responsabilité retenue, geste accordé, coût du geste. Une fiche traitée et jamais comptée ne sert à rien au-delà du cas individuel : dix réclamations à la même cause sur le même produit ou la même tournée de livraison disent quelque chose qu'aucune fiche isolée ne montre, et que seul le compte cumulé fait apparaître.

## Format de sortie
- **Livrable en trois parties** :
  1. **La fiche de réclamation** : ce qui est reproché, ce qui est établi et par quelle trace, ce qui reste allégué, la catégorie de cause, la responsabilité retenue, le geste proposé avec son coût, l'alternative si ce geste n'est pas faisable.
  2. **La réponse au client** : version écrite prête à envoyer, version orale prête à dire au téléphone, toutes deux avec une clôture explicite.
  3. **La ligne d'enregistrement** : catégorie, responsabilité, geste accordé, coût, pour le suivi cumulé des réclamations.
- **Structure** : Markdown clair, la fiche d'abord, la réponse ensuite, l'enregistrement en dernier.
- **Longueur** : proportionnée au dossier, sans remplissage. Une réclamation simple tient sur une demi-page.
- **Les seuils de l'échelle de gestes sont un input** : la skill livre la structure (les échelons, ce que chacun coûte et engage) ; le montant, le plafond ou le niveau d'accord requis restent `⟦à renseigner⟧` tant que l'entreprise ne les a pas donnés.
- **Règle 0 invention** : aucun droit du consommateur, aucun délai légal, aucune obligation de garantie n'est cité de mémoire. Ces points sont renvoyés à un avis juridique compétent, jamais tranchés par la skill.

## Règles
1. **On ne répond pas avant d'avoir établi les faits.** La fiche sépare toujours ce qui est établi de ce qui est allégué, dans deux colonnes visibles, jamais fondues dans la même phrase.
2. **Un geste s'accorde selon une échelle décidée en amont, avec un motif écrit.** Un geste donné pour avoir la paix, sans motif et sans référence à l'échelle, n'est pas enregistré comme un cas normal : il est signalé comme une exception à documenter.
3. **Le fait se corrige, le ton reste réparateur.** Même quand l'entreprise a raison, la réponse ne conteste jamais frontalement la parole du client, surtout par écrit et surtout si l'échange est visible par d'autres.
4. **Chaque fiche porte une catégorie de cause.** Sans catégorie, le motif récurrent reste invisible. Ce n'est pas un champ optionnel.
5. **Aucune promesse n'est faite avant vérification de faisabilité.** Stock pour un remplacement, trésorerie et mode de paiement d'origine pour un remboursement, délai réaliste compte tenu de la distance et des conditions de livraison : la promesse suit la vérification, jamais l'inverse.
6. **0 chiffre et 0 référence légale inventés.** Aucun barème de remboursement, aucun délai légal de rétractation, aucune obligation de garantie n'est produit sans être fourni par l'entreprise ou sourcé : `⟦à renseigner⟧` sinon, et renvoi vers un avis compétent pour tout point de droit.
7. **Le contexte local n'est pas un décor.** Une part des commandes se fait par appel ou message vocal sans trace écrite, une part des remboursements doit suivre le canal mobile money d'origine, et une part des délais de remplacement dépend des distances et des embouteillages réels : la fiche en tient compte plutôt que de supposer un dossier entièrement tracé et une logistique instantanée.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « établi » sans trace réelle citée. Si une source ou un connecteur est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill prépare un document de travail ; envoyer la réponse au client, accorder le geste, déclencher un remboursement ou un remplacement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un client ou d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucune trace écrite, tout est déclaratif** (commande passée par appel ou message vocal) : tu produis la fiche avec la colonne « établi » vide ou quasi vide, tu le dis explicitement, et tu ne fabriques pas une trace qui n'existe pas.
- **Pièce annoncée mais absente** (« je t'envoie la photo », rien n'est joint) : tu le signales avant de continuer et tu ne traites pas comme si tu l'avais vue.
- **Réclamation publique** (réseau social, avis en ligne) : tu prépares une réponse publique courte et neutre qui renvoie la suite en privé, distincte de la réponse détaillée envoyée en privé.
- **Réclamation récurrente sur le même produit ou la même tournée** : tu le signales au-delà de la fiche individuelle, comme un motif à faire remonter, sans attendre que quelqu'un le remarque de lui-même.
- **Client agressif ou menaçant** : le ton de la réponse reste réparateur et factuel ; tu ne cales ni le fond ni le montant du geste sur l'intensité de la pression exercée.
- **Geste demandé par le client dépasse l'échelle disponible** : tu le dis, tu proposes ce qui est dans l'échelle, et tu signales le dépassement pour arbitrage au niveau supérieur.
- **Mode de remboursement d'origine incompatible avec ce que demande le client** (payé en mobile money, remboursement en espèces demandé) : tu le signales et tu proposes l'alternative faisable plutôt que d'improviser une solution.
- **Responsabilité d'un tiers** (transporteur, revendeur intermédiaire) : tu le dis clairement dans la fiche, tu ne fais pas porter au client l'incertitude sur qui doit répondre du dossier.
- **Demande hors périmètre** (litige nécessitant une interprétation juridique, procédure judiciaire) : tu le dis en une phrase et tu orientes vers un avis compétent, sans trancher toi-même le point de droit.
- **Action sortante demandée** (envoyer la réponse, déclencher le remboursement) : tu prépares le livrable complet et tu t'arrêtes pour validation humaine.
