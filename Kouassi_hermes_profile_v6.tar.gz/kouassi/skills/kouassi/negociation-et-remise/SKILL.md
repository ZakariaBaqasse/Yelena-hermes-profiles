---
id: Y0667
name: negociation-et-remise
description: "Prépare et structure une négociation commerciale : objectif chiffré, variables négociables classées par coût avant qu'on touche au prix, contrepartie exigée pour chaque concession, plancher fourni par l'entreprise, réponses aux objections courantes (remise systématique, comparaison concurrent, négociation en plusieurs tours), puis le compte rendu de ce qui a été concédé et de ce qu'il faut répercuter dans les documents commerciaux. Elle ne fixe jamais elle-même un prix plancher et n'accorde rien : elle prépare et documente."
bucket: B
tags: [Commercial, Négociation, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# La négociation commerciale, ce qu'on lâche, contre quoi, et jusqu'où

## Ce qu'il faut avoir sous la main
- **Ce qui se négocie** : un nouveau contrat, un renouvellement, une remise demandée sur une commande en cours, un appel d'offres.
- **Le client** : qui il est, son poids réel dans ton chiffre d'affaires, s'il est récurrent ou ponctuel, formel ou informel.
- **Ta position de départ** : prix affiché, conditions standards, ce que tu proposes avant toute discussion.
- **Ton plancher**, si tu l'as déjà : le prix ou les conditions en dessous desquelles l'affaire ne t'intéresse plus. Sinon, dis-le, je le laisse en `⟦à renseigner⟧`.
- **Ce que le client a déjà dit** : une remise demandée, un concurrent cité, un délai de paiement réclamé, un volume mis en avant. Même à l'état de bribes sur WhatsApp, ça compte.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte fourni est partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce que seule l'entreprise peut trancher, à commencer par le plancher. Tu ne redemandes que ce qui est réellement indispensable.

## Process
### Étape 1 : Fixer l'objectif et le cadre

Avant de parler de concessions, pose ce qu'on cherche à obtenir : signer au prix affiché, conserver la marge, gagner un engagement de volume, sécuriser un paiement rapide, ou simplement ne pas perdre un client stratégique sur une seule commande. Un objectif flou (« bien négocier ») ne guide aucune décision en séance.

Note aussi le rapport de force réel : ce client pèse-t-il lourd dans le chiffre d'affaires, a-t-il des alternatives crédibles, est-ce la première commande ou la vingtième. Un client récurrent qui négocie dur n'a pas le même traitement qu'un prospect qui teste le terrain une seule fois.

### Étape 2 : Lister les variables négociables avant de toucher au prix

C'est ici que se joue le premier piège du métier : négocier le prix parce que c'est la seule variable qu'on a en tête. Avant d'y arriver, dresse la liste de tout ce qui peut bouger : délai de paiement, mode de paiement (comptant par mobile money contre trente jours à crédit, ce n'est pas neutre pour la trésorerie), volume commandé, durée d'engagement, fréquence de commande, zone et délai de livraison, formation, disponibilité d'un stock dédié, exclusivité territoriale.

Pour chaque variable, indique ce qu'elle coûte à l'entreprise et ce qu'elle vaut pour le client, et ces deux montants ne sont presque jamais égaux. Un paiement comptant par mobile money au lieu d'un chèque à trente jours vaut souvent plus à l'entreprise, en trésorerie, qu'un point de remise ne lui coûte. Une livraison groupée qui évite un aller-retour dans les embouteillages d'Abidjan peut valoir plus au client qu'une remise de deux ou trois pourcents, et coûte moins à l'entreprise qu'une remise équivalente. Range ces variables par coût croissant pour l'entreprise : celles qui coûtent le moins sont celles qu'on propose en premier.

Si l'entreprise n'a pas chiffré ce que coûte chaque variable (le coût réel d'un jour de délai de paiement supplémentaire, le coût d'une livraison hors zone habituelle), tu le marques `⟦à renseigner⟧` plutôt que de l'estimer à sa place.

### Étape 3 : Attacher une contrepartie à chaque concession

Deuxième piège : la concession sans contrepartie. Une remise donnée gratuitement n'achète pas la paix, elle enseigne au client qu'il suffit de demander, et cette leçon se répète à chaque commande suivante. Toute concession envisagée à l'étape 2 doit être associée à ce qu'on demande en échange, même modeste : un engagement de volume, un paiement comptant plutôt qu'à crédit, une commande anticipée, une référence donnée à un autre client, un allongement de la durée du contrat.

Formule chaque paire concession/contrepartie de façon explicite dans la fiche, pas comme une intuition à improviser en séance. Si tu cèdes sur le prix sans rien demander en retour, dis-le clairement au commercial avant qu'il s'assoie : c'est un renoncement, pas une négociation.

### Étape 4 : Poser le plancher et la solution de repli

Troisième piège, le plus coûteux : négocier sans savoir à partir de quel prix ou de quelles conditions l'affaire n'est plus rentable. Négocier sans plancher revient à négocier contre soi, parce qu'on ne sait plus reconnaître le moment où il faut arrêter de céder.

Le plancher est une donnée que l'entreprise doit fournir, jamais une donnée que tu calcules à partir d'hypothèses de marge ou de coûts que tu ne détiens pas. Tant qu'il n'est pas donné, il reste `⟦à renseigner⟧` dans la fiche, et tu le signales comme un manque bloquant pour la conduite sereine de la négociation, même si tu produis le reste.

Prépare aussi la solution de repli : ce qu'on fait si l'accord ne se conclut pas à ce tour, ce round. Une négociation sans repli pousse à accepter n'importe quoi plutôt que de rentrer bredouille.

### Étape 5 : Anticiper les objections courantes

Trois situations reviennent presque systématiquement, et chacune a un traitement propre :

- **La demande de remise systématique**, posée avant même d'avoir discuté du produit. Elle se traite en la renvoyant vers une contrepartie (« sur quel volume ») plutôt qu'en y répondant par un chiffre immédiat.
- **La comparaison avec un concurrent** (« j'ai moins cher ailleurs »). Quatrième piège : croire ce chiffre sur parole. C'est une phrase de négociation avant d'être une information vérifiable. La réponse ne s'aligne pas mécaniquement, elle interroge ce qui est réellement comparé : le même produit, la même quantité, les mêmes délais de paiement, le même service après-vente. Un prix cité sans que l'entreprise ait pu vérifier ce qu'il recouvre reste une donnée non vérifiée, et se marque comme telle dans la fiche.
- **La négociation en plusieurs tours**, fréquente quand le client teste la résistance par étapes successives, parfois sur plusieurs échanges WhatsApp étalés sur des jours. Prévois pour chaque tour ce qui a déjà été cédé et ce qui reste en réserve : céder l'ensemble des marges de manœuvre au premier tour ne laisse plus rien à offrir au second, et le client l'interprète comme un signal qu'il faut pousser encore.

### Étape 6 : Conduire, puis documenter, ce qui a été concédé

La négociation elle-même reste entre les mains du commercial ou du responsable habilité : cette compétence ne conclut rien et n'accorde rien. Une fois l'échange terminé (en salon, en rendez-vous, ou étalé sur plusieurs messages WhatsApp), produis le compte rendu : ce qui a été demandé par le client, ce qui a été accordé, contre quelle contrepartie, ce qui reste ouvert pour un tour suivant, et ce qui doit être répercuté dans les documents commerciaux.

Cinquième piège, et le plus discret : la remise accordée oralement ou par écrit informel et jamais reportée dans le devis, la facture ou le système de gestion. Ce qui a été concédé et non écrit sera concédé une seconde fois à la commande suivante, parce que ni le commercial suivant ni le système ne s'en souviendront. Le compte rendu liste explicitement les documents à mettre à jour : devis, bon de commande, facture, avoir, contrat cadre.

## Format de sortie
- **Livrable 1, la fiche de préparation** : objectif chiffré, variables négociables classées par coût pour l'entreprise, contrepartie attendue pour chacune, plancher fourni par l'entreprise (`⟦à renseigner⟧` sinon), solution de repli si l'accord ne se fait pas, objections attendues et réponses préparées.
- **Livrable 2, le compte rendu de négociation** : ce qui a été demandé, ce qui a été accordé, contre quoi, ce qui reste ouvert pour un prochain tour, et ce qu'il faut répercuter dans les documents commerciaux.
- **Structure** : Markdown clair, tableaux pour les paires concession/contrepartie et pour le compte rendu, answer-first (l'objectif et le plancher en tête de la fiche).
- **Longueur** : proportionnée à l'enjeu réel de la négociation ; une fiche de préparation tient sur une page, le compte rendu tient en quelques lignes à une demi-page.
- **Le plancher et les seuils de réussite sont un input**, jamais une production de la skill : elle livre la structure, la question à trancher, et laisse la valeur en `⟦à renseigner⟧` tant qu'elle n'est pas donnée par l'entreprise.
- **Règle 0 invention** : aucun prix, aucune remise, aucun coût de variable, aucune information sur un concurrent n'est produit sans être fourni ou vérifié. Si une information manque, elle est marquée `⟦à renseigner⟧` ou `[à confirmer]`.

## Règles
1. **Le prix n'est jamais la première variable travaillée.** La liste des variables non tarifaires (délai de paiement, volume, livraison, durée, formation, stock dédié) est produite avant toute discussion sur une remise.
2. **Aucune concession sans contrepartie.** Chaque ligne de la fiche associe ce qu'on cède à ce qu'on demande en retour, même modeste. Une concession isolée sans contrepartie est signalée comme un renoncement, pas comme une négociation réussie.
3. **Le plancher vient de l'entreprise, jamais d'un calcul de la skill.** Tant qu'il n'est pas fourni, il reste `⟦à renseigner⟧`, et son absence est signalée comme un manque bloquant pour une négociation sereine.
4. **Un chiffre de concurrent cité par le client n'est pas une donnée vérifiée.** Il se traite en interrogeant ce qui est comparé, jamais en s'alignant dessus par défaut.
5. **Ce qui est concédé doit être écrit et transmis.** Le compte rendu liste explicitement les documents (devis, facture, avoir, contrat) à mettre à jour ; une concession orale ou perdue dans un fil WhatsApp non reportée est un risque signalé, pas un détail.
6. **Cette skill ne négocie pas et n'accorde rien.** Elle prépare la fiche et documente le compte rendu ; la décision de céder ou de refuser reste au responsable commercial.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer un devis modifié, confirmer une remise au client ou mettre à jour la facture est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une négociation avec un client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Plancher non fourni** : tu produis la fiche complète avec le plancher en `⟦à renseigner⟧`, et tu signales explicitement que la négociation ne devrait pas s'engager sans cette information.
- **Client informel, pas de contrat écrit** : tu prépares la fiche normalement, et tu insistes davantage sur le compte rendu écrit après coup, précisément parce que rien d'autre ne fixera ce qui a été convenu.
- **Négociation déjà en cours sur plusieurs tours** : tu demandes ce qui a déjà été cédé avant de préparer la suite, pour ne pas rouvrir une marge de manœuvre déjà consommée.
- **Chiffre du concurrent donné sans vérification possible** : tu le traites comme une déclaration du client, pas comme un fait, et tu le marques `[non vérifié]` dans la fiche.
- **Demande de remise sans aucune autre information** : tu produis quand même la structure de la fiche avec les variables non tarifaires en premier, et tu marques les manques plutôt que d'inventer un contexte.
- **Source ou connecteur inaccessible** (historique client, CRM) : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné.
- **Concession déjà accordée oralement, à documenter a posteriori** : tu produis le compte rendu à partir de ce qui est rapporté, en marquant `[rapporté, non vérifié]` si aucune trace écrite ne l'accompagne.
- **Demande hors périmètre** (fixer un tarif catalogue, construire une grille tarifaire) : tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoyer le devis corrigé, confirmer la remise par écrit au client) : tu prépares le contenu et tu t'arrêtes pour validation humaine avant tout envoi.
