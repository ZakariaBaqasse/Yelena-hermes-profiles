---
id: Y0604
name: sales-objection-handler
description: >
  Prépare les réponses aux objections que le client entend vraiment, en séparant l'objection
  réelle du prétexte, et en donnant pour chacune une réponse principale, une réponse de repli
  et la question qui fait avancer. À charger avant un rendez-vous difficile, pour outiller une
  équipe commerciale, ou quand une affaire cale toujours au même endroit.
bucket: B
tags: [Sales]
version: 1
maj: 2026-09-07
---

# Traiter les objections

## Le principe qui commande tout

**Une objection n'est presque jamais ce qu'elle dit.** « C'est trop cher » signifie le plus
souvent « je ne vois pas ce que ça me rapporte », parfois « je n'ai pas le budget ce
trimestre », parfois « je n'ai pas le pouvoir de décider et je n'ose pas le dire ».

Répondre au mot prononcé, c'est baisser le prix d'une affaire qui n'avait pas de problème de
prix. Le travail commence donc par identifier laquelle des trois on a devant soi.

## Ce que je demande

1. **Ce que vend le client** et à qui.
2. **L'objection qu'il entend le plus souvent**, dans les mots exacts du prospect si possible.
3. **À quel moment elle tombe** : au premier contact, après le devis, ou juste avant la
   signature. Le moment change complètement le diagnostic.

Si le client ne cite aucune objection, je pars des objections documentées de son secteur et
je le dis clairement.

## La méthode

### 1. Qualifier l'objection avant d'y répondre

Trois familles, trois traitements opposés :

| Famille | Ce qu'on entend | Ce que ça veut dire | Ce qu'on fait |
|---|---|---|---|
| **Valeur** | « C'est trop cher », « je vais réfléchir » | La valeur n'est pas établie | On revient sur le coût du problème, pas sur le prix de la solution |
| **Moyen** | « Pas de budget cette année » | La valeur est comprise, le calendrier bloque | On travaille l'échéance et l'échelonnement, pas l'argumentaire |
| **Pouvoir** | « Je dois en parler », « on verra plus tard » | On ne parle pas au décideur | On demande à qui d'autre en parler, et on l'obtient |

Une seule question permet souvent de trancher : **« si le prix n'était pas un sujet, vous le
feriez ? »** Un oui déplace vers la famille Moyen. Un non ou une hésitation prouve que le
prix n'était pas l'objection.

### 2. Trois niveaux de réponse par objection

Pour chacune, j'écris :

- **La réponse principale**, courte, qui traite la cause identifiée et non le mot prononcé.
- **La réponse de repli**, quand la première ne passe pas. Elle change d'angle, elle ne
  répète pas la première plus fort.
- **La question qui fait avancer**, posée après la réponse. Sans elle, l'échange s'arrête sur
  la défense du vendeur et le prospect n'a plus rien à faire.

### 3. Ce qui ne se fait jamais

- **Contredire frontalement.** « Non, ce n'est pas cher » oblige le prospect à défendre sa
  position, et il la défendra.
- **Baisser le prix pour lever une objection de valeur.** La remise ne se donne jamais sans
  contrepartie ferme, mesurable et écrite : un volume, une durée, une avance, une référence
  citable. Et elle ne s'accorde pas en séance, l'octroi n'appartient pas à celui qui négocie.
- **Inventer un chiffre pour convaincre.** Un retour sur investissement improvisé se vérifie,
  et il ne survit pas au premier tableur du client.
- **Insister après un troisième refus.** À ce stade l'affaire n'est pas mûre. On la remet au
  vivier avec une date de réexamen, et on le dit.

### 4. L'objection qu'on n'entend pas

La plus coûteuse est celle qui n'est jamais formulée : le prospect trouve poli de ne rien
dire et disparaît. Je fais donc écrire au client **la question qu'il n'ose pas poser** à la
fin de chaque rendez-vous : « qu'est-ce qui vous ferait renoncer ? ». Elle fait sortir
l'objection tant qu'on peut encore la traiter.

## Mode borne : cinq objections à partir d'une seule phrase

Sur un salon, le recueil ne se fait pas : le visiteur ne citera pas les mots exacts d'un
prospect, il ne saura pas dire à quel moment l'objection tombe, et il repart dans trois
minutes. Voici ce qui remplace le recueil, et ce qu'il faut s'interdire de deviner.

**Une seule question, et elle donne tout :** « la dernière fois qu'on vous a dit non, c'était
sur quoi ? » Le visiteur répond par une objection réelle, dans ses mots, et le plus souvent
il en enchaîne deux ou trois sans qu'on relance.

**Le moment, lui, ne se devine pas.** Il commande le diagnostic, donc en son absence je ne
choisis pas de famille à sa place : j'écris la même objection sur deux lignes, une par moment
plausible, avec les deux traitements opposés. Le visiteur reconnaît son cas en le lisant, et
c'est plus rapide que de le lui demander.

| L'objection | Si elle tombe au premier contact | Si elle tombe après le devis |
|---|---|---|
| « C'est trop cher » | Famille Valeur, le problème n'est pas chiffré | Famille Moyen ou Pouvoir, la valeur passait, le budget ou le mandat bloque |
| « Je vais réfléchir » | Famille Pouvoir, on ne parle pas au décideur | Famille Valeur, quelque chose n'a pas été traité et n'a pas été dit |

**Ce que je ne fais pas en mode borne :** partir des objections documentées d'un secteur que
le visiteur n'a pas nommé précisément. Un tableau de cinq objections génériques, mis en forme,
sort de la borne avec l'autorité d'un document préparé pour lui, et il n'a été préparé pour
personne. Quand il ne donne aucune objection, je livre deux lignes sur celles qu'il a citées
et j'écris que les trois autres attendent son mot à lui.

## Un exemple complet, de bout en bout

⚠️ Visiteur fictif, écrit pour calibrer le format. Aucun élément de cet exemple ne se
réemploie chez un client réel.

**Ce qu'il dit :** « Je vends un logiciel de caisse aux boutiques. La dernière fois qu'on m'a
dit non, c'était : votre truc, ça va me prendre trois semaines à mettre en place. »

**Ce que l'objection dit et ce qu'elle veut dire.** Elle porte sur le délai et se présente
comme un obstacle pratique. Elle appartient pourtant à la famille Valeur : trois semaines
n'est un problème que parce que le gain n'est pas assez net pour les justifier. Le signe qui
le confirme se teste en une question, et c'est la première ligne du tableau.

| | Contenu |
|---|---|
| **Objection** | « Ça va me prendre trois semaines à mettre en place » |
| **Famille** | Valeur, à confirmer par la question de tri |
| **Question de tri** | « Si c'était installé demain matin, vous le prendriez ? » Un oui déplace vers Moyen, le délai devient une question de calendrier. Une hésitation confirme Valeur. |
| **Réponse principale** | « Les trois semaines, c'est nous qui les passons, pas vous : la saisie du catalogue est de notre côté. De votre côté, ce sont deux heures de formation, un matin. » Elle traite la cause réelle, qui est la charge redoutée et non la durée. |
| **Réponse de repli** | Changer d'angle et non répéter plus fort : « Combien de temps passez-vous aujourd'hui à faire votre caisse le soir ? » Elle met en face une charge qui existe déjà, et que le visiteur peut chiffrer lui-même. |
| **Question qui fait avancer** | « Sur quelle période de l'année vous ne voudriez surtout pas que ça tombe ? » Elle transforme un refus en question de calendrier, et elle donne la date de relance. |

**Ce que cet exemple ne contient pas, volontairement :** aucun chiffre de gain, aucun temps
gagné, aucun retour sur investissement. Le visiteur n'en a fourni aucun. La réponse de repli
fait chiffrer le client à sa place, ce qui est le seul moyen honnête d'avoir un chiffre en
trois minutes.

## Comment on rate cette compétence

Quatre façons, toutes observées :

- **Répondre au mot prononcé.** C'est la faute que la compétence existe pour éviter, et elle
  revient dès que le temps manque : on entend « trop cher », on argumente sur le prix, et on
  finit par proposer une remise à une affaire qui n'avait pas de problème de prix.
- **Choisir la famille à la place du client** quand le moment de l'objection est inconnu. La
  bonne sortie est de montrer les deux diagnostics, jamais d'en retenir un au hasard.
- **Livrer vingt objections génériques.** Un tableau long a l'air d'un travail sérieux et il
  ne sert à personne : ce qui compte, ce sont les cinq que le client entend vraiment.
- **Fabriquer le chiffre qui rend la réponse convaincante.** Un retour sur investissement
  improvisé en séance se vérifie au premier tableur, et il emporte avec lui la crédibilité de
  tout le reste du document.

## Ancrage local

`memory/reference/vendre-en-cote-d-ivoire.md`. Sur un marché où tout le monde se connaît,
une objection mal traitée circule. Le prospect qui dit non aujourd'hui parle à celui qui
dirait oui demain, et la manière dont on prend son refus compte autant que l'argumentaire.

## Format de sortie

Un tableau : objection · famille · réponse principale · repli · question de relance. Cinq
lignes au maximum, celles que le client entend vraiment. Une liste de vingt objections
génériques ne sert à personne.

## Garde-fous

- **0 invention.** Aucun chiffre, aucun fait inventé. Ce qui manque se demande ou se marque
  `[à confirmer]`. Une case vide vaut mieux qu'un chiffre faux.
- **0 prix qui ne vient pas du client.** Un montant absent de sa grille sort en `[à confirmer]`.
  Un prix plausible avancé en séance devient une promesse.
- **Aucune action sortante sans validation.** Je prépare l'envoi, je m'arrête pour un accord
  humain explicite.
- **Cloisonnement.** Ce que j'apprends d'une entreprise ne sert qu'à elle. Ni chiffre, ni nom
  de client, ni élément de stratégie ne passe d'une entité à l'autre dans la même conversation.
- **Produis, ne bloque pas.** Avec ce que j'ai, je produis en étiquetant mes hypothèses
  (`[hypothèse : …]`). Je ne réclame que ce qui est indispensable et impossible à supposer.

## Cas limites

- **Le client ne sait pas répondre** à une question du recueil : c'est en soi une information.
  Je le note et je continue ; un vide identifié vaut mieux qu'une réponse fabriquée.
- **Source ou connecteur inaccessible** : je signale le trou et je travaille avec ce que j'ai.
  Je ne présente jamais un élément comme sourcé sans l'avoir lu.
- **Sources contradictoires** : j'expose les deux versions et je demande l'arbitrage.
- **Demande hors périmètre** : je le dis en une phrase, je traite ce qui relève de mon champ,
  et j'oriente vers la compétence qui convient.
