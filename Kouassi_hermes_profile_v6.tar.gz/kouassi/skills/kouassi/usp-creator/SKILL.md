---
id: Y0622
name: usp-creator
description: >
  Trouve ce qui distingue réellement une offre de ses alternatives, et le formule en trois
  longueurs utilisables : la phrase de trente secondes, le paragraphe écrit, la ligne unique.
  Repose sur le test du contraire : une différence qu'un concurrent peut affirmer aussi n'est
  pas une différence. À charger dès qu'un client demande son argumentaire, sa proposition de
  valeur, « pourquoi nous », ou une accroche commerciale.
bucket: B
tags: [Sales]
version: 1
maj: 2026-09-07
---

# Ce qui vous distingue vraiment

## Ce que produit cette compétence

Un argument différenciant en trois longueurs, plus la preuve qui le tient debout. Rien
d'autre. Ce n'est ni un positionnement de marque, ni une signature publicitaire : c'est ce
que le commercial dit quand on lui demande pourquoi le choisir lui.

## Ce que je demande, dans cet ordre

1. **Ce que vous vendez**, en une phrase, comme vous le diriez à un voisin.
2. **À qui**, précisément. « Les PME » n'est pas une réponse : quelle taille, quel secteur,
   qui décide.
3. **Ce que disent vos clients actuels.** Leurs mots, pas les vôtres. Une phrase entendue au
   téléphone vaut dix adjectifs choisis en réunion. S'ils n'en ont aucun sous la main, je le
   note et je poursuis avec `[à confirmer]`.
4. **Les trois alternatives réelles du client** : les deux concurrents qu'il cite vraiment,
   et **ne rien faire**, qui est presque toujours la première.

## La méthode

### 1. Lister les alternatives avant les qualités

Un différenciateur n'existe que par rapport à quelque chose. Je pose les trois alternatives
d'abord, et j'écris pour chacune ce qu'elle donne au client. « Ne rien faire » compte comme
une alternative à part entière et c'est souvent celle qui gagne.

### 2. Le test du contraire

Pour chaque qualité avancée, je me demande : **est-ce qu'un concurrent pourrait affirmer
l'inverse sans mentir ?**

- « Nous sommes à l'écoute de nos clients. » Le contraire est indéfendable, personne ne se
  dit sourd. Ce n'est donc pas un différenciateur, c'est une politesse.
- « Nous livrons dans les 48 heures à Abidjan et Bouaké. » Le contraire est parfaitement
  défendable, un concurrent peut livrer en une semaine et l'assumer. C'est un différenciateur.

Tout ce qui échoue à ce test sort de la liste. Il en reste rarement plus de deux.

### 3. Le test de la preuve

Ce qui reste doit être **démontrable en une phrase**, avec un chiffre, un nom, un délai ou
un document. Sans preuve, ce n'est pas un argument, c'est une promesse, et une promesse se
retourne au premier client déçu.

Si le client n'a aucune preuve, je le dis franchement et je propose la seule chose honnête :
un argument plus modeste et vérifiable plutôt qu'un argument fort et invérifiable.

### 4. Formuler en trois longueurs

- **Trente secondes, debout.** Deux phrases. Ce qu'on fait, pour qui, et la différence. On
  doit pouvoir le dire sans reprendre son souffle.
- **Un paragraphe écrit.** Quatre à six lignes, pour un courriel ou une proposition. La
  différence, la preuve, et ce que ça change pour l'interlocuteur.
- **Une ligne.** Pour une signature de courriel, un profil, une carte de visite. Sept mots
  au maximum.

Les trois disent la même chose. Si elles disent trois choses, c'est que la différence n'est
pas encore trouvée.

### 5. La version négative

Je termine toujours par ce que l'offre **ne fait pas** ou **ne fait pas bien**, en une ligne.
C'est la partie que les clients retiennent, parce qu'elle rend le reste crédible, et c'est
celle qui évite les affaires mal engagées qui pourrissent le trimestre.

## Mode borne : produire à partir d'une seule phrase

Sur un salon, le recueil en quatre points ne se fait pas. Le visiteur donne une phrase sur ce
qu'il vend, il n'a aucun mot de client sous la main, il ne citera pas ses concurrents, et il
repart dans deux minutes. La compétence doit produire quand même, sinon elle manque au moment
où elle sert le plus.

Deux questions remplacent les quatre du recueil, et il n'en faut pas davantage :

1. **« Votre dernier client, il vous a choisi plutôt que quoi ? »** Elle donne l'alternative
   réelle sans jamais prononcer le mot concurrent, et le visiteur y répond toujours, parce
   qu'il pense à une personne précise.
2. **« Qu'est-ce qu'il vous a dit quand ça a marché ? »** Une phrase entendue, même
   approximative, vaut mieux que trois adjectifs choisis. Si rien ne vient, je passe.

Ce qui tient avec cela seul :

- **« Ne rien faire » reste disponible** comme alternative, y compris quand aucun concurrent
  n'est nommé. C'est la seule qui ne demande aucune information au visiteur.
- **Le test du contraire ne lui demande rien** : il s'applique à ses propres mots, sur place,
  et il élimine l'essentiel de ce qu'il vient de dire. C'est l'étape à ne jamais sauter, y
  compris à deux minutes, parce que c'est elle qui produit la valeur.
- **La preuve manquante se marque, elle ne se comble pas.** Un argument portant
  `[preuve à confirmer]` est un livrable. Le même argument avec un chiffre plausible est ce
  qui fera perdre l'affaire à laquelle il servira, six semaines plus tard, devant un tableur.

Ce que je ne produis pas en mode borne : la version négative, qui suppose de connaître les
affaires que le visiteur a mal engagées. Je dis qu'elle manque et pourquoi elle compte.

## Un exemple complet, de bout en bout

⚠️ Visiteur fictif, écrit pour calibrer le format. Aucun élément de cet exemple ne se
réemploie chez un client réel.

**Ce qu'il dit à la borne :** « Je fais de la maintenance de groupes électrogènes pour des
PME. »

**Première question, l'alternative.** « Votre dernier client, il vous a choisi plutôt que
quoi ? » Réponse : « Plutôt que d'appeler le mécanicien du quartier quand ça tombe en panne. »

**Seconde question, le mot du client.** « Qu'est-ce qu'il vous a dit quand ça a marché ? »
Réponse : « Que pour la première fois il n'avait pas eu de coupure pendant les inventaires. »

**Les alternatives, écrites avant les qualités :**

| Alternative | Ce qu'elle donne au client |
|---|---|
| Ne rien faire | Aucun coût jusqu'à la panne, puis un arrêt d'activité de durée inconnue |
| Le dépanneur appelé en urgence | Une intervention, sans visibilité sur la panne suivante |
| Un contrat de maintenance préventive | Des visites programmées et un coût connu d'avance |

**Le test du contraire, appliqué à ses propres mots :**

| Ce qu'il a dit | Un concurrent peut-il affirmer l'inverse sans mentir ? | Verdict |
|---|---|---|
| « On est réactifs » | Non, personne ne se dit lent | Sort |
| « On connaît bien le matériel » | Non | Sort |
| « On intervient sur site sous quatre heures » | Oui, un concurrent peut annoncer deux jours et l'assumer | Garde |
| « On passe avant les périodes où le client ne peut pas s'arrêter » | Oui | Garde |

Il en reste deux, ce qui est le résultat normal.

**Les trois longueurs :**

- **Trente secondes, debout.** « On entretient les groupes électrogènes des PME. Ce qui nous
  distingue, c'est qu'on passe avant vos périodes critiques et non après la panne : nos
  clients ne s'arrêtent pas pendant leurs inventaires. »
- **Un paragraphe écrit.** « Nous entretenons les groupes électrogènes de PME qui ne peuvent
  pas se permettre une coupure. Notre organisation repose sur deux engagements : les visites
  sont programmées avant vos périodes critiques, que vous nous indiquez en début d'année, et
  une intervention sur site se déclenche sous quatre heures. Concrètement, cela déplace la
  question de la rapidité du dépannage vers celle de la panne qui n'a pas lieu au mauvais
  moment. »
- **Une ligne.** « La panne qui n'arrive pas pendant l'inventaire. »

**La preuve : `[à confirmer]`.** Il n'a fourni ni taux de disponibilité, ni nom citable. Les
deux arguments gardés tiennent sans chiffre parce qu'ils décrivent un mode d'organisation,
vérifiable sur un calendrier de visites et dans un contrat. S'il avait voulu annoncer un taux
de disponibilité, il fallait le chiffre, ou rien.

## Comment on rate cette compétence

Quatre façons, toutes observées :

- **Sauter le test du contraire** parce que le temps manque, et rendre une liste de qualités
  qu'aucun concurrent ne contesterait. Le livrable a l'air complet et il ne distingue rien.
- **Compléter la preuve** pour que l'argument sonne mieux. C'est la faute la plus coûteuse de
  la compétence, et la plus difficile à repérer une fois le document mis en forme.
- **Rendre trois longueurs qui disent trois choses différentes.** Le signe que la différence
  n'est pas trouvée, et le moment de revenir au test du contraire au lieu de rédiger.
- **Livrer sans avoir posé « plutôt que quoi ? »**, donc sans alternative, donc sans point de
  comparaison. Une différence sans référence n'est pas une différence.

## Ancrage local

Voir `memory/reference/vendre-en-cote-d-ivoire.md` avant de formuler : l'argument sera dit
sur WhatsApp bien plus souvent qu'en réunion, donc la version « trente secondes » doit tenir
en un message qui ne se replie pas sur un téléphone.

Le prix en franc CFA, jamais en euros ni en dollars, sauf demande explicite.

## Format de sortie

Un tableau à trois lignes (les trois longueurs), suivi de la preuve associée et de la ligne
négative. Puis, si le client le souhaite, une page partageable via `publication-frames`.

## Garde-fous

- **0 invention.** Aucun chiffre, aucun fait inventé. Ce qui manque se demande ou se marque
  `[à confirmer]`. Une case vide vaut mieux qu'un chiffre faux.
- **0 prix qui ne vient pas du client.** Un montant absent de sa grille sort en `[à confirmer]`.
  Un prix plausible avancé en séance devient une promesse.
- **Aucune action sortante sans validation.** Je prépare l'envoi, je m'arrête pour un accord
  humain explicite.
- **Cloisonnement.** Ce que j'apprends d'une entreprise ne sert qu'à elle. Ni chiffre, ni nom
  de client, ni élément de stratégie ne passe d'une entité à l'autre dans la même conversation.
- **Produis, ne bloque pas.** Avec ce que j'ai, je produis en étiquetant mes hypothèses
  (`[hypothèse : …]`). Je ne réclame que ce qui est indispensable et impossible à supposer.

## Cas limites

- **Le client ne sait pas répondre** à une question du recueil : c'est en soi une information.
  Je le note et je continue ; un vide identifié vaut mieux qu'une réponse fabriquée.
- **Source ou connecteur inaccessible** : je signale le trou et je travaille avec ce que j'ai.
  Je ne présente jamais un élément comme sourcé sans l'avoir lu.
- **Sources contradictoires** : j'expose les deux versions et je demande l'arbitrage.
- **Demande hors périmètre** : je le dis en une phrase, je traite ce qui relève de mon champ,
  et j'oriente vers la compétence qui convient.
