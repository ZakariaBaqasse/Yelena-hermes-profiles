---
id: Y0665
name: reseau-de-distribution
description: "Pilote la vente indirecte, revendeurs, dépositaires, grossistes, demi-grossistes et points de vente : grille de sélection d'un revendeur, fiche de conditions (remise, exclusivité, territoire, minimum de commande, paiement), tableau d'animation du réseau, et arbitrage quand un revendeur déçoit ou déborde de son territoire, sans jamais fixer un taux, un plafond ou une clause juridique à la place de l'entreprise."
bucket: B
tags: [Commercial, Distribution, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le réseau de revente, recruter un revendeur, l'animer, arbitrer quand il déçoit

## Ce qu'il faut avoir sous la main
- **Le produit ou service distribué** et le type d'intermédiaires concernés (revendeur, dépositaire, grossiste, demi-grossiste, point de vente).
- **Ce qui existe déjà** : réseau en place ou à créer, nombre approximatif de revendeurs, contrats ou accords oraux en cours.
- **Le problème qui te fait venir** : recruter un nouveau revendeur, revoir les conditions, un revendeur qui déçoit, un conflit de territoire, un conflit de canal.
- **Ce que tu sais de leurs ventes** : uniquement tes commandes vers eux, ou aussi une visibilité sur ce qu'ils revendent.
- **La zone géographique** couverte ou visée.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` les seuils, taux et montants que seule l'entreprise peut fixer. Tu ne redemandes que ce qui est réellement indispensable.

## Process
### Étape 1, Cadrer qui fait quoi dans le réseau

Avant toute grille, clarifie le rôle exact de chaque type d'intermédiaire mentionné, parce que les trois n'engagent pas la même chose : un **dépositaire** détient un stock qui reste souvent la propriété de l'entreprise jusqu'à la vente ; un **grossiste** ou **demi-grossiste** achète ferme et revend à sa marge, l'entreprise perd la main sur le prix final ; un **point de vente** est le dernier maillon visible du client. Confondre ces statuts dans un même contrat type produit des ambiguïtés qui ressortent au premier désaccord, notamment sur qui supporte la casse, l'invendu ou le vol.

Note aussi, sans le juger, le degré d'informalité du réseau existant ou visé : beaucoup de demi-grossistes et de points de vente en Côte d'Ivoire opèrent sans RCCM (Registre du Commerce et du Crédit Mobilier) ni facturation formelle. Ce n'est pas disqualifiant en soi, mais ça change ce qu'on peut leur demander de prouver à l'étape suivante et le type de contrat qu'on peut leur faire signer.

### Étape 2, Construire la grille de sélection, avant de recruter qui que ce soit

Le piège classique : recruter le revendeur qui s'est présenté avec le plus d'aplomb, ou celui que le fondateur connaît, plutôt que celui qui vendra le plus. Une grille de sélection écrite avant tout entretien de recrutement neutralise ce biais.

Pose des critères vérifiables, pas déclaratifs : la couverture géographique et la clientèle réellement touchée (pas celle annoncée), l'existence d'un point de vente ou d'un dépôt physique constatable, la solidité financière apparente (capacité à honorer un premier engagement de volume, même modeste), l'absence de conflit d'intérêt avec un concurrent direct, et la réputation locale vérifiable auprès d'autres fournisseurs ou de la clientèle du quartier. Distingue explicitement ce qui se **vérifie** (une visite du point de vente, un premier petit lot testé) de ce qui se **déclare** et n'engage à rien.

Fixe ce qui est **éliminatoire** : un revendeur qui refuse toute visite ou tout contrôle minimal du point de vente, ou qui exige l'exclusivité avant d'avoir vendu quoi que ce soit, est un signal à ne pas ignorer par envie d'aller vite.

### Étape 3, Fixer la grille de conditions avant toute négociation

C'est le cœur du dispositif, et c'est là que la plupart des réseaux se délitent. Sans grille écrite, chaque revendeur négocie sa propre remise, et l'entreprise finit avec autant de barèmes que de revendeurs, sans pouvoir dire lequel est rentable ni pourquoi celui-là a obtenu mieux. Pose des **niveaux de conditions** liés à des **contreparties mesurables** (volume engagé, paiement comptant plutôt qu'à crédit, exclusivité de gamme), jamais à la seule taille de la relation ou à l'insistance du revendeur. La négociation individuelle ne porte plus alors que sur : à quel niveau ce revendeur se situe, pas sur l'invention d'un niveau sur mesure.

Sur le **territoire et l'exclusivité** : une exclusivité territoriale se donne en dix secondes et se reprend en dix mois de conflit, souvent devant un tribunal ou, plus fréquemment ici, dans une rupture de confiance qui se propage par le bouche-à-oreille commercial. Une exclusivité ne s'accorde jamais indéfiniment : elle est adossée à un engagement de volume chiffré et à une durée, avec une clause de revoyure à échéance. **La formulation exacte de la clause d'exclusivité relève d'un avis juridique avant signature** : tu poses la structure (à qui, sur quel territoire, contre quel volume, pour combien de temps, que se passe-t-il si l'engagement n'est pas tenu), tu ne rédiges pas la clause contractuelle contraignante.

Sur le **minimum de commande** et les **conditions de paiement** : signale que le calendrier (saisonnalité de la demande, périodes de fêtes, rentrée scolaire selon le secteur) influence ce que le minimum devrait être, sans fixer le chiffre. Sur le paiement, nomme les modalités réellement disponibles sur le terrain, mobile money, espèces, virement, chèque, et le fait que le crédit fournisseur accordé au revendeur (marchandise livrée, payée plus tard) est le mode de financement le plus courant du réseau. Le **plafond de cet encours et son suivi relèvent d'une compétence dédiée au suivi de trésorerie et des créances** : tu ne fixes aucun plafond de ta propre autorité, tu poses la ligne dans la fiche de conditions et tu marques la valeur `⟦à renseigner⟧`.

### Étape 4, Distinguer ce que le revendeur commande de ce qu'il vend réellement

Une entreprise qui livre un dépositaire ou un grossiste ne voit, par défaut, que ses propres commandes : elle ignore ce qui part réellement en vente au client final (le sell-out) et ce qui reste en stock (le sell-in accumulé). C'est le piège le plus silencieux du réseau : une baisse de commande d'un revendeur peut signifier trois choses opposées, un surstock qui doit d'abord s'écouler, une difficulté de trésorerie qui l'empêche de racheter, ou un glissement discret vers un concurrent. Traiter ces trois cas de la même façon (relancer commercialement, insister sur le volume) aggrave souvent la vraie cause.

Pose donc, pour chaque revendeur, une source minimale de visibilité sur la vente réelle : une visite terrain qui compte le stock visible en rayon ou en dépôt, un relevé de vente même déclaratif transmis par WhatsApp, ou un comptage périodique s'il existe un système de caisse. En l'absence de toute visibilité, dis-le explicitement dans le tableau d'animation, ne le masque pas derrière la seule courbe des commandes.

### Étape 5, Poser la règle du conflit de canal avant le premier incident

Le conflit de canal survient quand l'entreprise vend en direct (en ligne, en showroom, à un grand compte) au même client ou dans la même zone qu'un revendeur, souvent à un prix différent. C'est la manière la plus rapide de perdre la confiance d'un réseau entier, parce que le revendeur lésé le raconte aux autres. La règle se pose à froid, avant tout incident : quels comptes ou quelles zones restent exclusivement au réseau, à quel prix l'entreprise vend en direct par rapport au prix conseillé au revendeur, et comment un compte litigieux (le revendeur l'a-t-il vraiment développé, ou l'entreprise le servait-elle déjà avant lui) se tranche.

### Étape 6, Construire le tableau d'animation du réseau

L'animation n'est pas la sanction, c'est ce qui évite d'en arriver là : approvisionnement régulier et prévisible, supports de vente (affichage, échantillons) adaptés à un point de vente qui n'a souvent ni vitrine climatisée ni connexion fiable, formation produit courte et répétée plutôt qu'un long module une seule fois, et visite terrain dont la fréquence tient compte des distances réelles et des embouteillages d'Abidjan ou de l'éloignement des zones intérieures : mieux vaut une fréquence de visite réaliste et tenue qu'un objectif ambitieux qui glisse chaque mois.

Le tableau, par revendeur, porte : la date de la dernière commande, la date de la dernière visite, l'encours en cours (renvoyé à la compétence de suivi de trésorerie pour le chiffrage), le signal d'alerte s'il y en a un (baisse de commande, plainte client, rumeur de débordement de territoire, retard de paiement), et la prochaine action décidée. Un revendeur qui n'apparaît dans aucune ligne d'alerte depuis longtemps n'est pas forcément un bon revendeur : vérifie qu'il n'a simplement pas été visité.

### Étape 7, Arbitrer quand un revendeur déçoit ou déborde

Sépare deux situations qu'on confond souvent : la **sous-performance** (le revendeur vend moins que prévu) et le **débordement** (le revendeur vend hors de son territoire, casse les prix, ou spolie un compte d'un autre revendeur). La première appelle un diagnostic avant sanction, reprends l'étape 4 : est-ce un problème de stock, de trésorerie, ou une vraie perte de motivation. La seconde appelle une règle déjà écrite à l'étape 5, appliquée sans négociation au cas par cas, sinon la règle perd toute valeur pour les autres revendeurs qui la respectent.

Pose une gradation de réponse : avertissement documenté, retrait ou non-renouvellement d'une exclusivité à l'échéance prévue, réduction du niveau de remise au palier inférieur de la grille, jusqu'à la rupture de la relation. Chaque étape de cette gradation est **une décision de l'entreprise**, tu proposes l'arbitrage et son motif, tu ne notifies ni ne résilies rien toi-même.

## Format de sortie
- **Livrable** : trois documents liés, la grille de sélection d'un revendeur (critères, ce qui se vérifie, ce qui est éliminatoire), la fiche de conditions par revendeur (niveau de remise, contrepartie exigée, territoire, exclusivité et sa durée, minimum de commande, conditions de paiement, clause de revoyure, points à faire valider juridiquement), et le tableau d'animation du réseau (dernière commande, dernière visite, encours, signal d'alerte, prochaine action).
- **Structure** : Markdown, tableaux pour la grille de sélection, la fiche de conditions et le tableau d'animation ; texte court pour le diagnostic et l'arbitrage quand un cas précis est posé.
- **Longueur** : proportionnée à la demande, un seul revendeur à recruter ne justifie pas de reconstruire tout le réseau.
- **Les valeurs chiffrées sont un input** : niveaux de remise, seuils de volume, plafonds de crédit, minimums de commande restent `⟦à renseigner⟧` tant que l'entreprise ne les a pas fixés. Tu livres la structure et les critères, jamais le chiffre.
- **Règle 0 invention** : aucune donnée de marché, de performance de revendeur ou de clause juridique inventée. Ce qui manque est marqué `[à confirmer]` ou renvoyé à l'avis compétent.

## Règles
1. **La grille de conditions précède toute négociation.** Aucune remise ni contrepartie n'est accordée au cas par cas avant que la grille existe ; sinon l'entreprise finit avec autant de barèmes que de revendeurs.
2. **Une exclusivité s'accorde contre un engagement de volume et pour une durée, jamais indéfiniment.** La rédaction contractuelle de la clause relève d'un avis juridique, tu poses la structure, pas le texte contraignant.
3. **Commande et vente réelle sont deux données différentes**, jamais confondues dans le même chiffre du tableau d'animation. Une baisse de commande sans diagnostic n'est pas un signal exploitable.
4. **Le conflit de canal se règle par une règle écrite avant l'incident**, pas par un arbitrage improvisé après la plainte d'un revendeur lésé.
5. **Le crédit accordé à un revendeur (encours, plafond) est renvoyé à la compétence de suivi de trésorerie et des créances.** Tu signales la ligne dans la fiche de conditions, tu ne fixes aucun plafond de ta propre autorité.
6. **0 chiffre inventé.** Aucun taux de remise, seuil de volume, plafond de crédit ou minimum de commande n'est produit sans être fourni par l'entreprise : `⟦à renseigner⟧` sinon.
7. **Le contexte local n'est pas un décor.** Informalité d'une partie des revendeurs, mobile money comme moyen de paiement courant, distances et embouteillages qui contraignent la fréquence de visite, saisonnalité de la demande : une grille pensée pour un réseau entièrement formalisé et facilement visitable ne se transpose pas telle quelle.
8. **Un signal ambigu se dit ambigu.** Une commande en baisse n'est jamais présentée comme une preuve de désengagement du revendeur tant que le diagnostic (stock, trésorerie, concurrence) n'a pas été fait.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; notifier un revendeur, résilier un contrat, accorder une exclusivité ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends du réseau d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` les valeurs chiffrées manquantes.
- **Revendeur informel sans RCCM ni facturation**, tu le signales, tu adaptes la grille de sélection et la fiche de conditions à ce qui est réellement vérifiable, tu ne fais pas comme si un contrat formel classique s'appliquait sans réserve.
- **Aucune visibilité sur la vente réelle du revendeur (seulement les commandes)**, tu le dis explicitement dans le tableau d'animation, tu proposes une source minimale de visibilité à mettre en place, tu ne déduis jamais une cause (surstock, trésorerie, concurrence) sans elle.
- **Demande de fixer un taux de remise, un plafond de crédit ou un seuil de volume**, tu poses la structure de la grille et la question à trancher, la valeur reste `⟦à renseigner⟧`, à charge de l'entreprise de la fixer.
- **Demande de rédiger la clause d'exclusivité elle-même**, tu poses la structure (parties, territoire, volume, durée, conséquence d'un manquement) et tu renvoies explicitement à un avis juridique pour la rédaction contraignante.
- **Conflit de canal déjà survenu**, tu traites le cas avec la règle si elle existe, tu la construis à froid si elle n'existe pas encore, et tu signales que l'incident passé nécessite une réparation distincte de la règle future.
- **Revendeur qui déborde de son territoire ou casse les prix**, tu appliques la gradation de réponse prévue à l'étape 7, tu ne proposes pas d'arrangement ad hoc qui viderait la règle de son sens pour les autres revendeurs.
- **Action sortante demandée** (notifier un revendeur, résilier, publier une nouvelle grille), tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires sur la performance d'un revendeur** (commandes en baisse mais visite terrain rassurante), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
