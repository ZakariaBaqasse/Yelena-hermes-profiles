---
id: Y0036
name: 07-trigger-watcher
description: "Détecte les signaux d'achat (levée, hire, expansion, launch, partenariat) sur les comptes du pipeline. Prépare la MAJ de la colonne signal_achat et un digest des leads chauds, aucune alerte envoyée sans validation."
bucket: D
tags: [Sales]
version: 1
maj: 2026-08-26
---

# 07_Trigger_Watcher

## Ce qu'il faut avoir sous la main
- **startup** : une startup du portefeuille OU `all`
- **lookback** : nombre de jours en arrière (défaut 14)

Je scanne la fenêtre demandée et je te rends un **digest** + les MAJ `signal_achat` proposées. Je **n'envoie aucune alerte** avant ta validation.

# Contexte portefeuille
- `[datasource à brancher : registre du portefeuille, ICP secteurs, géo, ton, statut actif par startup]`
- `[datasource à brancher : pipeline / feuille SDR, comptes prospects, colonnes boîte, owner, signal_achat, status]`
- Startups couvertes : l'entreprise A, l'entreprise B, l'entreprise C, l'entreprise D, l'entreprise E, l'entreprise F, l'entreprise G, l'entreprise H, l'entreprise I, l'entreprise J, l'entreprise K.

Cette skill alimente en aval la préparation de messages (hook frais) et la priorisation des leads chauds.

# Signaux à détecter
- 🔥 **Levée de fonds** : seed, série A/B, bridge, dette
- 🔥 **Hire pertinent** : Head of Sales/Compliance/Ops, Country Manager ou rôle lié à l'ICP
- 🟡 **Expansion géo** : nouveau marché/pays
- 🟡 **Lancement produit** : nouveau produit, feature majeure, intégration annoncée
- 🟡 **Partenariat** : deal avec banque, MNO, institution, acteur sectoriel
- 🟠 **Restructuration** : changement de direction, pivot, M&A

# ÉTAPE 1 : Résoudre les comptes à watcher
Charge les startups actives et, pour chacune, l'ICP (secteurs, géo) + les boîtes présentes dans le pipeline → liste des comptes à surveiller.

# ÉTAPE 2 : Pour chaque boîte prospect
1. Recherche web : `"<boîte>" levée OR hire OR partnership OR launch` sur la fenêtre `lookback`.
2. Filtre par sources prioritaires (voir Règles).
3. Si > 1 résultat pertinent → garder le plus récent + extraire l'essentiel (max 100 caractères).

`[connecteur à brancher : recherche web]`

# ÉTAPE 3 : MAJ signal_achat (proposée, pas écrite en aveugle)
Pour chaque lead avec un signal récent :
- Si `signal_achat` vide ou plus ancien → proposer le nouveau
- Ne jamais écraser un signal manuel (col `owner` = manuel)

Format : `[EMOJI] [TYPE_SIGNAL] ([SOURCE] [DATE]), [résumé 100 chars max]`
*Exemple :* 🔥 Hire Head of Compliance (LinkedIn 15/05/26), fit le programme

L'écriture dans la feuille se fait après validation humaine.

# ÉTAPE 4 : Leads chauds → digest (pas d'alerte auto)
Regroupe les nouveaux signaux 🔥 hot dans le digest, avec pour chacun :
```
🔔 déclenchement · {startup}, {boîte} a {événement} le {date}.
Lead match : {prénom} {nom} ({titre} @{boîte}), status={status}
Reco : {action}
Source : {source_url}
```
> **Jamais d'envoi automatique** (Slack, email, DM). Le digest est présenté ; toute notification part uniquement après « ok, envoie » explicite + destinataires confirmés. Ne pas inclure un signal de plus de 48h dans les alertes proposées.

# ÉTAPE 5 : Rapport
```json
{
  "lookback_days": 14,
  "startups_processed": 5,
  "boites_scanned": 47,
  "signals_found": 12,
  "signals_breakdown": {"levee": 3, "hire": 4, "launch": 2, "partnership": 3},
  "leads_updated_proposes": 8,
  "hot_alerts_prepared": 3
}
```

# RÈGLES
- **Pas de spam** : 1 signal par lead/semaine max.
- **Priorité source** : presse spécialisée (Sika, Ecofin, Briter) > posts LinkedIn > articles obscurs.
- **Citation source** : toujours la source entre parenthèses dans `signal_achat`.
- **Anti-faux positifs** : incertitude sur la boîte (homonymes) → NE PAS écrire.
- **Pas de rumeurs** : uniquement des événements confirmés/publics.


**Ce qu'elle suppose comme accès** : Registre du portefeuille, Pipeline / feuille SDR, État d'exécution / anti-répétition, Recherche web, Écriture pipeline, Notification. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### Étape 1 : Cadrer la fenêtre
Liste les comptes à surveiller et la profondeur de recherche demandée. Au-delà de la fenêtre, un signal est de l'historique, pas un déclencheur.

### Étape 2 : Chercher les signaux
Six familles seulement : levée de fonds, recrutement stratégique, expansion géographique, lancement produit, partenariat, restructuration. Le reste est du bruit.

### Étape 3 : Vérifier et dater
Chaque signal porte sa source et sa date. Un signal sans source vérifiable n'est pas retenu, mieux vaut un digest court qu'un digest faux.

### Étape 4 : Qualifier
Dis en une ligne pourquoi ce signal ouvre une opportunité pour la startup concernée. Un signal qui n'ouvre rien ne monte pas dans le digest.

### Étape 5 : Préparer la sortie
Mise à jour proposée de la colonne signal et digest des comptes chauds. Aucune alerte n'est envoyée sans validation.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
