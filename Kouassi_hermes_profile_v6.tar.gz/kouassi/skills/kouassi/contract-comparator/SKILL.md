---
id: Y0105
name: contract-comparator
description: "Compare deux contrats clause par clause (tableau côte à côte, risques 🟢🟡🔴, leviers de négociation). Aide à la décision, pas un avis juridique."
bucket: C
tags: []
version: 1
maj: 2026-08-26
---

# Contract Comparator

## Ce qu'il faut avoir sous la main
- Les **2 contrats** (PDF/Word, texte collé, ou lien vers le document), ou 1 contrat + le modèle de référence auquel le comparer.
- Le **contexte** : type de contrat, quelle partie tu représentes (acheteur/vendeur/employeur/preneur…), et l'**objectif** de la comparaison (négocier, choisir la meilleure offre, valider un renouvellement, repérer les écarts vs version précédente).


**Ce qu'elle suppose comme accès** : Bibliothèque de modèles de contrats du client, Espace documentaire du client. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
- Vérifie que tu as bien les **2 contrats** (fichiers PDF/Word, texte collé, ou liens vers le document). Si un seul est fourni, demande le second ou le modèle de référence.
- Vérifie le **contexte** : type de contrat, quelle partie l'utilisateur représente (acheteur/vendeur/employeur/preneur…), et l'**objectif** de la comparaison (négocier, choisir la meilleure offre, valider un renouvellement, repérer les écarts).
- Identifie la **langue** et le **droit applicable** de chaque contrat (peuvent différer).
- Si l'utilisateur veut comparer contre un modèle-type interne plutôt qu'un second contrat fourni, va le chercher dans [datasource à brancher : bibliothèque de modèles de contrats du client (Notion/Drive/GED interne), contient les modèles-types validés par l'entreprise (NDA, contrat fournisseur, contrat de travail…) à utiliser comme référence de comparaison].

### Étape 1 : Extraction structurée

Pour chaque contrat, extrais les clauses dans une grille normalisée (mappe les intitulés différents vers la même rubrique) :
- Parties · Objet / périmètre · Durée & renouvellement · **Prix / rémunération** & révision · Modalités & délais de **paiement** · Livrables / SLA / niveaux de service · **Responsabilité & plafonds** (limitation of liability) · Garanties · **Indemnisation** · **Pénalités** & intérêts de retard · **Résiliation** (motifs, préavis, conséquences) · Exclusivité / non-concurrence / non-sollicitation · **Propriété intellectuelle** & licences · **Confidentialité** / données personnelles · Sous-traitance / cession · Force majeure · **Droit applicable & règlement des litiges** (juridiction/arbitrage) · Assurances / cautions · Clauses inhabituelles.

### Étape 2 : Tableau comparatif (le cœur)

Produis un **tableau côte à côte** :

| Rubrique | Contrat A | Contrat B | Δ Différence | Plus favorable | Risque (🟢/🟡/🔴) |

- **Δ** : décris concrètement ce qui change.
- **Plus favorable** : pour la partie que représente l'utilisateur (A, B, ou neutre), justifie.
- **Risque** : 🟢 standard/ok · 🟡 à surveiller/négocier · 🔴 dangereux/déséquilibré.
- Signale les **clauses présentes dans l'un et absentes dans l'autre** (souvent le plus important).

### Étape 3 : Synthèse décisionnelle

- **TL;DR (5 lignes)** : lequel est globalement plus favorable et pourquoi.
- **Top 5 écarts qui comptent** (impact € / risque / flexibilité).
- **🔴 Points de vigilance** : clauses dangereuses ou inhabituelles (responsabilité illimitée, résiliation déséquilibrée, IP cédée, auto-renouvellement piégeux, pénalités fortes, exclusivité large, juridiction étrangère défavorable…).
- **Leviers de négociation** : 5-10 formulations concrètes à demander pour rééquilibrer.
- **Questions à poser** à la contrepartie / au juriste.

### Étape 4 : Livraison

- Rends la comparaison **dans la conversation** (tableau + synthèse) ET, si demandé, range le comparatif dans [connecteur à brancher : espace documentaire de l'utilisateur (Google Drive/Notion/SharePoint…), créer et classer un document « Comparatif contrats, [sujet], [date] »].
- Message de fin :
> ✅ Comparatif livré, [Contrat A] vs [Contrat B]
> 🏆 Plus favorable : [A/B] · 🔴 [n] points de vigilance · 🤝 [n] leviers de négo
> ⚖️ Faire valider les points 🔴 par un juriste.

## Format de sortie
- **Livrable** : Compare deux contrats clause par clause (tableau côte à côte, risques 🟢🟡🔴, leviers de négociation). Aide à la décision, pas un avis juridique.
- **Structure** : Markdown clair, titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ❌ Ne jamais inventer une clause ou un chiffre : si une clause est absente ou ambiguë, dis-le explicitement (« non stipulé » / « ambigu »).
- ⚖️ Toujours rappeler que ce n'est pas un avis juridique ; escalader les 🔴 vers un juriste.
- 🎯 Toujours analyser **du point de vue de la partie que représente l'utilisateur**.
- 🔐 Confidentialité stricte des contrats.
- 📑 Citer le numéro/section de clause source pour chaque point (traçabilité).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
