---
id: Y0549
name: edition-contrat
description: Workflow systématique en DEUX TEMPS pour toute édition d'un contrat existant. Temps 1 — PROPOSER : sans toucher au contrat, lister précisément les modifications demandées (ancien wording → nouveau wording, article par article), puis attendre. Temps 2 — ÉDITER : UNIQUEMENT quand l'utilisateur valide explicitement (« go / mets à jour / édite »), appliquer les modifs validées dans une NOUVELLE version (_v(N+1)), régénérer le PDF, vérifier, mettre à jour l'index, livrer avec un rapport de changement. Use systématiquement dès qu'on veut modifier/itérer/ajuster un contrat ou un livrable juridique (contrat, avenant, NDA, propale contractuelle) — feedbacks d'advisor/board/avocat, reformulation de clauses, déplacement d'articles, etc. Ne jamais éditer un contrat directement sans être passé par le Temps 1 et avoir obtenu le go.
version: 1
maj: 2026-06-22
---

# Édition de contrat — workflow propose-d'abord, édite-ensuite

Skill qui impose un protocole strict en deux temps dès qu'on veut modifier un contrat (ou tout livrable juridique : avenant, NDA, propale contractuelle). Né d'itérations réelles sur un contrat long (une dizaine de versions successives).

## Règle d'or

**On ne touche JAMAIS au contrat au premier message.** Tout retour (le sien, ou celui d'un advisor/board/avocat relayé) déclenche d'abord une **proposition de modifications**. Le contrat n'est édité qu'**après go explicite**.

Cela vaut même si la demande paraît triviale ou « évidente ». Le go peut reformuler, fusionner, ou rejeter une partie des modifs — c'est exactement le point du Temps 1.

## Quand activer

- L'utilisateur envoie des feedbacks sur un contrat (les siens, ou ceux d'un advisor/board/avocat qu'il relaie)
- « Modifie l'article X », « reformule cette clause », « ajoute une clause », « déplace l'article »
- L'utilisateur colle un wording proposé et demande de l'intégrer
- Toute itération sur un contrat déjà généré (vN → vN+1)
- S'applique aux contrats, avenants, NDA, et tout document contractuel versionné

## TEMPS 1 — Proposer (aucune édition de fichier)

Objectif : que l'utilisateur voie exactement ce qui va changer, **avant** que ça change, et qu'il puisse approuver / amender / rejeter point par point.

1. **Localiser la version courante sur le disque** (jamais de mémoire) :
   - lister le dossier du projet — la version courante = **N max** parmi les fichiers du slug (comparer les N comme des nombres : v19 > v2).
   - Lire le `.md` de cette version pour extraire les **chaînes source exactes** concernées.
2. **Pour chaque point de feedback**, formuler une entrée structurée :
   - le **numéro d'article / l'emplacement** concerné,
   - l'**ancien wording** (citation exacte, ou son extrait pertinent),
   - le **nouveau wording proposé**,
   - si utile, une **note** : implication juridique, risque, incohérence détectée, alternative. (Cf. les réflexes intuitu personae, marchandage/préposé, acompte vs arrhes, obligation de moyens, clause pénale vs dédit, TVA autoliquidation, condition suspensive/résolutoire — voir `references/garde-fous-juridiques.md`.)
3. **Poser les questions ouvertes** quand un feedback est ambigu ou ouvre un choix (ex. « garder 1 mois ou 2 ? »). Ne pas trancher seul un arbitrage de fond.
4. **Envoyer** la liste numérotée des modifs. Pour les citations de wording, **préférer un bloc de code** — plus lisible pour comparer, et plus sûr si le canal de messagerie applique un formatage (Markdown) qui pourrait casser sur des caractères réservés.
5. **S'arrêter là.** Aucun fichier modifié. Attendre la réponse.

> Format de citation conseillé : pour chaque point, un libellé court en gras, puis l'ancien et le nouveau wording. Si le wording est long ou contient des caractères réservés, bloc de code.

## TEMPS 2 — Éditer (uniquement sur go explicite)

Déclencheurs valides : « go », « go pour les points 1 à 5 », « mets le contrat à jour », « édite », « ok pour ça, applique ». Un simple « ok » ambigu en réaction à une question → reconfirmer avant d'éditer.

L'utilisateur peut **amender au moment du go** (ex. « go mais pour (A) je reprends : … »). Toujours intégrer sa formulation finale, pas la proposition initiale.

### Procédure d'édition (déterministe, anti-régression)

1. **Nouvelle version, jamais d'écrasement** : on lit `<slug>_v(N).md` et on écrit `<slug>_v(N+1).md`. On ne réécrit jamais un fichier existant. (Convention de versioning : `_v<N>` numérique, slug stable, même dossier.)
2. **Script Python à asserts** (`assert md.count(old) == 1`) pour chaque remplacement — voir `references/patron-edition.py`. Tout remplacement doit matcher **exactement une** occurrence ; sinon le script lève et on inspecte. Pour un bloc à frontières (chapeau, considérants), repérer par index de deux ancres et remplacer la tranche.
   - **Attention aux apostrophes** : un `.md` mélange souvent `'` ASCII et `'` typographique (U+2019) selon l'historique des écritures. Si un `replace` ne matche pas, grep la ligne réelle et ancre sur une sous-chaîne sans apostrophe. Ne **jamais** utiliser `perl -pe` avec des caractères larges sur un flux UTF-8 (double-encodage → mojibake) ; faire les remplacements en Python `encoding='utf-8'`.
3. **Guard-fous** : asserter aussi ce qu'on veut **conserver** (ex. une clause sensible qui ne doit PAS bouger) et l'**absence** des anciennes chaînes après remplacement.
4. **Régénérer le PDF** : cloner le builder de la version précédente, en n'incrémentant que le numéro de version. Patron sed :
   ```bash
   sed -e 's/_v18/_v19/g' \
       -e 's/build-contract-<projet>-v18/build-contract-<projet>-v19/g' \
       scripts/build-contract-<projet>-v18.py > scripts/build-contract-<projet>-v19.py
   python3 scripts/build-contract-<projet>-v19.py
   ```
   **La charte / le CSS du PDF est figé** : ne jamais le changer sans go explicite. Le builder doit refléter le style existant, pas en diverger.
5. **Vérifier** avant de livrer :
   - `pdfinfo <pdf> | grep Pages` (nombre de pages attendu),
   - `pdffonts <pdf>` → vérifier que la police prévue est bien embarquée (pas de fallback générique inattendu),
   - `pdftotext` + grep des nouvelles chaînes (attention au line-wrap : un grep à 0 ≠ absent, vérifier avec `grep -A2` / la phrase non coupée),
   - `pdftoppm -png -r 110 <pdf>` + **inspection visuelle** de la/les page(s) modifiée(s). Regarder le rendu, pas seulement le succès de la commande.
6. **Mettre à jour l'index des livrables** (s'il existe) : marquer la version précédente « (Superseded par v(N+1).) » et ajouter une ligne `- v(N+1) — md + pdf (… pages). <ce qui a changé, précis, par article>.` L'index peut lui aussi mélanger des apostrophes typographiques — matcher en conséquence.
7. **Livrer** : le PDF en pièce jointe + un **rapport de changement** concis listant ce qui a été appliqué, article par article, et rappelant l'état (« reste : relecture X → envoi Y »).

## Anti-patterns (à ne jamais faire)

- ❌ Éditer le contrat dès le premier message de feedback (sauter le Temps 1).
- ❌ Écraser un fichier de version existant (`_v(N)` → réécrit). Toujours `_v(N+1)`.
- ❌ « Delete + recreate » un livrable pour une simple modif.
- ❌ Changer la charte / le CSS du PDF sans go explicite.
- ❌ Livrer un PDF sans l'avoir regardé visuellement.
- ❌ Trancher seul un arbitrage de fond (montant, durée, présence d'une clause) — poser la question au Temps 1.
- ❌ Déclarer « fait » sur la foi d'un exit 0 sans vérif de rendu.

## Références

- `references/patron-edition.py` — script Python type à asserts (slice par ancres + replace comptés + guard-fous).
- `references/garde-fous-juridiques.md` — réflexes de fond de droit français des contrats (intuitu personae, marchandage/préposé, dédit vs clause pénale, acompte vs arrhes, TVA autoliquidation, conditions suspensive/résolutoire, obligation de moyens, pourparlers).
- Penser à respecter la convention de versioning du projet (`<slug>_v<N>` dans le dossier du projet) et le pipeline de génération PDF existant (charte figée).
