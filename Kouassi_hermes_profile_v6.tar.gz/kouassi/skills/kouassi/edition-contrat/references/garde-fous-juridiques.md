# Garde-fous juridiques — réflexes de fond sur l'édition de contrats

Réflexes de droit français des contrats, à mobiliser au **Temps 1** (proposition) pour signaler les implications d'une modif demandée — jamais comme prétexte pour trancher seul un arbitrage de fond. Adapter au droit applicable du contrat concerné.

## Intuitu personae
- Un contrat « conclu en considération d'une personne nommée » devient fragile si cette personne part : risque de nullité / inexécution.
- **Parade** : engager le prestataire sur un **profil / niveau de séniorité** (ex. « Lead », « Product Manager senior »), pas sur une personne. Ne nommer un intervenant que comme **titulaire actuel** (« assuré à ce jour par M. … »).
- Ajouter une clause explicite « **Caractère non intuitu personae** » : départ/remplacement d'un intervenant nommé n'affecte ni la validité ni la poursuite, le prestataire assurant la continuité par un profil équivalent.
- Un « droit de regard » du client sur le remplaçant ne doit pas re-créer l'intuitu personae → le préciser.

## Marchandage / prêt de main-d'œuvre illicite
- Risque si un intervenant du prestataire apparaît subordonné au client.
- **Bouclier** : « préposés du prestataire, sans lien de subordination à l'égard du client », autorité hiérarchique/technique conservée par le prestataire.
- Nuance terminologique : dans le **préambule** descriptif on peut préférer « collaborateurs » (moins juridique) ; mais **conserver « préposés »** dans la clause anti-marchandage générique (terme juridiquement porteur). Ne pas confondre les deux emplacements.

## Faculté de dédit vs clause pénale
- **Faculté de dédit** : permet de sortir moyennant une indemnité prévue — n'est PAS une clause pénale (pas révisable par le juge au titre de l'art. 1231-5 C. civ.).
- Si on qualifie l'indemnité « non assimilable à une clause pénale », attention à ne pas se contredire ailleurs.
- Durée ferme + dédit = engagement ferme côté client, sortie encadrée.

## Acompte (à-valoir) vs arrhes
- **Acompte / à-valoir** : engagement ferme des deux parties ; remboursable selon le sort du contrat.
- **Arrhes** : permettent à chacun de se dédire (l'acheteur perd les arrhes, le vendeur rembourse le double).
- Retirer « non remboursable » d'un acompte change sa nature → le **signaler** (impact sur la récupération en cas de résolution).

## TVA / autoliquidation
- Prestataire **hors UE** → preneur **français** assujetti : autoliquidation, montants **HT**, mention d'autoliquidation à prévoir.
- Si on **supprime** la clause TVA, le contrat devient muet (montants réputés HT) → le signaler.
- Prestataire **français** → TVA française applicable.
- Adapter selon les juridictions des deux parties ; en cas de doute, le signaler plutôt que trancher.

## Conditions suspensive / résolutoire
- **Suspensive** : l'obligation ne naît qu'à la réalisation de l'événement.
- **Résolutoire** : l'obligation existe mais s'éteint si l'événement survient.
- Bien choisir selon qu'on veut différer (suspensive) ou sécuriser-puis-défaire (résolutoire).

## Obligation de moyens vs de résultat
- Une prestation de conseil / intellectuelle relève en principe d'une **obligation de moyens** (sauf engagement explicite de résultat). Le stipuler protège le prestataire.

## Fermeté de l'engagement — verrous anti-contradiction
- Quand on ajoute des clauses de souplesse (préavis, substitution, back-up), **verrouiller** qu'elles n'interrompent ni ne suspendent la facturation et ne remettent pas en cause la fermeté de la durée / du financier (renvoi explicite aux articles concernés).
- Sinon un advisor pointera une contradiction entre la souplesse opérationnelle et la fermeté de l'engagement.

## Pourparlers (art. 1112 C. civ.)
- La rupture des pourparlers est libre, mais la faute (rupture brutale) engage la responsabilité. Utile pour cadrer une phase pré-contractuelle.
