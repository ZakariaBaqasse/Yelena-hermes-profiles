#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Patron type pour éditer un contrat vN -> vN+1 (skill edition-contrat).

Principes :
- On LIT vN.md et on ÉCRIT vN+1.md (jamais d'écrasement).
- Chaque remplacement ponctuel : assert exactement 1 occurrence.
- Pour un BLOC à frontières (chapeau, considérants) : repérer par index de
  deux ancres et remplacer la tranche (robuste aux apostrophes internes).
- Guard-fous : asserter ce qu'on CONSERVE et l'ABSENCE des anciennes chaînes.
- Toujours encoding='utf-8'. JAMAIS de perl -pe avec caractères larges sur
  un flux UTF-8 (double-encodage -> mojibake).

Adapter DELIV / SLUG / N et la liste REPL + les blocs par-ancres.
"""
from pathlib import Path

DELIV = Path("deliverables/<projet>")  # dossier du projet (relatif ou absolu)
SLUG = "<slug>"
N = 18  # version source ; on produit N+1

SRC = DELIV / f"{SLUG}_v{N}.md"
DST = DELIV / f"{SLUG}_v{N+1}.md"

md = SRC.read_text(encoding="utf-8")

# --- 1) Remplacements ponctuels (chaîne exacte -> chaîne exacte) ---
REPL = [
    # ("ancien wording exact", "nouveau wording"),
]
for i, (old, new) in enumerate(REPL, 1):
    c = md.count(old)
    assert c == 1, f"R{i}: attendu 1 occurrence, trouvé {c} pour: {old[:60]!r}"
    md = md.replace(old, new)

# --- 2) Remplacement d'un BLOC par ancres (frontières) ---
# start_anchor = "..."           # début inclus
# end_anchor   = "..."           # fin incluse
# assert md.count(start_anchor) == 1
# assert md.count(end_anchor) == 1
# s = md.index(start_anchor)
# e = md.index(end_anchor) + len(end_anchor)
# md = md[:s] + NOUVEAU_BLOC + md[e:]

# --- 3) Guard-fous (à adapter au contrat) ---
# assert "ce qu'on garde" in md, "chaîne à conserver perdue"
# assert "ancienne chaîne supprimée" not in md, "ancienne chaîne résiduelle"

DST.write_text(md, encoding="utf-8")
print(f"OK -> {DST}  ({len(md)} chars)")
