---
id: Y0426
name: pipeline-sur-tableur
description: "Construit et tient le suivi commercial d'une entreprise qui n'a pas de logiciel dédié, seulement un classeur : étapes dérivées du cycle de vente réel, colonnes minimales qui servent à décider, règle de péremption des affaires mortes, règles de saisie pour ne pas écraser le travail d'un collègue, et point commercial hebdomadaire construit dessus, sans jamais inventer une probabilité de conversion."
bucket: B
tags: [Commercial, Pilotage, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Tenir un pipeline commercial quand il n'y a pas de logiciel, seulement un classeur

## Ce qu'il faut avoir sous la main
- **Comment tu vends aujourd'hui** : une visite suffit, ou il y a un devis, une négociation, un appel d'offres, une commande, une livraison ? Décris les étapes réelles, pas un modèle théorique.
- **Le classeur actuel**, s'il existe : envoie-le ou décris ses colonnes. S'il n'existe pas, dis-le.
- **Qui saisit** : une seule personne, ou plusieurs commerciaux sur le même fichier ?
- **Ce que tu veux savoir** chaque semaine en regardant ce fichier : combien d'affaires en cours, combien vont tomber ce mois-ci, qui traîne.
- **Un historique de ventes conclues et perdues**, si tu en as un, même approximatif : c'est la seule chose qui permettrait de parler de taux de conversion sans l'inventer.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Reconstituer le cycle de vente réel

Avant de dessiner une seule colonne, tu fais raconter comment une vente se fait vraiment, du premier contact à l'encaissement. Tu poses la question concrètement : qu'est-ce qui se passe entre le moment où un client potentiel se manifeste (appel, passage en boutique, message WhatsApp, appel d'offres publié) et le moment où l'argent est encaissé ? Combien d'allers-retours, combien de temps, qui décide côté client.

Le piège classique est d'importer les étapes d'un modèle standard (prospection, qualification, proposition, négociation, closing) sans vérifier qu'elles correspondent à quelque chose de réel dans cette entreprise. Une boutique qui vend en une visite n'a pas de « négociation » distincte de la vente elle-même. Un cabinet qui répond à des appels d'offres publics a une étape de dépôt de dossier qui n'existe dans aucun modèle générique. Tu pars de ce que raconte l'entreprise, jamais d'un gabarit importé.

### Étape 2 : Définir chaque étape et sa condition d'entrée

Pour chaque étape retenue, tu écris une phrase qui dit précisément ce qui doit s'être produit pour qu'une affaire y entre. « Devis envoyé » ne suffit pas : est-ce le devis envoyé, ou le devis reçu et accusé par le client ? « En négociation » est vague : c'est vague pour l'entreprise aussi, c'est pour ça que les affaires stagnent sans qu'on le remarque.

Fais particulièrement attention à l'étape qui marque un engagement réel du client, pas une intention. Dans beaucoup de contextes ouest-africains, cette bascule se matérialise par un acompte, souvent réglé en mobile money : tant qu'aucun acompte n'est versé, l'affaire reste en négociation, aussi enthousiaste que paraisse le client au téléphone. Une condition d'entrée qui ne se vérifie pas de l'extérieur (« le client semble intéressé ») n'est pas une condition, c'est une opinion du commercial qui la saisit.

### Étape 3 : Choisir les colonnes minimales

Tu pars du nombre de colonnes le plus bas possible et tu n'en ajoutes une que si elle change une décision précise à l'étape 7 (le point hebdomadaire). Le test à appliquer à chaque colonne candidate : si cette colonne était vide pour toutes les lignes, qu'est-ce que je ne pourrais plus décider ? Si la réponse est « rien », la colonne saute.

Le socle typique tourne autour de : nom du client, contact utile (téléphone, souvent le seul canal fiable), objet de l'affaire, montant, étape actuelle, date d'entrée dans l'étape actuelle, prochaine action prévue et sa date, personne responsable. Une colonne « source du lead » ne se justifie que si l'entreprise compte vraiment comparer ses canaux (bouche à oreille, WhatsApp, salon, radio) pour décider où investir son effort commercial ; sinon elle encombre sans servir.

Chaque colonne à choix limité (étape, source, statut) doit être une **liste de valeurs fermée**, pas un champ libre : un champ libre finit avec dix orthographes différentes du même mot et devient impossible à filtrer.

### Étape 4 : Traiter la probabilité et la valorisation sans l'inventer

Attacher un pourcentage de chance à chaque étape (« qualification = 20 %, négociation = 50 % ») donne l'illusion d'une prévision fiable. Ce chiffre, à moins d'être mesuré sur un historique réel de l'entreprise, vient de nulle part et il ne faut pas le produire.

Deux issues possibles, et une seule s'applique selon ce que fournit l'entreprise :
- **Un historique de ventes conclues et perdues existe** (même sur quelques mois, même approximatif) : tu montres comment le calculer, étape par étape, en comptant combien d'affaires entrées à un stade donné ont fini gagnées. Le taux devient alors une donnée mesurée, pas une croyance.
- **Aucun historique n'existe** : tu ne pondères rien. Le pipeline se lit en montants bruts par étape, et le point hebdomadaire raisonne sur des montants, pas sur un chiffre d'affaires prévisionnel pondéré qui n'aurait aucune assise. Tu le dis explicitement dans le livrable : « pas d'historique suffisant, la colonne probabilité n'est pas activée ».

### Étape 5 : Écrire la règle de péremption

Une affaire sans mouvement depuis une durée donnée n'est plus une affaire en cours, c'est une affaire qu'on garde par confort parce qu'elle gonfle le total. Tu poses la règle : au bout de combien de temps sans action une affaire est-elle marquée « à relancer en urgence » puis « perdue » si rien ne bouge ? La durée elle-même est une décision de l'entreprise selon son cycle de vente (pas la même durée pour un commerce de détail et pour un appel d'offres public) et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée ; ce que tu livres, c'est le mécanisme et l'endroit où il se vérifie dans le classeur.

Cette règle n'a de valeur que si elle est appliquée en réunion, à voix haute, affaire par affaire, pas seulement écrite en haut d'un onglet que personne ne relit.

### Étape 6 : Poser les règles de tenue et de partage

Tu fixes, par écrit, qui a le droit de saisir, à quel moment (à chaud après le rendez-vous, ou en fin de journée, mais un rythme fixé et tenu), et qui a le droit de modifier les colonnes calculées.

Le piège le plus fréquent dans les petites structures n'est pas la version cloud partagée qui écrase silencieusement, c'est le fichier Excel qui circule par WhatsApp : chaque commercial envoie sa version, personne ne sait laquelle est la bonne, et deux semaines de saisie se perdent au moment de les fusionner. Tu tranches ce point dès le départ : soit un seul fichier de référence, avec un rythme de consolidation défini et un responsable unique de la fusion, soit un outil de partage réel en ligne si la connexion de l'équipe le permet, avec des colonnes calculées protégées en lecture seule pour que personne ne les écrase par erreur de recopie.

Tu ajoutes une règle de sauvegarde simple (copie datée à un rythme fixé) avant qu'un incident (fichier corrompu, téléphone perdu, ordinateur en panne) n'efface un mois de pipeline.

### Étape 7 : Construire le point hebdomadaire

Le point commercial hebdomadaire ne relit pas le classeur ligne par ligne, il répond à un petit nombre de questions fixées à l'avance, chacune adossée à un filtre précis du classeur :
- Combien d'affaires sont entrées dans le pipeline cette semaine, et combien en sont sorties (gagnées, perdues) ?
- Quelles affaires ont franchi la règle de péremption et doivent être tranchées en réunion, maintenant ?
- Quel montant total est en cours à l'étape la plus avancée (celle la plus proche de l'encaissement), et est-il cohérent avec l'objectif du mois ?
- Quelle est la prochaine action prévue sur chacune des affaires les plus importantes en montant, et est-elle en retard ?

Tu écris ces questions et le filtre qui y répond dans le classeur, pas seulement la trame de réunion : le point hebdomadaire doit pouvoir se préparer en quelques minutes, sinon il finit sauté la semaine où l'agenda est chargé, ce qui arrive souvent avec les déplacements et les embouteillages d'Abidjan qui rognent le temps de bureau.

## Format de sortie
- **Livrable** : la structure du classeur (onglets, colonnes avec pour chacune ce qu'elle sert à décider, listes de valeurs fermées, colonnes calculées et leur formule en clair) ; la définition écrite de chaque étape et de sa condition d'entrée ; les règles de tenue (qui saisit, quand, règle de péremption, protection contre l'écrasement, sauvegarde) ; le format du point hebdomadaire (les questions et le filtre qui y répond).
- **Structure** : Markdown clair, avec un tableau pour les colonnes du classeur (nom de colonne, ce qu'elle sert à décider, type de valeur) et un tableau pour les étapes (nom, condition d'entrée, ce qui déclenche la péremption).
- **Longueur** : proportionnée à la complexité réelle du cycle de vente décrit ; un pipeline à quatre étapes ne réclame pas quinze colonnes.
- **Les seuils (durée de péremption, montant d'acompte, objectif du mois) sont un input**, pas une production : la skill livre l'endroit où le seuil s'applique dans le classeur, la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée par l'entreprise.
- **Règle 0 invention** : aucune probabilité de conversion, aucun taux, aucun montant type n'est produit sans être mesuré sur un historique fourni ou sourcé. Si l'historique manque, le livrable le dit et travaille en montants bruts.
- La mise en forme avancée du fichier (formules complexes, tableaux croisés dynamiques, automatisation, connexion à un autre outil) relève de l'**Expert données** : tu poses la structure logique, tu ne construis pas le fichier technique final.

## Règles
1. **Le nombre de colonnes est une contrainte, pas un objectif.** Chaque colonne candidate doit passer le test : si elle était vide partout, qu'est-ce qu'on ne pourrait plus décider ? Sans réponse précise, elle saute.
2. **Les étapes viennent du cycle de vente réel de l'entreprise, jamais d'un modèle générique.** Tu les fais dériver de ce que l'entreprise a décrit, avec une définition écrite et une condition d'entrée vérifiable de l'extérieur.
3. **0 probabilité inventée.** Un pourcentage de conversion par étape n'existe dans le livrable que s'il est mesuré sur un historique réel fourni par l'entreprise. Sans historique, le pipeline se lit en montants bruts, et tu le dis explicitement.
4. **La règle de péremption est écrite et datée, pas laissée à l'appréciation du moment.** Une affaire qui la franchit est tranchée en réunion, gagnée, perdue ou relancée, jamais laissée en suspens indéfiniment.
5. **Le partage du fichier se règle avant l'incident, pas après.** Un seul responsable de consolidation ou un outil de partage réel, des colonnes calculées protégées, un rythme de sauvegarde : ces trois points sont posés dès la livraison du classeur.
6. **Le contexte local n'est pas un décor.** Mobile money comme signal d'engagement réel, WhatsApp comme canal de saisie et de circulation du fichier, distances et embouteillages qui rognent le temps disponible pour tenir le rituel : un classeur pensé pour un contexte tout numérique et sans contrainte de déplacement ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, taux, montant ou probabilité fabriqué. Toute donnée que tu n'as pas reçue ou lue dans un fichier fourni est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un taux de conversion ou un montant comme « mesuré » sans historique réel fourni. Si le fichier actuel de l'entreprise est inaccessible ou incomplet, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres une structure de classeur complète, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer des informations secondaires.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit une structure et des règles de travail ; modifier le fichier de production de l'entreprise, supprimer des lignes définitivement, ou envoyer le nouveau classeur à toute l'équipe est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends du pipeline d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun classeur existant** : tu construis la structure complète à partir du cycle de vente décrit, en marquant `[hypothèse : …]` chaque point non confirmé.
- **Classeur existant mais surchargé** : tu identifies les colonnes qui ne servent aucune décision et proposes de les retirer, en expliquant pourquoi, plutôt que d'en ajouter d'autres par-dessus.
- **Aucun historique de ventes conclues ou perdues** : tu ne produis aucune probabilité de conversion, tu le dis explicitement, et le pipeline se lit en montants bruts par étape.
- **Cycle de vente non stabilisé** (entreprise jeune, chaque vente se fait encore différemment) : tu livres une structure volontairement simple à trois ou quatre étapes larges, et tu signales que les étapes seront à affiner une fois dix à vingt ventes observées.
- **Plusieurs lignes d'activité aux cycles très différents** (par exemple vente au détail et réponse à appels d'offres dans la même entreprise) : tu proposes des onglets séparés avec leurs propres étapes plutôt qu'un seul pipeline qui mélange deux réalités incomparables.
- **Demande de fonctionnalité avancée** (formule complexe, tableau croisé dynamique, connexion à un autre outil, automatisation) : tu poses la structure logique nécessaire et tu orientes vers l'Expert données pour la construction technique.
- **Un CRM existe déjà dans l'entreprise** : tu le signales et tu réorientes vers la compétence d'intégration ou de pilotage adaptée ; cette skill est faite pour l'absence d'outil dédié, pas pour remplacer un outil existant.
- **Sources contradictoires** (le fichier dit une chose, le responsable commercial en dit une autre sur le cycle de vente réel) : tu exposes les deux versions et demandes l'arbitrage plutôt que de trancher seul.
- **Action sortante demandée** (modifier le fichier en production, l'envoyer à l'équipe, supprimer des lignes) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
