---
id: Y0666
name: vente-par-whatsapp
description: "Conduit une vente de bout en bout sur la messagerie où les clients écrivent vraiment : mise en forme d'un catalogue exploitable sur téléphone d'entrée de gamme, réponse à une demande de prix sans piège, transformation d'un échange en commande claire, confirmation écrite qui vaut preuve, relance graduée d'une conversation en suspens, tenue de l'historique quand plusieurs personnes répondent sur le même numéro. Ne confond jamais une capture d'écran avec un encaissement réel, et ne fabrique ni n'envoie aucun message sans validation humaine."
bucket: B
tags: [Commercial, Messagerie, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Vendre par messagerie, du premier message à la commande confirmée

## Ce qu'il faut avoir sous la main
- **Ce que tu vends** et comment ton catalogue existe aujourd'hui (photos éparses, liste papier, rien du tout).
- **Le numéro utilisé** : un numéro d'entreprise dédié, ou le téléphone personnel de quelqu'un.
- **Qui répond** aux messages : une seule personne, ou plusieurs à tour de rôle sur le même numéro.
- **Comment tes clients paient** : mobile money (Orange Money, MTN Money, Moov Money, Wave), virement, espèces à la livraison, un mélange.
- **Un exemple récent** d'échange qui s'est mal terminé ou qui t'a mis mal à l'aise, si tu en as un. C'est souvent le meilleur point de départ.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte fourni est partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process

### Étape 1 : Rendre le catalogue exploitable sur un téléphone d'entrée de gamme
Un catalogue qui rame ou qui noie le prix sous dix photos lourdes ne se vend pas, il se ferme. Avant de produire quoi que ce soit, tu identifies ce qui rend le catalogue actuel illisible sur un écran de quelques pouces et une connexion en 3G instable : trop d'images en haute résolution envoyées d'un coup, prix absent ou noyé dans un texte, aucun ordre logique, aucune version courte pour un client pressé ou à petit forfait data.

Tu produis : l'ordre des articles (les plus demandés d'abord, pas l'ordre de fabrication), le nombre et le poids d'images recommandé par envoi, une version texte allégée qui tient sans image pour un client à connexion faible, et le prix toujours visible à côté de chaque article, jamais dans un message séparé qu'on doit retrouver.

Le piège du débutant : envoyer le catalogue complet en une seule salve de photos. Le client referme la conversation avant d'avoir vu le prix. Tu segmentes l'envoi et tu mets le prix en évidence dès le premier message.

### Étape 2 : Répondre à une demande de prix sans le laisser nu
Un prix envoyé seul, sans rien autour, est lu par le client comme un engagement ferme et permanent. C'est le deuxième piège, et il coûte cher : le client revient trois semaines plus tard en réclamant le même prix, ou une quantité qui n'a jamais été discutée n'était pas incluse dans le calcul.

Tu attaches systématiquement au prix ce qui le conditionne : la durée de validité de l'offre, la quantité à laquelle il s'applique, si la livraison est incluse ou facturée à part, la disponibilité réelle du stock au moment de la réponse. Un message de prix correct répond à « combien » et ferme immédiatement les questions que le client n'a pas encore posées.

Tu proposes le message type de réponse à une demande de prix, avec ces quatre éléments visibles, jamais en petits caractères qu'on peut ignorer.

### Étape 3 : Transformer l'échange en commande claire
Une conversation WhatsApp avance par bribes : un message pour la quantité, un autre pour la couleur, un troisième trois heures plus tard pour l'adresse. Rien ne garantit que tout le monde relise l'historique avant de préparer la commande, et c'est là que la mémoire trahit.

Tu structures la conversation autour de cinq informations qui doivent toutes être obtenues avant confirmation : **quoi** (l'article précis, pas une catégorie), **combien** (quantité et prix total, pas seulement l'unitaire), **où** (adresse ou point de retrait), **quand** (date ou créneau de livraison attendu), **comment payé** (mode et moment du règlement). Tant qu'une de ces cinq informations manque, la commande n'est pas prête à être confirmée, elle est marquée « en cours ».

### Étape 4 : La confirmation qui vaut preuve
C'est le cœur de la démarche, et c'est ce qui manque dans la plupart des ventes par messagerie. Trois messages après l'accord verbal, plus personne ne sait si le client a commandé douze pièces ou vingt, ni à quel prix exact. Sans document, chaque désaccord se règle à qui parle le plus fort.

Tu produis un message de confirmation récapitulatif, toujours au même format, qui reprend les cinq éléments de l'étape 3 en une seule fois : articles, quantités, prix total, adresse, date de livraison, mode de paiement. Ce message part **avant** toute préparation de commande, jamais après. Il demande une validation explicite du client (« c'est bien ça ? » ou équivalent), pas un silence interprété comme un accord. Ce message devient la référence écrite en cas de litige : c'est pour ça qu'il doit être complet, daté, et non modifiable après coup sans un nouveau message qui acte le changement.

### Étape 5 : Le paiement, distinguer une capture d'écran d'un encaissement
Troisième piège, et le plus coûteux quand il tombe : une capture d'écran de transfert n'est pas une preuve de paiement. Elle peut être fausse, périmée, ou sincère mais adressée au mauvais destinataire, un client de bonne foi peut se tromper de numéro ou de compte. Traiter une capture comme un règlement, c'est libérer une marchandise contre rien.

Tu poses la règle simple : la marchandise part quand la réception est vérifiée sur le compte de l'entreprise (solde mobile money, relevé bancaire), pas quand une image arrive dans la conversation. Tu produis le message type qui demande cette vérification sans braquer le client de bonne foi : formuler ça comme une procédure systématique de l'entreprise, pas comme une suspicion personnelle, désamorce presque toujours la tension.

Pour les ventes en espèces à la livraison, tu le notes explicitement dans la fiche de commande, ce n'est pas la même vérification qui s'applique.

### Étape 6 : Relancer sans harceler, et clore proprement
Une relance se justifie par un fait nouveau, une échéance qui approche, une rupture de stock imminente, pas par le seul silence du client. Relancer par simple impatience use la relation et fait taire le client pour de bon.

Tu proposes une gradation à nombre de messages limité et fixé à l'avance, chacun avec un motif réel et différent du précédent (rappel de l'offre qui expire, information sur le stock, dernière relance avant clôture). Passé ce nombre, tu proposes un message de clôture propre : la conversation se referme sans pression, en laissant la porte ouverte pour plus tard. Une relance qui s'éternise sans fin prévue n'est pas un suivi commercial, c'est une gêne.

### Étape 7 : Tenir le canal quand plusieurs personnes répondent
Quand la vente passe par le téléphone personnel d'un commercial, deux problèmes surgissent en même temps : l'historique client appartient au commercial et part avec lui s'il quitte l'entreprise, et si un autre collègue répond depuis un autre appareil, les deux versions de la conversation ne se recoupent pas.

Tu poses la question du numéro d'entreprise dédié et de la reprise de l'historique, sans trancher à la place du dirigeant : c'est une décision d'organisation, pas une case technique. Ce que tu produis, en revanche, c'est la procédure minimale pour que plusieurs personnes puissent répondre sur le même canal sans se contredire : qui répond à quelle heure ou quel type de demande, où se note ce qui a déjà été dit à un client donné (prix accordé, promesse faite), et comment une commande engagée par une personne est reprise proprement par une autre si besoin.

## Format de sortie
- **Le catalogue exploitable sur téléphone** : ordre des articles, poids et nombre d'images par envoi, version texte allégée pour connexion lente.
- **Les messages types** : réponse à une demande de prix (avec ses quatre conditions attachées), confirmation de commande récapitulative, demande de vérification de paiement, relance graduée (chaque palier avec son motif), message de clôture.
- **La fiche de commande** extraite de la conversation : client, articles, quantités, prix appliqué, livraison (adresse, date), mode de règlement, statut du paiement, ce qui reste à confirmer.
- **La procédure de tenue du canal à plusieurs voix** : qui répond, comment se transmet l'historique, comment une commande change de main sans se perdre.
- **Structure** : Markdown clair, les messages prêts à copier-coller sont isolés dans des blocs distincts, la fiche de commande est un tableau.
- **Longueur** : proportionnée à la demande, sans remplissage. Un jeu complet de messages types tient sur une page.
- **Règle 0 invention** : aucun prix, aucune quantité, aucune date, aucun numéro n'est inventé. Ce que le client ou l'entreprise n'a pas donné reste `[à confirmer]`.

## Règles
1. **Aucune commande n'existe sans confirmation écrite récapitulative.** Tant que ce message n'est pas envoyé et validé par le client, la commande reste « en cours », jamais « confirmée ».
2. **Un prix ne part jamais seul.** Il porte toujours sa durée de validité, la quantité concernée, le traitement de la livraison, et l'état du stock au moment de l'envoi.
3. **Une capture d'écran n'est pas un encaissement.** La marchandise ne part que sur réception vérifiée sur le compte de l'entreprise. Tu le rappelles chaque fois qu'une capture est présentée comme preuve suffisante.
4. **Le numéro d'entreprise est une décision du dirigeant, pas une hypothèse de la skill.** Tu poses la question et ses conséquences, tu ne la tranches jamais à sa place.
5. **Une relance se justifie par un fait, pas par le silence.** Chaque palier de relance porte un motif différent, et la gradation a une fin prévue, matérialisée par un message de clôture.
6. **Observé et supposé ne se mélangent jamais dans la fiche de commande.** Ce que le client a dit explicitement et ce que tu déduis sont distingués visiblement.
7. **Le contexte local n'est pas un décor.** Mobile money comme mode de paiement ordinaire, connexion coûteuse et instable, téléphones d'entrée de gamme, informalité possible du côté client : un message ou un catalogue pensé pour une connexion fibre ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des messages et une fiche de travail ; envoyer un message à un client, publier un catalogue ou confirmer une commande est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ou d'un client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable.
- **Client qui présente une capture comme preuve suffisante** : tu maintiens la règle de vérification sur le compte et tu proposes le message qui la formule sans braquer le client.
- **Numéro personnel déjà en usage depuis longtemps** : tu poses la question de la reprise de l'historique et des risques associés, tu ne forces pas un changement immédiat qui n'est pas ta décision.
- **Plusieurs personnes répondent déjà avec des versions différentes du prix** : tu le signales comme un problème de fond à traiter en priorité, avant même de produire de nouveaux messages types.
- **Client silencieux après la confirmation** : tu appliques la gradation de relance prévue, tu ne multiplies pas les messages hors de ce cadre.
- **Commande modifiée après l'envoi de la confirmation** : tu produis un nouveau message de confirmation qui acte le changement, l'ancien ne disparaît pas, il est remplacé explicitement.
- **Connexion très lente ou téléphone bas de gamme signalé** : tu privilégies systématiquement la version texte allégée du catalogue et tu limites le nombre d'images par envoi.
- **Aucun catalogue existant** : tu proposes la structure à partir de la liste de produits fournie, en marquant clairement que les photos et la mise en page restent à produire.
- **Demande hors périmètre** (fixation de prix de vente, stratégie commerciale globale, publicité) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoyer un message, publier le catalogue, confirmer un paiement) : tu prépares le contenu et tu t'arrêtes pour validation humaine.
- **Sources ou versions contradictoires** de la conversation (deux personnes rapportent des échanges différents avec le même client) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
