---
id: Y0582
name: portrait-client-ideal
description: >
  Écrit le portrait du client idéal sous une forme qui se cherche : fonction, secteur, lieu,
  taille, et le déclencheur d'achat visible de l'extérieur. Part de qui a déjà acheté, pas
  d'un profil imaginé. Produit aussi la liste de ceux à qui ne pas vendre. À charger avant
  toute recherche de prospects, avant une séquence de prospection, ou quand un pipeline se
  remplit de contacts qui ne signent jamais.
bucket: B
tags: [Sales]
version: 1
maj: 2026-09-09
---

# Le portrait du client idéal

## Ce que produit cette compétence

Un portrait en six lignes, la liste de ceux à qui ne pas vendre, et une requête de recherche
prête à être consommée par l'étape de sourcing. Rien d'autre. Ce n'est pas une étude de
marché, et ce n'est pas une fiche de psychologie d'acheteur.

**Le test de la compétence tient en une phrase : si le portrait ne peut pas devenir une
requête, il n'a servi à rien.** Un portrait qui dit « des dirigeants sensibles à
l'innovation et soucieux de leur productivité » ne se cherche nulle part. Un portrait qui
dit « fondateur, société de services, Abidjan, annonce de recrutement ouverte depuis plus
de deux mois » se cherche le jour même.

## Ce que je demande, dans cet ordre

1. **Qui a déjà acheté.** Un nom, deux si possible, et ce qui se passait chez eux au moment
   où ils ont dit oui. C'est la seule matière solide de cette compétence.
2. **Ce qui a déclenché**, dans leurs mots. Pas la raison qu'on leur prête après coup.
3. **Ce que vend la maison**, si je ne le tiens pas déjà de l'étape précédente.
4. **À qui elle a vendu sans que ça se passe bien.** Cette question rapporte souvent plus
   que la première, et personne ne la pose.

Quand la maison n'a encore vendu à personne, je le dis et je pars des références qu'elle
publie, ou de ce que son offre rend possible. Un portrait bâti sans preuve porte la
mention, il ne se déguise pas en portrait bâti sur des clients.

## La méthode

### 1. Partir de la preuve, jamais du profil rêvé

La faute d'origine est de décrire le client qu'on aimerait avoir. Le portrait juste se lit
dans les deux ou trois affaires déjà gagnées : quelle fonction occupait la personne qui a
signé, dans quelle taille de structure, et qu'est-ce qui, cette semaine-là, rendait le
sujet urgent.

Si les seules références disponibles sont des témoignages publiés, ce sont des preuves, et
elles se citent comme telles avec leur source. Deux témoignages qui racontent la même
situation valent mieux qu'une intuition sur un marché entier.

### 2. Les quatre critères, et rien de plus

Un portrait se tient à quatre critères, parce que c'est le nombre qu'une recherche sait
filtrer et qu'un commercial sait vérifier en trente secondes :

| Critère | Ce qu'on écrit | Ce qu'on n'écrit pas |
|---|---|---|
| **Fonction** | Les intitulés réels, tels qu'ils figurent sur un profil | « Les décideurs » |
| **Secteur** | Les secteurs des clients déjà gagnés | « Tous les secteurs porteurs » |
| **Lieu** | La ville, puis le pays | « L'Afrique de l'Ouest » |
| **Taille** | Ce qui se vérifie : la présence ou l'absence d'une fonction interne | Une tranche d'effectif qu'on n'a pas |

**Le tri se fait à trois critères sur quatre.** Un profil qui en coche moins sort de la
liste, et cette règle s'écrit dans le portrait pour que la personne qui cherche puisse
l'appliquer sans moi.

⚠️ **La tranche d'effectif est un chiffre, et elle obéit à la règle des chiffres.** « Entre
10 et 50 salariés » a l'air d'un critère de bon sens ; s'il ne vient de nulle part, il
filtrera de vrais clients hors de la liste et personne ne saura pourquoi. Sans donnée, la
taille s'écrit par ce qui se constate : pas de service des ressources humaines, pas
d'informatique interne, le dirigeant encore dans les opérations.

### 3. Le déclencheur doit se voir de l'extérieur

C'est le point qui sépare un portrait utilisable d'un portrait décoratif. Un déclencheur
intérieur, « quand il en a assez de perdre du temps », ne se cherche pas. Un déclencheur
visible se cherche : une annonce de recrutement toujours ouverte, un financement annoncé,
une ouverture de site ou de pays, un appel d'offres publié, un départ annoncé.

Je garde le meilleur signal visible, et j'en nomme deux ou trois autres en réserve. Si
aucun déclencheur n'est visible de l'extérieur, je l'écris : la prospection se fera au
volume et non au signal, et ça change le rendement de l'étape suivante.

### 4. Le portrait négatif vaut la moitié du travail

À qui ne pas vendre se déduit des affaires perdues, des affaires gagnées qui se sont mal
passées, et de la structure même de l'offre. Trois lignes suffisent, chacune avec sa
raison, parce qu'une interdiction sans motif ne se respecte pas.

Cette liste protège plus de temps commercial que le portrait positif n'en fait gagner : une
affaire mal engagée occupe un trimestre et finit par un non.

### 5. Deux marchés très différents ne font pas un portrait

Quand la maison vend à la fois à des entreprises et à des administrations, ou à des petites
structures et à des grands groupes, ce sont deux métiers de vente : cycle différent,
interlocuteur différent, pièces différentes. Je le dis, j'écris les deux portraits
séparément, et je rappelle qu'une recherche ne peut viser qu'un des deux à la fois.
Mélanger les deux produit une liste dont la moitié est intraitable.

## Mode borne : un portrait à partir d'une phrase

Sur un salon, le visiteur n'a ni fichier client, ni historique. Une seule question donne la
matière, et elle porte sur une personne précise :

**« Votre dernier client, c'était qui exactement, et qu'est-ce qui se passait chez lui à ce
moment-là ? »**

Il répond toujours, parce qu'il pense à quelqu'un. La première moitié donne la fonction et
le secteur, la seconde donne le déclencheur.

Ce qui tient avec cela seul :

- **Le lieu**, il se déduit de là où le visiteur travaille, sans le lui demander.
- **La taille** reste `[à confirmer]` neuf fois sur dix, et le portrait se livre quand même.
  C'est le critère le plus souvent absent et le moins bloquant, parce que le tri à trois sur
  quatre s'en passe.
- **Le portrait négatif** se produit sans lui : il se déduit de ce que l'offre ne sait pas
  servir, et le visiteur le corrige d'un mot en le lisant.

Ce que je ne fais pas en mode borne : inventer une tranche d'effectif pour que la requête
ait l'air complète. Une requête à quatre lignes dont une porte `[à confirmer]` fonctionne ;
une requête dont un filtre est faux ne rend que des profils hors cible, et personne ne s'en
apercevra avant d'avoir écrit à quinze personnes.

## Un exemple complet, de bout en bout

⚠️ Visiteur fictif, écrit pour calibrer le format. Aucun élément de cet exemple ne se
réemploie chez un client réel.

**Ce qu'il dit :** « Je vends des logiciels de gestion aux pharmacies. Mon dernier client,
c'est une pharmacienne à Yopougon, elle venait d'ouvrir une deuxième officine et elle ne
savait plus ce qu'elle avait en stock où. »

**Le portrait, écrit à partir de cette seule phrase :**

| Critère | Ce qu'on cherche |
|---|---|
| Fonction | Pharmacien titulaire, gérant d'officine |
| Secteur | Officine de pharmacie |
| Lieu | Abidjan, communes d'abord |
| Taille | Deux points de vente ou plus, pas de gestionnaire de stock dédié |
| Déclencheur | L'ouverture d'un second point de vente, visible : enseigne, annonce, registre |
| Où le trouver | Les groupements d'officines, les grossistes répartiteurs, le terrain |

**Le portrait négatif :**

- **L'officine unique tenue par son propriétaire seul.** Le stock tient dans sa tête, le
  logiciel lui coûte plus qu'il ne lui rapporte, et il le dira au bout de trois mois.
- **La chaîne qui a déjà un système central.** La décision remonte, elle ne se prend pas au
  comptoir, et le cycle n'a rien à voir.

**La requête :**

```
Fonction   : pharmacien titulaire, gérant d'officine
Secteur    : officine de pharmacie
Lieu       : Abidjan
Signal     : ouverture d'un second point de vente
Taille     : deux officines ou plus  [à confirmer]
Tri        : 3 critères sur 4
```

**Ce que cet exemple ne contient pas, volontairement :** aucun nombre d'officines sur le
marché, aucune part de marché, aucune tranche de chiffre d'affaires. Le visiteur n'en a
donné aucun, et un ordre de grandeur cité de mémoire ne devient pas juste parce qu'il sert
à cadrer.

## Comment on rate cette compétence

Cinq façons, toutes observées :

- **Décrire le client rêvé** au lieu de lire les clients gagnés. Le portrait est flatteur,
  il ne correspond à personne, et la recherche qui en découle rend des inconnus.
- **Écrire un déclencheur intérieur.** « Quand il prend conscience que… » ne se cherche pas.
  Le déclencheur se voit de l'extérieur ou il ne sert à rien.
- **Poser une tranche d'effectif inventée** pour que la requête paraisse complète. C'est le
  filtre qui écarte silencieusement de vrais clients.
- **Fondre deux marchés en un.** Le portrait moyen d'un ministère et d'une startup ne
  décrit ni l'un ni l'autre.
- **Livrer le portrait sans la requête.** Le portrait est alors une jolie page, et l'étape
  de sourcing repart de zéro en devinant ce qu'il fallait chercher.

## Ancrage local

Voir `memory/reference/vendre-en-cote-d-ivoire.md` avant d'écrire le canal : la fonction se
trouve sur LinkedIn, mais la réponse arrive sur WhatsApp, et beaucoup de dirigeants de
petite structure n'ont aucune présence en ligne exploitable. Quand c'est le cas, je le dis
et je nomme les portes d'entrée réelles, groupements professionnels, incubateurs, chambres
consulaires, plutôt que de faire semblant qu'une recherche suffira.

## La paire réelle : un à aller voir, un à laisser

Ajouté le 09/09/2026. Le portrait théorique se lit poliment et ne change rien. Ce qui
change une conversation, c'est **deux personnes qui existent**, sorties de la même
recherche, dont l'une est à aller voir et l'autre pas.

Ce que la paire produit, et que le portrait seul ne produit jamais : la preuve que le
filtre automatique ne suffit pas. Les deux ont le même intitulé et la même ville, un
fichier trié les met côte à côte, et rien à l'écran ne les sépare. Ce qui les sépare se
lit sur le site de l'entreprise et se demande au téléphone.

Chaque fiche porte le nom, le poste, l'entreprise et la ville tels que la recherche les a
rendus, puis les quatre critères cochés un par un, chacun avec son état : établi, `✗`, ou
`⟦à vérifier⟧`.

Quatre règles :

1. **Les deux sortent de la même recherche.** Un anti-persona pris ailleurs ne démontre
   rien, parce qu'il ne serait jamais entré dans la liste.
2. **Le secteur se vérifie sur le site de la maison, ouvert.** Il ne se déduit pas du nom
   de l'entreprise. Site injoignable, le critère porte `⟦hypothèse à vérifier⟧`.
3. **Le refus porte sur la maison, jamais sur la personne**, et la fiche le dit en toutes
   lettres. Une page qui circule ne doit pas pouvoir se lire comme un jugement sur
   quelqu'un.
4. **Personne n'est contacté.** La paire sert à montrer le tri, pas à ouvrir une
   prospection.

## Format de sortie

Un tableau à six lignes (les quatre critères, le déclencheur, le canal), suivi du portrait
négatif en trois puces motivées, puis de la requête en bloc de texte brut, recopiable telle
quelle par l'étape de sourcing. Puis, si le client le souhaite, une page partageable.

## Garde-fous

- **0 invention.** Aucun effectif, aucune part de marché, aucun volume avancé sans source.
  Ce qui manque s'écrit `[à confirmer]`, et le portrait se livre quand même.
- **0 chiffre de marché sans sa source et sa date**, dans le tableau lui-même. Un tableau
  est ce qui rend un chiffre inventé crédible ; la règle y est donc plus stricte qu'ailleurs.
- **Aucune donnée d'une autre maison.** Un portrait bâti sur ce qui marche chez un autre
  client est une fuite, même quand aucun nom n'apparaît.
- **Aucune action sortante.** Le portrait sert à chercher, jamais à écrire à quelqu'un.
- **Produis, ne bloque pas.** Sans historique client, je livre le portrait fondé sur les
  références publiées, je marque la preuve manquante, et je dis ce qu'il faut pour la
  combler.

## Cas limites

- **La maison n'a encore aucun client.** Je le dis en une ligne, je bâtis sur ce que l'offre
  rend possible, et je marque le portrait comme une hypothèse à corriger à la première
  affaire gagnée.
- **Les clients gagnés n'ont rien en commun.** C'est un résultat, pas un échec : je l'écris,
  et la question devient laquelle de ces familles la maison veut servir en priorité.
- **Le déclencheur n'est visible nulle part.** Je le signale, et je préviens que l'étape de
  sourcing travaillera au volume, avec le rendement que cela implique.
- **Demande hors périmètre** : je le dis en une phrase, je traite ce qui relève de mon
  champ, et j'oriente vers la compétence qui convient.
