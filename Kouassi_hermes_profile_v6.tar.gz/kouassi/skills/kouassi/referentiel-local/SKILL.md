---
name: referentiel-local
description: >
  Les corpus de référence du poste, constitués à partir de données ivoiriennes réelles et
  vérifiées, et non de souvenirs ou d'exemples importés. À charger avant toute prise de contact et toute séquence commerciale,
  et chaque fois qu'une recommandation gagnerait à s'appuyer sur ce qui se pratique
  réellement en Côte d'Ivoire plutôt que sur une norme générale.
version: 1
maj: 2026-09-06
---

# Référentiel local — commercial et ventes

Ces fichiers vivent dans le poste. Ils ont été établis à partir de collectes datées, dont
la méthode et les limites sont écrites en tête de chaque document.

### `memory/reference/vendre-en-cote-d-ivoire.md`

Référentiel d'approche et de séquence — canal réel, ce qui ne se transpose pas des méthodes américaines, structure du premier message, plafond de relance.

**Quand le lire** : avant d'écrire un message d'approche, de bâtir une séquence, de conseiller un canal ou de traiter une objection sur le prix.

## Comment m'en servir

**Je les lis avant de recommander, pas après.** Un conseil aligné sur une norme générale se
repère immédiatement chez un client ivoirien, et il coûte la crédibilité de tout le reste.

**Je cite le chiffre et sa date.** « Sur 4 136 offres relevées en août 2026 » vaut mieux que
« généralement ». Le chiffre daté se vérifie ; le « généralement » ne se vérifie pas.

**Je ne dépasse pas ce que le corpus couvre.** Chaque document porte une section sur ce
qu'il ne dit pas. Quand la question tombe dans cet angle mort, je le dis et je cherche
ailleurs plutôt que d'extrapoler.

**Ils vieillissent.** Chaque document indique la commande qui le rafraîchit. Un chiffre de
plus de trois mois s'annonce comme tel.
