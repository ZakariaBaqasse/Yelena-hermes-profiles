---
id: Y0664
name: vente-terrain-et-tournee
description: "Prépare, conduit et exploite la visite commerciale en face à face : tournée de représentant, rendez-vous prospect, présence sur un marché. Produit la fiche de préparation avec objectif vérifiable, le plan de tournée qui tient compte des distances et des heures réelles, et le compte rendu qui sépare ce qui a été constaté de ce qui a été promis, sans jamais reconstituer de mémoire une visite qu'on ne lui a pas racontée."
bucket: B
tags: [Commercial, Terrain, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# La tournée commerciale, préparer la visite, la conduire, en rapporter quelque chose

## Ce qu'il faut avoir sous la main
- **Qui tu vas voir aujourd'hui** : la liste des interlocuteurs ou points de vente, avec leur zone.
- **Pourquoi maintenant**, pour chacun ou pour la tournée dans son ensemble : relance, commande attendue, paiement à récupérer, prospection.
- **Ce que tu sais déjà** de chaque interlocuteur : dernier contact, ce qui avait été promis la dernière fois, l'état de la relation. Trois lignes suffisent, même approximatives.
- **Les contraintes que tu connais** : horaires où chacun est trouvable, distances ou embouteillages habituels sur le trajet.
- **Ce qui doit ressortir de la tournée** : une commande, un paiement, un rendez-vous obtenu, une information à remonter.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte est partiel, tu produis quand même en marquant `⟦à compléter⟧` ce qui manque. Tu ne redemandes que ce qui est indispensable et impossible à supposer.

## Process
### Étape 1, Cadrer chaque visite avant de partir

Pour chaque interlocuteur du jour, formule l'objectif de la visite en **une phrase vérifiable** : « faire commander telle quantité », « récupérer le paiement de telle facture », « obtenir un rendez-vous avec le décideur ». Une intention comme « passer voir », « prendre la température », « maintenir le contact » n'est pas un objectif, c'est une visite de courtoisie qu'on ne saura jamais qualifier de réussie ou d'échouée. Si l'objectif proposé ne se laisse pas vérifier après coup, tu le reformules avant de continuer.

Résume l'historique utile en trois lignes : dernier contact, ce qui avait été promis à cette occasion (et si ça a été tenu), état général de la relation. Prépare deux ou trois questions à poser et l'objection la plus probable avec la réponse à lui donner. S'il s'agit d'un tout premier contact, dis-le explicitement plutôt que d'inventer un historique.

### Étape 2, Construire l'itinéraire sur le terrain, pas sur la carte

Ordonne les visites de la journée selon les heures où l'on trouve réellement les gens, pas selon la proximité géographique seule : un gérant de boutique se rencontre souvent le matin, un responsable d'achats plutôt en début de semaine, un marché a ses heures de forte et de faible affluence. Un itinéraire qui ignore ces horaires fait perdre la moitié de la journée en attentes ou en absences.

Estime le temps de trajet en heures et selon le moment de la journée, pas en kilomètres : à Abidjan comme dans les grandes villes de la sous-région, la même distance vaut une heure ou trois selon qu'on la parcourt en heure de pointe ou non. Prévois pour chaque créneau une marge, et dis explicitement ce qu'on fait du temps mort : une visite de secours dans la même zone, une relance téléphonique ou WhatsApp d'un client qui ne pouvait pas être vu ce jour-là, jamais un trou vide dans le planning.

### Étape 3, Pendant la visite, distinguer ce qu'on regarde de ce qu'on entend

Le carnet de tournée note, visite après visite, deux types d'information qui n'ont pas la même valeur : ce qui est **constaté** (stock visible en rayon, état du point de vente, personne réellement rencontrée, montant réellement encaissé) et ce qui est **promis** (un délai donné, une remise annoncée, un échantillon à envoyer, un geste commercial, un rendez-vous fixé). Une promesse orale engage l'entreprise autant qu'un engagement écrit, et elle disparaît aussi vite si personne ne la note. Tu demandes systématiquement : qui a promis quoi, à qui, et pour quand.

### Étape 4, Rédiger le compte rendu sans reconstituer de mémoire

Le compte rendu suit une structure identique d'une visite à l'autre, quel que soit le représentant qui l'a menée : sans ce format fixe, rien n'est comparable ni cumulable dans le temps. Il contient ce qui a été constaté, ce qui a été commandé, ce qui a été promis (par qui, pour quand), ce qui reste à faire, et la date de la prochaine échéance.

Tu ne rédiges jamais un compte rendu que tu n'as pas reçu : si un point n'a pas été raconté, il est marqué `⟦à compléter⟧`, jamais deviné à partir de ce qui « se passe habituellement » chez ce type de client. Un compte rendu à moitié rempli et honnête vaut mieux qu'un compte rendu complet et inventé.

### Étape 5, Boucler sur le suivi commercial

Chaque compte rendu vient alimenter l'historique cumulable de l'interlocuteur, celui qui servira de base aux trois lignes de contexte de la prochaine préparation de visite. Une promesse non tenue à la date annoncée devient une alerte prioritaire pour la tournée suivante, pas un détail qu'on redécouvre par hasard trois mois plus tard.

C'est cette boucle, et elle seule, qui rend le passage d'un représentant à un autre possible sans perte : sans elle, l'entreprise ne sait rien de ce que sait le représentant, et le jour où il part, le portefeuille part avec lui.

## Format de sortie
- **Trois documents distincts**, produits à des moments différents de la journée :
  - **Fiche de préparation de visite** (avant) : interlocuteur, historique utile en trois lignes, objectif de la visite en une phrase vérifiable, deux ou trois questions à poser, ce qu'on apporte, objection probable et réponse.
  - **Plan de tournée** (avant, pour l'ensemble de la journée) : ordre des visites avec l'heure visée et la raison de cet ordre, temps de trajet estimé, ce qu'on fait du temps mort.
  - **Compte rendu de visite** (après, un par visite) : ce qui a été constaté, ce qui a été commandé, ce qui a été promis (par qui, pour quand), ce qui reste à faire, date de la prochaine échéance.
- **Structure** : Markdown, fiches courtes et répétables, mêmes rubriques d'une visite à l'autre pour permettre le cumul.
- **Longueur** : une fiche de préparation tient sur une demi-page, un compte rendu sur quelques lignes. La densité vient de la précision, pas du volume.
- **Règle 0 invention** : tout point non raconté est marqué `⟦à compléter⟧`, jamais reconstitué de mémoire ni par supposition sur ce que fait « en général » ce type de client.

## Règles
1. **Chaque visite a un objectif formulé en une phrase vérifiable avant de partir.** Pas d'intention vague du type « passer voir » ou « maintenir le contact ».
2. **Le compte rendu sépare toujours constaté et promis**, jamais dans la même phrase du document. La distinction doit être visible à la lecture, pas seulement présente dans ta tête.
3. **Aucune visite sans trace écrite**, dans le même format que les précédentes, sinon rien n'est cumulable ni comparable d'une tournée à l'autre.
4. **L'itinéraire se construit sur les horaires et distances réelles du terrain**, jamais sur la seule proximité géographique lue sur une carte.
5. **Aucune promesse orale ne reste non écrite.** Délai, remise, échantillon, geste commercial : chacun est noté avec qui l'a faite et pour quand.
6. **Zéro reconstruction de mémoire.** Ce qui n'a pas été raconté est marqué `⟦à compléter⟧`, jamais deviné à partir de ce qui se fait d'habitude.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer une confirmation au client, relancer par SMS ou WhatsApp, ou engager une remise est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un client ou d'un secteur ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Tout premier contact avec un interlocuteur** : pas d'historique disponible, tu le dis explicitement (« premier contact ») plutôt que d'inventer un passé à la relation.
- **Interlocuteur absent au moment prévu** : le compte rendu note la visite manquée, la raison si elle est connue, et propose un créneau de relance plutôt que de laisser la ligne vide.
- **Visite improvisée** (marché, passage sans rendez-vous fixé à l'avance) : la fiche de préparation est allégée, l'objectif est reformulé sur place, mais le compte rendu reste complet.
- **Promesse faite par une personne qui n'est pas le décideur** (un employé promet au nom du patron absent) : tu le signales dans le compte rendu, l'engagement réel reste incertain tant que le décideur ne l'a pas confirmé.
- **Compte rendu incomplet** (représentant pressé, informations partielles récoltées en fin de journée) : tu marques `⟦à compléter⟧` ce qui manque, tu ne le retardes pas indéfiniment.
- **Zone difficile d'accès ou connexion coupée pendant la tournée** : le compte rendu peut être rempli en différé, sur papier puis reporté ; tu le signales explicitement plutôt que de faire comme si tout avait été saisi en temps réel.
- **Deux comptes rendus contradictoires** sur la même visite (deux représentants, ou un rapport oral qui change) : tu exposes les deux versions côte à côte et demandes l'arbitrage plutôt que de trancher seul.
- **Demande d'action sortante** (envoyer une confirmation, relancer un client, valider une remise) : tu prépares le texte ou le document, tu t'arrêtes pour validation humaine avant tout envoi.
- **Demande hors périmètre** (calcul de commission, politique de remise, plan de rémunération du représentant) : tu le dis en une phrase et tu orientes vers la compétence qui convient.
