---
id: Y0480
name: client-ideal-et-ciblage
description: "Écrit le profil du client idéal champ par champ, à partir des clients réels et des affaires perdues (jamais d'un souhait), en tire la liste des organisations et des personnes à approcher avec preuve de vérification pour chaque ligne, et fixe le test de qualification en trois questions et la date de révision du profil, sans jamais inventer un nom, une taille ou une coordonnée de contact."
bucket: B
tags: [Commercial, Prospection, Nouveau]
version: 1
maj: 2026-09-09
---

# Le client idéal, écrit noir sur blanc, puis la liste qui en découle

## Ce qu'il faut avoir sous la main
- **Ce que tu vends** : le produit ou service, en une phrase simple.
- **Tes cinq clients qui rapportent le plus** : nom, secteur, taille approximative si tu la connais.
- **Tes trois clients qui reviennent le plus souvent** : les mêmes qui recommandent ou rachètent.
- **Trois affaires perdues récentes**, avec la raison si tu la connais (prix, mauvais timing, pas le bon interlocuteur, produit pas adapté).
- **Un profil déjà écrit**, s'il en existe un, même informel (une note, une slide, une conversation d'équipe).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à vérifier⟧` ce qui manque. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Partir des clients réels, jamais du souhait

Prends les cinq clients qui rapportent le plus et les trois qui reviennent le plus souvent : c'est la matière première, pas les affaires qu'on espère signer un jour. Regarde ce qu'ils ont en commun réellement (secteur, taille, fonction de l'interlocuteur), pas ce qu'on voudrait qu'ils aient en commun.

Ajoute tout de suite les affaires perdues : elles disent mieux où le profil s'arrête, parce qu'une affaire gagnée peut être un coup de chance isolé, alors qu'une affaire perdue dans le profil signale un champ mal calibré. Si une affaire est perdue à cause du prix chez un client qui coche toutes les cases du profil, c'est le champ taille ou budget qui est mal réglé, pas un accident.

Le piège ici : écrire le client qu'on voudrait plutôt que celui qu'on sert. Une entreprise qui n'a jamais vendu à un grand groupe ne met pas les grands groupes dans son profil parce que ça fait bien sur une slide.

### Étape 2 : Remplir les huit champs, chacun avec sa preuve

Pour chaque champ, indique sur quel client réel ou quelle affaire il s'appuie. Un champ sans client à citer est une supposition, marquée comme telle.

- **Secteur d'activité** : celui des clients qui achètent, pas celui qu'on cible en théorie.
- **Taille** (effectif ou chiffre d'affaires, en fourchette `⟦à renseigner⟧`) : la fourchette réelle des clients qui ont payé, pas une ambition de montée en gamme.
- **Zone géographique** : là où sont les clients qui achètent aujourd'hui, en tenant compte des distances et du temps de déplacement réel si le contact se fait en présentiel (une zone qui inclut Abidjan et l'intérieur du pays n'a pas le même coût d'acquisition).
- **Fonction de qui décide** et **fonction de qui utilise** : nommées séparément, jamais fusionnées.
- **Le problème, dans les mots du client** : reformulé tel que le client l'a dit en entretien ou en réunion de vente, pas dans le vocabulaire du produit.
- **Le déclencheur** : ce qui fait qu'ils cherchent une solution maintenant plutôt qu'il y a six mois ou dans six mois.
- **Ce qu'ils utilisent en attendant** : un cahier, un tableur, un prestataire informel, un cousin qui s'en occupe, un concurrent. Ce point de comparaison existe toujours, même quand il n'a pas de nom commercial.

Un profil trop large ("les PME d'Afrique de l'Ouest") ne permet de choisir ni où chercher, ni quoi dire, ni qui contacter en premier : c'est un signal qu'il faut resserrer au moins deux champs. Un profil trop étroit qui ne rend qu'une poignée de noms réels décrit un client, pas un segment : c'est un signal qu'il faut en élargir un.

### Étape 3 : Écrire les critères d'exclusion

C'est la moitié la plus utile de la fiche, celle qu'on saute le plus souvent. Pour chaque critère d'exclusion, écris la raison : un type d'organisation qui a toujours pris trois fois plus de temps à convaincre pour un contrat plus petit, un secteur où le déclencheur n'existe jamais, une taille en dessous de laquelle le prix n'est pas soutenable pour le client.

Une exclusion qui arrête une piste avant le premier rendez-vous vaut plus qu'un critère d'inclusion qui ne se voit qu'après le troisième devis.

### Étape 4 : Distinguer qui décide et qui utilise

Ce sont rarement les mêmes personnes, elles n'ont pas le même problème, et un message pensé pour l'une laisse l'autre indifférente. Nomme les deux fonctions précisément (pas "la direction" mais l'intitulé exact du poste qui signe), et dis explicitement qui a le pouvoir de dire oui.

Si le profil ne sait pas répondre à "qui signe", la liste de ciblage qui suivra visera la mauvaise personne, et l'échec sera invisible jusqu'au moment où l'affaire meurt en interne chez le client, sans qu'on comprenne pourquoi.

### Étape 5 : Construire la liste de ciblage

Pour chaque organisation retenue, la ligne contient : le nom de l'organisation, la fonction visée (avec le nom de la personne si on l'a), la source qui a permis de l'identifier, le canal d'approche prévu, et pour chaque champ du profil, la mention **vérifié** (avec sur quelle preuve) ou `⟦à vérifier⟧`.

Un nom sans moyen de contact vérifiable et sans preuve du critère est une ligne qui ne sert à rien : aucune adresse, aucun numéro, aucune fonction ne se reconstitue par déduction. Si la source est un annuaire professionnel, une chambre de commerce, un registre du commerce et du crédit mobilier (RCCM) ou une liste de participants à un salon, c'est écrit en clair ; si c'est une supposition à partir du nom de l'organisation, c'est marqué comme telle et ça reste `⟦à vérifier⟧`.

Le canal d'approche tient compte de la réalité du contact : beaucoup d'organisations, notamment les plus petites, n'ont pas de présence en ligne exploitable, et le premier contact utile passe par un appel, une visite ou un message WhatsApp Business plutôt que par un formulaire de site. Ça se dit ligne par ligne, pas en supposant que tout le monde est joignable de la même façon.

### Étape 6 : Le test de qualification en trois questions

Trois questions posées au tout premier échange, qui permettent de savoir en deux minutes si la piste entre dans le profil ou si elle sort dans une exclusion. Elles portent sur les champs les plus discriminants du profil (souvent : la taille, le déclencheur, ce qu'ils utilisent en attendant), pas sur les huit champs à la fois.

Une piste qui échoue à une seule de ces trois questions sort de la liste immédiatement : c'est le test qui fait gagner le temps qu'un profil bien écrit promet.

### Étape 7 : Fixer la date de révision

Le profil se relit dans deux cas précis : une affaire gagnée en dehors du profil (le profil est peut-être trop étroit, ou une nouvelle catégorie de client s'est ouverte), ou trois affaires perdues à l'intérieur du profil (un des huit champs est mal calibré). Les deux cas disent que le profil a bougé, pas que la vente a raté.

Fixe une date de révision par défaut même en l'absence de ces signaux, pour éviter qu'un profil juste au départ devienne obsolète sans que personne ne s'en aperçoive.

## Format de sortie
- **Livrable** : la fiche du client idéal (huit champs, chacun avec sa preuve), la liste des critères d'exclusion avec leur raison, la liste de ciblage (organisation, fonction visée, source, canal d'approche, statut vérifié/`⟦à vérifier⟧` par champ), le test de qualification en trois questions, et la date de révision avec ce qui la déclencherait plus tôt.
- **Structure** : Markdown, tableaux pour la fiche et pour la liste de ciblage, answer-first (la fiche d'abord, la liste ensuite, le test en dernier).
- **Longueur** : proportionnée au nombre de clients et d'affaires fournis ; la liste de ciblage vise plusieurs dizaines de lignes réelles, pas une poignée.
- **Les fourchettes de taille, les seuils et les critères chiffrés sont des inputs** de l'entreprise, jamais une production de la skill : ils restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés ou déduits d'un client réel cité.
- **Règle 0 invention** : aucun nom d'organisation, aucune coordonnée, aucun chiffre de taille ou de chiffre d'affaires inventé. Une ligne sans source vérifiable est marquée `⟦à vérifier⟧`, jamais présentée comme acquise.

## Règles
1. **Le profil se construit sur les factures, pas sur l'ambition.** Chaque champ cite un client réel ou une affaire (gagnée ou perdue). Un champ sans preuve citée est une hypothèse, étiquetée comme telle.
2. **Un profil utile exclut plus qu'il n'inclut.** Si la fiche ne contient aucun critère d'exclusion, elle est incomplète, quelle que soit la qualité des huit champs.
3. **La liste de ciblage se mesure en dizaines de lignes réelles.** Une liste de cinq noms signale que le profil décrit un client précis, pas un segment ; il faut resserrer un champ pour en retirer un autre.
4. **Décideur et utilisateur ne se fusionnent jamais** dans le même champ. Les deux fonctions sont nommées séparément, et la fiche dit qui signe.
5. **Ce qu'ils font aujourd'hui sans l'entreprise est toujours renseigné.** Un cahier, un tableur, un concurrent, un prestataire informel : ce point de comparaison décide du prix et de l'argumentaire, il ne se laisse jamais vide.
6. **Aucune ligne de ciblage sans preuve de contact vérifiable.** Un nom sans moyen de contact et sans preuve du critère ne rejoint pas la liste ; il reste dans une liste de pistes à vérifier.
7. **Le profil se revoit à deux signaux précis** : une affaire gagnée hors profil, ou trois affaires perdues dedans. Les deux cas sont des raisons de réviser, pas des anomalies à ignorer.
8. **Le contexte local n'est pas un décor.** Beaucoup d'organisations ciblées peuvent être informelles ou sans présence en ligne ; le canal d'approche et la preuve de vérification en tiennent compte ligne par ligne.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter une organisation identifiée, publier une liste ou engager un prestataire de sourcing est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** (pas d'affaires perdues fournies, seulement des clients gagnés) : tu produis la fiche avec ce que tu as, tu marques l'absence d'affaires perdues comme un trou du raisonnement (le profil risque d'être trop large faute de savoir où il s'arrête), et tu ne le comptes pas comme validé sur ce point.
- **Aucun profil préexistant, un seul client cité** : tu produis la fiche en marquant chaque champ `[hypothèse : …]` fondé sur ce client unique, et tu dis explicitement que le profil doit être confronté à d'autres clients avant d'être utilisé pour du ciblage massif.
- **Liste de ciblage impossible à sourcer** (aucun annuaire ni registre accessible) : tu livres la structure de la liste avec les lignes marquées `⟦à vérifier⟧` sur la source, et tu dis clairement qu'aucune ligne n'est prête à être contactée en l'état.
- **Le client cite un grand groupe ou une administration comme client idéal sans avoir jamais vendu à ce type d'organisation** : tu le signales comme un écart entre profil souhaité et profil réel, et tu proposes de le traiter comme un segment d'expérimentation séparé, pas comme le cœur du profil.
- **Décideur et utilisateur inconnus** (l'entreprise ne sait pas qui signe chez ses clients) : tu marques les deux fonctions `⟦à vérifier⟧` et tu proposes que ce soit la première chose à confirmer avant d'utiliser la liste.
- **Source ou connecteur inaccessible** (CRM non branché, export de clients absent) : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné en message.
- **Demande hors périmètre** (script d'approche commerciale, argumentaire de vente détaillé) : tu le dis en une phrase, tu produis ce qui relève du profil et du ciblage, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (envoi de message, prise de contact, achat d'une liste de prospection) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le CRM et le récit du commercial ne s'accordent pas sur qui a signé une affaire) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
