---
id: Y0018
name: 02-nps-analyzer
description: "Analyse les réponses NPS d'une startup (score, verbatims, segment) sur une fenêtre donnée : calcule le score NPS et son delta, cluster les verbatims par thème, identifie les promoteurs à fort potentiel case study et les détracteurs à risque de churn avec plan de recovery, et en tire 3 priorités produit classées par impact NPS attendu, sans jamais inventer un score, un thème ou un verbatim absent de la source."
bucket: C
tags: [Customer Success]
version: 1
maj: 2026-08-26
---

# NPS Analyzer

## Ce qu'il faut avoir sous la main
- La **startup** concernée
- Les **réponses NPS** : lien vers le tableur/formulaire, ou données brutes collées dans le message
- La **fenêtre d'analyse** (défaut : 30 derniers jours)
- *(optionnel)* une **période de comparaison** pour calculer le delta du score


**Ce qu'elle suppose comme accès** : Réponses NPS brutes, Registre central des startups, Sales Pipeline DB, Support FAQ / base de connaissance CS, Google Sheets (ou équivalent), Typeform (ou équivalent), Visualisation interactive. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Charge les réponses brutes depuis la source fournie :
- lien de tableur → `[connecteur à brancher : Google Sheets (ou équivalent), lecture d'un tableau de réponses NPS]` ;
- identifiant de formulaire → `[connecteur à brancher : Typeform (ou équivalent), export des réponses d'un formulaire]` ;
- données brutes collées directement dans le message.

Schéma attendu (souple) :

- `score` : 0-10 (obligatoire)
- `comment` : verbatim libre (souvent dispo)
- `respondent_id` ou `email` : pour follow-up
- `submitted_at` : date
- `segment` : (optionnel) type de client, ancienneté, plan

Si un champ manque : signale-le explicitement en output, **ne devine jamais** la valeur.

### Étape 2 : Calcul NPS

- **Promoteurs** : score 9-10
- **Passifs** : score 7-8
- **Détracteurs** : score 0-6

```
NPS = (%promoteurs - %détracteurs) × 100
```

Réponds en absolu (score actuel) + delta vs période précédente si fournie.

Range de référence :

- NPS > 50 = excellent
- 20-50 = solide
- 0-20 = à travailler
- < 0 = signal d'alarme

### Étape 3 : Analyse des verbatims

Cluster les commentaires par thème (3-7 max). Pour chaque thème :

- **theme** : nom court ("Onboarding confus", "Frais cachés", "Rapidité paiement", "Support inexistant")
- **count** : nombre de mentions
- **sentiment_split** : combien dans promoteurs / passifs / détracteurs
- **verbatims_top** : 2-3 citations brutes représentatives
- **so_what** : 1 phrase d'analyse, c'est un atout, un risque, ou les deux ?

### Étape 4 : Actions promoteurs

Pour chaque promoteur (score 9-10) avec verbatim positif :

- **case_study_potential** : `high` (verbatim spécifique, chiffré, secteur clé) · `medium` · `low`
- **action** : "Demander interview pour case study + tag équipe marketing"
- **referral_potential** : si le commentaire mentionne "j'ai recommandé à des amis" → flag programme parrainage

Liste explicitement les 5 promoteurs prioritaires à contacter cette semaine. Pour chaque promoteur `case_study_potential: high`, crée une entrée dans `[datasource à brancher : Sales Pipeline DB de la startup, champs : nom/email, verbatim clé, date, tag « Case Study »]`.

### Étape 5 : Actions détracteurs (recovery)

Pour chaque détracteur (score 0-6) avec verbatim :

- **churn_risk** : `imminent` (mention de churn, alternatives) · `latent` · `low`
- **root_cause** : à quel thème ça appartient (croise Étape 3)
- **recovery_action** : "Appel personnel CSM dans 48h" · "Refund partiel" · "Roadmap update sur la feature manquante" · "Aucune action, feedback générique"
- **owner** : qui pilote la recovery

Liste explicitement les 5 détracteurs prioritaires à sauver cette semaine.

### Étape 6 : Reco produit

Croise les thèmes négatifs récurrents → 3 priorités produit pour le sprint suivant, classées par ordre d'impact NPS attendu.

Exemple :

- "Frais cachés" mentionné par 12 détracteurs → reprioriser la transparence pricing P0
- "Onboarding confus" par 8 passifs → améliorer le first-time UX P1
- "Pas d'app iOS" par 3 promoteurs déjà conquis → P2 (pas un facteur d'attrition)

## Format de sortie
```json
{
  "startup": "l'entreprise",
  "window": "2026-04-20..2026-05-20",
  "nps": {
    "score": 42,
    "delta_vs_previous": "+8",
    "promoteurs_pct": 58,
    "passifs_pct": 26,
    "detracteurs_pct": 16,
    "total_responses": 187
  },
  "themes": [...],
  "promoteurs_to_contact": [...],
  "detracteurs_to_recover": [...],
  "product_priorities": [
    {"theme": "Frais cachés", "priority": "P0", "expected_nps_lift": "+6 pts"}
  ],
  "next_step": "Brief CSM + product owner sur les 3 priorités"
}
```

## Règles
- **Pas de moyenne arithmétique** sur le score, NPS n'est PAS une moyenne, c'est %prom - %détr
- **Citer les verbatims** in extenso, ne pas paraphraser (la formulation est le signal)
- **Anonymiser** dans le rendu public, garder les emails dans une section "actions privées"
- **Multilingue** : reconnaître FR + EN + parfois langues locales (bambara, wolof), si pas sûr, dis-le
- **Échantillon minimum** : < 30 réponses → output "échantillon trop faible, analyse indicative" + recommande de collecter plus
- **Zéro invention** : un champ manquant, un thème sans verbatim suffisant, ou une source non fournie se signalent explicitement, jamais comblés par une valeur plausible

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution des ressources : Registry

Pour créer une entrée case study ou loguer les insights d'une analyse (étapes 4 et « Log »), résous les ressources de la startup via `[datasource à brancher : registre central des startups, répertorie, pour chaque startup, les liens vers sa Sales Pipeline DB (pipeline commercial où loguer les promoteurs à fort potentiel case study) et sa Support FAQ / base de connaissance CS (où loguer les insights clés de l'analyse)]`.

Si la startup n'est pas dans le registre (client hors portefeuille habituel), ne bloque pas l'analyse elle-même : signale simplement que le log en base est impossible faute de destination connue, et propose un export brut à la place.

### Visualisation & log

Si un outil de visualisation interactive est disponible, génère un graphique : distribution des scores + barre delta promoteurs/détracteurs sur la fenêtre analysée. Repli sur un tableau texte si l'environnement cible n'a pas de rendu interactif embarqué.

Une fois l'analyse complète, écris les insights clés (score NPS, thèmes, priorités produit) dans `[datasource à brancher : Support FAQ DB / base de connaissance CS de la startup]`.
