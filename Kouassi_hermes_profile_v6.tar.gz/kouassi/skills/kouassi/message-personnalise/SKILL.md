---
id: Y0196
name: message-personnalise
description: "Message d'outreach personnalisé (LinkedIn + email, FR+EN) pour approcher une cible, basé sur une recherche multi-sources."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-09-09
---

# Message personnalisé

## Ce qu'il faut avoir sous la main
1. **Objectif de l'outreach**, ex. *prospection commerciale, partenariat, levée de fonds, recrutement...*
2. **Toi (l'expéditeur)**, nom complet, poste actuel, entreprise
3. **La cible**, nom complet, poste actuel, entreprise actuelle (ou simplement son lien LinkedIn)


---


**Ce qu'elle suppose comme accès** : LinkedIn (accès profil + posts), Recherche web, Calendly. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### Étape 1 : Cadrer l'objectif
Ce qu'on attend concrètement de la cible : un rendez-vous, une introduction, une réponse. Un message sans demande claire n'obtient rien.

### Étape 2 : Rechercher la cible
Parcours, actualité récente, publications, sujets qu'elle porte. C'est cette recherche qui fait la différence entre un message personnalisé et un publipostage.

### Étape 3 : Trouver le point d'accroche
Un élément précis et récent qui justifie qu'on écrive **maintenant** et **à cette personne**. Un compliment générique ne compte pas comme accroche.

### Étape 4 : Rédiger les quatre versions
LinkedIn et email, en français et en anglais. LinkedIn court et direct, email un peu plus construit. Une seule demande par message.

### Étape 5 : Rendre les messages
Les quatre versions prêtes à envoyer, avec les sources de la recherche pour que l'expéditeur puisse vérifier avant de cliquer.

## Format de sortie
Une fois toutes les informations collectées et analysées, présenter les 4 messages dans ce format :

```
═══════════════════════════════════════════════════════════
📱 MESSAGE LINKEDIN - VERSION FRANÇAISE
═══════════════════════════════════════════════════════════

[Message de 300 caractères max]

Nombre de caractères : [X]/300

═══════════════════════════════════════════════════════════
📱 LINKEDIN MESSAGE - ENGLISH VERSION
═══════════════════════════════════════════════════════════

[Message with 300 characters max]

Character count: [X]/300

═══════════════════════════════════════════════════════════
📧 EMAIL - VERSION FRANÇAISE
═══════════════════════════════════════════════════════════

**OBJET :** [Objet personnalisé]

[Corps de l'email]

---
**[Prénom]**
[Poste] @ [Entreprise]

═══════════════════════════════════════════════════════════
📧 EMAIL - ENGLISH VERSION
═══════════════════════════════════════════════════════════

**SUBJECT:** [Personalized subject]

[Email body]

---
**[First name]**
[Position] @ [Company]

═══════════════════════════════════════════════════════════
```

Terminer par une courte méthodologie : sources consultées, période couverte, limites identifiées (ex. profil LinkedIn inaccessible, peu de contenu public).

## Règles
1. **Personnalisation factuelle obligatoire**, chaque message doit contenir au moins un élément unique à la cible, basé sur une donnée réellement trouvée en recherche. Si la cible est peu active/peu documentée, s'appuyer sur son entreprise ou son parcours plutôt que d'inventer une activité récente.
2. **Recherche multi-sources avant rédaction**, toujours croiser LinkedIn et web général (presse, interviews, podcasts, actualités entreprise) avant d'écrire ; ne jamais rédiger à partir de connaissances générales non vérifiées sur la cible.
3. **Respect strict des contraintes de format**, LinkedIn 300 caractères max et jamais de Calendly ; email 150-250 mots avec option créneaux/Calendly ; texte brut sans Markdown dans les messages finaux (hors séparateurs de structure).
4. **Adaptation au profil et bilinguisme systématique**, registre ajusté au niveau hiérarchique et au secteur de la cible (tutoiement startup/tech vs vouvoiement corporate/senior) ; toujours produire les 2 langues (FR + EN) pour chaque message.
5. **🔒 Aucun envoi automatique**, cette skill ne fait que **rédiger des brouillons**. Elle n'envoie jamais elle-même un message LinkedIn ou un email, et ne prend jamais de rendez-vous Calendly à la place de l'utilisateur. Tout envoi effectif est une action manuelle de l'utilisateur, sous sa propre validation, voir golden set § C.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Collecte des inputs

Demander à l'utilisateur, de manière concise et structurée :
1. **Objectif de l'outreach** (ex : prospection commerciale, partenariat, levée de fonds, recrutement, etc.)
2. **Informations sur l'expéditeur** : nom complet, poste actuel, entreprise
3. **Informations sur la cible** : nom complet, poste actuel, entreprise actuelle, ou simplement son lien LinkedIn

### Collecte de données sur la cible

Avant de rédiger, rassembler :
- Profil LinkedIn de la cible (parcours, bio, recommandations)
- Posts LinkedIn récents (30 derniers jours)
- Commentaires et interactions, activité et engagement
- Articles de presse mentionnant la personne
- Interviews, podcasts, vidéos
- Publications sur le site de l'entreprise
- Actualités de l'entreprise (levées de fonds, lancements, recrutements)
- Présence sur d'autres plateformes (Twitter/X, Medium, blogs)

`[connecteur à brancher : LinkedIn (accès profil + posts), via Apify ou Unipile, pour lire le profil de la cible, son activité des 30 derniers jours et ses interactions]`

`[connecteur à brancher : recherche web, pour les articles de presse, interviews, podcasts, publications d'entreprise et actualités récentes de la cible/son entreprise]`

Rechercher :
1. Activité LinkedIn des 30 derniers jours (posts, commentaires, partages)
2. Actualités de l'entreprise des 3 derniers mois
3. Présence web récente (interviews, articles)
4. Parcours professionnel et expertise
5. Centres d'intérêt professionnels

### Adaptation de la stratégie selon le profil

**Selon le niveau hiérarchique de la cible :**
- C-level / Founder : approche directe, focus ROI/vision stratégique
- Manager / Director : focus opérationnel et résultats
- IC / Employee : approche collaborative, focus expertise

**Selon le secteur :** adapter le vocabulaire et les références au secteur de la cible.

**Selon l'activité en ligne de la cible :**
- Très active : référencer un post/commentaire récent précis
- Peu active : focus sur l'entreprise ou le parcours (ne jamais inventer une activité récente qui n'existe pas)

**Selon le contenu long trouvé :** si interviews/articles récents ou participation à des événements identifiés, les mentionner pour crédibiliser l'approche et créer du lien contextuel.

### Rédaction : créer 2 versions (FR + EN) de chaque message

### Message LinkedIn
**Contraintes :**
- Maximum 300 caractères (espaces inclus)
- Ton professionnel mais sympathique
- Accroche personnalisée basée sur la recherche
- Call-to-action simple vers l'email
- Pas de lien Calendly ni de créneaux

**Structure recommandée :**
1. Accroche personnalisée (référence à actualité/post/projet réel)
2. Raison du contact (brief)
3. CTA vers email (« Je t'envoie un email avec plus de détails »)

### Email
**Contraintes :**
- Longueur moyenne (150-250 mots)
- Ton professionnel mais accessible
- Objet percutant et personnalisé
- Corps structuré en paragraphes courts
- Inclure une option créneaux OU un lien Calendly

**Structure recommandée :**
1. **Objet** : personnalisé et intrigant
2. **Introduction** : accroche personnalisée (plus développée que LinkedIn)
3. **Contexte** : qui tu es et pourquoi tu contactes
4. **Proposition de valeur** : quel est l'intérêt pour la cible
5. **Call-to-action** : proposition de créneaux ou lien Calendly `[connecteur à brancher : Calendly, insertion du lien de prise de rendez-vous de l'expéditeur, si fourni]`
6. **Signature** : prénom + fonction

### Principes de rédaction
- **Authenticité** : personnalisation basée sur des faits réels, jamais inventés
- **Concision** : aller à l'essentiel
- **Valeur** : montrer clairement l'intérêt pour la cible
- **Proximité** : tutoiement si startup/tech, vouvoiement si corporate/senior
- **Éviter** : jargon excessif, promesses vagues, formules génériques

### Checklist qualité avant de livrer

☐ 4 messages produits (LinkedIn FR/EN + Email FR/EN)
☐ Chaque message LinkedIn ≤ 300 caractères, compteur affiché
☐ Chaque message contient au moins un élément de personnalisation vérifiable dans la recherche
☐ Calendly/créneaux uniquement dans l'email, jamais dans LinkedIn
☐ Texte brut dans les messages finaux (pas de Markdown, sauf séparateurs de structure)
☐ Registre (tutoiement/vouvoiement) cohérent avec le profil de la cible
☐ Aucune information inventée ; limites de recherche signalées si contenu insuffisant
