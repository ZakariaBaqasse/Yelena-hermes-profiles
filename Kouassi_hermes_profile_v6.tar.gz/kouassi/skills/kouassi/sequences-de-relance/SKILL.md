---
id: Y0399
name: sequences-de-relance
description: "Conçoit les suites de messages envoyées à quelqu'un qui a manifesté un intérêt sans acheter — visiteur de salon, panier abandonné, client qui n'a pas racheté : déclencheur, délai, canal, contenu à valeur ajoutée et condition d'arrêt pour chaque message, avec vérification systématique du consentement — sans jamais planifier un envoi qui parte sans validation humaine."
bucket: B
tags: [Marketing, Contenu, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Séquences de relance — rester présent sans harceler

## Ce qu'il faut avoir sous la main
- **Qui est relancé** : un visiteur qui a laissé son contact, un prospect de salon, un panier abandonné, un client qui n'a pas racheté — précise le déclencheur exact (date, action, ou absence d'action).
- **Comment ce contact est entré dans ta liste** : formulaire en ligne coché, carte de visite échangée en salon, numéro récupéré sans démarche explicite. C'est la première chose que je vérifie.
- **Le ou les canaux disponibles** : WhatsApp, SMS, courriel, appel — et lesquels tu privilégies.
- **L'objection ou le frein probable** qui explique pourquoi la personne n'a pas encore acheté, si tu le sais.
- **Ce que tu as déjà en main** comme contenu réutilisable : preuve sociale, offre, échéance réelle, FAQ.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage. La seule exception : l'origine du consentement, jamais supposée.

## Process
### Étape 1 — Reconstituer l'origine du contact et le consentement

Avant d'écrire un seul mot de message, tu établis **comment ce contact est arrivé dans la liste**. Formulaire coché avec case de consentement explicite, échange de carte en salon, numéro donné oralement, contact récupéré dans un carnet ou une liste achetée — chaque origine n'ouvre pas le même droit de relancer.

Si l'origine est floue ou si le consentement n'est pas établi, tu le dis avant de produire la séquence : envoyer sans savoir comment le contact est entré dans la liste expose l'entreprise et abîme la marque, quel que soit le soin mis dans la rédaction des messages. Tu nommes l'autorité compétente pour la protection des données personnelles dans le pays concerné (en Côte d'Ivoire, l'**ARTCI**) et tu rappelles qu'elle a la charge de ce sujet — tu ne cites aucun taux, aucun délai légal ni aucun article de mémoire : ce qui est chiffré ou juridiquement précis est `⟦à renseigner⟧` par le service juridique ou conformité de l'entreprise.

Le désabonnement doit être possible dans chaque message et respecté sans délai dès qu'il est exprimé, sur tous les canaux — y compris un simple « stop » tapé sur WhatsApp.

### Étape 2 — Identifier ce qui bloque, pas ce qu'on veut vendre

Une relance qui répète l'offre initiale n'apporte rien de nouveau à quelqu'un qui l'a déjà vue et n'a pas agi. Tu cherches **l'objection probable** : prix, doute sur la qualité, manque d'urgence, besoin de validation par un tiers, oubli pur et simple. Chaque hypothèse d'objection donne un message différent — ce n'est pas la même séquence qui répond à un doute sur le prix et à un simple oubli.

Si l'objection n'est pas connue, tu le marques `[hypothèse : …]` et tu proposes la séquence la plus prudente : celle qui apporte de l'information avant de redemander l'achat.

### Étape 3 — Choisir le canal et sa fréquence tolérée

Le piège classique est de traiter tous les canaux avec la même cadence. WhatsApp est un canal personnel : la tolérance y est basse, et un message de trop y coûte un blocage définitif, pas une simple désinscription. Un courriel professionnel tolère un rythme plus soutenu ; un appel a un coût humain qui limite de lui-même le nombre de tentatives.

Tu fixes, pour chaque canal retenu, une **fréquence maximale** — nombre de messages sur la période, espacement minimal entre deux messages — et tu la marques `⟦à renseigner⟧` tant que l'entreprise n'a pas tranché elle-même ce seuil ; tu donnes la structure de la décision (canal, cible de fréquence, justification), pas le chiffre à sa place.

### Étape 4 — Construire la séquence, message par message, par l'apport

Pour chaque message : le **déclencheur** (quelle action ou absence d'action le lance), le **délai** depuis le message précédent ou l'événement initial, le **canal**, l'**objet** s'il y a lieu, le **corps rédigé**, et surtout l'**apport propre** — ce que ce message donne au destinataire qu'il n'avait pas reçu avant : réponse à une objection, preuve, échéance réelle, information utile, offre différente.

Un message dont l'unique contenu est « je reviens vers vous » ou « avez-vous eu le temps de regarder » n'a pas d'apport et sort de la séquence — tu le dis explicitement plutôt que de le garder pour faire nombre. Une séquence courte et utile vaut mieux qu'une séquence longue qui use la patience du destinataire.

### Étape 5 — Écrire les conditions d'arrêt

Une séquence s'arrête quand : la personne répond (peu importe le sens de la réponse, une main humaine reprend la main), elle achète, elle se désabonne, ou le nombre de messages prévu est épuisé sans réponse. La faute la plus visible et la plus évitable est de continuer une séquence après une réponse humaine — tu l'écris comme une règle absolue, pas une recommandation.

Tu formalises ces conditions dans un tableau séparé, lisible indépendamment du contenu des messages, pour que quiconque programme l'envoi sache à quel moment couper.

### Étape 6 — Poser le point de validation humaine

Cette compétence prépare, elle n'envoie pas. Tu marques explicitement, avant la livraison de la séquence, qu'aucun message ne part sans validation d'un responsable pour cet envoi précis, et qu'aucun envoi n'est planifié à l'avance sans qu'une personne ait relu ce qui partira au moment où ça partira — un message resté correct au moment de l'écriture peut devenir déplacé après un changement d'offre, un incident, une actualité.

## Format de sortie
- **Livrable** : la séquence complète — un tableau par message (déclencheur, délai, canal, objet, corps rédigé, apport propre, condition de sortie associée), le tableau des conditions d'arrêt globales, la fiche de consentement par source de contact, la fréquence maximale retenue par canal, et le rappel du point de validation humaine avant tout envoi.
- **Structure** : Markdown clair — answer-first (la séquence d'abord, ses justifications ensuite) ; tableaux pour les messages et les conditions d'arrêt.
- **Longueur** : proportionnée au nombre de messages et de canaux, sans remplissage.
- **Les seuils de fréquence et les délais légaux sont un input**, pas une production : la skill livre la structure (canal, dénominateur, question à trancher), la **valeur** vient de l'équipe ou du service conformité et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Chaque message porte une raison d'exister.** Une réponse à une objection courante, une preuve, une échéance réelle ou une information utile — sinon le message est supprimé de la séquence, pas gardé pour faire nombre.
2. **L'origine du contact conditionne le droit de relancer.** Tu établis comment chaque contact est entré dans la liste avant d'écrire un message ; sans cette information, tu le signales et tu ne fabriques pas de consentement supposé.
3. **La fréquence est par canal, jamais unique.** WhatsApp, courriel et appel n'ont ni la même tolérance ni le même coût d'un envoi de trop ; une seule cadence pour tous les canaux est une erreur de conception.
4. **La réponse humaine arrête la séquence, sans exception.** Dès qu'une personne répond, achète ou se désabonne, la séquence s'arrête ; ce n'est jamais une option laissée à l'appréciation de l'outil d'envoi.
5. **Le désabonnement est toujours possible et toujours respecté.** Chaque message porte un moyen simple de sortir de la liste, sur tous les canaux, y compris WhatsApp.
6. **0 chiffre ou référence légale inventés.** Aucune fréquence maximale, aucun délai légal, aucun taux ou article n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon. Tu peux nommer l'autorité compétente (ARTCI en Côte d'Ivoire) et son domaine de charge, jamais un chiffre attaché à sa réglementation.
7. **Aucun envoi n'est déclenché ou planifié par cette compétence.** Elle prépare un document de travail relu et validé par un humain avant chaque envoi, y compris pour un envoi déjà prévu à l'avance.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer un message, programmer une campagne ou modifier une liste de diffusion est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ou d'une liste de contacts ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Origine du contact inconnue ou consentement non établi** — tu le signales avant de produire la séquence, tu ne la construis pas comme si le consentement existait, et tu proposes la marche à suivre la plus prudente (reconfirmation du consentement avant toute relance).
- **Contact issu d'une liste achetée ou d'un carnet sans démarche explicite** — tu le nommes comme un risque réputationnel et réglementaire clair, tu ne rédiges pas la séquence sans cet avertissement écrit dans le livrable.
- **Aucune objection connue** — tu marques l'hypothèse `[hypothèse : …]` et tu proposes la séquence la plus informative avant de redemander l'achat.
- **Un seul canal disponible** — tu adaptes la fréquence à ce canal précisément plutôt que d'appliquer une cadence générique, et tu signales la limite (pas d'alternative en cas de blocage).
- **Client déjà répondu ou déjà acheté** — la séquence s'arrête immédiatement ; tu ne proposes jamais de message de continuation « au cas où ».
- **Demande de programmer l'envoi ou d'automatiser la séquence sans point de contrôle** — tu prépares la séquence et le calendrier proposé, et tu t'arrêtes pour validation humaine explicite avant tout déclenchement.
- **Réglementation ou seuil de fréquence non fourni** — tu marques `⟦à renseigner⟧`, tu ne complètes pas avec un chiffre plausible « habituellement observé dans le secteur ».
- **Séquence destinée à un pays ou une réglementation différente de la Côte d'Ivoire** — tu le signales, tu ne transposes pas l'autorité ni les usages ivoiriens sans vérification.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (segmentation de base clients, campagne d'acquisition, gestion de la relation client).
