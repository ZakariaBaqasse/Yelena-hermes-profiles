---
id: Y0099
name: client-mapper
description: "Génère une carte interactive du portefeuille clients d'un client Yelema (épingles géolocalisées, fiches clients détaillées, filtres dynamiques par zone/secteur/statut, leaderboard des zones) à partir d'un fichier clients, colonnes affichées adaptées automatiquement au secteur d'activité détecté (fintech, mobilité, agritech, contech, recommerce...)."
bucket: C
tags: [Ops]
version: 1
maj: 2026-08-26
---

# ClientMapper

## Ce qu'il faut avoir sous la main
1. Le **nom du client/de l'entreprise** dont tu veux cartographier les clients (pour résoudre son contexte métier et ses préférences enregistrées) ;
2. Le **fichier clients** (upload ou copier-coller) si tu l'as sous la main, sinon je vais le chercher dans les bases connectées.

## Process
### Étape 1 : Lire les données
Charge le fichier clients et identifie les colonnes exploitables : localisation, secteur, statut, volume. Une colonne ambiguë est signalée, pas interprétée.

### Étape 2 : Géolocaliser
Place chaque client sur la carte. Les adresses non résolues sont listées à part plutôt que rattachées à un point approximatif, un client mal placé fausse la lecture de toute la zone.

### Étape 3 : Construire les fiches
Une fiche par client, avec les informations réellement présentes dans les données. Aucun champ n'est complété par déduction.

### Étape 4 : Poser les filtres et le classement des zones
Filtres dynamiques sur les critères disponibles, et classement des zones sur un indicateur explicite (nombre de clients, volume, taux d'activité), l'indicateur retenu est écrit.

### Étape 5 : Rendre la carte
Artefact interactif autoportant, avec le nombre de clients cartographiés et le nombre de non-résolus affichés en clair.

## Format de sortie
- **Livrable** : Génère une carte interactive du portefeuille clients d'un client Yelema (épingles géolocalisées, fiches clients détaillées, filtres dynamiques par zon.
- **Structure** : Markdown clair, titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Configuration par client

Une fois le nom du client reçu, **vérifie d'abord** via `[connecteur à brancher : mémoire agent persistante]` si des préférences sont déjà enregistrées pour ce client (colonnes prioritaires, filtres, palette de couleurs). **Si des préférences existent**, affiche-les et propose : **« Des préférences sont enregistrées pour [Client] : [résumé]. Souhaitez-vous les utiliser ou les modifier ? »**

Ensuite, **recherche le contexte du client** via :
1. `[datasource à brancher : base de connaissance décrivant les clients du portefeuille, secteur, type de clientèle, produit, zone d'activité]` ;
2. `[datasource à brancher : dossier de fichiers projet du client, fichier clients au format Sheet ou CSV]`.

Si introuvable, demande à l'utilisateur de fournir les données manuellement (copier-coller ou upload). **Ne jamais supposer ni inventer des données absentes.**

**⚠️ Chargement complet obligatoire** : lors de la lecture d'un fichier, effectuer autant de batches que nécessaire jusqu'à ce qu'aucune nouvelle ligne ne soit retournée. Ne JAMAIS générer la carte avant d'avoir confirmé que la totalité des données est chargée, quelle que soit la taille du fichier.

Sauvegarde les préférences confirmées via `[connecteur à brancher : mémoire agent persistante]` à la fin de la session.

### Données clients requises

**Colonnes requises (minimum) :** `nom` + au moins une colonne de localisation (`adresse`, `zone`, `quartier`, `ville` ou coordonnées GPS). Si absentes, **BLOQUER la génération** et afficher : **« ⚠️ Colonnes de localisation manquantes. Génération de la carte bloquée. Merci de compléter le fichier avec au moins une colonne de localisation. »**

**Colonnes recommandées :** `contact`, `secteur`, `statut` (actif / prospect / inactif), `produit_utilisé`, `date_acquisition`, `volume_ca`, `notes`.

### Adaptation selon le secteur du client

Adapte les informations affichées dans les fiches clients selon le secteur détecté :

- **FinTech / Paiement / Inclusion financière** : moyen de paiement utilisé, volume de transactions, fréquence d'utilisation, statut d'intégration
- **Mobilité électrique / Climate Tech** : type de véhicule, zone de recharge, statut de financement, kilométrage estimé
- **AgriTech / FoodTech / Marketplace B2B** : type de produits commandés, fréquence de commandes, distance au point de livraison, statut producteur ou acheteur, colonnes opérationnelles : `authorize_place_order` (le client peut-il commander ?), `orderJ+` / `orderJ0` (comportement de commande J0 vs J+1), `order_from_backoffice` vs `order_by_customer` (autonomie du client). Ajouter un badge **⚠️ Risque impayé** sur les fiches clients dont `number_days_last_unpaid_order` dépasse un seuil anormal, demander à l'utilisateur de définir ce seuil si non précisé, ou l'inférer depuis les données (ex : percentile élevé de la distribution observée).
- **Contech / Marketplace B2B** : type de matériaux, volume de commandes, délai de livraison moyen
- **Recommerce / Marketplace B2B** : type d'appareils, canal de revente, volume traité
- **Autre / Non identifié** : afficher toutes les colonnes disponibles dans le fichier

### Génération de la carte interactive

Génère un composant interactif via `[connecteur à brancher : génération de composant interactif/dashboard web (ex. React), avec carte géographique embarquée]`. **Ne pas afficher de cartes KPI globales en haut du dashboard.** Afficher directement :

- **Carte avec épingles** positionnées par zone/adresse
- **Fiches clients cliquables** affichant toutes les informations disponibles
- **Barre de recherche** permettant de filtrer instantanément par nom, ID client ou zone, **Filtres dynamiques** : afficher les zones sous le format **« Zone N (Nom du quartier) »** en combinant le libellé de zone (colonne `zone`) avec le nom géographique réel (colonne `quartier`, `commune` ou `arrondissement` si disponible). Si une seule colonne de localisation est présente, l'utiliser directement. Ajouter également les filtres : secteur, statut, et toute autre colonne pertinente détectée dans les données.
- **Code couleur par statut** : vert = actif, orange = prospect, rouge = inactif/churné
- **Statistiques résumées** : total clients, répartition par zone et par statut, **Leaderboard des zones** : tableau dont chaque ligne affiche la zone sous le format **« Zone N (Nom du quartier) »**, en combinant le libellé de zone (colonne `zone`) avec le nom géographique réel (colonne `quartier`, `commune` ou `arrondissement` si disponible). Si une seule colonne de localisation est présente, l'utiliser directement comme libellé de ligne. Colonnes du tableau : zone, nombre de clients total, nombre de clients actifs, **taux d'activité** (% clients actifs / total de la zone), **taux de churn** (% clients inactifs / total de la zone), CA total (`total_amount_order` si disponible), panier moyen (`medium_basket` si disponible). Trié par défaut par CA décroissant. Si aucune colonne montant n'est disponible, trier par taux d'activité décroissant et masquer la colonne CA. Toujours afficher les taux sous forme de pourcentage arrondi à une décimale.

Si les adresses sont textuelles (ex : « Quartier Matonge, Kinshasa »), représente les clients par zones/quartiers avec des marqueurs groupés. Ne jamais bloquer la génération pour absence de GPS, adapter la représentation en conséquence.

Si l'environnement cible ne permet pas de rendu interactif embarqué, produis en repli un **tableau markdown** listant les clients avec les mêmes colonnes (statut, zone, secteur…), précédé des statistiques résumées et du leaderboard des zones, sans jamais perdre l'information de filtrage ni de code couleur (rendu en texte : « 🟢 actif », « 🟠 prospect », « 🔴 inactif »).

### Partage

La carte est partageable via `[connecteur à brancher : partage de lien de composant interactif]`. Propose systématiquement à la fin de chaque session : **« Souhaitez-vous envoyer cette carte par email aux membres de l'équipe ? »** Si oui, suivre ces étapes :

1. **Collecte des emails** : demande les adresses email des destinataires (ou récupère-les depuis les données chargées si disponibles, ex. colonne `contact`).
2. **Vérification des accès** : rappelle à l'utilisateur que les destinataires doivent avoir accès à l'espace de travail pour pouvoir ouvrir le lien de la carte. Affiche : **« ⚠️ Assurez-vous que ces adresses ont bien accès à l'espace de travail avant l'envoi. »** Attend la confirmation avant de procéder.
3. **Envoi par email** : utilise `[connecteur à brancher : envoi d'email]` pour envoyer un message professionnel contenant : le nom du client, une courte description de la carte, et le lien de la carte.

🔒 **Aucun envoi automatique** : l'envoi par email reste une action déclenchée uniquement après confirmation explicite de l'utilisateur (étape 2 ci-dessus), jamais en silence.

### Configuration (déployée pour le programme)

>
