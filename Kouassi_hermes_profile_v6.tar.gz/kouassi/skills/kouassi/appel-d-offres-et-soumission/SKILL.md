---
id: Y0425
name: appel-d-offres-et-soumission
description: "Décide s'il faut candidater à un appel d'offres public ou privé, construit à partir du dossier de consultation lui-même la liste exacte des pièces exigées, le rétroplanning de collecte en remontant depuis la date limite, vérifie la conformité administrative avant de travailler l'offre technique et financière, et prépare le dossier de dépôt : sans jamais citer de mémoire un seuil de procédure, un montant de caution ou un délai légal absent du dossier."
bucket: B
tags: [Commercial, Appels d'offres, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le dossier de soumission, ce qui fait éliminer avant même qu'on lise l'offre

## Ce qu'il faut avoir sous la main
- **Le dossier de consultation** (DAO, cahier des charges, appel à manifestation d'intérêt) lui-même, ou son lien de téléchargement. C'est la seule source pour la liste des pièces, je n'en invente pas à partir d'un dossier précédent.
- **L'objet du marché** et **l'autorité contractante** ou le client, s'il s'agit d'un appel d'offres privé.
- **La date et l'heure limites de dépôt**, et le mode de dépôt attendu (physique, plateforme électronique, les deux).
- **Ta capacité actuelle** sur ce type de prestation : références similaires réalisées, équipe réellement disponible pour préparer le dossier, trésorerie pour couvrir une éventuelle caution ou avance.
- **Les pièces déjà en portefeuille** que tu penses détenir (registre de commerce, attestations fiscales et sociales, agréments, etc.) et leur date d'émission si tu l'as sous la main.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le dossier de consultation est déjà fourni (même sans le reste), je **produis directement le livrable** en étiquetant mes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Extraire la liste exacte des pièces, depuis le dossier lui-même
Lis le dossier de consultation ligne par ligne dans sa partie administrative et liste chaque pièce exigée telle qu'elle y est décrite : intitulé exact, forme demandée (original, copie certifiée conforme, légalisée, traduction assermentée si le dossier est dans une langue différente), nombre d'exemplaires, mode de dépôt (pli physique scellé, dépôt sur plateforme, les deux).

Piège à éviter absolument ici : recopier la liste d'un dossier précédent, ou une liste type « pour ce genre de marché ». Chaque dossier de consultation a ses propres exigences, parfois avec un addenda qui les modifie en cours de route. Une pièce qui suffisait la dernière fois peut être refusée cette fois sous une forme différente. Si le dossier fourni est incomplet ou illisible sur cette partie, tu le signales avant de continuer : tu ne complètes jamais de mémoire.

### Étape 2 : La grille de décision, avant de préparer quoi que ce soit
Avant d'engager du temps sur le dossier, trancher s'il faut y répondre. La grille porte sur : la capacité réelle de l'entreprise à exécuter dans le délai demandé, l'écart entre les références exigées et les références détenues, les conditions de paiement annoncées (délai de règlement, existence ou non d'une avance de démarrage), la concurrence probable sur ce type de marché, et le coût de préparation du dossier rapporté à la probabilité de gain estimée par l'équipe elle-même.

Chaque critère est noté par l'entreprise, pas par la compétence : tu poses la grille et la question à trancher, la valeur et le jugement viennent de l'équipe. Un no-go argumenté à ce stade est le résultat le plus utile que tu puisses produire : il évite d'épuiser l'équipe sur un dossier qu'elle ne peut pas gagner ou qu'elle gagnerait pour l'exécuter à perte.

### Étape 3 : Le rétroplanning à rebours de la date limite
Pars de la date et de l'heure limites de dépôt. Pour chaque pièce de la liste de l'étape 1, indique son détenteur (l'entreprise elle-même, une administration, un tiers comme une banque pour une caution ou une attestation), son délai d'obtention habituel, et remonte le calendrier avec une marge de sécurité.

Le point critique du rétroplanning est la pièce dont le délai d'obtention est le plus long ou le plus incertain, pas nécessairement la plus importante sur le fond. Certaines attestations administratives ne s'obtiennent pas le jour de la demande, et leur obtention suppose parfois un déplacement physique, une file d'attente, ou un passage par un guichet dont les horaires ne collent pas avec les embouteillages d'Abidjan. Tu nommes l'institution compétente pour chaque pièce (DGI, CNPS, chambre de commerce, ARTCI selon le cas) sans jamais inventer son délai de traitement : ce délai est une donnée à obtenir auprès d'elle ou à confirmer par l'entreprise, jamais une estimation de ta part présentée comme un fait.

### Étape 4 : Vérifier la conformité administrative avant de toucher au contenu
Reprends chaque pièce et vérifie, dans l'ordre : sa forme correspond-elle exactement à ce qui est exigé (original vs copie, certification, légalisation) ; sa date de péremption, si elle en a une, couvre-t-elle la date de dépôt et pas seulement la date de préparation ; la raison sociale, le numéro d'identification et l'objet du marché mentionnés correspondent-ils exactement à ceux du dossier de consultation ; le nombre d'exemplaires demandé est-il respecté.

Nomme explicitement les motifs d'élimination les plus fréquents pour que l'équipe les vérifie un par un : attestation valide au moment de la collecte mais périmée au moment du dépôt, pièce en copie simple alors qu'une certification était exigée, signature manquante sur une déclaration sur l'honneur, exemplaire en moins par rapport au nombre demandé, pli libellé de façon non conforme aux instructions du dossier (mention manquante, enveloppe non scellée). Une seule de ces erreurs suffit à ce que l'offre ne soit jamais ouverte, indépendamment de la qualité du contenu.

### Étape 5 : L'offre technique et financière, une fois la conformité sécurisée
Ce n'est qu'après avoir traité la conformité administrative que tu structures le mémoire technique et la partie financière. Vérifie la cohérence entre ce que demande le cahier des charges (méthodologie, moyens humains et matériels affectés, planning d'exécution, références présentées) et ce que l'entreprise peut réellement démontrer.

Le chiffrage du prix appartient à l'entreprise, tu ne le fabriques pas. Le piège à nommer ici : construire un prix à l'envers, aligné sur ce qu'on imagine être le budget de l'autorité contractante, plutôt que sur le coût réel de réalisation augmenté de la marge. Un marché gagné à un prix construit à l'envers se perd en exécution, souvent avec des pénalités de retard ou une qualité dégradée qui abîme la réputation de l'entreprise pour les prochains appels d'offres. Tu structures la grille de chiffrage (postes de coût, marge, aléas), la valeur reste `⟦à renseigner⟧` par l'entreprise.

### Étape 6 : Assembler le dossier de soumission et préparer le dépôt
Construis le sommaire du dossier dans l'ordre exact imposé par le dossier de consultation, pas dans un ordre logique de ton choix : certains dossiers de consultation sont eux-mêmes éliminatoires sur l'ordre des pièces. Pour chaque section, indique ce qui est prêt et ce qui manque encore.

Vérifie les conditions matérielles du dépôt : nombre d'exemplaires du dossier complet, mode de reliure ou d'agrafage si précisé, recours à un imprimeur local si le volume ou la qualité de reproduction l'exige, mode de dépôt (dépôt physique à une adresse et un horaire précis, ou téléversement sur une plateforme électronique avec ses propres contraintes de format de fichier et de délai serveur). Signale si le dossier de consultation prévoit une plateforme électronique dont l'accès est déjà connu pour être instable en fin de délai : c'est un motif fréquent de dépôt manqué, à anticiper largement avant l'échéance plutôt que la veille.

## Format de sortie
- **Livrable** : la grille de décision de candidature avec sa recommandation argumentée ; la liste des pièces exigées reprise du dossier de consultation, avec pour chacune sa forme, son détenteur, son délai d'obtention, son état (détenue, à obtenir, en cours) et sa date de péremption le cas échéant ; le rétroplanning à rebours de la date limite avec le point critique identifié ; le sommaire du dossier de soumission dans l'ordre imposé, avec ce qui est prêt et ce qui manque.
- **Structure** : Markdown clair, answer-first (la décision de candidater ou non d'abord, son raisonnement ensuite), tableaux pour la liste des pièces et le rétroplanning.
- **Longueur** : proportionnée à la complexité du dossier de consultation, sans remplissage.
- **Les seuils et les prix sont des inputs**, pas une production de la compétence : elle livre la structure de la grille et du chiffrage, la valeur vient de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune référence réglementaire, aucun seuil de procédure, aucun montant de caution, aucun délai légal inventé. Ce qui n'est pas écrit dans le dossier de consultation est marqué « à vérifier auprès de l'autorité contractante ».

## Règles
1. **La conformité administrative se traite avant le contenu.** Tant que la liste des pièces n'est pas vérifiée et le rétroplanning posé, tu ne discutes pas de méthodologie technique ni de prix.
2. **La liste des pièces vient du dossier de consultation, jamais de mémoire.** Une liste recopiée d'un dossier précédent ou d'une habitude sectorielle est une erreur de méthode, même si elle se ressemble à 90 %.
3. **Le rétroplanning part de la date limite et remonte, avec marge.** Le point critique est la pièce au délai d'obtention le plus long ou le plus incertain, pas la plus visible.
4. **Le no-go est une issue normale de la grille de décision.** Tu ne cherches pas un angle pour justifier de candidater à tout prix ; une réponse préparée sans chance réelle coûte du temps qui manquera pour le prochain dossier gagnable.
5. **Le chiffrage vient de l'entreprise, la compétence ne le fabrique pas.** Un prix aligné sur un budget supposé plutôt que sur un coût réel augmenté de la marge n'est jamais proposé par la compétence.
6. **Aucune référence réglementaire n'est citée de mémoire.** Autorité compétente : nommée. Article, seuil de procédure, montant de caution, délai légal : jamais cités sans être écrits dans le dossier de consultation ou sourcés par un lien vérifié.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans le dossier de consultation est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une plateforme de dépôt ou un connecteur est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette compétence produit un document de travail ; déposer un dossier, signer une déclaration, contacter l'autorité contractante ou verser une caution est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier d'appel d'offres ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Dossier de consultation incomplet ou pages manquantes** : tu le signales avant de continuer, tu ne complètes jamais la liste des pièces de mémoire.
- **Date limite déjà très proche ou dépassée** : tu le dis explicitement dès le premier message, avant de produire quoi que ce soit d'autre ; le rétroplanning peut montrer qu'il est déjà trop tard pour une pièce donnée.
- **Pièce administrative introuvable ou périmée sans possibilité de renouvellement à temps** : tu le signales comme un risque d'élimination et tu le fais remonter dans la grille de décision, plutôt que de l'ignorer.
- **Plateforme électronique de dépôt inaccessible ou non testée** : tu recommandes un test de dépôt à blanc avant la dernière heure, et tu signales le risque dans le rétroplanning.
- **Appel d'offres restreint, gré à gré ou marché privé sans procédure formalisée** : tu adaptes la grille de décision et la vérification de conformité, en signalant que certaines mentions du gabarit public ne s'appliquent pas telles quelles.
- **Groupement d'entreprises ou sous-traitance déclarée** : tu identifies les pièces à fournir par chaque membre du groupement séparément, sans les fusionner de mémoire.
- **Dossier en langue étrangère ou partiellement traduit** : tu le signales et tu marques les sections non traduites comme non vérifiées.
- **Demande hors périmètre** (rédaction commerciale hors appel d'offres, négociation contractuelle post-attribution) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (déposer le dossier, envoyer une pièce, signer un engagement) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (addenda modifiant le dossier initial, versions différentes du cahier des charges) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
