---
id: Y0529
name: compte-rendu-entretien-commercial
description: >
  Transforme des notes de rendez-vous en compte rendu utilisable : ce qui s'est dit, ce qui
  a été promis et par qui, ce qui reste inconnu, et la prochaine échéance datée. Sépare
  strictement ce que le client a dit de ce qu'on en a déduit. À charger après un rendez-vous,
  un appel, ou pour rattraper un fil de messages avant de relancer.
bucket: A
tags: [Sales]
version: 1
maj: 2026-09-06
---

# Compte rendu d'entretien commercial

## Pourquoi c'est la compétence la plus rentable de la série

Tout le reste s'appuie dessus. La qualification a besoin de ce qui s'est dit, le devis a
besoin du périmètre discuté, la relance a besoin de ce qui a été promis, et le successeur
d'un commercial qui part a besoin de tout. Sans compte rendu, chaque rendez-vous suivant
recommence à zéro et le client s'en aperçoit.

Et c'est la première chose qu'on saute, parce qu'elle ne se voit pas le jour même.

## Ce que je demande

Les notes brutes, la transcription, ou simplement ce dont on se souvient. **En désordre,
c'est très bien.** Mettre en ordre est mon travail. Plus les notes sont brutes, moins
elles sont déjà réinterprétées.

Si des notes manquent, je produis avec ce qu'il y a et je marque les trous.

## La méthode

### La règle unique : trois colonnes qui ne se mélangent jamais

C'est tout l'intérêt de l'exercice.

- **Dit** — les mots du client, entre guillemets quand ils sont exacts. « Notre problème,
  c'est qu'on refait deux fois le même devis. »
- **Déduit** — ce qu'on en comprend, marqué comme tel. `[déduction : leur outil de devis ne
  garde pas l'historique]`.
- **Inconnu** — ce qui n'a pas été abordé et qu'il faudra demander.

Un compte rendu qui mélange les trois se relit deux mois plus tard comme un fait établi.
C'est ainsi qu'on construit une proposition sur une déduction que personne n'a jamais
vérifiée.

### La structure

1. **En-tête** — date, participants avec leur fonction, canal, durée.
2. **Ce que le client a dit**, par sujet, dans ses mots.
3. **Ce que j'en déduis**, clairement séparé.
4. **Ce qui a été promis** — deux listes distinctes : par nous, par eux. Chaque engagement
   porte un nom et une date. Un engagement sans date n'est pas un engagement.
5. **Ce qui reste inconnu** — alimente directement les sept questions de
   `qualification-affaire`.
6. **La prochaine échéance** — quoi, qui, quand. Une seule.

### Les signaux qui méritent d'être notés même s'ils semblent secondaires

- **Qui parle et qui se tait.** Le silencieux qui pose une question à la fin est souvent
  celui qui décide.
- **Une échéance mentionnée en passant** — un salon, un exercice budgétaire, une
  installation. C'est ce qui donne une date réelle à l'affaire.
- **Une objection formulée en plaisantant.** C'est une vraie objection, testée à moindre
  risque.
- **Ce que le client a demandé deux fois.** La répétition marque ce qui compte pour lui,
  et c'est rarement ce qu'on croit.

### Ce qu'on écrit dans un compte rendu destiné au client

Un compte rendu envoyé au client n'est pas le compte rendu interne. Il ne contient ni les
déductions, ni les appréciations, ni les notes sur les personnes. Il reprend les faits, les
engagements réciproques et la prochaine échéance. Il vaut confirmation écrite, ce qui
est précisément son utilité.

Deux documents, deux périmètres. Ne jamais envoyer l'interne.

## Ancrage local

Voir `memory/reference/vendre-en-cote-d-ivoire.md`. Une grande partie des échanges se fait
en messages, pas en réunion : le compte rendu se fabrique aussi bien à partir d'un fil
WhatsApp, et c'est même là qu'il manque le plus, parce qu'un fil donne l'illusion d'être
déjà une trace. Un fil de trois cents messages n'est pas une trace, c'est une archive
illisible.

## Format de sortie

Le compte rendu interne en document structuré, plus la version client si elle est demandée.
Formats de rendu : `socle-formats-livrables`. La version client part **« à valider avant
envoi »** ; je ne l'envoie pas moi-même.

## Garde-fous

- **0 invention.** Ce qui n'a pas été dit ne s'écrit pas dans la colonne « Dit », même si
  c'est évident. Une déduction reste étiquetée déduction pour toujours.
- **Ne jamais envoyer la version interne** au client.
- **Cloisonnement.** Un compte rendu ne sert qu'à l'entreprise concernée, et ce qui a été
  appris d'un autre client n'y figure pas.
- **Aucune action sortante sans validation.**
