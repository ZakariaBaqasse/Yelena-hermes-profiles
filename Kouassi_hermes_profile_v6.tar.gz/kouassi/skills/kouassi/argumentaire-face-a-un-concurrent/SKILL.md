---
id: Y0499
name: argumentaire-face-a-un-concurrent
description: >
  Prépare la réponse à « pourquoi vous plutôt qu'eux », concurrent nommé, sur les faits
  publics et vérifiables uniquement. Produit une grille de comparaison, la question qui
  déplace le terrain, et la liste de ce qu'il ne faut jamais dire. À charger avant un
  rendez-vous en concurrence, une réponse à appel d'offres, ou quand un prospect cite un nom.
bucket: A
tags: [Sales]
version: 1
maj: 2026-09-06
---

# Répondre sur un concurrent nommé

## La règle qui commande tout

**On ne dit jamais de mal d'un concurrent.** Pas par courtoisie : parce que ça ne marche
pas. Le prospect qui l'a présélectionné a fait un choix, et l'attaquer revient à lui dire
qu'il a mal choisi. Il défendra son choix, et l'échange est perdu.

La bonne réponse ne compare pas deux entreprises. Elle **déplace la question** vers ce que
le client cherche réellement, puis montre où chacun est bon.

## Ce que je demande

1. **Le nom du concurrent**, tel que le prospect l'a prononcé.
2. **Ce que le prospect en a dit** — ce qui l'attire chez lui est l'information la plus
   utile de tout l'exercice.
3. **Ce que le client vend**, et son argument différenciant s'il existe (`usp-creator`).

## La méthode

### 1. Ne travailler que sur des faits publics et vérifiables

Ce qui est utilisable : le site du concurrent, ses tarifs publiés, ses offres, ses délais
annoncés, ses zones desservies, ses références citées publiquement, sa taille si elle est
publique.

Ce qui ne l'est pas, et ne doit jamais entrer dans un argumentaire : une rumeur, un
salarié qui a parlé, un client mécontent rapporté de seconde main, un chiffre financier
non publié, une accusation. Un fait invérifiable qui revient aux oreilles du concurrent
devient un problème juridique, et il revient toujours.

Si je n'ai pas lu la source, je ne l'écris pas. Une case vide est meilleure qu'une
affirmation invérifiable.

### 2. La grille, sur les critères du client

Trois à cinq lignes, jamais plus. Les critères sont ceux que le prospect a cités, pas
ceux qui nous arrangent. Une grille construite sur nos points forts se voit immédiatement
et détruit la crédibilité du reste.

| Critère cité par le prospect | Eux | Nous | Source |
|---|---|---|---|

La colonne **Source** est obligatoire. Une ligne sans source ne sort pas.

### 3. Écrire honnêtement là où ils sont meilleurs

**Au moins une ligne doit leur être favorable.** C'est ce qui rend le reste crédible, et
c'est aussi vrai : un concurrent présélectionné fait forcément quelque chose de bien.

La phrase à savoir dire : « sur ce point, ils sont plus forts que nous, et si c'est votre
critère principal, allez-y. » Elle coûte peu d'affaires et en gagne beaucoup, parce
qu'elle est la seule chose qu'aucun vendeur ne dit jamais.

### 4. La question qui déplace le terrain

Une comparaison frontale se joue sur le prix, et se perd. La sortie est une question qui
ramène le prospect à son problème :

- « Qu'est-ce qui vous ferait dire, dans six mois, que vous avez bien choisi ? »
- « Sur les trois derniers projets de ce type, qu'est-ce qui a mal tourné ? »

La réponse rouvre le terrain sur des critères réels, où la comparaison redevient utile.

### 5. La liste de ce qu'on ne dit pas

Elle se rédige explicitement, et elle est aussi importante que l'argumentaire. Ce qui y
figure toujours : toute affirmation sur leur santé financière, sur leurs clients perdus,
sur la qualité de leurs équipes, sur leur avenir. Et toute phrase commençant par « eux,
ils ne savent pas ».

## Ancrage local

Voir `memory/reference/vendre-en-cote-d-ivoire.md`. Sur un marché de cette taille, les
équipes se croisent, se connaissent et changent d'employeur. Ce qui est dit d'un concurrent
lui parvient, souvent la même semaine. C'est une raison pratique, pas morale, de ne rien
écrire qu'on ne dirait pas devant lui.

## Format de sortie

La grille sourcée, la ligne où ils sont meilleurs, la question de déplacement, la liste de
ce qu'on ne dit pas. Une page. Formats de rendu : `socle-formats-livrables`.

## Garde-fous

- **0 invention, 0 rumeur.** Uniquement des faits publics dont j'ai lu la source, et la
  source est citée dans la grille.
- **Aucune affirmation dépréciative** sur une personne, une équipe ou la solidité d'une
  entreprise.
- **Cloisonnement.** Si le concurrent est aussi un client de la maison, rien de ce qu'on
  sait de lui par ce biais n'entre ici. Cette compétence ne travaille que sur le public.
- **Produis, ne bloque pas.** Un critère sans source se marque `[non vérifié]` et ne sert
  pas d'argument.
