---
id: Y0027
name: 04-customer-health
description: "Score de santé 0-100 par client (usage, paiements, tickets, NPS) pondéré par segment (B2B premium/SMB/SaaS/B2C app), flag des at-risk avant churn + playbook (upsell/nurture/save/let-go) + alertes agrégées par startup. Observe et recommande, n'agit pas sur le client."
bucket: D
tags: [Customer Success]
version: 1
maj: 2026-08-26
---

# 04_Customer_Health

## Ce qu'il faut avoir sous la main
- **startup** concernée
- **segment** : `b2b_premium` · `b2b_smb` · `b2c_app` · `b2b_saas` (sinon je l'infère depuis la fiche startup)
- **window** : période d'observation (défaut 30 derniers jours)
- (optionnel) **comparison** : période précédente pour le delta


**Ce qu'elle suppose comme accès** : Espaces documentaires par entité, Registre du portefeuille, Sources de données client. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Pour chaque client actif, pull 5 signaux :
| Signal | Source | Mesure |
|---|---|---|
| **usage** | analytics | login_count, transactions, sessions sur la window |
| **paiements** | revenue / facturation / pipeline | factures payées vs en retard, montant cumulé |
| **support** | base support / email | tickets + sentiment moyen (historique de triage) |
| **nps** | enquête NPS | dernière réponse + score |
| **contrat** | pipeline | contract_value, anniversaire renewal, durée |
`[connecteur à brancher : sources de données client, analytics, facturation, support, NPS]`. Signal manquant → l'utiliser comme 0 pondéré (pas NULL) + flag `data_gap: true`.

### Étape 2 : Score par segment (0-100)

- **b2b_premium** : `0.35×paiements + 0.25×usage + 0.20×support + 0.15×nps + 0.05×renewal_proximity`
- **b2b_smb** : `0.40×usage + 0.30×paiements + 0.20×support + 0.10×nps`
- **b2c_app** : `0.40×usage + 0.25×nps + 0.20×support + 0.15×paiements` (NPS pondéré fort car LTV/user faible)
- **b2b_saas** : `0.35×usage + 0.30×paiements + 0.20×support + 0.15×nps`
(`paiements` = % factures payées à temps ; `usage` = transactions vs baseline segment mobile 90j.)

### Étape 3 : Buckets de santé

- **healthy (80-100)** : vert · upsell ou case study
- **stable (60-79)** : jaune-vert · nurture
- **at-risk (40-59)** : jaune-rouge · save proactif (handoff Churn_Recovery)
- **churn-imminent (0-39)** : rouge · escalade CSM/founder
- **already-churned** : pas d'activité > 60j ET aucun paiement window.

### Étape 4 : Playbook par bucket

- **healthy** : `upsell` (usage > 130% baseline + pas premium) · `case_study` (NPS promoteur → skill NPS_Analyzer) · `referral_ask` (promoteur + usage stable 90j).
- **stable** : `nurture` (check-in trimestriel, roadmap, sondage features). Pas d'urgence.
- **at-risk** : `save_proactive` (déclencher la séquence Churn_Recovery, J0 = appel CSM) + identifier la root cause (payment_late / usage_drop / support_friction / NPS_detractor).
- **churn-imminent** : `save_urgent` (escalade CSM + founder < 24h) + offre rétention pré-approuvée ; si LTV restant < cost-of-save → `let_go`.
- **let-go** : documenter la root cause, exit interview pour 50% des cas, pas de séquence agressive (préserver la marque).

### Étape 5 : Alertes agrégées startup

`health_avg` (moyenne pondérée par contract_value) · `delta_health` (si comparison) · `churn_rate_30j` · `top_at_risk_revenue_concentration` (top 5 at-risk = revenue at-risk) · `save_budget_recommended` (10% du contract_value des at-risk).

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Pas de score sans 3 signaux minimum** : sinon « données insuffisantes, recommander instrumentation » + lister ce qui manque.
- **Pondération par segment toujours** : jamais une formule unique.
- **LTV vs cost-of-save** : churn-imminent → si LTV restant < 2× cost-of-save → `let_go`.
- **Pas d'invention** : signal manquant → `data_gap`, ne pas extrapoler.
- **Pas d'action client direct** : observer et recommander ; l'action passe par la skill Churn_Recovery ou un CSM humain.
- **Confidentialité** : ne JAMAIS exporter de PII client hors de la startup (pas de cross-portfolio leak).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Output (JSON strict)

```json
{"startup":"le programme","segment":"b2b_smb","window":"2026-04-21..2026-05-21",
 "summary":{"total_clients":142,"health_avg":67,"delta_health":"+3",
   "by_bucket":{"healthy":38,"stable":62,"at-risk":27,"churn-imminent":11,"already-churned":4},
   "revenue_at_risk":"2.4M XOF","save_budget_recommended":"240k XOF"},
 "alerts":["11 clients churn-imminent, escalade CSM","Top concentration : 3 merchants = 60% revenue at-risk"],
 "clients_at_risk":[{"client_id":"JK-0421","name":"Boutique X","bucket":"at-risk","score":52,
   "root_cause":"usage_drop","playbook":"save_proactive","recommended_owner":"csm","handoff_to":"skill Churn_Recovery"}],
 "clients_upsell_ready":[{"client_id":"JK-0102","name":"Grossiste Y","score":88,"upsell_proposal":"Premium tier"}],
 "next_step":"Lancer Churn_Recovery sur les 11 churn-imminent + 5 at-risk top revenue"}
```
Si un rendu visuel est activé → pyramide buckets + courbe health_avg + scatter usage × paiements.
