---
id: Y0580
name: pitch-commercial-audio
description: Fabrique le pitch commercial d'une entreprise en note vocale de 60 à 120 secondes, écoutable directement dans le fil. À charger dès qu'on demande un pitch, un elevator pitch, un argumentaire d'ouverture, « ce qu'on dit au client en une minute », ou la version audio d'un pitch déjà écrit. Porte la structure du pitch, la règle des sources, et la chaîne de fabrication audio.
version: 1
maj: 2026-09-10
---

# Le pitch commercial en note vocale

Un pitch écrit se lit et se corrige. Un pitch audio s'écoute, et c'est le seul format qui
montre **le rythme réel** : là où le commercial va trébucher, là où la phrase est trop
longue pour être dite, là où il manque une respiration. C'est pour ça qu'on le rend en
audio et pas en note.

Deux usages, et ils ne demandent pas la même chose :
- **Le commercial l'écoute pour l'apprendre**, avant une tournée ou un salon. Il veut
  entendre le débit.
- **Le client l'écoute**, en note vocale WhatsApp ou en ouverture de rendez-vous. Là, la
  règle des validations s'applique : ça sort de l'entreprise, donc **rien ne part sans
  accord**.

## La structure, six blocs, 150 à 250 mots

150 mots ≈ 60 s, 250 mots ≈ 100 s. Au-delà de 300 mots, ce n'est plus un pitch, c'est une
présentation, et personne ne l'écoute jusqu'au bout.

1. **Qui parle**, une phrase : prénom, poste, maison.
2. **Le problème du client**, dans SES mots, pas dans le vocabulaire de la maison. C'est le
   bloc qui décide si l'écoute continue.
3. **Ce que fait la maison**, en une phrase qu'un enfant comprend. Pas de nom de
   technologie, pas d'acronyme.
4. **La preuve** : un client nommé, un chiffre sourcé, une référence publique. Rien de
   fabriqué, rien d'arrondi. S'il n'y a aucune preuve disponible, le bloc **saute** — un
   pitch sans preuve vaut mieux qu'un pitch avec une preuve inventée.
5. **Ce qui distingue**, une phrase, et de préférence un fait vérifiable plutôt qu'un
   adjectif. « Opéré depuis Abidjan » vaut mieux que « leader ».
6. **La demande**, une seule, précise et petite : un rendez-vous de vingt minutes, une
   date. Pas « qu'en pensez-vous ».

## Les règles qui ne bougent pas

- **Tout ce qui se dit vient d'une source ouverte** : le site de la maison lu ce jour-là,
  sa mémoire d'entreprise datée, ou ce que l'interlocuteur vient d'écrire. Un pitch est le
  document où l'invention passe le plus facilement, parce qu'il est court et qu'il sonne
  bien.
- **Un engagement de délai ou de résultat ne se dit pas**, même quand la maison l'affiche
  ailleurs. « Des résultats dès la première semaine » dans une voix qui part chez un client
  devient une promesse opposable.
- **Un prix ne se dit que s'il est public**, et alors on dit qu'il est public. Le plancher,
  les remises, les conditions de règlement ne se prononcent jamais.
- **Ce qui manque s'écrit dans le texte**, pas dans l'audio : on ne fait pas dire
  `⟦à renseigner⟧` à une voix. La note vocale se fabrique sur la version dont tous les
  trous sont comblés ; tant qu'il en reste un, on livre le **texte** troué et on demande.

## Fabriquer

Le texte d'abord, dans un fichier, et on le compte :

    wc -w pitch.txt      # cible 150-250

Puis la relecture anti-tics, obligatoire, un texte qui se dit à voix haute pardonne encore
moins les tics d'écriture machine :

    python3 outils/relire-sans-tics.py pitch.txt

Puis la voix :

    python3 integrations/openai-tts/dire.py \
      --texte-fichier pitch.txt \
      --sortie deliverables/<projet>/pitch-<slug>_v1.ogg \
      --voix onyx

Voix disponibles : `onyx` et `ash` (masculines, graves), `echo` et `fable` (masculines,
plus claires), `nova`, `coral`, `sage`, `shimmer`, `ballad`, `alloy`. `--consigne` pilote
l'accent et le débit — le défaut est une voix masculine posée, français d'Afrique de
l'Ouest. **La voix retenue par la maison se demande une fois et s'écrit dans la mémoire**,
sinon chaque pitch sort avec une voix différente et rien ne s'installe.

Le rendu part en `.ogg` Opus, que Telegram et WhatsApp lisent comme une vraie note vocale
(le fil affiche l'onde, pas une pièce jointe à télécharger).

## Écouter avant de livrer

Trois défauts s'entendent et ne se voient pas. Ils se corrigent dans le TEXTE, jamais en
changeant de voix :

- **Une phrase trop longue** : la voix la dit d'un souffle et le sens se perd. On coupe.
- **Un sigle ou un montant** : la synthèse les prononce mal. On écrit « F CFA », « trois
  cent mille », « U E M O A » dans le texte lu.
- **Une fin en suspens** : la demande doit tomber nette. Une question ouverte à la fin
  sonne hésitante.

## Livrer

Les deux ensemble, dans cet ordre : **la note vocale d'abord** (elle s'écoute en trois
secondes), le texte juste après (il se corrige). Le texte compte autant que l'audio : c'est
lui qu'on modifiera, et une note vocale seule n'est pas révisable.

Les deux vont dans `deliverables/<projet>/`, même slug, même numéro de version :
`pitch-<slug>_v1.ogg` et `pitch-<slug>_v1.md`. Une correction produit un `_v2` des deux.

Et si le pitch est destiné à un client, la phrase qui accompagne la livraison le dit :
c'est un brouillon, il attend un accord, il ne part pas tout seul.
