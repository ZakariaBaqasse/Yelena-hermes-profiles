---
name: devis-proposal-generator
description: >
  Produit un devis chiffré ou une proposition commerciale à partir du besoin du client et de
  sa grille tarifaire, avec un périmètre exclu écrit noir sur blanc, une date de validité et
  des conditions de paiement. Aucun prix n'est inventé : ce qui manque sort en `[à confirmer]`.
  À charger dès qu'un client demande un devis, une proposition, une offre chiffrée ou une
  réponse à une demande de prix.
bucket: A
tags: [Sales]
version: 1
maj: 2026-09-06
---

# Devis et propositions commerciales

## Ce que produit cette compétence

Un document chiffré, prêt à relire par un humain avant envoi. Deux formats selon l'enjeu :

- **Le devis d'une page** — lignes, quantités, prix unitaires, total, validité, conditions.
  C'est ce qu'on envoie dans neuf cas sur dix, et ça suffit.
- **La proposition détaillée** — le devis, précédé de la compréhension du besoin, de la
  solution et du périmètre. Elle se justifie quand plusieurs personnes vont la lire sans
  avoir assisté au rendez-vous.

Ce n'est pas un contrat. Un devis signé engage, mais il ne remplace pas les conditions
générales ni un contrat de prestation : `edition-contrat` prend le relais.

## Ce que je demande

**Indispensable**, et je ne peux pas le supposer :

1. **La grille tarifaire** du client, ou à défaut les prix déjà pratiqués sur des affaires
   comparables. Sans elle, je ne chiffre pas : j'écris la structure et je laisse les
   montants en `[à confirmer]`.
2. **Le besoin**, tel qu'il a été exprimé. Les mots du client, pas une reformulation
   commerciale.

**Utile**, et je fais sans si nécessaire : nom et forme juridique du destinataire, échéance
souhaitée, taux de taxe applicable, conditions de paiement habituelles, devise.

## La méthode

### 1. Reformuler le besoin avant de chiffrer

Trois à cinq lignes qui reprennent la demande dans les termes du client. Ça n'est pas de la
politesse : c'est le seul endroit du document où une incompréhension se voit avant qu'elle
coûte de l'argent. Un client qui corrige cette section évite un devis refait.

### 2. Écrire le périmètre exclu, toujours

**C'est la section la plus importante du document, et c'est celle que tout le monde saute.**
Un devis qui ne dit pas ce qu'il ne couvre pas se fait élargir gratuitement au fil du
chantier, ligne par ligne, sans qu'aucune de ces lignes ne se discute jamais.

Deux blocs, côte à côte :

- **Compris dans le prix** — la liste précise, avec les quantités. « Trois séances »,
  pas « des séances ».
- **Non compris** — ce qui sera facturé en plus, et sur quelle base. Les frais de
  déplacement, les révisions au-delà d'un nombre donné, l'hébergement, la formation, la
  reprise d'un travail existant, l'attente due au client.

Une hypothèse dont dépend le prix se pose ici : « le prix suppose que les contenus sont
fournis avant le démarrage ». C'est ce qui permet de renégocier sans conflit quand elle
tombe.

### 3. Chiffrer sur la grille, jamais de mémoire

Chaque ligne : désignation, quantité, unité, prix unitaire, sous-total. Puis le total, la
taxe si elle s'applique, le total à payer.

- **Un prix qui n'est pas dans la grille sort en `[à confirmer]`.** Un montant plausible
  avancé pour ne pas laisser un blanc devient un engagement.
- **Le taux de taxe se reprend des factures existantes du client**, il ne se suppose pas.
- **La devise s'écrit**, et pour la Côte d'Ivoire c'est le franc CFA. Format `1 250 000 F`.
- **Aucune remise sans contrepartie ferme, mesurable et écrite** : un volume, une durée,
  une avance, une référence citable. Et pas accordée en séance, car l'octroi n'appartient pas
  à celui qui négocie. `negociation-et-remise` traite le cas en détail.

### 4. Trois clauses qui évitent trois litiges

- **La date de validité.** Sans elle, un devis de mars se signe en novembre au prix de
  mars. Trente jours par défaut, et je le dis quand je l'applique par défaut.
- **Les conditions de paiement.** Quand, en combien de fois, à quel événement. Une avance
  au démarrage est la norme et se demande sans s'excuser ; c'est aussi la meilleure
  protection contre l'impayé, qui est le premier problème de trésorerie des PME ivoiriennes.
- **Le délai, et ce qui le fait courir.** « Trois semaines » ne veut rien dire. « Trois
  semaines à compter de la réception de l'avance et des contenus » veut dire quelque chose.

### 5. Une seule prochaine étape

Le document se termine sur une action unique et datée : « retour souhaité avant le
<date> », « signature à retourner à <adresse> ». Deux options de fin, c'est zéro décision.

## Ancrage local

Voir `memory/reference/vendre-en-cote-d-ivoire.md`. Deux points y changent la forme du devis :

- Il sera très souvent **lu sur un téléphone, dans WhatsApp**. Le PDF doit rester lisible
  sans zoom : peu de colonnes, des montants alignés, un total qui saute aux yeux.
- L'**encaissement** se prépare au moment du devis, pas après. Si le client encaisse par
  lien de paiement, la contrainte se vérifie avant de la promettre (voir l'intégration
  `[entreprise cliente]`), et jamais en appelant l'API au hasard : chez ce fournisseur, un appel de
  production déplace de l'argent réel.

## Format de sortie

Le devis en document présentable, plus le lien de la page partageable si le client le
souhaite. Les formats de rendu obligatoires sont ceux de `socle-formats-livrables` :
un Google Doc et son PDF, ou un tableur et son export. Jamais un fichier brut dans un fil
de discussion.

Le document part toujours **« à valider avant envoi »**. Je ne l'envoie pas moi-même.

## Garde-fous

- **0 invention.** Aucun chiffre, aucun fait inventé. Ce qui manque se demande ou se marque
  `[à confirmer]`. Une case vide vaut mieux qu'un chiffre faux.
- **0 prix qui ne vient pas du client.** Y compris un prix « de marché » : il n'engage pas
  le même montant que le sien.
- **Aucune action sortante sans validation.** Je prépare l'envoi, je m'arrête pour un accord
  humain explicite.
- **Cloisonnement.** La grille tarifaire d'une entreprise ne sort jamais vers une autre
  traitée dans la même conversation, et un prix consenti à un client ne se cite pas à un autre.
- **Produis, ne bloque pas.** Avec ce que j'ai, je produis en étiquetant mes hypothèses
  (`[hypothèse : …]`).

## Cas limites

- **Pas de grille tarifaire** : je produis la structure complète, montants en `[à confirmer]`.
  Le client remplit, le document est prêt. Je n'invente pas un ordre de grandeur.
- **Le client demande un prix « à la louche » en séance** : je donne une fourchette seulement
  si des affaires comparables la fondent, et je la nomme fourchette indicative non engageante.
  Sinon je dis que je ne peux pas, et je donne une date de retour.
- **Demande d'un concurrent moins cher** : ce n'est pas une question de devis mais d'objection,
  voir `sales-objection-handler`. Le devis ne se réécrit pas pour s'aligner.
- **Sources contradictoires sur un prix** : j'expose les deux et je demande l'arbitrage.
