---
id: Y0039
name: 08-lead-lifecycle
description: "Score 0-100 les leads engagés et applique un stop-loss (archive/nurture) sur les leads dead. Prépare les MAJ pipeline + un digest d'alertes ; rien n'est envoyé sans validation."
bucket: D
tags: [Sales]
version: 1
maj: 2026-08-26
---

# 08_Lead_Lifecycle

## Ce qu'il faut avoir sous la main
- **startup** : un onglet ou `all` (défaut `all`)
- **mode** : `score_only` | `stoploss_only` | `both` (défaut `both`)

Je te rends les scores, les décisions de stop-loss et un digest d'alertes. Les écritures pipeline et les alertes sont **préparées et présentées** ; je n'envoie/n'écris rien sans ton « ok ».


**Ce qu'elle suppose comme accès** : Pipeline / feuille SDR, Registre du portefeuille, Écriture pipeline, Envoi email d'alerte. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. Lire les onglets startup actifs, puis les leads (lignes 14:300 par onglet).
2. Calculer le score + temperature → préparer le PATCH AE/AF/AG.
3. Appliquer les règles stop-loss → préparer le PATCH I/AH/AI.
4. **Présenter** les PATCHes en batch ; les appliquer **après validation** (batch_update).
5. **Alertes** : compter les nouveaux hot (score → ≥ 75), les archivés (log seul), les `escalation_required`. Constituer un digest :
```
🔥 5 nouveaux hot leads le programme : Aminata Diallo (CFO BankX), 82 · …
⚠️ 2 leads escalation_required : …
```
Le digest est **présenté pour validation** ; aucune alerte email n'est envoyée sans « ok, envoie » + destinataires confirmés. `[connecteur à brancher : envoi email d'alerte]`.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Idempotent** : 2 passages ne changent rien si l'état est stable ; `paused`/`campaign_stopped` toujours skippés.
- **Pas de delete** : on `archive`, jamais de suppression de ligne.
- **Pas de scoring sans engagement** : un lead `ready` sans signal sortant garde score 0.
- **Colonnes requises** : `engagement_count`, `AE` score, `AF` temperature, `AG` last_scored_at, `AH` archive_reason, `AI` archived_at.
- **Logs** : toujours produire le JSON, même si rien fait.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### PARTIE 1 : Scoring post-engagement

Pour chaque lead `status ∈ {connected, sent_J3, replied, engaging, booked}`. **Exclure** : `paused`, `campaign_stopped`, `lost_blocked`, `lost_unfit`, `archived`.

| Critère | Points |
|---|---|
| A répondu (replied/engaging) | +25 |
| Meeting booké (booked) | +35 |
| Réponse < 24h | +15 |
| Réponse 24-72h | +5 |
| Sentiment positif | +20 |
| signal_achat actif (ICP > 70 ou flag = 1) | +20 |
| engagement_count ≥ 3 | +10 |
| Sentiment négatif / objection | −20 |
| Aucune réponse depuis > 7j | −15 |

Plafond 100, plancher 0.

**Catégorisation** : 🔥 hot ≥ 75 (priorité outbound + **alerte** si nouveau hot) · 🟠 warm 50-74 · 🟡 cool 25-49 · ❄️ cold < 25 (candidat stop-loss).

**Colonnes à mettre à jour** : `score` (AE), `temperature` (AF), `last_scored_at` (AG).

### PARTIE 2 : Stop-loss

Appliquer dans l'ordre (premier match gagne) :
1. `paused`/`campaign_stopped` → skip.
2. `lost_blocked` → skip. 3. `lost_unfit` → skip.
4. `cold` ET `engagement_count = 0` ET `last_J7_at > 14j` → `archived` (`cold_no_engagement`).
5. `sent_J7` ET `last_J7_at > 14j` ET pas de booking → `archived` (`no_response_14d`).
6. `nurture` ET `next_touch_at > 90j` → garder + `parked_long`.
7. `engaging` ET `engagement_count ≥ 5` ET pas de booking → `escalation_required` + **alerte**.
8. `booked` mais `meeting_at` passé > 7j sans `closed_won/lost` → `meeting_no_outcome` + **alerte** fondateur.

**Colonnes à mettre à jour** : `archive_reason` (AH), `archived_at` (AI), `status` (I).

### Output final

```json
{"run_at":"ISO","startups_processed":["le programme","l'entreprise"],"leads_scored":124,"new_hot":5,"leads_archived":12,"escalations":2,"writes_applied":false,"alerts_sent":false}
```
