---
id: Y0031
name: 06-churn-recovery
description: "Génère une séquence de save personnalisée quand un client est flaggé at-risk/churn-imminent : calcule le LTV restant vs cost-of-save (ratio > 5 = priorité haute, < 1 = let_go), 3-7 touchpoints sur 14j + budget/approval. Prépare la séquence ; le CSM l'exécute après validation."
bucket: D
tags: [Customer Success]
version: 1
maj: 2026-08-26
---

# 06_Churn_Recovery

## Ce qu'il faut avoir sous la main
- **startup** + **client** (name, segment, contract_value, tenure, bucket)
- **root_cause** : `usage_drop` · `payment_late` · `support_friction` · `nps_detractor` · `competitor_switch` · `pricing_objection`
- **source du flag** : Customer_Health · NPS_Analyzer · Support_Triage (signal manuel)


**Ce qu'elle suppose comme accès** : Espaces documentaires par entité, Registre du portefeuille, Messagerie multicanale. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
**LTV restant** : b2b_premium/saas `(contract_value×12)×proba_renewal` (0.4-0.9 selon health+tenure) · b2b_smb `(avg_monthly×12)` · b2c_app `(avg_monthly×24)`.
**Cost-of-save** par root_cause : usage_drop ~1 appel + 1 formation · payment_late = workout + éventuel discount 10-20% · support_friction = escalade tech + geste · nps_detractor = appel founder/C-level (+ parfois discount) · competitor_switch = discount 20-40% + lock-in · pricing_objection = downgrade OU annuel -15-20%.
**Décision** :
```
ratio = LTV_restant / cost_of_save
> 5   → save (priorité haute) · 2-5 → save (normale) · 1-2 → save soft · < 1 → let_go
```
Afficher explicitement ce calcul dans l'output.

### Étape 2 : Séquence recovery (3-7 touchpoints)

**Base : 4 touchpoints / 14j.**
- **J0, outreach personnel** : appel (premium) / WhatsApp (smb, b2c) / email+LinkedIn (saas). Owner CSM (défaut) · founder (premium + ratio>5) · CEO (concentration revenue >10%). Script : reconnaître le problème, ne pas vendre, comprendre → booker 20-30 min.
- **J3, réponse au feedback** : email écrit, « voici ce que tu m'as dit, ce qu'on va faire, les délais ».
- **J7, geste concret** : action visible (fix déployée / geste / invitation), pas une promesse.
- **J14, check-in santé** : appel/WhatsApp court → confirmer save ou détecter persistance → let_go.

**Variations** : `payment_late` (J0 appel finance ≠ CSM, J3 échéancier signé, J7 reprise ou escalade, J14 santé) · `nps_detractor` (J0 founder, J3 roadmap update, J7 beta/geste, J14 nouveau NPS) · `competitor_switch` (J0 meeting CEO, J3 counter-offer chiffrée, J7 lock-in/contrat révisé, J14 confirmation ou acceptation du churn).

### Étape 3 : Génération de contenu (drafts)

Par touchpoint : `channel` · `subject`/`opening_line` · `body` (50-200 mots, ton du brand kit) · `cta` · `variables_to_fill` (`{prenom}`, `{nb_mois_client}`, `{produit}`, `{pain_point}`) · `personalization_notes`.

### Étape 4 : Budget & approval

`time_cost` (heures × taux) · `monetary_cost` (discount/refund/geste) · `total_save_budget` · `approval_required` : csm (< 100 USD) · head_of_cs (100-500) · founder (> 500 ou > 10% MRR client). Si `total_save_budget > LTV_restant × 0.3` → flag `over_budget` + alternative plus light.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Toujours calculer LTV vs cost-of-save** explicitement, pas de recovery aveugle.
- **Pas d'agressivité** : max 4-7 touches/14j, après c'est let_go.
- **Owner adapté** au segment et au ratio.
- **Ton du brand kit** (jamais générique corporate).
- **Geste concret > promesse** à J7.
- **Documenter même les let_go** (50% des exit interviews révèlent des root causes systémiques).
- **Pas de discount ni d'envoi sans validation** : la séquence est préparée ; les messages partent après validation humaine (`sent: false` par défaut), les gestes monétaires attendent l'approval level.
- **Confidentialité** : ne JAMAIS partager les conditions de save d'un client à un autre (leak prix).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Output (JSON strict)

```json
{"startup":"le programme","client":{"id":"CL-0421","name":"Boutique X","segment":"b2b_smb","tenure_months":8,"contract_value_monthly":"45000 XOF"},
 "diagnosis":{"bucket":"at-risk","root_cause":"usage_drop","trigger_source":"Customer_Health"},
 "ltv_calculation":{"ltv_restant":"540000 XOF","cost_of_save_attendu":"75000 XOF","ratio":7.2,"decision":"save_priority_haute"},
 "sequence":[{"day":0,"channel":"wa_personal","owner":"csm","opening_line":"Bonjour {prenom}...","body":"...","cta":"booker 20min","variables_to_fill":["prenom","boutique_name"],"personalization_notes":"Mentionner sa dernière transaction réussie"}],
 "budget":{"time_cost_estimate":"30000 XOF","monetary_cost_estimate":"0 XOF","total_save_budget":"30000 XOF","approval_required":"csm"},
 "kpis_to_track":["client_responded_j0","call_booked_j3","transactions_resumed_j14","nps_post_recovery_j30"],
 "fallback_if_fail":"Pas de réponse J14 → let_go + exit interview",
 "next_step":"Le CSM valide puis lance la séquence","sent":false}
```
