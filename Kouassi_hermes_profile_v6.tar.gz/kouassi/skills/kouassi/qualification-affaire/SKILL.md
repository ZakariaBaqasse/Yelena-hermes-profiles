---
id: Y0589
name: qualification-affaire
description: >
  Décide si une affaire mérite du temps, avant d'en dépenser. Sept questions, une note, et
  trois issues seulement : on avance, on met en attente avec une date, on abandonne et on le
  dit. À charger à l'arrivée d'une demande entrante, avant de produire un devis, ou quand un
  pipeline est encombré d'affaires qui n'avancent plus.
bucket: A
tags: [Sales]
version: 1
maj: 2026-09-06
---

# Qualifier une affaire

## Pourquoi cette compétence existe

Un commercial ne perd pas ses affaires : il perd son temps sur celles qui n'allaient nulle
part. Un pipeline de quarante lignes dont trente sont mortes ne dit plus rien, ne se
priorise plus, et fabrique des prévisions fausses qui se répercutent sur la trésorerie.

Qualifier, ce n'est pas trier les bons clients des mauvais. C'est répondre à une seule
question : **est-ce que cette affaire peut se conclure, et quand ?**

## Ce que je demande

Ce qui s'est dit lors du dernier échange, et l'historique s'il existe. Rien d'autre. La
qualification se fait avec ce qu'on a ; un trou dans les réponses **est** le résultat.

## Les sept questions

Je réponds à chacune par ce que le client a réellement dit, ou par **inconnu**. Un inconnu
n'est pas un échec : c'est ce qu'il faut aller chercher au prochain contact.

| # | Question | Ce qu'une bonne réponse ressemble |
|---|---|---|
| 1 | **Quel problème**, dans ses mots ? | Une phrase du client, pas une catégorie de produit |
| 2 | **Que coûte ce problème** aujourd'hui ? | Un chiffre, un délai, un client perdu. Sans coût, il n'y a pas d'achat |
| 3 | **Qui décide** vraiment, et qui signe ? | Un nom et une fonction. « La direction » est un inconnu |
| 4 | **Quel budget**, et déjà voté ou à créer ? | Un budget à créer double le délai, au minimum |
| 5 | **Quelle échéance**, et pourquoi celle-là ? | Une échéance sans cause est une échéance qui glisse |
| 6 | **Quelles alternatives** examine-t-il ? | Y compris ne rien faire, qui est presque toujours la première |
| 7 | **Qu'est-ce qui pourrait faire échouer** ce projet chez lui ? | La question qu'on n'ose pas poser, et la plus rentable |

## Lire le résultat

Ce qui compte n'est pas le nombre de réponses, c'est lesquelles manquent.

- **Question 2 inconnue** — le client n'a pas chiffré son problème. L'affaire n'est pas
  qualifiée, elle est intéressée. Prochaine action : faire chiffrer le coût du problème,
  pas envoyer un devis.
- **Question 3 inconnue** — on ne parle pas au décideur. C'est le premier motif d'affaires
  qui s'éteignent en silence. Prochaine action : demander qui d'autre doit être associé, et
  l'obtenir. Un devis envoyé à quelqu'un qui ne signe pas ne revient jamais.
- **Question 5 inconnue** — rien n'oblige le client à décider. L'affaire est réelle mais
  sans date ; elle va en attente, avec une date de réexamen, et elle sort des prévisions.
- **Questions 4 et 6 inconnues ensemble** — on est en train de servir de devis de
  comparaison. Ça arrive, et il vaut mieux le savoir tôt.

## Les trois issues, et il n'y en a pas de quatrième

1. **On avance.** L'affaire a un coût du problème, un décideur identifié et une échéance
   causée. Elle reste au pipeline avec une prochaine action datée.
2. **En attente, avec une date.** Quelque chose de connu manque et ne dépend pas de nous :
   un budget de l'exercice suivant, un arbitrage interne. On note la date de réexamen, et
   on sort l'affaire des prévisions du trimestre. `sequences-de-relance` prend le relais.
3. **On abandonne, et on le dit.** Trois contacts sans réponse, ou un besoin qu'on ne sait
   pas servir. On envoie un message court et sans reproche qui referme proprement, parce
   que sur un marché où tout le monde se connaît, la façon de renoncer se raconte.

**Ce qui est interdit : laisser une affaire au pipeline sans prochaine action datée.** C'est
ce qui fabrique les pipelines de quarante lignes.

## Ce que la qualification ne doit pas devenir

Un interrogatoire. Les sept questions ne se posent pas en rafale au premier rendez-vous :
elles se remplissent au fil des échanges. Un client qui répond à sept questions d'affilée
sans rien recevoir en retour ne rappelle pas.

Et elle ne se fait pas contre le client : la question 7 lui sert autant qu'à nous.

## Format de sortie

Le tableau des sept questions rempli, la note de ce qui manque, l'issue retenue et la
prochaine action datée. Une demi-page. Alimente directement `pipeline-sur-tableur` et
`compte-rendu-entretien-commercial`.

## Garde-fous

- **0 invention.** Une réponse que le client n'a pas donnée reste **inconnu**. Supposer un
  budget ou un décideur produit une prévision fausse, ce qui est pire qu'un pipeline vide.
- **Un abandon se dit.** On ne laisse pas une affaire mourir sans message.
- **Cloisonnement.** Ce qu'on apprend d'une affaire ne sert qu'à elle.
