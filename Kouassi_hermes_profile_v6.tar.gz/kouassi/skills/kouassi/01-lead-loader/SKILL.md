---
id: Y0011
name: 01-lead-loader
description: "Charge des leads bruts (CSV/JSON, ou output direct d'un pipeline de sourcing amont) dans le sheet SDR d'une entité : valide le fit ICP (titre/secteur/géo/taille, seuil ≥3/4 critères, assoupli si déjà scoré ≥70% en amont), déduplique contre les leads déjà présents, enrichit le signal d'achat manquant par une recherche web sourcée (moins de 60 jours, 1 phrase max), et n'écrit jamais un email non fourni ni n'écrase une ligne existante."
bucket: C
tags: [Sales]
version: 1
maj: 2026-08-26
---

# 01 Lead Loader

## Ce qu'il faut avoir sous la main
1. l'**entité/startup** cible (pour résoudre sa config ICP et son onglet leads) ;
2. les **leads bruts**, CSV ou JSON avec au minimum `nom, titre, boîte, pays, linkedin_url, email, whatsapp, signal_achat` (ou l'output direct d'un pipeline de sourcing amont, voir Add-on plus bas).


**Ce qu'elle suppose comme accès** : Sheet maître SDR, Registry, Lecture/écriture de tableurs, Recherche web, Skill à brancher : `00-sdr-router`, Skill à brancher : `b2b-prospection`, Skill à brancher : `account-intelligence`. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Lire `Startups_Config!A:B`. Trouver la ligne où col A = entité demandée → récupérer le **nom d'onglet** (col B).

Puis lire `{tab_name}!B3:B6` pour charger les critères ICP :

- **B3** = ICP titres
- **B4** = ICP secteurs
- **B5** = ICP géo
- **B6** = ICP taille

Si l'entité n'existe pas dans `Startups_Config` → stop et signaler à l'orchestrateur. **Ne jamais fabriquer** une config ICP par défaut.

### Étape 2 : Lire les leads existants (dédupe)

Lire `'{tab_name}'!A:F` pour récupérer les leads déjà présents (skip les rows de config + header, commencer à la row où le header `linkedin_url` se trouve).

Construire un set des `linkedin_url` et `email` existants → dédupliquer les nouveaux leads sur ce set avant toute validation ICP.

### Étape 3 : Validation ICP par lead

Pour chaque lead candidat (déjà déduppliqué à l'étape 2) :

- Titre vs ICP titres (B3) : match si un des titres ICP est contenu dans le titre du lead (insensible à la casse)
- Secteur vs ICP secteurs (B4) : match si overlap avec au moins 1 secteur
- Pays vs ICP géo (B5) : match si pays dans la liste géo
- Taille vs ICP taille (B6) : match si dans la fourchette cible
- Lead **validé** si ≥ 3/4 critères matchent, sinon → `rejected_icp_mismatch`
- Si `signal_achat` vide → enrichir via `[connecteur à brancher : recherche web]` (1 phrase max, source récente de moins de 60 jours) → incrémenter `enriched_signal_achat`. Si aucune source récente exploitable n'est trouvée, laisser `signal_achat` vide plutôt que de fabriquer une phrase.

Garder le compteur : `validés / rejetés_icp / dédupliqués / enriched_signal`.

### Étape 4 : Écriture sheet

Pour chaque lead validé, écrire une ligne dans l'onglet de l'entité, à la première row libre après les headers. Colonnes :

- A nom · B titre · C boîte · D pays · E linkedin_url · F email · G whatsapp · H signal_achat
- I `ready` (status)
- Z added_at = maintenant

Via `[connecteur à brancher : lecture/écriture de tableurs]`, avec `valueInputOption=USER_ENTERED` + `insertDataOption=INSERT_ROWS` (append). **Jamais** de réécriture d'une ligne existante, toujours append.

### Étape 5 : Rapport

Retour à l'orchestrateur (JSON strict) :

```json
{"startup": "{entité}", "tab_name": "{tab_name}", "input_count": 30, "validated": 28, "rejected_icp_mismatch": 1, "rejected_dedupe": 1, "enriched_signal_achat": 5, "ready_total_in_sheet": 41}
```

### Add-on : Input depuis un pipeline de sourcing amont

L'orchestrateur peut te passer **directement le retour d'un pipeline de sourcing amont** (type `b2b-prospection`, skill à brancher, CSV inline ou texte structuré) en plus du mode « CSV/JSON manuel ».

### Détection du mode

- Si l'input est un CSV avec 8+ colonnes → mode manuel (comme à l'étape 3)
- Si l'input mentionne « output pipeline de sourcing » ou une trentaine de profils ICP → mode pipeline
- Si l'input est un objet JSON `{"leads": [...]}` → mode API

### En mode pipeline (sourcing amont)

Le pipeline de sourcing amont retourne typiquement une trentaine de profils avec un scoring ICP contextuel déjà appliqué localement. Tu :

1. Acceptes les leads tels quels (le sourcing amont a déjà fait son scoring ICP)
2. Repasses ta validation de dédupe (sheet existant), c'est ton job principal, il reste entier
3. Peux légèrement adoucir la validation ICP : si le sourcing amont a scoré ≥ 70 %, fais-toi confiance et accepte
4. Status par défaut = `ready` (pas `rejected_icp_mismatch`) sauf si la dédupe échoue

### Marquer la source

Pour chaque lead écrit, renseigner la colonne `source` (col Y, à ajouter si absente) :

- `b2b-prospection` si vient du pipeline de sourcing amont
- `Manual_CSV` si import direct
- `account-intelligence` si vient du ciblage de compte (skill à brancher)

Ainsi la skill `09-sales-analytics` (à brancher) pourra découper les conversions par source plus tard.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Ne jamais écraser** une ligne existante (toujours append)
- **Ne jamais inventer** un email, si pas fourni et pas trouvable, laisser vide
- **Enrichissement signal_achat** : max 1 phrase de 100 caractères, source web récente (moins de 60 jours) ; à défaut, laisser vide
- **Format LinkedIn URL** : normaliser en `https://linkedin.com/in/{slug}` (retirer les paramètres de requête)
- **Startup-agnostic** : marche pour n'importe quelle entité tant qu'elle existe dans `Startups_Config`
- **Pas de fuite cross-entité** : les critères ICP (B3:B6) et le set de dédupe d'une entité ne sont jamais réutilisés pour une autre, chaque onglet est résolu et lu indépendamment, même dans un même échange traitant plusieurs entités

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution de l'entité : Sheet maître SDR

`[datasource à brancher : Sheet maître SDR, onglet Startups_Config (1 ligne par entité : nom en col A, nom de l'onglet leads en col B) + 1 onglet par entité (critères ICP en B3:B6, colonnes leads A→I, colonne Y source, colonne Z added_at)]`

Si ce sheet n'est pas directement accessible, un registre central peut le résoudre : `[datasource à brancher : Registry, mapping entité → identifiants de ses ressources opérationnelles, dont son Sheet maître SDR]` (voir la skill `00-sdr-router`, à brancher, pour la mécanique complète de résolution).

### Input

L'orchestrateur (`[skill à brancher : 00-sdr-router]`) te passe :

- **entité** : nom de l'entité cible (la même valeur que dans `Startups_Config` col A)
- **leads** : CSV ou JSON avec colonnes minimum `nom, titre, boîte, pays, linkedin_url, email, whatsapp, signal_achat`

### Configuration (déployée pour le client)

>
