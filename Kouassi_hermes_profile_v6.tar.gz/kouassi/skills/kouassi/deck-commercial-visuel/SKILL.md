---
id: Y0540
name: deck-commercial-visuel
description: >
  Fabrique un deck commercial de cinq à dix diapositives en paysage, habillé à la charte de
  l'entreprise concernée : logo, couleurs et polices relevés sur son site, plus ses
  références et ses témoignages publics. Sort en images, en PDF et en Google Slides
  modifiable. À charger dès qu'un persona, un argumentaire, une offre ou une présentation
  doit convaincre ou circuler.
bucket: B
tags: [Sales]
version: 1
maj: 2026-09-09
---

# Le deck commercial visuel

## Ce que produit cette compétence

Trois choses, dans cet ordre, et l'ordre compte :

1. **Les diapositives en images**, envoyées dans le fil. C'est ce que la personne voit en
   premier, sans cliquer et sans réseau qui réponde.
2. **Le PDF**, pour l'imprimer et le faire suivre.
3. **Le lien Google Slides**, pour qu'elle le modifie elle-même.

🚨 **L'aperçu passe devant le lien, toujours.** Décidé le 09/09/2026 après un lien remis
seul, que l'interlocuteur n'a pas pu ouvrir. Un lien demande de la confiance et une
connexion ; une image ne demande rien.

## 1. Relever la charte à la source

Le document parle d'une maison réelle, donc il porte ses couleurs. Rien ne se prend de
mémoire.

| Ce qu'il faut | Où ça se trouve |
|---|---|
| Le logo | Le site de la maison, en fichier, téléchargé et intégré au document |
| Les couleurs | Les **variables** de la feuille de style, pas les valeurs comptées à la main |
| Les polices | Les déclarations `font-family` du site |
| Le fond et l'encre | Les variables de fond de page et de couleur de texte |
| Le rayon des angles | La variable de rayon, souvent unique dans toute la charte |
| L'échelle typographique | Les variables de taille, qui donnent toute la hiérarchie |

🚨 **Compter les couleurs les plus fréquentes ne suffit pas, et c'est la faute qui s'est
vue.** Repérées ainsi, les couleurs de la maison ont servi d'accents sur un fond blanc, et
le retour est tombé : « je n'ai pas l'impression que ce soit vraiment dans leur branding ».
Il l'était à la lettre et pas du tout à l'œil, pour une seule raison : **le fond**. Un site
dont le fond est un calcaire, un crème ou un gris chaud n'a pas du tout la même présence
qu'une page blanche, et le fond couvre quatre-vingt-dix pour cent de la surface.

Une feuille de style moderne déclare ses **variables** en tête, `--color-background`,
`--color-text`, les familles de teintes numérotées, `--border-radius`, l'échelle de tailles.
C'est là que se lit la charte, en entier, et en une minute. On les prend toutes :

- **Le fond de page d'abord.** C'est lui qui décide si le document ressemble à la maison.
- **La couleur signature**, souvent un dégradé entre deux teintes déclarées comme telles.
  Elle vaut mieux qu'un filet neutre en tête de couverture.
- **Les familles de teintes**, chacune avec ses niveaux clairs et foncés. Le niveau clair
  fait les fonds de blocs, le niveau foncé fait le texte du même bloc.
- **Le rayon**, une seule valeur qui se répète partout et qu'on ne varie pas.
- **Les tailles**, prises dans l'échelle déclarée plutôt que choisies au jugé.

Deux règles :

- **Une police propriétaire ne se télécharge pas.** On prend la plus proche librement
  distribuable, et **on le dit en pied de document**. Taire la substitution, c'est laisser
  croire que le document est sorti de leur studio.
- **Un logo sombre sur un fond sombre disparaît.** On produit la variante claire soi-même
  plutôt que de compter sur un filtre : les filtres graphiques ne survivent pas à la
  conversion en PDF.

## 2. Piller le site, pas seulement sa charte

C'est le vrai gain de l'étape 1, et il se rate souvent : pendant qu'on cherche le logo, on
lit ce que la maison publie. **Les témoignages clients valent plus que tout ce qu'on peut
déduire.** Un portrait bâti sur six témoignages nommés n'est plus une intuition.

Ce qui se ramasse : les logos clients, les témoignages et qui les signe, les chiffres
annoncés, les intitulés de produits, les visuels de produit.

⚠️ Ces chiffres sont **ceux que la maison publie**, pas des chiffres mesurés. La diapositive
le dit, en toutes lettres, sous les chiffres.

## 3. Construire les diapositives

Cinq à dix, jamais plus. Une idée par diapositive. Format 16/9, soit 338,667 × 190,5 mm,
la taille exacte d'une diapositive Google.

Une trame qui tient pour un persona ou un argumentaire :

1. Couverture, logo de la maison
2. La preuve : chiffres, témoignages, logos clients
3. La fiche principale
4. Son exact contraire
5. Un cas réel qui valide
6. Un cas réel qui invalide
7. Ce que la paire démontre, et la question qui tranche
8. Provenance de chaque élément

**La dernière diapositive n'est pas facultative.** Elle dit d'où vient chaque chose, avec
les dates d'ouverture des sources, ce qui n'a pas pu être vérifié, et le fait que personne
n'a été contacté.

## 4. Fabriquer : les pièges mesurés

Le rendu s'écrit en HTML, puis WeasyPrint en fait un PDF, puis `pdftoppm` en fait des images.
**Trois défauts de WeasyPrint ont été mesurés le 09/09/2026, et chacun a coûté un tour :**

| Ce qui casse | Ce qu'il faut écrire |
|---|---|
| `display:flex` et `display:grid` | ignorés en silence : tout se replie en une colonne |
| `float` avec `overflow:hidden` | ne crée pas de contexte fiable : les colonnes se superposent |
| `stroke` et `fill` en CSS sur un SVG | attributs de présentation sur la balise `<svg>` |
| `filter:invert()` | ignoré : un logo sombre reste sombre sur fond sombre |

**La seule mise en colonnes qui tient, c'est le tableau.** `display:table` et
`display:table-cell`, avec `table-layout:fixed` et des largeurs explicites. C'est laid à
écrire et ça marche à tous les coups.

Le plus économique est donc d'écrire **un fichier d'impression dédié**, en tableaux, plutôt
que de corriger à coups de `@media print` une feuille de style faite pour l'écran. Deux
tours ont été perdus à tenter la seconde voie.

⚠️ **Mais cela ne vaut que pour un deck.** Une diapositive doit tenir dans un cadre fixe :
une colonne qui s'effondre déborde, et la page suivante part blanche. Une page de lecture,
elle, coule librement, et un simple bloc `@media print` qui remet `flex` et `grid` en flux
suffit à en tirer un PDF correct. Distinguer les deux cas évite d'écrire un second fichier
là où six lignes de style suffisent.

```bash
weasyprint <deck>-impression.html <deck>.pdf
pdftoppm -png -r 192 <deck>.pdf sl        # 2560 × 1440, la taille d'une diapositive
```

**Regarder au moins deux diapositives en image avant d'envoyer.** Une colonne effondrée ne
se voit pas dans le HTML.

## 5. Pousser en Google Slides

```bash
python3 integrations/google-gogcli/creer-deck-slides.py \
  --titre "AAMMJJ_<Nom du deck>" \
  --images sl-1.png sl-2.png … \
  --pdf <sortie>.pdf
```

Une image plein cadre par diapositive. Le rendu reste exactement celui qui a été validé, et
la présentation s'exporte en PDF depuis Slides comme n'importe quelle autre.

🔒 **Ouvrir le partage est une décision, pas une étape.** Le deck naît dans le Drive de la
maison. Je rends le lien et je demande à qui l'ouvrir, ou à quelle adresse le partager. Je
n'ouvre jamais un document en lecture par lien de ma propre initiative : c'est une
publication.

## Garde-fous

- **0 chiffre sans sa source et sa date, dans la diapositive elle-même.** Une diapositive
  rend un chiffre plus crédible qu'un paragraphe, donc la règle y est plus stricte.
- **Ce qui manque porte `⟦…⟧`** et la diapositive part quand même.
- **Aucune donnée d'une autre maison**, y compris en repère ou en contre-exemple.
- **Personne n'est contacté.** Un deck sert à préparer, jamais à approcher.
- **Une personne nommée dans un deck est nommée sur son profil public**, et le jugement
  porte sur son entreprise, jamais sur elle.
