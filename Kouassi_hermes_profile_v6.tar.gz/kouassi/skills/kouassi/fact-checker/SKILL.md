---
name: fact-checker
version: 1.0.0
description: Garde-fou de vérification avant publication. À invoquer obligatoirement en fin de TOUT livrable produit par un automatisme planifié, un sous-agent ou l'Expert Yelema elle-même, si ce livrable contient des affirmations factuelles (dates, chiffres, identités professionnelles, statuts juridiques, citations, événements récents, montants financiers, références contractuelles). Vérifie chaque affirmation structurante par AU MOINS 2-3 sources primaires indépendantes. Bloque la publication si erreur critique détectée. Décidé par le dirigeant le 25/05/2026 après une erreur factuelle (rapport de veille présentant le Directeur Général d'un fournisseur clé comme en poste alors qu'il avait été remplacé 3 jours avant).
intention: "Aucune information envoyée au dirigeant ne doit contenir une affirmation factuelle non vérifiée. La véracité est un prérequis non négociable avant publication, surtout pour les rapports produits par des automatismes planifiés sans supervision humaine en boucle directe."
maj: 2026-08-26
---

# Skill : fact-checker (garde-fou avant publication)

> Principe posé à la conception de l'Expert Yelema : "Je veux bien que tu rajoutes un skill fact-checker, et qu'il aille vraiment suffisamment loin, qu'il vérifie au moins deux, trois sources à chaque fois avant de me publier quelque chose. Valide toute la véracité de l'information."
>
> **Le précédent qui justifie ce skill.** Sur un dispositif comparable, une veille automatique a présenté le Directeur Général d'un fournisseur clé comme étant en poste alors qu'il avait été remplacé trois jours plus tôt par décision du conseil d'administration, et a daté « du jour » une offre commerciale publiée le mois précédent. Deux erreurs de la même famille : une **fonction périmée** et une **date reprise sans vérification**. Elles auraient conduit le destinataire à solliciter un interlocuteur qui n'était plus en fonction. C'est exactement ce que ce skill existe pour empêcher, et c'est le risque n°1 de tout agent qui cite des responsables d'entreprise, de banque ou d'administration.

## Règle d'or

**Aucun livrable contenant des affirmations factuelles n'est envoyé au dirigeant sans passer par ce skill.**

Si une affirmation ne peut pas être vérifiée sur au moins 2 sources primaires indépendantes : elle est soit retirée, soit explicitement marquée `⚠ À VÉRIFIER : <ce qu'il faut confirmer>` dans le livrable final.

Si une affirmation critique (date, identité professionnelle, montant, citation, statut juridique) est divergente d'une source primaire fiable : le livrable est BLOQUÉ, une alerte est envoyée au dirigeant à la place, et le livrable est corrigé avant publication.

## Quand invoquer ce skill (obligatoire)

- Tout brief matinal automatique (revue de presse, veilles, briefs ad hoc)
- Tout rapport thématique produit par un automatisme planifié (`rapport-*`, `note-*`, `analyse-*`, `veille-*`)
- Toute synthèse de presse, benchmark, étude de marché, rapport opportunité
- Tout livrable juridique (contrats, avenants, notes contractuelles)
- Toute note stratégique destinée à un tiers (un client, un fournisseur, une banque partenaire, l'administration, la presse économique)

## Quand NE PAS invoquer

- Échanges conversationnels sur la messagerie interne en direct (sparring en temps réel, la vérification ralentirait trop)
- Confirmations courtes, accusés de réception, salutations
- Documents purement organisationnels (registres d'automatisation, état machine, listes de tâches internes)

Ce skill cible les **livrables structurés à durée de vie longue** qui peuvent fonder une décision du dirigeant ou être transmis à un tiers.

## Processus en 6 étapes (à exécuter intégralement)

### Étape 1 : Extraction des affirmations factuelles structurantes

Lire le livrable produit, en extraire les **5 à 15 affirmations factuelles** les plus structurantes, celles qui, si fausses, casseraient la décision ou décrédibiliseraient le document.

Catégories à scanner systématiquement :
- **Dates précises** (jour, mois, année, surtout les dates récentes "aujourd'hui", "cette semaine", "le X mai 2026")
- **Identités professionnelles** (qui est directeur / DG / responsable aujourd'hui ? quel statut ?)
- **Montants financiers** (chiffre d'affaires, levées de fonds, budgets de projets, valorisations)
- **Statuts juridiques** (sociétés en activité / liquidation, contrats en vigueur, lois applicables, jurisprudences)
- **Citations verbatim** (propos rapportés, paroles d'un dirigeant, extraits de contrat)
- **Événements récents** (annonces, lancements, signatures, démissions, restructurations)
- **Pourcentages, statistiques, rangs** (parts de marché, taux d'adoption, classements)
- **Références bibliographiques / juridiques / contractuelles** (numéros de contrat, articles de code, identifiants réglementaires)

Pour chaque affirmation extraite : la noter avec son numéro de ligne dans le livrable.

### Étape 2 : Vérification par au moins 2-3 sources primaires indépendantes

Pour CHAQUE affirmation extraite, faire **au minimum 2 recherches web** (idéalement 3) sur des sources primaires différentes :

- **Pour le droit des affaires / OHADA / UEMOA** : Journal Officiel du pays concerné, textes légaux publiés, sites des régulateurs, greffes du tribunal de commerce
- **Pour les chiffres financiers / entreprises** : AgenceEcofin, Financial Afrik, CB Insights, sites officiels des entreprises, communiqués de presse vérifiés
- **Pour les nominations / événements d'entreprise** : communiqués officiels, sites institutionnels des entreprises concernées, presse économique locale fiable, agences de presse spécialisées
- **Pour les statistiques publiques** : instituts nationaux de statistique, banque centrale régionale (BCEAO/BEAC), FMI, Banque Mondiale, ONU, OIT
- **Pour le droit applicable à l'entreprise** : Journal Officiel du pays concerné, textes publiés sur les sites des institutions, décrets et arrêtés dans leur version publiée

Sources à exclure ou à pondérer :
- Wikipedia : à vérifier sur source primaire derrière
- Articles relais sans citer de source primaire
- Réseaux sociaux non vérifiés
- Blogs personnels

### Étape 3 : Comparer chaque affirmation aux sources trouvées

Pour chaque affirmation, produire une ligne de fact-check :

```
[Numéro ligne] Affirmation : "<verbatim de l'affirmation>"
  Source 1 : <URL>, <ce que la source dit>
  Source 2 : <URL>, <ce que la source dit>
  Source 3 (si fait sensible pour un tiers) : <URL>, <ce que la source dit>
  Statut : [✅ Vérifié 2+ sources concordantes] | [⚠ Divergence : <quoi>] | [❌ Non vérifié, source primaire introuvable]
```

### Étape 4 : Classer les divergences par criticité

- **CRITIQUE (bloque la publication)** :
  - Identité professionnelle fausse (X présenté comme DG alors qu'il a quitté ses fonctions)
  - Date d'événement majeur fausse (annonce présentée comme "ce jour" alors qu'elle date d'un mois)
  - Montant financier divergent de plus de 10 % d'une source primaire
  - Statut juridique d'entreprise faux (présentée active alors qu'en liquidation)
  - Citation verbatim non retrouvée dans la source originale
  - Référence contractuelle ou juridique introuvable ou hors-sujet

- **MAJEURE (signaler mais ne bloque pas)** :
  - Date approximative (mois exact divergent mais année OK)
  - Chiffre légèrement différent entre sources crédibles (préciser la fourchette)
  - Affirmation plausible mais source primaire fragile (signaler en `⚠ À VÉRIFIER`)

- **MINEURE (ajuster silencieusement)** :
  - Orthographe d'un nom propre
  - Précision géographique (ville vs quartier d'affaires)
  - Détail accessoire au raisonnement principal

### Étape 5 : Verdict de publication

Trois sorties possibles :

**Option A, PUBLICATION VALIDÉE** : aucune divergence critique, au plus des points `⚠ À VÉRIFIER` signalés dans le livrable. Le livrable peut être envoyé au dirigeant.

**Option B, PUBLICATION CORRIGÉE** : divergences critiques détectées mais correctibles automatiquement (date à recaler, identité à mettre à jour). Corriger le livrable, refaire un mini fact-check sur les corrections, puis publier.

**Option C, PUBLICATION BLOQUÉE** : divergences critiques non correctibles (le livrable repose entièrement sur une prémisse fausse, ex : "ce qu'a annoncé le directeur commercial aujourd'hui" alors que le directeur commercial a quitté l'entreprise). Ne PAS publier le livrable original. Envoyer au dirigeant une **alerte de fact-check** courte expliquant le problème + proposition de reformulation à valider.

### Étape 6 : Annexe de traçabilité (obligatoire en bas du livrable publié)

À la fin de tout livrable publié, ajouter un encart :

```
---
Vérification fact-checker (Skill v1.0)
- Affirmations factuelles structurantes extraites : <n>
- Affirmations vérifiées sur 2+ sources primaires : <n>
- Affirmations signalées "À VÉRIFIER" : <n>
- Divergences critiques détectées : <n> (toutes corrigées avant publication)
- Sources primaires consultées : <liste URLs courte>
- Date du fact-check : <date>
```

Cette annexe sert deux buts : (1) prouver au dirigeant que le contrôle a bien eu lieu, (2) tracer les sources pour audit ultérieur.

## Garde-fou anti-erreur

1. **Pas de mémoire, pas d'intuition** : chaque affirmation factuelle est tracée à une URL ou à un fichier corpus. Jamais "je crois que".
2. **Source primaire > source relais** : préférer un texte publié au Journal Officiel à un commentaire de cabinet, préférer un communiqué officiel à un article de presse, préférer une page institutionnelle à un blog.
3. **2 sources indépendantes minimum** : 2 articles citant la même dépêche ne comptent que pour 1 source. Vérifier que les sources sont vraiment indépendantes.
4. **Dater chaque source** : un article de 2024 cité en 2026 sur une nomination d'entreprise = quasi certainement obsolète.
5. **Pour les sujets d'entreprise en mouvement (partenariats, filiales, marchés régionaux)** : exiger 3 sources et privilégier les communiqués officiels et la presse économique spécialisée en plus de la presse locale.
6. **Jamais d'invention pour combler un trou** : si une source primaire est introuvable après 2-3 recherches, écrire `❌ Non vérifié` et NE PAS valider la publication sur ce point.

## Pièges à éviter (issus de l'incident fournisseur du 25/05/2026)

- **Confondre une annonce primaire et un article relais** : si un article du 25 mai parle d'une annonce, vérifier la DATE de l'annonce originale, pas la date de l'article.
- **Ne pas vérifier le statut courant des personnes citées** : un directeur / DG / responsable peut avoir quitté ses fonctions entre l'écriture du draft et la publication. Toujours vérifier "est-il toujours en poste à la date de la livraison ?".
- **Présumer qu'un automatisme en bonne foi ne se trompe pas** : un automatisme planifié est une session sans supervision humaine en boucle directe ; il peut produire un raisonnement cohérent mais sur des prémisses fausses. C'est précisément le rôle de ce skill.

## Format de sortie attendu

Le skill ne produit pas un nouveau livrable, il produit :
1. **Un rapport de fact-check** (à archiver en interne pour audit, ne pas le transmettre au dirigeant sauf demande)
2. **Le livrable original, corrigé ou non, ou bloqué**
3. **L'annexe de traçabilité** insérée en bas du livrable publié
4. **Si bloqué** : un message d'alerte court au dirigeant expliquant le problème détecté

## Principe d'amélioration

Ce skill est appliqué à un livrable à la fois. Chaque incident détecté est consigné dans `ERRORS.md` (`/home/<utilisateur>/agents/yelema/ERRORS.md`) pour enrichir le garde-fou. Si un automatisme produit régulièrement des erreurs sur le même type de fait (ex : statuts professionnels périmés), modifier le prompt de l'automatisme en amont pour intégrer la vérification structurellement.

## Référence

Ce skill est un compagnon obligatoire de toute compétence qui produit un livrable à enjeu :
- les briefs (`meeting-brief`, `brief-direction`) et les notes (`note-decision`, `note-blanche`)
- toutes les automatisations productrices (revue de presse, veilles, radar)

Il est aussi à invoquer manuellement pour tout livrable structuré préparé hors tâche planifiée.
