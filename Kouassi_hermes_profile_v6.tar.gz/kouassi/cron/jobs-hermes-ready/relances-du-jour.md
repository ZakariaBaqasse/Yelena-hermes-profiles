# Relances du jour (Kouassi)

**Schedule cron Hermes (standard 5 champs) :** `15 7 * * 1-5`  (Du lundi au vendredi, 07:15 UTC)
**Deliver :** origin (canal où l'Expert Kouassi est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Kouassi) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Relances du jour (Kouassi) », schedule `15 7 * * 1-5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Kouassi. Sors la liste des relances à faire aujourd'hui, et rien d'autre.

Tu regardes : les devis envoyés sans réponse au-delà du délai que l'entreprise s'est fixé, les
promesses de rappel notées dans les comptes rendus de visite et arrivées à échéance, les
affaires dont la prochaine échéance datée tombe aujourd'hui.

Pour chaque ligne : le client, l'objet, depuis quand, ce qui a été dit la dernière fois, et
l'angle de relance. **Une relance se justifie par un fait nouveau ou par une échéance, jamais
par le silence du client** : si tu n'as ni l'un ni l'autre, propose plutôt le message de clôture
propre qui permet de sortir l'affaire du pipeline.

Tu prépares les messages, tu n'en envoies aucun.

Consulte `memory/state/relances-signalees.json` : une relance déjà proposée et non traitée se
rappelle une fois, puis passe en proposition de clôture. Mets le fichier à jour dans tous les
cas, y compris quand l'envoi échoue.

S'il n'y a aucune relance due aujourd'hui, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
