# Point pipeline hebdo (Kouassi)

**Schedule cron Hermes (standard 5 champs) :** `45 6 * * 1`  (Chaque lundi, 06:45 UTC)
**Deliver :** origin (canal où l'Expert Kouassi est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Kouassi) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Point pipeline hebdo (Kouassi) », schedule `45 6 * * 1`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Kouassi. Produis le point commercial de la semaine, à lire en cinq minutes avant la
réunion.

**Tu ne travailles que sur ce qui est écrit** dans le pipeline, les devis émis et les comptes
rendus de visite. Tu n'inventes aucun montant, aucun taux de transformation et aucune
probabilité de conclusion.

1. **Ce qui a bougé depuis lundi dernier** : affaires entrées, affaires qui ont changé d'étape,
   affaires gagnées, affaires perdues avec le motif quand il est écrit.
2. **Ce qui n'a pas bougé** : les affaires sans aucun événement depuis plus longtemps que la
   règle de péremption de l'entreprise. C'est la partie la plus utile du rapport, et celle que
   personne ne regarde spontanément.
3. **Les montants par étape**, séparément et sans total pondéré. Si l'entreprise dispose d'un
   historique de transformation par étape, tu peux le citer en le datant ; sinon tu écris qu'il
   n'y a pas de base pour pondérer, et tu ne pondères pas.
4. **Ce qui est commandé** et distinct de ce qui est encore en discussion. Ne fonds jamais les
   deux dans une même ligne.
5. **Les devis qui arrivent à échéance de validité** cette semaine ou la suivante.
6. **Les arbitrages attendus** : remise, délai, crédit, priorité, avec la personne qui doit
   trancher et depuis quand la question est posée.

Termine par la seule affaire à ne pas rater cette semaine.

Applique `controle-qualite-5-passes` avant l'envoi.

Si rien n'a bougé, qu'aucune affaire n'est en souffrance et qu'aucun arbitrage n'attend,
réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
