# Couche locale : Mamadou · Finance et comptabilité

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-MAMADOU-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Source identifiée, note encore à fabriquer. Le relevé du gouvernement de 2026 existe sur la machine (memory/reference/gouvernement-2026.md chez LOKOLI) et sert de base. Pour un poste juridique, la note utile n'est pas la liste des ministres mais la chaîne qui décide d'un texte : Assemblée nationale et Sénat pour la loi, Président pour l'ordonnance, Secrétariat général du Gouvernement pour la publication au Journal officiel, juridictions pour l'application. POINT DUR À PORTER : le Journal officiel n'est PAS en accès libre en ligne ; le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66). Toute date de publication citée sans avoir ouvert le JO est une date de seconde main, et doit être annoncée comme telle. Écart tranché le 18/09 : décret n°2026-05/2 du 07/01/2026, publié au Journal officiel n°5 (Spécial) du 17/02/2026, il ne reste que DEUX districts autonomes, Abidjan et Yamoussoukro.

### CL-MAMADOU-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-MAMADOU-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-MAMADOU-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-MAMADOU-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-MAMADOU-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || FAIT LE 18/09 : les dix actes uniformes sont sur la machine, en PDF et en texte, dans ~/.claude/outils-communs/ohada/ avec une fiche LISEZ-MOI. La Côte d'Ivoire est État partie au traité OHADA : ces actes y sont directement applicables et priment sur le droit interne contraire. CEUX QUI TOUCHENT LE MÉTIER COMPTABLE ET FINANCIER : AUDCIF (droit comptable et information financière, adopté le 26/01/2017 à Brazzaville, 113 articles, en vigueur au 01/01/2018 pour les comptes personnels et au 01/01/2019 pour les comptes consolidés, combinés et les états financiers en normes IFRS), c'est le texte qui commande la tenue des comptes ; AUSCGIE (sociétés commerciales et GIE, 30/01/2014, 920 articles) pour le capital, les comptes sociaux, l'affectation du résultat et les seuils de commissariat aux comptes ; AUDCG (droit commercial général, 15/12/2010, 307 articles) pour le RCCM, l'entreprenant et la prescription commerciale ; AUPCAP (procédures collectives, 10/09/2015, 258 articles) pour l'entreprise en difficulté, du règlement préventif à la liquidation ; AUS (sûretés, 15/12/2010, 228 articles) pour ce qui garantit une créance au bilan.

## Langue

### CL-MAMADOU-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || CORRIGÉ LE 18/09 : le socle affirmait que la compétence parler-ivoirien était déjà liée à ce poste. C'ÉTAIT FAUX — elle l'était chez KOUASSI, d'où le socle a été repris, et elle manquait sur SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis le 18/09, version du catalogue vérifiée neutre. ⚠ LA LEÇON : un socle transverse porte la réponse du poste SOURCE, pas celle du poste cible. Une affirmation du type « déjà chez lui » doit se vérifier poste par poste avant d'être propagée. Ce que sert ce corpus : la règle de registre (le premier contact reste formel ici, on vouvoie, l'urgence fabriquée est mal vue) autant que le lexique.

## Canaux

### CL-MAMADOU-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : mobile money à 50,3 % des individus, dont 85 % de transferts — c'est le flux que la comptabilité d'une PME ivoirienne rencontre le plus.

## Fiscalité

### CL-MAMADOU-11 · Les impôts et taxes qui touchent une entreprise ici, et leur calendrier
- **Pourquoi** : Une échéance manquée coûte une pénalité
- **Où chercher** : Direction générale des impôts
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base fiscale sur disque : Code général des impôts édition 2025 de la DGI (9 762 paragraphes), annexe fiscale à la loi de finances 2025-987 du 19/12/2025 pour le budget 2026 (41 mesures), et deux synthèses DGI. ⚠ Chercher dans cgi-2025-recolle.txt (césures de colonnes recollées), citer depuis cgi-2025.txt. TVA 18 %, taux réduit 9 %. Pour la vue d'ensemble, « Impôts et taxes en Côte d'Ivoire », tableau synoptique de la DGI, 129 pages. || FAIT LE 18/09 : ~/.claude/outils-communs/fiscalite-ci/ porte le CODE GÉNÉRAL DES IMPÔTS, édition 2025 des Publications de la DGI (1 017 618 caractères, 1 153 articles), qui contient aussi le Livre de Procédures fiscales (p. 281), les taxes parafiscales (341), les droits domaniaux (351), divers textes fiscaux (373), la fiscalité des collectivités territoriales (471), le Code des Investissements (503), le Code pétrolier (531), le Code minier (541) et les actes communautaires (559) ; plus l'ANNEXE FISCALE 2026, annexe à la loi de finances n°2025-987 du 19/12/2025, 148 pages et 41 mesures ; plus deux documents de synthèse de la DGI. ⛔ LE DÉCALAGE À NE JAMAIS OUBLIER : le Code est arrêté au 10 janvier 2025, l'annexe 2026 lui est postérieure et en modifie des pans entiers. On lit l'article dans le Code, PUIS on cherche le même sujet dans l'annexe 2026. Un chiffre tiré du Code seul peut être périmé de douze mois. LES TAUX DE BASE, sur article : bénéfices 25 %, porté à 30 % pour les télécommunications et les TIC (art. 51) ; bénéfices non commerciaux 25 % (art. 90) ; TVA 18 %, réduite à 9 % sur une liste limitative (art. 359) ; microentreprises 6 % du chiffre d'affaires déclaré, réduit pour les adhérents d'un Centre de Gestion Agréé et les contribuables suivis par un expert-comptable inscrit à l'Ordre (art. 71 bis à 71 quater) ; taxe d'État de l'entreprenant 5 %, ramenée à 4 % pour le commerce et le négoce (art. 77) ; option de changement de régime avant le 1er février (art. 46). MESURES 2026 QUI TOUCHENT NOS CLIENTS : impôt sur les bénéfices des plateformes de commerce en ligne sans installation en Côte d'Ivoire (art. 33), régime de faveur pour les startups numériques labellisées (art. 35), déductibilité des règlements par mobile money (art. 7), prix de transfert (art. 23 et 25), périodicité de paiement de la taxe d'État de l'entreprenant et de l'impôt des microentreprises (art. 36). CE QUI RESTE À FAIRE, et c'est la seconde moitié de l'intitulé : LE CALENDRIER DES ÉCHÉANCES n'est pas extrait. Il se construit sur le Livre de Procédures fiscales, et il se recoupe avec la compétence calendrier-fiscal-et-social. DEUX PIÈGES DE RECHERCHE, dans le LISEZ-MOI : l'apostrophe du Code est typographique et non droite (7 résultats contre 342 sur le même mot), et le texte porte 5 179 césures de colonnes (presta-taires, ser-vice) ; d'où deux fichiers, cgi-2025-recolle.txt pour CHERCHER et cgi-2025.txt pour CITER.

## Comptabilité

### CL-MAMADOU-12 · Le plan comptable SYSCOHADA révisé
- **Pourquoi** : Tenir des comptes sur un plan étranger rend le bilan inexploitable
- **Où chercher** : OHADA, textes SYSCOHADA
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : PARTIEL, donc Non, et la nuance compte. Ce qui EST là depuis le 18/09 : l'ACTE UNIFORME lui-même, AUDCIF du 26/01/2017, 113 articles, dans ~/.claude/outils-communs/ohada/, en deux exemplaires, une saisie retapée complète pour chercher et la publication authentique au Journal officiel du 15/02/2017 pour citer. Il donne les principes, les obligations de tenue, les états financiers et les dates d'entrée en vigueur. CE QUI MANQUE, ET C'EST PRÉCISÉMENT CE QUE DEMANDE L'INTITULÉ : le PLAN COMPTABLE GÉNÉRAL OHADA et le DISPOSITIF RELATIF AUX COMPTES CONSOLIDÉS ET COMBINÉS, c'est-à-dire le SYSCOHADA révisé lui-même, ses classes, ses comptes et ses états. Ce sont les annexes de l'acte, et elles occupent à elles seules plus de mille des 1 200 pages du numéro spécial du Journal officiel de l'OHADA. Aucun exemplaire libre n'en a été trouvé le 18/09. TANT QUE C'EST ABSENT : on peut citer une obligation comptable par son article, on ne peut PAS donner un numéro de compte ni le contenu d'un état normalisé. Écrire un numéro de compte de mémoire est exactement ce que cette couche locale existe pour empêcher.

## Social

### CL-MAMADOU-13 · Cotisations CNPS et charges sur salaire
- **Pourquoi** : Un coût employeur faux fausse tout le budget
- **Où chercher** : CNPS
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Taux de cotisation CNPS sur disque. ⚠ Répartition vieillesse 7,70 employeur / 6,30 salarié : source secondaire, pas le document CNPS. || DÉJÀ SUR LA MACHINE : ~/.claude/outils-communs/droit-travail-ci/cnps/ porte le document de recouvrement de la CNPS (cnps.ci), rapatrié le 18/09, avec les taux, l'assiette, la périodicité des versements, la régularisation annuelle, les pénalités de retard et les formalités d'affiliation. TAUX : prestations familiales 5 %, assurance maternité 0,75 %, accidents du travail et maladies professionnelles 2 à 5 % selon le secteur, assurance vieillesse 14 %. ⚠ LA RÉPARTITION DE LA VIEILLESSE entre employeur (7,70 %) et salarié (6,30 %) NE FIGURE PAS dans le document de la CNPS : elle vient de sources secondaires concordantes, et se porte comme telle. ⚠ Le document porte la mention Édition 2018 ; ses taux coïncident avec ce que publient les sources secondaires pour 2026, mais UN TAUX DE PAIE SE RECONFIRME SUR cnps.ci AVANT CHAQUE EXERCICE. La régularisation annuelle (DISA et DASC) est due au plus tard le 31 mars. SMIG : 75 000 FCFA par mois depuis le 1er janvier 2023, première hausse depuis 2014 selon l'Organisation internationale du travail ; le numéro du décret (2022-986 du 21/12/2022) et le SMAG (39 960 FCFA) viennent de sources secondaires. L'article 31.8 du Code du travail renvoie le montant à un décret négocié tous les trois ans. À NE PAS CONFONDRE : les cotisations sociales ne sont pas de l'impôt, l'ITS et ses barèmes vivent chez la DGI, dans ~/.claude/outils-communs/fiscalite-ci/.

## Banque

### CL-MAMADOU-14 · Comment se passe un virement, un dépôt, une remise de chèque ici
- **Pourquoi** : Promettre un encaissement à une date impossible
- **Où chercher** : BCEAO, banques de la place
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE. Ce que demande cette ligne, ce sont des DÉLAIS DE PRATIQUE BANCAIRE : combien de temps met un virement entre deux banques de la place, un virement depuis l'étranger, un dépôt d'espèces, une remise de chèque avant disponibilité des fonds. Ces délais ne sont écrits dans aucun texte : ils se relèvent auprès des banques, et ils diffèrent d'un établissement à l'autre. Ce qui est établi et utilisable : le cadre de la BCEAO, huit États membres, parité fixe 655,957 XOF pour 1 EUR. Ce qui manque : les conditions tarifaires et les délais de valeur publiés par les banques de la place, qu'aucune source consolidée ne rassemble. C'est une ligne qui se remplit par des retours de mission, pas par une recherche.

## Trésorerie

### CL-MAMADOU-15 · Les délais réels d'encaissement, public et privé
- **Pourquoi** : Un plan de trésorerie sur des délais théoriques
- **Où chercher** : Retours de missions
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://tresor.gouv.ci/tres/
- **Pièce, ici** : references/pieces/1pAHeYudTogFLYZe9dOgUDm2NJbpFZhundCQVfaLZ8Kc.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, et le chiffre change de rang. Note neuve bases-locales/marches-publics-ci/DELAIS-DE-PAIEMENT.md. ⛔ LE DÉLAI DE 90 JOURS N'EST PLUS UNE SOURCE DE SECOND RANG : il est à l'ARTICLE 139 DU CODE DES MARCHÉS PUBLICS DE 2019, que nous détenons. L'autorité contractante est tenue de payer acomptes et solde dans un délai QUI NE PEUT DÉPASSER QUATRE-VINGT-DIX JOURS, avec deux nuances qui comptent : un délai PLUS LONG peut être fixé POUR LE SOLDE, et des délais PLUS COURTS peuvent être accordés aux PME ou pour des projets urgents ou à caractère social, ce qui se demande et ne s'obtient pas d'office. AUTRES DÉLAIS DU CODE : 45 jours maximum pour payer une avance à compter de la réception de la garantie (art. 132), 60 jours maximum pour payer les intérêts moratoires après demande, 10 jours maximum pour que le titulaire achemine la demande de paiement d'un sous-traitant (art. 137). INTÉRÊTS MORATOIRES, art. 142 : taux de l'INTÉRÊT LÉGAL MAJORÉ D'UN POINT, jours calendaires, années de 365 jours, courant du jour suivant l'expiration du délai jusqu'à l'émission du titre de règlement, capitalisés un an après l'échéance, et SANS AVENANT. ⛔ MAIS ILS NE SONT PAS AUTOMATIQUES EN PRATIQUE : ils sont dus SUR DEMANDE MOTIVÉE ET CHIFFRÉE du titulaire. Un fournisseur qui ne demande rien ne reçoit rien. Et deux exclusions : rien sur les prestations non réalisées, et LE RETARD DE PAIEMENT DES AVANCES N'EST PAS SANCTIONNÉ. LE CHIFFRE ET SON CONTRE-CHIFFRE RESTENT CITÉS ENSEMBLE, tous deux de rang 2 : Trésor, 1 556,8 Md FCFA payés à 6 721 fournisseurs au 31/12/2025 et 416,98 Md à 2 870 au premier semestre 2026 ; SYNAFECI, plus de 39,04 Md d'impayés réclamés en juillet 2025 dont le Trésor ne reconnaissait que 1,8 Md. C'est l'écart qui porte l'information commerciale. ⛔ CE QUI MANQUE, ET IL FAUT LE DIRE : le secteur privé, où aucun relevé de délai réel n'existe et où les 90 jours publics ne se transposent pas ; le taux de l'intérêt légal en vigueur, qui est la base de calcul ; et le délai RÉEL constaté, les chiffres du Trésor donnant des volumes, pas des durées. ⚠ PIÈGE D'EXTRACTION signalé dans la note : ce Code est en trois colonnes, l'extraction texte décale les numéros d'articles, toute citation se vérifie dans le PDF.

## Change

### CL-MAMADOU-16 · Le rattachement du franc CFA et ce que ça implique
- **Pourquoi** : Traiter une facture en euros comme une opération de change
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Règlement n° 09/2010/CM/UEMOA du 01/10/2010 sur les relations financières extérieures (47 p., 43 art.) et note BCEAO de mai 2023. Parité fixe 655,957 XOF pour 1 EUR. ⛔ LA RÈGLE EST ASYMÉTRIQUE : l'entrée est libre (investissements étrangers et cessions entre non-résidents libres), la SORTIE ne l'est pas (tout investissement à l'étranger par un résident est subordonné à autorisation préalable du ministre chargé des Finances). ⛔ La note de 2023 décrit une révision EN PROPOSITIONS, pas un texte adopté. || Le cadre est établi et relevé sur bceao.int : parité FIXE de 655,957 FCFA pour 1 euro, garantie par le Trésor français, huit États membres de l'UEMOA (Bénin, Burkina Faso, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo). CE QUE ÇA IMPLIQUE, ET C'EST LE FOND DE LA LIGNE : une facture libellée en euros n'est PAS une opération de change au sens d'un risque, puisque le taux ne bouge pas ; il n'y a ni couverture à prendre ni écart de conversion à provisionner sur l'euro. L'écart existe en revanche sur toute autre devise, dollar en tête, et là un taux se cite TOUJOURS avec sa date. Règle d'usage déjà posée sur les autres onglets : chiffrer en XOF d'abord. Coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. CE QUI N'EST PAS TRANCHÉ ICI et ne doit pas être improvisé : le régime des changes, c'est-à-dire ce qu'une entreprise a le droit de transférer hors de la zone et sous quelles formalités. Cela relève de la réglementation des changes de l'UEMOA, non rapatriée au 18/09.

## Formalités

### CL-MAMADOU-17 · Création, modification et cessation d'une société
- **Pourquoi** : Conseiller une structure impossible à créer ici
- **Où chercher** : CEPICI, guichet unique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OHADA complète sur disque : les DIX actes uniformes en PDF et en .txt cherchable (AUDCG-2010 307 art., AUSCGIE-2014 920, AUSCOOP-2010 397, AUS-2010 228, AUPSRVE-2023 338, AUPCAP-2015 258, AUDCIF-2017 113, AUA-2017 36, AUM-2017 17, AUCTMR-2003 31), plus l'AUDCIF tel que publié au Journal officiel. Ces actes sont DIRECTEMENT applicables en Côte d'Ivoire et priment sur le droit interne contraire. ⛔ Citer par l'article, jamais de mémoire. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches. Création, modification et cessation se lisent dans l'AUDCG (registre du commerce) et l'AUSCGIE (constitution, transformation, dissolution). || FAIT LE 18/09 pour la partie texte, à compléter pour la partie guichet. LE DROIT EST SUR LA MACHINE dans ~/.claude/outils-communs/ohada/ : l'AUSCGIE (30/01/2014, 920 articles) donne les formes sociales, le capital, les statuts, les cessions de parts, les augmentations de capital et la dissolution ; l'AUDCG (15/12/2010, 307 articles) donne l'immatriculation au RCCM, le statut de l'entreprenant et la cessation ; l'AUPCAP (10/09/2015) donne ce qui se passe quand la cessation n'est pas volontaire. L'effet fiscal du choix de forme est dans ~/.claude/outils-communs/fiscalite-ci/, articles 51, 71 bis à 71 quater et 77 du Code général des Impôts. CE QUI MANQUE, et c'est la partie pratique : le parcours réel au GUICHET UNIQUE DU CEPICI, les pièces à fournir, les frais et les délais annoncés. Le droit dit ce qu'on peut créer, le CEPICI dit comment et en combien de temps. Tant que ce n'est pas relevé, une note de création annonce la forme et ses conséquences, jamais un délai d'immatriculation.

## Références

### CL-MAMADOU-18 · Modèles de documents comptables acceptés par l'administration
- **Pourquoi** : Un document refusé fait perdre un mois
- **Où chercher** : Direction générale des impôts, cabinets locaux
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE, et c'est en partie une donnée interne. Ce que demande cette ligne, ce sont les documents qu'une administration ivoirienne accepte sans discuter : présentation de facture, mentions obligatoires, format des états financiers déposés, pièces justificatives admises en déduction. Deux manques distincts. (1) Côté normalisation comptable, c'est le SYSCOHADA qui donne les états, et il n'est pas sur la machine, voir la ligne 12. (2) Côté fiscal, les mentions et formats relèvent de la DOCTRINE ADMINISTRATIVE de la DGI, notes et circulaires, qui ne sont pas dans ~/.claude/outils-communs/fiscalite-ci/ et ne se trouvent que sur dgi.gouv.ci. Ce qui est vérifiable dès maintenant : les conditions de déductibilité des charges, qui sont dans le Code et que l'annexe fiscale 2026 modifie (art. 39), et la déductibilité des règlements par mobile money (art. 7 de la même annexe).
