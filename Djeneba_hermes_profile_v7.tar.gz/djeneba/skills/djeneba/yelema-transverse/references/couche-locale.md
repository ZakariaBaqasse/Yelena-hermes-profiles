# Couche locale : Djénéba · Assistance de direction

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-DJENEBA-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci/gouvernement
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Socle commun, ET LA PIÈCE EXISTE DÉJÀ AILLEURS : memory/reference/gouvernement-2026.md chez LOKOLI donne la composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 » (1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués), relevée le 10/09 sur le portail officiel, avec la bonne réserve : rouvrir la page avant de citer un ministre, c'est la seule source qui se met à jour. À reprendre plutôt qu'à refaire. Voir aussi la hiérarchie de fiabilité des sources dans watchlist-sources-ci.md (Benkan, Yiriwa, Lokoli).

### CL-DJENEBA-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Socle commun. Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021. MISE À JOUR DU 18/09, ET CE JEU EST ANTÉRIEUR AU CHANGEMENT : le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026 (référence établie sur le recensement mensuel d'Ivoire-Juriste, cohérence vérifiée contre son récapitulatif de janvier). La presse ne l'a relevé que le 18/03. L'écart noté plus haut sur les districts est donc tranché : UN LIVRABLE ÉCRIT DEUX DISTRICTS AUTONOMES, JAMAIS DOUZE NI QUATORZE. L'écart sur les communes, 201 contre 197, reste ouvert. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-DJENEBA-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || DÉJÀ FAIT, ET C'EST LA SEULE LIGNE 03 RÉELLEMENT FAITE DES CINQ POSTES TRAITÉS LE 17/09. memory/reference/droit/JOURS-FERIES.md distingue les trois niveaux (férié, chômé, payé), cite l'article 24.2 du Code du travail pour les deux seuls jours fériés chômés payés par la loi (fête nationale et 1er mai), donne la liste réglementaire du décret 96-205 et renvoie à l'article 64 de la convention de 1977 pour les fériés payés. Et il pose honnêtement ce qui manque : le décret fixant la liste n'a jamais été téléchargé, et les fêtes mobiles ne sont fixées par aucun texte, elles s'annoncent chaque année par communiqué ministériel. Voir CL-DJENEBA-20 et 21. ⚠ 17/09 : remis à « Intégré : Non ». Le mode d'emploi est explicite, « une pièce sans lien n'est pas intégrée », et la pièce n'est pas encore déposée dans le dossier Couche Locale du Drive. Elle est disponible dans le poste, ce qui est autre chose.

### CL-DJENEBA-20 · Le décret qui fixe la liste des jours fériés
- **Pourquoi** : Tant qu'il n'est pas lu, la liste utilisée vient d'une page d'ambassade
- **Où chercher** : Journal officiel, Secrétariat général du gouvernement
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.fonctionpublique.gouv.ci/assets/rubriques/_documentation/D_2011_371_04.11_.11_Jours_Feries_.pdf
- **Pièce, ici** : references/pieces/1hDJMwhXoCWdAZ_EkzQVdgGDB8qwpFeV0jOm10fs1AF8.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Le décret était marqué « à récupérer » depuis le 26/08 : il est lu. Deux textes, pas un. Le décret 96-205 du 7 mars 1996 porte l'article premier (fête nationale et 1er mai, fériés chômés ET payés) et TOUT le régime, articles 3 à 10 ; le décret 2011-371 du 4 novembre 2011 remplace le seul article 2, c'est-à-dire la liste, portée à seize entrées. La fiche JOURS-FERIES.md a été réécrite sur les textes et non plus sur une page d'ambassade, et cette lecture corrige DEUX ERREURS que nous servions : (1) le 15 novembre, Journée nationale de la Paix, manquait à notre liste alors qu'il y est depuis 1996 ; (2) la règle du lendemain quand la fête tombe un dimanche ne se limite pas à la fête nationale et au 1er mai, elle couvre aussi la Korité, Noël et la Tabaski depuis 2011. Trois fériés potentiels de plus dans un calendrier de paie. Deux apports venus de la convention de 1977 relue au passage : quand le 7 août tombe un mardi ou un vendredi, la veille ou le lendemain est aussi férié et chômé (art. 65) ; et la rémunération d'un férié payé autre que le 1er mai et le 7 août suppose d'avoir travaillé la dernière journée avant et la première après (art. 64). CE QUE LA PIÈCE NE COUVRE PAS, et c'est écrit dans la fiche : le décret de 1996 n'existe chez nous qu'en transcription privée (loidici.biz), droit-afrique.com rend 403 et aucun site gouvernemental ne le publie ; le décret de 2011 vient lui du ministère de la Fonction publique avec mention « copie certifiée conforme ». Un point aveugle de paie reste ouvert et n'a pas été tranché : quand la Korité, la Tabaski ou Noël tombe un dimanche, le lendemain est férié et chômé par le décret de 2011, mais la convention de 1977 lui est antérieure de trente-quatre ans et ne dit pas s'il est payé. Enfin l'article 7 du décret de 1996 interdit le travail des femmes ces jours-là sauf accord des intéressées : disposition marquée « à vérifier », en tension avec le Code du travail de 2015, à ne pas servir telle quelle.

### CL-DJENEBA-21 · Les fêtes mobiles et leur annonce
- **Pourquoi** : Tout calendrier posé en janvier est faux en cours d'année
- **Où chercher** : Communiqués ministériels, au fil de l'eau
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.fonctionpublique.gouv.ci/assets/rubriques/_documentation/D_2011_371_04.11_.11_Jours_Feries_.pdf
- **Pièce, ici** : references/pieces/1hDJMwhXoCWdAZ_EkzQVdgGDB8qwpFeV0jOm10fs1AF8.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 31/12/2026
- **Commentaire** : INTÉGRÉ LE 22/09, avec une réserve nommée. La règle de fond est posée et lisible : le décret NOMME la Korité, la Tabaski, le Maouloud et la nuit du Destin, il ne les DATE pas. Leur date est fixée chaque année par communiqué du ministère en charge de l'emploi, quelques jours avant, et deux fériés ont été appris par la presse en août 2026 dont un la veille au soir. La fiche interdit donc de poser un rendez-vous sur une date supposée fériée ou supposée ouvrée sans l'avoir vérifiée, et tient un relevé des annonces constatées. Deux pièges y sont écrits : pour le Maouloud et la nuit du Destin, c'est LE LENDEMAIN qui est férié, pas le jour de la fête ; et depuis 2011, tant que la date de la Korité ou de la Tabaski n'est pas annoncée, on ne sait pas non plus si le lendemain sera férié, donc le calendrier d'une année n'est complet qu'en fin d'année. RÉSERVE : le relevé est alimenté à la main et ne compte que deux entrées, celles d'août 2026. Une couche dont la fraîcheur dépend de quelqu'un qui pense à regarder ne tient pas à l'échelle, c'est le constat du 03/09 sur le dépôt des livrables. Ce qui fermerait vraiment la ligne est un contrôle récurrent des communiqués du ministère ; il n'a pas été créé de ma seule initiative, parce que toute tâche planifiée pèse sur la fenêtre de quota. À arbitrer.

## Zone UEMOA

### CL-DJENEBA-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Socle commun. uemoa.int répond mais sa chaîne de certificat est incomplète, les scripts tombent et le navigateur passe.

### CL-DJENEBA-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Socle commun. Aucun chiffre relevé. Manque transverse aux cinq fiches du 17/09 : aucun montant de SMIG. MISE À JOUR DU 18/09 : les chiffres de base sont désormais relevés sur bceao.int, huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. LE SMIG RESTE NON RELEVÉ, c'est un manque transverse distinct et il n'est pas comblé par cette mise à jour.

## Droit des affaires

### CL-DJENEBA-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/actes-uniformes/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Socle commun, peu utile ici : le métier d'assistance de direction relève des usages et du droit social national, pas du droit régional des affaires.

## Langue

### CL-DJENEBA-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Socle commun, déjà chez elle : compétence parler-ivoirien (Y0487) liée au poste.

## Canaux

### CL-DJENEBA-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : WhatsApp à 92,8 % confirme ce que le corpus vendre-en-cote-d-ivoire observait sans le chiffrer.

## Direction

### CL-DJENEBA-11 · L'agenda réel d'une direction ici : contraintes, déplacements, protocole
- **Pourquoi** : Poser un rendez-vous impossible
- **Où chercher** : Retours de missions, secrétariats
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Interne. Ne se cherche nulle part. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. CONSÉQUENCE POUR CETTE LIGNE : l'agenda réel d'une direction est INACCESSIBLE depuis mon poste. Il faudrait un partage en lecture d'un agenda de direction, ou un relevé fait par un humain.

## Déplacements

### CL-DJENEBA-12 · Visas, vols régionaux, temps de trajet dans Abidjan
- **Pourquoi** : Un enchaînement de rendez-vous intenable
- **Où chercher** : Compagnies, services consulaires
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://snedai.com/e-visa/
- **Mis à jour** : 17/09/2026
- **Commentaire** : TROIS SUJETS DE NATURE DIFFÉRENTE, UN SEUL EST DOCUMENTÉ. Les visas : source officielle snedai.com/e-visa (vérifiée). L'e-visa s'obtient avant le départ et ne vaut que pour une arrivée à l'aéroport Félix Houphouët-Boigny, avec enrôlement biométrique sur place ; conditions d'entrée aussi sur aeroport-abidjan.com (vérifié). ⛔ AUCUN PRIX NI DÉLAI N'EST REPRIS ICI : les chiffres qui circulent (73 €, 112 €, 48 h) viennent tous d'agences intermédiaires qui revendent le service, pas de l'émetteur. Les vols régionaux : rien de stable, ça se prend à la réservation. LES TEMPS DE TRAJET DANS ABIDJAN : introuvables, et c'est pourtant le plus utile des trois. Aucune mesure publique. La pièce se construit, voir CL-DJENEBA-23.

### CL-DJENEBA-19 · La météo comme donnée de planning
- **Pourquoi** : À Abidjan une pluie forte réorganise un agenda
- **Où chercher** : SODEXAM, source nationale
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://sodexam.com
- **Pièce, ici** : references/pieces/1jd_OGrfQl9jId-N-YAjuigeL-Om3W4xxc4wjVZGirjY.md
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/09/2027
- **Commentaire** : ⚠ CORRIGÉ LE 21/09 APRÈS CONTRÔLE À L'USAGE, ET LE DÉFAUT MÉRITE D'ÊTRE LU : la pièce était le script open-meteo, et Djénéba ne s'en est PAS servie. Question posée, « séminaire de deux jours à Korhogo, quelle période éviter » : elle est partie sur le web et a cité deux agrégateurs climatiques touristiques. Un chemin qui finit par .py ne se LIT pas, il se LANCE, et le réflexe de lecture ne s'y applique donc pas. La pièce est désormais une NOTE, saisons-ci.md, engendrée par l'outil et donc réengendrable ; l'outil reste nommé derrière pour rafraîchir. Re-test passé : elle mène avec notre relevé, août 267 mm, 61 % de la pluie annuelle sur juillet-septembre, et rétrograde les agrégateurs en corroboration. || INTÉGRÉ LE 21/09, par l'intégration open-meteo. Dix ans d'observations remplacent une ligne qui disait encore hier « les saisons ne sont pas établies », sodexam.com refusant la connexion. ⛔ ET LA CÔTE D'IVOIRE N'A PAS UN RÉGIME, ELLE EN A DEUX : Abidjan, littoral, pluies d'avril à juin puis de septembre à novembre, aucun mois sec, 1 902 mm par an ; Korhogo, nord, pluies de juillet à septembre seulement, secs de novembre à février, 1 036 mm. Un calendrier du sud appliqué au nord se trompe de plusieurs mois et du simple au double sur les volumes : LA VILLE SE NOMME TOUJOURS À CÔTÉ DE LA SAISON. Sept villes couvertes. Prévisions à sept jours par la même commande. ⚠ Le cumul en mm est la mesure solide ; le compte de jours de pluie n'est qu'un ordre de grandeur, ERA5 travaillant sur une maille de 25 km qui étale les pluies faibles. || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || Ajout du 17/09, validé par l'équipe. Demandée le 14/09, jamais posée. sodexam.com répond. Ce n'est pas du confort, c'est une contrainte de déplacement.

### CL-DJENEBA-23 · Les temps de trajet réels dans Abidjan
- **Pourquoi** : C'est ce qui empêche l'enchaînement de rendez-vous intenable
- **Où chercher** : Mesure au fil des missions
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Formalisation de la moitié manquante de la ligne 12, sous forme de tableau entre les points où la maison se rend vraiment, aux heures où elle s'y rend. C'est mesurable, et personne ne l'a mesuré.

### CL-DJENEBA-25 · L'accès aux bâtiments publics et aux sièges d'entreprise
- **Pourquoi** : Des détails qui font arriver en retard à un rendez-vous préparé un mois à l'avance
- **Où chercher** : Relevé au fil des visites
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Badge, dépôt d'une pièce d'identité, délai d'annonce d'un visiteur, restrictions de stationnement.

## Protocole

### CL-DJENEBA-13 · Les usages d'adresse et de préséance
- **Pourquoi** : Une formule d'adresse fausse ferme une porte
- **Où chercher** : Guides de protocole, retours de missions
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://protocoledetat.diplomatie.gouv.ci/
- **Pièce, ici** : references/pieces/1iyrwH8sBfjVCJnwYWykxLvW8ivxBDdZbx8pruvRs2GA.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Au 20/09 seule une adresse était connue ; la pièce existe maintenant, base neuve bases-locales/protocole-ci/, et elle sert deux gestes que la ligne confondait. (1) L'ORDRE D'ADRESSE, relevé mot pour mot sur un discours du Premier ministre en Conseil des ministres du 24/01/2026, source Primature. « Excellence » précède le titre POUR LE SEUL CHEF DE L'ÉTAT ; l'énumération DESCEND SANS SAUT ; elle se ferme TOUJOURS par « Mesdames et Messieurs », seule place légitime de cette formule ; chaque ligne finit par un point-virgule. Quand on n'est pas au sommet, on commence à l'autorité la plus élevée RÉELLEMENT PRÉSENTE. ⚠ Les autorités coutumières et religieuses ne s'omettent JAMAIS dans une cérémonie en région, c'est l'oubli le plus fréquent d'un texte préparé à Abidjan, et en cas de doute sur la présence d'une autorité ON LA RETIRE : saluer un absent est la faute la plus visible. (2) LA HIÉRARCHIE OFFICIELLE ÉCRITE, tirée de la liste des personnalités habilitées aux salons d'honneur de l'aéroport publiée par la Direction générale du protocole d'État. Ce n'est pas une liste d'avantages, c'est la préséance de l'État noir sur blanc, et elle tranche une hésitation d'ordre. ℹ UN DIRIGEANT D'ENTREPRISE N'Y FIGURE PAS : il n'accède au salon qu'en accompagnant une personnalité habilitée, dans la délégation déclarée. (3) ET LA PROCÉDURE, QUI EN EST UNE VRAIE, directement utile à une assistance de direction : 48 HEURES avant pour une personnalité ivoirienne qui demande elle-même par courrier, 72 HEURES pour une personnalité étrangère dont la mission diplomatique adresse une note verbale, par fax ou courriel. La demande porte obligatoirement nom, titre, date et heure, compagnie, NUMÉRO DE VOL, provenance ou destination, et la composition nominative de la délégation. Accueil obligatoire au bas de la passerelle par un agent du protocole ET un porteur de badge ANAC. ⛔ LES COMITÉS D'ACCUEIL SONT STRICTEMENT INTERDITS D'ACCÈS aux salons : prévoir la délégation en conséquence. Les DEUX FORMULAIRES OFFICIELS sont dans la base, en .doc et en texte extrait, à remplir et transmettre en PDF à demandes@protocoledetat.diplomatie.gouv.ci. ⛔ CE QUI MANQUE, ET IL FAUT LE DIRE : les formules d'adresse dans une LETTRE D'AFFAIRES ordinaire, à un directeur général, un préfet, un maire. Rien d'officiel ne les fixe et ce qui circule vient de guides commerciaux. Elles se relèveront sur des courriers réels.

## Fournisseurs

### CL-DJENEBA-14 · Traiteurs, salles, hôtels et transporteurs de confiance
- **Pourquoi** : Organiser sans carnet
- **Où chercher** : Carnet de la maison, devis réels
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Interne. Le carnet de prestataires se constitue sur prestations réelles. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. Une recherche Drive sur « traiteur », « prestataire » et « devis » ne ramène que mes propres documents et les transcripts du salon : aucun carnet n'existe.

## Documents

### CL-DJENEBA-15 · Les pièces à réunir pour un déplacement ou une signature
- **Pourquoi** : Découvrir une pièce manquante la veille
- **Où chercher** : Services administratifs
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://servicepublic.gouv.ci/
- **Mis à jour** : 17/09/2026
- **Commentaire** : PARTIELLEMENT OUTILLÉ. Sa compétence preparation-deplacement (Y0376) couvre la méthode et interdit explicitement d'inventer un horaire, une durée de trajet ou une exigence de visa non vérifiée. ℹ Une note interne prétendait que cette compétence nomme LOKOLI : c'est faux pour elle, le catalogue en porte trois variantes et Djénéba utilise la sienne, qui ne le nomme pas. CE QUI MANQUE : la liste réelle des pièces ivoiriennes par type de démarche, à relever sur servicepublic.gouv.ci démarche par démarche.

### CL-DJENEBA-24 · Les circuits de signature et de parapheur
- **Pourquoi** : C'est la cause la plus fréquente d'un délai qu'on ne peut pas expliquer à sa direction
- **Où chercher** : Usages relevés chez les clients et dans l'administration
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Qui signe quoi dans une entreprise ivoirienne, dans quel ordre, avec quelles pièces jointes, et combien de temps ça prend.
