# 260922_Protocole ivoirien - ordre d'adresse, preseance et salons d'honneur

===== onglet t.0 · Tab 1 · 34 lignes non vides =====

# Protocole ivoirien : l'ordre, les titres, et l'accès aux salons d'honneur
Constituée le 22/09/2026. Elle sert deux gestes très différents : s'adresser aux autorités dans le bon ordre, et faire accéder un dirigeant au salon d'honneur de l'aéroport. Les deux se ratent de la même façon, en croyant qu'il s'agit de politesse alors qu'il s'agit de procédure.

⛔ Sauter un rang ou saluer un absent est la faute la plus visible. Elle ne se rattrape pas, et elle est lue comme un message.
## 1. L'ordre protocolaire d'adresse
Relevé mot pour mot sur un discours du Premier ministre en Conseil des ministres du 24 janvier 2026, source officielle de la Primature :

Excellence, Monsieur le Président de la République ; Monsieur le Vice-Président de la République ; Monsieur le Vice-Premier Ministre ; Mesdames les Ministres d'État ; Mesdames et Messieurs les Ministres ; Madame la Secrétaire Générale de la Présidence de la République ; Mesdames et Messieurs ;

Ce qui s'en retient :

- « Excellence » précède le titre pour le seul chef de l'État. Les autres non.
- L'énumération descend sans saut : Président, Vice-Président, Vice-Premier ministre, ministres d'État, ministres, puis les hautes fonctions administratives.
- Elle se ferme toujours par « Mesdames et Messieurs », qui recueille le reste de la salle. C'est la seule place légitime de cette formule.
- Chaque ligne se termine par un point-virgule.
- Après l'énumération, on reprend la personne principale sur une ligne seule, et cette reprise revient à chaque charnière.

Quand on n'est pas au sommet de la liste, on commence à l'autorité la plus élevée réellement présente et on suit la même descente : Premier ministre, ministres d'État, membres du gouvernement, corps constitués, autorités préfectorales et municipales du lieu, autorités religieuses et coutumières quand la cérémonie est décentralisée, partenaires techniques et financiers, puis « Mesdames et Messieurs ».

⚠ Les autorités coutumières et religieuses ne s'omettent jamais dans une cérémonie en région. C'est l'oubli le plus fréquent d'un texte préparé à Abidjan.

⚠ En cas de doute sur la présence effective d'une autorité, on la retire.
## 2. La hiérarchie de l'État, telle que le protocole la fixe
La Direction générale du protocole d'État publie la liste des personnalités habilitées aux salons d'honneur de l'aéroport Félix Houphouët-Boigny. Ce n'est pas une liste d'avantages, c'est la hiérarchie officielle écrite noir sur blanc, et elle sert à trancher un ordre de préséance quand on hésite.

Pavillon présidentiel : le Président et le Vice-Président de la République · les souverains · les chefs d'État · les chefs d'exécutif de pays tiers · les princes héritiers · les vice-présidents en exercice · le Secrétaire général des Nations unies · le président de la Commission de l'Union africaine · les anciens chefs d'État. Conjoints compris.

Salon ministériel : le président de l'Assemblée nationale · le Premier ministre · les présidents des institutions de la République · les ministres d'État · les ministres · le président de la Commission de la CEDEAO · le président de la Commission de l'UEMOA · le gouverneur de la BCEAO · le président, les vice-présidents et les administrateurs de la BAD · les hautes personnalités étrangères en visite ou en transit · les secrétaires généraux et adjoints de la Présidence et du Gouvernement · les directeurs de cabinet et adjoints du Président et du Premier ministre · les gouverneurs de district · les chefs de missions diplomatiques et d'organisations internationales. Conjoints compris.

ℹ Un dirigeant d'entreprise n'y figure pas. Il n'y accède qu'en accompagnant une personnalité habilitée, dans la délégation déclarée.
## 3. La procédure d'accès, qui est une vraie procédure
|  | Personnalité ivoirienne | Personnalité étrangère |
| Qui demande | elle-même, par courrier | sa mission diplomatique ou son organisation internationale, par note verbale |
| Délai | 48 heures avant le départ ou l'arrivée | 72 heures avant |
| Voie | fax ou courriel à la Direction générale du protocole d'État | idem |

La demande doit mentionner, à la lettre : nom et prénoms · titre ou qualité · date et heure d'arrivée ou de départ · nom de la compagnie · numéro de vol · destination au départ · provenance à l'arrivée · et la composition de la délégation accompagnante, chacun avec son nom et sa qualité.

Accueil obligatoire au bas de la passerelle par un agent du protocole d'État et par le chef de mission ou un membre de l'ambassade muni d'un badge d'accès en cours de validité délivré par l'ANAC, l'Agence nationale de l'aviation civile.

⛔ Les comités d'accueil et de soutien sont strictement interdits d'accès aux salons d'honneur. Prévoir la délégation en conséquence.

Contacts : demandes@protocoledetat.diplomatie.gouv.ci · fax (+225) 20 32 77 00. Les deux formulaires officiels sont ici, formulaire-courrier-officiel-salon-honneur.doc et formulaire-note-verbale-salon-honneur.doc, avec leur texte extrait. Ils se remplissent et se transmettent en PDF.
## Ce que cette base ne contient pas
- ⛔ Les formules d'adresse dans une lettre d'affaires ordinaire : comment on écrit à un directeur général, à un préfet, à un maire. Rien d'officiel ne les fixe, et ce qui circule vient de guides commerciaux. ⟦à relever sur des courriers réels⟧
- Le décret de préséance lui-même, qui existe probablement et n'a pas été retrouvé. La liste des salons en est un reflet, pas la source. ⟦à chercher⟧
- Les formules d'ouverture et de clôture d'un discours, qui sont dans le corpus de discours institutionnel tenu par ailleurs.

À recontrôler le 22/03/2027, et à chaque remaniement : la liste des titres suit la composition du gouvernement.
