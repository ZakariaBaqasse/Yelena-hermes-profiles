# 260922_Jours feries en Cote d'Ivoire - liste et regime

===== onglet t.0 · Tab 1 · 65 lignes non vides =====

# Jours fériés en Côte d'Ivoire, ce qui est établi et ce qui ne l'est pas
Arrêté le 26/08/2026, réécrit le 22/09/2026 après lecture des deux décrets. Trois niveaux à ne pas confondre : férié, chômé, payé. Un jour peut être férié sans que la journée soit payée de la même façon pour tous.
## Les textes, et où ils sont
| Texte | Ce qu'il fait | Où il est |
| Code du travail, art. 24.2 | renvoie la liste à un décret, et pose deux jours fériés chômés et payés | code-du-travail-2015-532.txt |
| Décret 96-205 du 7 mars 1996 | la liste d'origine et tout le régime (art. 1 et 3 à 10) | jours-feries/decret-96-205-jours-feries-transcription.txt |
| Décret 2011-371 du 4 novembre 2011 | remplace le seul article 2, c'est-à-dire la liste | jours-feries/decret-2011-371-jours-feries.pdf et sa transcription |
| Convention interprofessionnelle de 1977, art. 64 et 65 | qui paie quoi, et les ponts | convention-interprofessionnelle-1977.txt |

⚠ Le décret 2011-371 ne touche que la liste. Le régime reste celui de 1996 : article 3 pour les jours payés, articles 4 à 7 pour les autres, article 9 pour les sanctions.
## Les deux jours qui tiennent de la loi
Art. 24.2 du Code du travail, repris à l'article premier du décret 96-205 : le jour de la fête nationale (7 août) et le 1er mai sont fériés, chômés et payés. Ces deux-là seulement tiennent de la loi. Tout le reste vient du décret, donc n'est que férié et chômé, et c'est la convention qui décide s'il est payé.
## La liste en vigueur, seize entrées
Article 2 nouveau du décret 96-205, tel que remplacé en 2011. Elle est le texte applicable, pas une liste d'usage :

- 1er janvier
- lundi de Pâques
- Ascension
- lundi de Pentecôte
- fin du Ramadan, Aïd-El-Fitr, Korité
- Tabaski, Aïd-El-Kébir
- 15 août, Assomption
- 1er novembre, Toussaint
- 15 novembre, Journée nationale de la Paix
- 25 décembre, Noël
- le lendemain de la nuit du Destin, Laïlatou-Kadr
- le lendemain de l'anniversaire de la naissance du Prophète, Maouloud
- le lendemain de la fête nationale et de la fête du travail si elles tombent un dimanche
- le lendemain de la fin du Ramadan si elle tombe un dimanche
- le lendemain de Noël si elle tombe un dimanche
- le lendemain de la Tabaski si elle tombe un dimanche
### Trois corrections que cette lecture apporte
⛔ Le 15 novembre manquait à notre liste. Il est à l'article 2 depuis 1996, maintenu en 2011, et nous ne l'avions pas : la liste que nous servions venait d'une page d'ambassade. Aucun texte abrogeant ce jour n'a été trouvé.

⛔ La règle du lendemain ne se limite plus à la fête nationale et au 1er mai. Depuis 2011, elle couvre aussi la Korité, Noël et la Tabaski. La note antérieure disait le contraire, en s'appuyant sur la même page d'ambassade. Trois jours fériés de plus, potentiellement, dans un calendrier de paie.

ℹ Le 7 décembre a disparu. Le décret de 1996 le retenait jusqu'au 7 décembre 2000 inclus, par ses propres termes ; la liste de 2011 ne le reprend pas.
### Deux pièges de lecture dans cette liste
- Pour la nuit du Destin et le Maouloud, c'est le lendemain qui est férié, pas le jour de la fête. Une erreur d'un jour est facile ici.
- Les entrées 13 à 16 sont conditionnelles. Elles ne créent rien les années où la fête ne tombe pas un dimanche.
## Payé ou non, c'est la convention qui tranche
Convention interprofessionnelle de 1977, art. 64, jours fériés chômés payés :

- 7 août et 1er mai, payés même s'ils tombent un dimanche ;
- puis 1er janvier, Korité, Tabaski, 1er novembre, Noël, Ascension, Assomption, sauf s'ils tombent un dimanche.

Ni le Maouloud, ni le lendemain de la nuit du Destin, ni le 15 novembre n'y sont. Ni les lundis de Pâques et de Pentecôte, que l'art. 65 range expressément parmi les jours seulement fériés et chômés. Pour ceux-là, si le salarié travaille : heures compensées heure pour heure ou payées au taux normal en sus du mois pour les mensualisés, majoration de 100 % pour les payés à l'heure.
### La condition de présence, art. 64 dernier alinéa
Pour avoir droit à la rémunération d'un jour férié payé autre que le 1er mai et le 7 août, le travailleur doit avoir accompli normalement la dernière journée avant et la première journée après. Une absence autorisée par un texte légal ou conventionnel ne fait pas perdre ce droit ; une absence non autorisée, si.
### Le pont du 7 août, art. 65
⚠ Quand le 7 août tombe un mardi ou un vendredi, la veille ou le lendemain est également férié et chômé. La convention l'impose, ce n'est pas une largesse de l'employeur. Un calendrier qui l'ignore se trompe d'un jour ouvré une année sur cinq environ.
## Ce que le régime de 1996 impose en plus
- Art. 3 pour les jours chômés payés : chômage obligatoire, salaire mensuel intact, indemnité égale au salaire perdu pour les payés à l'heure ou à la journée, et double paiement pour ceux qui travaillent dans un établissement qui ne peut pas s'arrêter.
- Art. 5 : les heures perdues sont récupérables, et les heures de récupération se paient au taux normal, pas en heures supplémentaires.
- Art. 6 : tout travail des moins de 18 ans est interdit ces jours-là.
- Art. 9 : les infractions sont des contraventions de 1re classe, de 2e classe quand elles portent sur la rémunération.
- ⚠ Art. 7 : le décret de 1996 interdit le travail des femmes ces jours-là sauf accord des intéressées. Disposition de 1996 à ne pas servir telle quelle comme règle RH : elle est en tension avec l'égalité posée par le Code du travail de 2015, et aucune vérification de son sort n'a été faite ici. ⟦à vérifier⟧
## Les fêtes mobiles ne se calculent pas, elles s'annoncent
Korité, Tabaski, Maouloud, nuit du Destin : le décret les nomme, il ne les date pas. Leur date est fixée chaque année par communiqué du ministère en charge de l'emploi, quelques jours avant. Aucune date future ne se prédit ici. Deux fériés ont été appris par la presse en août 2026, dont un la veille au soir. La seule méthode fiable est de relever l'annonce quand elle sort, et de ne jamais poser un rendez-vous sur une date supposée fériée ni supposée ouvrée sans l'avoir vérifiée.

Corollaire des entrées 14 à 16 : tant que la date de la Korité ou de la Tabaski n'est pas annoncée, on ne sait pas non plus si le lendemain sera férié. Le calendrier d'une année n'est complet qu'en fin d'année.
## Relevé des annonces constatées
| Date | Fête | Annonce | Traitement |
| samedi 15/08/2026 | Assomption | presse des 12 et 14/08, décret 2011-371 cité | dans la liste de l'art. 64, un samedi n'est pas un dimanche : chômé payé |
| mardi 25/08/2026 | Maouloud | communiqué du ministère de l'Emploi du 21/08, deux sources concordantes | hors liste de l'art. 64 : régime de rémunération de l'art. 65 |

À compléter à chaque annonce.
## Ce que cette fiche ne couvre pas
- Le point aveugle de paie : quand la Korité, la Tabaski ou Noël tombe un dimanche, le jour lui-même n'est pas payé au titre de l'art. 64, et le lendemain est férié et chômé par le décret. Le texte de la convention de 1977 est antérieur de trente-quatre ans à cette règle et ne dit pas s'il est payé. Ne pas trancher seul : c'est une question pour un conseil ivoirien ou pour l'inspection du travail.
- Les conventions sectorielles. L'article 2 réserve les « dispositions conventionnelles plus favorables » : mines, banque, transport peuvent ajouter. Voir conventions-sectorielles/.
- La fonction publique, qui a son propre régime d'absences.
- Le Journal officiel. Le décret de 1996 n'a pas été trouvé en version officielle : droit-afrique.com rend 403 et aucun site gouvernemental ne le publie. Notre copie est une transcription privée, signalée comme telle. Le décret de 2011, lui, vient du site du ministère de la Fonction publique avec la mention « copie certifiée conforme ».

Prochaine revérification : 22/03/2027, ou à la première annonce de fête mobile.
