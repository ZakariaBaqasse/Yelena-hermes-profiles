---
id: Y0254
name: synthese-meeting
description: "Transforme automatiquement une transcription de réunion (Fireflies ou équivalent) en dashboard interactif (6 onglets : synthèse exécutive, insights, décisions, actions, participants, timeline) et en email de synthèse épuré envoyé aux participants, zéro invention, zéro hallucination de date, emails exclusivement issus de la source validée."
bucket: C
tags: [Agent Tools, Data & Analytics]
version: 1
maj: 2026-09-09
---

# Synthèse de réunion

## Ce qu'il faut avoir sous la main
1. l'**URL de la transcription** (Fireflies ou équivalent) ;
2. la **liste exacte des emails des participants** destinataires (source de vérité, je n'en invente ni n'en déduis jamais).

Optionnel : titre de réunion, date, email expéditeur, emails en copie. Dès que j'ai les deux inputs obligatoires, je produis directement le dashboard et l'email, pas de plan intermédiaire, pas de confirmation avant d'agir.

## Process
### Étape 0 : Validation des inputs ⚠️ bloquante

1. `url_fireflies` : fourni, respecte `^https://app\.fireflies\.ai/view/.+$` (ou l'URL du connecteur retenu), longueur > 40 caractères.
2. `emails_participants` : fourni et non vide.
   - Si string : extraire tous les emails par regex `[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}`, ignorer virgules/espaces parasites.
   - Si array de strings : utiliser directement.
   - Si array enrichi `[{nom, email, role}]` : conserver la structure complète pour l'affichage, extraire le champ `email` pour l'envoi.
   - Normaliser (trim + lowercase), dédupliquer (logger un warning si doublons supprimés), valider le format de chacun (`.+@.+\..+`).
3. `metadata_optionnels` : valeurs fournies utilisées telles quelles ; sinon extraites/complétées aux étapes suivantes.

Si une validation obligatoire échoue → **STOPPER immédiatement**, retourner :
```json
{
  "status": "error",
  "etape": "VALIDATION_INPUTS",
  "champ": "url_fireflies | emails_participants",
  "message": "...",
  "details": { "valeur_recue": "...", "probleme": "..." },
  "action_requise": "..."
}
```

Log si OK : `✅ Inputs validés, URL: [url] · Emails: [N] fournis → [liste]`.

### Étape 1 : Récupération de la transcription ⚠️ bloquante

`[connecteur à brancher : récupération de la transcription (scraping de page ou API Fireflies/équivalent), titre, date, durée, participants, résumé, sujets, action items, transcription complète]`, timeout 30 s.

Extraction (avec fallback si absent) :
- **Titre** ← page/API, sinon `metadata_optionnels.titre_reunion`, sinon `"Réunion du [date]"`.
- **Date** ← page/API (format lisible, ex. « 23 janvier 2026 »), sinon `metadata_optionnels.date_reunion`, sinon date du jour.
- **Durée** ← metadata, sinon `"N/A"`.
- **Participants (source)** ← section Participants/metadata ; complétée ensuite par détection des speakers dans la transcription.
- **Résumé natif**, **sujets/topics**, **action items natifs** ← si disponibles, sinon `null`/`[]` (seront reconstruits à l'étape 2).
- **Transcription complète** : texte brut avec speakers identifiés, **minimum 500 caractères**.

Erreurs :
- **URL inaccessible** (404, réseau, timeout, accès refusé) → **STOPPER**, erreur `RECUPERATION_TRANSCRIPTION`.
- **Contenu incomplet** (titre OU transcription introuvable) → **STOPPER**, erreur `RECUPERATION_TRANSCRIPTION`.
- **Transcription courte** (< 500 caractères) → **continuer avec avertissement** : « analyse limitée, sections potentiellement incomplètes ».

Log si OK : `✅ Transcription récupérée, Titre / Date / Durée / [N] participants détectés / [N] caractères`.

### Étape 2 : Analyse & structuration

Génère toutes les données qui alimenteront le dashboard et l'email. Sources de vérité **exclusives** : transcription + inputs. Aucune donnée inventée, déduite ou supposée, absence → `"N/A"` / `"Non spécifié"`.

**Participants.** Pour chaque participant détecté (webhook + transcription) : nom complet (1re lettre majuscule), rôle (metadata → mentions type « X, CEO de… » → sinon `"Participant"`), entreprise (metadata → détection `"de [Entreprise]"` / `"chez [Entreprise]"` → sinon `"Non spécifié"`), initiales pour avatar (1re lettre prénom + 1re lettre nom, ex. « Awa Koné » → « AK »), temps de parole en % et minutes si détection des speakers possible. Grouper par entreprise (groupe la plus nombreuse d'abord, puis alphabétique ; sans entreprise → groupe « Autres participants »). Si format enrichi fourni, mapper les emails webhook aux noms pour affichage, sinon dashboard affiche tous les participants détectés indépendamment de la liste d'emails.

**Métriques.** Durée (metadata), nb participants (liste ci-dessus), 6 sujets, nb décisions/actions (comptage exact des éléments extraits ci-dessous, jamais arrondi), montant clé (uniquement si un montant/budget/levée est explicitement mentionné, sinon `null`).

**Sujets** (6 principaux). Sources : topics natifs si disponibles, sinon analyse sémantique de la transcription (thèmes récurrents regroupés, priorisés par temps consacré ou importance mentionnée). Par sujet : titre court, description 1-2 phrases fidèle au sens, 3-4 points clés.

**Décisions.** Mots-clés primaires : *décidé, acté, validé, go, on part sur, on valide, c'est bon pour* ; secondaires : *d'accord, ok pour, approuvé, confirmé*. Patterns : « [Sujet] est décidé », « On valide [action] », « Go pour [projet] », « C'est acté ». **Exclusions** : propositions (« on pourrait »), suggestions (« je suggère »), idées non validées. Par décision : titre court, contexte (2-3 phrases), responsable (règle stricte ci-dessus), échéance (mots exacts de la transcription), impact, classification automatique :
| Impact | Critères | Couleur |
|---|---|---|
| Critique | impact majeur, deadline < 1 semaine ou critique, ressources importantes engagées, risque élevé | rouge |
| Majeur | impact notable/structurant, deadline 1-4 semaines, changement de direction significatif | orange |
| Important | à suivre, deadline > 1 mois, impact modéré | jaune |
| Modéré | faible impact, pas de deadline pressante, décision opérationnelle mineure | bleu |

Si aucune décision → liste vide (le dashboard affiche le message dédié, ne rien inventer).

**Actions.** Mots-clés : *je vais, il faut que, action:, [nom] doit, [nom] va, à faire, TODO*. Description = verbe d'action + complément, résumée en 1 phrase claire et actionnable (ex. « Envoyer le pitch deck aux investisseurs », pas « Il faut qu'on pense à peut-être faire quelque chose »). Responsable/échéance : mêmes règles que les décisions. Priorité, classification automatique :
| Priorité | Critères | Couleur |
|---|---|---|
| Critique | bloquante pour la suite, deadline < 3 jours, mentionnée « urgent »/« critique » | rouge |
| Haute | importante non bloquante, deadline 3-7 jours, mentionnée « important »/« prioritaire » | orange |
| Moyenne | standard, deadline > 1 semaine, pas de mention d'urgence | bleu |

Dédupliquer : une action similaire à une décision déjà extraite n'est pas dupliquée. Si aucune action → liste vide.

**Insights.** Forces/opportunités (5-7, phrases affirmatives, catégories : expérience, innovation, réseau, financement, équipe, marché). Risques/défis (5-7, phrases identifiant clairement le risque, catégories : contraintes, dépendances, délais, ressources, compétition, exécution). Recommandations stratégiques (exactement 5, actionnables, verbe d'action, spécifiques au contexte, priorisées, titre + description 2-3 phrases). 3 cartes exécutives : Forces Principales (2-3, vert), Points d'Attention (2-3, orange), Opportunités (2-3, violet).

**Résumé exécutif** en 4 paragraphes : (1) Contexte & Objectif, qui, quoi, pourquoi, 2-3 phrases ; (2) Proposition de Valeur, 3-5 points chiffrés/différenciateurs avec badge d'impact ; (3) Décisions Stratégiques Majeures, top 3-4 en grille 2 colonnes, couleur selon impact ; (4) Prochaines Étapes Critiques, 3-5 bullets « [Emoji] [Action] ([Responsable] - [Échéance optionnelle]) ».

**Timeline.** 4-5 phases idéalement, sources = mentions explicites de périodes + séquencement (« d'abord/ensuite », « si/alors »). Par phase : titre, période (si mentionnée, sinon description), statut automatique (active = en cours/« actuellement » ; critical = deadline proche/urgence/risque de retard ; upcoming = « bientôt »/« prochainement » ; future = long terme), 3-5 items (objectifs/actions/livrables), progression % (valeur explicite si mentionnée ; estimée seulement pour une phase active sans info, avec log de l'estimation ; 0 % pour upcoming/future sans info). **Si aucune phase claire ne ressort de la transcription : ne rien inventer**, pas de génération de phases génériques.

**Note critique** : ne jamais tenter de faire correspondre les emails du webhook aux participants détectés, ce sont deux listes indépendantes par construction (dashboard = tous les participants détectés, email = liste webhook).

Log si OK : récap métriques + insights (voir logs de succès du prompt source, reformulables librement).

### Étape 3 : Génération du dashboard interactif

Génère le composant (code brut, sans wrapper markdown). Architecture **non négociable** : Hero → Navigation (6 onglets) → 6 blocs de contenu → Footer.

**Hero.** Gradient bleu → violet → indigo avec overlay motif de points, logo opérateur en haut à droite (`[connecteur/asset à brancher : logo opérateur]`), titre de la réunion, date + durée, 4 cartes métriques (durée · participants · décisions · montant **ou** actions si aucun montant mentionné).

> **Règle critique, gradients.** Les classes Tailwind `bg-gradient-*` peuvent être écrasées par les composants UI ou le mode sombre (fond blanc au lieu du gradient). Toujours utiliser un style inline avec des valeurs RGB explicites pour tout fond en gradient (hero, headers). Palette de référence : bleu `rgb(37,99,235)`, violet `rgb(147,51,234)`, indigo `rgb(79,70,229)`, bleu clair `rgb(59,130,246)`, violet clair `rgb(168,85,247)`. Pour un overlay motif : combiner `background` (gradient) et `backgroundImage` (radial-gradient de points, `backgroundBlendMode: overlay`).

**Navigation.** 6 onglets obligatoires : *Executive Summary · Insights · Décisions · Actions · Participants · Timeline*. Onglet actif = gradient bleu→violet, texte blanc, ombre ; inactif = fond neutre, hover léger.

**Onglet Executive Summary.** 3 cartes insight (Forces Principales vert / Points d'Attention orange / Opportunités violet) + résumé structuré en 4 paragraphes (voir étape 2) + graphique de répartition du temps de parole (barre de progression par speaker, % + minutes).

**Onglet Insights.** Grille 2 colonnes : carte Forces & Opportunités (verte, 5-7 items) / carte Risques & Défis (orange, 5-7 items) ; puis bloc Recommandations Stratégiques (5, numérotées, titre en gras + description).

**Onglet Décisions.** Timeline verticale, une carte numérotée par décision, couleur du cercle/badge selon l'impact (voir table étape 2 : 1=rouge, 2=orange, 3=jaune, 4+=bleu si plusieurs de même palier), titre + badge impact + contexte (2-3 phrases) + responsable + échéance. Si aucune décision : carte centrée « Aucune décision formelle n'a été identifiée dans cette réunion. »

**Onglet Actions.** 3 cartes métriques (actions totales / échéances proches / responsables) + liste de cartes actions, bordure et badge colorés selon priorité, description + responsable + échéance. Si aucune action : carte centrée « Aucune action spécifique n'a été identifiée dans cette réunion. »

**Onglet Participants.** Grille de cartes par organisation (header gradient, nom + nombre de participants), corps = liste avatars (initiales, dégradé) + nom + rôle + badge entreprise. Note d'information : « [N] participants détectés dans la transcription. L'email de synthèse sera envoyé aux [M] destinataires fournis. »

**Onglet Timeline.** Timeline verticale par phase avec indicateur coloré selon statut (active = bleu, anneau, icône éclair ; critical = rouge, anneau, pulsation, icône alerte ; upcoming = orange, icône horloge ; future = gris, icône cible), titre + période + badge statut + 3-5 items + barre de progression %. Si aucune timeline : carte centrée « Aucune timeline spécifique n'a été identifiée dans cette réunion. »

**Footer.** Date de génération + attribution « Propulsé par **[Nom opérateur]** ».

**Design system.** Icônes (lucide-react) : `Calendar, Clock, Users, Target, CheckCircle, ListTodo, TrendingUp, AlertCircle, Lightbulb, Rocket, DollarSign, Brain, Globe, Building2, FileText, ArrowRight, Zap, Shield, BarChart3, ChevronRight, Star, Award, User, Info`. Gradients nommés : primary (bleu→violet), hero (bleu→violet→indigo), subtle (gris clair), success/warning/danger/info (vert/orange/rouge/bleu clairs). Ombres `shadow-sm` → `shadow-2xl`. Arrondis `rounded-sm` → `rounded-full`. Espacements : sections `space-y-8/12`, items `space-y-4/6`, padding cartes `p-6/8`. Typo : hero `text-5xl/6xl font-bold`, titre section `text-3xl font-bold`, titre carte `text-xl/2xl font-bold`. Couleurs sémantiques : critique rouge-600, majeur orange-600, important jaune-600, modéré/info bleu-600/500, succès vert-600.

**Règles de génération** : code brut (aucun wrapper ```` ``` ````) ; utiliser 100 % des données extraites à l'étape 2, aucun placeholder vide (donnée absente → message dédié « si aucune… ») ; respecter le design system ci-dessus ; code indenté 2 espaces, peu de commentaires (sections principales seulement) ; transitions CSS (`transition-all duration-200`) sur les éléments interactifs. Participants sans organisation → groupe « Autres participants ».

### Étape 4 : Publication du dashboard & lien de partage ⚠️ bloquante

`[connecteur à brancher : génération/hébergement du dashboard interactif à partir du code du composant, production d'une URL publique consultable]`, timeout 30 s. Conserver l'URL pour l'email (étape 5).

Erreurs → **STOPPER** (un email sans dashboard n'a pas de sens) : échec de création (code invalide, erreur technique, timeout) ou création réussie mais lien de partage indisponible (permissions).

Log si OK : `✅ Dashboard publié, 🔗 [URL]`.

### Étape 5 : Génération de l'email de synthèse

Génère un email HTML épuré et concis (anciennement délégué à un agent de templating séparé, désormais produit directement par cette skill, mêmes règles) :

- **Objet** : « 📊 Compte Rendu : [Titre Réunion] - [Date] ».
- **Style** : épuré, **sans logo en entête**, focus sur la redirection vers le dashboard.
- **Synthèse** (en gras, < 150 mots) : objectif de la réunion + principaux sujets + résultat/décision principale.
- **Points clés** (en gras, 3-5) : insight ou décision majeure / métrique importante / opportunité ou force / risque ou défi principal / élément stratégique (optionnel).
- **Actions prioritaires** (3-5) : description (en gras) + responsable (en gras, ou « Non assigné »).
- **CTA** : « 📖 En savoir plus sur cette réunion » → lien du dashboard (étape 4) + description courte (« Accédez au compte rendu complet avec analyses détaillées, recommandations et timeline interactive »).
- **Signature** : « [Nom opérateur] » / « Assistant Réunions ».
- **Préférences visuelles** : pas de logo header, couleur CTA bleu, style minimal épuré, contenu court.

Validations avant usage : (1) absence de logo en entête, sinon warning, continuer ; (2) **lien du dashboard présent dans le CTA, critique, email inutilisable sans ce lien** ; (3) synthèse < 150 mots, sinon info, continuer ; (4) 3-5 points clés, sinon info ; (5) 3-5 actions, sinon info. En cas d'échec critique (impossible de produire un email exploitable), utiliser un template minimal de repli (synthèse brute + lien dashboard, sans mise en forme avancée) et logger le repli.

### Étape 6 : Préparation de l'envoi de l'email ⚠️ validation humaine requise avant envoi effectif

`[connecteur à brancher : envoi/dépôt de l'email (ex. Gmail ou équivalent), destinataires EXCLUSIVEMENT ceux validés à l'étape 0]`.

Destinataires : format simple → liste directe ; format enrichi → extraire uniquement le champ `email` de chaque objet. Paramètres : `to` (liste), `cc` (`metadata_optionnels.cc_emails` si fourni), `subject`, `body` (HTML étape 5), `from` (`metadata_optionnels.expediteur_email` sinon défaut opérateur).

Validations avant envoi : lien dashboard présent dans le HTML (critique, sinon logger l'erreur, ne pas envoyer) ; liste destinataires non vide (bloquant, ne devrait jamais arriver si étape 0 correcte) ; HTML basique valide (medium, warning si suspect).

Erreurs : échec technique d'envoi (auth, quota, taille, réseau) → **ne pas stopper** (le dashboard existe déjà et reste utilisable) → retourner un succès partiel avec `dashboard_url` + détail de l'erreur + destinataires prévus, action requise = partage manuel du lien ou nouvel essai. Emails rejetés par le connecteur d'envoi (format invalide côté connecteur) → filtrer, envoyer aux emails valides restants, logger les emails exclus.

Log si OK : `✅ Email prêt/envoyé, [N] destinataires · Objet · Lien dashboard inclus`.

### Étape 7 : Confirmation & sortie structurée

Afficher un récapitulatif lisible (dashboard : lien + 6 sections + date de génération ; participants détectés : total + liste ; métriques : durée/décisions/actions/sujets/timeline ; insights : forces/risques/recommandations ; email : destinataires + format + statut ; note d'incohérence participants/emails si applicable ; durée totale de traitement).

Sortie structurée (ex. pour un webhook amont) :
```json
{
  "status": "success",
  "timestamp": "ISO 8601",
  "duration_seconds": 0,
  "dashboard": { "url": "...", "sections_count": 6 },
  "participants": { "detected": 0, "names": [] },
  "metrics": { "duration": "...", "decisions": 0, "actions": 0, "subjects": 6, "timeline_phases": 0 },
  "email": { "sent_to": [], "recipients_count": 0, "status": "pending_validation | sent | failed" },
  "warnings": []
}
```

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- 🚫 **ZERO_INVENTION (bloquant)**, les emails des participants proviennent EXCLUSIVEMENT de l'input `emails_participants`. Interdiction formelle d'extraire un email de la transcription, de le déduire d'un nom/entreprise, d'utiliser un pattern `prenom.nom@entreprise.com`, ou de compléter une liste partielle. Si absent → **STOPPER** et retourner l'erreur (voir Cas limites).
- ✅ **Source unique**, `emails_participants` est la seule source de vérité pour les destinataires de l'email, quel que soit le nombre de participants détectés dans la transcription.
- 📊 **Dashboard ≠ email (comportement normal)**, le dashboard affiche **tous** les participants détectés dans la transcription ; l'email part **uniquement** aux emails fournis par l'input. Un écart entre les deux nombres n'est **pas** une erreur : le logger, continuer avec la liste d'emails comme référence pour l'envoi.
- 📅 **Zéro hallucination de date/chiffre**, n'extraire que les dates, échéances, montants et métriques **explicitement mentionnés**. Une formulation vague (« bientôt », « la semaine prochaine », « mi-février ») se **copie mot pour mot**, jamais convertie en date calendaire précise. Absence d'info → afficher `"N/A"` ou `"À définir"`, ne jamais estimer.
- 👤 **Responsable = lien explicite uniquement**, n'assigner un responsable à une décision/action que si un nom est explicitement lié à cette décision/action dans la phrase. « On valide le budget » → Non assigné (pas de nom cité), même si un nom apparaît ailleurs dans la réunion.
- ✍️ **Qualité rédactionnelle**, sur tous les textes générés (synthèses, décisions, actions, recommandations, email, dashboard) : phrases complètes avec articles, grammaire correcte, pas de style télégraphique ni de tournures génériques IA. S'applique à 100 % du contenu produit.
- ⚠️ **Validation humaine avant tout envoi sortant**, l'email de synthèse doit être **présenté à validation humaine avant expédition effective**. Le dashboard peut être généré et son lien communiqué librement ; l'envoi de l'email aux participants est l'action irréversible qui requiert un go explicite.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
| Situation | Étape | Comportement |
|---|---|---|
| `emails_participants` absent ou vide | 0 | **STOP**, erreur critique, ne jamais deviner un email |
| Emails au format invalide | 0 | Filtrer les invalides, logger, continuer avec les valides ; si aucun valide → STOP |
| `url_fireflies` invalide/inaccessible | 0/1 | **STOP**, erreur critique |
| Transcription < 500 caractères | 1 | Continuer avec avertissement, analyse limitée |
| Transcription vide ou < 100 caractères | 1 | **STOP**, erreur critique |
| Aucune décision détectée | 2/3 | Continuer, dashboard affiche le message dédié, email omet ou mentionne « aucune décision formelle » |
| Aucune action détectée | 2/3 | Continuer, même logique que ci-dessus |
| Aucune timeline claire | 2/3 | Continuer, message dédié, **ne jamais générer de phases inventées** |
| Génération de l'email en échec critique | 5 | Utiliser le template de repli minimal, logger le repli |
| Publication du dashboard échouée | 4 | **STOP**, un email sans dashboard n'a pas de sens |
| Envoi de l'email en échec technique | 6 | Ne pas stopper, succès partiel avec lien dashboard + détail erreur + action requise |
| Incohérence nb participants transcription ≠ nb emails webhook | 2/7 | Normal, logger, dashboard = tous les participants, email = liste webhook |

## Détails complémentaires
### Format d'entrée attendu

```json
{
  "url_fireflies": "string (OBLIGATOIRE), https://app.fireflies.ai/view/{meeting-id}",
  "emails_participants": "OBLIGATOIRE, string \"a@x.com,b@y.com\" OU array [\"a@x.com\",...] OU array enrichi [{\"nom\":\"...\",\"email\":\"...\",\"role\":\"...\"}]",
  "metadata_optionnels": {
    "titre_reunion": "string (sinon extrait de la transcription)",
    "date_reunion": "string ISO ou lisible (sinon extraite)",
    "expediteur_email": "string (sinon défaut opérateur, voir Configuration)",
    "cc_emails": ["array de strings, optionnel"]
  }
}
```

### Configuration (déployée pour l'entreprise)

> **Ce qui se règle au démarrage.** Le logo est celui de l'entreprise, le pied de page porte sa signature, et l'adresse d'expédition par défaut est son adresse de contact, avec une adresse de repli si la première est indisponible. `[datasource à brancher]` = mémoire des marques de l'entreprise et de leur jargon (noms exacts, jamais approximés).
>
> Pour installer la même chose ailleurs dans la maison, on remplace le logo, la signature, l'adresse d'expédition et la base de normalisation des noms par ceux de l'entité concernée, le reste du processus (validation, extraction, génération dashboard/email, garde-fous anti-invention) est inchangé.
