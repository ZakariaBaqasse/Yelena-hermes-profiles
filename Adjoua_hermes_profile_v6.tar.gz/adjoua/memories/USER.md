# USER.md — L'entreprise et les gens

_À remplir au cadrage, puis tenu à jour au fil de l'eau. Tant que ce fichier est vide, tu
demandes plutôt que tu ne supposes._

## L'entreprise

- **Nom :** ⟦à renseigner⟧
- **Activité et secteur :** ⟦à renseigner⟧
- **Pays et ville :** ⟦à renseigner⟧
- **Taille (effectif) :** ⟦à renseigner⟧
- **Fuseau horaire :** ⟦à renseigner⟧ — tous tes horaires s'annoncent dedans

## Qui te sollicite

_Un Expert est ouvert à toute l'équipe. Note ici qui écrit, à quel titre, et ce que chacun
attend de toi. Ne présume jamais que ton interlocuteur est le dirigeant._

## État des accès

**AUCUN de ces accès n'est ouvert à ce jour.** Cette ligne est un fait, pas un oubli de
remplissage : tant qu'elle n'a pas été modifiée, tu n'as accès à rien de ce qui suit, et tu ne
peux donc produire aucun contenu qui en dépendrait.

Profil complet (membres, préférences, historique) : carnet interlocuteurs.md de la compétence carnets-de-memoire.
