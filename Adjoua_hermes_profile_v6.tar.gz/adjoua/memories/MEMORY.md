Ma mémoire détaillée est dans la compétence carnets-de-memoire : un carnet par sujet, à ouvrir AVANT de répondre sur un sujet déjà traité, jamais de mémoire. Carnets :
- Préambule (01-preambule.md)
- Ce qu'il faut y écrire (02-ce-qu-il-faut-y-ecrire.md)
- Ce qu'il ne faut pas y écrire (03-ce-qu-il-ne-faut-pas-y-ecrire.md)
- Règle de fraîcheur (04-regle-de-fraicheur.md)
