# Conversion Adjoua (profil OpenClaw nettoyé, 25/09/2026) → profil Hermes

Source : l'archive OpenClaw nettoyée de Adjoua (v5 du 25/09/2026), et pour les automatisations et les
épreuves, le paquet `adjoua-yelema_v12`, passé dans le même nettoyage. Même arborescence que le profil Hermes
de référence de Koffi (v12). **Rien n'a été installé** : c'est un tar.gz à déployer.

## Mapping effectué

| OpenClaw (source) | Hermes (destination) | Note |
|---|---|---|
| `workspace/IDENTITY.md` + `SOUL.md` + `AGENTS.md` | `SOUL.md` (racine) | Fusionnés en un seul fichier avec frontmatter YAML (`name`, `description`, `version`, `lang`). |
| `workspace/MEMORY.md` | `memories/MEMORY.md` | Mémoire de départ vierge, elle se remplit chez le client. |
| `workspace/USER.md` | `memories/USER.md` | Fiche entreprise et interlocuteurs, à remplir au cadrage. |
| `workspace/HEARTBEAT.md` | `reference/HEARTBEAT-source-openclaw.md` | Pas d'équivalent silencieux natif : à recréer en cron `[SILENT]`. |
| `workspace/TOOLS.md` | `reference/TOOLS-source-openclaw.md` | Outils et accès attendus, à brancher par les connecteurs Hermes. |
| `workspace/skills/*` (117 dossiers) | `skills/adjoua/*` | Copiés à l'identique. |
| `epreuves/` du paquet | `reference/epreuves/` | Harnais de test, à utiliser en test manuel. |
| `jobs/*.md` du paquet | `cron/jobs-source-openclaw/` + `cron/jobs-hermes-ready/` | Horaires traduits en cron 5 champs, `NO_REPLY` → `[SILENT]`. |

## Ce qui a été retiré

- aucune clé, aucun identifiant de connexion
- la mémoire accumulée pendant les tests
- toute mention des entreprises et des personnes des tests, de l'équipe interne et des startups accompagnées
- les exemples de livrables du paquet : ils avaient été produits pour les entreprises de test

## À faire à l'installation

1. Déposer `SOUL.md` à la racine du profil, `memories/` dans le dossier memories.
2. Déposer `skills/adjoua/` dans le dossier skills du profil.
3. Recréer les automatisations comme crons Hermes (`deliver=origin`), prompts prêts dans `cron/jobs-hermes-ready/` :
   - Point de fin de journee : `0 18 * * 1-5`
   - Point recrutement hebdo : `0 7 * * 1`
   - Relance candidats en attente : `0 8 * * *`
   - Revision memoire : `0 18 * * 0`
   - Veille marche emploi : `0 9 * * 4`
4. Remplir `memories/USER.md` au cadrage avec le client.
5. Brancher les outils listés dans `reference/TOOLS-source-openclaw.md`.
