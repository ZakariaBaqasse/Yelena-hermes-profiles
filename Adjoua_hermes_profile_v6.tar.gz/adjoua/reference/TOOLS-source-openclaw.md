# TOOLS.md - notes propres à cette installation

Les compétences disent *comment* les outils marchent. Ici, ce qui est **spécifique à cette
machine** : les chemins, les comptes, les paquets présents ou absents. Une compétence qui
renvoie au « TOOLS.md du poste » renvoie à ce fichier.

## Fabriquer un document : l'interpréteur et les bibliothèques

⚠ Le Python du système **ne porte aucune bibliothèque bureautique**. L'appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est le mauvais interpréteur.

| Ce que je fabrique | Avec quoi |
|---|---|
| Word, présentation, tableur, PDF, lecture d'un document | `~/.venv-office/bin/python` |
| il porte | `docx` · `pptx` · `openpyxl` · `pandas` · `pypdf` · `weasyprint` · `markitdown` |
| Word ou deck côté Node (`docx-js`, `pptxgenjs`) | `NODE_PATH=~/.claude/outils-communs/node/node_modules node …` |
| Figer un document bureautique en PDF | `soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>` |

⛔ **`pandoc` n'est pas installé sur cette machine.** Toute recette qui en dépend est à écarter.
Lire un `.docx` : `markitdown` ou `python-docx`. Convertir en PDF : `soffice`, ci-dessus.

ℹ LibreOffice porte Calc, Draw et Impress, et Writer depuis le 22/09/2026. Si `soffice` répond
« source file could not be loaded », vérifier d'abord le paquet installé (`dpkg -l | grep
libreoffice`), pas le fichier.

⚠ **Sur une autre installation, rien de ceci n'est garanti.** Je vérifie avant d'affirmer, et
je dis franchement qu'un format ne se produit pas ici plutôt que de le remplacer en silence.

## Outils communs à tous les experts

- `outils/deposer-livrable.py` : dépose un livrable dans mon Drive, le nomme et l'inscrit à l'index.
- `outils/relire-sans-tics.py` : compte les marqueurs d'écriture de machine. Il signale, il ne corrige pas.
- `outils/ligne-etat.py` : la ligne d'état, tenue hors de mon tour.
- `outils/echapper-markdownv2.py` : échappe un texte pour Telegram MarkdownV2.

## Mes outils de recrutement (`tools/`)

Tous se lancent avec `~/.venv-office/bin/python`. Chacun part d'un fichier de contenu JSON
(dossiers `*-configs/`) : un même contenu donne le tableur, le Doc, le PDF et la page.

| Famille | Scripts |
|---|---|
| Cadrer le poste | `cadrage-docx.py`, `fiche-borne.py`, `fiche-docx.py`, `business-case-borne.py`, `guide-borne.py` |
| Diffuser l'annonce | `flyer-borne.py` (A4 + image WhatsApp), `flyer-reseaux.py` (trois formats réseaux) |
| Sourcer et trier | `sourcing-borne.py`, `tri-candidatures-xlsx.py`, `notation-candidatures-xlsx.py`, `vivier-xlsx.py`, `vivier-anonyme-xlsx.py` |
| Évaluer | `grille-borne.py`, `grille-multi.py`, `grille-evaluateurs-xlsx.py`, `comparatif-xlsx.py` |
| Approcher | `messages-borne.py`, `messages-xlsx.py` (défaut depuis le 23/09 : tableur, pas Doc) |
| Rémunérer | `cout-employeur.py` (charges CNPS), `its-ci.py` (brut / net), `smcc.py` (minimum catégoriel), `salaires-ci.py` (base Grey Search Africa), `note-remuneration-docx.py` |
| Engager | `lettre-docx.py`, `lettre-formelle-docx.py` (promesse d'embauche, engagement, avenant) |
| Piloter | `tableau-bord-xlsx.py`, `point-blocages-xlsx.py`, `point-recrutement-mail.py`, `point-frame.py`, `schema-etapes.py` |
| Mettre en forme et contrôler | `doc-generique-docx.py`, `references-docx.py`, `marque_docx.py` (logo de l'employeur), `controle-visuel.py` et `apercu-page.py` (avant remise) |

ℹ `comparatif-docx.py`, `messages-docx.py` et `kit-messages-docx.py` ne servent plus que si un
Doc est demandé EN PLUS du tableur. Les scripts propres à un dossier client ou à une épreuve
restent dans `tools/` mais ne sont pas des outils génériques.

## Services branchés (`integrations/`)

Recruitee (ATS), Unipile (WhatsApp et LinkedIn), profils LinkedIn, Emploi Afrique, Tally,
Frames (pages publiées), Google Workspace, Canva, Fireflies et transcription vocale, Brave
Search et Apify (facturés : Apify ne consomme rien sans accord). Chaque dossier porte son
`README.md` et son `check.py`.
