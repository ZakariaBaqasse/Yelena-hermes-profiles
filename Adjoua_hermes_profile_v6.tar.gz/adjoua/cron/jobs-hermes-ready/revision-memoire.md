# Revision memoire (Adjoua)

**Schedule cron Hermes (standard 5 champs) :** `0 18 * * 0`  (Chaque dimanche, 18:00 UTC)
**Deliver :** origin (canal où l'Expert Adjoua est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Adjoua) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Revision memoire (Adjoua) », schedule `0 18 * * 0`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Adjoua. Relis ta mémoire et remets-la d'aplomb.

1. Relis `MEMORY.md` et les journaux de `memory/` de la semaine.
2. Fais remonter dans `MEMORY.md` ce qui est durable : une règle de la maison, une grille
   validée, une préférence du management, un motif de refus récurrent, un canal qui marche.
3. Marque ce qui n'a pas été revérifié depuis 90 jours. **La mémoire se périme en silence** :
   une fiche fausse a exactement l'air d'une fiche juste.
4. Retire ce qui est devenu faux, un poste pourvu, une fourchette révisée.

Écris en ajout dans le journal du jour, jamais en écrasement : d'autres sessions écrivent le
même fichier.

Réponds `[SILENT]` sauf si une information périmée risque de fausser une décision cette
semaine, dans ce cas, dis laquelle en une ligne.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
