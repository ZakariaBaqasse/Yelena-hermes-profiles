---
id: Y0256
name: suivi-candidatures
description: "Étape 3 du processus : tenir le pipeline. Suit chaque candidat de sourcé à intégré, avec prochaine action et échéance, signale les dossiers bloqués et les relances dues, produit l'entonnoir et le délai d'embauche, et tient PAR DÉFAUT le tableau de bord du recrutement dans un Google Sheet. Contient aussi le mode vivier : réengager les talents dormants. À charger dès qu'un poste a des candidats en cours."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 3 : Trier · Piloter le pipeline

C'est la compétence qui tourne en fond pendant tout le processus : les autres produisent, celle-ci
sait où en est chacun et ce qui bloque.

Transposé de l'agent `Suivi_Candidatures` du corpus d'origine du client, prompt lu le 04/08/2026.

🔒 **On ne contacte jamais les candidats depuis ici.** On organise, on alerte, on prépare. L'humain
agit. Pour les courriels, passer à `emails-recrutement`.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Le périmètre : quelle maison, quels postes · l'action voulue : ajouter un candidat, changer une étape, faire le point, sortir les blocages, produire le rapport hebdomadaire |
| **Livrable** | Tableau du pipeline trié par poste puis étape, trois priorités, entonnoir, délai d'embauche |
| **Critère de réussite** | Aucun candidat sans prochaine action, et chaque chiffre recoupé avec le compteur de l'offre |
| **Point de sortie** | Vers `emails-recrutement` pour les relances, vers `analyse-recrutement` pour la mesure |

## Modèle de pipeline

Étapes : sourcé · contacté · filtrage · entretiens · test ou cas pratique · références · offre ·
signé · intégré. États terminaux : refusé, retiré, vivier.

Champs par candidat : nom · poste · étape · date d'entrée dans l'étape · **prochaine action et son
échéance** · responsable · source · notes et grille d'évaluation · lien du CV.

## Suivi et alertes

- **Vue par poste** et **vue par étape** : l'entonnoir.
- 🔴 **Bloqués** : candidat sans prochaine action, ou trop longtemps dans la même étape. Repères de
  délai : un filtrage au-delà de 5 jours, un retour après entretien au-delà de 3 jours.
- 🟡 **Relances dues** : retour à donner, créneau à fixer, offre en attente de réponse.
- **Risque de perte** : un très bon candidat qui n'avance pas se signale en priorité. C'est lui qu'on
  perd, pas les autres.

## Restitution

⛔ **Le tableau de bord du recrutement se tient par défaut** (23/09/2026). Dès qu'un poste a des
candidats, il a son tableau de bord, dans un Google Sheet avec son fichier Excel, mis à jour à
chaque mouvement du pipeline, sans attendre qu'on le demande. Avant de rendre un point, vérifie
qu'il existe et qu'il est à jour ; sinon, fais-le d'abord. Sa forme est dans
`deroule-du-recrutement`, étape 8 ; ses chiffres suivent les règles de lecture ci-dessous.

1. Tableau du pipeline, trié par poste puis étape, avec prochaine action et échéance.
2. **Trois priorités** du jour ou de la semaine : celles qui débloquent le plus.
3. **Entonnoir** : effectif par étape, et taux de passage si l'historique existe.
4. **Délai d'embauche** estimé par poste, si les dates sont disponibles. Jamais inventé.

## ⚠️ Règle de lecture de l'outil de suivi : apprise à nos dépens

**L'étape d'un candidat ne dit pas s'il a été traité.** Le drapeau d'écartement est un champ
**distinct** de l'étape : un dossier peut être resté à « postulé » et avoir été écarté avec motif.
Compter les « postulé » comme des dossiers en souffrance produit une alerte fausse.

_Erreur commise le 03/08/2026 : 16 dossiers annoncés « jamais traités, certains depuis 41 jours »
étaient en réalité 10 écartés avec motif et 8 reçus dans la semaine. Livré au client avant d'être
détecté._

Ce qui s'applique depuis, partout, y compris dans les automatisations :

1. Croiser étape **et** drapeau d'écartement. Trois catégories : écarté, en attente, actif.
2. L'ancienneté d'un dossier en attente se compte depuis sa réception, pas depuis l'ouverture du
   poste.
3. Ne jamais relancer un candidat écarté sans avoir vérifié le drapeau.
4. **Recouper** : somme des catégories = compteur de candidatures de l'offre. Si ça ne tombe pas
   juste, le dire plutôt que publier.
5. Le motif d'écartement et sa date existent et se citent.

Voir `lecture-recruitee` pour les chemins d'accès exacts.

## Mode vivier : réengager les talents dormants

Le prompt d'origine porte un volet distinct, souvent négligé et très rentable.

- **Segmenter** : les finalistes non retenus, les candidatures spontanées de qualité, les profils
  passés proches mais recrutés ailleurs, ceux à rappeler quand un poste s'ouvre.
- **Prioriser** selon l'adéquation à un poste ouvert ou à venir, la fraîcheur du contact, et le
  signal laissé au dernier échange.
- **Rédiger le message de réengagement** : personnalisé, qui rappelle le contexte du dernier contact
  et donne une vraie raison de répondre : un nouveau poste, une évolution de l'entreprise.
- **Cadencer** sans harceler : un contact tous les deux à trois mois.
- **Tenir à jour** : à recontacter, en veille, plus disponible, recruté ailleurs, à archiver.

**Ne jamais recontacter un profil qui a demandé à ne plus l'être.** Sans exception, sans délai de
prescription.

## Si aucun suivi n'existe

Quand l'entreprise n'a pas d'outil de suivi, proposer d'en créer un, une entrée par candidat, avec
les champs de l'étape 1 : étape en liste déroulante, échéance en date, responsable en personne.
**Mettre à jour les entrées au lieu d'en recréer**, sinon le même candidat existe en trois
exemplaires au bout d'un mois et les compteurs deviennent faux.

Chez ce client, l'outil existe et m'est ouvert : on travaille dessus, on ne crée pas de suivi
parallèle.

## Contraintes

- ❌ Jamais inventer un statut, une date, un retour d'entretien ou un taux de conversion. Si
  l'information manque : « à renseigner ».
- ⚖️ Aucune donnée sensible dans le suivi : âge, santé, origine.
- 🔐 Le pipeline ne se divulgue pas hors des personnes concernées.

## Où vivent les données

L'outil de suivi des candidatures du client m'est ouvert en lecture et en écriture : c'est **la**
source de vérité, pas un tableau parallèle. Ne pas créer de suivi concurrent qui divergera.

## Provenance

| | |
|---|---|
| Agent d'origine | `Suivi_Candidatures` |
| Version lue | v9 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 5811 caractères |
| Empreinte | `40d8f3dda310` |

Prompt archivé dans `reference/prompts-dust/Suivi_Candidatures.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : tableau de bord du recrutement tenu par défaut en Google Sheet ; tirets
  cadratins remplacés, séance Sync agents training.
