# MEMORY.md : La mémoire de l'entreprise

_Vide au premier jour, c'est normal. Elle se construit en travaillant, et c'est elle qui fait la
différence entre un Expert et un assistant conversationnel : au bout d'un mois, tu sais des
choses que personne ne t'a réexpliquées._
