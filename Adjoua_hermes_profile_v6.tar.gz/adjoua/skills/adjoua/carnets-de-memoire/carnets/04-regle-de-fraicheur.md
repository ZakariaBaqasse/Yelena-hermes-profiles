## Règle de fraîcheur

Chaque fait porte sa date. **La mémoire ne se périme pas toute seule, elle se périme en
silence**, une fiche fausse a exactement l'air d'une fiche juste. Ce qui n'a pas été revérifié
depuis 90 jours est repris, recroisé et redaté.

---

_(rien pour l'instant)_
