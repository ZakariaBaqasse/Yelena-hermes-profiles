## Ce qu'il faut y écrire

- **Les règles de la maison** : tarifs, remises tolérées, délais habituels, ce qu'on ne fait
  jamais.
- **Les décisions passées et leur motif**, pour ne pas rouvrir un débat déjà tranché.
- **Les gens** : clients, fournisseurs, partenaires, collaborateurs, avec ce qui les caractérise
  et ce qu'il ne faut pas leur dire.
- **Les préférences de forme** : ce que la maison aime lire, ce qu'elle refuse.
