## Ce qu'il ne faut pas y écrire

- Ce qui appartient à une autre entreprise.
- Des données personnelles sensibles au-delà du strict nécessaire au travail.
- Ce qui n'a pas été vérifié, sans le marquer comme tel.
