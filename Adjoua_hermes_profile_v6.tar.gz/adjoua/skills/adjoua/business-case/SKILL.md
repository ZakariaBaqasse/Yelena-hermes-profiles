---
id: Y0095
name: business-case
description: "Étape 4 du processus — évaluer par mise en situation stratégique. Transforme une fiche de poste en business case complet remis au candidat, en cinq phases, avec branding de l'entreprise et export synchronisé. Alternative au test pratique, pas son complément."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-04
---

# Étape 4 — Évaluer · Business case

**Alternative à `test-competences`.** Le business case sert les postes qui demandent une mise en
situation stratégique, commerciale, financière ou opérationnelle. Le test pratique sert les métiers
où le travail se montre directement. On choisit l'un des deux.

Transposé de l'agent `Business_Case` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | La fiche de poste, collée, en lien ou en document · les missions à tester si le manager en a en tête · puis, en phase 4 : logo, nom de l'entreprise, couleurs · échéance, destinataires, format attendu, lien de rendez-vous si présentation orale |
| **Livrable** | Le business case remis au candidat, en page interactive brandée et en PDF, contenus identiques |
| **Critère de réussite** | Le livrable du candidat est potentiellement utilisable par l'entreprise, et faisable en 3 à 7 jours |
| **Point de sortie** | Vers `grille-evaluation` puis `evaluation-candidat`. ⚠️ Envoyer le cas au candidat est une **action à validation humaine** |

## Philosophie

- **Évaluer par la pratique** : tester les compétences réelles, pas les diplômes.
- **Contextualiser** : refléter l'environnement réel du poste, l'écosystème local, les enjeux
  concrets.
- **Laisser de la place à la créativité** : pas de sortie de secours, la partie créative est libre.
- **Rester inclusif** : accessible à des profils divers, avec des attentes claires.
- **Générer de la valeur** : le candidat produit quelque chose d'utile.

## Les cinq phases

### Phase 1 — Collecte et analyse de la fiche

- Si la fiche arrive en PDF : **en extraire le texte avant toute analyse**, étape obligatoire.
- **Chercher les fiches et business cases existants** pour la même entreprise ou un poste similaire,
  et s'aligner sur leur ton, leur structure et leur niveau **avant** de démarrer.
- Analyser : compétences clés à évaluer, contexte de l'entreprise et du projet, niveau d'autonomie
  attendu, collaborations transverses.

### Phase 2 — Génération du contenu

Structure obligatoire :

- **Titre** : « Business case — <intitulé du poste> ».
- **Contexte** : présentation de l'entreprise et du projet, enjeux du poste, liens cliquables vers
  les ressources.
- **Objectifs** : ce qu'on évalue et les compétences testées.
- **Missions, deux à quatre** : chacune un bloc numéroté distinct, avec objectif clair, livrables
  attendus précis, tâches concrètes, critères de réussite.
- **Instructions de soumission** : format, échéance, destinataires, critères d'évaluation — laissés
  en attente à ce stade, complétés en phase 4.
- **Présentation finale** si le poste le justifie.

Règles : ancrer dans le réel avec des exemples du portefeuille et de l'écosystème · varier les
formats — analyses, productions créatives, prototypes, stratégies · difficulté calibrée sur 3 à 7
jours pour un candidat compétent · liens cliquables obligatoires.

### Phase 3 — Enrichissement, facultatif

Documents de référence, ressources pédagogiques, jeux de données ou fichiers supports, script de
brief vidéo. Proposer, puis créer si validé.

### Phase 4 — Branding et logistique

**Deux questions groupées, pas plus :**

1. **Branding** : le logo et le nom de l'entreprise. Les couleurs si elles sont connues, sinon on les
   relève sur le logo.
2. **Logistique** : échéance de soumission, destinataires, format attendu, lien de rendez-vous si
   présentation orale.

**Relever les couleurs sur le logo, ne jamais les deviner.** Méthode qui marche sur cette machine :
décodeur PNG en Python pur, aucune bibliothèque image n'étant installée. ⚠️ Un PNG en palette ne se
lit pas comme un PNG RGB — il faut résoudre les index par la table de palette, sinon on relève des
niveaux de gris sans rapport avec les couleurs réelles.

**Point de contrôle** : toutes les informations validées avant de passer à la phase 5.

### Phase 5 — Finalisation et export

1. Remplacer tous les champs en attente par les vraies valeurs, ajouter les contenus additionnels,
   vérifier que les liens fonctionnent.
2. **Page interactive brandée** aux couleurs et au logo de l'entreprise.
3. **PDF**.
4. ⚠️ **Synchronisation obligatoire** : les deux exports portent exactement le même contenu, dans le
   même ordre de sections. Vérifier avant de livrer.

Puis le récapitulatif : échéance · destinataires · format · lien de présentation · nombre de missions
et compétences évaluées.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine — tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Missions par famille de poste

| Famille | Exemples de missions |
|---|---|
| **Investissement** | Analyse de startups, proposition de flux d'affaires, plan d'accompagnement d'une participation |
| **Technique, données, IA** | Créer un agent avec sa démonstration, automatiser un flux de travail, produire un tableau de bord |
| **Communication, événementiel** | Concevoir un événement complet, calendrier éditorial avec publications rédigées, campagne d'influence |
| **Juridique, finance** | Modéliser une table de capitalisation, annoter un contrat, proposer une structure juridique |
| **Commercial, opérations, produit** | Modèle économique, analyse concurrentielle, feuille de route produit ou plan de mise sur le marché |

## Business cases de référence — ce qui rend un cas bon

Quatre cas réels cités dans le prompt d'origine, avec ce qui fait leur qualité. À regarder avant
d'en écrire un nouveau.

| Cas | Ce qui le rend bon |
|---|---|
| **Investissement** | Contexte riche avec les participations détaillées · trois missions alignées sur le poste : représentation, flux d'affaires, accompagnement · questions ouvertes qui appellent une stratégie · instructions précises : format, destinataires, échéance · critères d'évaluation explicites |
| **Stagiaires IA et données** | Trois missions techniques à livrables précis · objectifs mesurables : un agent qui fonctionne, un tableau de bord complet, une automatisation opérationnelle · références externes fournies · présentation orale prévue |
| **Événementiel et communication** | Quatre blocs thématiques · mélange de questions stratégiques et de productions concrètes — une affiche, des publications, un calendrier · liberté de format · liens cliquables obligatoires |
| **Direction juridique** | Quatre volets très spécialisés · **documents fournis en annexe** — contrats types, accords d'investissement · livrables précis : table de capitalisation modélisée, contrat annoté · restitution orale d'une heure avec la direction · lien de prise de rendez-vous |

Le point commun des quatre : **le candidat reçoit de la matière** (documents, données, références),
et il sait exactement à quoi il sera jugé.

## Principes qualité

- **Pertinence** : tester les compétences réelles. ❌ « Faites une présentation sur votre parcours »
  ✅ « Construisez le tableau de bord des indicateurs que vous suivriez à ce poste ».
- **Faisabilité** : réalisable en 3 à 7 jours sans ressources exceptionnelles. Si une mission demande
  des données, les fournir ou dire où les trouver.
- **Valeur générée** : le livrable devrait être potentiellement utilisable.
- **Clarté** : objectif explicite, livrables définis, critères d'évaluation pour chaque mission.
- **Workflow strict** : ⚠️ ne jamais produire les exports avant d'avoir collecté **et validé** la
  logistique. Aucun champ en attente ne survit à l'export final.

## Ce qu'un business case ne fait pas

Sa valeur prédictive est de **0,33**, et son apport au-delà d'un test d'aptitude générale est quasi
nul. _Source lue intégralement le 04/08/2026 : Schmidt, Oh et Shaffer._

**Un business case ne décide pas d'une embauche.** Il éclaire le raisonnement et alimente un
entretien ciblé. La décision se construit en combinant le cas, l'entretien structuré et la prise de
références.

Voir `REFERENTIEL.md` dans ce dossier pour les ancrages détaillés.

## Provenance

| | |
|---|---|
| Agent d'origine | `Business_Case` |
| Version lue | v18 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 13036 caractères |
| Empreinte | `08a60f59c185` |

Prompt archivé dans `reference/prompts-dust/Business_Case.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**
