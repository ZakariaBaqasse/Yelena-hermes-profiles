# Référentiel — business case candidat

Un business case n'est pas une question d'entretien plus longue. C'est un **document autonome remis
au candidat**, qui lui donne assez de contexte pour produire un travail réel, et qui dit
explicitement ce qui sera évalué.

Le défaut constaté le 03/08/2026 : des business cases d'un paragraphe. Un paragraphe n'évalue rien,
il mesure la capacité à improviser.

---

## Ce qu'un business case doit contenir — la structure, non négociable

### 1. Le contexte (une page)

Le candidat doit pouvoir travailler **sans avoir travaillé chez vous**. On lui donne :

- L'entreprise, son marché, sa taille, son modèle — en clair, pas en jargon interne
- La situation précise sur laquelle porte le cas, avec des **chiffres**
- Ce qui a déjà été tenté, et pourquoi ça n'a pas suffi
- Les contraintes réelles : budget, délai, effectif, réglementation, saisonnalité

⚠️ **Les chiffres d'un business case sont soit réels et anonymisés, soit inventés et annoncés comme
tels.** Un chiffre inventé présenté comme réel se retourne à l'entretien, quand le candidat pose une
question de suivi et que personne ne sait répondre.

### 2. La question posée

Une seule question principale, formulée en une phrase, plus deux ou trois sous-questions. Un cas qui
pose six questions mesure la gestion du temps, pas la compétence.

### 3. Le livrable attendu

Format, volume, durée de préparation, mode de restitution. Exemple : « une note de trois pages plus
dix minutes de présentation, deux heures de préparation. » Sans ces bornes, on compare un candidat
qui y a passé une soirée à un candidat qui y a passé trois jours.

### 4. Les critères d'évaluation — communiqués au candidat

C'est le point le plus souvent oublié, et c'est celui qui change tout. On dit au candidat **ce qui
est évalué et avec quel poids**. Trois raisons :

- Un candidat qui sait ce qu'on cherche produit un travail comparable aux autres
- Cela oblige l'entreprise à savoir elle-même ce qu'elle cherche
- Cela protège d'une décision prise sur une impression après coup

### 5. Ce qui n'est pas attendu

Le dire explicitement évite les hors-sujets et rassure : « nous n'attendons pas un chiffrage
financier détaillé », « la forme importe peu, le raisonnement compte ».

### 6. Les conditions matérielles

Qui est présent à la restitution, combien de temps, ce que le candidat peut demander avant, à qui il
pose ses questions et sous quel délai.

---

## La grille qui accompagne le cas

Elle se construit **en même temps que le cas**, jamais après la restitution. Structure type :

| Dimension | Poids indicatif | Ce qu'on observe |
|---|---|---|
| Compréhension du problème | 20 | A-t-il identifié le vrai problème ou traité le symptôme |
| Structuration du raisonnement | 20 | Le cheminement se suit-il sans que l'évaluateur comble les trous |
| Maîtrise technique du domaine | 25 | Profondeur réelle sur le métier concerné |
| Réalisme et contraintes | 15 | La solution tient-elle avec le budget, l'effectif et le délai donnés |
| Restitution orale | 10 | Clarté, tenue face aux objections |
| Questions posées en amont | 10 | Un bon candidat interroge le cas avant de répondre |

**Éliminatoire, quel que soit le score :** inventer un chiffre pour combler un trou du cas. C'est le
comportement qu'on cherche le plus à détecter, et le cas doit contenir volontairement une donnée
manquante pour le tester.

---

## Le piège à tendre dans tout bon cas

Laisser **une donnée manquante et une donnée contradictoire** dans l'énoncé.

- Le candidat qui ne les voit pas manque de rigueur.
- Le candidat qui les voit et invente une valeur est disqualifié.
- Le candidat qui les signale et pose la question est celui qu'on cherche.

C'est le test le plus discriminant d'un business case, et il ne coûte rien à mettre en place.

---

## Calibrage par niveau de poste

| Niveau | Durée de préparation | Volume attendu | Nature du cas |
|---|---|---|---|
| Opérateur, technicien | 45 min sur site | Oral + geste | Mise en situation réelle sur machine ou document |
| Agent de maîtrise, Team Leader | 1 à 2 h | Note d'une page + oral | Incident de production à traiter, priorisation |
| Cadre, responsable de service | 2 à 4 h | Note de 3 pages + présentation | Diagnostic et plan d'action sur une situation dégradée |
| Direction, C-level | Une demi-journée | Document + présentation au comité | Choix stratégique avec arbitrage assumé |

⚠️ **Au-delà d'une demi-journée de travail demandé, on rémunère le candidat.** Un cas qui exige trois
jours de travail gratuit est un travail déguisé, et les bons candidats refusent.

---

## Le référentiel local

- Un business case **ne doit jamais faire produire au candidat un travail directement exploitable
  par l'entreprise** sans rémunération. C'est la ligne entre une évaluation et une prestation.
- Les données remises au candidat sortent de l'entreprise : elles s'anonymisent, et les éléments
  couverts par un secret d'affaires n'y figurent pas.
- Les critères d'évaluation étant écrits et communiqués, ils doivent être exempts de tout élément
  visé par l'article 4 du Code du travail ivoirien — voir le référentiel de la compétence
  `fiche-de-poste` pour le texte cité.

---

## État du corpus

⟦**Aucun business case du client n'a été fourni.**⟧ Demandé le 03/08/2026. Tant qu'il manque, les cas
produits sont construits sur la structure ci-dessus mais ne reprennent ni les situations réelles de
l'entreprise ni son niveau d'exigence habituel.

---

## Règle de forme — un livrable, un destinataire

Le business case remis au candidat **ne contient aucune note interne** : pas de réserve de méthode,
pas de commentaire sur ce qui manque, pas de barème détaillé au-delà des critères qu'on a choisi de
communiquer.

Deux fichiers, systématiquement :

| Fichier | Contenu | Destinataire |
|---|---|---|
| `<slug>_vN.pdf` | Le cas : contexte, question, livrable attendu, critères communiqués, conditions | Le candidat |
| `<slug>_vN_grille-interne.pdf` | La grille complète avec pondérations, les réponses attendues, les pièges volontaires et ce qu'ils révèlent | Les évaluateurs seuls |

Un candidat qui reçoit par erreur la grille interne connaît les pièges. Le cas est mort.
