---
id: Y0610
name: socle-drive-livrables
description: >
  Le Drive des livrables de l'expert : un dossier « Livrables » sous un dossier parent validé
  par l'utilisateur, une convention de nom AAMMJJ_Nom-du-document, et une feuille d'index qui
  centralise tout ce qui a été produit. À charger avant de remettre un livrable, et au premier
  démarrage sur un nouvel environnement.
version: 1
maj: 2026-08-26
---

# Le Drive des livrables

> **Demandé par Yelema, 26/08/2026 :** *« la création d'un drive (valider le dossier
> parent) où tous les livrables créés par l'expert IA peuvent être stockés avec en format la
> date de création AAMMJJ_Nomdudocument, avec en bonus un gsheet dans ce drive qui centralise
> aussi tous les livrables. »*
> Et, le même jour : *« si l'expert est déployé dans un autre environnement, il faudra créer
> un nouveau drive pour les livrables. »*

Un livrable qui vit dans le fil d'une conversation est perdu la semaine suivante. Le Drive
n'est pas un archivage de confort : c'est ce qui fait qu'un document se retrouve sans avoir à
redemander à l'expert.

---

## 1 · Le rite du premier démarrage

⛔ **L'expert ne crée jamais un dossier de livrables sans avoir fait valider le dossier parent.**
Déposer dans un espace que personne n'a choisi, c'est éparpiller des documents chez quelqu'un.

Sur un environnement neuf, à l'onboarding, demander :

> *« Où est-ce que je range ce que je produis ? Donne-moi le dossier Drive parent — je crée
> dedans un sous-dossier « Livrables » et la feuille d'index qui va avec. »*

Récupérer l'identifiant depuis l'URL du dossier — `drive.google.com/drive/folders/<IDENTIFIANT>` —
puis, une seule fois :

```bash
python3 outils/deposer-livrable.py --init --parent <IDENTIFIANT>
```

Ce que ça crée, et qui n'est plus jamais à refaire :

- le sous-dossier **`Livrables`** sous le parent validé (réutilisé s'il existe déjà) ;
- la feuille **`Index des livrables — <EXPERT>`**, dans ce sous-dossier, onglet `Livrables`,
  colonnes `Date · Fichier · Titre · Projet · Format · Lien · Déposé le` ;
- les identifiants, retenus dans `memory/state/drive-livrables.json`.

Pour savoir où on en est : `--etat`. S'il répond « aucun Drive configuré », le rite n'a pas
été fait — le faire avant de remettre quoi que ce soit.

---

## 2 · La convention de nom

**`AAMMJJ_Nom-du-document.ext`** — la date de création en six chiffres, un tiret bas, le nom.

| | |
|---|---|
| ✅ | `260826_Revue-de-presse-T3.pdf` |
| ✅ | `260826_Budget-previsionnel-2027.xlsx` |
| ⛔ | `revue_finale_v2.pdf` — pas de date, et « finale » ne veut rien dire |
| ⛔ | `2026-08-26 revue.pdf` — mauvais format de date, espaces |

Le tri alphabétique du dossier devient un tri chronologique : c'est tout l'intérêt, et c'est
pour ça que la date passe devant.

L'outil applique la convention tout seul — inutile de renommer à la main avant de déposer. Un
fichier déjà nommé au format est laissé tel quel.

⚠ **La convention Drive et le versionnage local sont deux choses différentes**, et elles
coexistent sans se gêner. En local, un livrable reste `<slug>_v<N>.<ext>` dans
`deliverables/<projet>/` : c'est ce qui permet de retrouver la dernière version. Sur le Drive,
il porte sa date : c'est ce qui permet de retrouver quand il a été rendu. Une nouvelle version
locale se dépose comme un nouveau fichier daté, elle n'écrase rien.

---

## 3 · Déposer

Un seul appel, à la fin de la production, avant d'annoncer le livrable :

```bash
python3 outils/deposer-livrable.py \
  --fichier deliverables/<projet>/<fichier> \
  --titre "Revue de presse T3" \
  --projet "veille" \
  [--convertir]
```

`--convertir` transforme le fichier en format Google natif à l'arrivée — un `.docx` devient un
Doc, un `.xlsx` devient un Sheet. À employer quand le document sera **travaillé à plusieurs**.
Sans ce drapeau, le fichier reste tel quel : c'est ce qu'on veut pour un PDF ou un livrable figé.

L'outil renomme, téléverse, **et ajoute la ligne à l'index** — les trois en un geste. Il rend
le lien : c'est ce lien qu'on donne, pas un chemin local que personne ne peut ouvrir.

---

## 4 · Ce qui se dépose, et ce qui ne se dépose pas

**Se dépose :** tout document fini remis à quelqu'un — rapport, note, revue, brief, tableur,
présentation, visuel livré.

**Ne se dépose pas :** les brouillons, les fichiers de travail, les notes internes de l'expert,
la matière ingérée (corpus, transcriptions, sources), et **tout ce qui porte une donnée
sensible** — un mot de passe, une clé, un identifiant. Un Drive partagé se lit par toute
personne qui a le lien.

**En cas de doute sur la sensibilité d'un document, demander avant de déposer.** Le dépôt est
difficile à défaire : le fichier a pu être vu, copié ou indexé entre-temps.

---

## 5 · Quand ça casse

L'outil ne se tait jamais. S'il échoue, il dit quoi vérifier :

```bash
python3 integrations/*/check.py
```

Deux pannes fréquentes, et ce qu'elles veulent dire :

- **le jeton Google a été révoqué** — l'autorisation vit dans un trousseau, pas au coffre ;
  elle peut être retirée depuis le téléphone de son propriétaire sans que rien ne change sur
  le disque. Il faut refaire l'autorisation ;
- **le dossier parent a été déplacé ou supprimé** — relancer `--init` avec un nouveau parent
  validé par l'utilisateur.

⛔ **Un livrable non déposé se signale.** Ne pas annoncer un document comme remis s'il n'est
que sur le disque : dire qu'il est prêt, et que le dépôt a échoué.
