---
id: Y0387
name: tableur-livrable
description: "Construit un tableur destiné au client — suivi, comparatif, modèle, extraction — pensé pour être utilisé et pas seulement regardé : en-tête figée, colonnes typées et formatées, code couleur déclaré, distinction stricte entre saisi / calculé / importé, source datée pour tout chiffre venu d'ailleurs, onglet de lecture, charte du client appliquée — sans jamais remplacer une donnée manquante par un zéro ou une valeur plausible."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Le tableur livrable — un fichier de chiffres qui se lit et se trie

## Ce qu'il faut avoir sous la main
- **L'objet du tableur** : suivi de quoi, comparatif de quoi, extraction de quoi — et à quoi ça va servir concrètement une fois reçu.
- **Qui va l'ouvrir** : le client final, un opérationnel, un comité — et sur quel logiciel (Excel, Google Sheets, autre) et dans quelle langue/format (virgule ou point décimal, devise, format de date).
- **Les données brutes** : le fichier source, l'export, ou les chiffres que tu as déjà en main — même en vrac.
- **La charte du client** si elle existe : couleurs, police, logo, gabarit déjà utilisé ailleurs.
- **Ce qui doit être calculé** dans le fichier (formules) versus ce qui est simplement saisi ou importé.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cadrer l'objet, le destinataire et le logiciel cible

Avant de poser une seule colonne, tu établis trois choses : ce que ce tableur doit permettre de faire (suivre, comparer, trancher, extraire), qui l'ouvre en premier et avec quelle familiarité du sujet, et sur quel logiciel il vivra. Un tableau conçu pour Excel avec des formules imbriquées complexes peut casser à l'ouverture dans Google Sheets ; un fichier destiné à un comité qui ne lira que la synthèse n'a pas besoin des mêmes onglets qu'un fichier destiné à un opérationnel qui filtrera ligne à ligne.

Le piège ici : traiter le tableur comme neutre vis-à-vis du destinataire. Un tableur n'est pas un objet technique, c'est une interface entre une donnée et une décision — le cadrage détermine tout ce qui suit.

### Étape 2 — Distinguer saisi, calculé et importé avant de poser la première colonne

Chaque donnée du fichier appartient à une seule des trois catégories, et cette appartenance doit être visible dans la structure — pas seulement dans ta tête : une colonne saisie manuellement, une colonne calculée par formule à partir d'autres colonnes du fichier, une colonne importée d'une source externe. Tu ne mélanges jamais les trois dans la même colonne.

C'est le piège le plus coûteux du métier : un fichier où un chiffre saisi à la main côtoie un chiffre calculé sans qu'on sache lequel est lequel devient, au bout de quelques mois, un fichier qu'on ne peut plus auditer — et un chiffre qu'on ne peut plus vérifier finit par être répété comme une vérité. Si tu ne sais pas dans quelle catégorie ranger une donnée qu'on t'a donnée, tu le demandes plutôt que de trancher au hasard.

### Étape 3 — Construire l'onglet Lisez-moi avant les onglets de données

Le premier onglet du classeur, toujours, est un onglet de lecture : l'objet du fichier en une phrase, le périmètre couvert, la date d'extraction ou de dernière mise à jour, les définitions des termes qui ne sont pas évidents pour quelqu'un qui n'a pas suivi le dossier, et — s'il y a une seule couleur porteuse de sens dans le classeur — sa légende complète.

Le piège : le code couleur privé. Du vert et du rouge posés dans un tableau sans légende ne veulent rien dire pour quiconque n'était pas présent quand on les a choisis — et six mois plus tard, tu ne t'en souviendras pas non plus. Toute couleur qui porte une information (statut, seuil franchi, alerte) se déclare noir sur blanc dans le Lisez-moi, jamais seulement dans un commentaire de cellule.

### Étape 4 — Formater pour que le lecteur n'ait rien à refaire

En-tête figée sur la première ligne de chaque onglet de données, largeur de colonnes ajustée au contenu, format de cellule qui correspond au type réel de la donnée (nombre avec séparateur de milliers, pourcentage, date, devise) — et ce format respecte la convention du destinataire, pas une convention par défaut. Un montant en francs CFA doit s'afficher comme tel ; une date doit suivre le format jour/mois attendu localement et pas être réinterprétée en mois/jour par un logiciel réglé sur une autre locale ; le séparateur décimal (virgule ou point) doit correspondre à ce que le destinataire ouvrira.

Le piège : livrer un export brut — six cents lignes sans en-tête figée, sans format homogène, sans largeur ajustée — en croyant avoir livré un tableur. Ce n'est pas un livrable, c'est une donnée transmise : celui qui la reçoit doit la retravailler avant de pouvoir s'en servir, et c'est précisément le travail qu'on te demandait de faire à sa place.

### Étape 5 — Tracer la source de toute donnée qui vient d'ailleurs

Toute valeur qui n'est pas produite dans le fichier lui-même (un chiffre importé d'un export, d'un rapport, d'une base tierce) porte une colonne — ou au minimum un commentaire de cellule — indiquant d'où elle vient et à quelle date elle a été relevée. Une donnée sans source tracée est une donnée qu'on ne pourra plus jamais vérifier, et c'est exactement le mécanisme par lequel un chiffre approximatif devient, avec le temps, un chiffre qu'on cite sans plus le questionner.

Si une donnée demandée n'a pas de source identifiable ou de valeur établie, la cellule reçoit `⟦à renseigner⟧` — jamais un zéro, jamais une estimation non signalée comme telle. Un zéro se prend pour un chiffre ; `⟦à renseigner⟧` ne se prend pour rien d'autre que ce qu'il est.

### Étape 6 — Synthèse, relecture et cohérence d'ensemble

S'il y a plus de deux onglets de données, tu ajoutes un onglet de synthèse qui agrège ou renvoie vers le détail — sans dupliquer de saisie manuelle qui pourrait diverger de la source. Tu relis ensuite l'ensemble du classeur en te mettant à la place du destinataire du premier message : est-ce qu'il comprend l'objet en ouvrant le Lisez-moi, est-ce qu'il peut trier sans casser une formule, est-ce qu'une couleur qu'il croise a bien sa légende quelque part.

Tu vérifies enfin qu'aucune formule ne référence une cellule vide sans que ce soit voulu, et qu'aucun `⟦à renseigner⟧` n'a été silencieusement remplacé par une valeur au fil de la construction — cette dernière vérification est celle qui protège le plus contre l'invention accidentelle.

## Format de sortie
- **Livrable** : un classeur comportant un onglet « Lisez-moi » (objet, périmètre, date d'extraction ou de mise à jour, définitions, légende des couleurs le cas échéant), un ou plusieurs onglets de données avec en-tête figée, colonnes typées et formatées selon la convention du destinataire, et une colonne ou un commentaire de source daté pour chaque donnée importée. Un onglet de synthèse est ajouté dès qu'il y a plus de deux onglets de données.
- **Distinction structurelle** : saisi, calculé et importé sont visuellement ou structurellement séparés (colonnes distinctes, en-têtes explicites) — jamais mélangés dans une même colonne.
- **Cellules non établies** : toute valeur non confirmée porte `⟦à renseigner⟧`, jamais un zéro ni une valeur plausible non signalée.
- **Mise en forme** : conforme à la charte du client quand elle existe (couleurs, police, logo) ; à défaut, une mise en forme sobre et lisible, signalée comme provisoire dans le Lisez-moi.
- **Longueur et structure** : proportionnées à l'objet — un tableau de suivi simple n'a pas besoin de la même profondeur qu'un modèle financier à plusieurs onglets, mais l'onglet Lisez-moi et les en-têtes figées sont non négociables dans les deux cas.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Toute donnée manquante est demandée ou marquée `⟦à renseigner⟧`.

## Règles
1. **Un export n'est pas un tableur.** Sans en-tête figée, sans format homogène, sans largeur de colonnes ajustée et sans onglet de lecture, ce que tu produis est une donnée transmise, pas un livrable — tu ne le présentes jamais comme terminé.
2. **Toute couleur porteuse de sens se déclare dans une légende.** Sur le même onglet, dans le Lisez-moi. Une couleur non déclarée est une information perdue dès que quelqu'un d'autre ouvre le fichier.
3. **Saisi, calculé et importé ne se mélangent jamais dans la même colonne.** La distinction doit être lisible dans la structure du fichier, pas seulement connue de celui qui l'a construit.
4. **Toute donnée importée porte une source et une date.** Une donnée sans origine tracée devient invérifiable — et c'est ainsi qu'un chiffre approximatif finit cité comme un fait établi.
5. **Les formats locaux ne sont pas un détail.** Devise, séparateur décimal, format de date : ils suivent la convention du destinataire, pas un défaut du logiciel. Un fichier mal formaté pour la locale du lecteur peut être réinterprété et devenir faux, pas seulement illisible.
6. **`⟦à renseigner⟧` remplace toujours le zéro par défaut.** Un zéro dans un tableur se prend pour un chiffre réel ; une cellule vide se prend pour un oubli. Seul `⟦à renseigner⟧` dit clairement que la valeur reste à obtenir.
7. **0 chiffre inventé.** Aucun total, moyenne, taux ou estimation n'est produit sans donnée source ou formule vérifiable. Un chiffre plausible non sourcé reste un chiffre inventé.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; l'envoyer au client, l'intégrer à un système ou l'utiliser pour une décision engageante est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre tableur traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les cellules non établies `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune charte graphique fournie** — tu produis avec une mise en forme sobre et lisible, tu le signales dans le Lisez-moi comme provisoire, et tu n'inventes pas de couleurs de marque.
- **Volume de données très important** — tu structures par onglets logiques plutôt qu'un onglet unique illisible, et tu ajoutes systématiquement l'onglet de synthèse.
- **Fichier existant à mettre à jour plutôt qu'à créer** — tu respectes la structure déjà en place sauf si elle viole une règle dure (pas d'en-tête figée, couleurs non légendées) ; dans ce cas tu le signales avant de corriger.
- **Donnée source introuvable ou connecteur inaccessible** — tu le dis explicitement, tu marques la cellule `⟦à renseigner⟧`, et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Sources contradictoires pour une même donnée** — tu exposes les deux valeurs et leur origine respective dans le fichier, et tu demandes l'arbitrage plutôt que de trancher seul.
- **Formules complexes demandées sur un logiciel cible incertain** — tu vérifies d'abord le logiciel de destination ; une formule qui casse à l'ouverture n'est pas un livrable utilisable.
- **Demande hors périmètre** (analyse, recommandation stratégique à partir des chiffres) — tu le dis en une phrase, tu livres le tableur, et tu orientes vers la compétence qui traite l'analyse.
- **Action sortante demandée** (envoi au client, publication, intégration à un système) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
