---
id: Y0718
name: remuneration-et-offre-ci
description: >
  Construire une rémunération et une lettre d'offre en Côte d'Ivoire : la convention
  collective du secteur commande les catégories et le salaire minimum de chaque catégorie,
  mais elle ne donne PAS le package (primes et avantages au-delà des planchers relèvent de
  l'entreprise) ; les congés se comptent en jours ouvrables, 2,2 par mois selon le Code du
  travail ; les avantages se proposent selon le niveau du poste puis se font valider ; ce
  que le poste « rapporte » ne se calcule que lorsque c'est mesurable. À appliquer dès qu'un
  salaire, une grille, un package ou une lettre d'offre est en jeu.
version: 2
maj: 2026-09-23
---

# Rémunération et lettre d'offre, en Côte d'Ivoire

> **Écrit le 22/09/2026 d'après le point de formation.** Trois corrections y ont été
> apportées coup sur coup, toutes du même genre : une réponse juste en général, fausse ici.

---

## 1. La convention collective commande, pas la moyenne du marché

Le Code du travail pose le socle. Ce qui fixe réellement les catégories, les minima par
catégorie et une partie des usages, c'est la **convention collective du secteur**. Commerce
et négoce, bâtiment et travaux publics, banque, industrie : ce ne sont ni les mêmes
catégories, ni les mêmes salaires catégoriels, ni la même manière de pratiquer.

**Le geste :** avant toute grille ou tout repère de salaire, tu demandes de quel secteur
relève l'entreprise, donc quelle convention s'applique. Puis tu raisonnes dans cette
convention, en la nommant dans ton livrable.

⛔ Sans la convention, un repère de rémunération est une moyenne de marché déguisée en règle.
Il se contestera au premier désaccord, et il aura tort.

### ⛔ La convention donne le salaire de base, pas le package (23/09/2026)

Rappelé en séance : la convention collective ne contient pas le package salarial. Elle donne
le **salaire minimum de la catégorie**, et quelques accessoires obligatoires calculés sur lui.
Tout le reste est à la discrétion de l'entreprise. Ce que dit le texte, lu dans la convention
interprofessionnelle du 19 juillet 1977
(`~/.claude/outils-communs/droit-travail-ci/convention-interprofessionnelle-1977.txt`) :

- article 47 : chaque travailleur est classé dans une catégorie, et les salaires de chaque
  catégorie sont fixés par une commission paritaire. Le montant ne figure donc pas dans la
  convention elle-même : il se lit dans le barème catégoriel et son arrêté de revalorisation
  (compétence `droit-du-travail-ci`, section 3 bis) ;
- article 53 : une prime de fin d'année au moins égale aux trois quarts du salaire minimum
  conventionnel mensuel de la catégorie ;
- article 55 : une prime d'ancienneté calculée sur le salaire minimum de la catégorie,
  2 % après deux ans, puis 1 % par année supplémentaire jusqu'à la vingt-cinquième ;
- article 56 : une indemnité mensuelle de transport, dont le montant est fixé par arrêté
  du ministre du Travail.

Ce sont des planchers. Le salaire réellement proposé au-dessus du minimum, le logement, la
couverture santé, le téléphone, une prime sur objectifs, la formation : c'est l'entreprise qui
les choisit, et ils se sourcent sur ce qu'elle pratique et sur le marché, jamais sur la
convention.

**Avant de remettre une proposition de rémunération, vérifie que** le livrable sépare deux
blocs : « Ce que la loi et la convention imposent » (catégorie, salaire minimum, primes
obligatoires, avec l'article et la source du barème) et « Ce que l'entreprise propose »
(salaire proposé, avantages, sources de marché). Aucun élément du second bloc n'est présenté
comme tiré de la convention. Sinon, ne remets pas.

⚠ La convention applicable dépend de la branche : voir
`~/.claude/outils-communs/droit-travail-ci/conventions-sectorielles/LISEZ-MOI.md` (mines et
carrières ont leur convention de 2023 ; pour les banques, une convention de 2025 existe et
n'est pas sur le disque).

## 2. Un repère de salaire ne s'appuie jamais sur une seule source

Un cabinet unique, aussi sérieux soit-il, n'est pas un marché. Tu croises au minimum la
convention collective, une référence sectorielle publiée, et ce que pratique l'entreprise si
elle accepte de le dire.

⛔ Aucun chiffre inventé. Un repère sans source ouverte n'est pas un repère, et une fourchette
vaut mieux qu'un chiffre unique qui fait croire à une certitude.

## 3. Les congés : des jours ouvrables, et la base se dit

Le Code du travail (loi n° 2015-532, article 25.1, texte sur disque dans
`~/.claude/outils-communs/droit-travail-ci/code-du-travail-2015-532.txt`) : « sauf disposition
plus favorable des conventions collectives ou du contrat individuel, le travailleur acquiert
droit au congé payé […] à raison de **2,2 jours ouvrables par mois de service effectif** ».
La convention interprofessionnelle de 1977 (article 69) reprend le même taux, en jours
ouvrables. C'est un plancher : la convention ou le contrat peuvent donner plus, jamais moins.

⛔ Corrigé le 23/09/2026 : cette section disait « environ 2,5 jours par mois en calendaire,
2,2 en ouvré ». Aucun texte sur disque ne porte ce 2,5, et le 2,2 du Code est en jours
ouvrables, pas en jours ouvrés. « Ouvrable » et « ouvré » ne sont pas le même compte : on
écrit le mot du texte. Le seul décompte en jours calendaires que portent nos textes est celui
des contrats d'expatrié de l'article 69 de la convention (5 jours calendaires par mois au
premier séjour, 6 à l'issue du second).

**Le geste :** tu écris toujours « jours ouvrables » à côté du nombre, et tu ajoutes les
majorations qui s'appliquent (ancienneté et situation de famille, article 25.2 : détail dans
`~/.claude/outils-communs/droit-travail-ci/CONGES-PAYES.md`). Un nombre de jours sans sa base
laisse croire à un avantage qui n'existe pas, ou en cache un qui existe.

## 4. Une offre n'est pas qu'un salaire

Le benchmark salarial est la partie la plus facile et la moins discriminante. Ce qui fait
accepter une offre, ce sont souvent les **avantages** : transport, logement, couverture
santé, téléphone, prime de fin d'année, aménagement du temps, formation. Deux d'entre eux ont
un plancher conventionnel (la prime de fin d'année, article 53, et l'indemnité de transport,
article 56, section 1) : l'offre peut aller au-dessus, jamais en dessous, et ce qui dépasse le
plancher est un choix de l'entreprise.

**Le geste, dans cet ordre :**
1. tu demandes à l'entreprise ce qu'elle pratique déjà, poste par niveau ;
2. tu proposes ce qui manque pour rendre l'offre compétitive au niveau visé ;
3. **tu fais valider avant d'écrire la lettre.** Un avantage annoncé qu'il faudra retirer
   coûte plus cher que l'absence d'avantage.

Les avantages se calibrent **selon le niveau du poste** : ce qui se propose à une direction
ne se propose pas à un premier emploi, et l'inverse décrédibilise l'offre.

## 5. La lettre d'offre part prête à signer

⛔ Une lettre remise avec des mentions entre crochets n'est pas prête à signer, quel que soit
le reste de sa qualité. Ce qui manque se demande avant, pas au moment de remettre. Si une
information n'arrive pas, tu remets une version explicitement annoncée comme intermédiaire,
et tu dis ce qui la bloque.

## 6. Ce que le poste « rapporte » : seulement quand c'est mesurable (23/09/2026)

Constaté en séance : des fiches et des offres calculaient ce que la personne recrutée allait
rapporter à l'entreprise pour tous les postes, en partant d'idées très générales, et certains
calculs étaient faux.

**Avant d'écrire un calcul de rentabilité d'un poste, vérifie que :**
1. le poste produit un résultat en argent **mesurable et attribuable** à la personne : poste
   commercial, développement commercial, rémunération à la commission, recouvrement. Pour un
   poste de support, de fonction ou de direction, pas de calcul : tu décris les indicateurs du
   poste et ce qu'ils permettent de suivre ;
2. chaque hypothèse est écrite (volume, panier moyen, taux de transformation, délai de montée
   en charge), avec sa source ou la mention « hypothèse à valider par l'entreprise » ;
3. le calcul a été refait une seconde fois par une autre voie, ou posé en formules dans un
   tableur, et les unités tiennent : mois ou année, brut ou coût employeur (compétence
   `droit-du-travail-ci`, section 5) ;
4. le résultat se présente en fourchette, comme un ordre de grandeur, jamais comme un chiffre
   unique qui ferait croire à une certitude.

Un point en échec : le calcul sort du livrable.

## Historique

- v2, 23/09/2026 : la convention donne le salaire minimum de la catégorie et quelques planchers,
  pas le package (articles 47, 53, 55 et 56 de la convention de 1977) ; congés corrigés en
  jours ouvrables d'après l'article 25.1 du Code du travail ; rentabilité d'un poste calculée
  seulement quand elle est mesurable, séance Sync agents training.
