---
id: Y0719
name: tri-de-cv-et-nuance
description: >
  Trier des candidatures sans conclure trop vite : recouper chaque CV retenu avec le profil
  public du candidat, ne jamais traiter une mention absente comme une compétence absente, et
  distinguer ce que dit le droit de ce que fait la pratique. À appliquer sur tout tri de
  candidatures et tout avis sur un dossier. Utiliser dès qu'un candidat est écarté.
version: 1
maj: 2026-09-22
---

# Trier des candidatures, et rester nuancé

> **Écrit le 22/09/2026 d'après le point de formation.** Deux remarques y ont été faites, et
> elles touchent la même chose : la confiance excessive dans un document unique.

---

## 1. Le CV n'est pas le candidat

Un CV est un document de vente, écrit à un moment, pour un poste, souvent pas le tien. Il
omet, il abrège, il hiérarchise autrement que toi.

**Le geste :** pour chaque candidat que tu retiens ou que tu t'apprêtes à écarter de peu, tu
regardes aussi **son profil public**. On y trouve régulièrement une expérience, une
certification, une recommandation ou une durée qui ne figurent pas sur le CV. Tu dis
explicitement ce que tu as trouvé d'un côté et pas de l'autre, et tu ne traites pas une
divergence comme un mensonge : le plus souvent, c'est une mise à jour.

## 2. Une mention absente n'est pas un zéro

C'est la faute de raisonnement la plus coûteuse du tri automatique. L'anglais n'apparaît pas
sur le CV : cela peut vouloir dire que le candidat ne le parle pas, qu'il a jugé son niveau
trop faible pour l'écrire, ou simplement qu'il a oublié.

**Le geste :** une compétence attendue et non mentionnée devient une **question d'entretien**,
jamais une note de zéro et jamais un motif d'élimination à elle seule. Tu l'écris comme telle
dans ton tableau : « non mentionné, à vérifier », pas « absent ».

⛔ Cela vaut doublement quand la compétence est courante dans le métier : personne n'écrit
qu'il sait se servir d'un téléphone.

## 3. Le droit dit le cadre, la pratique dit le reste

Sur une question de gestion des personnes, une réponse tirée du seul texte juridique est
souvent exacte et inutilisable. Le texte dit ce qui est permis ; il ne dit ni ce qui se fait,
ni ce qui se conteste, ni ce qui se négocie.

**Le geste, en trois temps :**
1. ce que dit le texte, cité ;
2. ce que fait la pratique dans le secteur et le pays, quand tu le sais et avec ta source ;
3. ce que tu recommandes, et le risque que ça porte.

⛔ Ne tranche pas catégoriquement un cas que le texte ne tranche pas. Un avis trop net sur un
sujet ambigu se retourne contre celui qui l'a suivi, et c'est lui qui en paiera le prix, pas
toi.
