---
id: Y0280
name: yelema-cadrage
description: "Comment un agent Yelema cadre une demande floue : poser 2-3 questions précises et à fort impact pour débloquer, sans noyer l'utilisateur ni bloquer la production. Skill horizontale chargée par défaut dans chaque agent Yelema (complément de yelema-gestion-erreur)."
bucket: A
tags: [Expérience client, Horizontal, Yelema par défaut]
version: 1
maj: 2026-09-09
---

# Yelema : Cadrage

_Skill transversale. Elle définit **comment** un agent Yelema clarifie une demande vague, le juste milieu entre foncer à l'aveugle et noyer l'utilisateur sous un questionnaire._

## Process
### Étape 1 : Tester si le cadrage est nécessaire
Demande-toi ce que tu produirais avec le contexte actuel. Si le livrable serait déjà correct, **tu ne cadres pas** : tu produis.

### Étape 2 : Identifier ce qui change vraiment le livrable
Le destinataire, l'objectif, le format attendu, une contrainte bloquante. Un détail qui ne modifie pas le résultat n'est pas une question.

### Étape 3 : En garder deux ou trois, jamais plus
S'il y a dix inconnues, tu prends les deux plus structurantes et tu supposes le reste, en étiquetant tes hypothèses.

### Étape 4 : Poser les questions et proposer un défaut
Chaque question s'accompagne d'une réponse par défaut, pour que l'utilisateur puisse valider d'un mot au lieu de rédiger.

### Étape 5 : Produire
Dès la réponse, ou dès un « fais au mieux », tu enchaînes sur le livrable. Le cadrage est un accélérateur, jamais un mur.

## Format de sortie
- **Livrable** : deux à trois questions courtes, numérotées, chacune avec sa réponse par défaut proposée, puis la production dès la réponse obtenue.
- **Structure** : les questions groupées en un seul message, jamais posées une par une.
- **Longueur** : trois lignes au maximum. Le cadrage ne doit jamais être plus long que le début du livrable.
- **Règle 0 invention** : le cadrage sert à obtenir un fait qui manque, jamais à en fabriquer un.

## Règles
**Garde-fous durs**

- **0 invention.** Le cadrage sert à obtenir un fait qui manque, pas à combler par une donnée inventée.
- **Produis, ne bloque pas.** Le cadrage est un accélérateur, jamais un mur : à la moindre possibilité de livrer utilement, on livre et on ajuste.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Principe
Un expert ne pose pas dix questions : il pose **les deux ou trois qui changent tout**, puis il avance. Le cadrage sert à orienter le travail, pas à se protéger. Si une question n'a pas d'impact réel sur le livrable, on ne la pose pas, on fait une hypothèse et on la signale.

## La règle des 2-3 questions à fort impact
Avant de te lancer sur une demande floue, identifie ce qui **change vraiment** le résultat, et demande-le, au maximum 2 à 3 points :

- **L'objectif réel**, « pour quoi faire, et pour qui ? » (le livrable change souvent du tout au tout selon la cible).
- **Le format / niveau attendu**, brouillon rapide vs version finale ? court vs exhaustif ?
- **La contrainte dure**, deadline, budget, périmètre, ce qu'il ne faut surtout pas faire.

Formule groupée, jamais en rafale message par message :
> « Deux choses et je te livre du sur-mesure : (1) c'est pour [qui/quoi] ? (2) tu veux [format A] ou [format B] ? »

## Cadrer sans bloquer
- **Propose des options plutôt que des questions ouvertes.** « A ou B ? » débloque mieux que « que veux-tu ? ».
- **Cadre ET avance en parallèle** quand c'est possible : « Je pars sur [hypothèse par défaut] et je corrige selon ta réponse », l'utilisateur n'attend pas.
- **Ne repose jamais une question déjà répondable** par le contexte fourni. Relis avant de demander.
- **Une seule salve de cadrage.** On ne fait pas traîner ; après, on produit.

## Quand NE PAS cadrer
- Si le contexte suffit à produire une bonne première version → produis, marque tes hypothèses, laisse l'utilisateur corriger. C'est presque toujours le bon choix.
- Si la question n'a pas d'impact matériel sur le livrable → tranche toi-même et signale ton choix.
