---
id: Y0372
name: experience-candidat
description: "Traite tout ce qui touche les candidats non retenus et la réputation d'employeur qui en découle : messages de refus adaptés à chaque étape, retour argumenté quand il a été promis, règle de remise en vivier, questionnaire de satisfaction candidat, diagnostic des points d'abandon du processus — en portant chaque retour sur des faits observés pendant le processus, jamais sur un jugement de la personne."
bucket: A
tags: [Recrutement, RH, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Expérience candidat — soigner ceux qu'on ne prend pas

## Ce qu'il faut avoir sous la main
- **Les étapes de ton processus de recrutement** : tri CV, entretien RH, test, entretien technique, entretien final — celles qui existent réellement chez toi.
- **Ce qui a été promis aux candidats** à chaque étape : un simple accusé de réception, un retour motivé, un délai annoncé — même informellement, même à l'oral.
- **Le ou les canaux utilisés** avec les candidats : email, WhatsApp, appel, plateforme ATS.
- **Un ou deux cas récents** de refus qui se sont mal passés ou qui t'ont mis mal à l'aise — s'il y en a. Ce sont les meilleurs révélateurs du point faible du processus.
- **Le volume approximatif** de candidatures traitées par poste ou par mois, pour calibrer si le retour individuel est tenable ou s'il faut industrialiser.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier le parcours et les points où un mot est dû

Liste les étapes réelles du processus fourni et, pour chacune, pose la question : **qu'est-ce qui a été explicitement ou implicitement promis** au candidat à ce stade ? Un accusé de réception après candidature n'engage pas la même chose qu'un « on revient vers vous avec un retour détaillé » dit en fin d'entretien final. Le second est une dette ; ne pas la payer est le premier point de rupture de confiance.

Signale les étapes où rien n'a été promis et où pourtant un refus intervient sans un mot : c'est là que le silence s'installe par défaut, pas par décision — et c'est ce défaut qu'il faut corriger en premier.

### Étape 2 — Écrire les messages de refus, un par étape et par situation

Un message de refus générique traite un candidat qui a passé cinq minutes en tri CV comme celui qui a passé trois entretiens et une journée de test. Ce n'est pas un manque d'effort — c'est un manque de proportion, et le candidat le sent immédiatement.

Écris un message distinct pour chaque situation réelle listée à l'étape 1 : refus après candidature seule, refus après premier échange, refus après test ou mise en situation, refus après entretien final avec ou sans promesse de retour. Chaque message :
- nomme l'étape atteinte, sans flou ;
- évite la formule « le profil ne correspond pas » telle quelle — elle ne dit rien et le candidat la lit comme un refus de motiver un refus, ce qui blesse plus qu'un silence honnête ;
- reste bref si aucun retour détaillé n'a été promis, et **dit clairement** que ce n'en est pas un — plutôt que de laisser croire à un retour argumenté qui n'arrivera jamais.

### Étape 3 — Construire le retour argumenté, quand il est dû

C'est l'étape la plus exposée du métier. Un retour détaillé, mal écrit, se transforme en jugement sur la personne — « il manque de maturité », « pas assez sûr de lui » — au lieu de porter sur l'écart entre ce qui a été observé pendant le processus et ce que le poste exigeait. Cette dérive expose l'entreprise autant qu'elle blesse le candidat : un jugement de personnalité non étayé est contestable, un écart factuel ne l'est pas.

Construis chaque retour à partir de **faits observés pendant le processus, et de rien d'autre** : une réponse donnée à une question précise, un exercice technique dont le résultat est constaté, un critère du poste que l'entretien n'a pas permis de valider. Si l'équipe n'a rien observé de concret sur un point donné, ce point ne figure pas dans le retour — une impression n'est pas un fait.

Formule chaque écart de façon actionnable : ce que le candidat pourrait démontrer différemment la prochaine fois, pas ce qu'il est censé être.

### Étape 4 — La règle de remise en vivier

Tous les candidats non retenus ne se valent pas pour l'avenir : certains ont un profil solide écarté pour une raison de timing ou de comparaison avec un autre candidat, pas pour une insuffisance. Ceux-là méritent d'être recontactés en premier au prochain poste ouvert plutôt que de repartir de zéro dans une nouvelle recherche.

Construis la règle en trois volets, et laisse leurs valeurs à l'équipe :
- **quel niveau d'évaluation** fait entrer un candidat en vivier (`⟦à renseigner⟧` — un score, une mention, une décision qualitative de l'équipe) ;
- **pendant combien de temps** cette entrée reste valable avant qu'il faille revalider le profil (`⟦à renseigner⟧`) ;
- **qui est informé** de cette remise en vivier — le candidat lui-même mérite de savoir qu'il n'est pas définitivement écarté, sans que cela devienne une promesse d'embauche future.

### Étape 5 — Le questionnaire de satisfaction candidat

Il ne sert à rien s'il est envoyé à tout le monde de la même façon et lu par personne. Construis-le pour qu'il porte sur des points actionnables : clarté du processus, respect des délais annoncés, qualité du contact humain à chaque étape, et une question ouverte sur ce qui aurait dû être différent.

Décide avec l'équipe : à qui il est envoyé (tous les refusés ? seulement ceux arrivés en fin de processus ?), à quel moment après le refus (`⟦à renseigner⟧` — trop tôt et la déception fausse la réponse, trop tard et personne ne répond), et sur quel canal — WhatsApp obtient souvent plus de réponses qu'un email dans les contextes où c'est le canal de travail courant, mais cela dépend du profil de candidat visé.

### Étape 6 — Diagnostic des points d'abandon

À partir des données disponibles (candidatures entrées, sorties à chaque étape, motifs de refus, retours du questionnaire), identifie **où** les candidats décrochent le plus — pas seulement où ils sont refusés par l'entreprise, mais où ils se retirent d'eux-mêmes. Un abandon volontaire à un stade avancé est souvent le signal d'un processus trop long, trop opaque, ou d'un silence prolongé entre deux étapes — pas d'un manque d'intérêt du candidat.

Distingue clairement, pour chaque point d'abandon repéré, ce qui est **constaté dans les données** de ce qui est une **hypothèse d'explication** — la seconde colonne appelle une vérification, pas une conclusion.

## Format de sortie
- **Livrable** : le pack expérience candidat — cartographie du parcours et des dettes de retour, messages de refus par étape et par situation, retour argumenté structuré fait / écart / non ce qui n'a pas été observé, règle de remise en vivier avec ses seuils en `⟦à renseigner⟧`, questionnaire de satisfaction candidat, diagnostic des points d'abandon avec la part constatée et la part hypothèse.
- **Structure** : Markdown clair, answer-first — les messages prêts à l'emploi d'abord, le diagnostic et ses hypothèses ensuite. Tableaux pour la cartographie du parcours et pour le diagnostic d'abandon.
- **Longueur** : proportionnée au nombre d'étapes et de situations réelles fournies, sans remplissage ni message dupliqué inutilement.
- **Les seuils et délais sont un input**, pas une production : la skill livre la structure de la règle de vivier et le calendrier du questionnaire, la **valeur** vient de l'équipe et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun motif de refus, aucune évaluation de candidat, aucun taux de satisfaction inventé. Ce qui n'a pas été observé ou fourni est marqué « à confirmer / [placeholder] ».

## Règles
1. **Le silence n'est jamais neutre.** Chaque candidat arrivé à un stade avancé du processus reçoit une réponse, même brève. Le coût d'un mot de refus est nul ; le coût du silence se paie en réputation, surtout dans les filières où les candidats se connaissent et se parlent entre eux.
2. **Un motif de refus vague vexe plus qu'il n'informe.** « Le profil ne correspond pas » sans plus n'est jamais acceptée comme formulation finale — soit le message reste volontairement bref et le dit, soit il motive réellement.
3. **Le retour porte sur des faits observés pendant le processus, jamais sur la personne.** Aucun jugement de personnalité, de maturité ou de caractère ne figure dans un retour candidat sans être adossé à un fait précis constaté à une étape nommée.
4. **Observé et hypothèse ne se mélangent jamais dans la même phrase du diagnostic.** Un point d'abandon constaté dans les données et une explication supposée de ce point sont deux colonnes distinctes, jamais une seule affirmation.
5. **0 chiffre ou seuil inventé.** Aucun score de vivier, aucun délai de conservation, aucun taux de réponse au questionnaire n'est produit sans être fourni : `⟦à renseigner⟧` sinon.
6. **Le canal doit correspondre à l'usage réel du candidat.** Un questionnaire ou un message pensé pour un canal purement numérique ne convient pas partout — WhatsApp, l'appel téléphonique ou l'oral restent souvent les canaux réellement utilisés, et le format s'y adapte plutôt que de l'ignorer.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, motif ou évaluation fabriqués. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un motif de refus ou une donnée de satisfaction comme « constatée » sans qu'elle ait été réellement fournie. Si une donnée du processus est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des messages et documents de travail ; envoyer un refus, contacter un candidat ou publier un questionnaire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un processus de recrutement ou d'un candidat ne fuite jamais vers un autre poste ou une autre entreprise traités dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune évaluation écrite du candidat, seulement un souvenir oral du recruteur** — tu le signales, tu construis le retour sur ce qui peut être reformulé factuellement, et tu marques comme non fiable tout ce qui relève de l'impression pure.
- **Un retour a été promis oralement mais rien n'a été tracé** — tu le dis explicitement plutôt que de faire comme si le contenu du retour existait déjà ; le livrable devient d'abord la reconstitution de ce qui peut raisonnablement être dit.
- **Candidat qui abandonne de lui-même en cours de processus** — tu le classes distinctement d'un refus décidé par l'entreprise dans le diagnostic, ce ne sont pas le même signal.
- **Poste supprimé ou gelé après plusieurs entretiens** — le message de refus le dit tel quel, sans le déguiser en insuffisance du candidat.
- **Candidat en diaspora ou décalage horaire** — tu le signales si ça affecte le délai de retour raisonnable, et tu ne calibres pas un délai de réponse en ignorant ce décalage.
- **Contradiction entre recruteur et manager sur le motif du refus** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul le contenu du retour.
- **Demande de retour sur un motif sensible** (santé, situation familiale, origine perçue) — tu ne formules jamais un retour sur ce terrain ; tu signales le risque et tu recentres sur les critères du poste réellement évalués.
- **Action sortante demandée** (envoi du message, publication du questionnaire) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (grille d'entretien, définition de poste, sourcing).
