---
id: Y0221
name: recrutement-linkedin
description: "Étape 2 du processus : sourcer les candidats sur les réseaux professionnels. Identifie 20 profils, les note sur 100 (compétences 40 · expérience 35 · secteur 25) et produit un message d'approche de moins de 300 caractères par profil, plus un tableur et un PDF. À charger quand le sourcing passe par les réseaux."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 2 : Sourcer · Réseaux professionnels

Un des deux canaux de sourcing, à choisir selon d'où viennent les candidats. L'autre est
`recherche-talents-ci`, qui interroge un vivier déjà constitué.

Transposé de l'agent `Recrutement_LinkedIn` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Trois, toutes obligatoires : la fiche de poste · la zone géographique (Côte d'Ivoire, UEMOA, diaspora, ou combinaison) · le niveau de séniorité (junior 0-3 ans, intermédiaire 3-7 ans, senior 7 ans et plus) |
| **Livrable** | 20 profils notés et justifiés, un tableur, un PDF de synthèse, un message d'approche par profil |
| **Critère de réussite** | Chaque note est justifiée en une ou deux phrases factuelles, et chaque profil a été **réellement ouvert**, pas déduit d'un extrait de résultat de recherche |
| **Point de sortie** | Vers `messages-personnalises` si l'approche demande plus de travail, puis vers `suivi-candidatures`. ⚠️ Contacter un candidat est une **action à validation humaine** |

## Les trois entrées bloquent

C'est le seul point du processus où le prompt d'origine demande explicitement de **s'arrêter** :

| Manque | Conduite |
|---|---|
| Fiche de poste | Bloquer et lister ce qu'il faut : titre, compétences, expérience, secteur |
| Fiche incomplète | Lister les manques et poser des questions ciblées |
| Zone non précisée | Proposer les quatre options |
| Séniorité non précisée | Proposer junior, intermédiaire, senior avec leurs bornes |

## Workflow

### 1. Analyse de la fiche

Extraire le titre, trois à cinq compétences clés au maximum, l'expérience requise, le secteur, la
zone et la séniorité confirmées. En déduire les mots-clés de recherche. Présenter l'analyse
brièvement avant de lancer le sourcing.

### 2. Sourcing

Requêtes du type `site:linkedin.com/in/ "<compétence>" "<titre>" "<localisation>"`, adaptées à la
zone : Abidjan ou Côte d'Ivoire pour le local, les capitales pour l'UEMOA, Paris ou Montréal plus la
nationalité pour la diaspora.

Trois à cinq recherches avec des combinaisons différentes, puis extraction des adresses de profils.

⚠️ **Ouvrir chaque profil.** Un extrait de résultat de recherche, un titre et deux lignes, ne
suffit pas à établir l'ancienneté réelle, les compétences ou l'employeur actuel. Pour chaque profil,
relever : nom complet, poste actuel, **employeur actuel du candidat** (pas l'entreprise qui recrute,
confusion fréquente), localisation exacte, compétences affichées, années réelles et intitulés
successifs, secteur, diplômes visibles. Profil inaccessible : le noter comme tel et le remplacer.

Viser 20 profils uniques, d'entreprises différentes, avec des informations complètes et récentes.

**Règle hors zone** : un profil situé hors de la zone demandée mais estimé au-dessus de 80/100 peut
être inclus avec la mention 🌐 hors zone stricte, dans la limite de 5 sur 20.

### 3. Notation sur 100

| Critère | Points | Barème |
|---|---|---|
| **Compétences techniques** | 40 | 40 = toutes les compétences clés plus certifications · 30-39 = la majorité avec pratique · 20-29 = partielles · 10-19 = bases · 0-9 = très éloigné |
| **Expérience pertinente** | 35 | 35 = alignée, postes similaires, progression cohérente · 25-34 = proche · 15-24 = suffisante · 5-14 = insuffisante · 0-4 = très insuffisante |
| **Secteur** | 25 | 25 = secteur exact sur plusieurs années · 18-24 = adjacent · 10-17 = transférable · 5-9 = éloigné · 0-4 = sans pertinence |

Lecture : 90-100 priorité absolue · 80-89 excellent · 70-79 solide · 60-69 exploratoire · sous 60 ne
pas prioriser. Chaque note est justifiée en une ou deux phrases factuelles.

### 4. Restitution

**Tableau** trié par note décroissante : rang · lien du profil · nom · poste actuel · employeur
actuel du candidat · compétences clés · expérience · localisation · zone (✅ ou 🌐) · note ·
justification.

**Fichiers** : un Google Sheet (et son fichier Excel) avec les mêmes colonnes, plus trois
colonnes de coordonnées, **e-mail, LinkedIn et numéro WhatsApp**, remplies quand l'information
est connue et laissées vides sinon (c'est le recruteur qui les complète, jamais une coordonnée
devinée), plus le message d'approche ; et un PDF de synthèse. Avant d'envoyer, vérifie que ces
trois colonnes existent ; sinon, ne remets pas (règle du 23/09/2026, détail dans
`deroule-du-recrutement`, étape 5).
⚠️ Jamais un bloc de texte à recopier : on produit les fichiers.

**Page interactive** triable et filtrable, proposée en option à la fin.

### 5. Messages d'approche

Un par profil. **Moins de 300 caractères, strictement.** Ton semi-formel, en français sauf profil
anglophone. La personnalisation porte sur **un** élément précis du profil : une compétence, une
expérience, l'employeur actuel. Structure : salutation, contexte de l'entreprise qui recrute,
accroche personnalisée, proposition d'échange.

Les messages figurent dans le tableur **et** dans une section dédiée.

### Prochaines étapes à proposer

- Au-dessus de 85 : contacter immédiatement.
- De 75 à 84 : sous 48 heures.
- De 60 à 74 : liste de veille.

## Moins de 20 profils trouvés

Ne pas livrer un lot amputé sans le dire. Expliquer pourquoi et proposer un choix lettré :
élargir la zone · assouplir la séniorité · accepter le résultat partiel.

## ✅ Le sourcing est opérationnel, via la passerelle d'extraction (04/08/2026)

La lecture directe d'un profil est impossible depuis cette machine : la page rend un écran de
connexion. **Le client a ouvert un accès à une passerelle d'extraction** qui contourne ce mur et rend
les profils complets. Testé le 04/08/2026 sur un cas réel : **25 profils en 22 secondes**.

### Ce qu'on obtient réellement par profil

Adresse du profil · nom · titre · localisation · poste actuel avec employeur · **expériences datées
avec leur durée** · formations et diplômes · compétences déclarées · langues · signal de recherche
active. Vérifié : renseigné sur 10 profils sur 10, sauf les langues (7 sur 10).

C'est exactement ce que la notation sur 100 exige. **La note peut donc être justifiée factuellement**,
ce qui n'était pas le cas avant.

### Méthode

Jeton dans le magasin de secrets. Outil de recherche de profils par critères : intitulé de poste,
localisation, séniorité, années d'expérience, entreprises actuelles ou passées, écoles, langues, avec
exclusions possibles.

```bash
source ~/.config/agents/secrets.env
curl -s -X POST -H "Content-Type: application/json" -H "Authorization: Bearer $APIFY_TOKEN" \
  -d @requete.json \
  "https://api.apify.com/v2/acts/harvestapi~linkedin-profile-search/run-sync-get-dataset-items"
```

Requête type : mode `Full` pour obtenir les expériences datées :

```json
{"profileScraperMode":"Full","searchQuery":"CTO OR \"Head of Engineering\"",
 "locations":["Côte d'Ivoire"],"maxItems":25,"takePages":1}
```

### Coût : à annoncer avant de lancer

0,10 USD par page de recherche, plus 0,004 USD par profil complet. **25 profils coûtent environ
0,20 USD.** Le compte est sur une formule plafonnée à 100 USD par mois ; au 04/08/2026, 29 USD
étaient déjà consommés sur le cycle en cours. Vérifier le budget restant avant un gros volume :

```bash
curl -s -H "Authorization: Bearer $APIFY_TOKEN" "https://api.apify.com/v2/users/me/usage/monthly"
```

### Cibler une diaspora : filtrer par école, jamais par langue

Constaté le 04/08/2026 : chercher « profils francophones à Paris, Londres, Montréal » remonte des
Français, pas des Ivoiriens de l'étranger. La langue du profil ne dit rien de l'origine.

**Ce qui marche** : filtrer par **école du pays d'origine** en excluant le pays de résidence.

```json
{"schools":["Institut National Polytechnique Félix Houphouët-Boigny","ESATIC",
            "Ecole Nationale Supérieure de Statistique et d'Economie Appliquée ENSEA"],
 "excludeLocations":["Côte d'Ivoire"]}
```

⚠️ Les valeurs de `profileLanguages` sont les libellés complets : « French », pas « fr ». Un code
langue fait échouer la requête.

### Trois pièges constatés

1. **Une requête large ramène du bruit.** « Directeur technique » remonte le BTP, les mines et
   l'assurance. Filtrer par intitulé précis, et trier ensuite sur les compétences réelles.
2. **La localisation seule ne suffit pas** pour la diaspora : chercher séparément sur les villes
   d'accueil.
3. **Le nombre d'expériences n'est pas l'ancienneté.** Certains profils listent douze lignes pour
   six ans. Lire les durées, pas le compte.

### 🔒 Données personnelles : ces gens n'ont pas postulé

C'est la différence de fond avec un tri de candidatures. Les règles, non négociables :

- Traitement **limité à ce recrutement**. Aucune donnée versée dans une base réutilisable ni dans un
  document destiné à un tiers.
- Le livrable de sourcing est **interne**, et porte la mention qu'il contient des données de
  personnes n'ayant pas candidaté.
- **Le contact reste une action à validation humaine.** On rédige les messages, on ne les envoie pas.
- Une personne qui demande à ne plus être contactée ne l'est plus jamais, sur aucun canal.

## Production des fichiers

Le tableur et le PDF promis à l'étape 4 sont réellement produisables : voir `production-fichiers`
pour la chaîne exacte. Jamais un bloc de valeurs à recopier.

## Ligne rouge

Envoyer un message à un candidat est une **action à validation humaine**. Les messages se préparent,
ils ne partent pas.

## Provenance

| | |
|---|---|
| Agent d'origine | `Recrutement_LinkedIn` |
| Version lue | v33 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 7748 caractères |
| Empreinte | `4125adc8adc7` |

Prompt archivé dans `reference/prompts-dust/Recrutement_LinkedIn.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : le tableur devient un Google Sheet avec colonnes e-mail, LinkedIn et
  WhatsApp, cases vides quand l'information manque ; tirets cadratins remplacés, séance Sync agents training.
