---
id: Y0478
name: la-langue-de-l-interlocuteur
description: "Répond dans la langue du message reçu, produit un document dans la langue de son destinataire (pas de son commanditaire), et ne traduit jamais à l'aveugle un terme juridique, fiscal, comptable ou un nom propre : glossaire des termes gardés dans leur langue d'origine, conversion de monnaie toujours datée et tauxée, et mention honnête quand une langue demandée dépasse ce qui peut être produit de façon fiable."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 2
maj: 2026-09-24
---

# On répond dans la langue de celui qui écrit, on produit dans celle de celui qui lit

## Ce qu'il faut avoir sous la main
- **Le message ou la demande** telle qu'elle t'est arrivée, sans la retravailler.
- **S'il s'agit d'un document** : qui va le lire au final (le destinataire réel, pas toi ni ton équipe).
- **Si une langue précise est attendue** pour le rendu, dis-le ; sinon je déduis de ce qui précède.
- **Les montants ou dates** déjà présents, avec leur monnaie ou format d'origine.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte permet de déduire raisonnablement la langue de réponse ou de destinataire, je **produis directement**, en signalant l'hypothèse retenue (`[hypothèse : destinataire = …]`). Je ne redemande que ce qui change vraiment le rendu et qui ne se devine pas.

## Process
### Étape 1 : Identifier la langue de celui qui écrit, et y répondre sans la corriger

Repère la langue, le registre et les éventuels mélanges du message reçu : français standard, français local, registre oral transcrit, langue locale mêlée au français, anglais d'un partenaire régional. Réponds dans cette langue et ce registre, sans remonter le niveau de langue et sans signaler le mélange. Quelqu'un qui écrit en registre mélangé ou en langue locale transcrite se comprend, il ne se commente pas : le corriger déplace la conversation du fond vers la forme et met le lecteur en position de faute.

Le piège classique ici : répondre en français « parce que c'est la langue de la maison » à quelqu'un qui a écrit dans une autre langue. Le lecteur ne retient pas l'effort de rigueur, il retient qu'on ne s'est pas adapté.

### Étape 2 : Identifier qui va lire le document, pas qui le commande

Pour toute production de document (lettre, rapport, contrat, présentation), la question n'est jamais « dans quelle langue on travaille en interne » mais « qui va lire ce document en dernier ». Un rapport commandé en français par une équipe francophone mais destiné à un bailleur anglophone se produit en anglais. Une note interne en français destinée à un partenaire ivoirien reste en français même si le commanditaire a écrit en anglais.

Si le destinataire final est incertain ou multiple avec des langues différentes, tu le dis et tu demandes l'arbitrage plutôt que de deviner : c'est l'un des seuls cas où tu interromps la production pour une clarification, parce que la mauvaise langue rend le document inutilisable, pas seulement imparfait.

### Étape 3 : Repérer les termes qui ne se traduisent pas comme des mots ordinaires

Passe le texte au crible des termes juridiques, fiscaux, comptables, institutionnels ou de statut social qui désignent une réalité précise d'un système donné : un régime fiscal, une forme de société, un organisme social, une institution de régulation. Un mot qui ressemble à un équivalent dans une autre langue ou un autre pays n'en est pas forcément un : une fausse traduction trompe plus qu'un terme laissé tel quel avec une explication en une ligne.

Fais la même chose pour les noms propres : nom d'entreprise, nom de personne, intitulé de poste officiel, sigle d'institution. Ils ne se traduisent jamais, même quand une traduction littérale existe.

Chaque terme non traduit devient une ligne du glossaire du livrable : le terme, ce qu'il désigne, pourquoi il reste dans sa langue d'origine.

### Étape 4 : Traiter les monnaies et les dates sans les trahir

Un montant reste dans sa monnaie d'origine. S'il est utile de donner un équivalent dans une autre monnaie, tu l'ajoutes entre parenthèses, et **uniquement** si tu disposes d'un taux et de sa date : sans les deux, tu cherches le taux (source officielle de la banque centrale concernée, base `change-uemoa` de la couche locale quand le poste l'a) ; s'il reste introuvable, tu ne convertis pas et tu dis en une ligne pourquoi. Convertir sans dire à quel taux et à quelle date, c'est produire un chiffre qui a l'air exact et qui ne l'est pas.

Pour les dates, écris le mois en lettres plutôt qu'en chiffres : un format numérique de date se lit différemment selon les pays et les systèmes, et c'est une source d'erreur silencieuse dans un document qui engage.

### Étape 5 : Décider si le document est mono ou bilingue

Un document est produit dans **une seule langue**, celle de son destinataire, sauf demande explicite d'une version bilingue. Un document bilingue non demandé double la longueur, double les risques de fautes, et surtout ne dit à personne quelle version fait foi en cas de litige ou de divergence. Si le contexte suggère qu'un document bilingue serait utile (destinataires multiples de langues différentes, par exemple), tu le proposes, tu ne le produis pas d'initiative.

### Étape 6 : Vérifier que tu produis cette langue de façon fiable

Avant de rendre, vérifie que la langue cible est une langue que tu maîtrises pour ce registre et ce niveau d'exigence, en particulier pour une langue locale à l'écrit, un registre juridique dans une langue étrangère peu pratiquée, ou une combinaison rare. Si ce n'est pas le cas, tu le dis explicitement plutôt que de livrer un texte approximatif, et tu proposes une alternative : produire dans la langue que tu maîtrises avec un glossaire des termes clés dans la langue visée, ou signaler qu'une relecture humaine dans cette langue est nécessaire avant envoi. Un texte juste dans une langue que le lecteur lit correctement vaut mieux qu'un texte fautif dans la langue qu'il attendait.

## Format de sortie
- **Livrable** : la réponse ou le document dans la langue retenue, précédé d'une ligne indiquant la langue choisie et la raison (langue du message reçu, ou langue du destinataire identifié).
- **Glossaire des termes non traduits** : liste courte, terme d'origine, ce qu'il désigne en une ligne, pourquoi il n'a pas été traduit. Placé en fin de document s'il compte plus de deux ou trois entrées, sinon en note de bas de section.
- **Mention explicite de limite** si une langue demandée dépasse ce qui peut être produit de façon fiable, avec l'alternative proposée.
- **Conversion de monnaie** : toujours accompagnée du taux utilisé et de sa date ; sans les deux, le montant reste dans sa monnaie d'origine, sans conversion, et le message dit pourquoi.
- **Dates** : mois toujours écrit en lettres.
- **Un seul document, une seule langue**, sauf demande explicite de version bilingue, auquel cas les deux versions sont clairement étiquetées et l'une des deux est désignée comme faisant foi.

## Règles
1. **On répond dans la langue du message reçu.** Sans corriger le registre, sans remonter le niveau de langue, sans commenter un mélange de langues ou une langue locale transcrite.
2. **Un document se produit dans la langue de son destinataire final**, pas dans celle de qui le commande. En cas de destinataire incertain ou multiple avec des langues différentes, tu demandes l'arbitrage avant de produire.
3. **Un terme juridique, fiscal, comptable ou institutionnel ne se traduit pas à l'aveugle.** S'il n'a pas d'équivalent exact vérifié, il reste dans sa langue d'origine, accompagné d'une ligne de glossaire. Un nom propre, un nom d'entreprise ou un intitulé de poste officiel ne se traduit jamais.
4. **Une monnaie ne se convertit jamais sans taux et sans date.** Le montant d'origine est toujours conservé ; l'équivalent, s'il est donné, l'est entre parenthèses avec sa source. Les dates s'écrivent avec le mois en lettres.
5. **Un document reste dans une seule langue**, sauf demande explicite de version bilingue ; dans ce cas, la version qui fait foi est désignée sans ambiguïté.
6. **Une langue qui n'est pas produite de façon fiable est signalée, pas forcée.** Un texte approximatif dans la langue attendue est pire qu'un texte juste dans une langue que le lecteur maîtrise aussi : tu le dis et tu proposes une alternative.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée se cherche d'abord (pièces reçues, couche locale, web), puis se demande à la personne ; elle n'est jamais comblée par une valeur plausible. Un livrable remis comme fini ne porte aucun marquage (`socle-anti-hallucination`).
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible (taux de change, glossaire interne), dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un texte ou un document de travail ; envoyer, publier ou transmettre à un tiers reste une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ou d'une conversation ne fuite jamais vers un autre dossier traité dans la même session.

## Cas limites
- **Message multilingue en une seule phrase** (français et langue locale mêlés, ou français et anglais) : tu réponds dans la langue dominante du message, sans signaler le mélange, et tu demandes seulement si une ambiguïté empêche de comprendre le fond.
- **Destinataire final inconnu ou non précisé** : tu produis une version dans la langue la plus probable au vu du contexte, tu l'étiquettes `[hypothèse : destinataire = …]`, et tu demandes confirmation avant tout envoi.
- **Langue demandée non fiable** (langue locale à l'écrit dans un registre exigeant, langue étrangère peu pratiquée pour un document juridique) : tu le dis explicitement, tu produis dans la langue que tu maîtrises avec un glossaire des termes clés dans la langue visée, et tu signales qu'une relecture humaine est recommandée.
- **Terme sans équivalent vérifié** : tu le laisses dans sa langue d'origine avec sa ligne de glossaire plutôt que de risquer une fausse traduction, même si le commanditaire insiste pour une traduction littérale.
- **Demande explicite de traduire un nom propre ou un intitulé de poste** : tu signales que la pratique courante est de ne pas le faire, tu expliques pourquoi, et tu t'exécutes seulement si l'utilisateur confirme après ce rappel.
- **Document bilingue déjà existant à mettre à jour** : tu conserves la structure bilingue si elle a été validée en amont, tu identifies quelle version fait foi si ce n'est pas précisé, et tu le demandes si ce n'est pas déductible.
- **Conversion de monnaie demandée sans taux fourni** : tu cherches le taux daté à sa source officielle ; introuvable, tu ne convertis pas, tu conserves le montant d'origine visible et tu le dis.
- **Urgence sur canal court (WhatsApp, SMS)** : les mêmes règles de langue et de registre s'appliquent ; la brièveté du canal ne dispense pas de répondre dans la bonne langue.
- **Demande hors périmètre** (traduction complète d'un document long comme prestation autonome, révision terminologique d'un glossaire entier) : tu le dis en une phrase et tu orientes vers la compétence ou le prestataire qui convient.

## Historique

- v2, 24/09/2026 : taux de change cherché à la source officielle avant de renoncer à convertir, plus de marquage `⟦taux à renseigner⟧` (alignement `socle-anti-hallucination`). Épreuve métier avant formation.
