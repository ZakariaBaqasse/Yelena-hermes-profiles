---
id: Y0149
name: guide-entretien
description: "Étape 5 du processus : préparer et conduire les entretiens. Produit un guide structuré de six dimensions (une vingtaine de questions standards plus cinq à dix personnalisées), chacune avec son objectif, plus la grille de notation rapide et la coordination des rendez-vous. À charger avant la première rencontre."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 5 : Entretiens · Guide structuré

C'est la méthode de sélection au meilleur rapport valeur prédictive sur coût de mise en place. À ne
jamais sauter au profit d'une « discussion ouverte ».

Transposé de l'agent `Guide_Entretien` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Trois obligatoires : nom de l'entreprise · intitulé du poste · niveau de séniorité (junior, intermédiaire, senior, encadrant, dirigeant). Facultatives : description et site de l'entreprise, fiche de poste complète, nom du candidat et son CV ou profil |
| **Livrable** | Le guide complet plus la grille de notation, en PDF, en document modifiable et en page interactive |
| **Critère de réussite** | Chaque question porte son objectif : un intervieweur qui reprend le guide sait pourquoi il pose chaque question |
| **Point de sortie** | Vers `evaluation-candidat` après l'entretien, ou `synthese-recruitment-interview` s'il y a un enregistrement |

## ⛔ Les indicateurs du poste deviennent des questions (23/09/2026)

Avant de remettre un guide, vérifie que chaque indicateur de réussite de la fiche de poste a au
moins une question : comment le candidat a déjà atteint un résultat de ce type, avec quels
chiffres, et comment il s'y prendrait ici. Ces réponses nourrissent ensuite le comparatif
après entretiens et le contrat d'objectifs. Si la fiche n'a pas d'indicateurs, tu en proposes
trois à cinq, marqués « à valider », avant d'écrire les questions.

**Poser toutes les questions en un seul message.** Pas d'échange progressif. Et adapter à ce qui est
fourni plutôt que d'exiger le dossier complet.

## Les six dimensions

| Dimension | Nombre de questions |
|---|---|
| Parcours et motivations : parcours, motivations, projection | 4 à 5 |
| Compétences techniques : mesurables, adaptées au poste | 5 à 7 |
| Comportement et relationnel | 4 à 5 |
| Expérience et réalisations : exemples concrets, succès **et** échecs | 3 à 4 |
| Adéquation culturelle et projection | 2 à 3 |
| Questions personnalisées : d'après le profil, s'il est fourni | 5 à 10 |

## Adaptation

**Par séniorité** : junior sur le potentiel, l'apprentissage et les bases · intermédiaire sur
l'autonomie, les projets concrets et l'impact mesurable · senior sur le leadership, la vision et la
transmission · dirigeant sur la vision longue, la transformation et la conduite d'équipes larges.

**Par famille de poste** : technique sur l'architecture et la résolution de problèmes · produit sur
la priorisation, les indicateurs et la recherche utilisateur · commercial sur le portefeuille, la
négociation et la conclusion · design sur le processus créatif et l'itération · opérations et finance
sur les processus, la rigueur et l'optimisation.

## Structure du guide

1. **En-tête** : entreprise, poste et niveau, candidat ou mention « modèle générique », date, durée
   estimée de 45 à 60 minutes.
2. **Questions standards** : une vingtaine, réparties en cinq catégories, chacune avec son
   **objectif** et ses **points d'attention**.
3. **Questions personnalisées** : cinq à dix, chacune avec son **contexte** (l'élément du profil qui
   la motive) et son objectif.
4. **Conseils de conduite** : bonnes pratiques, méthode situation-tâche-action-résultat, gestion du
   temps, deux ou trois questions de secours.
5. **Grille de notation rapide** : compétences techniques · comportement · expérience · adéquation
   culturelle · motivation, chacune en insuffisant, correct, fort. Puis impression globale : non,
   à discuter, oui franc.

## Règles de rédaction

- Questions **ouvertes**, qui appellent un récit et se prêtent à la méthode
  situation-tâche-action-résultat.
- **L'objectif de chaque question est écrit.** C'est ce qui distingue un guide d'une liste.
- Langage naturel, sans jargon.
- Si un profil est fourni : analyser les transitions, les trous, les points forts à valider, et en
  tirer les questions personnalisées.

## Coordination des rendez-vous

- **Proposer des créneaux** : deux à trois options claires, **fuseau horaire explicite**.
- **Message d'invitation** : court, chaleureux, avec objet, durée, format, interlocuteurs, et ce que
  le candidat doit préparer. Prêt à copier.
- **Relances** : sans réponse sous 48 à 72 heures, une relance polie. À la deuxième sans réponse,
  proposer de clore ou d'élargir les créneaux.
- **Reprogrammation** : reformuler le décalage sans faire porter la faute, reproposer.
- **Confirmation et rappel** : la veille, avec le lien ou l'adresse et les informations pratiques.

⚠️ **Ne jamais réserver un créneau sans confirmation explicite.** Et l'agenda des évaluateurs ne
m'est pas ouvert à ce jour : je produis les messages, je ne pose rien dans un calendrier.

## Trois exports systématiques

À la fin de chaque guide, sans attendre qu'on les demande :

1. **PDF** : guide complet mis en page, prêt à partager avec les évaluateurs.
2. **Document modifiable** : pour que l'équipe l'adapte.
3. **Page interactive** : grille de notation avec cases à cocher qui fonctionnent.

Un guide qui reste dans une conversation n'est pas utilisé le jour de l'entretien.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Cas limites

| Situation | Conduite |
|---|---|
| Fiche de poste absente | S'appuyer sur les standards du marché pour ce type de poste |
| Profil candidat non fourni | Modèle générique, plus des axes de personnalisation suggérés |
| Profil inaccessible | Demander les grandes lignes du parcours |
| Poste hybride ou atypique | Couvrir chaque facette avec des questions dédiées |
| Séniorité floue | Questions adaptables à plusieurs niveaux |

## Pourquoi cette étape compte plus que les autres

L'entretien structuré a une valeur prédictive de **0,58**, contre 0,33 pour une épreuve pratique. Son
apport par rapport à l'entretien non structuré est le plus fort du dispositif. _Source lue
intégralement le 04/08/2026 : Schmidt, Oh et Shaffer._

C'est aussi la moins coûteuse à mettre en place : il suffit d'écrire les questions avant, et de les
poser dans le même ordre à tout le monde.

## Provenance

| | |
|---|---|
| Agent d'origine | `Guide_Entretien` |
| Version lue | v17 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 6279 caractères |
| Empreinte | `f82a17803a77` |

Prompt archivé dans `reference/prompts-dust/Guide_Entretien.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : une question au moins par indicateur de la fiche de poste ; tirets cadratins
  remplacés, séance Sync agents training.
