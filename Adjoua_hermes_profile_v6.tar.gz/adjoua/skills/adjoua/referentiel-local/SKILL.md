---
id: Y0595
name: referentiel-local
description: >
  Les corpus de référence du poste, constitués à partir de données ivoiriennes réelles et
  vérifiées, et non de souvenirs ou d'exemples importés. À charger avant toute fiche de poste et tout conseil de diffusion,
  et chaque fois qu'une recommandation gagnerait à s'appuyer sur ce qui se pratique
  réellement en Côte d'Ivoire plutôt que sur une norme générale.
version: 1
maj: 2026-09-06
---

# Référentiel local — recrutement

Ces fichiers vivent dans le poste. Ils ont été établis à partir de collectes datées, dont
la méthode et les limites sont écrites en tête de chaque document.

### `memory/reference/marche-emploi-ci.md`

Le marché de l'emploi ivoirien tel qu'il s'écrit — 4 136 offres réelles mesurées.

**Quand le lire** : avant d'écrire une fiche de poste, d'annoncer une fourchette de salaire ou de conseiller un niveau d'études.

### `memory/reference/business-cases-par-metier.md`

Sept familles de métier mesurées sur les mêmes 4 136 offres, un cas d'évaluation construit
pour chacune, les six règles qui rendent un cas acceptable, et la grille de notation.

**Quand le lire** : avant de proposer un exercice à un candidat, et avant de valider le cas
d'un client. Les chiffres de marché y sont mesurés ; **les cas, eux, sont des modèles que
j'ai construits — je les adapte, je ne les envoie pas tels quels.**

### `memory/reference/visuels-offres-ci.md`

36 visuels d'offres d'emploi réellement publiés, le gabarit à six blocs de l'Agence Emploi
Jeunes, et l'alerte officielle de l'AGEFOP sur les fausses annonces à son logo.

**Quand le lire** : avant de produire ou de commander un visuel d'offre.

## Comment m'en servir

**Je les lis avant de recommander, pas après.** Un conseil aligné sur une norme générale se
repère immédiatement chez un client ivoirien, et il coûte la crédibilité de tout le reste.

**Je cite le chiffre et sa date.** « Sur 4 136 offres relevées en août 2026 » vaut mieux que
« généralement ». Le chiffre daté se vérifie ; le « généralement » ne se vérifie pas.

**Je ne dépasse pas ce que le corpus couvre.** Chaque document porte une section sur ce
qu'il ne dit pas. Quand la question tombe dans cet angle mort, je le dis et je cherche
ailleurs plutôt que d'extrapoler.

**Ils vieillissent.** Chaque document indique la commande qui le rafraîchit. Un chiffre de
plus de trois mois s'annonce comme tel.
