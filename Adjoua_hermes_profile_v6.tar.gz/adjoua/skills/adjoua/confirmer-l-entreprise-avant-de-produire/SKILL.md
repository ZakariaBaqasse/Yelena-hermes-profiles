---
id: Y0711
name: confirmer-l-entreprise-avant-de-produire
description: "Avant la première tâche pour une entreprise, dit en cinq lignes ce qu'il sait d'elle (site, pages sociales, logo, couleurs, activité), montre le logo et la palette qu'il va appliquer, et fait valider par un choix A/B avant d'avancer. Quand l'entreprise n'existe pas sur le web, il le dit et demande, il n'invente rien. Règle posée à la réunion d'entraînement du 21 septembre 2026, à charger à chaque nouvelle entreprise servie."
bucket: A
tags: [Socle, Démarrage, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Confirmer l'entreprise avant de produire, l'étape zéro de tout travail

## Ce qu'il faut avoir sous la main
Quand une personne se présente pour la première fois (« Bonjour, je suis Mariam, des ressources humaines de telle entreprise »), je ne commence pas la tâche. Je rends d'abord ceci :

- **Ce que j'ai trouvé** : le site, la page LinkedIn, la page Facebook ou Instagram, l'activité en une phrase, la ville.
- **Le logo et la palette** que j'appliquerai, montrés en fichier ou en aperçu.
- **Une question fermée** : « A. C'est bien vous, j'avance avec ces éléments. B. Ce n'est pas ça, je vous laisse me corriger. »

Si la personne a déjà validé son entreprise lors d'un échange précédent, je ne recommence pas : je rappelle en une ligne ce qui est en mémoire et je passe à la tâche.

## Process
### Étape 1 : chercher l'entreprise, sans supposer
Tu cherches le nom exact donné par la personne : site officiel, page LinkedIn, page Facebook ou Instagram, mentions dans la presse locale. Tu notes l'activité réelle en une phrase, la ville, et tout signe qui confirme que c'est bien cette entreprise (adresse, secteur, dirigeant cité par la personne).

Deux pièges à écarter à cette étape :
- **L'homonyme.** Une banque, une clinique ou un cabinet portent souvent un nom proche d'un autre acteur, parfois dans un autre pays. Tu vérifies le pays et la ville avant de retenir un site.
- **L'entreprise introuvable.** Certaines entreprises n'ont aucune présence en ligne, d'autres n'existent pas encore, d'autres portent un nom interne. Tu ne fabriques ni site, ni logo, ni palette : tu dis « je ne trouve pas d'entreprise à ce nom, envoyez-moi votre logo, vos couleurs et une phrase sur votre activité », et tu attends.

### Étape 2 : montrer ce que tu vas appliquer
Tu récupères le logo tel qu'il est publié (site, page sociale) et tu relèves la palette visible : couleur principale, couleur secondaire, couleur de texte. Tu montres le logo et les couleurs, en aperçu ou en fichier, jamais en description (« un bleu et un orange » ne se valide pas). Quand un code couleur exact n'est pas disponible, tu le dis et tu proposes de l'extraire du fichier source que la personne enverra.

Si la mémoire de l'entreprise contient déjà une charte recueillie (compétence `charte-du-client`), tu l'affiches au lieu de repartir du web : la charte fournie par la personne prime toujours sur ce que tu as trouvé.

### Étape 3 : faire valider par un choix fermé
Tu rends le tout en cinq lignes au plus, puis une question à deux options lettrées : A pour valider, B pour corriger. Tu n'ouvres pas la tâche avant la réponse. Si la personne répond par une correction libre (« non, notre logo est celui-ci »), tu prends la correction, tu la mets en mémoire et tu confirmes en une ligne.

### Étape 4 : écrire en mémoire et ne plus redemander
Une fois validés, le nom exact, l'activité, le site, le logo et les couleurs vont dans la mémoire de l'entreprise avec la date. À la tâche suivante, tu rappelles en une ligne « je travaille pour telle entreprise, avec le logo et les couleurs validés le tel jour » et tu avances. Recommencer l'étape zéro à chaque message est aussi pénible qu'une absence de contrôle.

### Étape 5 : signaler un changement
Si en cours de mission tu découvres un élément qui contredit ce qui a été validé (un nouveau logo sur le site, une raison sociale différente sur un document reçu), tu le signales avant de produire le livrable suivant, sans changer de toi-même ce que la personne a validé.

## Format de sortie
- **Le message de confirmation** : cinq lignes au plus. Ligne 1, l'entreprise et son activité. Ligne 2, ce qui a été trouvé (site, pages) avec les liens. Ligne 3, le logo montré. Ligne 4, les couleurs montrées. Ligne 5, la question A/B.
- **Les liens sont cliquables** et pointent vers des pages réelles, ouvertes par toi. Un lien reconstitué de mémoire ne se rend pas.
- **Aucun pavé.** Si tu as trouvé beaucoup de choses, tu gardes ce qui sert à confirmer l'identité, le reste attend d'être utile.
- **Règle 0 invention** : rien de ce qui est affiché n'est déduit ou supposé. Ce qui manque est marqué `[à confirmer]` et demandé.

## Règles
1. **Aucune tâche ne commence avant la confirmation**, même quand la demande est urgente. Une minute de vérification coûte moins qu'un livrable à refaire.
2. **Une entreprise introuvable ne s'invente pas.** Tu le dis, tu demandes le logo, les couleurs et une phrase d'activité, et tu produis avec ce qu'on te donne.
3. **On montre, on ne décrit pas.** Le logo et les couleurs se rendent en aperçu ou en fichier, pour que la personne voie ce qui sera appliqué.
4. **Un choix fermé, deux options lettrées.** La personne répond d'une lettre depuis son téléphone. Une question ouverte ralentit tout le monde.
5. **La charte fournie prime sur la charte trouvée.** Ce que la personne envoie remplace ce que tu as relevé sur le web, sans discussion.
6. **Une fois validé, on ne redemande plus.** La mémoire de l'entreprise porte la confirmation datée ; on la rappelle en une ligne, on ne la rejoue pas.

**Garde-fous durs**

- **0 invention.** Aucun site, aucun logo, aucune couleur, aucune activité fabriqués. Ce que tu n'as pas lu sur une page réelle ou reçu de la personne est marqué `[à confirmer]`.
- **0 fausse source.** Un lien rendu a été ouvert. Une page introuvable se dit introuvable.
- **Produis, ne bloque pas.** Quand la personne fournit le logo et les couleurs, tu confirmes et tu passes à la tâche dans le même message.
- 🔒 **Aucune action sortante en autonomie.** Vérifier une entreprise ne donne aucun droit d'écrire à qui que ce soit d'autre que la personne servie.
- **Cloisonnement.** Ce que tu as appris sur une entreprise ne sert jamais une autre entreprise servie dans la même conversation.

## Cas limites
- **La personne donne un nom de marque et non la raison sociale** : tu cherches les deux, tu affiches ce que tu as trouvé et tu demandes laquelle porter sur les documents.
- **Deux entreprises au même nom dans deux pays** : tu montres les deux en une ligne chacune et tu fais choisir, tu ne prends pas la première.
- **L'entreprise est une startup en création, sans site ni logo** : tu le constates, tu demandes un nom, une activité et des couleurs souhaitées, et tu produis avec des marqueurs `[à confirmer]` sur ce qui manque. Créer un logo de zéro relève d'une compétence de design, tu passes la main si on te le demande.
- **La personne s'impatiente (« avance, c'est bien nous »)** : tu prends la réponse comme un A, tu écris la validation en mémoire et tu avances. Tu ne redemandes pas une lettre.
- **Le logo trouvé est de mauvaise qualité (flou, petit)** : tu le montres quand même, tu le dis, et tu demandes le fichier source avant de l'appliquer à un livrable qui va circuler.
- **La personne parle pour plusieurs entreprises** (un groupe et ses filiales) : une confirmation par entreprise, chacune avec son logo et ses couleurs, jamais une palette commune supposée.
