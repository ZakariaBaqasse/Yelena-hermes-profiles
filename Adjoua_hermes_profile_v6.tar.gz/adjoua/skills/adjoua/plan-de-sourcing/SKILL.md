---
id: Y0368
name: plan-de-sourcing
description: "Mène l'entretien de cadrage avec le manager qui recrute — pourquoi ce poste maintenant, à quoi ressemble la réussite à 6 mois, ce qui est vraiment indispensable contre ce qui est négociable — puis construit le plan de sourcing : viviers, canaux hiérarchisés, calendrier, plan B si personne ne répond. Sans jamais inventer un salaire, un délai ou un vivier qui n'a pas été vérifié."
bucket: A
tags: [Recrutement, RH, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Plan de sourcing — cadrer le besoin avant de chercher

## Ce qu'il faut avoir sous la main
- **Le poste** : intitulé, équipe, à qui il rapporte.
- **Pourquoi ce poste s'ouvre maintenant** : remplacement, création, croissance d'équipe.
- **Ce que le manager t'a déjà dit vouloir** : compétences, expériences, traits — tel quel, même si c'est une liste trop longue.
- **Une personne existante qui incarne ce qu'on cherche**, si le manager en a une en tête (collègue, ancien collaborateur, profil vu ailleurs) — et ce qui, chez elle, compte vraiment.
- **Le budget ou la fourchette de rémunération**, si elle est fixée — sinon dis-le, ce n'est pas bloquant.
- **Le délai souhaité** pour pourvoir le poste.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Pourquoi ce poste, maintenant

Établis d'abord la nature réelle du besoin : remplacement d'une personne partie, poste créé pour absorber une croissance, ou poste qui existe depuis des mois sans qu'on sache vraiment pourquoi il traîne. Chaque cas change la stratégie — un remplacement urgent tolère moins de compromis sur le délai mais peut réutiliser une fiche de poste qui a déjà fait ses preuves ; une création pure n'a ni référence ni historique, donc plus d'incertitude sur les critères.

Si le manager ne sait pas répondre clairement à « pourquoi maintenant », c'est un signal : le besoin n'est peut-être pas encore mûr, et lancer un sourcing dessus revient à courir après une cible qui bouge.

### Étape 2 — La réussite à 6 mois, pas la liste de qualités

Demande ce que la personne recrutée aura *fait* dans les six premiers mois si le recrutement est réussi — pas ce qu'elle *sera*. « Autonome », « rigoureux », « bon relationnel » ne se testent pas et ne se sourcent pas ; « aura repris seule la gestion de tel portefeuille client » ou « aura livré tel chantier » se traduit directement en critères vérifiables.

Si le manager ne peut décrire que des traits de personnalité, reformule avec lui jusqu'à obtenir des résultats concrets. Un poste défini par des qualificatifs ne donne aucune prise au sourcing — il donne prise au hasard de l'entretien.

### Étape 3 — Séparer indispensable, souhaitable et disqualifiant

C'est le piège central du métier : un manager décrit le mouton à cinq pattes — dix ans d'expérience, une compétence rare, une disponibilité immédiate, un salaire modeste — et personne ne le contredit. Le sourcing part alors chercher une personne qui n'existe pas, ou qui existe mais n'acceptera jamais les conditions offertes, et le poste reste ouvert.

Range chaque critère donné en trois colonnes : **indispensable** (son absence disqualifie, même si tout le reste est excellent), **souhaitable** (un plus, pas un critère d'élimination) et **disqualifiant** (un signal qui exclut, indépendamment du reste). Puis pose la question que personne ne pose jamais : *si tu devais lâcher un critère indispensable pour pourvoir ce poste dans le délai visé, lequel serait le premier à sauter ?* La réponse — ou son absence — te dit si le manager a réellement hiérarchisé ou s'il campe sur une liste de vœux.

Si une personne de référence a été citée en intake, décompose ce qui, chez elle, relève du poste (transférable) et ce qui relève d'elle (son parcours propre, non reproductible) — chercher un clone est une autre version du mouton à cinq pattes.

### Étape 4 — Cartographier les viviers

Identifie où ces profils existent réellement : entreprises concurrentes ou adjacentes qui emploient ce type de poste, écoles et filières qui forment ce profil, associations professionnelles du secteur, réseaux de diaspora si le profil est rare localement. Nomme les viviers de façon spécifique — pas « le marché », mais les organisations, écoles ou cercles identifiables.

Signale explicitement quand un vivier est supposé plutôt que vérifié : une école réputée former ce profil n'est une piste fiable que si quelqu'un l'a confirmé récemment, pas par réputation ancienne.

### Étape 5 — Hiérarchiser les canaux, pas les empiler

Le deuxième piège : un plan de canaux qui se limite à « on poste l'annonce en ligne ». Une part significative des bons profils, en Côte d'Ivoire comme ailleurs dans la sous-région, se trouve par cooptation interne, par les réseaux d'anciens élèves, par les associations professionnelles et par les groupes WhatsApp métier — des canaux qui ne coûtent rien en budget mais demandent du temps de relation, contre une annonce en ligne qui coûte peu de temps mais touche large et non ciblé.

Pour chaque canal retenu : ce qu'il coûte réellement (temps, argent, relation à mobiliser), qui l'active en interne, et ce qu'on attend de lui en volume et en délai. Classe-les dans l'ordre où les activer plutôt que de tous les lancer en même temps sans savoir lequel a produit quoi.

### Étape 6 — Le calendrier et le plan B

Troisième piège, le plus silencieux : sans calendrier, rien n'est jamais en retard, donc rien n'avance vraiment. Pose des jalons datés — lancement des canaux, premier point de volume de candidatures, décision de relance ou d'élargissement — même si les dates précises restent `⟦à renseigner⟧` en attendant l'arbitrage de l'équipe.

Prévois le cas où le vivier ne répond pas au premier jalon : élargir les critères souhaitables, ouvrir un canal non prévu initialement, revoir la fourchette de rémunération, ou accepter un délai plus long. Un plan sans plan B n'est un plan que si tout se passe comme prévu — ce qui n'arrive presque jamais.

## Format de sortie
- **Livrable** : le plan de sourcing — besoin reformulé (pourquoi maintenant, réussite à 6 mois), tableau des critères indispensable / souhaitable / disqualifiant, portrait des viviers (entreprises, écoles, réseaux), canaux hiérarchisés avec l'effort que chacun coûte, calendrier avec jalons, plan B si le vivier ne répond pas.
- **Structure** : Markdown clair — answer-first (le résumé du besoin cadré, puis le plan) ; tableaux pour les critères et les canaux.
- **Longueur** : proportionnée à la demande, sans remplissage. Un plan de sourcing tient en une à deux pages.
- **Les délais, seuils de volume et budgets sont un input**, pas une production : la skill livre la structure du calendrier et la question à trancher à chaque jalon ; la **valeur** vient de l'équipe et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun salaire, aucun délai, aucun vivier chiffré inventé. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **L'indispensable et le souhaitable ne se mélangent jamais dans le même tableau sans étiquette.** Un critère non tranché par le manager reste marqué `⟦à trancher⟧`, il n'est jamais classé par défaut en indispensable.
2. **0 chiffre inventé.** Aucun salaire, aucune fourchette de rémunération, aucun délai, aucun volume de vivier n'est produit sans être fourni : `⟦à renseigner⟧` sinon. Un ordre de grandeur « courant sur ce type de poste » non sourcé reste une invention.
3. **Un canal unique n'est jamais un plan.** Si l'intake ne mentionne qu'une plateforme en ligne, tu proposes explicitement les canaux relationnels — cooptation, écoles, associations professionnelles, réseaux communautaires — avant de valider le plan.
4. **Le calendrier n'est pas optionnel.** Un plan de sourcing sans jalon daté (même en `⟦à renseigner⟧`) est incomplet et signalé comme tel.
5. **Une personne de référence n'est pas un gabarit à cloner.** Tu distingues ce qui, chez elle, est transférable au poste et ce qui relève de son parcours propre, non reproductible.
6. **Le contexte local n'est pas un décor.** Le poids réel de la cooptation, le rôle des écoles et associations professionnelles, l'usage de WhatsApp comme canal de travail : un plan pensé pour un marché où tout passe par une plateforme en ligne ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter des candidats, publier une annonce ou solliciter un réseau externe est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un recrutement ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Manager indisponible pour le cadrage** — tu produis le plan à partir des éléments transmis, tu marques les critères non tranchés `⟦à trancher⟧`, et tu signales que le cadrage reste provisoire tant que le manager n'a pas validé la séparation indispensable / souhaitable.
- **Poste ouvert depuis longtemps sans qu'on sache pourquoi** — tu le nommes explicitement à l'étape 1 : c'est un signal que le besoin n'est peut-être pas mûr, pas seulement un problème de sourcing.
- **Aucune référence de personne existante** — tu construis le portrait uniquement à partir des critères de réussite à 6 mois, sans forcer une comparaison à quelqu'un.
- **Vivier introuvable ou très restreint** — tu le dis explicitement plutôt que de gonfler artificiellement les pistes, et tu bascules directement sur le plan B à l'étape 6.
- **Poste confidentiel** (remplacement non annoncé, restructuration) — tu le signales et tu adaptes les canaux proposés à ce que la confidentialité permet, sans supposer que tous les canaux relationnels restent ouverts.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (grille d'entretien, offre salariale, fiche de poste).
- **Action sortante demandée** (contacter un candidat, publier une annonce, solliciter un réseau) — tu prépares le plan et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le manager et son N+1 décrivent des besoins différents) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
