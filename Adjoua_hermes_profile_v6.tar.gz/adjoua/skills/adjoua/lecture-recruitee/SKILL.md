---
id: Y0559
name: lecture-recruitee
description: "Lire les données Recruitee sans se tromper : croiser étape et drapeau d'écartement, endpoints utiles, pièges constatés, recoupements obligatoires. À charger dès qu'un chiffre de recrutement doit sortir de l'ATS."
bucket: A
tags: [Recrutement, Données]
version: 1
maj: 2026-08-03
---

# Lire Recruitee sans se tromper

À charger **avant** de produire le moindre chiffre tiré de Recruitee : point hebdomadaire, état
des lieux d'un poste, tableau de bord, relance de candidats, tri de candidatures.

Tout ce qui suit a été constaté en interrogeant l'API le 3 août 2026, pas déduit d'une
documentation.

## La règle qui a coûté un livrable faux

⚠️ **L'étape du pipeline ne dit PAS si un dossier a été traité.**

Le drapeau d'écartement (`disqualified` sur le placement) est un champ **distinct** de l'étape.
Un candidat peut être resté à l'étape « Postulé » **et** avoir été écarté avec un motif et une
date. Lire l'étape seule fabrique une alerte qui n'existe pas.

_Ce qui s'est passé le 03/08/2026, offre 2642821 :_ 16 dossiers à l'étape « Postulé » ont été
annoncés au client comme « jamais traités, certains depuis 41 jours ». En réalité : 10 écartés
avec motif, dont 6 avec courriel de refus, et 8 reçus dans la semaine. Le document était déjà
parti.

**Ce qui aurait évité l'erreur, et qui s'applique désormais :** avant d'interpréter un champ,
lister les champs de l'objet et vérifier qu'aucun autre ne porte l'information cherchée.
Un recoupement arithmétique n'aurait rien vu — 16 + 7 + 3 = 26 tombait juste. L'erreur n'était
pas un calcul faux, c'était un mot mal traduit.

## Les trois catégories, jamais deux

Toute restitution de l'état d'un vivier se fait en croisant étape **et** drapeau :

| Catégorie | Comment la déterminer |
|---|---|
| **Écarté** | `disqualified` vrai, quelle que soit l'étape. Le motif et la date sont disponibles. |
| **En attente de traitement** | non écarté, à l'étape d'arrivée. Ancienneté comptée **depuis la réception du dossier**, jamais depuis l'ouverture du poste. |
| **Actif dans le processus** | non écarté, au-delà de l'étape d'arrivée. |

Et deux interdits :
- **Ne jamais proposer de relancer un candidat écarté.** Vérifier le drapeau avant tout message.
- **Ne jamais présenter l'ancienneté d'un poste comme l'attente d'un candidat.** Un poste ouvert
  depuis 47 jours peut n'avoir que des dossiers vieux de 5 jours.

## Recoupements avant publication

1. Somme des catégories = `candidates_count` de l'offre. Sinon, la pagination a coupé.
2. `qualified_candidates_count` + `disqualified_candidates_count` = `candidates_count`.
3. Si une addition ne tombe pas juste : le dire, ne pas publier.

## Endpoints utiles

Base : `https://api.recruitee.com/c/103010`, en-tête `Authorization: Bearer <jeton>`.
Jeton dans `~/.config/agents/secrets/recruitee.txt`. Limite observée : 1000 requêtes / 60 s.

| Besoin | Appel |
|---|---|
| Postes | `GET /offers?scope=active\|all&view_mode=brief` — statuts `published`, `internal`, `closed`, `archived`. **Ouverts = published + internal.** |
| Détail d'un poste | `GET /offers/{id}` — 106 champs, dont `department`, `city`, `salary`, les compteurs de candidats. |
| Candidats d'un poste | `GET /search/new/candidates?filters_json=[{"filter":"jobs","id":{"in":[ID]}}]` — porte l'étape et le drapeau. **Paginer**, `limit` plafonne à 200. |
| Détail candidat | `GET /candidates/{id}` — CV analysé dans `fields` (`experience`, `education`, `skills`, `language_skill`). |
| Tous les candidats | `GET /candidates?limit=200&offset=N` — les placements portent `created_at`, `hired_at`, `disqualified_at`, `disqualify_reason`, `department_name`. |
| Départements | `GET /departments` |

## Ce que le jeton voit vraiment — sondé le 03/08/2026

Constaté en interrogeant l'API, pas déduit. **À vérifier avant de dire « je n'ai pas ».**

| Répond | Ce que ça donne |
|---|---|
| `GET /candidates/{id}/notes` | ✅ **Les comptes rendus d'entretien saisis par les évaluateurs.** Corps en HTML, date, identifiant de l'auteur. C'est de la matière d'évaluation réelle. |
| `GET /candidates/{id}/tasks` | ✅ les tâches attachées à un dossier |
| `GET /tasks?scope=uncompleted&limit=200` | ✅ toutes les tâches ouvertes du compte, avec `due_date` — permet de mesurer le retard opérationnel |
| `GET /admins` | ✅ la liste des évaluateurs : nom, courriel, fuseau |

| Ne répond pas (404) | Conséquence |
|---|---|
| `/candidates/{id}/mailbox`, `/messages`, `/emails` | **La correspondance avec les candidats est invisible.** Le compteur de messages existe sur le dossier, pas leur contenu. |
| `/candidates/{id}/interview_events`, `/calendar_events`, `/event_types` | pas d'agenda : impossible de proposer un créneau réel |
| `/candidates/{id}/evaluations`, `/evaluation_cards` | pas de scorecards structurées ; les notes libres sont le seul support d'évaluation |
| `/candidates/{id}/timeline` | pas d'historique d'étapes daté |

⚠️ **La leçon du 03/08/2026.** Une comparaison entre deux candidats a été rendue au client sur la
seule base des CV analysés, alors que **le compte rendu d'entretien de l'un des deux existait dans
l'ATS** et n'avait pas été lu. Personne ne l'avait caché : l'endpoint n'avait pas été essayé.

**Réflexe désormais obligatoire avant toute évaluation, comparaison, relance ou préparation
d'entretien : appeler `/candidates/{id}/notes`.** Un dossier sans note et un dossier avec un compte
rendu détaillé ne se traitent pas de la même façon — et l'absence de note est elle-même une
information à remonter, parce qu'elle veut dire qu'un entretien a eu lieu sans trace écrite.

## Le cloisonnement entre maisons

Le compte héberge **plusieurs entreprises** : Yelema et les startups du portefeuille. Un jeton
non restreint voit tout. Le champ qui sépare proprement est le **département** :
`Yelema Core Team`, `Startups`, `Co-fondateurs EIR`. Le titre de l'offre ne suffit pas — certains
postes ne nomment aucune maison.

Quand un chiffre est annoncé, **dire de quel périmètre il parle** : « 14 postes ouverts » sur tout
le compte et « 1 poste ouvert » chez Yelema sont vrais tous les deux.

## Pièges d'installation du connecteur

- `pip install "mcp[cli]"` installe aujourd'hui la version 2.x, où `mcp.server.fastmcp` n'existe
  plus : le serveur plante à l'import. **Épingler `mcp[cli]<2`.**
- Pas de `pip` système sur la machine : passer par `python3 -m venv`.
- Le connecteur vit dans `~/agents/adjoua/connecteurs/`, lancé par `run-tellen.sh` qui source le
  magasin de secrets. Le jeton n'est jamais écrit dans un fichier de configuration.
- `add_candidate_note` et `send_candidate_email` sont volontairement bloqués : les points d'entrée
  d'écriture ne sont pas confirmés. Ne pas les activer sans vérification.
- Le couple `propose_*` / `confirm_action` force deux appels, **pas** l'accord d'un humain. La
  validation reste une règle de conduite, pas une barrière technique.

## Écriture : les bons chemins, trouvés le 03/08/2026

Les pages `docs.recruitee.com` renvoient un 403. **La documentation complète est ailleurs et elle
s'ouvre : <https://apidocs.recruitee.com/>** — page unique d'environ 11 Mo, à récupérer avec `curl`
puis à fouiller localement (un chargement direct dépasse la limite de l'outil de lecture web).

| Action | Chemin exact |
|---|---|
| **Déplacer d'étape** ✅ *exécuté avec succès le 03/08/2026* | `PATCH /c/{company_id}/placements/{id}/change_stage` — `stage_id` requis ; `proceed: true` pour placer en haut de colonne ; `position` pour un rang précis. Marquer embauché exige en plus `hired_at` et `work_location_id`. |
| **Écarter** | `PATCH /c/{company_id}/placements/{id}/disqualify` — `disqualify_reason_id` requis |
| **Requalifier** | `PATCH /c/{company_id}/placements/{id}/requalify` |
| **Créer une note** | `POST /c/{company_id}/candidates/{candidate_id}/notes` |

⚠️ **L'erreur qui a fait perdre une demi-journée.** `PATCH /placements/{id}` avec
`{"placement":{"stage_id":…}}` renvoie 404 — c'est le chemin qu'annonçait le connecteur
`tellen-recruitee`, et il est faux. Le déplacement d'étape a **son propre sous-chemin**,
`/change_stage`. Un 404 sur une API Recruitee veut dire « cette route n'existe pas », pas
« tu n'as pas le droit » : les droits se voient dans `GET /admins` et `GET /roles`.

⚠️ **Les étapes sont partagées entre plusieurs offres.** Les mêmes `stage_id` servent à des offres
différentes. **Ne jamais déduire l'offre d'un `stage_id`** : toujours lire `offer_id` sur le
placement, et le dire au client quand on déplace un dossier — il croit parfois parler d'un autre
poste que celui où le candidat est réellement inscrit.

**Après toute écriture, recompter.** Un déplacement d'étape doit faire baisser de 1 le compteur de
l'étape de départ, monter de 1 celui d'arrivée, et laisser le total inchangé. Si ça ne tombe pas
juste, le dire.

`OPTIONS` n'est pas routé sur cette API (404 même sur une route qui répond en `GET`) : inutile
pour découvrir les méthodes autorisées.

## Ce qui ne marche PAS (testé le 03/08/2026)

Le connecteur `tellen-recruitee` livré par le client pointe sur `PATCH /placements/{id}` pour le
déplacement d'étape. **Ce chemin est faux** — voir le tableau ci-dessus pour le bon.

Chemins sondés en lecture, tous en 404 : `/placements/{id}`, `/placements`,
`/candidates/{cid}/placements`, `/candidates/{cid}/placements/{pid}`, `/offers/{oid}/candidates`.
Seul `GET /offers/{oid}/placements` répond — il renvoie les étapes avec leurs placements, et
confirme que les identifiants de placement lus ailleurs sont bons.

**Conduite à tenir :** ne pas deviner d'autres adresses d'écriture sur de vrais dossiers
candidats. Dire que l'action n'a pas pu être faite, vérifier que rien n'a bougé, et donner le
lien direct de la fiche pour que l'humain le fasse en un clic :
`https://app.tellent.com/ats/dashboard/overview?candidate={id}&company=103010`.

Un 404 peut aussi masquer un jeton sans droit d'écriture : à vérifier avant de conclure.

## Ce qui ne se fait jamais sans accord

Écarter une candidature, déplacer un dossier d'étape, envoyer un message à un candidat, publier
une offre. Le connecteur en lecture ne change rien à cette liste.
