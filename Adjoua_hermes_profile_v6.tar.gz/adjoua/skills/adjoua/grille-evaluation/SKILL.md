---
id: Y0651
name: grille-evaluation
description: "Étape 5 du processus — construire l'outil de notation AVANT d'évaluer. Produit un tableur de scorecard à 15 critères (6 techniques, 4 comportementaux, 2 entreprise, 3 parcours), échelle 1 à 5 avec ancrages, pondération par séniorité et seuils de décision. À charger quand plusieurs évaluateurs doivent noter pareil."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-04
---

# Étape 5 — Entretiens · Construire la grille

Vient **avant** `evaluation-candidat` : ici on fabrique l'outil, là on s'en sert. À charger dès que
plus d'une personne note, sinon chacun note dans sa tête et les notes ne se comparent pas.

Transposé de l'agent `Grille_Evaluation` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | L'entreprise : nom, description en une ligne, site, deux à trois comparables · le poste : intitulé, fiche complète si disponible, séniorité (déduite de la fiche si non précisée) |
| **Livrable** | Un tableur prêt à l'emploi, pas un tableau à recopier |
| **Critère de réussite** | Deux évaluateurs différents qui notent le même candidat arrivent au même ordre de grandeur |
| **Point de sortie** | Vers `evaluation-candidat` |

**Vérifier la mémoire avant de demander.** Si un profil de cette entreprise a déjà été enregistré, le
proposer et demander confirmation plutôt que de tout redemander. Un recruteur à qui on repose les
mêmes questions chaque semaine cesse de répondre.

## Enrichissement obligatoire

- **Site fourni** : l'ouvrir et en extraire deux à trois éléments de ton, de culture, de valeurs et
  de positionnement. Les réinjecter dans les critères « match entreprise ».
- **Comparables fournis** : une recherche rapide sur leur positionnement pour **calibrer le niveau
  d'exigence** — taille d'équipe encadrée, budgets typiques, standards du secteur.
- **Sauvegarder le profil de l'entreprise** pour les grilles suivantes.

## Structure — 15 critères, répartition fixe

| Catégorie | Nombre |
|---|---|
| 🎯 Compétences techniques | 6 |
| 🤝 Comportement | 4 |
| 🏢 Match entreprise | 2 |
| 📈 Parcours et potentiel | 3 |

**Total fixe : 15. Aucune dérive.** Un emoji par catégorie, jamais mélangés.

**Nommer les compétences techniques de façon spécifique, jamais générique.** « Bonne maîtrise des
outils » ne se note pas ; « pilotage de campagnes payantes avec budget et résultats » se note.

## Notation

Échelle de **1 à 5**, avec des ancrages explicites par critère.

**Pondération par défaut selon la séniorité** — technique / comportement / entreprise / parcours :

| Niveau | 🎯 | 🤝 | 🏢 | 📈 |
|---|---|---|---|---|
| Junior | 40 % | 25 % | 15 % | 20 % |
| Intermédiaire | 35 % | 25 % | 15 % | 25 % |
| Senior | 30 % | 30 % | 15 % | 25 % |
| Direction | 25 % | 35 % | 15 % | 25 % |

La note pondérée se calcule par formule dans le tableur, visible et modifiable.

## Aide à la notation — le cœur de l'outil

Pour **chaque** critère, fournir dans le fichier :

- une **question d'entretien suggérée** ;
- un exemple de **ce qui justifie un 5** ;
- un exemple de **ce qui justifie un 2**.

Exemple : critère « pilotage de campagnes payantes ». Question : « décrivez une campagne que vous
avez pilotée de bout en bout, avec son budget et ses résultats ». 5 = a piloté plus de six mois de
campagnes multicanal avec retour sur investissement documenté et optimisation continue. 2 =
connaissance théorique, aucun pilotage réel de budget.

Sans ces ancrages, la grille ne sert à rien : chacun met 3 par prudence.

## Seuils de décision

- **80 % et plus** : go franc — profil aligné, on continue.
- **60 à 79 %** : go avec réserves — creuser certains points en entretien complémentaire.
- **Moins de 60 %** : non — écart significatif avec les attentes.

## Le fichier

Un tableur, **jamais du texte brut à recopier**, contenant :

- l'en-tête entreprise, poste, date ;
- les 15 critères avec une **couleur fixe par catégorie** : technique bleu, comportement vert,
  entreprise jaune, parcours orange ;
- un **menu déroulant de 1 à 5** sur la colonne note ;
- une colonne commentaire large ;
- les ancrages et la question suggérée, en commentaire de cellule ou en colonne annexe ;
- la **note globale pondérée** par formule, selon la séniorité ;
- la légende de décision ;
- un onglet **comparaison multi-candidats**, pour aligner plusieurs notes globales sur le même poste.

## Ce qui accompagne le fichier

Deux choses, dans la conversation, en plus du tableur :

1. **L'introduction** : entreprise, poste, niveau, comparables, et les deux ou trois éléments relevés
   sur le site et chez les comparables qui ont servi à calibrer.
2. **Le message d'accompagnement** : une brève explication des critères retenus et de la pondération
   choisie, avec une proposition d'ajustement.

Une grille qui arrive sans explication de sa pondération se fait contester à la première note.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine — tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Cas limites

| Situation | Conduite |
|---|---|
| Fiche de poste absente | Déduire les compétences standard du marché pour ce poste et ce niveau |
| Site inaccessible ou non fourni | Le dire dans l'introduction : les critères « match entreprise » restent génériques |
| Comparables non fournis | Ne pas bloquer ; signaler que le niveau d'exigence suit les standards généraux |
| Poste hybride | Décomposer les facettes, **mais conserver la répartition 6/4/2/3** en répartissant entre elles |

## Ancrage de méthode

La structure de référence en recrutement — mission, résultats attendus, compétences, avec une
notation A / B / C où **A = 90 % de chances d'atteindre les résultats, B = 50 %, C = 25 %** — est
documentée dans `job-scorecard`. Les deux approches se combinent : celle-ci produit l'outil de
notation détaillé, celle-là définit ce que le poste doit produire.

## Provenance

| | |
|---|---|
| Agent d'origine | `Grille_Evaluation` |
| Version lue | v21 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 7397 caractères |
| Empreinte | `7afd0a282a2d` |

Prompt archivé dans `reference/prompts-dust/Grille_Evaluation.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**
