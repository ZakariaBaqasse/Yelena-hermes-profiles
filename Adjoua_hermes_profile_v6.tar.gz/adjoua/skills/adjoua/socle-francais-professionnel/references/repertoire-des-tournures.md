# Répertoire des tournures

Trois listes, à ouvrir au moment de la relecture. ⚠ Aucune n'est un automate : la bonne
réponse est souvent de refaire la phrase, pas de substituer un mot à un autre.

## 1 · Les calques de l'anglais

Un calque est un mot anglais habillé en français, qui recouvre un mot français exact. Ceux
qui suivent reviennent le plus souvent dans nos textes.

| Ce qu'on écrit | Ce que ça veut dire | Ce qu'on écrit à la place |
|---|---|---|
| adresser un problème | *to address* | traiter, régler, prendre en charge |
| supporter un client | *to support* | assister, prendre en charge, aider |
| une opportunité | *an opportunity* | une occasion, une piste, un marché |
| délivrer un livrable | *to deliver* | remettre, livrer, rendre |
| impacter | *to impact* | peser sur, modifier, faire baisser (dire quoi) |
| initier une démarche | *to initiate* | lancer, ouvrir, engager |
| au final | *in the end* | finalement, au bout du compte |
| en termes de délais | *in terms of* | pour les délais, côté délais |
| basé sur | *based on* | fondé sur, à partir de, d'après |
| digital | *digital* | numérique |
| agenda de la réunion | *agenda* | ordre du jour |
| définitivement | *definitely* | sans aucun doute, certainement |
| réaliser que | *to realize* | se rendre compte que, comprendre que |
| développer un outil | *to develop* | mettre au point, construire, écrire |
| challenger une hypothèse | *to challenge* | mettre à l'épreuve, contester, discuter |
| compléter une tâche | *to complete* | terminer, achever, finir |
| une audience | *audience* | un public, un lectorat, des destinataires |
| investiguer | *to investigate* | examiner, enquêter, vérifier |
| prioriser | *to prioritize* | classer par ordre d'urgence, traiter d'abord |
| implémenter | *to implement* | mettre en oeuvre, installer, appliquer |

**Ce qui reste :** le vocabulaire que l'équipe emploie en réunion. ROI, pipeline, ICP, BANT,
MEDDIC, TOFU/MOFU/BOFU, BFR, KPI, lead, closing. Traduire un terme de métier n'améliore pas
le français, cela oblige seulement le lecteur à retraduire.

## 2 · Les mots passe-partout et ce qu'ils cachent

Chacun tient dans n'importe quel dossier, ce qui prouve qu'il ne dit rien du nôtre. Devant
l'un d'eux, la bonne question est : *qu'est-ce qui s'est réellement passé ?*

| Mot | Ce qu'il remplace, souvent |
|---|---|
| mettre en place | installer, signer, écrire, recruter, ouvrir, brancher |
| solution | l'outil, le contrat, la méthode, le logiciel (le nommer) |
| dispositif | le formulaire, l'équipe, la procédure, la subvention |
| élément | le chiffre, la clause, la pièce, l'argument |
| problématique | le problème, la question, le blocage |
| thématique | le sujet, le thème |
| accompagner | former, conseiller, relire, présenter, relancer |
| optimiser | réduire de X, accélérer, supprimer une étape |
| dans le cadre de | pour, lors de, pendant |
| au niveau de | dans, chez, pour, sur |
| en matière de | pour, sur |
| permettre de | (souvent supprimable : *cela permet de réduire* → *cela réduit*) |
| il convient de | (à supprimer, et conjuguer le verbe qui suit) |
| il est important de noter que | (à supprimer entièrement) |
| un certain nombre de | combien exactement |
| différents, divers, plusieurs | combien exactement |

## 3 · Les liens logiques, par ce qu'ils font

Une machine juxtapose, un humain relie. Le connecteur porte le raisonnement : il se choisit
sur le rapport réel entre les deux phrases, jamais pour varier.

- **Cause** : parce que, car, puisque, faute de, sous l'effet de, d'où.
- **Conséquence** : donc, si bien que, au point que, d'où, ce qui explique.
- **Opposition** : mais, en revanche, alors que, tandis que, pourtant, si l'on excepte.
- **Concession** : certes… mais, même si, quoique, il reste que.
- **Condition** : si, à condition que, faute de quoi, sauf si.
- **Temps et ordre** : d'abord, ensuite, une fois que, dès que, depuis que.
- **Reprise et précision** : autrement dit, c'est-à-dire, plus précisément, en pratique.
- **Ajout d'un argument de même sens** : et, de plus, s'y ajoute, à quoi s'ajoute.

⛔ **Ceux qui sonnent la machine** parce qu'ils ne relient rien : *par ailleurs* employé comme
simple séparateur, *en effet* posé devant une phrase qui n'explique rien, *notamment* devant
une liste complète, *ainsi* en tête de conclusion, *il est à noter que*.

⛔ **Le connecteur de tête de paragraphe en série.** Quatre paragraphes qui commencent par
*Par ailleurs*, *De plus*, *Enfin*, *En outre* forment un sommaire, pas un raisonnement.

## 4 · La ponctuation qui porte du sens

- **Le deux-points** annonce une explication ou une liste, une fois par phrase au plus. Employé
  comme roulement de tambour avant une formule, il s'entend immédiatement.
- **Le point-virgule** sépare deux propositions liées, ou des éléments de liste qui contiennent
  déjà des virgules. Il est rare et précis, pas décoratif.
- **La virgule** marque la syntaxe, pas la respiration : elle isole une incise, sépare une
  subordonnée en tête de phrase, détache une apposition.
- **Les parenthèses** valent pour une précision accessoire. Une information nécessaire ne se
  met pas entre parenthèses, elle se met dans la phrase.
- ⛔ **Zéro tiret cadratin**, règle de la maison (l'équipe, 09/09/2026). Virgule, deux-points,
  point, ou trait d'union ordinaire.

## 5 · L'usage, là où il se discute

⛔ **L'orthographe et la grammaire ne sont PAS ici.** Elles vivent dans
`socle-relecture-orthographe`, qui liste les six fautes à chercher une par une (accord du
participe avec « avoir », « quel que soit », infinitif en -er contre participe en -é, « leur »
devant un verbe, sujet éloigné de son verbe, les classiques ce/se et ou/où). Deux exemplaires
d'une même liste divergent en une semaine : on n'en tient qu'un.

Ce qui suit relève de l'usage, pas de la faute, et se tranche donc ici.

- **« Malgré que » ne s'emploie pas** : *bien que*, ou *malgré le fait que* si l'on y tient.
- **« Pallier » et « se rappeler » sont transitifs directs** : *pallier un manque*, *se
  rappeler un fait*, sans préposition.
- **« Deuxième » quand il y en a plus de deux**, *second* quand la série s'arrête à deux.
- **« Suite à » est du courrier commercial** : *à la suite de*, *après*, *comme convenu*.
- **Les nombres** : espace insécable entre les tranches de mille et avant l'unité
  (*1 250 000 FCFA*), et on écrit en lettres de zéro à neuf dans un texte courant. Un chiffre
  en début de phrase s'écrit toujours en lettres, ou la phrase se retourne.
- **Les sigles ne prennent pas de point** (*OHADA*, *BCEAO*), et s'expliquent à leur première
  apparition, une seule fois.
