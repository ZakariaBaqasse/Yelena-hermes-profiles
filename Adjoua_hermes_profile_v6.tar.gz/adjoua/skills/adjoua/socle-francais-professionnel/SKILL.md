---
id: Y0671
name: socle-francais-professionnel
description: >
  Écrire un français que personne ne devine écrit par une machine : phrases construites avec
  un verbe et un sujet réel, liens logiques explicites, mot juste plutôt que mot passe-partout,
  calques de l'anglais retirés. Registre professionnel, ni scolaire ni littéraire. À charger
  avant de rédiger un livrable, une note, un courriel ou un message long, et à relire avant
  de remettre. Elle ne remplace pas la relecture anti-tics, qui passe après.
version: 1
maj: 2026-09-17
---

# Écrire en français, pour de vrai

> **Demandé par Yelema, 17/09/2026 :** *« il manque à tous les experts une compétence
> importante, de bien écrire en français, structurer des phrases complètes, aussi bien écrite
> que par un humain, ou un professeur de français ou un journaliste, tout en restant business.
> Pourquoi ? Parce que certaines formulations ne sont pas naturelles et font très IA. »*

Ce qui trahit une machine n'est presque jamais une faute. C'est une langue correcte et sans
syntaxe : des groupes de mots posés côte à côte, sans verbe qui les tienne, sans lien qui dise
pourquoi la deuxième phrase suit la première. Le lecteur ne sait pas nommer ce qui cloche, il
sent seulement qu'il lit un formulaire. Et un document qui se fait reformuler par celui qui le
reçoit n'a pas été livré, il a été sous-traité à l'envers.

**Quand la charger** : avant de rédiger quoi que ce soit qui sera lu par quelqu'un d'autre,
livrable, note, courriel, message long dans un fil, texte d'un visuel.

**Quand ne pas la charger** : pour du code, un tableur, une suite de valeurs, une commande.
Là, la langue n'a rien à tenir.

**Où elle s'arrête** : elle construit la phrase, et rien d'autre. `socle-ton-de-collegue` fixe
la chaleur et le registre ; `socle-relecture-orthographe` cherche les fautes une par une ;
`socle-relecture-anti-tics` retire les marqueurs de machine. L'ordre est : construire, chauffer,
corriger, nettoyer. ⛔ Aucune de ces quatre ne recopie la liste d'une autre.

**Les listes** (calques, mots passe-partout, connecteurs) vivent dans
`references/repertoire-des-tournures.md`. On y va au moment de la relecture, pas avant :
écrire avec la liste sous les yeux produit du texte qui évite des mots au lieu de dire quelque
chose.

## Ce qu'il faut avoir sous la main

1. **Le registre de l'entreprise** : vouvoiement ou tutoiement, « nous » ou « on », le
   vocabulaire du secteur, les mots que la maison n'emploie pas. Il vit dans la mémoire du
   poste (`memory/reference/`, ou le fichier de registre du client). **Pas de registre
   trouvé : on prend le vouvoiement et « nous », et on le dit en remettant le texte.**
2. **Un texte déjà validé par ce client**, s'il en existe un. Une page de ce qu'il a approuvé
   vaut mieux que toutes les règles générales.
3. **Ce que le document doit obtenir du lecteur** : une décision, un accord, une information.
   Un texte sans intention se reconnaît à ce qu'il est également tiède partout.

## Le geste, en cinq temps

**1 · Dire la phrase avant de l'écrire.** Une phrase qu'on ne peut pas prononcer d'un trait est
mal construite. C'est le seul contrôle qui attrape tout le reste.

**2 · Un sujet réel, un verbe conjugué, une idée.** Le sujet est celui qui agit, nommé, en tête
de phrase. La voix passive et les tournures impersonnelles cachent l'acteur, et cacher l'acteur
est presque toujours une faiblesse du raisonnement, pas un choix de style.

> *Une décision a été prise concernant la refonte du processus de validation.*
> **→** *Le comité a décidé de refondre la validation.*

> *Il convient de noter que les délais sont en augmentation.*
> **→** *Les délais s'allongent.*

**3 · Lier, au lieu de juxtaposer.** Deux phrases qui se suivent entretiennent un rapport :
cause, opposition, conséquence, temps, condition. Un humain l'écrit, une machine le laisse
deviner. Le mot de liaison porte le raisonnement ; sans lui, le lecteur reconstruit à ses frais
et se trompe.

> *Le fournisseur a livré en retard. Nous avons décalé le lancement.*
> **→** *Le fournisseur ayant livré en retard, nous avons décalé le lancement.*
> **ou** *Nous avons décalé le lancement parce que le fournisseur a livré en retard.*

**4 · Le mot juste contre le mot passe-partout.** « Mettre en place », « solution »,
« dispositif », « élément », « problématique », « accompagner » remplissent une ligne sans rien
apprendre. Remplacer par ce qui s'est réellement passé : signer, installer, écrire, refuser,
recompter. La règle pratique : si le mot tient dans n'importe quel dossier, il ne dit rien du
nôtre.

**5 · Varier la longueur, pas le vocabulaire.** Une longue qui déroule, une courte qui tranche.
C'est le rythme qui fait humain, pas la richesse des synonymes ; chercher un synonyme pour ne
pas répéter un mot technique produit l'effet inverse, on répète le mot technique.
⛔ **La cadence ternaire systématique** (trois adjectifs, trois groupes, trois exemples) est le
tic de rythme le plus reconnaissable. Deux, ou quatre.

## Rester business, et pas professeur

La grammaire d'un professeur, l'économie d'un journaliste, le vocabulaire de la maison. Ce qui
reste dehors :

- **Pas de littérature** : aucune métaphore, aucune image, aucun effet. Un chiffre se pose, il
  ne « s'envole » pas.
- **Pas de point d'exclamation**, pas de question rhétorique dans un livrable.
- **Pas d'adjectif d'enthousiasme** (« remarquable », « incontournable », « stratégique »
  employé comme compliment). Un fait se montre, il ne se qualifie pas.
- **Pas de pédanterie** : le subjonctif imparfait, l'inversion, la phrase à trois relatives
  emboîtées sont aussi peu naturels que le style formulaire, dans l'autre sens.
- **Les termes du métier restent** : ROI, pipeline, ICP, BFR. On ne francise pas ce que
  L'équipe dit en réunion ; on traduit ce qui a un mot français exact et courant.

## Ce qu'elle rend

Un texte dont chaque phrase a un sujet identifiable et un verbe, dont les paragraphes tiennent
par des liens explicites, qui nomme les choses par leur nom, et qui se lit à voix haute sans
buter. Rien de visible ne signale qu'elle est passée : c'est le but.

## Les pièges de ce travail

- ⛔ **Réécrire jusqu'à changer le fond.** La langue se corrige, le chiffre et la nuance ne
  bougent pas. Devant un doute, garder la formulation d'origine et signaler la phrase.
- ⛔ **Appliquer le répertoire mot à mot.** « Impacter » est laid, « avoir un impact sur » l'est
  aussi : parfois la bonne réponse est de refaire la phrase autrement, pas de substituer.
- ⛔ **Uniformiser le style d'un client sur celui d'un autre.** Le registre se lit dans la
  mémoire du poste, il ne se déduit pas du secteur.
- ⛔ **Confondre naturel et familier.** « Du coup », « en vrai », « clairement » ne sont pas plus
  humains, ils sont seulement plus oraux, et dans une note écrite ils sonnent faux.
- ⛔ **Relire une seule fois.** La construction et le nettoyage sont deux passages distincts, et
  celui qui vient de rédiger ne voit pas ses propres tournures. Poser le texte, puis le relire.
