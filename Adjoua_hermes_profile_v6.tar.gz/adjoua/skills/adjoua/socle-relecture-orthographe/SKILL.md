---
id: Y0637
name: socle-relecture-orthographe
description: "La passe d'orthographe et de grammaire avant toute remise, message dans le fil compris. Un outil relève les mots mal tapés ; la grammaire, lui, ne la voit pas, et cette compétence dit exactement quoi relire à la main. Existe parce qu'une faute d'accord dans un livrable client détruit plus de crédit qu'un retard d'une journée."
bucket: A
tags: [Conduite, Livrables, Horizontal, Socle]
version: 1
maj: 2026-09-15
---

# Relecture d'orthographe et de grammaire

## Pourquoi cette compétence existe

Demande de Yelema, 15/09/2026 : *« ANTI FAUTE ORTHOGRAPHE OU GRAMMAIRE »*.

Une faute dans un livrable remis à un client ne se rattrape pas. Elle ne se discute pas non
plus : le lecteur ne se demande pas si le fond est juste, il se demande qui a relu. Un retard
d'une journée s'explique, une faute d'accord ne s'explique pas.

⚠ Cette compétence ne remplace pas `socle-relecture-anti-tics`, qui traque les marqueurs de
machine. Les deux passent, dans cet ordre : d'abord le sens et le ton, ensuite la langue.

---

## 1. La passe mécanique : l'orthographe d'usage

```bash
python3 ~/.claude/outils-communs/relire-orthographe.py <fichier>
echo "un message" | python3 ~/.claude/outils-communs/relire-orthographe.py -
```

Il rend la liste des mots que le dictionnaire français ne connaît pas, avec la ligne et les
suggestions. Il attrape ce que l'œil rate : le mot juste mal tapé, l'accent oublié, le nom
propre écorché, le pluriel d'un mot rare.

- Un mot juste que l'outil ne connaît pas s'ajoute à
  `~/.claude/outils-communs/mots-de-la-maison.txt`, une ligne, un mot.
- ⛔ **On n'y ajoute que ce qu'on a vérifié.** Un mot posé là ne sera plus jamais signalé :
  y ranger une faute revient à la graver.
- Les mots entièrement en capitales sont laissés passer, parce que la maison met en
  capitales pour insister. Le prix est assumé : une faute écrite en capitales passe.

---

## 2. Ce que la machine ne voit pas, et qui se relit à la main

🚨 **L'outil ne voit AUCUNE faute de grammaire.** « Les données est fausse », « je les ai
vu », « quelque soit le résultat » passent sans un mot, parce que chaque mot existe. Croire
que l'outil couvre la grammaire est pire que ne pas l'avoir : on cesse de relire.

Les six erreurs qui reviennent, et qu'il faut chercher **une par une** :

| À chercher | Ce qui est juste |
|---|---|
| Accord du participe avec `avoir` | il s'accorde avec le complément **placé avant** : « les notes que j'ai **écrites** », mais « j'ai **écrit** les notes » |
| `quelque soit` | **quel que soit** le résultat, **quelle que soit** la date |
| Infinitif et participe en `-er` / `-é` | remplacer par *vendre* : « à **livrer** » (à vendre), « il a **livré** » (il a vendu) |
| `leur` devant un verbe | invariable : « je **leur** ai dit », jamais « leurs ai dit » |
| Sujet loin de son verbe | « la liste des livrables **est** prête », pas « sont prêtes » |
| `ce` / `se`, `ces` / `ses`, `ou` / `où`, `a` / `à` | les classiques, à vérifier en fin de passe |

**Le geste qui marche vraiment :** relire **la dernière phrase en premier**, puis remonter.
Lu à l'endroit, le cerveau répare les fautes sans les voir.

---

## 3. Quand cette passe est obligatoire

- Tout **livrable** remis, quel que soit son format.
- Tout **message dans le fil** qui dépasse trois lignes.
- Toute **page publiée**, tout visuel qui porte du texte : là, la faute est publique et
  reste en ligne.
- ⛔ Tout texte qui porte le **nom d'un tiers** : une entreprise, un ministère, une personne.
  Un nom propre écorché se lit comme un manque de respect, pas comme une coquille.

---

## Garde-fous

- ⛔ **Aucun livrable ne part sans cette passe**, même pressé. Une faute remise coûte plus
  cher que l'heure gagnée.
- ⛔ **Ne jamais corriger une citation.** Ce qu'un client a écrit se cite tel quel ; si sa
  phrase porte une faute, on la cite sans la réparer et sans la signaler.
- ⚠ **Le français d'ici n'est pas une faute.** Une expression ivoirienne attestée, un mot du
  nouchi validé, un sigle de la zone ne se corrigent pas au motif que Paris ne les connaît
  pas. En cas de doute, `parler-ivoirien` tranche, pas le dictionnaire.
