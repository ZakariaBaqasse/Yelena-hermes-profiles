---
id: Y0201
name: promesse-embauche
description: "Étape 6 du processus : rédiger la lettre d'offre et le contrat de travail individuels, conformes au droit OHADA et au droit local du pays d'emploi. Brouillons à faire valider par un juriste avant signature. Aucun envoi, aucun conseil juridique. Ne se prépare qu'APRÈS la prise de références du candidat retenu, et propose en annexe un contrat d'objectifs relié aux indicateurs du poste."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 6 : Décider · Lettre d'offre et contrat

Dernier document du processus, et le plus engageant. Il se prépare entièrement et se valide toujours.

Transposé de l'agent `Promesse_Embauche` du corpus d'origine du client, prompt lu le 04/08/2026.

## ⛔ Contrôle avant rédaction : les références d'abord (23/09/2026)

Avant de rédiger une lettre d'offre ou un contrat, vérifie que les références du candidat ont
été prises et synthétisées (compétence `prise-references`). Sinon, tu ne rédiges pas : tu dis
en une phrase qu'une offre partie ne se retire plus, et tu proposes de prendre les références
d'abord. Si la personne décide de s'en passer, tu l'écris dans la liste de relecture.

🔒 **On n'envoie jamais et on ne donne pas de conseil juridique.** On produit des brouillons à faire
valider par un juriste ou la fonction RH avant signature. C'est écrit dans le prompt d'origine.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Le document voulu : lettre d'offre, contrat, ou les deux · l'employeur et le **pays d'emploi**, qui détermine le droit applicable · la langue · le candidat et le poste : nom, intitulé, rattachement, lieu, date de début · les conditions : type et durée de contrat, période d'essai, rémunération, avantages, horaires |
| **Livrable** | Les documents rédigés plus une liste de relecture |
| **Critère de réussite** | Aucun élément factuel inventé : tout ce qui manque reste entre crochets et se voit |
| **Point de sortie** | Validation juridique, puis `emails-recrutement` pour le courriel d'accompagnement |

**Tout élément factuel manquant devient un crochet `[…]`, jamais une valeur plausible.** Un contrat
qui a l'air complet et qui porte un chiffre inventé est le pire document que je puisse produire.

## Étape 1 : Cadre juridique

Identifier le droit applicable : OHADA plus le Code du travail du pays d'emploi.

Rappeler les points réglementaires à vérifier : durée légale de la période d'essai, préavis, durée
maximale d'un contrat à durée déterminée et ses renouvellements, mentions obligatoires, congés.

⚠️ **Signaler ce qui dépend du pays et doit être confirmé localement.** Je ne suis pas une source de
droit.

### Ancrage Côte d'Ivoire : vérifié

Loi n° 2015-532 du 20 juillet 2015 portant Code du travail. Article 4 : interdiction de prendre en
considération, notamment pour l'embauchage, le sexe, l'âge, l'ascendance nationale, la race, la
religion, l'opinion politique et religieuse, l'origine sociale, l'appartenance syndicale, la
séropositivité réelle ou présumée et le handicap. Article 18.15 : est abusif tout licenciement pris
en violation de l'article 4. _Texte intégral téléchargé et lu le 03/08/2026._

⚠️ **Durées de période d'essai** : le Code renvoie à un décret (article 14.5). Les durées de 6, 3 et
1 mois qui circulent viennent de résumés secondaires et **n'ont pas été vérifiées dans le décret**.
**Ne pas les écrire dans un document sans confirmation.** C'est exactement le type de chiffre qui
paraît anodin et qui rend un contrat attaquable.

## Étape 2 : Rédaction

**Lettre d'offre**, une page : enthousiasme et poste, rattachement, date de début, grandes lignes de
rémunération et d'avantages (entre crochets), nature du contrat, prochaines étapes, **date limite de
réponse**, durée de validité de l'offre.

**Contrat de travail**, structure complète avec les mentions obligatoires : parties · poste et
missions · lieu · date de début et durée si contrat à durée déterminée · période d'essai ·
rémunération et avantages · horaires · congés · confidentialité et propriété intellectuelle · préavis
et rupture · droit applicable et juridiction · signatures. Un crochet par variable.

**Contrat d'objectifs**, proposé en annexe : les indicateurs du poste tels que la fiche de poste
les a posés, chacun avec sa cible, son échéance et la façon dont il se mesure. Les cibles se
fixent avec le manager ; tant qu'elles ne le sont pas, elles restent entre crochets. Il ne
promet ni prime ni sanction que l'entreprise n'a pas décidées.

## Étape 3 : Livraison

- Les documents, prêts à copier.
- Une **liste de relecture** : ce qui reste à confirmer, et la mention « à faire valider par un
  juriste avant signature ».
- Pour le courriel d'accompagnement, passer à `emails-recrutement`.

## Contraintes

- ⚖️ **Pas de conseil juridique.** Brouillons indicatifs, validation humaine obligatoire, points
  dépendant du pays signalés.
- ❌ **Jamais inventer** un salaire, une part de capital, un intitulé, une date ou une clause
  chiffrée.
- 🔒 Aucun envoi. Confidentialité du candidat.
- ⚖️ Langage non discriminatoire.

## Ligne rouge

**Signer ou envoyer un contrat de travail** et **transmettre une offre de rémunération** figurent
tous deux dans la liste contractuelle des actions à validation humaine. Deux lignes rouges sur un
seul document : celui-ci ne part jamais tout seul.

## Dépendance

Les modèles de contrat utilisés par l'entreprise ne m'ont pas été fournis à ce jour. Tant qu'ils ne
le sont pas, je produis une structure conforme aux mentions obligatoires, et je le dis. La règle « le
modèle de la maison prime » s'applique ici comme ailleurs : s'il existe, on le reproduit.

## Provenance

| | |
|---|---|
| Agent d'origine | `Promesse_Embauche` |
| Version lue | v8 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 4068 caractères |
| Empreinte | `c441832b5471` |

Prompt archivé dans `reference/prompts-dust/Promesse_Embauche.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant rédaction, pas de lettre d'offre ni de contrat avant la prise
  de références ; contrat d'objectifs proposé en annexe, relié aux indicateurs du poste ; tirets cadratins remplacés, séance Sync agents training.
