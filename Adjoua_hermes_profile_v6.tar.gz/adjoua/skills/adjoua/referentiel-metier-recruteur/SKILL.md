---
id: Y0596
name: referentiel-metier-recruteur
description: Le référentiel international du métier de recruteur — ce qu'un bon recruteur doit savoir faire, comment il s'organise, et ce que la preuve scientifique dit de chaque méthode de sélection. À charger pour s'auto-évaluer, cadrer un processus, arbitrer entre deux méthodes, ou justifier un choix devant une direction.
version: 1
maj: 2026-08-13
---

# Référentiel métier du recruteur

## Ce que ce référentiel est, et ce qu'il n'est pas

Il rassemble **des sources ouvertes réellement lues**, pas des bonnes pratiques de blog. Chaque
affirmation porte sa source et sa date de lecture. Ce qui n'a pas pu être ouvert est écrit comme
tel — voir « Ce que je n'ai pas pu lire ».

Deux familles à ne jamais confondre :

| Famille | Ce qu'elle dit | Ce qu'elle ne dit pas |
|---|---|---|
| **Référentiels de profession** (CIPD, ISO) | ce qu'un recruteur doit savoir faire, par niveau | si la méthode marche |
| **Preuves scientifiques** (méta-analyses, essais contrôlés) | ce qui prédit la réussite en poste | comment organiser un service |

Un recruteur qui ne connaît que la première famille applique des procédures sans savoir lesquelles
servent. Un recruteur qui ne connaît que la seconde a raison et n'est pas suivi.

---

## 1 · Le référentiel de compétences — CIPD Profession Map, domaine « Resourcing »

_Source lue intégralement le 13/08/2026 :_
<https://www.cipd.org/uk/the-people-profession/the-profession-map/explore-the-profession-map/specialist-knowledge/resourcing/>

Le CIPD est l'organisme professionnel britannique des métiers RH. Son référentiel définit le
resourcing comme « identifier, attirer et recruter pour obtenir les bonnes personnes pour
l'organisation » — au bon poste, **au bon moment et au bon coût**.

**Neuf domaines de connaissance**, chacun décliné sur quatre niveaux d'impact
(Foundation → Associate → Chartered Member → Chartered Fellow) :

| # | Domaine | Ce que le niveau le plus bas exige | Ce que le niveau le plus haut exige |
|---|---|---|---|
| 1 | Planification des effectifs | comprendre son effet sur le recrutement | bâtir une stratégie qui tient le budget **et** le plan d'effectifs |
| 2 | Types de travailleurs | connaître les formes d'emploi | anticiper leur évolution et son effet sur la stratégie |
| 3 | Marque et positionnement | connaître sa marque et sa position | positionner l'organisation dans un marché du travail donné |
| 4 | Attraction et sourcing | connaître les canaux | définir la direction stratégique du sourcing |
| 5 | Évaluation et sélection | savoir ce qui rend une évaluation juste et objective | établir la stratégie d'évaluation de l'organisation |
| 6 | **IA dans le recrutement** | connaître bénéfices **et risques** | définir la stratégie d'IA de recrutement de l'organisation |
| 7 | Expérience candidat | savoir la mesurer | piloter l'amélioration continue avec ces retours |
| 8 | Programmes d'employabilité | connaître ceux de sa maison | bâtir des partenariats d'employabilité |
| 9 | Mobilité internationale | connaître les politiques | mesurer l'effet de la mobilité sur la performance |

**Ce que ce référentiel apprend sur l'organisation d'un recruteur**, et qui se voit dans la
progression des quatre niveaux : on passe de *connaître les outils* → *savoir choisir* →
*savoir concevoir un dispositif* → *savoir définir une stratégie*. Le partage entre un exécutant et
un responsable ne tient pas au nombre de postes pourvus : il tient à **la capacité de concevoir un
dispositif qui tient sans soi**.

⚠️ **Le domaine 6 existe dans le référentiel officiel du métier.** Une IA qui recrute n'est pas un
sujet d'avenir, c'est une compétence attendue — et son niveau d'entrée porte sur les **risques**
autant que les bénéfices. Voir la compétence `audit-inclusif` et la section « Les cinq questions »
de `MEMORY.md`.

---

## 2 · Ce que la preuve dit de chaque méthode de sélection

_Source lue intégralement (74 pages) le 04/08/2026 : Schmidt, Oh & Shaffer,_
*The Validity and Utility of Selection Methods in Personnel Psychology* —
<https://home.ubalt.edu/tmitch/645/session%204/Schmidt%20&%20Oh%20validity%20and%20util%20100%20yrs%20of%20research%20Wk%20PPR%202016.pdf>

| Méthode | Validité prédictive |
|---|---|
| Aptitude générale | 0,65 |
| **Entretien structuré** | **0,58** |
| Épreuve pratique / échantillon de travail | 0,33 _(Roth, Bobko & McFarland 2005)_ |
| Entretien non structuré | nettement inférieur, apport incrémental faible |

**Trois conséquences opérationnelles, et elles tranchent des débats réels :**

1. **Un business case ne décide pas d'une embauche.** Il éclaire le raisonnement et alimente un
   entretien ciblé. La décision vient de la **combinaison** cas + entretien structuré + références.
2. **L'entretien structuré est la meilleure méthode qu'un évaluateur maîtrise seul**, sans budget
   et sans outil. C'est le premier investissement, avant tout logiciel.
3. **Les prises de références manquent presque partout** — c'est le trou le plus courant d'un
   circuit d'évaluation, et le moins cher à combler.

**Structure d'une scorecard** _(support ghSMART « Using the A Method for Hiring Successfully »,
Bruce W. Elder, 34 diapositives, © 2011, lu le 04/08/2026 —_
<https://www.mequoda.com/wp-content/uploads/Using-the-A-Method-for-Hiring-Successfully.pdf>_)_ :
mission / résultats attendus / compétences, notation **A = 90 % de chances d'atteindre les
résultats, B = 50 %, C = 25 %**, et quatre entretiens (filtrage, parcours complet, ciblé,
références).

---

## 3 · Ce qui rend une sélection défendable

_Source lue le 13/08/2026 : EEOC, « Employment Tests and Selection Procedures » —_
<https://www.eeoc.gov/laws/guidance/employment-tests-and-selection-procedures>

Le régulateur américain de l'égalité professionnelle pose trois exigences que **toute** méthode de
sélection doit satisfaire, et qui se transposent telles quelles :

1. **La procédure doit être validée** — reliée au poste, et ses résultats adaptés à l'usage qu'on
   en fait. « Job-related and consistent with business necessity ».
2. **L'impact disparate est interdit même sans intention** : une procédure neutre qui a **pour
   effet** d'exclure de façon disproportionnée est illicite. Ce n'est pas l'intention qui est
   jugée, c'est l'effet mesuré.
3. **Chercher l'alternative moins discriminante** : à efficacité égale, la méthode qui exclut le
   moins s'impose.

Et la phrase à retenir : *« No test or selection procedure should be implemented without an
understanding of its effectiveness and limitations for the organization. »*

⚠️ **Transposition en Côte d'Ivoire.** Ce texte est américain et ne s'applique pas ici.
L'équivalent local est l'**article 4 du Code du travail** (loi n° 2015-532 du 20 juillet 2015), qui
interdit de prendre en considération pour l'embauchage le sexe, l'âge, l'ascendance nationale, la
race, la religion, l'opinion, l'origine sociale, l'appartenance syndicale, la séropositivité et le
handicap — l'article 18.15 qualifiant d'abusif tout licenciement pris en violation. Ce que l'EEOC
apporte en plus, et qui n'est **pas** écrit dans le Code ivoirien : le raisonnement par **effet
mesuré** plutôt que par intention. C'est ce raisonnement qui a produit l'audit de biais du
12/08/2026, pas une obligation légale locale.

---

## 4 · L'organisation d'un recruteur — ce qui distingue un service qui tient

Tiré de la progression du référentiel CIPD, de la veille sur 68 parcours du 12/08/2026, et de ce
qui a réellement cassé sur les dossiers en cours.

1. **Une trace de décision par candidat.** Un circuit où une étape ne laisse aucun écrit n'est pas
   auditable et ne permet pas d'arbitrer entre deux finalistes. _Constat réel : sur 140 candidats
   examinés chez ce client, un seul auteur de comptes rendus, et l'étape « rencontre des
   cofondateurs » ne produit rien._
2. **Les grilles s'écrivent avant les entretiens**, jamais après. Une grille écrite après sert à
   justifier une décision déjà prise.
3. **Un point unique d'évaluation est un risque d'exploitation**, pas un détail d'organisation :
   une absence d'une semaine arrête le recrutement.
4. **Mesurer ce que le métier ne mesure pas** : qualité d'embauche à 6 et 12 mois, taux de
   maintien, écart entre ce qu'une scorecard prévoyait et ce qui s'est produit. _12 % seulement des
   68 parcours étudiés revendiquent une pratique chiffrée, pour une durée médiane en poste de
   1,4 an : on ne mesure pas ce qu'on ne reste pas assez longtemps pour observer._
5. **Nombre de postes pourvus et délai d'embauche ne mesurent pas la qualité** — un mauvais
   recrutement les satisfait aussi bien qu'un bon.
6. **Un verdict tient en trois réponses possibles** : oui on y va · pas encore, corrige ces deux ou
   trois points et reviens · non, et voici pourquoi. Aucune échappatoire.

---

## Ce que je n'ai pas pu lire, et qu'il ne faut pas croire lu

- **ISO 30405:2023 — « Human resource management — Guidelines on recruitment »**, seconde édition
  publiée en juin 2023, est **le seul texte véritablement international** sur le sujet. Elle couvre
  la préparation, la planification, la conduite des phases et parties prenantes, puis la revue et
  l'apprentissage, avec une approche de l'expérience candidat.
  🔴 **Le texte est payant et n'a pas été lu.** Les trois pages consultées (iso.org, la plateforme
  de consultation ISO, l'aperçu ANSI) répondent toutes **403**. Ce qui précède vient de la notice
  publique, pas du texte. **Rien de cette norme ne se cite comme une exigence tant qu'elle n'a pas
  été achetée et lue.** Coût à instruire si le client veut s'y aligner formellement.
- **SHRM** (corpus américain d'acquisition de talents) : non ouvert à ce jour.
- **Google re:Work**, guide sur l'entretien structuré : les URL connues renvoient 404, le site
  semble avoir été réorganisé. Non lu.

## Provenance

Compétence écrite le 13/08/2026 sur demande du client. Sources primaires archivées dans
`reference/sources-metier/`. Les sources sur le recrutement technique sont dans la compétence
`recrutement-technique`, qui en est le prolongement.
