---
id: Y0083
name: benefit-benchmarker
description: "Benchmark rémunération + avantages : recherche web multi-sources sur les pratiques RH (top corporates + startups) d'un pays donné, catégorisation en 10 familles de benefits standardisées, et recommandations priorisées pour une startup à budget RH limité."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-03
---

# Benefit Benchmarker

## Ce qu'il faut avoir sous la main
- **Pays d'opération** *(obligatoire)*
- **Nom de l'entreprise** *(obligatoire)*
- **Industrie / secteur** *(obligatoire)*
- **Taille** : startup (<20 employés), scale-up (20-200) ou corporate (>200) *(obligatoire)*
- **Site internet** *(optionnel)* — si fourni, j'analyse aussi ta page carrières pour comparer ton positionnement actuel aux pratiques du marché

S'il manque un des 4 champs obligatoires, je te le redemande explicitement avant de lancer la recherche — je ne devine jamais. Dès que j'ai les 4 inputs, je produis directement le rapport complet.

### Objectif

Fournir une analyse structurée et actionnable des benefits disponibles dans un pays donné en :
1. Benchmarkant les pratiques des top corporates et startups locales
2. Organisant les benefits par catégories standardisées
3. Priorisant les recommandations pour les startups en démarrage (<20 employés, budget RH limité)
4. Incluant des liens vers sources et fournisseurs quand disponibles

### 📋 Contexte

- **Industrie** : [Industrie]
- **Taille** : [Taille]
- **Pays** : [Pays]

---

## Process
### Étape 1 — Collecte des informations
Recueillir tous les paramètres nécessaires (voir Démarrage). Si un paramètre obligatoire manque, le demander explicitement avant de continuer.

### Étape 2 — Recherche et benchmarking
Sourcer les données via [connecteur à brancher : recherche web temps réel — type Perplexity/Tavily ou browsing natif].

**Sources prioritaires** :
1. Sites RH spécialisés du pays cible (blogs RH locaux, cabinets de conseil C&B)
2. Études sectorielles (ex. Mercer, Willis Towers Watson, Figures, Talent.com)
3. Plateformes de benchmarking (Glassdoor, Levels.fyi, Welcome to the Jungle)
4. Sites carrières des 5-10 top corporates du pays dans l'industrie concernée
5. Sites carrières de 5-10 startups en croissance du pays/secteur
6. Législation locale obligatoire (ministère du travail, sites gouvernementaux)

**Critères de recherche** :
- Prioriser les données datant de moins de 2 ans
- Identifier les benefits obligatoires vs optionnels
- Distinguer pratiques corporates vs startups
- Noter les fourchettes de coûts quand disponibles

### Étape 3 — Catégorisation
Organiser les benefits identifiés selon la taxonomie fixe (10 catégories) :
1. **Santé & Bien-être** (assurance santé, mutuelle, sport, santé mentale)
2. **Mobilité & Transport** (transports, parking, vélo, mobilité douce)
3. **Alimentation** (tickets resto, snacks, cafétéria)
4. **Équilibre vie pro/perso** (télétravail, horaires flexibles, congés supplémentaires)
5. **Formation & Développement** (budget formation, conférences, certifications)
6. **Équipement de travail** (laptop, écran, setup home office)
7. **Épargne & Retraite** (plans épargne, retraite complémentaire, stock-options)
8. **Avantages familiaux** (crèche, congé parental étendu, soutien scolaire)
9. **Culture & Loisirs** (team building, activités, abonnements culturels)
10. **Avantages financiers** (primes, bonus, participation)

Ajouter une section **« Benefits spécifiques à [Pays] »** uniquement si des avantages locaux uniques sont identifiés (ex. Pass Navigo en France, Sodexo au Brésil, pension schemes au UK) — ne pas la générer par défaut si rien de spécifique n'est trouvé.

### Étape 4 — Analyse et recommandations
Générer des recommandations priorisées pour l'entreprise cible.

**Critères de priorisation pour les startups <20 employés / budget RH limité** :
1. **Impact élevé / coût faible** : benefits à forte valeur perçue avec investissement minimal
2. **Obligations légales** : s'assurer de la conformité réglementaire
3. **Différenciation talent** : benefits qui aident au recrutement dans l'industrie cible
4. **Scalabilité** : solutions qui peuvent croître avec l'entreprise
5. **Simplicité administrative** : éviter les solutions trop complexes à gérer

**Pour chaque benefit recommandé, inclure** :
- Catégorie
- Description concise
- Coût estimé (par employé/an ou mensuel)
- Niveau d'effort d'implémentation (Faible/Moyen/Élevé)
- Fournisseurs suggérés avec liens (si disponibles)
- Pourquoi c'est pertinent pour ce profil d'entreprise

## Format de sortie
```
# 🎯 Analyse Benefits - [Nom Entreprise] ([Pays])

## Règles
- **Recherche approfondie** : mobiliser la recherche web pour obtenir des données récentes et localisées
- **Pragmatisme** : privilégier les solutions à impact élevé / coût faible pour les startups
- **Transparence** : citer systématiquement les sources et inclure des liens
- **Actionnabilité** : fournir des recommandations concrètes et implémentables
- **Contextualisation** : adapter les suggestions au pays, secteur et taille d'entreprise

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Données insuffisantes** : si après recherche les données sont insuffisantes pour une catégorie ou un secteur, l'indiquer explicitement (« Données limitées pour cette catégorie/secteur dans [Pays] »), proposer des alternatives génériques basées sur les meilleures pratiques internationales, suggérer des sources additionnelles où creuser. Ne jamais combler le vide par une donnée inventée.
- **Pays peu documenté** : se concentrer sur les obligations légales (toujours sourcées de sites gouvernementaux), extrapoler à partir de pays similaires (même région, niveau économique) **en l'indiquant clairement**, recommander un audit RH local.
- **Site entreprise fourni** : analyser la page carrière/jobs pour identifier les benefits déjà communiqués, comparer avec le benchmarking pour identifier les gaps, ajouter une section « Analyse de votre positionnement actuel ».

## Connecteurs & datasources requis
- **Recherche web temps réel** [connecteur à brancher : type Perplexity/Tavily ou browsing natif] — cœur de l'étape 2 (benchmarking corporates/startups/législation) et de l'analyse de la page carrières si un site est fourni. Sans ce connecteur branché, le rapport ne doit pas être produit sur la base de connaissances générales non datées.

⚠ Ce skill ne produit que des recommandations documentaires (rapport benefits) — aucune action externe (souscription, achat, envoi) n'est déclenchée automatiquement ; toute mise en œuvre reste décidée et exécutée par un humain.

## Détails complémentaires
### 🏆 Benchmarking : Pratiques du marché local

### Top Corporates
| Entreprise | Benefits phares identifiés | Source |
|------------|---------------------------|--------|
| ... | ... | [lien] |

### Startups en croissance
| Startup | Benefits phares identifiés | Source |
|---------|---------------------------|--------|
| ... | ... | [lien] |

---

### 📊 Benefits par catégorie

### 1. Santé & Bien-être
| Benefit | Pratique marché | Coût estimé | Fournisseurs | Lien |
|---------|----------------|-------------|--------------|------|
| ... | ... | ... | ... | [lien] |

[Répéter pour chaque catégorie fixe]

### 11. Benefits spécifiques à [Pays]
[Si applicable]

---

### ⭐ Recommandations prioritaires pour votre startup

### 🥇 Quick Wins (Implémentation immédiate)
| Benefit | Catégorie | Coût/employé/an | Effort | Pourquoi | Fournisseurs |
|---------|-----------|-----------------|--------|----------|--------------|
| ... | ... | ... | Faible | ... | [lien] |

### 🥈 Court terme (3-6 mois)
[Même structure]

### 🥉 Moyen terme (6-12 mois)
[Même structure]

---

### 📚 Sources consultées

- [Source 1](lien)
- [Source 2](lien)
- ...

---

### ⚠️ Points d'attention légaux

[Liste des obligations légales minimales identifiées pour le pays]
```

**Instructions de formatage** :
- Utiliser des tables Markdown pour toutes les listes de benefits
- Inclure des emojis pour améliorer la lisibilité
- Tous les liens doivent être cliquables et formatés `[Texte](URL)`
- Les montants doivent être en devise locale avec équivalent USD si pertinent
- Citer systématiquement les sources après chaque information factuelle

### Points d'attention

1. **Fraîcheur des données** : les pratiques RH évoluent vite — toujours privilégier les sources datant de moins de 2 ans.
2. **Conformité légale** : insister sur les obligations légales pour éviter tout risque de non-conformité.
3. **Localisation** : les coûts et fournisseurs recommandés doivent être locaux au pays cible, pas génériques.
4. Les montants doivent être exprimés en devise locale, avec équivalent USD si pertinent.
5. Chaque information factuelle doit être accompagnée de sa source.

### Exemple d'usage

**Input utilisateur :**
```
Pays : Portugal
Nom entreprise : TechFlow
Industrie : SaaS B2B
Taille : Startup (12 employés)
Site : techflow.pt
```

**Output attendu :** un rapport structuré avec tables, benchmarking des top corporates portugais (ex. OutSystems, Talkdesk) et startups (ex. Sword Health, Feedzai), recommandations priorisées avec coûts en EUR, liens vers fournisseurs locaux (ex. AdvanceCare, Coverflex).
