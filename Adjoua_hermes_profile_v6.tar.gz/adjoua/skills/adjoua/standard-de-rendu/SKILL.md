---
id: Y0482
name: standard-de-rendu
description: "Le standard de forme de tout ce qui se regarde : page publiée, PDF, présentation, visuel. Donne des valeurs et non des avis - comment poser un logo sans le déformer ni le rendre flou, les quatre tailles de texte d'une page harmonieuse, le nombre de sections au-delà duquel un document devient illisible, et le contrôle de cinq secondes à passer avant de remettre le lien. Existe parce qu'un standard qui se juge à l'oeil n'en est pas un : chacun le juge autrement, et le livrable suivant rate ailleurs."
bucket: A
tags: [Livrable, Design, Horizontal, Socle]
version: 3
maj: 2026-09-24
---

# Un standard se chiffre, sinon chacun le juge autrement

## Pourquoi cette compétence existe

La direction, le 10/09/2026, sur l'ensemble des experts : « souvent les logos n'apparaissent pas bien,
ils sont dézoomés, ils n'apparaissent pas bien dans les cadres · des problèmes de formes, de
formats, de navigabilité · parfois le rendu est trop compliqué en termes de sections · les
polices ne sont pas harmonieuses, d'autres trop grosses, d'autres trop petites · il faut
vraiment trouver le standard, fixer ça partout. »

Chacun de ces défauts avait déjà été « corrigé » plusieurs fois, au jugé. C'est bien le problème :
un livrable jugé à l'œil est jugé par un œil différent à chaque fois. Ce qui suit donne des
**valeurs**, vérifiables par quelqu'un d'autre que son auteur.

**Périmètre : tout ce qui se regarde.** Une page publiée, un PDF, une présentation, un visuel.
Pas un message dans un fil, pas une note interne.

## Le logo : contenu, jamais étiré, jamais agrandi

| Règle | Valeur |
|---|---|
| Ajustement | `object-fit: contain` **toujours**. Jamais `cover`, jamais une largeur ET une hauteur imposées ensemble : c'est ce qui écrase ou étire |
| Hauteur en en-tête | 32 px, 40 au maximum |
| Hauteur en couverture | 64 px, 88 au maximum |
| Agrandissement | **interdit au-delà de la taille native du fichier**. Un logo de 64 px affiché à 88 est flou, et le flou se voit plus que l'absence |
| Respiration | au moins une demi-hauteur de logo, de chaque côté. Collé à un bord, il se lit comme une erreur de gabarit |
| Logo clair sur fond clair | il ne se rattrape pas tout seul : plaque de la couleur de marque, coins 8 px, ou version sombre du logo |
| Fond du fichier | un PNG à fond blanc dans une carte grise fait un rectangle blanc. Préférer un SVG ou un PNG transparent, sinon poser une plaque blanche assumée |
| Impression | à partir de 40 mm de large, un logo tiré d'une capture d'écran se voit. Prendre le fichier source |

⛔ **Aucun logo vaut mieux qu'un logo mal posé.** Sans fichier exploitable : le nom de
l'entreprise dans la police de titre, ou un monogramme de deux lettres dans un carré de la
couleur de marque. C'est propre, c'est volontaire, personne n'y voit un défaut.

⛔ **La couleur d'une marque se relève sur son fichier**, jamais à l'œil sur une capture.

## La typographie : quatre tailles, pas davantage

Une page harmonieuse n'a pas besoin de beaucoup de tailles, elle a besoin de peu de tailles bien
écartées. **Quatre valeurs, et l'échelle ne se réinvente pas d'un livrable à l'autre.**

| Rôle | Taille | Graisse | Interlignage |
|---|---|---|---|
| Titre de page | 40 px, 32 sur téléphone | 700 | 1,1 |
| Titre de section | 24 px | 600 | 1,25 |
| Texte courant | 16 px, **jamais moins** | 400 | 1,6 |
| Annotation, légende, source | 13 px | 500 | 1,4 |

- **Deux familles au maximum.** Une de titre, une de texte. La troisième se remarque, et pas en
  bien.
- **Un seul chiffre mis en avant** peut monter à 56 px. C'est un ornement, il ne compte pas dans
  l'échelle ; deux chiffres géants sur la même page se neutralisent.
- **Mesure de 65 à 75 signes** par ligne. Un paragraphe qui traverse un écran de bureau ne se lit
  pas, quelle que soit la police.
- Sur un document imprimé, l'échelle se transpose en points : 28 / 17 / 11 / 9.

**Le chapô ne respire jamais plus large que son propre texte — 15/09/2026.** Le chapô d'une page
publiée était à 1,7 d'interligne sur une mesure de 66 signes, alors que le corps qu'il introduit
est à 1,62. Résultat : quatre lignes courtes très espacées en haut de page, et la cliente qui
écrit « beaucoup de passage à la ligne dans tes frames, c'est pas joli », capture à l'appui.
Un texte d'introduction se pose donc **à l'interligne du corps ou en dessous, jamais au-dessus**,
et sa mesure va jusqu'à 76 signes pour couper le nombre de lignes. Valeur en vigueur dans
la feuille de style du gabarit de pages publiées, quand le poste en a une (`tools/livrable/base.css`) : `line-height:1.5`, `max-width:76ch`. Un poste qui n'a pas ce gabarit applique les deux valeurs dans le style de sa page.

**Un bandeau de tête n'est pas le chapô — 15/09/2026.** Le bandeau de haut de page porte une ligne
d'identification courte, employeur, poste, date. Quand l'outil bascule faute de mieux sur le chapô,
la même phrase sort deux fois à trois lignes d'intervalle, en gras puis en clair. Signalé par la
cliente le même jour, sur la même fiche. Tout gabarit qui a un bandeau reçoit sa ligne propre.

## Les sections : cinq, une idée chacune

**Cinq sections au maximum**, titrées par ce qu'elles disent et non par leur fonction : « Ce que
coûte le retard » plutôt que « Analyse ». Une section qui a besoin d'un sous-titre pour être
comprise est deux sections, ou une de trop.

- **Trois sections ou moins : aucune navigation.** Elle prend de la place et n'aide personne.
- **Quatre ou cinq : un sommaire collant**, qui montre où l'on est et y mène en un geste. Sur
  téléphone, une barre d'une ligne, jamais un menu déroulant.
- **Le premier écran porte la réponse**, pas un titre suivi d'une introduction. Qui fait défiler
  cherche déjà autre chose.

## Le contrôle de cinq secondes, avant de remettre

1. Le logo est-il **net**, contenu, respiré, visible sur son fond ?
2. Compter les tailles de texte : **quatre au plus** ?
3. Compter les sections : **cinq au plus** ?
4. **Réduire la fenêtre à 390 px** : rien ne déborde, rien ne se chevauche, le texte reste à
   16 px ? (Sur un PDF : la même page lue sur un téléphone.)
5. Thème sombre, ou impression en noir et blanc : logos et plaques tiennent-ils encore ?

⛔ **On regarde le rendu, on ne se contente pas de l'exécuter sans erreur.** Un document qui
s'ouvre sans planter peut être laid, et c'est la laideur qu'on nous reproche, pas les erreurs.

## Cas limites

- **Le client impose sa charte et elle contredit ces valeurs** sa charte gagne, et je le dis en
  une ligne pour que personne ne croie à un oubli.
- **Le contenu ne tient pas en cinq sections** c'est presque toujours qu'il y a deux documents.
  Je le dis et je propose la coupe, plutôt que d'empiler.
- **Le logo fourni est une capture d'écran de mauvaise définition** je ne l'agrandis pas. Je
  demande le fichier source, et en attendant je pose le monogramme.
- **Un tableau large sur téléphone** il défile horizontalement dans son propre cadre, la page ne
  défile jamais latéralement.
- **Une page d'une seule section** parfaitement légitime : pas de sommaire, pas de remplissage
  pour « faire riche ».

## Ce que cette compétence ne fait pas

Elle ne dit pas quoi écrire, ni quelle direction artistique prendre. La chaîne de publication,
les polices encapsulées, les graphiques et l'atelier vivent dans `publication-frames`. Le fond,
lui, appartient au métier de chaque expert.

## Le relevé d'univers d'une institution — 10/09/2026

Retour de la direction, borne du salon, sur le site des 40 projets du ministère : « tu n'a pas
scrappé le branding du ministère et son univers graphique avant ». J'avais relevé les couleurs
de leur feuille de style et rien d'autre. **Les couleurs sont la moitié du relevé.**

Ce qui se cherche, dans cet ordre, avant de composer une page pour une institution :

1. **Le fichier du logo, sur leur serveur.** Il est dans le HTML de leur accueil :
   `curl -sL -A "Mozilla/5.0" <url> -o page.html` puis `grep -in "logo" page.html`. Chez le
   ministère de la Transition numérique il portait un nom de téléversement sans rapport
   (`uploads/contacts/176962053593.jpg`) : chercher le mot, pas un nom de fichier probable.
2. **Ce que le logo contient.** Le leur porte les armoiries de la République, le nom en
   capitales, et **deux barres — orange à gauche, verte à droite** de part et d'autre du blanc :
   le drapeau déconstruit. C'est l'artefact, et il ne s'invente pas.
3. **Les couleurs mesurées sur le fichier**, par comptage des pixels dominants, jamais au
   nuancier : écu `#14943F`, barre verte `#0AB203`, barre orange `#FE9600`.
4. **Le découpage.** Seuil de blanc pour la transparence, et un recadrage qui **ne prend que
   l'élément voulu** : ma première découpe des armoiries a emporté un bout de la barre orange
   voisine, qui est ressorti en petit rectangle flottant sur la page.

⛔ **Un logo officiel ne se recolore pas et ne se redessine pas.** Il se pose tel quel, sur le
fond que sa version admet.

## Ne pas reservir la même page — 10/09/2026

Même retour, même minute : « je trouve tes designs de site trop similaires, voir basique un
peu ». Mon moule, quatre pages d'affilée : aplat sombre en héros, surtitre coloré en capitales
espacées, grille de cartes bordées à rayon égal, rangée de compteurs.

**Avant de composer, je nomme la composition du site précédent et je change trois choses de
structure** — pas trois couleurs. Ce qui a fonctionné pour sortir du moule sur le site du
ministère :

- héros **blanc** éditorial, l'emblème posé en grand à droite, au lieu d'un aplat sombre ;
- les rubriques en **lignes** pleine largeur avec leur numéro en 44 px, au lieu de cartes ;
- une **frise** d'années au lieu d'une grille ;
- les quarante projets en **vrai tableau** — n°, intitulé, pilier, maître d'ouvrage, statut.

🚨 **Une donnée à suivre se montre dans la forme où elle sera suivie.** Quarante cases carrées
numérotées, c'est décoratif ; quarante lignes de tableau, ça se lit, ça se trie et ça se remplit.

## Le lien de rendu part avec le fichier — 10/09/2026

« et tu ne m'as mme pas mis un lien render ». Ma réserve « pas d'adresse publique pour une
maison tierce sans mandat » ne dispense pas du lien : ce qui protège, c'est le `noindex` et le
fait de dire que le mandat n'est pas posé, pas l'absence d'adresse. Donc : fichier HTML joint,
lien publié, PDF — même quand la page porte le nom d'une institution.

## Un marquage se cuit dans la photographie — 10/09/2026

Le reproche exact : « souvent, ça a l'air comme si tu as juste mis le logo sur un fond flou.
On n'a pas l'impression que tu as pensé là où le logo doit être, les artefacts, la couleur du
tote bag », et « tu as mis le monogramme, mais tu ne l'as pas vraiment mis sur le tablier ».
Un marquage posé en superposition HTML reste un autocollant : il ne prend ni le relief de la
matière, ni la lumière de la photographie. Six règles, toutes vérifiables à l'œil.

1. **Le marquage se déforme avec la surface.** Carte de déplacement tirée de la luminance de
   la zone, amplitude choisie selon la matière : la toile bouge plus que le papier, le verre
   presque pas.
2. **Le marquage prend la lumière de la photographie.** Multiplication par les ombres pour une
   encre foncée sur clair, mode inverse pour une encre claire sur sombre. Jamais une opacité
   uniforme : c'est elle qui produit l'effet autocollant.
3. **Le marquage se place là où l'objet l'attend.** Poitrine gauche sur un tablier, tiers haut
   sur un sac, plat de couverture sur un carnet, bol sur un verre, tiers haut de la feuille sur
   un porte-bloc. Le centre géométrique n'est presque jamais le bon endroit.
4. **La couleur de l'objet se choisit.** Une encre foncée sur une matière sombre ne se lit pas.
   Deux issues seulement : changer de photographie, ou poser autre chose que le logo — un motif
   de la maison, par exemple. ⛔ **Créer une version claire d'un logo est une modification du
   logo, donc un accord.** On ne la fabrique pas pour sauver une planche.
5. **Photographie nette, objet à quarante pour cent du cadre au moins**, coupé par un bord, et
   la surface marquée vue assez de face pour qu'un plan s'en déduise.
6. **Un objet par planche**, cadré serré, et le marquage reste lisible réduit au dixième.

**L'outil**, présent seulement sur un poste qui produit des visuels (vérifier `ls outils/marquer.py` ; absent, le dire et passer la main à l'expert visuel plutôt que d'improviser) : `~/.venv-office/bin/python outils/marquer.py <photo> <marquage.png> <sortie.jpg>
--zone x,y,w,h --matiere toile|tissu|cuir|papier|verre --mode multiply|screen
[--teinte R,G,B] [--opacite 0.95] [--rotation deg]`. Le marquage est redimensionné à la zone :
la zone doit donc respecter le rapport du fichier de marquage, sinon il s'écrase.

**Une surface en perspective ne se règle pas avec `--rotation`.** Le cas se voit tout de suite :
un plat de carnet photographié de trois quarts est un quadrilatère, pas un rectangle tourné. On
relève ses quatre coins sur une vignette à grille, on projette le marquage dessus par
homographie (`cv2.getPerspectiveTransform` puis `warpPerspective`, alpha nul hors du
quadrilatère), on rentre les coins de six pour cent pour garder une marge franche, et on passe
l'image obtenue à `marquer.py` avec la boîte englobante en zone et aucune rotation.

⚠ **Un motif pavé se contrôle sur ses coutures.** Un fond de motif dont les bords ne se
raccordent pas laisse une ligne droite visible en travers de l'objet. Le pavage en miroir, une
colonne sur deux retournée, fait disparaître la couture sans retoucher le fichier.

**Les deux objets se suggèrent par défaut** — « par défaut, Koffi devrait suggérer les deux
objets, ne pas nécessairement se laisser influencer » (10/09). Cela remplace la règle
antérieure « la liste des objets se propose, le client choisit » : on choisit les deux objets
qui servent le mieux la maison, on les livre, et on dit en une ligne qu'ils se changent d'un
mot. Une liste de dix objets soumise à un visiteur pressé produit un choix par défaut, pas un
choix.

## Le répertoire des natures de section — 10/09/2026

Le reproche : « certaines sections se ressemblent toutes. Tu te challenge pas. » Le défaut ne
venait pas du soin, il venait du répertoire : trois natures de section employées en boucle.
Voici celles réellement composées et mesurées. **Huit sections au minimum par site, six
natures différentes, et jamais le même enchaînement que le site précédent** — le site
précédent se nomme avant de commencer.

- **la barre d'annonce** — un aplat ou un dégradé de dix pixels de haut, une phrase, un mot en accent
- **l'en-tête translucide** — fond semi-opaque et `backdrop-filter`, filet bas
- **le héros à carte flottante** — texte à gauche, une pièce du métier à droite, légèrement tournée, avec une carte d'ombre décalée derrière
- **le bandeau défilant** — une liste qui glisse en `@keyframes`, pour montrer une étendue sans l'énumérer
- **la colonne collante** — un `position:sticky` à gauche face à une pile de documents à droite
- **l'aplat sombre à cartes de verre** — fond nuit, halos radiaux, cartes translucides
- **le mur de cartes** — trois ou quatre par ligne, dont une en grand format qui rompt la grille
- **l'accordéon numéroté** — des `<details>` pleine largeur, le numéro qui change de couleur à l'ouverture
- **la frise verticale à ligne continue** — un filet et des pastilles, les étapes d'un mécanisme
- **la frise horizontale sur une ligne** — des années sur un dégradé, des pastilles cerclées
- **les deux colonnes opposées** — ce qu'il fait, ce qu'il ne fait pas, deux fonds différents
- **le tableau comparatif** — une colonne en surbrillance, l'en-tête collant sous l'en-tête du site
- **le tableau de bord** — une case par domaine, une légende de statuts, les cases non renseignées visibles comme telles
- **l'énoncé plein cadre** — un aplat vif, une seule phrase en grand, aucune illustration
- **la fiche type bordée** — un gabarit de document montré tel qu'il sera rempli
- **le bloc en attente** — bordure pointillée, la liste de ce que la maison doit transmettre
- **la FAQ en deux colonnes** — des `<details>`, un signe qui bascule
- **la bande finale en dégradé** — le rappel d'action, deux colonnes
- **le pied en quatre colonnes** — la marque, deux colonnes de liens, un contact

⚠ **La sophistication a un coût, et il se nomme** : dégradés, halos, flous et images
augmentent le poids de la page sur un téléphone d'entrée de gamme. Sur une page destinée à un
usage grand public, on compte les images avant de compter les effets.

⛔ **Une autorité publique se traite à l'inverse.** Là, la sobriété est le signal : aucun
dégradé, aucun effet de verre, des sections calmes, et une section qui dit ce que la page
refuse d'accueillir. Un ministère ou une primature dont la page ressemble à celle d'une
startup perd ce qu'elle avait à gagner.

## La paire typographique se mesure avant de se choisir — 10/09/2026

« Tu ne travailles même pas les polices. » La règle qui en sort, et qui vaut pour tout site
composé pour une maison de Côte d'Ivoire :

- **La police à caractère porte les titres, une police à couverture porte le texte courant.**
  Les polices de caractère, celles qui donnent une voix à une page, couvrent mal les latins
  étendus : mesuré le 10/09 sur les 46 signes de la table des langues de Côte d'Ivoire —
  Bodoni Moda 17, Newsreader 19, Gloock 19, Source Serif 4 26, Nunito 25, Open Sans 18,
  Poppins 16. Noto Sans les compose tous les 46. **Libre Baskerville en compose 44** (Ɣ et ɣ
  exceptés) et **Inter 44** : ce sont les deux exceptions connues, à préférer quand un titre
  doit aussi composer une langue nationale.
- **On mesure quatre ou cinq candidates avant de choisir**, jamais de mémoire, en unissant les
  `cmap` de tous les woff2 listés dans la feuille de style de Google. ⚠ Le premier woff2 servi
  est un sous-ensemble : mesurer sur lui seul fait conclure « tout manquant ». Et la requête
  passe avec un agent de navigateur récent, sinon Google renvoie du TTF sans `unicode-range`.
- **La charte de la maison l'emporte sur le goût.** Quand un site déclare ses polices, on
  choisit dans sa liste et on mesure laquelle tient : pour le ministère de la Transition
  numérique, entre Inter, Open Sans, Poppins et Nunito, c'est Inter qui gagne la mesure.

## Retours du 21/09/2026 (Aicha Koné, par écrit) — priment sur ce qui précède

1. **Avant tout travail** : confirmer l'entreprise, montrer le logo et la palette, demander « A je pars là-dessus / B corrige », n'avancer qu'après la réponse.
2. **Relire la charte à chaque livrable** (couleurs, typographies, règles du logo) ; un support hors charte est à refaire.
3. **Trois niveaux de design à chaque proposition** : basique (texte, logo, motif), intermédiaire (avec image), sophistiqué ; chacun en carré et en story, jamais un seul A4.
4. **Un benchmark** est une analyse stratégique (positionnement, réseaux, campagnes, ton) qui sort en **Google Slides visuel** (icônes, chiffres) puis en PDF, jamais un long PDF de texte.
5. **Un écran d'application ne sort jamais en PDF** : Figma, UXPilot ou Stitch, rendu moderne, lien partagé, au niveau des applications de référence.
6. **Chaque livraison nomme l'application utilisée.**
7. **Messages courts** : une idée, deux au plus, QCM A/B/C pour tout choix, liens en avant.

Texte intégral et ce que chaque règle change contre le travail du 21/09 : `memory/regles-de-forme.md`.

## Le lecteur non technique, par défaut — 23/09/2026

Tout rendu vise la personne la moins technique qui le lira. Sur chaque page : une icône par
idée (le même sens dans tout le document), un chiffre qui se voit avant le texte, cinq lignes
au plus, un calcul écrit en une ligne avec un vrai exemple. Les règles complètes et le test des
dix secondes sont dans `restitution-des-donnees`, section 0 ; le contrôle de cinq secondes
ci-dessus s'y ajoute, il ne le remplace pas.

## Historique

- v3, 24/09/2026 : les deux outils cités (`tools/livrable/base.css`, `outils/marquer.py`) sont signalés comme propres aux postes qui les ont, avec la conduite à tenir quand ils manquent. Épreuve métier avant formation.
