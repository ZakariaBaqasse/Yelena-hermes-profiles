---
id: Y0678
name: deroule-du-recrutement
description: "Le déroulé d'un recrutement tel que l'équipe l'attend, dans l'ordre et dans la forme, avec un contrôle avant remise OBLIGATOIRE. Pré-cadrage interne AVANT la fiche de poste (date de démarrage, rémunération à valider au budget, circuit des entretiens, délai de clôture, critères principaux, questions en QCM). Fiche de poste en lien publié et en PDF, points bloquants mis en évidence, accompagnée de son formulaire de candidature. Annonce en trois options de flyer aux couleurs de l'entreprise. Sourcing en vingt profils au plus. Messages de campagne dans un GOOGLE SHEET avec les colonnes e-mail, LinkedIn et WhatsApp. Comparatif NOMINATIF dans un GOOGLE SHEET, avec le lien du CV et du profil LinkedIn de chaque candidat, fondé sur les entretiens quand ils ont eu lieu. TABLEAU DE BORD du recrutement tenu par défaut dès l'ouverture du poste. Références prises AVANT toute validation ou offre. Point d'avancement par e-mail chaque lundi. À charger dès qu'un recrutement s'ouvre, et avant de remettre un comparatif, des messages ou un point d'avancement."
bucket: A
tags: [Recrutement, Processus, Nouveau]
version: 2
maj: 2026-09-23
---

# Le déroulé d'un recrutement, du pré-cadrage au rapport du lundi

## ⛔ Contrôle avant remise, obligatoire (23/09/2026)

Ajouté parce que plusieurs consignes de la veille existaient déjà et ne s'appliquaient pas :
le comparatif et les messages sortaient encore en Google Doc, le comparatif disait « dossier 1,
dossier 2 », et aucun tableau de bord n'avait été produit. Avant d'envoyer un livrable de
recrutement, tu vérifies le point qui le concerne. Un seul point en échec : tu ne remets pas,
tu corriges d'abord.

1. **Comparatif de candidats.** Avant d'envoyer, vérifie que :
   - il est dans un **Google Sheet**, accompagné de son fichier Excel (jamais un Google Doc,
     jamais un PDF seul) ;
   - chaque colonne ou ligne porte le **nom du candidat**, le **lien de son CV** et le **lien de
     son profil LinkedIn**. Un lien introuvable s'écrit « non trouvé », jamais inventé ;
   - aucune étiquette anonyme (« dossier 1 », « candidat A ») ne remplace un nom dans la version
     de travail ;
   - si des entretiens ont eu lieu, le comparatif s'appuie sur leurs comptes rendus, pas sur les
     seuls CV (étape 7).
   Sinon, ne remets pas.
2. **Messages à envoyer à plusieurs candidats.** Avant d'envoyer, vérifie qu'ils sont dans un
   **Google Sheet** avec, pour chaque candidat, les colonnes e-mail, LinkedIn et numéro WhatsApp
   (étape 5). Sinon, ne remets pas.
3. **Tableau de bord du recrutement.** Avant de remettre un comparatif ou un point d'avancement,
   vérifie que le tableau de bord du poste existe et qu'il est à jour à la date du jour
   (étape 8). S'il n'existe pas, tu le produis d'abord.
4. **Validation d'un candidat ou offre.** Avant de proposer de valider un candidat, de préparer
   une offre ou une lettre d'engagement, vérifie que les références ont été prises (étape 9).
   Sinon, tu le dis et tu proposes de les prendre.
5. **Fiche de poste.** Avant de la remettre, vérifie qu'elle part en lien publié et en PDF,
   avec son formulaire de candidature (étapes 2 et 2 bis).

Le message de remise dit en une ligne ce qui a été contrôlé.

## Process
### Étape 1 : le pré-cadrage, avant la fiche de poste
Dès que le poste est nommé, tu proposes le cadrage interne, en cinq points, chacun avec des options lettrées quand un choix est possible :
- **Date de démarrage** souhaitée.
- **Fourchette de rémunération**, à valider au budget : tu proposes une fourchette tirée des sources de rémunération disponibles (compétences `remuneration-ci` et `remuneration-et-offre-ci`), tu ne l'inventes pas.
- **Circuit et nombre d'entretiens** : qui reçoit, dans quel ordre, avec ou sans test pratique, et à quel moment les références sont prises (avant toute offre).
- **Délai de clôture** visé.
- **Critères principaux** : les logiciels locaux à maîtriser, le niveau d'anglais, l'expérience de management, ce qui est bloquant et ce qui est souhaité.

Le tout tient en un message, questions en QCM, pour que la personne réponde par une suite de lettres. Tu ne rédiges pas la fiche avant d'avoir ces réponses, mais tu peux préparer sa trame en attendant.

### Étape 2 : la fiche de poste, en lien publié et en PDF
La fiche reprend le cadrage validé, au logo et aux couleurs de l'entreprise (compétence `charte-du-client`), sections courtes, et **les points bloquants mis en évidence** (couleur vive, gras ou surlignage) : un logiciel exigé, un niveau de langue, une contrainte de démarrage. Ce qui est bloquant se voit avant d'être lu.

Elle sort par défaut en deux formes, rendues ensemble : **le lien de la page publiée** (chaîne de publication du poste, compétence `publication-frames`) et **le PDF** tiré de la même source. Le Google Doc s'ajoute quand la personne veut annoter la fiche à plusieurs ou le demande ; il ne remplace jamais le lien et le PDF. Le lien se rend en première ligne du message.

⚠ Une page publiée est lisible par qui a le lien. N'y va que ce qui peut figurer dans une annonce : pas de fourchette de rémunération qui n'a pas été validée pour publication, pas de note interne, pas de nom de candidat.

### Étape 2 bis : le formulaire de candidature, avec la fiche
Chaque fiche part avec **son formulaire de candidature** : les champs propres au poste, les questions posées à tous, et pour chaque pièce, obligatoire ou facultative. La méthode est dans la compétence `formulaire-de-candidature`. Le formulaire propose aussi de recueillir, dès le dépôt, deux contacts de référence (étape 9), quand l'entreprise l'accepte.

### Étape 3 : l'annonce en trois options de flyer
Pour la diffusion, tu rends **trois options de flyer**, dont **une carrée** pour LinkedIn et WhatsApp : peu de texte, une image, le poste, la ville, et un bloc « Pour postuler » simple (une seule voie, celle que la personne donne). Jamais un A4 pour un réseau social. Chaque flyer part dans les formats fixés par `production-visuelle-livrable` (JPEG, PNG et PDF), avec l'application utilisée.

Avant de remettre un flyer, vérifie que :
- il reprend **l'univers graphique de l'entreprise** : ses couleurs, sa typographie, son logo, le ton de ses propres publications. Des cercles ou des formes abstraites génériques qui ne viennent pas de sa charte ne sont pas un visuel d'annonce ;
- il montre **des personnes** en situation de travail, cohérentes avec le métier et le lieu : de préférence une photo fournie par l'entreprise, sinon une photo libre de droits dont la licence est notée. Une image générée se dit générée ;
- le rendu est moderne : peu de texte, une hiérarchie nette, rien de collé en planche.

Quand le flyer doit être publié et que l'entreprise dispose aussi d'un expert en design, tu proposes de lui confier la finition ; sinon, tu appliques ces règles toi-même.

### Étape 4 : le sourcing en vingt profils au plus
Tu rends une **liste courte et classée**, vingt profils au maximum, du plus proche au moins proche du poste, dans un **Google Sheet**, avec pour chacun une ligne qui dit pourquoi il est là, le lien du profil et les coordonnées trouvées. Une liste de vingt-huit ou trente-huit noms sans raison ni ordre est un export, et un export ne se lit pas. Quand tu trouves plus de vingt profils pertinents, tu gardes les vingt premiers et tu dis combien tu en as écartés.

### Étape 5 : les messages de campagne, dans un Google Sheet
Par défaut, les messages à envoyer sortent dans un **Google Sheet**, jamais dans un Google Doc. Une ligne par candidat, avec au minimum ces colonnes :

| Colonne | Contenu |
|---|---|
| Nom | le nom du candidat |
| E-mail | l'adresse si elle est connue, sinon la case reste vide |
| LinkedIn | le lien du profil s'il est connu, sinon vide |
| WhatsApp | le numéro s'il est connu, sinon vide |
| Message e-mail | objet et corps |
| Message LinkedIn | deux lignes |
| Message WhatsApp | quatre lignes au plus |
| Statut d'envoi | à envoyer, envoyé, réponse reçue (menu déroulant) |

Une coordonnée inconnue laisse **la case vide** : c'est le recruteur qui la complète. Jamais une adresse ou un numéro deviné. Le Sheet part avec son fichier Excel.

Tu rédiges **trois versions** par candidat, chacune à la longueur de son canal (l'e-mail se lit, le message WhatsApp tient en quatre lignes, la note LinkedIn en deux). Pour les cinq premiers profils, sauf demande contraire, tu les **affiches aussi dans la conversation**, séparés par des lignes vides, sous le lien du Sheet. Aucun message ne part sans validation.

### Étape 6 : le comparatif sur CV, nominatif, dans un Google Sheet
Quand des candidatures arrivent, tu rends un **Google Sheet** (et son fichier Excel) : une colonne par candidat, une ligne par critère du cadrage.

- **En tête de chaque colonne** : le nom du candidat, le lien de son CV, le lien de son profil LinkedIn. Sans ces trois éléments, on ne sait pas de qui on parle.
- **Dans chaque case** : ce que le dossier prouve, ce qu'il ne dit pas (« non mentionné, à vérifier », jamais « absent »), avec un code couleur déclaré dans un onglet de lecture.
- **En bas** : les questions ouvertes, ce qui manque pour trancher, et ta lecture.

La version de travail est nominative. Elle se partage aux seules personnes qui décident, jamais par un lien ouvert à tous ni sur une page publiée. Une version anonymisée ne se fait qu'en plus, quand elle doit circuler, et le dit dans son titre.

### Étape 7 : le comparatif après entretiens
Dès qu'un entretien a eu lieu et qu'il a un compte rendu (compétence `synthese-recruitment-interview`, qui sait retrouver un enregistrement), le comparatif se refait **sur les réponses données en entretien**, critère par critère, avec pour chaque candidat la réponse qui fonde l'appréciation. Le CV ne sert plus qu'à ce que l'entretien n'a pas couvert, et tu le dis.

Tu termines par **le candidat qui te paraît le plus proche du poste, et pourquoi**, en deux ou trois raisons tirées des entretiens, formulé comme une proposition : « je te propose de retenir X, parce que… ; le point à vérifier avant de décider est… ». Tu éclaires la décision, le manager la prend.

### Étape 8 : le tableau de bord du recrutement, par défaut
Chaque recrutement suivi a **son tableau de bord**, sans qu'on le demande, ouvert dès la publication de l'annonce et mis à jour à chaque événement (candidature reçue, étape franchie, entretien tenu, refus, offre). C'est un **Google Sheet** avec son fichier Excel, aux couleurs de l'entreprise, avec des graphiques natifs :

| Onglet | Ce qu'il montre |
|---|---|
| Lisez-moi | le poste, la date de mise à jour, la source des chiffres, la légende des couleurs |
| Synthèse | candidatures reçues, en cours par étape, entretiens tenus, refus, offres, jours depuis l'ouverture, date de clôture visée |
| Entonnoir | l'effectif et le taux de passage de chaque étape |
| Délais | les jours passés dans chaque étape, comparés au délai du cadrage |
| Candidats | une ligne par candidat : nom, source, étape, date d'entrée dans l'étape, prochaine action et échéance, lien du CV |

Les chiffres viennent de l'outil de suivi des candidatures quand il est branché (compétences `lecture-recruitee` et `ats-au-quotidien`), sinon des candidatures reçues. Ce qui n'est pas mesuré s'écrit « non disponible », jamais zéro. Le lien du tableau de bord figure dans chaque point d'avancement.

Pour un exercice sans recrutement réel (entraînement, démonstration), le tableau se fait sur des données simulées, marquées « DONNÉES FICTIVES » dans le nom du fichier, dans le titre et sur chaque onglet. Des données simulées ne se mélangent jamais avec des données réelles.

### Étape 9 : les références, avant toute validation et toute offre
Les références sont **l'avant-dernière étape**, jamais la dernière : elles se prennent avant de valider un candidat et avant toute offre. Une offre partie ne se retire plus, et un signal grave découvert après coup oblige à recruter quelqu'un dont on ne veut pas, ou à rompre pendant l'essai. Le kit est dans `prise-references`.

Tu proposes à l'entreprise de demander les contacts de référence **dès le dépôt de la candidature**, dans le formulaire (étape 2 bis), pour ne pas perdre de temps au moment de décider. Contacter une référence reste une action validée par un humain, et le candidat sait que ses références seront appelées.

### Étape 10 : le point d'avancement par e-mail
Chaque lundi matin (ou à la cadence demandée), tu envoies **toi-même** l'e-mail de point d'avancement à l'adresse de la personne : aux couleurs de l'entreprise, une ligne par étape, le lien du tableau de bord, les liens cliquables sur leur libellé, ce qui attend sa décision en QCM. Tu proposes ce modèle dès la première semaine, et tu le tiens sans qu'on te le redemande.

### Étape 11 : le point d'étape à la demande
« Où on en est ? » se répond en trois lignes, avec les liens, jamais par un récit de la semaine (compétence `messages-courts-qcm-et-liens`).

## Format de sortie
- **Pré-cadrage** : un message, cinq points, QCM lettrés.
- **Fiche de poste** : lien de la page publiée et PDF, brandés, points bloquants visibles ; Google Doc en plus sur demande.
- **Formulaire de candidature** : avec chaque fiche.
- **Annonce** : trois flyers dont un carré, aux couleurs de l'entreprise, avec des personnes, dans les formats de `production-visuelle-livrable`.
- **Sourcing** : Google Sheet, vingt lignes au plus, classées, avec la raison de chaque présence.
- **Messages de campagne** : Google Sheet et Excel, colonnes e-mail, LinkedIn, WhatsApp remplies ou laissées vides ; les cinq premiers aussi dans la conversation.
- **Comparatif** : Google Sheet et Excel, nominatif, liens du CV et du profil LinkedIn, fondé sur les entretiens quand ils existent, avec le candidat le plus proche proposé et ses raisons.
- **Tableau de bord** : Google Sheet et Excel, par défaut pour chaque recrutement suivi, à jour.
- **Point d'avancement** : e-mail envoyé par l'Experte, brandé, lien du tableau de bord, modèle récurrent.
- **Règle 0 invention** : aucune fourchette de salaire, aucun profil, aucune coordonnée fabriqués.

## Règles
1. **Le cadrage précède la fiche.** Aucune fiche de poste n'est rédigée sans les cinq points validés.
2. **Les questions se posent en QCM.** La personne répond par des lettres.
3. **Ce qui est bloquant se voit** dans la fiche, en couleur, avant d'être lu.
4. **La fiche part en lien publié et en PDF**, avec son formulaire de candidature.
5. **Une annonce se poste**, donc elle sort en carré ou en story, aux couleurs de l'entreprise, jamais en A4.
6. **Vingt profils au plus**, classés, chacun avec sa raison.
7. **Les messages de campagne sortent dans un Google Sheet**, avec e-mail, LinkedIn et WhatsApp.
8. **Le comparatif sort dans un Google Sheet, nominatif**, avec les liens du CV et du profil LinkedIn.
9. **Le comparatif prépare la décision, il ne la prend pas** : il propose le candidat le plus proche et dit pourquoi.
10. **Le tableau de bord existe dès l'ouverture du poste**, sans qu'on le demande.
11. **Pas de validation ni d'offre avant les références.**
12. **Le point du lundi part par e-mail**, envoyé par l'Experte, brandé, avec les liens.

**Garde-fous durs**

- **0 invention.** Aucun profil, aucune entreprise d'origine, aucun numéro, aucune fourchette de rémunération fabriqués. Ce qui n'est pas lu dans une source réelle est marqué `[à confirmer]`. Une coordonnée inconnue laisse la case vide.
- **0 fausse source.** Un profil listé a été vu sur une page réelle ; une fourchette cite sa source.
- **Produis, ne bloque pas.** Le pré-cadrage tient en un message ; tu prépares la trame de la fiche pendant que la personne répond.
- 🔒 **Aucune action sortante en autonomie.** Aucun message à un candidat, aucune publication d'annonce, aucune référence contactée, aucune offre transmise sans validation. L'e-mail d'avancement part à la personne servie, jamais à un tiers.
- **Cloisonnement.** Les profils sourcés pour une entreprise ne sont jamais proposés à une autre.

## Cas limites
- **La personne veut la fiche « tout de suite », sans cadrage** : tu rends la fiche avec les points du cadrage marqués `[à confirmer]` en couleur, et le QCM de cadrage dans le même message. Elle a sa fiche, et elle voit ce qui manque.
- **La rémunération n'est pas connue** : tu proposes une fourchette sourcée et tu la marques « à valider au budget » ; tu ne laisses pas la case vide, tu ne l'inventes pas non plus. Elle ne va pas sur la page publiée tant qu'elle n'est pas validée.
- **Le sourcing rend moins de vingt profils** : tu rends ce que tu as, tu dis combien, et où tu as cherché.
- **La personne demande « le meilleur candidat »** : tu rends le comparatif, tu proposes celui qui te paraît le plus proche des critères et pourquoi, et tu laisses la décision.
- **La personne demande un comparatif « anonyme »** : tu fais la version anonymisée en plus de la version nominative, jamais à sa place.
- **L'adresse de candidature n'est pas donnée** : le bloc « Pour postuler » porte `[adresse à confirmer]` ; tu n'en inventes pas une plausible.
- **Un canal ne convient pas au profil** (pas de LinkedIn) : la case du canal reste vide et tu rends les deux autres versions.
- **La personne veut valider un candidat sans références** : tu rappelles en une phrase ce que coûte une offre qui ne se retire plus, tu proposes la prise de références en QCM, et c'est elle qui tranche.
- **Le recrutement concerne plusieurs postes** : un déroulé par poste, et un tableau de bord par poste avec un onglet qui les réunit.

## Historique

- v1, 21/09/2026 : règles posées à la réunion d'entraînement du 21 septembre 2026.
- v2, 23/09/2026 : contrôle avant remise obligatoire en tête ; comparatif nominatif en Google Sheet avec liens du CV et du profil LinkedIn, refait sur les entretiens ; messages de campagne en Google Sheet avec colonnes e-mail, LinkedIn et WhatsApp ; tableau de bord du recrutement par défaut ; références avant toute validation ou offre ; fiche de poste en lien publié et en PDF, avec son formulaire de candidature ; flyers aux couleurs de l'entreprise, avec des personnes, séance Sync agents training.
