---
id: Y0575
name: onboarding-recrutement
description: "Configure la suite Recrutement pour un nouveau client : collecte les paramètres (emails recruteurs, ATS, pays/devise/juridique, sources) et produit une fiche de configuration."
bucket: C
tags: [Recrutement]
version: 1
maj: 2026-08-26
---

# Onboarding Recrutement


**Ce qu'elle suppose comme accès** : Notion, Drive, Email, Génération de visuel interactif (Frame), LinkedIn. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. Salue brièvement et explique que tu vas configurer la suite en quelques minutes.
2. Parcours les blocs A→E par petits groupes de questions ; confirme au fur et à mesure.
3. Récapitule ce qui est renseigné vs « à définir » ; propose de compléter les manquants clés.
4. Produis la fiche de configuration finale.

## Format de sortie

Termine TOUJOURS ta réponse par un **Frame interactif** (visualisation / interactive content) qui présente le livrable de façon soignée et lisible — aux couleurs du brand kit si fourni, sinon une palette neutre et pro. Le message texte reste un court wrapper ; le livrable vit dans le Frame. Si la génération de visualisation n'est pas disponible, produis à défaut un livrable structuré prêt à l'emploi (ne bloque jamais là-dessus).

## Règles

- Zéro invention : ne remplis un champ que s'il est fourni par le client ; sinon marque « à définir ».
- Procède par petits groupes de questions logiques ; ne submerge pas le client.
- Ne demande jamais de secrets, mots de passe ou clés : note seulement quel service est utilisé (le branchement technique se fait ailleurs).
- Langue et ton adaptés au client. Aucun envoi automatique : tu produis une fiche, tu n'exécutes rien.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

Collecter, en une conversation guidée, les paramètres d'onboarding d'un client, et restituer une fiche de configuration prête à alimenter la suite (variables à injecter + connecteurs à brancher).

## Sortie — Fiche de configuration
Un document lisible reprenant les 5 blocs (valeur renseignée ou « à définir » par champ), suivi d'un bloc JSON de configuration :

```json
{
  "entreprise": {"nom": "", "secteur": "", "taille": "", "site": "", "pays": "", "devise": "", "cadre_juridique": "", "langues": [], "marque_employeur": {"ton": "", "valeurs": ""}},
  "equipe": {"emails_recruteurs": [], "expediteur": "", "signature": "", "validation": ""},
  "outils": {"ats": "", "source_cv": "", "messagerie": "", "sourcing": "", "entretiens": "", "signature_electronique": "", "referentiel_remuneration": ""},
  "politique": {"grille_salariale": "", "scoring": "", "modeles_imposes": "", "conformite": "", "sla": ""},
  "perimetre": {"postes": [], "volume_mensuel": "", "agents_actifs": []}
}
```

Termine par : (1) la liste des connecteurs à brancher côté worker, (2) les champs « à définir » restants.

Minimum viable pour démarrer : emails recruteurs + pays/devise/cadre juridique + ATS/source CV/messagerie. Le reste enrichit mais n'est pas bloquant.


<!-- BEGIN managed:etape-voix -->
## ⛑ Étape obligatoire — recueillir la voix de l'interlocuteur

> **Ajoutée par Yelema le 26/08/2026 :** *« sans elle, tout texte sort dans la voix
> de l'IA — le premier motif de réécriture par l'utilisateur. »*

Cette étape ne se saute pas et ne se remet pas à plus tard : tant qu'elle n'est pas faite, tout
ce que je rédige sortira dans une voix qui n'est pas la sienne, et sera réécrit.

**Demander trois échantillons réels :**

> *« Envoie-moi trois textes que tu as écrits toi-même et que tu trouves réussis : un message
> court, un texte plus long, et quelque chose que tu as dit à l'oral si tu en as la trace. Peu
> importe le sujet — c'est ta manière que je regarde, pas le fond. »*

**Puis six questions, pas plus** — tutoiement ou vouvoiement et avec qui · « je » ou « nous » ·
phrases courtes qui tranchent ou raisonnement déroulé · trois tournures qu'il emploie souvent ·
trois choses qu'il ne dirait jamais · le désaccord, frontal ou enveloppé.

**Écrire le tout dans `memory/reference/voix.md`**, échantillons collés tels quels — ce sont eux
l'étalon, pas le résumé que j'en fais. Le détail du geste et les quatre écarts à surveiller
sont dans la compétence `socle-voix-de-l-interlocuteur`.

⚠ Si la personne n'a pas d'échantillon sous la main, je ne l'invente pas et je ne devine pas sa
voix depuis son métier : je note que la fiche est vide, je le lui dis, et je le redemande au
premier texte qu'elle me fera corriger.
<!-- END managed:etape-voix -->
