---
id: Y0611
name: socle-livrables-tous-formats
description: >
  Produire un livrable dans le format qui convient au contenu : Google Doc, Google Sheet,
  Google Slides, PDF, Word, Excel, présentation, image, page web, note vocale, et savoir
  lequel choisir. Impose la règle de maison : un livrable sort TOUJOURS par paire, la version
  vivante et sa version figée. Donne la commande exacte pour chaque format sur cette machine.
  À charger dès qu'un document doit être fabriqué, avant de choisir son format.
version: 3
maj: 2026-09-22
---

# Tous les formats, et lequel choisir

> **Demandé par Yelema, 26/08/2026 :** *« permettre à tous les experts de créer tout
> type de doc (word, pdf, excel, gdoc, gsheet, tableur, image, et autre) ».*

Le format n'est pas un détail de présentation : il décide de ce que le lecteur pourra faire
du livrable. Un tableau de chiffres livré en PDF ne se trie pas. Un contrat livré en image ne
se modifie pas. Une note de trois pages livrée en tableur ne se lit pas.

---

## 0 · La règle de maison — un livrable sort par PAIRE

> **Demandé par Yelema, 06/09/2026 :** *« selon les livrables, ça doit être livré
> toujours en gslide suivi du pdf, en gdoc suivi du pdf, en gsheet suivi de l'excel, en lien
> figma, en lien render. Il faut vraiment qu'on ait des livrables présentables. »*

Un livrable ne se remet jamais en un seul morceau. Il sort en deux : la version que le
client peut ouvrir, commenter et modifier, et la version figée qu'il peut transmettre sans
qu'elle bouge. C'est la règle, pas une préférence.

| Nature du livrable | Ce qui part | Et avec lui |
|---|---|---|
| Présentation, deck | Google Slides (lien) | le PDF |
| Document rédigé, rapport, note, contrat | Google Doc (lien) | le PDF |
| Tableau, budget, grille, suivi | Google Sheet (lien) | le .xlsx |
| Maquette, écran, charte, visuel | lien Figma | l'export image ou PDF |
| Page interactive, comparateur, restitution en ligne | lien Render (page publiée) | — |

⛔ **Ce qui ne part plus jamais dans un fil de discussion : un fichier `.md`.** Telegram ne
l'ouvre pas sur mobile, et le destinataire n'a rien à en faire. Le Markdown est une source de
travail, il reste dans `deliverables/`.

⛔ Un lien seul ne suffit pas : il peut être coupé, expiré, ou inaccessible à
quelqu'un qui n'a pas le compte. Le PDF est la copie que le client garde.

⛔ Un fichier seul ne suffit pas non plus : un PDF ne se commente pas et ne se corrige pas,
c'est le lien vivant qui permet à l'équipe de travailler dessus.

### Les commandes de la paire

Le chemin du binaire `gog` et le compte Google à passer en `--account` sont propres à
chaque installation : ils sont écrits dans le `TOOLS.md` du poste. Je les y lis, je ne les
devine pas et je ne les grave pas ici.

```bash
export PATH="$PATH:<chemin du binaire gog, voir TOOLS.md>"
# toutes les commandes ci-dessous se préfixent de GOG_KEYRING_PASSWORD=""
# et se terminent par --account <compte, voir TOOLS.md>
```

#### Doc + PDF, depuis un Markdown déjà rédigé et relu
```bash
gog drive upload <doc.md> --parent <dossier> --name "AAMMJJ_Titre" --convert-to doc
gog docs export <idDuDoc> --format pdf --out deliverables/<projet>/<slug>_v<N>.pdf
```

#### Slides + PDF
```bash
gog slides create-from-markdown "AAMMJJ_Titre" --content-file <deck.md> --parent <dossier>
gog slides export <idDuDeck> --format pdf  --out deliverables/<projet>/<slug>_v<N>.pdf
```

#### Sheet + Excel
```bash
gog sheets create "AAMMJJ_Titre"                     # ou upload d'un .xlsx avec --convert-to sheet
gog sheets export <idDuSheet> --format xlsx --out deliverables/<projet>/<slug>_v<N>.xlsx
```

Les trois chaînes ci-dessus ont été exécutées de bout en bout et vérifiées le 06/09/2026 :
le deck de test a bien été créé, exporté en PDF de 33 Ko, puis supprimé.

#### Lien Render

La page publiée, pour tout ce qui se consulte plutôt que se lit : voir la compétence de
publication de pages du poste. Le lien se donne toujours avec ce qu'il montre,
jamais seul.

#### Lien Figma

Pour un livrable de design, le lien du fichier fait partie de la remise, au même titre que
l'export. Un export sans lien empêche toute reprise.

### Ce que « présentable » veut dire, concrètement

Un livrable présentable porte un titre, une date, le nom de qui l'a demandé, et une première
page qui dit ce qu'on va lire. Le document sans en-tête, la feuille de calcul
sans nom de colonne et le deck sans page de garde ne sont pas des livrables : ce sont des
brouillons partagés par erreur.

### Quand la paire ne s'applique pas

- Une réponse courte dans le fil reste une réponse dans le fil. La règle vise les livrables,
  pas chaque message.
- Un format demandé explicitement par le destinataire l'emporte, et je le note.
- Un format que je ne sais pas produire se dit, — voir la règle 5 de la section 3. Il ne se
  remplace pas en silence par un autre.

---

## 1 · Choisir — la question est « qu'est-ce que le lecteur va en faire ? »

| Il va… | Format | Pourquoi |
|---|---|---|
| **le lire, puis l'archiver ou le transmettre** | **PDF** | figé, se transmet sans se déformer |
| **le modifier, le compléter, le signer** | **Word (.docx)** ou **Google Doc** | éditable ; le Doc si on travaille à plusieurs |
| **trier, filtrer, recalculer** | **Excel (.xlsx)** ou **Google Sheet** | les chiffres restent des chiffres |
| **le commenter à plusieurs, en continu** | **Google Doc / Sheet** | commentaires et historique |
| **le projeter** | **présentation (.pptx)** ou page web | une idée par écran |
| **le regarder** — schéma, visuel, capture | **image (.png / .jpg)** | se colle partout |
| **le consulter depuis un lien, sur téléphone** | **page web** | rien à télécharger |
| **l'écouter** — en voiture, en marchant | **note vocale (.ogg)** | s'ajoute au texte, ne le remplace jamais |

**En cas d'hésitation, demander.** « Tu le veux en tableur ou en PDF ? » coûte une ligne et
évite de refaire le document.

⛔ **Un tableau de chiffres se livre toujours dans un format calculable** (tableur ou Sheet),
même quand on fournit aussi le PDF. Le lecteur veut trier.

---

## 2 · Produire — les commandes sur cette machine

### PDF et page web
```bash
python3 .claude/skills/livrable-html-pdf/build.py --body corps.html \
  --out deliverables/<projet>/<AAMMJJ_Nom> --title "…" --chapo "…"
```
Sort le `.html` et le `.pdf` d'un coup. C'est le chemin par défaut d'un livrable rédigé.

### ⚠ L'interpréteur Python à utiliser pour un document

Le Python du système **ne porte aucune bibliothèque bureautique**. Les appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est un mauvais
interpréteur. Toutes les bibliothèques de document vivent dans un environnement dédié :

```bash
~/.venv-office/bin/python        # docx · pptx · openpyxl · pandas · pypdf · weasyprint · markitdown
```

C'est cet interpréteur, et lui seul, qui fabrique un Word, une présentation ou un tableur.
Le chemin exact est propre à chaque installation : il est écrit dans le `TOOLS.md` du poste,
je l'y lis plutôt que de le deviner.

⛔ **`pandoc` n'est pas installé.** Toute recette qui en dépend est à écarter : la conversion
d'un Markdown en Word passe par `python-docx`, et la conversion d'un document bureautique en
PDF par LibreOffice (`soffice --headless --convert-to pdf`), qui, lui, est présent.

### Word (.docx) et présentation (.pptx)

```bash
~/.venv-office/bin/python -c "import docx, pptx"      # contrôle avant de commencer
```

`python-docx` et `python-pptx` produisent des fichiers natifs éditables. Côté Node, les
bibliothèques `docx` (docx-js) et `pptxgenjs` sont installées dans un dossier partagé ; elles
se chargent en passant `NODE_PATH` sur ce dossier, indiqué dans le `TOOLS.md` du poste.

Pour figer un `.docx` ou un `.pptx` en PDF :
```bash
soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>
```

### Excel (.xlsx) et tableur

Voir `tableur-livrable` pour les règles de présentation : en-tête figée, colonnes typées,
distinction saisi / calculé / importé, source datée, jamais de zéro à la place d'une donnée
manquante.

Et voir `xlsx` pour les règles de **calcul**, qui sont d'un autre ordre et qui priment quand
le tableur contient des formules : une formule et jamais un résultat calculé en dur, chaque
hypothèse documentée à côté de la case avec sa provenance, et le contrôle de recalcul
obligatoire avant la remise.

⛔ **Un tableur qui contient des formules ne se livre pas sans avoir été recalculé.**
`openpyxl` écrit les formules sans leur résultat : tant qu'on n'a pas recalculé, chaque case
de formule est vide pour qui lit le fichier, et une erreur de formule reste invisible.

### Google Doc et Google Sheet natifs
Voir `create-doc` pour la chaîne markdown → Doc natif. Le dépôt et la conversion passent par
l'intégration Google :
```bash
python3 outils/deposer-livrable.py --fichier <chemin> --convertir
```
`--convertir` transforme un `.docx` en Doc natif et un `.xlsx` en Sheet natif à l'arrivée.

### Image
Un schéma se produit en HTML puis se rend en image :
```bash
python3 outils/formats-sortie.py apercu <fichier.pdf>     # vignette de première page
```
Pour une image générée, passer par l'intégration image de l'expert quand il en a une.

### Note vocale
```bash
python3 outils/formats-sortie.py vocal version-dite.txt --out <sortie>.ogg
```
⛔ **Le vocal s'ajoute au texte, il ne le remplace jamais.** Un message uniquement vocal n'est
ni citable ni vérifiable en réunion. Pas de vocal pour un tableau, des chiffres ou un arbitrage.

---

## 3 · Ce qui vaut pour tous les formats

1. **Le nom du fichier suit la convention** `AAMMJJ_Nom-du-document` — voir `socle-drive-livrables`.
2. **Le livrable est déposé au Drive et inscrit à l'index**, quel que soit son format.
3. **La relecture anti-tics passe avant la remise**, y compris sur les titres de colonnes et
   les légendes.
4. **Aucune donnée inventée** pour remplir une case — voir `socle-anti-hallucination`.
5. **Un format qu'on ne sait pas produire se dit**, il ne se remplace pas en silence par un
   autre. « Je n'ai pas de quoi faire du .pptx ici, je te le fais en PDF ou en page web » est
   une réponse acceptable ; livrer un PDF quand on a demandé un tableur ne l'est pas.

---

## 4 · Le document du client ne porte pas ton travail de fabrication

> **Règle de NADIA, 22/09/2026, étendue aux quinze.**

Un livrable porte **sa ligne de source** et rien d'autre en notes : les fichiers reçus, la
date de réception, la période couverte, le statut des chiffres. C'est ce dont le lecteur a
besoin pour savoir si le document l'engage.

Tout le reste est de la fabrication et vit ailleurs, dans un classeur ou un document
« Notes de travail » séparé, rangé à côté du livrable mais jamais dedans :

- les notes de méthode et les hypothèses de calcul,
- le contrôle qualité et son tableau d'anomalies,
- le journal des corrections et des choix,
- le glossaire des termes que tu as dû trancher.

**Pourquoi.** Ce matériel est utile, souvent le plus intéressant de ton travail, et c'est
précisément pour ça qu'il déborde. Mais dans le document remis, il déplace l'attention du
résultat vers la manière, et il expose des tâtonnements qu'un lecteur pressé lit comme des
réserves sur le résultat lui-même. Un client qui lit ton contrôle qualité avant ta
conclusion doute de la conclusion.

Si une hypothèse change la lecture du chiffre, elle ne va pas en note : elle va dans le
corps, en une phrase, à l'endroit où le chiffre est affiché.

---

## 5 · La forme du document remis, trois règles sans exception

> **Point de formation du 22/09/2026.** Trois défauts de forme revenaient chez tous les
> experts, et aucun n'est une question de goût : chacun a coûté un aller-retour réel.

**1. Tout document porte sa pagination.** Document, présentation ou PDF, chaque page est
numérotée au format `1 sur X`. Un lecteur qui reçoit une page isolée doit savoir combien il
en manque, et un document sans pagination ne se discute pas en réunion.

**2. Tout lien remis s'ouvre sans demander d'accès.** Avant d'envoyer un lien, tu le partages
en lecture pour toute personne qui en dispose, et tu vérifies. Le 22/09, un testeur a demandé
l'accès par courriel plusieurs fois sans jamais rien recevoir : de son côté, le travail
n'existait pas. ⛔ Un lien fermé n'est pas un livrable, c'est une promesse.

**3. En-tête et pied de page sont ceux du client.** Nom, logo, date, numéro de page. Un
document neutre dit au lecteur qu'il vient d'ailleurs, avant même qu'il le lise.
