# Lexique nouchi, premier relevé

**Source unique :** Wiktionnaire, *Annexe : Liste de mots nouchis*,
https://fr.wiktionary.org/wiki/Annexe:Liste_de_mots_nouchis , relevé le 14/09/2026.
La page annonce elle-même « plus de 500 mots » et n'en publie qu'une partie : ce lexique
est un point de départ, pas un dictionnaire.

⛔ **Aucun de ces mots ne part dans la bouche d'une marque sans validation humaine.**
Le relevé donne le sens, il ne dit ni le registre, ni la charge, ni qui se sent visé.
Plusieurs entrées ci-dessous sont violentes ou sexuelles : elles sont conservées parce
qu'un expert doit les RECONNAÎTRE dans un commentaire reçu, pas parce qu'il doit les écrire.

| Mot | Sens relevé |
|---|---|
| (se) Fongnon | Se positionner pour se battre, frimer |
| Agboloh | Muscles, musclé, musculature |
| Agnon | Habits |
| Apoutchou | Belle jeune femme pulpeuse et callipyge, « grosses fesses ; ronde » |
| Badrô | Boire |
| Banger | Feu d’artifice (éclater les bangers = tirer les feux d’artifice) |
| Barre | Milles (1000) FRANCS CFA |
| Beko | Un baiser |
| Bengué | Europe |
| Bédou | Porte-feuille, porte-monnaie |
| Béou | Fuir, aller |
| Bigo | Œuf,téléphone |
| Binguiste | Quelqu'un qui vient d'Europe, de la France |
| BobaraBa | Posterieur genereux |
| Bobarafitini | Posterieur fin |
| Borlaï | Ignorant |
| Bourou | Pain |
| Bôrô | Beaucoup, Fan, sac |
| Bôtchô | Fesses |
| Brobro | Chercher, Travailler dur |
| Brobroli | Job |
| Broutage | Arnaque |
| Brouteur | Arnaqueur |
| Cargo | Panier à salade (fourgon de police) |
| Chier | Crier , réprimander |
| Cohan | Comme ça |
| Côcô | Quémander |
| Côcôta | Coup sur la tête |
| Daba | Manger, ou frapper |
| Dabali | Nourriture ou frapper |
| Dendjô | Comprendre, piger/déshabiller |
| Dédja | Ouvrir, Ouvert, blessé |
| Dindin | Regarder, lorgner, surveiller, hésiter |
| Dja | Tuer |
| Djafoule | Tout donner, impressionner |
| Djandjou | Personne aux mœurs légères |
| Djanterman | Homme stylé |
| Djantra | Prostituée |
| Djê | L'argent |
| Djossi | Travail, taf |
| Dôhi | Mensonge |
| Enjaillement | Amusement, fête |
| Enjailler | S'amuser, plaire |
| Fal | Cigarette |
| Faler | Fumer |
| Fangan | Force |
| Fata | Tomber, vendre |
| Fatali | Chute |
| Faux-type | Hypocrite, malhonnête |
| Fiengal | Maigrichon |
| Flôcô | Mentir, mensonge |
| Foul | Plein, beaucoup |
| Fraichnie | Petite-amie, demoiselle |
| Frapper Ahoco | Se masturber |
| Fraya | Fuir, s'échapper |
| Gaou | Ignorant, une personne pas branché |
| Gawa | Ringard |
| Gbagboter | Marcher (beaucoup et sur une longue distance) |
| Gbahé | Gronder ; conseiller ; sermonner, s’absenter |
| Gbai | Vérité ; conseil ; sermon |
| Gbairè | Commérage ; ragot ; médisance, dénigrement |
| Gbêdê | Baiser |
| Gbêss | 500 |
| Gbonhi | Groupe / Bande |
| Gbonhon | Cinq milles francs (5 000 F) |
| Gbô | Manger, point de la main |
| Gbôlôzailli | Gros, massif, musclé |
| Glôglô | Couloirs, raccourci, bas quartier |
| Gnaga | Bagarre |
| Gnakoué | Ignorant, couillon |
| Gnanhi | Femme cougar |
| Gnata | Très ignorant |
| Go | Femme, fille, petite amie |
| Goumin | Chagrin d’amour |
| Groto | Homme riche |
| Grouilleur | Débrouillard |
| Jahin | Jamais |
| Ken | Chose / plan / deal / affaire |
| Kener | Planifier / dealer / vendre |
| Keneur | Dealeur / vendeur |
| Kourou bâtard | Coup de poing violent |
| Kpakpato | Rapporteur, colporteur |
| Kpakpatoya | Commérage, colportage |
| Kpetou | Vulve, vagin |
| Kpôclé | Fille de mauvaises mœurs / prostituée |
| Laler | Gifler, frapper, téléphone, endroit |
| Lā | Donner |
| Maga (''Magatapé'') | Se battre, battre, dérober, surprise |
| Maudia maudit | Malhonnête |
| Mono | Policier / Gendarme |
| Moro | Une pièce de 5 Francs |
| Mougou | Faire l’amour |
| Mougouli | Rapport sexuel |
| Mousso | Femme |
| Môgô | Personne, gens, homme, pote |
| Pahé | Parceque / car |
| Painhou | Prostituée |
| Pantougouler | Fuir / s'échapper |
| Petit pompier | Gigolo |
| Pinkou | Faire l'amour |
| Plomb | 100 Francs CFA |
| Propro | Produit éclaircissant, poursuivre |
| Sêkpêl | Poids plume, maigrichon |
| Skinny | Belle jeune femme mince |
| Soayé | Méchant / Mauvais |
| Soutra | Aider, sauver, sortir d'une passe |
| Sri | Attraper |
| Tassaba | Grosses Fesses |
| Tchiza (Tchizambengué) | Amante d’un homme marié |
| Tchizo | Homme marié qui a une amante |
| Togo | 100 FCFA, 100 mille FCFA |
| Tolo | Giffler |
| Wéh | Chose / truc / plan / deal |
| Wéman | Dealeur |
| Woro-woro | Taxi collectif, taxi communal |
| Yafor | D’accord |
| Yé | Je |
| Zébri manyé | Viol |
| Zo | Beau (neutre) |
| Zogor | Une chose/personne/idée ennuyeuse |
| Zogotape | Assommer |
| Zota | Belle |

_122 entrées._
