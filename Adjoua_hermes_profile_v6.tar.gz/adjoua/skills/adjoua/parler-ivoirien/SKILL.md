---
id: Y0487
name: parler-ivoirien
description: "Les trois registres du français parlé en Côte d'Ivoire, et lequel une marque peut employer sans se ridiculiser : français standard, français populaire ivoirien, nouchi. Donne le lexique relevé, les sources où le vérifier, la règle qui interdit d'inventer un mot, et le test qui dit si une marque a le droit de descendre d'un registre. Existe parce qu'un texte écrit en français de France se voit à Abidjan, et qu'un texte qui singe le nouchi se voit encore plus."
bucket: A
tags: [Couche locale, Côte d'Ivoire, Langue, Marketing]
version: 1
maj: 2026-09-14
---

# Parler ivoirien : trois registres, et lequel est le vôtre

## Pourquoi cette compétence existe

Le français est la langue officielle de la Côte d'Ivoire, et son usage y diffère de celui
de la France. Un texte de marque écrit en français de Paris s'entend immédiatement à
Abidjan : ce n'est pas faux, c'est étranger. L'inverse est pire. Une marque qui plaque du
nouchi sur une publication pour « faire local » se fait corriger en commentaire, et le
commentaire circule plus loin que la publication.

Cette compétence ne donne pas un accent. Elle donne les trois registres, la manière de
choisir, et l'interdiction de bricoler.

## Les trois registres

Source : Wikipédia, *Français de Côte d'Ivoire*,
https://fr.wikipedia.org/wiki/Français_de_Côte_d%27Ivoire (lu le 14/09/2026).

**1. Le français standard.** Parlé par la population scolarisée. C'est le registre de
l'institutionnel, du juridique, du bancaire, du contrat, de l'annonce de recrutement,
de tout document qui engage. C'est aussi le registre par défaut : on n'en descend que
pour une raison nommée.

**2. Le français populaire ivoirien.** Variété parlée surtout à Abidjan, qui tend à
devenir le français véhiculaire du pays. Elle a ses expressions propres et emprunte au
nouchi. Jérémie Kouadio la décrit comme « une espèce de sabir franco-ivoirien qui utilise
des mots français, phonétiquement déformés, sur des structures syntaxiques des langues
ivoiriennes ». Exemple de trait relevé : la terminaison *-ir* devient *-ie*, « je vais
partir » se dit « je vais patie ».
C'est le registre de la conversation, de WhatsApp, de la réponse en commentaire, de la
radio de proximité, du terrain.

**3. Le nouchi.** Argot né dans la rue d'Abidjan, dérivé en partie des langues du pays,
parlé d'abord par des jeunes marginalisés puis devenu une mode dans toute la jeunesse.
C'est un registre de connivence. Il appartient à ceux qui le parlent, pas à ceux qui
veulent leur vendre quelque chose.

## Le test avant de descendre d'un registre

Trois questions, dans cet ordre. Une seule réponse « non » et on reste au registre
au-dessus.

1. **Est-ce que la marque a le droit de parler comme ça ?** Une banque, une clinique, un
   cabinet, une administration : non. Une marque de boisson, un média jeune, un service
   de transport : peut-être.
2. **Est-ce qu'une personne de la maison parle vraiment comme ça ?** Si le texte n'est
   validé par personne qui emploie ces mots tous les jours, il ne sort pas. Un expert IA
   n'a pas d'oreille ivoirienne, il a un lexique.
3. **Est-ce que le mot a été vérifié dans une source, aujourd'hui ?** Voir plus bas.

Ce qui passe presque toujours, quel que soit le secteur : **le français standard écrit
avec des références locales réelles** (les quartiers, les prix en francs CFA, les
opérateurs, les heures de circulation, le calendrier des fêtes). La localisation se joue
là bien plus que dans l'argot.

## ⛔ Ce qui ne se fait jamais

- **Inventer un mot nouchi, ou en deviner le sens.** Un mot mal employé ne produit pas
  un malentendu, il produit une moquerie. Si le mot n'est pas dans une source, il ne
  s'écrit pas.
- **Employer un mot du lexique sans validation humaine.** Le relevé donne un sens, pas
  une charge. Plusieurs entrées du lexique joint sont violentes ou sexuelles : elles y
  figurent pour être **reconnues dans un message reçu**, jamais pour être écrites.
- **Transposer d'un pays à l'autre.** Le nouchi est ivoirien. Ce n'est ni le wolof urbain
  de Dakar, ni le camfranglais de Douala, ni le pidgin de Lagos. Les confondre est la
  faute que tout le monde repère.
- **Traduire un slogan mot à mot vers le registre populaire.** On réécrit l'intention,
  jamais la phrase.

## Où vérifier un mot

| Source | Adresse | Ce qu'on y trouve |
|---|---|---|
| Dictionnaire des francophones, localisation Côte d'Ivoire | https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781 | Les mots du français de Côte d'Ivoire, dans un dictionnaire francophone institutionnel. La source la plus solide des trois. |
| Wiktionnaire, annexe des mots nouchis | https://fr.wiktionary.org/wiki/Annexe:Liste_de_mots_nouchis | Le lexique joint à cette compétence en vient. Collaboratif, donc à recouper. |
| Wikipédia, Nouchi | https://fr.wikipedia.org/wiki/Nouchi | L'histoire et le statut social du registre, utiles pour savoir à qui il appartient. |

Les trois ont été ouvertes le 14/09/2026. Une quatrième piste, le corpus universitaire
ivoirien (ltml.ci), ne répondait pas ce jour-là : à retenter.

## Le lexique

`lexique-nouchi.md`, joint à cette compétence : **122 entrées**, relevées le 14/09/2026.
La source annonce elle-même plus de 500 mots et n'en publie qu'une partie. C'est donc un
premier relevé, pas un dictionnaire, et il est écrit dessus.

**Ce qui manque et qui se construit avec un collègue ivoirien, pas tout seul :**
le registre de chaque mot (courant, familier, grossier), ce qu'une marque peut reprendre,
et les **ivoirismes du français standard**, ces tournures parfaitement correctes et
parfaitement locales qui sont le vrai gisement pour une marque. Tant que cette passe n'a
pas eu lieu, le lexique sert à **comprendre**, pas à **écrire**.

## Ce que j'en fais concrètement

- **Je lis** un commentaire, un message WhatsApp, un verbatim de terrain sans buter sur
  un mot et sans en inventer le sens.
- **J'écris** en français standard par défaut, avec des références locales réelles.
- **Je propose** une variante en registre populaire quand le canal s'y prête, en la
  marquant comme *à faire valider*, jamais comme livrée.
- **Je signale** quand un texte reçu de la maison sonne étranger, et je dis pourquoi.
