---
id: Y0677
name: socle-couche-locale
description: >
  La carte de ta matière locale : ce que tu possèdes déjà comme sources ivoiriennes et
  régionales, ce qui est repéré sans être chez toi, et ce qui manque encore, avec le
  pourquoi et l'endroit où chercher. À charger avant tout livrable qui cite un chiffre,
  une règle, un prix, un calendrier ou un usage local, et chaque fois que tu t'apprêtes à
  répondre par une norme générale là où le terrain ivoirien commande.
version: 4
maj: 2026-09-21
---

# Ta couche locale

## Ce que c'est

`memory/reference/couche-locale.md`, dans ton espace. Une carte tenue par la maison, qui dit
pour ton métier quelle matière locale te sert, pourquoi, et où elle se trouve.

Elle est **engendrée depuis le tableur « Yelema, Couches locales centralisées »** et
redescend toute seule. ⛔ Une correction écrite dans le fichier disparaît au passage
suivant : elle se fait dans le tableur, et tu le signales plutôt que de l'écrire toi-même.

## Quand l'ouvrir

Avant d'écrire un livrable qui avance :

- un **chiffre** local (population, tarif, salaire, délai, part de marché) ;
- une **règle** qui dépend du pays ou de la zone (droit du travail, fiscalité, UEMOA) ;
- un **calendrier** (fériés, saisons, périodes creuses, échéances administratives) ;
- un **usage** de métier propre à la Côte d'Ivoire ou à la région ;
- le **nom d'une institution** et ce qu'elle décide.

## Comment s'en servir

1. Ouvre le fichier et cherche la famille qui correspond à ta question.
2. **« Ce que tu as déjà »** : la pièce est dans ton espace. La ligne **« Chez toi »** donne
   le chemin exact. Va la lire, ne la suppose pas.
3. **« Repéré, pas encore chez toi »** : le lien est donné. Ouvre-le, c'est plus rapide et
   plus sûr qu'une recherche neuve.
4. **« Encore à chercher »** : personne ne l'a. Applique `aller-chercher`, et si tu ne
   trouves pas, écris que tu n'as pas trouvé **et où tu as regardé**.

## ⛔ Une pièce qui est un outil ne se lit pas, elle se lance

Constaté le 21/09/2026, à l'usage, et c'est un piège qui ne se voit pas autrement. Quand la
ligne **« Chez toi »** désigne un **script** (`integrations/<service>/<outil>.py`) et non un
document, il n'y a rien à ouvrir : le chiffre n'existe pas encore, il se produit en lançant
la commande.

Le réflexe de lecture ne s'y applique pas, et le réflexe qui prend sa place est le mauvais :
on part chercher sur le web, on tombe sur un agrégateur grand public, et on sert un chiffre
d'une qualité inférieure à celui qu'on avait sous la main. La maison n'a rien perdu de
visible, elle a simplement servi moins bien que ce qu'elle pouvait.

**Ce que ça t'impose :**

- un chemin qui finit par `.py` se **lance**, il ne se cite pas. Lance-le, lis sa sortie,
  puis écris ;
- un outil qui répond est une **source primaire relevée par la maison**, et il prime sur un
  site tiers trouvé en cherchant. Tu nommes sa source réelle dans le livrable, pas le nom du
  script ;
- si le lancement échoue, tu le dis et tu descends l'échelle de `aller-chercher`. Tu n'as pas
  le droit de sauter l'outil en silence.

⚠ Côté maison : chaque fois qu'un outil produit une matière stable, on en tire **aussi** une
note lisible dans `bases-locales/`, et c'est elle qu'on nomme en premier. L'outil reste
nommé derrière, pour rafraîchir ou pour un cas non couvert. Un relevé qui n'existe que sous
forme de commande n'est pas une couche locale, c'est une promesse.

## Une couche locale périme

Chaque élément intégré porte une ligne **« À revérifier le »**. Passée cette date, la pièce
reste lisible mais son chiffre n'engage plus : une enquête annuelle a été republiée, un tarif
a bougé, un décret a changé le découpage. Tu peux t'en servir, et tu écris alors la date du
relevé à côté du chiffre. Si l'écart compte pour le livrable, tu le signales plutôt que de
servir une valeur périmée sans le dire.

## ⛔ Le triple contrôle, obligatoire avant d'écrire « ça n'existe pas »

Demandé par la direction le 20/09/2026, après deux manques que rien d'autre n'aurait vus. Une
absence de source ne se déclare qu'après ces trois passages, et **on écrit où l'on a
regardé** : sans cela, rien ne distingue une recherche menée d'une recherche non menée.

1. **Chez le producteur, dans TOUTES ses rubriques.** Une institution publie plusieurs
   familles de chiffres qui ne sont pas au même endroit. L'ARTCI publie le parc et le trafic
   déclarés par les opérateurs dans son rapport trimestriel, et l'usage réel des plateformes
   dans une enquête ménages rangée ailleurs. Chercher dans la mauvaise rubrique et conclure à
   l'absence est l'erreur la plus fréquente.
2. **Chez un co-éditeur.** Une publication officielle est presque toujours co-signée, et le
   co-éditeur l'héberge sans protection. Un document introuvable sur le site de l'ANStat se
   récupère sur celui du ministère qui l'a signé. Avant de conclure qu'un document public est
   hors d'atteinte, chercher **qui d'autre l'a signé**.
3. **À l'usage.** Poser à l'expert la question que la pièce est censée servir, et regarder ce
   qui sort. C'est le seul contrôle qui attrape un chiffre juste rapporté à la mauvaise base :
   la valeur n'a pas bougé, aucune relecture ne la signale, et elle est fausse.

## Les deux fautes à ne pas commettre

⛔ **Un élément marqué intégré ne veut pas dire que tu l'as lu.** Il dit que la pièce est
là. Une affirmation se tire d'une page ouverte, jamais de la ligne d'un tableau.

⛔ **Un élément marqué à chercher n'autorise pas à inventer.** L'absence de source se dit,
elle ne se comble pas. C'est la même règle que `socle-anti-hallucination`, appliquée à la
matière locale.

## Ce qu'elle ne remplace pas

Elle dit **où** est la matière, elle ne la contient pas. Les quatre postes qui ont un corpus
constitué gardent `referentiel-local`, qui lui porte vraiment du contenu : la couche locale
est la carte, le référentiel est le terrain.
