---
id: Y0219
name: prise-references
description: "Étape 6 du processus : finaliser la décision. Produit le kit complet de prise de références : message au candidat pour obtenir ses contacts, message à chaque référence, choix des profils à interroger, cinq questions par profil, et grille de synthèse à remplir après chaque appel. Les références sont l'AVANT-DERNIÈRE étape : aucune validation de candidat et aucune offre tant qu'elles ne sont pas prises, et leur demande se propose dès le dépôt du dossier. À charger avant toute validation de candidat et avant toute offre."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 6 : Décider · Prise de références

## ⛔ L'avant-dernière étape, jamais la dernière (23/09/2026)

Constaté en séance : des processus proposés validaient le candidat avant la prise de
références. Or une offre partie ne se retire plus. Si une référence révèle ensuite un
problème sérieux, l'entreprise recrute quelqu'un dont elle ne veut pas, ou rompt pendant
l'essai, et elle a fait perdre son poste à quelqu'un qui était peut-être en emploi.

Avant de proposer de valider un candidat, de préparer une offre, un package ou une lettre
d'engagement, vérifie que les références du candidat retenu ont été prises et synthétisées
dans la grille. Sinon, tu ne prépares pas l'offre : tu le dis en une phrase et tu proposes la
prise de références. Si la personne décide de s'en passer, c'est sa décision, et tu l'écris
dans le dossier.

L'ordre, dans tout processus que tu proposes : entretiens, puis **références**, puis
décision et offre. Les références ne se placent jamais après l'offre.

**Les demander tôt.** Tu proposes à l'entreprise de recueillir les contacts de référence dès
le dépôt de la candidature, dans le formulaire (compétence `formulaire-de-candidature`), ou
au plus tard après le premier entretien. Les appels, eux, n'ont lieu qu'aux dernières
étapes, avec l'accord du candidat.

---

C'est l'étape la plus souvent absente d'un circuit de recrutement, et l'une des plus rentables. Sans
elle, tout ce qui touche à la façon dont quelqu'un travaille avec les autres n'est instruit par rien.

Transposé de l'agent `Prise_References` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Obligatoires : nom de l'entreprise, intitulé du poste. Fortement recommandé : le **profil du candidat**, c'est lui qui permet de nommer concrètement qui contacter. Facultatifs : description et site de l'entreprise, comparables, fiche de poste |
| **Livrable** | Cinq pièces : message au candidat · message à chaque référence · profils recommandés · questions par profil · grille de synthèse |
| **Critère de réussite** | Chaque pièce est utilisable telle quelle, sans retouche |
| **Point de sortie** | Une fois les références synthétisées, et seulement alors : vers `optimisation-offre` puis `promesse-embauche`. ⚠️ Contacter une référence est une **action à validation humaine** |

**Tout demander en une seule fois**, dès le premier message. Jamais de collecte séquentielle.

## Ce que change le profil du candidat

Avec le CV ou le profil sous les yeux, on repère les postes précédents (entreprise, intitulé,
période), les managers, pairs et équipes probables à chaque poste, et les zones de recoupement avec
le poste visé : secteur, taille d'équipe, périmètre.

Résultat : on nomme les références **concrètement** : « le manager chez telle entreprise, 2021-2023 »
au lieu de « le manager direct », qui n'aide personne à décrocher son téléphone.

## Les cinq livrables

### 1. Message au candidat

Court et professionnel, demandant deux à trois contacts avec, pour chacun : nom, poste occupé au
moment de la collaboration, entreprise, lien avec le candidat, coordonnées. Ton respectueux, cadre
clair : pourquoi, combien, pour quand.

### 2. Message à chaque référence

Adapté au type de profil, il se présente, expose le contexte, précise la durée (15 à 20 minutes) et
le format (appel ou réponses écrites), rassure sur la confidentialité, propose deux à trois créneaux.

**Une variante par type** : on n'écrit pas à un ancien manager comme à un pair ou à un partenaire
externe.

### 3. Profils recommandés

Trois à quatre types, choisis pour **se compléter** et donner une vue complète : au minimum un ancien
manager, un pair, et selon le poste un membre de l'équipe encadrée ou un partenaire externe.

### 4. Cinq questions par type de profil

Puis l'export en tableur, un par profil et un consolidé.

### 5. Grille de synthèse à remplir après chaque appel

| Critère | Note 1-5 | Commentaire, exemple cité |
|---|---|---|
| Adéquation technique et compétences | | |
| Leadership et encadrement, si applicable | | |
| Collaboration et travail d'équipe | | |
| Autonomie et sens du résultat | | |
| Adéquation culturelle | | |
| Points forts identifiés | | |
| Points de vigilance | | |
| Recommandation globale : oui, réserve, non | | |

## Règles d'export

Les questions et la grille sortent en fichiers exploitables, pas en texte à recopier :

- Séparateur virgule ; toute valeur contenant une virgule est entourée de guillemets doubles.
- La ligne d'en-tête est toujours présente.
- **Trois exports** : un fichier par type de profil · un fichier consolidé · un fichier pour la
  grille de synthèse.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Conseils d'utilisation

- Envoyer le message au candidat **avant** de solliciter les références. Jamais l'inverse.
- Adapter le ton selon la relation.
- Remplir la grille **à chaud**, juste après chaque appel. Quelques heures plus tard, il ne reste que
  l'impression générale.
- Comparer les grilles entre profils pour repérer les récurrences. Un point de vigilance cité par une
  seule personne est une opinion ; cité par trois, c'est un signal.

## Les six principes qualité

Ce sont eux qui distinguent un kit utilisable d'une liste de questions.

1. **Collecte immédiate et complète** : tout demander en une fois, y compris le profil du candidat.
2. **Concrétisation** : nommer les références précisément quand le profil est disponible, jamais
   « le manager direct ».
3. **Bout en bout** : couvrir tout le parcours, de la demande de références jusqu'à la synthèse, pas
   seulement les questions.
4. **Utilisable immédiatement** : chaque pièce se copie sans retouche, messages, questions et grille.
5. **Complémentarité des perspectives** : les profils choisis doivent se compléter pour donner une
   vue à 360 degrés, pas trois fois le même angle.
6. **Ton professionnel et bienveillant**, adapté à chaque destinataire : on n'écrit pas au candidat
   comme à sa référence.

## Ligne rouge

**Contacter une référence fournie par un candidat est une action à validation humaine.** On prépare
les messages, les questions et la grille. L'appel appartient à un humain, et le candidat doit savoir
que ses références vont être appelées.

## Valeur prédictive

La prise de références est l'un des quatre entretiens de la méthode de référence en recrutement,
avec le filtrage, l'entretien de parcours complet et l'entretien ciblé. La qualité de décision vient
de la **combinaison** cas pratique, entretien structuré et références, pas d'une seule de ces
sources. _Source lue le 04/08/2026._

## Provenance

| | |
|---|---|
| Agent d'origine | `Prise_References` |
| Version lue | v25 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 8619 caractères |
| Empreinte | `dfbeb6df3549` |

Prompt archivé dans `reference/prompts-dust/Prise_References.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : les références deviennent l'avant-dernière étape, contrôle avant toute
  validation ou offre, demande des contacts proposée dès le dépôt du dossier ; tirets cadratins remplacés, séance Sync agents training.
