---
id: Y0644
name: publication-frames
description: "Publie un livrable HTML sur le service de pages partageables de la maison et rend un lien public. À charger dès qu'un prompt d'origine demande un « Frame interactif », ou quand le client veut un lien plutôt qu'un fichier. Porte les règles de ce qui a le droit d'y aller — et surtout de ce qui n'y va jamais."
bucket: B
tags: [Recrutement, Production]
version: 1
maj: 2026-09-10
---

# Publier un livrable en page partageable

Le service de la maison publie une page HTML autonome et rend un **lien partageable**. C'est ce que
réclament les prompts d'origine sous le nom de « Frame interactif », et c'est ce que le client
demande quand il veut un lien plutôt qu'une pièce jointe.

**Éprouvé de bout en bout le 04/08/2026** : publication, lecture du lien sans clé, mode privé,
révocation, refus sans clé. Les cinq comportements sont vérifiés, pas supposés.

## 🔴 Ce qui n'y va JAMAIS

Le lien est **public et non listé** : quiconque l'a l'ouvre, sans mot de passe. Une page publiée est
sur le web ouvert et peut être indexée ou recopiée avant toute révocation.

Ne partent donc jamais en page publiée :

- **Un nom de candidat**, qu'il ait postulé ou non. Cela couvre les études de candidatures, les
  listes de sourcing, les comptes rendus d'entretien, les scorecards remplies.
- **Un montant de rémunération** : fourchette, benchmark, offre, grille.
- **Une note interne** : réserve de méthode, commentaire de source, arbitrage en attente. Vérifier
  le pied de page avant de publier — c'est là qu'elles se cachent.
- **Une donnée d'une autre maison du portefeuille.**

Ce qui peut y aller : une **fiche de poste**, une annonce, un guide destiné à un candidat, un
document de méthode sans nom propre, un tableau de bord agrégé sans donnée nominative.

⚠️ **Le doute se tranche vers le fichier joint.** Un PDF sur le fil Telegram ne fuit pas.

## Mode privé — ce qu'il fait vraiment

`isPublic: false` rend `visibility: private`, et le lien répond **403 « Ce Frame n'est pas
public »**. Vérifié. Conséquence à connaître : le mode privé ne sert pas à partager avec quelqu'un
de précis, il rend la page **inaccessible tout court**. Il n'existe pas de partage restreint. Donc
un document sensible ne devient pas partageable en le passant en privé : il ne se publie pas.

## Deux hébergements possibles — celui du fournisseur est meilleur

Éprouvés tous les deux le 04/08/2026, sur le même document.

| | Service de la maison | **Publication native du fournisseur** |
|---|---|---|
| Persistance | ✅ **réglée le 04/08/2026 au soir** — stockage en base, survit aux redéploiements | ✅ conservé, republication à la même adresse |
| Visibilité par défaut | 🔴 **public** | ✅ **privé**, le client partage s'il le décide |
| Partage restreint | 🔴 n'existe pas : public ou fermé | ✅ le propriétaire ouvre depuis la page |
| React encapsulé | ✅ | ✅ |
| Clé à gérer | une, devinable | aucune |
| Bascule de thème pour le lecteur | non | ✅ offerte par l'hébergeur |

**Conséquence de fond : le mode privé par défaut lève l'interdit principal.** Ce qui ne pouvait
pas être publié — sourcing nominatif, montants, notes internes — peut vivre sur une page privée du
fournisseur, que le client ouvre à qui il veut. Le contrôle de fuite reste utile, mais il n'est
plus la seule barrière.

🔴 **Éprouvé le 04/08/2026 : le client a reçu « Page not found ».** La page est rattachée au
compte qui l'a publiée, et le partage se fait **dans l'interface de la page**, pas depuis l'agent.
Tant que ce point n'est pas réglé, une page native n'est pas livrable à quelqu'un d'autre.

⚠️ **Règle qui en découle, valable bien au-delà de ce service : un accès se teste du côté du
destinataire.** Vérifier qu'une page répond depuis sa propre session ne prouve rien sur ce que
voit le client. À défaut de pouvoir le tester, l'annoncer comme non vérifié plutôt que comme
acquis.

**Fabrication** : `frame.py … --natif <fichier>` produit la variante attendue — contenu de page
seul, sans `<!doctype>` ni `<head>`, l'hébergeur enveloppant lui-même. Republier **le même chemin
de fichier** conserve l'adresse ; un chemin différent en crée une nouvelle.

⚠️ **La bascule de thème du lecteur estampille `data-theme` sur la racine.** Un gabarit qui ne
connaît que `prefers-color-scheme` ignore le bouton : il faut aussi `:root[data-theme="dark"]` et
`:root[data-theme="light"]`, et ils doivent l'emporter dans les deux sens. Corrigé dans `base.css`
le 04/08/2026.

## Deuxième chaîne : le TSX compilé par le service

Depuis le 04/08/2026 au soir, le service compile lui-même un composant React. C'est la chaîne que
décrit la documentation de la maison, et elle **coexiste** avec la nôtre : chacune a un manque, et
c'est le contenu qui décide.

| | **Chaîne maison** (`type: "html"`) | **Chaîne du service** (`type: "react"`) |
|---|---|---|
| Écriture | `htm`, React encapsulé dans le fichier | vrai `.tsx`, Tailwind, composants shadcn |
| Graphiques | ✅ bibliothèque encapsulée | 🔴 **aucune** — `Could not resolve "recharts"` |
| Contrôles bloquants | ✅ fuite et niveau, avant publication | à faire à la main sur le source |
| Modification en place | ✅ par `PUT` | ✅ par `PUT` |

**Ce qui décide** : dès qu'il y a des courbes, la chaîne maison. Pour du texte, un processus, un
tableau filtrable, la chaîne du service donne un rendu plus proche de ce que la maison produit
ailleurs. Dans les deux cas, `PUT /api/frames/{id}` change le contenu **sans changer le lien** —
donc un livrable garde une adresse stable d'une version à l'autre.

### Ce qu'il faut savoir avant d'écrire un `.tsx`

- Le fichier d'entrée fait `export default` d'un composant. **Jamais** de code de montage : le
  service s'en charge.
- Composants disponibles : Button, Card, Badge, Tabs, Input, Separator, Progress, plus `cn`. Rien
  d'autre — pas de Select, pas de Dialog, pas de graphique.
- Les types ne sont pas vérifiés, seulement retirés. Une faute de syntaxe fait échouer la
  publication avec le message du compilateur ; une faute de typage passe et casse à l'exécution.
- Données volumineuses : fichier séparé dans `files`, chargé par `useFile("nom")`, jamais importé.
- ⚠️ **Le thème sombre passe par la classe `.dark` sur la racine**, pas par la préférence du
  système : le style compilé porte `.dark` et ignore `prefers-color-scheme`. **Un bouton de bascule
  est donc obligatoire**, sinon la page reste claire chez tout le monde. Vérifié le 05/08/2026.
- Les tracés se font en SVG calculé dans le composant — échelles, `path`, aires, barres, survol
  géré par un état.

### Le contrôle hors navigateur survit au changement de chaîne

C'est le point à ne pas lâcher : la compilation est distante, **la vérification reste locale**.
`jsdom` permet d'exécuter la page publiée et de cliquer chaque commande avant d'annoncer le lien.

```bash
npm install jsdom --silent          # une fois, dans un dossier de travail
node run.mjs                        # JSDOM(html, {runScripts:"dangerously", pretendToBeVisual:true})
```

Ce qu'on contrôle : zéro erreur d'exécution · chaque filtre cliqué et **ses compteurs relus dans le
DOM** · les tracés présents · les dépliables qui s'ouvrent un à un · la bascule de thème qui pose
réellement la classe.

⚠️ **Deux pièges de vérification, tous deux rencontrés :**
1. `document.body.textContent` **inclut le contenu des `<script>`**. Un test qui y cherche une
   chaîne conclut « présent » même quand rien n'est affiché. Chercher dans les nœuds rendus.
2. Les accents sont **échappés en unicode** dans le fichier compilé : un `grep` au shell sur le HTML
   servi renvoie 0 à tort. Comparer en Python sur la chaîne décodée.

Et re-requêter les boutons **après** chaque clic : une liste de nœuds capturée avant un changement
d'onglet est périmée, et fait conclure à tort qu'un bouton est introuvable.

## Deux garde-fous automatiques, et un modèle à remplir

L'atelier ne se contente pas d'assembler : il **refuse** de publier dans deux cas.

| Garde-fou | Ce qu'il refuse | Sortie |
|---|---|---|
| **Fuite** | un nom de candidat, une adresse, un téléphone, un identifiant technique, un secret, un nom interne | code 1 |
| **Niveau** | des chiffres sans graphique · aucune interaction · pas de thème sombre · règles `data-theme` absentes · rien pour le téléphone · aucune date · pas de pied de page · des chiffres sans un mot sur leur provenance | code 2, `--brut` pour outrepasser |

Le premier dit ce qu'une page **n'a pas le droit de montrer**, le second ce qu'elle **doit être**.
Les deux ont été éprouvés en leur soumettant une page fautive : tous deux ont bloqué.

**`modeles/tableau-de-bord.js`** est un modèle prêt à remplir : un bloc DONNÉES en tête, tout le
reste générique. Trois tracés fournis — barres horizontales pour un entonnoir ou un classement,
courbe cumulée pour une évolution, barres empilées pour une répartition en deux séries. Copier dans
`apps/<sujet>.js`, remplir les données, publier. **C'est ce qui rend le niveau reproductible sans
dépendre de l'inspiration du moment.**

## L'atelier — le seul chemin

Ne plus assembler à la main : `tools/livrable/` fait le travail identique à chaque fois.

```bash
source ~/.config/agents/secrets.env
python3 tools/livrable/frame.py tools/livrable/apps/<sujet>.js \
        --titre "…" --desc "…" --sortie deliverables/<projet>/<slug>_v<N>.html \
        --noms /tmp/noms.txt          # liste des candidats du poste, un par ligne
        --brouillon                    # tout sauf publier, pour itérer
```

Il enchaîne : assemblage (React, ReactDOM, htm, gabarit, logo — tout dans le fichier) · exécution
du composant hors navigateur · **contrôle de fuite bloquant** · publication · réouverture du lien.

Le composant vit dans `tools/livrable/apps/`, reçoit la globale `LOGO`, monte sur `#root`, et
utilise les classes de `base.css` : `.wrap .marque .stats .stat .onglets .ong .carte .g .cst .meth`.

⚠️ **Le contrôle porte sur le HTML rendu, pas sur le fichier assemblé.** Le contenu d'une page
React vit dans un `<script>` : contrôler le fichier en excluant les scripts ne contrôle rien.
Erreur commise puis corrigée le 04/08/2026, et le garde-fou a été éprouvé en lui soumettant une
page où un nom de candidat avait été injecté volontairement — il l'a bloquée.

Pour un PDF, même atelier : `tools/livrable/pdf.py` prend un corps HTML nu, l'habille du gabarit
d'impression, rend, compte les pages, applique le même contrôle et sort un aperçu image **à
regarder avant d'envoyer**.

## Mode d'emploi

Le jeton est dans le magasin de secrets (`frames.txt`), exporté par `secrets.env` sous
`FRAMES_API_KEY`, avec `FRAMES_API_URL`. **Jamais en dur dans un script.**

```bash
source ~/.config/agents/secrets.env
# le HTML se passe par fichier JSON : un document réel dépasse la ligne de commande
curl -s --max-time 90 -X POST "$FRAMES_API_URL/api/frames" \
  -H "x-api-key: $FRAMES_API_KEY" -H "Content-Type: application/json" \
  -d @payload.json
# -> {"status":"published","frameId":"frm_xxxxxxxx","shareUrl":"…","visibility":"public"}

# ⚠ REMPLACER une page en place : --id prend le frameId, PAS l'UUID du lien de partage.
#   Le frameId vaut « frm_ » + les huit premiers caracteres de l'UUID :
#   .../share/frame/33d89945-1e7b-4b08-9c1e-da1d2620fef2  ->  --id frm_33d89945
#   L'UUID complet repond 404, ce qui ressemble a une page disparue alors que rien n'est casse
#   (verifie le 09/09/2026 sur la page du visiteur 9).

curl -s -X DELETE "$FRAMES_API_URL/api/frames/frm_xxxxxxxx" -H "x-api-key: $FRAMES_API_KEY"
# -> {"status":"revoked",…} puis le lien répond 404
```

Champs : `title` et `html` obligatoires, `description` et `isPublic` optionnels, `expiresAt` en
ISO 8601 pour une expiration automatique. Erreurs : 400 champ invalide, 401 clé absente ou fausse,
413 au-delà de 2 Mo.

Construire le corps avec Python plutôt qu'à la main — le HTML contient des guillemets, des accents
et souvent une image encodée :

```python
json.dump({"title":…,"description":…,"html":open(f).read(),"isPublic":True},
          open("payload.json","w"), ensure_ascii=False)
```

## 🔴 Une page React : possible, mais aucun script externe ne se charge

Le service renvoie une **politique de sécurité stricte**, relevée dans ses en-têtes le 04/08/2026 :

```
default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline';
img-src data: https:; connect-src 'none'; frame-ancestors 'none'
```

Ce que cela impose, et qui n'est écrit nulle part dans la documentation de la maison :

| Contrainte | Conséquence |
|---|---|
| `script-src 'unsafe-inline'` seul | **Aucun script depuis un serveur externe.** Charger React depuis un dépôt public échoue en silence : la page reste blanche. |
| `connect-src 'none'` | Aucun appel réseau depuis la page. Elle porte ses données ou elle n'en a pas. |
| `style-src 'unsafe-inline'` | CSS inline uniquement, pas de feuille externe. |
| `img-src data: https:` | Une image s'encode en data URI. C'est ce qui permet le logo. |
| `frame-ancestors 'none'` | La page ne s'embarque pas dans une autre. Elle s'ouvre seule. |

**La méthode qui marche** : encapsuler React, ReactDOM et `htm` **dans le fichier**, et écrire le
composant avec `htm` plutôt qu'en JSX — `htm` donne une syntaxe presque identique au JSX sans
aucune compilation. Poids total d'une page complète : environ 175 Ko, très loin de la limite de
2 Mo.

```python
shell = shell.replace("/*REACT*/", open("react.production.min.js").read())
shell = shell.replace("/*RDOM*/",  open("react-dom.production.min.js").read())
shell = shell.replace("/*HTM*/",   open("htm.umd.js").read())
shell = shell.replace("/*APP*/",   open("app.js").read())
```

⚠️ **Ne jamais compiler du JSX au vol dans la page** : la bibliothèque qui le ferait pèse plusieurs
mégaoctets et dépasse la limite du service. `htm` pèse 1,4 Ko.

### Vérifier qu'une page React fonctionne vraiment

Servir le fichier ne prouve pas qu'il s'exécute. **Rendre le composant hors navigateur** avant de
livrer le lien, avec le bundle serveur de React :

```bash
node -e "… renderToReadableStream(React.createElement(App)) …"
```

Contrôler dans la sortie : le nombre de blocs attendus, les compteurs calculés par le composant,
et la présence des textes clés. Éprouvé le 04/08/2026 sur la page des 7 étapes : 7 sections
rendues, compteur d'arrêts à 6, tous les blocs présents.

⚠️ Le bundle serveur ne sert qu'au test et **ne part jamais dans la page publiée**.

## Le standard de rendu — arrêté par le client le 04/08/2026

**Une page publiée n'est jamais une page brute.** La demande est explicite : un beau format React,
dynamique. Ce qui suit n'est pas une préférence de style, c'est le niveau attendu par défaut.

**Si la page porte des chiffres** — tableau de bord, entonnoir de candidatures, délais, sources de
recrutement : elle porte des **courbes et des graphiques soignés**, pas un tableau de nombres.

**Si la page porte du texte ou un processus** : elle est **cliquable et vivante** — dépliables,
filtres, onglets, compteurs qui se recalculent, états visibles au survol.

Dans les deux cas : thème clair et sombre, lisible sur téléphone, hiérarchie typographique réelle,
palette tirée du logo de la maison concernée.

⚠️ **Et la même exigence vaut pour les PDF.** Un livrable en pièce jointe se soigne autant qu'une
page en ligne : mise en page, couleurs de la maison, tableaux tenus, rien qui déborde. Un document
qui a l'air bâclé décrédibilise ce qu'il contient.

### Les graphiques — la bibliothèque de la maison, encapsulée

⚠️ **Correction du 04/08/2026.** Cette compétence a longtemps dit « pas de bibliothèque de
graphiques, tout en SVG à la main ». C'était vrai de l'interdiction de charger un script externe,
faux comme conclusion : **une bibliothèque encapsulée dans le fichier ne viole aucune politique de
sécurité**, puisqu'elle n'est pas chargée depuis un serveur.

**Recharts est donc embarqué**, la bibliothèque même qu'emploient les agents de la maison. Elle est
dans `tools/livrable/vendor/recharts.js` avec sa dépendance `prop-types.js`, et l'atelier ne
l'ajoute **que si le composant s'en sert** — elle pèse un demi-méga, on ne la fait pas payer à une
page de texte. La détection est automatique : écrire `RC.` dans le composant suffit.

```js
<${RC.ResponsiveContainer} width="100%" height=${260}>
  <${RC.AreaChart} data=${FLUX}>
    <${RC.CartesianGrid} strokeDasharray="3 3" vertical=${false} stroke="hsl(var(--border))" />
    <${RC.XAxis} dataKey="s" /><${RC.YAxis} allowDecimals=${false} />
    <${RC.Tooltip} ...${infobulle} />
    <${RC.Area} type="monotone" dataKey="n" stroke=${T(1)} fill="url(#gf)" />
  <//>
<//>
```

Trois pièges, tous rencontrés et réglés :

1. **`ResponsiveContainer` ne rend rien hors navigateur** — il mesure le DOM. Sans correctif, le
   contrôle de niveau ne voyait aucun graphique et aucune erreur n'était levée. L'atelier lui
   substitue une taille fixe **le temps de la vérification seulement** ; la page publiée garde bien
   le conteneur élastique.
2. **Le bundle universel veut un `this` global.** Chargé en module strict, il lit `t.React` sur
   `undefined` et casse. On l'exécute avec `new Function(src).call(globalThis)`, ou dans un contexte
   où `this` vaut le global.
3. **L'infobulle par défaut est blanche en dur** : illisible en thème sombre. Lui passer
   `contentStyle` avec les jetons de couleur, sinon la page est cassée pour la moitié des lecteurs.

Ce qui n'a pas besoin de la bibliothèque — une jauge, un entonnoir simple, une barre d'avancement —
se dessine toujours en **SVG calculé dans le composant** : c'est plus léger et suffisant.

- Une échelle = une fonction qui projette une valeur sur une coordonnée. Deux lignes de code.
- Une courbe = un `path` construit par `points.map(…).join(' ')`.
- Une aire = le même tracé refermé sur la ligne de base, en remplissage à faible opacité.
- Des barres = des `rect` avec un rayon de 3 px sur les extrémités côté valeur.
- Le survol se gère avec un état React et un repère vertical ; les cibles de survol sont plus
  larges que la marque elle-même.

**Règles qui ne se négocient pas** : jamais deux axes verticaux sur un même graphique — deux
grandeurs d'échelles différentes font deux graphiques. Une couleur suit une entité, jamais son
rang : un filtre qui change le nombre de séries ne repeint pas les survivantes. Grille et axes
restent discrets. Les nombres alignés en colonne prennent `font-variant-numeric: tabular-nums`.
Une légende dès deux séries, et les valeurs restent en couleur de texte, pas en couleur de série.

### Sur « TSX »

Le service sert un fichier, il ne compile rien. Il n'y a donc **pas de TypeScript ni de JSX
compilé** dans la page : le composant s'écrit avec `htm`, dont la syntaxe est celle du JSX à
l'identique. Le résultat est du vrai React ; le dire tel quel plutôt que d'annoncer du TSX.

## Ce que dit le standard de la maison — lu à la source le 04/08/2026

« Create Frames » n'est pas un agent de l'espace de travail : c'est un **skill natif de la
plateforme**, référencé sous l'identifiant `frames`. Son texte n'est pas exposé par l'interface de
programmation. En revanche deux choses le sont, et elles suffisent :

**1. Une customisation maison, `Chart this`**, qui hérite du skill natif et en expose les règles :

- Recharts avec le conteneur de graphique de shadcn ; couleurs par `var(--chart-1)` à `--chart-5` ;
  infobulle au survol ; grille en pointillés `3 3` ; axes nommés d'après les colonnes.
- **Le choix de la forme se déduit des données** : une colonne de nombres et une de catégories →
  barres ou courbe ; plusieurs séries dans le temps → courbes multiples ; une seule série de
  catégories → barres horizontales au-delà de 5 items, camembert en deçà ; deux colonnes numériques
  → nuage de points.
- **Cas limites nommés** : au-delà de 20 lignes, tout afficher mais supprimer les points ; au-delà
  de 6 catégories, le camembert devient des barres horizontales ; des ordres de grandeur très
  différents appellent une échelle logarithmique ou une mention de l'exception.
- **Une phrase d'enseignement après le graphique** — « les candidatures culminent en juin à 15 » —
  pas un commentaire, un constat chiffré.
- Design : minimal, sans ornement ni effet de relief, beaucoup de blanc, la couleur distingue les
  séries et ne décore pas, le graphique est le sujet de la carte et non son illustration.

**2. La consigne de sortie que portent 253 des 355 agents de l'espace**, mot pour mot :

> Termine TOUJOURS ta réponse par un Frame interactif qui présente le livrable de façon soignée et
> lisible — aux couleurs du brand kit si fourni, sinon une palette neutre et pro. Le message texte
> reste un court wrapper ; le livrable vit dans le Frame. Si la génération de visualisation n'est
> pas disponible, produis à défaut un livrable structuré prêt à l'emploi (ne bloque jamais là-dessus).

Trois enseignements à appliquer :

- **Le message de conversation est un emballage court.** Le travail est dans la page, pas recopié
  au-dessus. Un pavé dans le fil suivi du lien, c'est le livrable rendu deux fois.
- **Un document se découpe en pages ou en onglets**, pas en un long défilement : leur analyse SWOT
  impose quatre pages distinctes, leur veille un onglet par entreprise suivie.
- **Ne jamais bloquer sur l'outil.** Si la publication échoue, le livrable sort quand même, en
  fichier.

### Ce que j'ajoute, et qui n'est pas dans leur standard

Leur skill décrit **quoi produire**. Il ne dit rien de ce qui empêche de publier une bêtise, et
c'est là que se joue la différence sur un sujet de recrutement :

| Chez eux | Ici, en plus |
|---|---|
| le composant est rendu par la plateforme | **rendu hors navigateur avant publication** : une erreur React est vue par moi, jamais par le client |
| rien ne relit ce qui part | **contrôle de fuite bloquant** : nom de candidat, adresse, téléphone, identifiant, secret |
| rien n'impose un niveau | **contrôle de niveau bloquant** : graphique, interaction, thème sombre, téléphone, date, provenance |
| `--chart-1..5` de shadcn, non éprouvés | **paire de séries validée** pour le daltonisme et le contraste, en clair **et** en sombre |
| — | **le lien est rouvert après publication** avant d'être annoncé |

Et une divergence de fond, qui tient au métier : leur palette de couleurs de série n'est pas
vérifiée pour les lecteurs daltoniens. Sur un tableau de bord de recrutement lu en comité, deux
séries indistinguables, c'est une décision prise de travers.

## Adapter le document avant de publier

Un livrable de la maison est calibré pour l'A4 : corps autour de 8,8 pt, largeur 190 mm. **Tel
quel, il est illisible sur un écran.** Ajouter un bloc `@media screen` qui surcharge la mise en
page sans toucher au fond, et un second pour le téléphone :

- corps à 11,5 pt, interligne 1,55, largeur maximale de 820 px centrée sur un fond gris clair ;
- les listes en deux colonnes repassent en une seule (`column-count:1`) ;
- sous 560 px : en-tête empilé, marges réduites, bandeau de conditions en bloc.

Le `@page` et les règles d'impression restent en place : le même fichier sert les deux usages.

## Toujours vérifier après publication

```bash
curl -s -o rendu.html -w "HTTP %{http_code}\n" "<shareUrl>"
```

Contrôler dans le rendu : le titre attendu, la présence du logo, **l'absence de toute note
interne**, et la présence du CSS écran. Un lien annoncé sans être ouvert est un lien mort en
puissance, et un lien mort est pire que pas de lien.

## Limites déclarées par la maison, à répéter au client

- ✅ **La persistance est réglée depuis le 04/08/2026 au soir** — le stockage est passé en base
  hébergée, et les pages survivent aux redéploiements. Vérifié le 05/08/2026 : une page publiée la
  veille à 23 h 50 répond toujours, et une autre publiée avant la bascule aussi.

  ⚠️ **Ce qui reste vrai malgré ça** : ce qui avait été publié **avant** la bascule n'a pas été
  repris — un lien du 04/08 au matin est resté mort. Et un lien reste révocable. Donc pour un
  document qui doit durer, le **PDF fait toujours foi** et un lien ne s'écrit toujours pas dans un
  document remis à un candidat.

  _Historique, pour comprendre les liens morts d'avant : jusqu'au 04/08/2026, le stockage était
  éphémère et une page pouvait mourir en huit minutes. Ce n'est plus le cas._
- **Démarrage à froid — atténué, pas éliminé.** L'hébergeur met jusqu'à une cinquantaine de
  secondes à se réveiller après un quart d'heure d'inactivité. Un ping automatique toutes les dix
  minutes est censé l'en empêcher. ⚠️ **Vérifié le 05/08/2026 : ce ping n'avait encore jamais été
  exécuté**, plus d'une heure après sa mise en place — le planificateur ne s'était pas déclenché.
  Donc garder un délai d'attente d'au moins 60 s, et ne pas promettre au client un accès immédiat.
  Mesures du 05/08/2026, service chaud : 0,6 à 2,1 s.
- **Une diffusion sans réveil existe mais n'est pas activée** (copie de la page sur un stockage
  objet servi par un point d'entrée qui ne dort jamais). Le code est écrit, il attend une décision
  de moyen de paiement. ⚠️ Si elle est activée un jour, **l'adresse des pages change de domaine** —
  or le client a refusé une adresse portant le nom d'un fournisseur. Le point est à lui reposer
  avant activation, pas après.
- **La clé de publication est le nom du service.** Elle est devinable, et la documentation de la
  maison demande elle-même de la remplacer par une valeur forte avant tout usage réel.

## Ce qu'on rend au client

Le titre, une phrase sur ce que contient la page, et **le lien cliquable**. Jamais du code, jamais
un pavé de HTML. Si le document est aussi un livrable classé, le PDF part en même temps : le lien
se partage, le fichier fait foi.

---

## Le standard, chiffré — il vit désormais dans `standard-de-rendu`

Les valeurs de forme (logo contenu et jamais agrandi, quatre tailles de texte, cinq sections au
maximum, contrôle de cinq secondes) ont été **sorties d'ici** le 10/09/2026 : La direction les voulait
partout, or cette compétence-ci n'est liée qu'aux quatre bornes.

👉 **`standard-de-rendu` (Y0482) fait foi**, et il est lié aux quinze postes. Ne pas recopier ses
valeurs ici : deux exemplaires d'un standard divergent en une semaine.

Ce qui reste dans cette compétence est ce qui lui appartient vraiment : la chaîne de
publication, les polices encapsulées, les graphiques, l'atelier.

## Refonte du gabarit — 12/08/2026, sur reproche « tes frames sont vraiment pas beaux »

Reproche fondé. Les pages étaient correctes et plates. Ce qui suit remplace les règles
d'habillage antérieures et s'applique par défaut.

### Un plan de conception s'écrit AVANT le code

Trois lignes, en tête du fichier de gabarit : la palette en valeurs nommées, l'appariement
typographique et ce que chaque face porte, le principe de mise en page. Une page écrite sans
ce plan retombe sur le même habillage passe-partout à chaque fois — et cet habillage a une
signature reconnaissable : crème et terracotta, gris purs, une seule police système,
tout centré, des coins arrondis partout.

### Les polices sont ENCAPSULÉES, jamais liées

La politique de sécurité du service interdit tout chargement externe : une police appelée par
URL ne se charge pas et la page retombe en silence sur la pile système. Elle a l'air normale,
elle n'est simplement pas celle qu'on a dessinée. Les faces sont donc sous-ensemblées puis
inscrites en `data:` dans `tools/livrable/fontes/fontes.css`, injecté en tête par l'atelier.

Chaîne de fabrication (fonttools + brotli dans `.venv-office`) :

```bash
/home/openclaw/.venv-office/bin/python -m fontTools.subset <face>.ttf \
  --unicodes="U+0020-007E,U+00A0-00FF,U+0152-0153,U+2010-2015,U+2018-201D,U+2026,U+202F,U+20AC" \
  --layout-features="kern,liga,calt,tnum" --flavor=woff2 --output-file=<face>.woff2
```

Sous-ensemble latin + ponctuation française : une variable de titre tombe à ~110 Ko, une
face de texte à ~20 Ko. Quatre faces pèsent 230 Ko en base64, pour une limite de 2 Mo.

**Appariement retenu pour la maison** : Fraunces en titres (serif variable, axes `opsz`,
`SOFT`, `WONK` — ton éditorial qui éloigne du tableau de bord logiciel) et Inter sous-ensemblée
en texte et en chiffres. `font-variation-settings` porte les axes ; sans lui la variable rend
son poids par défaut.

### Les neutres se choisissent

Un gris pur se lit « pas choisi ». Les neutres portent un biais de teinte vers l'accent
(ici 215°, côté bleu de la charte). Cela vaut pour le fond, les cartes, les filets, l'encre.

### Marques de graphiques — specs fixes

| Marque | Règle |
|---|---|
| Barre | 18 px, plafond 24 · bout arrondi 4 px **côté valeur**, carré à la base · piste d'un pas sous la surface derrière chaque barre |
| Ligne | 2 px, jointures rondes |
| Point | ≥ 8 px de diamètre, anneau de 2 px en couleur de surface |
| Aire | teinte de série à ~10 % d'opacité |
| Grille et axes | filet 1 px **plein**, jamais tireté, récessif |
| Écart | 2 px en couleur de surface entre marques voisines — jamais un contour |

**Le texte ne porte jamais la couleur de série.** L'identité vient de la marque colorée
à côté du texte, pas du texte coloré. `tabular-nums` uniquement en colonnes de chiffres,
jamais sur un grand nombre isolé.

**La valeur se pose en colonne fixe à droite de la piste**, pas au bout de la barre : au bout,
elle chevauche la piste dès que la barre est longue.

**La gouttière d'étiquettes se dimensionne sur la plus longue.** 268 px sur 760 de large pour
des libellés de six à huit mots ; en dessous, les étiquettes se coupent — et une étiquette
coupée ne se voit pas dans le code, seulement à l'image.

### Le survol est la règle, pas une option

Une page HTML est interactive par nature. Barres, points, cases : chacun ouvre une infobulle
au survol, et les autres marques s'estompent. **Piège** : React synthétise `mouseEnter` à
partir de `mouseover` — un test qui dispatche `mouseenter` sans propagation ne déclenche rien
et fait croire à une panne. Tester avec `new MouseEvent("mouseover", {bubbles:true,
relatedTarget:document.body})`.

⚠️ **Un pourcentage ne s'affiche que si la valeur est une part d'un tout.** Sur une médiane
de réactions, l'infobulle affichait « 74 · 93 % » — un chiffre inventé par la mise en forme.
Le paramètre de base est désormais facultatif : absent, aucun pourcentage n'est calculé.

### Regarder la page, pas seulement l'exécuter

Il n'y a pas de navigateur sur cette machine. Le contrôle hors navigateur prouve que la page
s'exécute ; il ne montre pas à quoi elle ressemble. **Faire un fac-similé statique** — même
CSS, même balisage, sans React — rendu par la chaîne PDF puis converti en image, et le
regarder. Trois défauts réels ont été trouvés ainsi le 12/08, invisibles dans le code :
valeurs écrites par-dessus les barres, libellés coupés, étiquette de date passant sous le titre.

⚠️ Deux artefacts du fac-similé à ne pas prendre pour des défauts : la chaîne PDF ne connaît
ni `repeat(auto-fit, …)` ni les variables CSS dans un attribut de présentation SVG, et elle
rejette `clamp()` avec une addition. Figer ces trois points **dans le fac-similé seulement**.

### La palette de séries se valide, elle ne se juge pas

`node scripts/validate_palette.js "#0581bc,#c8720f" --mode light` — cinq contrôles : bande de
clarté, plancher de chroma, séparation en vision déficiente, plancher en vision normale,
contraste sur la surface. La paire de la maison les passe tous : protanopie ΔE 21,9 ·
vision normale 28,0. À repasser avant toute modification de couleur de série.
