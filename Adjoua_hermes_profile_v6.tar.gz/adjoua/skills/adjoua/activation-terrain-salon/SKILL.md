---
id: Y0396
name: activation-terrain-salon
description: "Prépare, encadre et exploite une présence physique — salon professionnel, foire, activation de rue, portes ouvertes, tournée de marché : objectif chiffré et dispositif de collecte avant, qualification et scripts par profil de visiteur pendant, tri, relance datée et bilan au coût complet après — sans jamais fabriquer une fréquentation, un taux de conversion ou un coût d'opération non fourni."
bucket: B
tags: [Marketing, Terrain, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Salons, foires et activations — vendre là où les gens sont

## Ce qu'il faut avoir sous la main
- **L'événement** : nom, dates, lieu, organisateur, et ce qu'il annonce comme fréquentation (avec la source de ce chiffre si tu l'as).
- **L'objectif** de ta présence : vendre, collecter des contacts, recruter des revendeurs, faire connaître un produit, observer la concurrence — dis-le clairement, un stand ne peut pas viser tout à la fois avec la même intensité.
- **L'équipe mobilisée** : combien de personnes, sur combien de jours, avec quelle disponibilité réelle (celle qui manque à son poste habituel compte).
- **Le budget déjà engagé ou prévu** : stand, transport, impression, hébergement — ce que tu as, même partiel.
- **Ce que tu vends ou présentes**, et à qui tu penses t'adresser en priorité (client final, revendeur, institutionnel...).
- **Le contexte** : premier salon ou opération répétée — si répétée, les résultats et le bilan de la dernière fois sont utiles.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Fixer l'objectif et ce qui prouvera qu'il est atteint

Avant tout supports et tout stand : qu'est-ce que cette présence doit produire, et comment on le saura ? Un objectif comme « se faire connaître » ne se mesure pas — reformule-le en quelque chose de comptable : nombre de contacts qualifiés, nombre de rendez-vous pris, montant de commandes signées sur place, nombre de revendeurs approchés. L'objectif chiffré est un `⟦à renseigner⟧` fourni par l'équipe — tu ne le fixes jamais à sa place, mais tu refuses de construire un plan sans lui.

Distingue l'objectif principal des objectifs secondaires (image, veille concurrentielle, recrutement) : une équipe qui poursuit tout en même temps ne fait rien de bien.

### Étape 2 — Construire le kit de stand et la logistique, en pensant au terrain réel

Liste ce qui doit être physiquement présent et fonctionnel : supports imprimés (et leur délai de fabrication chez l'imprimeur — un support qui arrive le deuxième jour d'un salon de trois jours a manqué la moitié de l'opération), échantillons ou démonstrateurs, monnaie disponible en cash, moyen d'encaisser en mobile money testé avant le jour J, batterie ou groupe électrogène de secours si le site est sujet aux coupures, eau et de quoi tenir des journées longues débout.

Le stock de produits à vendre ou à offrir se dimensionne sur l'objectif de l'étape 1, pas au jugé — et prévoit une marge pour un pic de fréquentation le jour où le salon reçoit une visite officielle ou une couverture radio qui gonfle l'affluence.

Traite le transport et les distances comme une variable du plan, pas un détail : un stand à installer à l'autre bout d'Abidjan un jour d'embouteillage impose une marge de temps que l'équipe doit connaître à l'avance.

### Étape 3 — Préparer le protocole de qualification et les scripts par profil de visiteur

C'est ici que se joue la moitié de la valeur du salon. Écris les quelques questions courtes qui, posées à un visiteur, disent s'il a un besoin réel, un budget, et une échéance — pas des questions ouvertes qui invitent à la conversation sociale, des questions qui produisent une donnée exploitable en trente secondes.

Prévois une fiche de collecte standardisée — papier ou numérique, peu importe le support tant qu'il ne dépend pas de la mémoire de la personne qui tient le stand. Chaque contact collecté doit porter : le profil, la réponse aux questions de qualification, et une note d'intention de l'équipe (chaud / tiède / froid) inscrite sur le moment, pas reconstituée le soir.

Écris ensuite un script différent selon le profil rencontré : le client final qu'on qualifie et qu'on oriente vers l'achat ou le rendez-vous, le revendeur potentiel à qui on parle marge et volume, l'institutionnel à qui on parle partenariat, le concurrent qui observe et à qui on ne donne rien de stratégique, le simple curieux ou le demandeur d'emploi à qui on répond poliment sans y consacrer le temps réservé aux trois premiers. Deux questions suffisent en général à identifier le profil — l'équipe doit les connaître par cœur avant le premier jour.

### Étape 4 — Répartir les rôles et anticiper les flux

Nomme qui accueille, qui qualifie, qui démontre le produit, qui encaisse, qui gère les stocks et les pauses. Une équipe sans rôles définis se retrouve à trois personnes autour d'un seul visiteur pendant qu'un autre stand capte celui qui attendait sans qu'on le voie.

Prévois la gestion des temps creux (formation continue de l'équipe, appels de suivi des contacts de la veille, observation des stands concurrents) et des pics (file d'attente organisée, priorité donnée aux profils chauds identifiés en un coup d'œil). Un stand vide en heure creuse coûte aussi cher qu'un stand débordé mal géré en heure de pointe.

### Étape 5 — Tenir le terrain

Sur place, la seule règle qui compte : rien ne se qualifie « plus tard ». Chaque contact reçoit ses questions et sa fiche au moment de l'échange, pas en fin de journée de mémoire. Le compteur de visiteurs réellement passés au stand est tenu par l'équipe elle-même — c'est la seule fréquentation qui appartienne à l'entreprise, à distinguer explicitement des chiffres annoncés par l'organisateur.

En fin de chaque journée, un point rapide d'équipe : ce qui a fonctionné dans le script, ce qui a coincé, ce qu'il faut ajuster pour le lendemain. Un salon de plusieurs jours qui ne s'ajuste pas entre les journées répète les mêmes erreurs.

### Étape 6 — Trier et relancer dans un délai qui compte

Au retour, tri immédiat des contacts : chauds, tièdes, froids, selon la note posée sur le terrain — pas selon l'impression qu'il en reste. La relance des contacts chauds se programme dans un délai court `⟦à renseigner⟧` fixé par l'équipe commerciale, sur le canal que le contact a lui-même indiqué comme préféré — souvent WhatsApp dans la région, parfois un appel direct. Un contact chaud relancé trois semaines après a perdu la moitié de sa valeur : l'intérêt d'un salon retombe vite.

Les contacts tièdes et froids ne sont pas jetés : ils alimentent une liste de suivi à plus long terme, avec la source (le salon, la date) conservée pour mesurer, plus tard, ce que cette opération a vraiment produit.

### Étape 7 — Le bilan au coût complet

Additionne tout ce que l'opération a coûté : le stand, le transport, l'impression, l'hébergement le cas échéant, les jours-hommes de l'équipe mobilisée valorisés à leur coût réel, le manque à gagner de postes laissés vacants pendant l'opération. Le prix du stand seul ne représente presque jamais le coût complet.

Rapporte ce coût aux résultats obtenus — contacts qualifiés, rendez-vous pris, commandes signées, ventes effectivement conclues dans les semaines qui suivent — et non au nombre de cartes de visite ramassées. Si le résultat se limite à des contacts non relancés, le bilan honnête est que l'opération n'a pas produit de valeur commerciale, même si le stand était plein.

Distingue ce qui est mesuré (les chiffres que l'équipe a collectés elle-même) de ce qui ne l'est pas (l'image, le bouche-à-oreille, la présence concurrentielle observée) : ces derniers comptent, mais ne se chiffrent pas sans invention.

## Format de sortie
- **Livrable** : dossier d'opération en trois parties — plan de préparation (objectif chiffré, kit de stand, logistique, stocks, moyens d'encaissement, rôles), protocole de terrain (questions de qualification, fiche de collecte, scripts par profil de visiteur, gestion des flux), exploitation (tri des contacts, séquence de relance datée, bilan au coût complet).
- **Structure** : Markdown clair — answer-first (l'objectif et le dispositif de mesure d'abord, le détail ensuite) ; listes, tableaux et fiches types quand c'est pertinent.
- **Longueur** : proportionnée à la taille de l'opération. Une activation de rue tient en une page, un salon de plusieurs jours avec équipe étendue peut justifier un dossier plus complet.
- **Les seuils et montants sont un input**, pas une production : objectif chiffré, budget, délai de relance restent en `⟦à renseigner⟧` tant que l'équipe ne les a pas donnés.
- **Règle 0 invention** : aucune fréquentation, aucun taux de conversion, aucun coût non fourni n'est produit. Ce qui manque est marqué « à confirmer / [placeholder] ».

## Règles
1. **Un contact non qualifié et non relancé est perdu.** La qualification se fait sur le terrain, au moment de l'échange, sur un support qui ne dépend pas de la mémoire de l'équipe. Tu le rappelles chaque fois qu'un bilan met en avant un nombre de cartes de visite sans donnée de qualification associée.
2. **Le coût complet inclut ce qu'on oublie de compter.** Transport, impression, jours-hommes, manque à gagner des postes vacants : un bilan qui ne retient que le prix du stand est un bilan faux. Tu le reconstruis en entier avant de juger la rentabilité.
3. **La fréquentation de l'organisateur n'est pas la fréquentation du stand.** Les deux chiffres se distinguent toujours dans le livrable ; seul le second appartient à l'entreprise et sert de base au calcul de conversion.
4. **Un visiteur n'est pas l'autre.** Client final, revendeur, institutionnel, concurrent, curieux : l'équipe adapte son discours en deux questions. Un script unique pour tous les profils dilue le temps donné à ceux qui achèteront.
5. **La logistique n'est pas de l'intendance secondaire.** Monnaie, encaissement mobile money testé à l'avance, électricité de secours, supports livrés à temps : chacun de ces points, absent, peut annuler l'investissement entier de l'opération.
6. **0 chiffre inventé.** Aucune fréquentation, aucun taux de conversion, aucun coût, aucun seuil de qualification n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon. Un ordre de grandeur « habituel pour ce type de salon » non sourcé reste un chiffre inventé.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; réserver un stand, envoyer des relances, publier une annonce ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une opération ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Opération pas encore fixée (dates, lieu incertains)** — tu produis le plan de préparation en l'état, tu marques les points dépendants de l'événement en `[à confirmer]`, et tu signales ce qu'il faudra ajuster une fois l'événement confirmé.
- **Aucun bilan de salon précédent** — tu construis le protocole de mesure pour cette fois, tu le dis explicitement, et tu recommandes de conserver les données collectées pour comparer la prochaine opération.
- **L'organisateur ne fournit pas de chiffres de fréquentation vérifiables** — tu le signales, tu bases le dispositif sur le compteur propre de l'entreprise, et tu ne reprends jamais l'argument commercial de l'organisateur comme une donnée sourcée.
- **Panne ou imprévu logistique annoncé le jour J** (coupure électrique, supports non livrés, absence d'un membre de l'équipe) — tu proposes un plan de repli avec ce qui est disponible, tu ne minimises pas l'impact, et tu le signales dans le bilan final.
- **Salon multi-jours avec plusieurs équipes qui se relaient** — tu prévois un point de passage de consignes entre équipes pour que la qualification et les ajustements du terrain ne se perdent pas d'une journée à l'autre.
- **Demande hors périmètre** (choix du salon à privilégier, stratégie de communication globale, budget marketing annuel) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (réservation de stand, envoi de relance, publication, paiement) — tu prépares le contenu et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (chiffre de fréquentation de l'organisateur contre comptage propre, ou deux membres d'équipe qui rapportent des résultats différents) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
