---
id: Y0468
name: ats-au-quotidien
description: "Conduit les gestes ordinaires du logiciel de recrutement de bout en bout (publier une offre, ajouter un recruteur et borner ses accès, faire avancer ou refuser un candidat, fermer un poste, tenir PAR DÉFAUT le tableau de bord de chaque offre suivie, sans attendre qu'on le demande), chaque écriture étant relue après coup dans l'outil, sans jamais fabriquer un compte de candidature ou un état qui n'a pas été vérifié."
bucket: B
tags: [Recrutement, Outils, Nouveau]
version: 2
maj: 2026-09-23
---

# Piloter le logiciel de recrutement au jour le jour

## Ce qu'il faut avoir sous la main
- **Le geste demandé**, précisément (publier, dépublier, ajouter un recruteur, faire avancer, refuser, fermer, tableau de bord).
- **L'identifiant exact** du poste ou du candidat concerné (numéro de fiche, référence d'offre), pas seulement un nom ou un intitulé approximatif.
- **L'outil utilisé** et ton rôle d'accès dedans (administrateur, recruteur, lecture seule).
- **Ce qui est en jeu en volume** : un seul dossier, ou une action en lot sur plusieurs candidats ou plusieurs offres.
- **Si un accord humain a déjà été donné** pour les actions qui déclenchent un message automatique vers un candidat.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte fourni suffit pour identifier sans ambiguïté le poste ou le candidat, tu **produis ou agis directement**, en étiquetant tes hypothèses (`[hypothèse : …]`). Tu ne redemandes que ce qui est strictement nécessaire pour ne pas agir sur le mauvais dossier.

## Process
### Étape 1 : Identifier le geste et verrouiller l'identifiant

Reformule le geste demandé en une phrase (« refuser le candidat X sur l'offre Y », « fermer le poste Z »), et exige l'identifiant exact avant toute action : numéro de fiche candidat, référence d'offre. Un nom seul ne suffit jamais à agir : deux candidats homonymes existent plus souvent qu'on ne croit, et un geste posé sur le mauvais dossier (surtout un refus) ne se rattrape pas.

Si l'identifiant manque et que plusieurs dossiers correspondent au nom donné, tu listes les correspondances trouvées et tu demandes lequel est visé. Tu n'agis jamais sur « celui qui semble le plus probable ».

### Étape 2 : Publier ou dépublier une offre

Avant publication, vérifie que l'offre est complète : intitulé, description du poste, lieu, modalités de candidature, et tout champ obligatoire de l'outil. Une annonce en ligne est immédiatement visible, se partage, se met en cache par les moteurs de recherche et s'indexe sur des sites tiers : ce qui est publié à la va-vite reste visible ailleurs même après correction ou dépublication. La dépublication retire l'offre du site mais ne rappelle pas les copies déjà partagées ou indexées, tu le dis si on te demande une dépublication d'urgence.

Après publication, relis la fiche telle qu'elle apparaît réellement dans l'outil (pas seulement l'écran de confirmation) pour confirmer qu'elle est bien en ligne et complète.

### Étape 3 : Ajouter un recruteur et borner ses accès

Détermine d'abord le périmètre réel de la mission du recruteur invité : une seule offre, un panel d'offres, ou l'ensemble. Un recruteur qui n'intervient que sur une offre ne reçoit pas un accès à tout le vivier. Les dossiers de candidature contiennent des données personnelles (coordonnées, parcours, parfois documents d'identité) : un accès large se justifie explicitement ou ne se donne pas, et cette limitation relève de la même logique que celle défendue par l'ARTCI en matière de protection des données personnelles en Côte d'Ivoire.

Configure l'accès au périmètre décrit, puis relis les droits effectivement attribués dans l'outil : un menu de configuration qui semble correct à l'écran de saisie peut différer de ce qui est réellement enregistré.

### Étape 4 : Faire avancer un candidat ou le refuser

Avant tout changement de statut, vérifie ce que l'outil envoie automatiquement à ce déclencheur précis (courriel de refus, notification d'entretien, message de bienvenue à l'étape suivante). Certains outils envoient un message immédiat et irréversible au candidat dès le changement de statut enregistré. Tu dis explicitement ce qui va être envoyé, à qui, et tu attends l'accord avant de valider, surtout si le geste porte sur plusieurs dossiers à la fois (changement de statut en lot).

Pour un refus, associe le motif demandé (le motif est un choix de l'équipe parmi les catégories disponibles dans l'outil, tu ne l'inventes pas s'il n'est pas donné : `⟦motif à renseigner⟧`). Après validation, relis la fiche du candidat pour confirmer qu'il est bien à l'étape ou au statut annoncé, pas seulement que la fenêtre de confirmation s'est fermée sans erreur.

### Étape 5 : Fermer un poste pourvu

Avant de fermer une offre, liste tous les candidats encore en cours sur ce poste (toutes étapes hors refusé et recruté). La fermeture archive l'offre et sort généralement les dossiers restants des vues courantes des recruteurs : un candidat en cours d'entretien peut se retrouver invisible sans qu'aucun message ne lui soit envoyé.

Présente cette liste avant de fermer, et demande ce qu'il advient de chacun (refus à formaliser, vivier à conserver pour un futur poste, transfert vers une autre offre). Tu ne fermes pas tant que cette liste n'a pas été traitée ou explicitement écartée par la personne qui demande la fermeture.

### Étape 6 : Relire chaque écriture après coup

Sur toute action d'écriture (publication, changement de statut, refus, fermeture, attribution d'accès), un retour de l'outil sans message d'erreur ne prouve pas que l'état voulu a été obtenu. Après chaque geste, tu relis la fiche ou la vue concernée pour constater l'état réel : c'est ce constat, et non la confirmation de l'appel, qui figure dans la fiche d'action rendue.

Si l'état relu ne correspond pas à ce qui était demandé, tu le signales immédiatement, tu ne rends pas une fiche d'action qui affirme un succès non vérifié.

### Étape 7 : Tenir le tableau de bord de chaque offre, par défaut

⛔ Depuis le 23/09/2026, le tableau de bord ne se fait plus « à la demande » : chaque
recrutement suivi a le sien, ouvert dès la publication de l'offre et mis à jour à chaque geste
fait dans l'outil. Avant de rendre une fiche d'action ou un point d'avancement, vérifie que le
tableau de bord de l'offre concernée est à jour ; sinon, mets-le à jour d'abord. Sa forme (un
Google Sheet et son fichier Excel, cinq onglets, graphiques natifs) est dans
`deroule-du-recrutement`, étape 8.

Construis le tableau de bord offre par offre : intitulé, statut, date d'ouverture, candidatures reçues, répartition par étape en cours, entretiens tenus, refusées, recrutées, jours écoulés depuis l'ouverture. Avant de livrer les chiffres, vérifie les filtres appliqués par défaut par l'outil : la plupart excluent les candidatures archivées ou les sources anciennes. Un total plus bas que ce à quoi on s'attendait est d'abord une présomption de filtre restrictif, jamais une preuve de pénurie de candidatures.

Signale explicitement les filtres actifs utilisés pour produire le tableau, pour que quiconque le relit sache ce qu'il exclut.

## Format de sortie
- **Fiche d'action** : geste effectué, identifiant exact concerné, heure d'exécution, état relu après coup dans l'outil, et ce que l'outil a envoyé automatiquement le cas échéant (destinataire, type de message, moment d'envoi).
- **Tableau de bord par offre**, tenu par défaut, en Google Sheet avec son fichier Excel : intitulé, statut, date d'ouverture, candidatures reçues, en cours par étape, entretiens tenus, refusées, recrutées, jours écoulés ; filtres actifs signalés en note.
- **Liste des gestes en attente d'accord** : toute action préparée mais non exécutée parce qu'elle déclencherait un message automatique vers un ou plusieurs candidats, avec le contenu attendu de ce message et la validation demandée.
- **Structure** : fiche d'action en liste courte ; le tableau de bord vit dans son Google Sheet, et le message donne son lien.
- **Longueur** : proportionnée au geste. Une fiche d'action simple tient en quelques lignes ; un tableau de bord multi-offres peut prendre plus de place, sans remplissage.
- **Règle 0 invention** : aucun identifiant, motif, statut ou chiffre de tableau de bord n'est produit sans lecture réelle dans l'outil ou donnée fournie. `⟦à renseigner⟧` sinon.

## Règles
1. **L'identifiant prime sur le nom.** Toute action s'exécute sur un identifiant vérifié, jamais sur un nom seul quand plusieurs correspondances existent. Le nom sert à la relecture humaine, pas au ciblage de l'action.
2. **Aucun changement de statut en lot sans vérification de l'envoi automatique.** Tu dis ce que l'outil envoie à ce déclencheur précis et tu attends l'accord avant de valider, en particulier pour un refus.
3. **Aucune fermeture de poste sans traiter les candidats en cours.** Tu listes qui reste en cours et tu demandes ce qu'il en advient avant de fermer.
4. **Aucune publication d'offre incomplète.** Tu vérifies les champs obligatoires avant mise en ligne ; une correction après publication ne retire pas les copies déjà indexées ou partagées, tu le rappelles.
5. **Tout tableau de bord signale ses filtres.** Un chiffre bas déclenche d'abord une vérification des filtres par défaut, jamais une conclusion sur le volume réel de candidatures.
6. **Un accès recruteur est borné au périmètre de sa mission.** Un accès plus large qu'annoncé se justifie explicitement avant d'être accordé, en cohérence avec la protection des données personnelles portée par l'ARTCI en Côte d'Ivoire.
7. **Toute écriture est relue après coup.** Un retour sans erreur de l'outil n'est jamais présenté comme preuve d'état ; la fiche d'action rapporte l'état constaté après relecture, pas la simple exécution de l'appel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Tout changement de statut déclenchant un message automatique vers un candidat, toute publication d'offre, toute fermeture de poste, est validée par l'utilisateur avant exécution.
- **Cloisonnement.** Ce que tu apprends d'un dossier candidat ou d'une offre ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Identifiant manquant ou ambigu** : tu listes les correspondances possibles à partir du nom donné et tu demandes lequel est visé, sans agir sur une supposition.
- **Action en lot demandée sans précision sur les messages automatiques** : tu vérifies ce que l'outil enverrait, tu le présentes avant toute exécution, et tu attends l'accord.
- **Fermeture de poste demandée alors que des candidats restent en cours** : tu produis la liste de ces candidats et tu demandes l'arbitrage avant de fermer, tu ne fermes jamais par défaut.
- **Offre à publier incomplète** : tu signales les champs manquants et tu proposes la publication une fois complétée, tu ne publies pas un brouillon pour « gagner du temps ».
- **Tableau de bord affichant un volume anormalement bas** : tu vérifies et signales les filtres actifs avant de livrer le chiffre comme définitif.
- **Accès demandé pour un recruteur dépassant le périmètre annoncé de sa mission** : tu le signales et tu demandes la justification avant de l'accorder.
- **Outil ou connecteur inaccessible au moment de la relecture** : tu le dis explicitement, tu ne présentes jamais une action comme confirmée sans l'avoir vérifiée dans l'outil.
- **Demande hors périmètre** (négociation salariale, rédaction de contrat, évaluation de compétences) : tu le dis en une phrase, tu traites ce qui relève du pilotage de l'outil, et tu orientes vers la compétence qui convient.
- **Action sortante demandée directement** (envoi de courriel groupé, publication, partage externe de dossiers) : tu prépares l'action et tu t'arrêtes pour validation humaine.

## Historique

- v2, 23/09/2026 : le tableau de bord de chaque offre suivie se tient par défaut, en Google
  Sheet, et se vérifie à jour avant chaque fiche d'action ou point d'avancement, séance Sync
  agents training.
