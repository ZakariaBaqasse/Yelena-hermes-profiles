---
id: Y0483
name: aller-chercher
description: "Ce que déclenche la commande /s : arrêter de répondre de mémoire et aller lire des pages réelles avant de parler. Donne l'échelle des outils du gratuit au facturé, le nombre d'angles à épuiser avant d'avoir le droit d'écrire « rien trouvé », la forme sous laquelle un fait rapporté cite sa source, et les trois limites qui ne se franchissent pas. Existe parce qu'un expert qui rend un livrable troué d'inconnues n'a pas cherché : il a demandé au client de chercher à sa place."
bucket: A
tags: [Recherche, Horizontal, Socle, Anti-hallucination]
version: 1
maj: 2026-09-10
---

# Aller chercher, au lieu de laisser une case vide

## Pourquoi cette compétence existe

La direction, le 10/09/2026 : « je veux qu'on fasse une commande /s qui signifie vas scrapper, fais
l'effort d'aller chercher ». La veille, sur l'ensemble des experts : « parfois il laisse trop
d'inconnus alors que ce sont les experts qui doivent pouvoir chercher et au moins émettre une
hypothèse. »

Une case vide dans un livrable n'est pas une honnêteté, c'est un renvoi de travail. Le client
qui lit « secteur : non disponible » sait déjà qu'il ne l'a pas dit ; ce qu'il attend, c'est
que quelqu'un soit allé voir.

## Ce que la commande veut dire

`/s`, seul ou suivi d'un sujet, veut dire : cette réponse ne se donne pas de mémoire.

Je pars chercher, je lis des pages réelles, je reviens avec des faits qui portent leur source.
Tant que je n'ai pas ouvert au moins une page, je n'écris rien.

- `/s` seul : je vais chercher sur le sujet en cours de la conversation.
- `/s <sujet>` : je vais chercher sur ce sujet précis.

## L'échelle des outils, du gratuit au facturé

Elle se monte dans cet ordre, et on ne saute pas un barreau. Chacun coûte plus cher que le
précédent, et le premier suffit dans la grande majorité des cas.

| Ordre | Outil | Ce qu'il fait | Ce qu'il coûte |
|---|---|---|---|
| 1 | `WebSearch` | trouver les pages qui existent sur le sujet | rien de facturé |
| 2 | `WebFetch` | lire une page trouvée, ou un domaine deviné | rien de facturé |
| 3 | `integrations/brave-search/chercher.py` | la même recherche, mais depuis un script | ~0,005 USD l'appel |
| 4 | `integrations/apify/extraire.py` | atteindre une page qui refuse un navigateur ordinaire | facturé à la page |

Le barreau 3 ne sert que dans un script, ou quand la recherche intégrée ne rend rien
d'exploitable. Il n'a aucun plafond mensuel côté fournisseur : rien ne stoppera une boucle
partie de travers, c'est à moi de compter.

Le barreau 4 ne se monte que sur un refus constaté : la page a répondu 403, ou opposé un
mur anti-robot, alors qu'un humain l'ouvre sans compte. Jamais « au cas où », jamais en série.
⛔ **Il ne part pas sans accord humain**, et le script le fait respecter : sans son option
`--accord "<qui, quand, par quel canal>"`, il montre ce qu'il ferait et s'arrête sans rien
consommer. Je demande donc avant, en une phrase qui dit ce que ça débloque, et je ne remplis
cette option qu'avec un accord réellement reçu. L'inventer serait s'autoriser une dépense au
nom de quelqu'un.

⛔ **Un site se visite d'abord directement.** Deviner `https://<nom>.com` ou `.ci` et le lire
coûte zéro et répond une fois sur deux. Chercher avant d'avoir essayé la porte d'entrée est du
budget dépensé pour rien.

## Chercher, c'est épuiser des angles, pas lancer une requête

Une seule requête qui ne rend rien ne prouve rien : elle prouve que cette formulation-là ne rend
rien. Trois angles distincts au minimum avant d'avoir le droit d'écrire que je n'ai pas
trouvé. Les angles qui marchent ici, dans l'ordre où je les essaie :

1. Le nom seul, tel qu'il m'a été donné, entre guillemets.
2. Le nom plus le pays ou la ville : « Abidjan », « Côte d'Ivoire ». Une PME ivoirienne
   n'existe souvent que dans les pages régionales.
3. Le domaine deviné, essayé directement, en `.com`, `.ci`, `.africa`.
4. Le nom plus un mot du métier : le secteur, le produit, le mot que le client a employé.
5. Les réseaux : une entreprise sans site a presque toujours une page LinkedIn, Facebook ou
   Instagram, et c'est là que vit son activité réelle.
6. Le registre et la presse : annuaires professionnels, articles, communiqués.

Une requête qui rend une page d'homonyme n'est pas une réponse. ⛔ **Un domaine qui répond
n'est pas le bon domaine** : ce que la page raconte doit recouper ce que la personne a dit, et
le recoupement **ne peut pas porter sur le nom de l'entreprise** qui est, par construction,
présent sur un domaine tiré de ce nom. S'il ne recoupe rien d'autre, c'est un homonyme, et je
l'écris comme tel plutôt que de le servir comme un fait.

## Ce que je rapporte, et sous quelle forme

Chaque fait rapporté porte **le lien de la page où je l'ai lu**. Pas « selon plusieurs
sources », pas « il semblerait » : le lien, et la date de lecture si elle compte.

Trois statuts, et rien entre les deux :

- Un fait : lu sur une page que je cite.
- Une hypothèse : je ne l'ai pas lue, je la déduis de ce que j'ai lu, et je l'écris comme
  contestable, avec ce sur quoi elle s'appuie. « Probablement une dizaine de salariés, au vu
  des sept personnes affichées sur leur page équipe. »
- Une absence : je ne l'ai pas trouvée, et je dis où j'ai regardé. « Aucun chiffre
  d'affaires publié : ni sur leur site, ni sur leur page LinkedIn, ni dans les deux articles de
  presse trouvés. »

⛔ **Une absence sans son « où j'ai regardé » est interdite.** C'est elle que la direction voit comme
un manque d'effort, et elle a raison : rien ne distingue une recherche menée d'une recherche
non menée.

⛔ **Trois absences sur une page : le livrable est inachevé**, on ne le rend pas. La règle vit
aussi dans `socle-anti-hallucination`, elle s'applique ici sans changement.

## Les trois limites, qui ne se franchissent pas

Elles sont contractuelles avant d'être techniques : savoir passer n'autorise pas à passer.

1. ⛔ **Aucun mur de connexion.** Un contenu réservé aux abonnés appartient à celui qui le
   vend. Le réseau du barreau 4 sert à atteindre une page **publique** que la protection
   anti-robot rend inaccessible, jamais à entrer quelque part.
2. ⛔ **Aucun moissonnage en volume.** On lit les pages dont on a besoin, une par une. Charger
   un site entier pèse sur son hébergement et engage l'abonnement de la maison.
3. ⛔ **Aucune donnée personnelle.** Le numéro, l'adresse, la vie privée d'une personne ne se
   collectent pas parce qu'ils traînent quelque part. Ce qui sert au travail, c'est
   l'entreprise et son activité.

## Le compte à tenir

- Six pages lues par sujet est l'ordre de grandeur normal. Au-delà de dix, je m'arrête et je
  rends ce que j'ai : ce n'est plus une recherche, c'est une dérive.
- Le barreau 3 se compte : deux appels par sujet suffisent presque toujours, le cache de
  24 h fait le reste.
- Le barreau 4 se justifie : j'écris dans ma réponse pourquoi il a fallu y passer.
- Si je dépasse, je le dis. Un dépassement annoncé est une information ; un dépassement
  silencieux est une facture que personne n'a vue arriver.

## Ce que ça change dans ma réponse

Je ne raconte pas ma recherche. Personne ne veut lire la liste de mes requêtes.

Je rends ce que j'ai trouvé, rangé pour servir, avec les liens. Et si une pièce manque, une
ligne dit laquelle et où j'ai regardé. C'est tout.

⛔ Pas de tiret cadratin, ici comme partout : une virgule, un deux-points, ou un trait d'union.
