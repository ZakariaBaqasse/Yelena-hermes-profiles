---
id: Y0672
name: socle-ecrire-un-email
description: >
  Écrire un courriel professionnel qui obtient ce qu'il demande : un objet qui dit l'action,
  l'essentiel dans la première phrase, une seule demande, datée et nommée, et une formule de
  politesse juste pour le rapport qu'on a avec la personne. À charger avant de rédiger ou de
  faire relire n'importe quel courriel, y compris un brouillon de trois lignes. Les cas
  délicats (retard, refus, relance, erreur à corriger) ont leur gabarit en référence.
version: 1
maj: 2026-09-17
---

# Écrire un courriel

> **Demandé par Yelema, 17/09/2026 :** *« Il manque aussi une grosse compétence qui
> est comment écrire des e-mails. »*

Un courriel professionnel n'est pas un texte, c'est une demande avec une enveloppe. Il réussit
quand le destinataire sait, en trois secondes sur un téléphone, ce qu'on attend de lui et pour
quand. Tout le reste est du décor, et le décor est ce qui fait qu'on répond « je reviens vers
vous » sans jamais revenir.

**Quand la charger** : avant de rédiger un courriel, avant d'en relire un, avant de proposer un
brouillon à quelqu'un de la maison.

**Quand ne pas la charger** : les courriels d'un cycle métier ont leur compétence, qui porte
les gabarits et la voix de ce cycle. Recrutement : `emails-recrutement`. Relance sur un fil
existant : `follow-up-emailer`. Prospection : `02-message-crafter`. Tri d'une boîte et
brouillons de réponse : `inbox-manager`. Celle-ci tient le métier d'écrire, elles tiennent le
cas d'usage ; elles se chargent ensemble.

**Ce qu'elle ne tient pas** : la langue (`socle-francais-professionnel`), le ton
(`socle-ton-de-collegue`), les fautes (`socle-relecture-orthographe`), les tics de machine
(`socle-relecture-anti-tics`). Un courriel passe par les quatre avant de partir.

⛔ **L'envoi reste un acte humain.** On rédige, on propose, on ne poste jamais. Règle de la
maison, sans exception : ni pour un accusé de réception, ni pour un destinataire interne.

**Les formules, le protocole et les huit cas délicats** vivent dans
`references/protocole-et-cas-delicats.md`.

## Ce qu'il faut avoir sous la main

1. **Qui lit**, nommément, et son rapport avec nous : client, prospect, fournisseur,
   administration, collègue. Le rang compte en Afrique de l'Ouest francophone comme ailleurs :
   un directeur général se salue par son titre.
2. **L'action attendue** : répondre, valider, payer, signer, venir, transmettre. Si on ne sait
   pas la nommer, on n'écrit pas encore le courriel.
3. **La date à laquelle on en a besoin**, et ce que le retard bloque.
4. **Le fil, s'il existe.** Un courriel qui rouvre un sujet sans rappeler où on en était
   oblige le lecteur à chercher, et il cherchera plus tard.
5. **Le registre du client** (vouvoiement, « nous » ou « on », signature, langue). Il vit dans
   la mémoire du poste. Pas de registre connu : vouvoiement, « nous », et on le signale.

## Le geste, en sept temps

**1 · Nommer la demande avant d'écrire.** Une phrase, pour soi : *« je veux qu'il valide le
devis avant vendredi »*. Elle ne figurera pas telle quelle, elle commande tout le reste.

**2 · L'objet dit le sujet ET l'action.** Six à neuf mots. Il doit se lire entier dans une
liste sur téléphone, où l'on voit rarement plus de quarante signes.
> *Objet : Point*   → *Objet : Devis maintenance, validation avant le 24/09*
> *Objet : Information importante* → *Objet : Coupure de service le 22/09, 8h à 11h*

**3 · La première phrase porte la conclusion.** Pas le contexte, pas les salutations d'usage
étendues, pas l'historique. Le contexte vient après, pour qui en a besoin.
> *Suite à notre échange de la semaine dernière et après avoir consulté l'équipe technique,
> nous avons le plaisir de vous informer que…*
> **→** *Le devis est prêt, 1 250 000 FCFA sur douze mois. Il tient jusqu'au 24/09.*

**4 · Une seule demande.** Deux demandes dans un courriel, c'est une réponse sur deux. S'il en
faut plusieurs, elles sont numérotées, chacune avec son responsable et sa date, et on accepte
qu'elles reviennent séparément.

**5 · La demande est datée et attribuée.** « Dès que possible » ne se traite jamais. « Merci de
me confirmer avant jeudi 18h » se traite.

**6 · Ce qui tient sur un écran.** Au-delà, le détail part en pièce jointe ou dans un document
partagé, et le courriel dit ce qu'on y trouve. ⚠ Une pièce jointe se relit avant d'être
attachée, et s'annonce dans le texte : une pièce non annoncée ne s'ouvre pas.

**7 · La clôture dit la suite.** Pas « restant à votre disposition », qui ne dit rien. *« Je
vous rappelle jeudi si je n'ai rien reçu »*, ou *« l'équipe démarre lundi une fois votre accord
reçu »*.

## Les copies, et ce qu'elles veulent dire

- **En destinataire** : on attend quelque chose de cette personne.
- **En copie** : on l'informe, on n'attend rien d'elle. Mettre quelqu'un en copie pour faire
  pression est lisible par tout le monde, y compris par celui qu'on vise.
- **En copie cachée** : jamais entre personnes qui se connaissent. Le seul usage propre est
  l'envoi à une liste dont les adresses ne doivent pas circuler.
- ⛔ **« Répondre à tous » est un geste délibéré**, jamais un réflexe. On vérifie la liste avant,
  pas après.

## Ce qui ne part jamais

- Un chiffre, une date ou un prix qui n'a pas été rouvert à la source au moment d'écrire
  (`socle-anti-hallucination`). Dans un courriel, un chiffre faux devient un engagement.
- Une pièce jointe non ouverte et non relue, ou annoncée et absente.
- Un courriel écrit sous le coup de l'agacement. Il s'écrit, il ne s'envoie pas le même jour.
- Un mot de passe, une clé, un jeton, un identifiant. Jamais, quel que soit le destinataire.
- Un engagement de délai qu'on n'a pas vérifié auprès de qui fera le travail.

## Les pièges de ce travail

- ⛔ **Écrire long pour montrer le travail fourni.** La longueur d'un courriel ne prouve rien,
  elle retarde la réponse.
- ⛔ **La politesse qui remplace la clarté.** « Je me permets de revenir vers vous afin de
  savoir si vous auriez eu l'occasion de » veut dire « avez-vous répondu ». Dire les deux, dans
  cet ordre : la demande, puis la formule.
- ⛔ **Le courriel qui aurait dû être un appel.** Un désaccord, une mauvaise nouvelle
  personnelle ou une négociation ne se règlent pas à l'écrit. On propose un appel, et on écrit
  ensuite ce qui a été dit.
- ⛔ **Confondre relance et rappel.** Une relance qui ne dit pas ce que le retard bloque n'est
  qu'un rappel, et un rappel s'ignore sans coût (`relance-interne`).
- ⛔ **Recopier un gabarit sans changer ce qui compte.** Un modèle donne la charpente, pas les
  faits. Un courriel qui sent le modèle obtient une réponse qui sent le modèle.
