# Protocole, formules, et les huit cas délicats

⚠ Rien ici ne se recopie tel quel. Un gabarit donne la charpente et l'ordre des idées ; les
faits, les noms et les dates viennent du dossier.

## 1 · L'appel, selon qui lit

| À qui | Comment on ouvre |
|---|---|
| Quelqu'un qu'on ne connaît pas | `Madame,` ou `Monsieur,` seul sur sa ligne |
| Sans savoir qui lira | `Madame, Monsieur,` |
| Un dirigeant, une autorité | `Monsieur le Directeur Général,` `Madame la Ministre,` `Monsieur le Préfet,` (le titre en entier, jamais abrégé) |
| Un contact professionnel établi | `Bonjour Madame Koné,` puis `Bonjour Awa,` quand la relation le permet |
| Un collègue | `Bonjour Awa,` ou le prénom seul |
| Plusieurs personnes | `Bonjour à tous,` ou les prénoms cités, les décideurs d'abord |

⚠ **Le passage au prénom se suit, il ne se décide pas.** On adopte l'usage que l'autre a
installé dans le fil. Passer au prénom le premier avec une administration ou un grand compte
se lit comme de la familiarité.

## 2 · La clôture, selon le rapport

| Rapport | Formule | Quand |
|---|---|---|
| Courant, professionnel | `Cordialement,` | le cas par défaut, partout |
| Cordial, relation établie | `Bien à vous,` `Bien cordialement,` | client ou partenaire suivi |
| Collègue | `Merci,` `À jeudi,` `Bonne journée,` | interne, fil vivant |
| Formel, première fois | `Je vous prie d'agréer, Madame, mes salutations distinguées.` | courrier d'ouverture, candidature |
| Autorité, courrier officiel | `Je vous prie d'agréer, Monsieur le Ministre, l'expression de ma très haute considération.` | institutionnel uniquement |

⚠ **La formule longue reprend l'appel à l'identique.** Si on a ouvert par `Monsieur le
Directeur Général,`, on ferme par `Monsieur le Directeur Général,` et non par `Monsieur`.
⛔ Pas de formule longue dans un fil déjà engagé : elle rouvre une distance qu'on avait fermée.

## 3 · La signature

Prénom Nom, fonction, organisation, un numéro de téléphone joignable. Pas de citation, pas de
mention écologique, pas d'avertissement juridique automatique de dix lignes : personne ne les
lit et ils allongent chaque réponse du fil.

## 4 · Les huit cas délicats

### Annoncer un retard
L'ordre qui marche : le fait, la nouvelle date, la raison en une ligne, ce qu'on fait pour
limiter la casse. ⛔ Jamais la raison avant le fait : le lecteur croit qu'on prépare une excuse.
> *Le rapport sera prêt mercredi 24 et non lundi 22. La base comptable nous est arrivée
> incomplète vendredi. Nous livrons dès lundi la partie trésorerie, qui est celle dont vous
> avez besoin pour le comité.*

### Dire non
Le refus d'abord, la raison ensuite, une alternative si elle existe. Un refus enveloppé se lit
comme un oui hésitant, et revient.
> *Nous ne pouvons pas tenir le 30 septembre. Trois semaines sont nécessaires après réception
> des accès. Deux options : décaler au 14 octobre, ou réduire le périmètre à la partie A pour
> le 30.*

### Relancer
Une relance rappelle la demande, sa date, et ce que le retard bloque. Deux relances au
maximum, puis on change de canal ou on remonte (`relance-interne`).
> *Je reviens sur le devis envoyé le 10/09. Sans validation avant vendredi, le démarrage passe
> après les congés et la livraison bascule en novembre.*

### Corriger une erreur qu'on a faite
Le fait, la correction, ce qui a été mis en place pour que ça ne revienne pas. Pas d'excuses
répétées : une suffit, le reste s'entend comme du bruit.
> *Le tableau envoyé hier comportait une erreur de somme sur la colonne des charges, 2,4 M au
> lieu de 2,1 M. La version corrigée est jointe. Le contrôle de cohérence est désormais fait
> avant envoi.*

### Écrire à quelqu'un au-dessus de soi
Court, décidable, une seule demande. On donne la recommandation et non l'ensemble des options,
et l'on dit ce qui se passe sans réponse.
> *Deux prestataires répondent au cahier des charges. Je recommande le second, moins cher de
> 18 % et déjà référencé. Sans avis contraire de votre part avant jeudi, je lance avec lui.*

### Répondre à un mécontentement
On reconnaît le fait avant de l'expliquer. Aucune défense dans les trois premières lignes,
aucune contestation de ce que la personne a ressenti, et une action concrète datée.

### Écrire à une administration
Objet précis avec la référence du dossier, une demande unique, les pièces listées et numérotées,
la base réglementaire si elle existe, et la formule complète. Une copie du courrier reste au
dossier : dans une chaîne administrative, ce qui n'est pas écrit n'a pas eu lieu.

### Transmettre un dossier à un tiers
On dit ce qu'on transmet, pourquoi, ce qu'on attend et à quelle date, et on met en copie celui
qui suivait le dossier. ⛔ On ne transfère jamais un fil entier sans le relire : il contient
souvent des échanges internes que le tiers n'a pas à lire.

## 5 · Le contrôle, avant de proposer le brouillon

1. L'objet, seul, dit-il le sujet et l'action ?
2. La première phrase suffit-elle à comprendre ?
3. Y a-t-il **une** demande, avec une date et un responsable ?
4. Chaque chiffre a-t-il été rouvert à la source aujourd'hui ?
5. Les pièces jointes sont-elles annoncées, présentes et relues ?
6. La liste des destinataires et des copies est-elle juste ?
7. Le texte est-il passé par la langue, le ton, l'orthographe et les tics ?
