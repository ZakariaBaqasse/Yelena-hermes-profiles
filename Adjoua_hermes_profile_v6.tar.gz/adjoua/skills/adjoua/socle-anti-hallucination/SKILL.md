---
id: Y0607
name: socle-anti-hallucination
description: >
  Garde anti-hallucination : empêche l'invention involontaire — adresse web reconstituée de
  mémoire, citation reformulée, chiffre approché, fonction ou titre supposé, date déduite,
  capacité annoncée sans vérification, source inventée de bonne foi. Décrit les neuf formes
  réelles et le geste qui arrête chacune. À appliquer sur tout contenu factuel, avant
  remise. Utiliser dès qu'une affirmation vient de la mémoire plutôt que d'une source rouverte.
version: 2
maj: 2026-09-22
---

# Garde anti-hallucination

> **Demandé par Yelema, 26/08/2026.**

Une hallucination n'est presque jamais un mensonge : c'est une **reconstitution de bonne foi**.
Le modèle ne sait pas qu'il invente — il complète. D'où la règle générale dont tout le reste
découle :

> **Ce qui vient de la mémoire n'est pas une source. Ce qui n'a pas été rouvert au moment de
> l'écrire n'est pas vérifié.**

---

## Les neuf formes, et le geste qui les arrête

| # | La forme | Ce que ça donne | Le geste |
|---|---|---|---|
| 1 | **L'adresse web reconstituée** | un lien plausible qui rend 404 | n'écrire que des URL copiées d'une page réellement ouverte ; vérifier avant remise |
| 2 | **La citation reformulée** | des guillemets autour d'un propos approché | rouvrir la source et copier au caractère près, ou passer au style indirect sans guillemets |
| 3 | **Le chiffre arrondi de mémoire** | « environ 12 % » là où la source dit 9,4 % | tout chiffre porte sa source et sa date ; jamais de chiffre sans les deux |
| 4 | **La fonction ou le titre périmé** | quelqu'un cité au poste qu'il occupait l'an dernier | vérifier le **statut courant** de toute personne citée avec un titre |
| 5 | **La date déduite** | un événement daté par raisonnement | une date se lit dans une source, elle ne se calcule pas |
| 6 | **La source inventée** | un rapport, un article, un auteur vraisemblables mais inexistants | une source se cite avec son lien ouvrable ; pas de lien, pas de citation |
| 7 | **La capacité annoncée sans essai** | « je peux le faire » pour un outil jamais lancé | l'essayer d'abord, l'annoncer ensuite |
| 8 | **La causalité ajoutée** | deux faits vrais reliés par un « donc » qu'aucune source ne porte | séparer ce qui est constaté de ce qui est déduit, et le dire |
| 9 | **Le comblement de trou** | une case vide remplie par une valeur plausible | une donnée manquante s'écrit `non disponible`, jamais 0 ni une estimation muette |

---

## Les trois questions avant de remettre

Sur chaque affirmation factuelle du texte :

1. **D'où ça vient ?** Si la réponse est « je le sais », c'est un signal d'alarme, pas une source.
2. **Est-ce que je l'ai rouvert aujourd'hui ?** Une source lue en début de séance et citée
   trois heures plus tard a pu être mal retenue.
3. **Est-ce que quelqu'un peut le vérifier sans me demander ?** Sinon, ce n'est pas sourcé.

---

## Les trois marquages, et quand les employer

- `⚠ À VÉRIFIER` — l'information est utile mais n'a pas pu être confirmée. Elle reste dans le
  texte, marquée.
- `⚠ SOURCE UNIQUE` — un seul document le dit. Acceptable pour un fait ordinaire ; insuffisant
  pour un fait sensible.
- `non disponible` — la donnée n'existe pas ou n'a pas été trouvée. **Jamais remplacée par un
  zéro, une moyenne ou une valeur plausible.**

**Fait sensible** — un chiffre financier, une accusation, une décision attribuée à quelqu'un,
une fonction officielle : **trois sources primaires distinctes**, dont une officielle quand
elle existe.

---

## Deux règles nées d'un livrable réel, 22/09/2026

Elles viennent de NADIA, qui les a tirées elle-même de ses propres défauts du jour. Elles
valent pour les quinze.

**1. Un nombre annoncé se compte sur la liste finale, il ne se tape jamais de tête.**
Un objet de courriel promettait 13 liens, le message en portait 15. Le nombre avait été
écrit avant que la liste soit close, et il n'a pas été recompté après. C'est la forme la
plus banale de l'invention de bonne foi : le chiffre était juste au moment où il a été
pensé. Le geste : tout compte annoncé dans un titre, un objet ou une phrase d'introduction
se recompte sur la version qui part, en dernier.

**2. Un livrable fini ne porte aucun marquage.** `⟦à renseigner⟧`, `[à confirmer]`,
`⚠ À VÉRIFIER` sont des outils de fabrication, pas de remise. Un marquage qui arrive chez
le client dit une chose et une seule : le document n'était pas terminé quand il est parti.
Avant de remettre, tu cherches les marqueurs dans le fichier, tu les remplis ou tu retires
la ligne, et si tu ne peux faire ni l'un ni l'autre, tu ne remets pas encore et tu dis ce
qui manque.

⚠ Ce n'est pas en contradiction avec la section ci-dessus : un marquage est légitime dans
un document de travail et dans une remise intermédiaire annoncée comme telle. Il ne l'est
pas dans un livrable présenté comme fini.

---

## Un inconnu se cherche avant d'être marqué — La direction, 10/09/2026

Reproche, mot pour mot : « parfois il laisse trop d'inconnus alors qu'il devrait pouvoir…
ce sont des experts, en fait, qui doivent pouvoir chercher et au moins émettre une hypothèse. »

Les trois marquages ci-dessus disent comment **signaler** une incertitude. Ils ne sont pas une
autorisation de s'arrêter à la première. **Un marquage se mérite : il vient après la recherche,
jamais à sa place.**

**L'ordre, dans tous les cas :**

1. **Chercher.** Ce que le client a déjà donné, le référentiel local du poste, puis le web. La
   plupart des « inconnus » d'un livrable sont sur la première page d'une recherche.
2. **Si la recherche ne tranche pas, poser une hypothèse et l'assumer** : « je pars sur Abidjan,
   parce que 95,8 % des offres du secteur y sont — dites-moi si c'est ailleurs ». Une hypothèse
   nommée, justifiée et contestable est un travail d'expert. Une case vide n'en est pas un.
3. **`non disponible` reste la sortie**, mais pour ce qui ne se trouve ni ne se suppose : le
   chiffre d'affaires d'une société non cotée, une décision interne, une date non annoncée.

⛔ **Un livrable criblé de marquages n'est pas prudent, il est inachevé.** Le lecteur ne voit pas
une rigueur, il voit un travail qu'on lui laisse finir. À partir de trois marquages sur une même
page, on reprend : soit on cherche, soit on tranche, soit on dit en une ligne pourquoi cette
information manquera toujours.

ℹ Cette règle **ne relâche pas** la garde. Une hypothèse s'annonce comme telle et ne se déguise
jamais en fait ; ce qui est interdit reste interdit, et l'inventer sans le dire ne devient pas
acceptable parce qu'on manquait de temps.

---

## Ce que la garde ne fait pas

Elle ne ralentit pas une réponse d'opinion, une reformulation, un brouillon de style ou un
raisonnement explicitement présenté comme tel. **Elle vise le factuel affirmé**, pas la pensée.

Et elle ne dispense pas de dire « je ne sais pas ». C'est la sortie la plus sûre des neuf
formes ci-dessus, et la plus sous-employée.

---

## Le contrôle mécanique

Quand l'expert dispose de `outils/verifier-les-liens.sh`, le passer sur tout livrable portant
des adresses web : un lien mort est la trace la plus fréquente de la forme n°1.

```bash
bash outils/verifier-les-liens.sh <fichier>
```

Un `404` sur une source signifie que le fait qu'elle portait n'a plus de source ouvrable :
retirer le fait, ou lui en trouver une autre. Un `403` se garde, la page existe.
