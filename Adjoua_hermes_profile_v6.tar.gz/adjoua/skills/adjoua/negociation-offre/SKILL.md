---
id: Y0371
name: negociation-offre
description: "Prépare et conduit la dernière ligne droite du recrutement : ce qui motive réellement le candidat au-delà du salaire, l'argumentaire d'offre, les objections à anticiper, la marge de manœuvre et sa limite, le scénario de contre-offre de l'employeur actuel préparé en amont, le calendrier de relance pendant le délai de réflexion, et la sécurisation de la signature avant toute démission — sans jamais fabriquer un montant, un pourcentage ou une marge de négociation."
bucket: A
tags: [Recrutement, RH, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Négociation et closing — transformer un oui en signature

## Ce qu'il faut avoir sous la main
- **Le candidat et le poste** : qui, pour quel rôle, à quel niveau de séniorité.
- **Ce que tu sais de ses motivations** : ce qu'il a dit vouloir (évolution, stabilité, télétravail, proximité familiale, fuir un manager, revenu, statut) — même en vrac, même contradictoire.
- **La situation actuelle du candidat** : en poste ou non, préavis en cours, risque connu de contre-offre, présence d'un concurrent dans la boucle.
- **L'offre envisagée** : package proposé, ce qui est négociable selon toi, ce qui ne l'est absolument pas.
- **Le calendrier** : date de réponse attendue, date de démarrage souhaitée, contraintes de préavis.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier ce qui motive vraiment ce candidat

Avant de toucher au montant, reconstitue le classement réel de ses priorités : titre, périmètre de responsabilité, personne à qui il reporte, date de démarrage, possibilité de travailler à distance ou en horaires flexibles, prise en charge du transport ou de la scolarité des enfants, proximité géographique avec la famille, visibilité sur l'évolution de carrière. Un candidat qui a mentionné deux fois un manager toxique dans son poste actuel valorise souvent plus le nom de son futur reporting que 10% de salaire en plus — mais personne ne le lui a demandé directement.

Si l'entretien n'a pas fait remonter ces éléments, c'est le premier signal : on a mené un process centré sur les compétences et pas sur la personne, et la négociation qui arrive va tâtonner à l'aveugle.

### Étape 2 — Construire l'argumentaire dans l'ordre : leviers non-monétaires d'abord

**Le piège du métier** : croire que la négociation porte sur le salaire. Un montant qu'on augmente pour convaincre ne redescend jamais — ni pour ce candidat, ni comme précédent interne face à d'autres. À l'inverse, un titre plus précis, une date de démarrage décalée, une clause de télétravail, une prise en charge de transport ou de scolarité coûtent souvent moins cher à l'entreprise et pèsent davantage dans la décision du candidat.

Construis l'argumentaire d'offre en présentant d'abord ce qui répond aux motivations identifiées à l'étape 1, et seulement ensuite le package chiffré. Si le candidat n'a exprimé aucune priorité au-delà du salaire, dis-le — ce n'est pas à toi de lui en inventer une.

### Étape 3 — Objections, marge de manœuvre et sa limite

Liste les objections probables (montant jugé bas, titre jugé insuffisant, délai de démarrage trop court, doute sur l'équipe) et prépare une réponse pour chacune — pas un argument creux, un fait vérifiable ou un engagement que l'entreprise peut tenir.

Fixe la **marge de manœuvre réelle** : jusqu'où on peut monter, sur quel levier en priorité, et la **limite au-delà de laquelle on retire l'offre plutôt que de continuer à monter**. Cette limite est une décision de l'entreprise, pas un calcul que tu peux produire : elle reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée. Une négociation sans limite fixée à l'avance se termine toujours par une concession de trop, décidée sous pression en direct.

### Étape 4 — Anticiper la contre-offre AVANT qu'elle arrive

**Le piège le plus coûteux** : un candidat en poste accepte l'offre, démissionne, son employeur actuel réagit avec une contre-offre — augmentation, promesse de promotion, changement de manager — et le candidat, pris dans l'émotion du moment, hésite ou se retire. Ce scénario ne se traite pas quand il arrive, il se traite avant.

Si le candidat est en poste : pose directement la question de ce qu'il ferait si son employeur actuel revenait avec une contre-offre. Sa réponse — hésitante ou ferme — est le signal le plus fiable de la solidité du oui. Prépare avec lui, à ce stade, les raisons pour lesquelles il a initié sa recherche : elles ne disparaissent pas avec une augmentation, et le lui rappeler avant que la contre-offre tombe est plus efficace que d'argumenter après coup, en position défensive.

### Étape 5 — Le calendrier de relance pendant le délai de réflexion

**Le piège du silence** : un délai de réflexion sans relance planifiée est lu par le recruteur comme un désintérêt, et par le candidat comme un abandon — les deux lectures sont fausses et les deux abîment la suite. Fixe un calendrier de points de contact légers pendant le délai : un message pour répondre à une question restée en suspens, une mise en relation avec un futur collègue, une information pratique sur la prise de poste. Chaque point de contact a un objectif, pas juste « prendre des nouvelles ».

En Côte d'Ivoire comme ailleurs dans la sous-région, WhatsApp est souvent le canal réel de ce suivi, plus rapide et plus naturel qu'un e-mail formel — utilise le canal que le candidat utilise déjà avec toi, pas celui qui rassure le process interne.

### Étape 6 — La signature avant tout, et ce qu'on fait d'un refus

Tant que le contrat n'est pas signé, l'offre n'est pas acquise — **ne jamais laisser un candidat démissionner de son poste actuel avant la signature effective**, même si le oral semble ferme. C'est le moment où une contre-offre non anticipée fait le plus de dégâts : un candidat qui a déjà démissionné n'a plus de retrait possible et vit la contre-offre dans l'angoisse plutôt que dans la clarté.

Si le candidat refuse malgré tout : documente le motif réel du refus (montant, contre-offre, délai, doute sur le poste) — c'est une donnée utile pour le prochain candidat sur ce poste, pas un échec à enterrer.

## Format de sortie
- **Livrable** : le dossier de closing — ce que veut ce candidat et pourquoi, l'argumentaire d'offre construit dans l'ordre des leviers, les objections avec leur réponse, la marge de manœuvre et sa limite `⟦à renseigner⟧`, le scénario de contre-offre préparé en amont, le calendrier de relance, et le message d'offre prêt à valider.
- **Structure** : Markdown clair — answer-first (l'argumentaire et le calendrier d'abord, le détail des objections ensuite) ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage. Le dossier tient en une à deux pages, le message d'offre est un texte court, autonome, prêt à copier.
- **La marge de manœuvre et sa limite sont un input**, pas une production : la skill livre la structure de la négociation, l'ordre des leviers et la question à trancher ; la **valeur** (montant, pourcentage, seuil de retrait) vient de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Le salaire n'est jamais le premier levier.** Titre, périmètre, reporting, date de démarrage, télétravail, transport, scolarité : ces leviers se travaillent avant de toucher au montant, parce qu'un montant augmenté ne redescend jamais et devient un précédent interne.
2. **0 chiffre inventé.** Aucun montant, pourcentage d'augmentation, marge de négociation ou seuil de retrait n'est produit sans être fourni : `⟦à renseigner⟧` sinon. Cela vaut aussi pour les fourchettes « habituelles du marché » — un chiffre plausible non sourcé reste un chiffre inventé.
3. **La contre-offre se prépare avant, jamais après.** Si le candidat est en poste, la question de sa réaction à une contre-offre potentielle est posée pendant la négociation, pas découverte le jour où elle tombe.
4. **Le silence pendant le délai de réflexion n'est jamais laissé filer.** Un calendrier de relance est produit systématiquement, avec un objectif par point de contact — jamais une simple prise de nouvelles.
5. **Aucune démission avant signature.** Le closing n'est acquis qu'à la signature du contrat ; tant que ce n'est pas fait, le candidat n'est pas encouragé à quitter son poste actuel.
6. **Le contexte local n'est pas un décor.** Canal de suivi réellement utilisé par le candidat (WhatsApp souvent plus efficace que l'e-mail), poids réel du transport ou de la scolarité dans le package, situation de la diaspora qui négocie un retour : une négociation calquée sur un standard générique ignore ce qui pèse vraiment ici.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer le message d'offre, contacter le candidat ou engager un montant est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un candidat ou d'une négociation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune information sur les motivations du candidat** — tu produis le dossier complet, tu marques l'argumentaire comme **provisoire**, et tu recommandes explicitement de poser directement la question au candidat avant d'aller plus loin. Tu ne construis jamais un argumentaire sur des priorités supposées.
- **Marge de manœuvre non communiquée** — tu livres la structure de la négociation avec les cases `⟦à renseigner⟧`, tu ne fixes jamais toi-même un montant ou une limite.
- **Candidat déjà en poste avec risque de contre-offre connu** — tu places l'étape 4 en priorité absolue et tu ne poursuis pas tant que le scénario de contre-offre n'est pas préparé.
- **Candidat de la diaspora en cours de retour** — tu intègres les enjeux propres (déménagement, scolarité, adaptation) comme leviers potentiels à explorer à l'étape 1, sans les supposer automatiquement prioritaires.
- **Offre déjà refusée une fois** — tu documentes le motif du refus précédent avant de reconstruire un nouvel argumentaire, et tu signales si le motif n'a pas été traité.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (grille salariale, sourcing, entretien).
- **Action sortante demandée** (envoi du message d'offre, relance directe du candidat, engagement d'un montant) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le recruteur et le manager n'ont pas la même version de la marge de manœuvre) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
