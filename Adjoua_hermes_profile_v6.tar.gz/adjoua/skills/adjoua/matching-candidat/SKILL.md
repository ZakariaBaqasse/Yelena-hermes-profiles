---
id: Y0192
name: matching-candidat
description: "Étape 3 du processus — apparier UN profil à PLUSIEURS offres. Note chaque offre sur 100 avec quatre sous-notes (compétences, secteur, séniorité, localisation), dit ce qui matche et ce qui manque, et rédige les lettres de motivation. Utile au recruteur qui a plusieurs postes ouverts et un bon candidat mal placé."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-04
---

# Étape 3 — Trier · Apparier un profil aux offres

⚠️ **Sens de lecture.** Ici c'est **un profil contre plusieurs offres**. `tri-cv-masse` fait
l'inverse : plusieurs candidats contre un poste. Ne pas confondre, la méthode n'est pas la même.

⚠️ **À qui ça sert.** Le prompt d'origine est écrit pour servir **le candidat** — il produit ses
lettres de motivation. Pour un recruteur qui gère un portefeuille de postes ouverts, l'usage est
autre et vaut le détour : un très bon candidat écarté sur un poste correspond souvent à un autre.
C'est ce qui évite de perdre quelqu'un qu'on a mis trois semaines à trouver.

Transposé de l'agent `Matching_Candidat` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Le profil : CV et/ou profil professionnel, avec expériences, formations, compétences, certifications, langues, projet · la base d'offres réelles, chacune avec intitulé, entreprise, secteur, niveau, lieu, contrat, description, lien de candidature |
| **Livrable** | Les six meilleures offres notées et justifiées, les recommandations transverses, les lettres pour les trois premières |
| **Critère de réussite** | Un mauvais appariement reste un mauvais appariement — trois offres pertinentes valent mieux que six forcées |
| **Point de sortie** | Vers `suivi-candidatures` pour repositionner le candidat sur une autre offre |

Si le profil ou la base d'offres manque, la demander. On peut travailler sur un profil partiel en
signalant ce qui manque pour affiner.

## Méthode

1. **Comprendre le profil** : deux à trois phrases sur qui est la personne et son projet. Repérer ses
   compétences réelles, son niveau, ses secteurs, et tout atout différenciant — parcours
   international, bilinguisme, double culture, expérience de terrain.
2. **Présélectionner** les offres les plus proches, puis **réévaluer chacune en recruteur exigeant**.
3. **Noter chaque offre retenue** :
   - **Adéquation globale de 0 à 100**, cohérente avec les sous-notes.
   - **Quatre sous-notes de 0 à 100** : compétences · secteur · séniorité · localisation.
   - **Points forts** : deux à trois éléments **précis et réels du profil** qui collent à *cette*
     offre.
   - **Écarts** : un à deux manques honnêtes pour *cette* offre, ou aucun s'il n'y en a pas.
   - **Positionnement** : comment se présenter pour *cette* offre, en une ou deux phrases.
4. **Recommandations transverses** : trois à cinq conseils — forces à mettre en avant, manques à
   combler, façon de se positionner sur ce marché.
5. **Angle différenciant** : signaler les offres où un parcours particulier est un avantage décisif,
   et comment le formuler.
6. **Lettres de motivation** : une lettre complète et prête à envoyer par offre, pour les trois
   meilleures par défaut, fondée **uniquement** sur le profil fourni, **sans crochets à remplir**.

## Format de sortie

1. Profil et projet, deux à trois phrases, plus l'atout différenciant.
2. Les meilleures offres, six par défaut, triées par adéquation décroissante : intitulé et
   entreprise · adéquation en pourcentage · les quatre sous-notes · points forts ✓ · écarts ⚠ ·
   positionnement · lien pour candidater.
3. Recommandations transverses.
4. Lettres de motivation.

## Quand cette compétence se charge

- Un candidat dépose son CV ou son profil et veut savoir quelles offres lui conviennent.
- « Quelles offres pour ce profil ? », « aide-moi à me positionner », « écris-moi une lettre pour
  cette offre ».
- **En lot** : « apparie cette liste de profils contre ces offres » — sourcing inversé pour une
  équipe.

## Contexte d'activation — à préciser à chaque déploiement

L'agent est **générique et réutilisable** : le marché, le profil-cible et la base d'offres sont
fournis à l'activation, rien n'est codé en dur sur un client. Deux paramètres à poser avant de
lancer :

| Paramètre | Ce qu'il détermine |
|---|---|
| **Profil-cible** | Qui on aide, et donc quel atout différenciant valoriser systématiquement |
| **Marché des offres** | D'où vient la base d'offres appariées |

La première instance documentée dans le prompt d'origine vise les talents de la diaspora ivoirienne
formés à l'étranger qui rentrent chercher un emploi en Côte d'Ivoire, avec pour atout à valoriser le
parcours international, le bilinguisme et la double culture — très recherchés sur les fonctions
cadres, la relation client bilingue, la finance et les données.

Pour un autre déploiement, on remplace ces deux lignes ; le reste de la méthode ne bouge pas.

## Règles dures

- **Aucune invention.** Jamais un diplôme, un chiffre, une expérience ou une compétence qui n'est pas
  dans le profil fourni. Un écart non couvert se signale, il ne se masque pas.
- **Honnêteté de l'appariement.** Ton encourageant mais lucide : on aide la personne à réussir, pas à
  se survendre.
- **Lettres sans bluff** : elles ne promettent que ce que le profil démontre.

## 🔒 Données personnelles

Un CV et un profil professionnel sont des **données personnelles**.

- Traitées **uniquement** pour produire cet appariement, dans le travail en cours.
- **Jamais recopiées, stockées ni versées** dans un autre document, une base partagée ou une sortie
  destinée à des tiers.
- Aucune donnée sensible demandée : santé, religion, situation familiale.
- Le traitement suppose le consentement de la personne, recueilli en amont.

## Provenance

| | |
|---|---|
| Agent d'origine | `Matching_Candidat` |
| Version lue | v8 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 6159 caractères |
| Empreinte | `aca9387b36ed` |

Prompt archivé dans `reference/prompts-dust/Matching_Candidat.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**
