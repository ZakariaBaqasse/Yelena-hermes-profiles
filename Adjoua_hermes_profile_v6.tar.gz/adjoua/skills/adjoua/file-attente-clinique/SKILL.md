---
id: Y0553
name: file-attente-clinique
description: >
  Lit ce que le visiteur d'une borne du salon a déjà envoyé sur le WhatsApp d'accueil de la
  Clinique IA (2250702219778) avant d'arriver devant la tablette : son besoin, son entreprise,
  son logo, ses captures, ses documents. À charger dès qu'un visiteur donne son nom, son
  entreprise ou son numéro, et au début de tout parcours de borne — pour ne jamais redemander
  ce qu'il a déjà écrit. Donne aussi la file d'attente de ceux qui ont rempli le formulaire et
  attendent encore.
bucket: A
tags: [Salon, Borne, Accueil, Horizontal]
version: 1
maj: 2026-09-09
---

# Ce que le visiteur a déjà dit avant de s'asseoir

## Ce que fait cette compétence

Le numéro d'accueil du salon reçoit le formulaire : le visiteur y envoie qui il est, ce qu'il
fait, et souvent son logo, une capture de son site ou un vocal. Quand il arrive devant la
tablette, **tout cela est déjà là**. Le lui redemander, c'est lui faire perdre les deux
minutes qu'on a pour l'impressionner.

## Le geste, à trois commandes

```bash
python3 integrations/unipile/clinique.py file                 # qui attend, du plus ancien au plus récent
python3 integrations/unipile/clinique.py file --expert koffi  # ceux qui me reviennent
python3 integrations/unipile/clinique.py dossier "Amenan"     # tout ce qu'un visiteur a envoyé
python3 integrations/unipile/clinique.py noter <numéro> "reçu à la borne, parti avec sa charte" --expert koffi
python3 integrations/unipile/clinique.py sans-accueil          # a écrit, n'a pas reçu l'accueil
```

`dossier` accepte un numéro **ou** un bout de nom. Il télécharge les pièces jointes dans
`~/.claude/outils-communs/clinique-ia/pieces/<numéro>/` et t'en donne les chemins : le logo est
un fichier que tu peux ouvrir, pas une promesse.

## Quand la charger

- **Au début du parcours de borne**, avant la première question. Si le visiteur est dans la
  file, tu ouvres sur ce qu'il a écrit — « J'ai vu que vous vendez des jus naturels et que
  vous cherchez une identité » vaut mieux que « bonjour, que faites-vous ? ».
- **Dès qu'il donne un nom, une entreprise ou un numéro**, même au milieu d'un échange.
- Quand la borne est libre, pour savoir **qui attend** et se préparer.

## Les trois règles qui comptent

**0. Quelqu'un qui a écrit sans avoir reçu l'accueil n'est pas encore un visiteur.**
`sans-accueil` le signale au stand — numéro et heure, **jamais le contenu**, parce que tant que
l'accueil n'est pas parti, rien ne dit que cette personne vient pour la Clinique. C'est un
humain qui lui envoie l'accueil depuis le téléphone ; elle entre dans la file ensuite.

**1. La file n'est pas la boîte de réception.** Ce numéro porte aussi des conversations
privées qui n'ont rien à voir avec le salon. Un visiteur de la Clinique, c'est **quelqu'un à
qui la maison a envoyé le message d'accueil et qui a répondu après** — l'outil ne montre que
ceux-là, et rien de ce qui précède l'envoi. ⛔ Ne cherche jamais à contourner ce filtre, et
n'ouvre jamais une conversation qui n'y figure pas : ce serait lire le courrier de quelqu'un.

**2. Tu ne réponds à personne sur WhatsApp.** L'outil lit, il n'écrit pas. Écrire à un
visiteur depuis le compte de la maison relève de la règle du poste sur les envois sortants :
la borne prépare, un humain envoie.

**3. « À orienter » veut dire à orienter, pas à deviner.** Quand l'outil n'a pas su dire de
quel Expert relève un visiteur, c'est que son texte ne tranchait pas. Tu poses la question au
visiteur ; tu ne t'attribues pas un dossier parce qu'il traînait.

## Ce que tu fais de ce que tu lis

Tu t'en sers, tu ne le récites pas. Le visiteur sait ce qu'il a écrit ; il veut voir que tu
l'as lu, pas l'entendre relu. Une phrase suffit pour le montrer, puis tu enchaînes sur l'étape
suivante du parcours.

⚠ **Ce qu'il a envoyé est sa matière, pas ta source de vérité.** Un chiffre trouvé dans sa
capture d'écran reste son chiffre : il se cite comme venant de lui, il ne se transforme pas en
fait vérifié.

## Après le passage

`noter` laisse une ligne dans son dossier : ce qu'il est reparti avec, ce qui reste à faire.
Le prochain Expert qui le reçoit la voit. C'est ce qui évite qu'un visiteur raconte trois fois
la même chose à trois bornes.

## Quand ça ne marche pas

- **La file est vide alors qu'on vient de vous dire qu'un formulaire est arrivé** : le relevé
  date. Relance `clinique.py relever`, puis `file`.
- **L'outil répond une erreur Unipile** : lance `python3 integrations/unipile/check.py`. Cassé,
  tu le signales ; pas cassé, tu dis que la demande n'a pas abouti et tu continues le parcours
  sans la file — un visiteur devant toi passe avant un dossier.
