---
id: Y0565
name: mode-degrade
description: >
  Quoi faire quand un accès tombe : messagerie, agenda, espace documentaire, service de pages,
  transcription de réunions, source publique. Nommer précisément ce qui est indisponible, dire
  l'impact sur le livrable, continuer avec ce qui reste, proposer un contournement, et ne jamais
  laisser croire que le travail complet a été fait. À charger dès qu'une commande échoue ou
  qu'une source ne répond pas.
version: 1
maj: 2026-08-05
---

# Mode dégradé — quand un accès tombe

Demandé par la directrice générale le 05/08/2026.

## ⛔ La faute que cette compétence empêche

Livrer un document qui a l'air complet alors qu'une de ses sources n'a pas répondu. Le lecteur
ne voit pas le trou : il voit un document, et il lui fait confiance. **Un livrable amputé qui ne
le dit pas est plus dangereux qu'un livrable manquant**, parce qu'il désarme la vigilance au lieu
de l'appeler.

Le réflexe naturel est le pire : combler le trou avec ce qu'on « sait » du sujet. C'est
exactement le mécanisme d'une donnée inventée, et il se déclenche justement quand un accès manque.

## Les quatre gestes, dans cet ordre

**1. Nommer l'accès, pas le symptôme.** « L'agenda n'a pas répondu » ne suffit pas. On écrit
*quel compte*, *quelle commande*, *quel code d'erreur*, *à quelle heure*. Une panne nommée se
répare ; une panne vague se répète.

**2. Dire l'impact sur le livrable, pas sur moi.** Pas « je n'ai pas pu lire la boîte », mais
« les courriers arrivés depuis 6 h ne sont pas dans ce brief : s'il y a une échéance dedans, je
ne l'ai pas vue ».

**3. Continuer avec ce qui reste.** Une source sur quatre en panne ne justifie pas de ne rien
rendre. Le document sort, avec le trou marqué à sa place exacte — jamais renvoyé en note de bas
de page.

**4. Proposer le contournement, et l'essayer avant de le proposer.** Coller le contenu à la
main, passer par un autre compte, reporter au prochain passage, ou ouvrir l'accès. Un
contournement annoncé sans avoir été essayé est la faute du 03/08/2026, qui a coûté une page
inaccessible annoncée comme prête.

## Comment savoir ce qui est réellement tombé

```bash
bash outils/etat-de-mes-moyens.sh      # clés, comptes, formats, automatisations, garde-fous
bash outils/verifier-les-liens.sh <doc>  # les liens cités répondent-ils encore
```

Cet inventaire **teste** au lieu de déduire. On ne déclare jamais un accès mort sans l'avoir
lancé : le 04/08/2026, j'ai annoncé deux outils absents de la machine alors qu'ils y étaient.

## Pannes déjà rencontrées, et ce qu'elles veulent dire

| Symptôme | Cause réelle | Ce qu'on fait |
|---|---|---|
| `no TTY available` sur une commande Google | `GOG_KEYRING_PASSWORD` non exporté | `export GOG_KEYRING_PASSWORD=""` |
| `gog: command not found` | binaire hors du `PATH` | `export PATH="$HOME/gogcli/bin:$PATH"` |
| `403 accessNotConfigured` sur les contacts | API People désactivée sur le projet | le dire, et demander l'activation |
| Page hébergée en 404 | le service efface les pages au redémarrage | republier depuis la source conservée |
| Page qui ne s'ouvre pas chez le client, 200 chez moi | le service dort, premier chargement long | le dire, ne pas conclure au lien mort |
| Source publique en 403 | le site refuse une machine | ouvrir la page autrement, ou ne pas citer |

## La phrase à ne jamais écrire

« Voici le point complet » quand une source manque. On écrit ce qui manque **avant** ce qu'on a
trouvé, parce que c'est ce qui change la lecture du reste.
