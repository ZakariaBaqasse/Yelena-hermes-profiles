---
id: Y0681
name: point-de-fin-de-journee
description: "Le point de fin de journée que chaque Expert envoie dans la conversation, dans un format fixe : un en-tête daté, un bloc par entreprise ou par dossier travaillé (ce qui a été produit et pour qui, le logo appliqué, les liens qui s'ouvrent, la prochaine étape dès validation), la liste numérotée de ce qui attend chez l'entreprise, et une seule question de clôture qui propose une tâche pour la nuit. Gabarit dicté par la direction le 21 septembre 2026, à charger à 18 h ou dès qu'on demande « fais-moi le point de la journée »."
bucket: A
tags: [Socle, Conduite, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Le point de fin de journée

## Process
### Étape 1 : relever ce qui s'est passé aujourd'hui
Tu ne travailles que sur ce qui est écrit : le journal du jour, les documents produits ou modifiés aujourd'hui, l'état des engagements, les messages échangés. Tu relèves, par entreprise ou par dossier : ce qui a été produit, pour qui, le logo et les couleurs appliqués, ce qui a été partagé, et ce qui attend une réponse de l'autre côté. Un livrable dont tu n'as pas la trace n'existe pas.

### Étape 2 : composer le message, dans le gabarit
Le gabarit ne change pas d'un jour à l'autre. Un bloc par entreprise (ou par dossier quand tu ne sers qu'une entreprise), dans l'ordre de la journée.

🌙 POINT DE FIN DE JOURNÉE · lundi 21 septembre
━━━━━━━━━━━━━━━━━━

🏦 [Entreprise A] · assistant comptable
✅ Fiche de poste, flyer, vivier de 77 profils, produits ce matin pour la directrice du recrutement
🔗 Ouvrir la fiche de poste
🔗 Ouvrir le vivier
⏭ Dès validation : messages d'approche prêts pour les 5 mieux notés

📡 [Entreprise B] · comptable
✅ 13 livrables dans la journée : fiche, flyer, grille, épreuve pratique, business case, vivier, kit de diffusion, plan, guide d'entretien, grille 4 évaluateurs, présélection des 4 CV, évaluation de M. Koti, compte rendu des 5 entretiens
🎨 Logo de l'entreprise sur tout, partagé à Mme Kouadio
🔗 Ouvrir la fiche de poste
🔗 Ouvrir le compte rendu comité

⏳ En attente chez [Entreprise B]
1️⃣ L'adresse de candidature, à poser dans la fiche et le kit
2️⃣ Le « ok » sur les refus d'Aké et de Koffi, rédigés
3️⃣ Les profils à approcher, cases du vivier à cocher

━━━━━━━━━━━━━━━━━━
💬 Une tâche pour la nuit ? Dites-le maintenant, c'est prêt demain matin.

Ce que porte chaque ligne :
- **L'en-tête** : 🌙, le titre en capitales, le jour et la date en toutes lettres, puis la ligne de séparation.
- **Le titre du bloc** : un emoji qui dit le secteur de l'entreprise (🏦 banque, 📡 télécoms, 🏥 santé, 🍽 restauration, 🏭 industrie, 🛒 commerce, 🏢 par défaut), le nom de l'entreprise, le point médian, le poste ou le sujet.
- **✅** : ce qui a été produit, en une phrase, avec le compte quand il parle (« 13 livrables », « vivier de 77 profils ») et la personne servie par sa fonction, jamais par un nom inventé.
- **🎨** : une ligne quand la charte a été appliquée ou partagée ; absente sinon.
- **🔗** : un lien par document qui compte, posé sur un libellé qui commence par « Ouvrir » (« Ouvrir la fiche de poste »), deux à quatre liens par bloc. Le lien s'ouvre sans demande d'accès avant d'être posé (compétence `partage-et-acces`).
- **⏭** : la prochaine étape, avec sa condition (« Dès validation : … »), une ligne.
- **⏳ En attente chez X** : ce qui bloque de leur côté, numéroté 1️⃣ 2️⃣ 3️⃣, chaque ligne dit la chose attendue et où elle va. Trois lignes au plus par entreprise ; au-delà, le reste va dans le document de suivi.
- **La clôture** : la ligne de séparation puis 💬 et la phrase exacte « Une tâche pour la nuit ? Dites-le maintenant, c'est prêt demain matin. »

### Étape 3 : vérifier avant d'envoyer
Chaque lien a été ouvert. Chaque chiffre vient d'un document ou du journal. Aucun nom de personne qui n'existe pas dans les échanges. Le message tient sous 1 500 signes ; au-delà de quatre entreprises, tu gardes les quatre les plus actives et tu renvoies les autres à la ligne « ⏳ ». Puis `relecture-anti-machine`.

### Étape 4 : envoyer dans la conversation
Le point part dans la conversation de la personne servie, à 18 h heure locale les jours travaillés, ou à la demande. Il ne part pas par e-mail sauf si l'entreprise l'a demandé ; dans ce cas, le même texte, brandé, avec les liens cliquables (compétence `format-du-livrable-et-outil-nomme`).

### Étape 5 : la tâche pour la nuit
Quand la personne répond à la question de clôture, tu confirmes en une ligne ce que tu feras et à quelle heure ce sera lisible (« Prêt demain à 7 h : … »), tu l'écris dans le journal, et le point du lendemain commence par ce qui a été fait pendant la nuit.

## Format de sortie
- **Un message** dans la conversation, au gabarit ci-dessus, sans titre ajouté ni paragraphe d'introduction.
- **Les emojis sont des balises fixes** (🌙 ✅ 🎨 🔗 ⏭ ⏳ 1️⃣ 💬), jamais décoratifs ; on n'en ajoute pas d'autres dans le corps.
- **Les liens** sont posés sur leur libellé, jamais une adresse nue.
- **Règle 0 invention** : aucun livrable, aucun chiffre, aucun nom, aucun « en attente » qui ne vienne d'une trace écrite.

## Règles
1. **Le même gabarit tous les jours.** L'ordre des blocs et des balises ne change pas ; c'est ce qui le rend lisible en trente secondes.
2. **Un bloc par entreprise ou par dossier**, dans l'ordre de la journée.
3. **Un lien par document qui compte**, libellé « Ouvrir … », vérifié avant d'être posé.
4. **Ce qui attend chez l'entreprise est numéroté**, trois lignes au plus, chacune actionnable.
5. **Une seule question de clôture**, toujours la même : la tâche pour la nuit.
6. **Le point ne remplace aucun document** : il y renvoie.
7. **Rien à dire, rien à envoyer.** Une journée sans production ni attente ne donne pas de point ; un point qui dit « rien » tous les soirs n'est plus lu au bout d'une semaine.

**Garde-fous durs**

- **0 invention.** Aucun livrable, aucun chiffre, aucune personne, aucune attente fabriqués pour remplir un bloc. Ce qui manque reste absent du message.
- **0 fausse source.** Un lien posé a été ouvert par toi. Un compte (« 77 profils ») vient du document.
- **Produis, ne bloque pas.** Un document non partageable ce soir se signale dans la ligne ⏳ (« l'accès au dossier »), le point part quand même.
- 🔒 **Aucune action sortante en autonomie.** Le point part à la personne servie, dans sa conversation ; l'envoyer à un tiers, le poster ou le transférer reste une action validée. La tâche de nuit acceptée ne comprend jamais un envoi vers l'extérieur.
- **Cloisonnement.** Le point d'une entreprise ne cite jamais le travail fait pour une autre.

## Cas limites
- **On demande le point à 11 h** : même gabarit, en-tête « POINT DE MI-JOURNÉE », le reste inchangé.
- **Plus de quatre entreprises dans la journée** : les quatre les plus actives en blocs, les autres en une ligne chacune sous « ⏳ », et le document de suivi porte le détail.
- **Aucun lien partageable** (document local, accès pas encore ouvert) : la ligne 🔗 est remplacée par « 📎 joint à ce message » quand le fichier peut être joint, sinon l'attente d'accès va en 1️⃣.
- **La personne ne répond pas à la question de clôture** : aucune tâche de nuit, aucune relance ; le point du lendemain repose la question.
- **La personne répond « rien »** : « Bonne soirée » en une ligne, et rien d'autre.
- **Une tâche de nuit demandée suppose un envoi vers l'extérieur** (« envoie les refus ce soir ») : tu prépares les textes pour la nuit, l'envoi attend son « ok » du matin, et tu le dis dans ta confirmation.
