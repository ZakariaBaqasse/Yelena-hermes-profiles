# Référentiel — job scorecard

La scorecard est le document qui transforme une fiche de poste en décision d'embauche défendable.
Sans elle, un comité tranche sur une impression, et l'impression suit la personne la plus assurée
dans la pièce.

Défaut constaté le 03/08/2026 : aucune scorecard proposée spontanément. Elle doit désormais
accompagner **chaque** fiche de poste, sans qu'on la demande.

---

## Ce qu'est une scorecard, et ce qu'elle n'est pas

**Ce n'est pas** une liste de compétences notées de 1 à 5. Ça, c'est un formulaire, et un formulaire
se remplit après coup pour justifier une décision déjà prise.

**C'est** un document en trois parties, écrit **avant** de recevoir le premier candidat :

### 1. La mission, en une phrase

Ce que la personne devra avoir accompli pour qu'on considère l'embauche réussie. Pas les tâches :
le résultat.

### 2. Les résultats attendus, datés et chiffrés

Trois à cinq lignes, chacune avec une échéance et un indicateur. Ce sont eux qui rendent l'évaluation
possible : on n'évalue pas « la rigueur », on évalue la capacité démontrée à produire un résultat de
ce type ailleurs.

| Résultat attendu | Échéance | Indicateur |
|---|---|---|
| ⟦résultat 1⟧ | 3 mois | ⟦mesure⟧ |
| ⟦résultat 2⟧ | 6 mois | ⟦mesure⟧ |
| ⟦résultat 3⟧ | 12 mois | ⟦mesure⟧ |

### 3. Les compétences, pondérées et adossées à une preuve

Chaque ligne porte **le moyen de vérification**. Une compétence sans moyen de vérification n'est pas
un critère, c'est un souhait.

| Compétence | Poids | Comment on la vérifie |
|---|---|---|
| ⟦compétence⟧ | ⟦%⟧ | Question STAR / mise en situation / test pratique / prise de références |

---

## Les règles d'usage — c'est là que les scorecards échouent

1. **Elle s'écrit avant le premier entretien.** Écrite après, elle enregistre une décision au lieu
   de la produire.
2. **Chaque évaluateur la remplit seul, avant la mise en commun.** C'est la règle la plus violée et
   la plus importante. Remplie en réunion, elle ne mesure que le premier avis exprimé.
3. **Les poids totalisent 100 et sont fixés avant.** Ajuster les poids après avoir vu les candidats
   revient à choisir le gagnant puis à écrire les règles.
4. **Les critères éliminatoires sont nommés comme tels**, séparément des critères pondérés. Un
   éliminatoire ne se compense pas par un bon score ailleurs.
5. **Un écart de moins de 10 points entre deux candidats n'est pas un écart.** Il se tranche par un
   tour supplémentaire ou une prise de références, pas par la décimale.
6. **La note s'accompagne d'un fait.** Chaque case porte au moins une phrase de justification tirée
   de ce que le candidat a dit ou fait. Une note sans fait est ininterprétable trois semaines plus
   tard.

---

## Échelle de notation

Une échelle à quatre niveaux, sans milieu, pour forcer la prise de position :

| Niveau | Signification |
|---|---|
| **4 — Dépasse** | A démontré ce niveau dans un contexte plus exigeant que le nôtre |
| **3 — Répond** | A démontré ce niveau dans un contexte comparable |
| **2 — Partiel** | Éléments présents, mais démontrés dans un contexte plus simple ou plus ancien |
| **1 — Absent** | Rien de démontré, ou déclaratif seulement |

⚠️ **La différence entre 3 et 1 est le mot « démontré ».** Un candidat qui dit avoir fait n'a pas
démontré. On note ce qui a été raconté avec un contexte, une action et un résultat vérifiables.

---

## Les moyens de vérification, par nature de critère

| Ce qu'on veut vérifier | Moyen qui marche | Moyen qui ne marche pas |
|---|---|---|
| Un savoir-faire technique | Test pratique, mise en situation sur pièce ou document | Question fermée sur une définition |
| Une expérience réelle | Question sur le détail matériel : chiffres, outils, fréquences, incidents | « Parlez-moi de votre expérience » |
| Un comportement | Récit d'une situation passée, creusé jusqu'à l'action précise | Question hypothétique « que feriez-vous si » |
| Une capacité d'encadrement | Récit d'un conflit d'équipe traité, avec l'issue | Affirmation de style de management |
| La tenue dans la durée | Prise de références, avec accord du candidat | Intuition sur la « motivation » |

---

## Le référentiel local

Les critères d'une scorecard sont écrits, conservés, et opposables en cas de contentieux. Ils doivent
donc être **exempts de tout élément visé par l'article 4 du Code du travail ivoirien** — sexe, âge,
ascendance nationale, race, religion, opinion, origine sociale, appartenance syndicale, séropositivité
réelle ou présumée, handicap. Le texte cité figure dans le référentiel de la compétence
`fiche-de-poste`.

En corollaire : une scorecard bien faite est la **meilleure protection** d'un employeur contre une
accusation de discrimination, parce qu'elle montre sur quoi la décision a réellement porté. Une
décision sans trace écrite ne se défend pas.

⟦Conventions collectives applicables et grilles de classification : à récupérer — elles fixent les
niveaux et donc le calibrage des attentes par catégorie.⟧

---

## État du corpus

⟦**Aucune scorecard du client n'a été fournie.**⟧ Demandé le 03/08/2026.

---

## Règle de forme — un livrable, un destinataire

| Fichier | Contenu | Destinataire |
|---|---|---|
| `<slug>_vN_grille-vierge.pdf` | La grille à remplir : critères, poids, échelle, cases vides | Chaque évaluateur, avant l'entretien |
| `<slug>_vN_synthese.pdf` | Les grilles consolidées, l'écart, la recommandation | Le comité de décision |

La grille vierge ne contient **aucune** indication de ce qui est attendu comme bonne réponse : sinon
l'évaluateur note la conformité à un corrigé au lieu de noter le candidat.
