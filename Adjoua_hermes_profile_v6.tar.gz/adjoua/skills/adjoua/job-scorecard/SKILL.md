---
id: Y0181
name: job-scorecard
description: "Scorecard évaluation candidat + reco."
bucket: A
tags: [Recrutement]
version: 1
maj: 2026-08-03
---

# Job Scorecard

## Ce qu'il faut avoir sous la main
1. Le **job title** du poste (obligatoire) ;
2. *(optionnel)* la **fiche de poste complète** (missions, compétences requises) ;
3. *(optionnel)* le **nom de l'entreprise** + one-liner + site internet + 2-3 entreprises comparables.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un brief ou un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant clairement tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cadrer le poste
Intitulé et, quand elle est fournie, la fiche complète. Sans fiche, tu construis à partir des standards du poste et tu le dis explicitement.

### Étape 2 — Choisir les dimensions d'évaluation
Quatre à six dimensions maximum, chacune réellement discriminante pour ce poste. Au-delà, les évaluateurs cochent au hasard.

### Étape 3 — Définir les niveaux
Pour chaque dimension, ce que vaut un candidat insuffisant, correct, bon, excellent — décrit par des comportements observables, pas par des adjectifs.

### Étape 4 — Pondérer
Les dimensions n'ont pas le même poids ; la pondération est visible sur la scorecard pour que chacun note en connaissance de cause.

### Étape 5 — Rendre le template
Scorecard prête à remplir pendant l'entretien, avec l'espace pour les notes factuelles et la recommandation finale.

## Format de sortie
### 1. Introduction du Template

**Template de Score Card**
- **Entreprise** : [Nom de l'entreprise]
- **Poste** : [Job title]
- **Date de création** : [Date actuelle]

[Si contexte fourni, ajouter 1-2 phrases sur l'entreprise et le contexte du poste]

### 2. Tableau Markdown

Présenter le template sous forme de **tableau Markdown** :

```
| Catégorie | Critère | Note (/5) | Commentaire |
|-----------|---------|-----------|-------------|
| 🎯 Hard Skills | [Compétence spécifique 1] |  |  |
| 🎯 Hard Skills | [Compétence spécifique 2] |  |  |
| 🎯 Hard Skills | [Compétence spécifique 3] |  |  |
| 🎯 Hard Skills | [Compétence spécifique 4] |  |  |
| 🤝 Soft Skills | [Compétence comportementale 1] |  |  |
| 🤝 Soft Skills | [Compétence comportementale 2] |  |  |
| 🤝 Soft Skills | [Compétence comportementale 3] |  |  |
| 🏢 Match Entreprise | Adéquation culture d'entreprise |  |  |
| 🏢 Match Entreprise | Motivation pour le secteur/mission |  |  |
| 📈 Parcours | Pertinence de l'expérience |  |  |
| 📈 Parcours | Cohérence de la trajectoire |  |  |
| 🚀 Potentiel | Capacité d'apprentissage |  |  |
| 🚀 Potentiel | Ambition et drive |  |  |

**Score Global : __/XX** (moyenne : __/5)
```

### 3. Guide d'Utilisation

Après le tableau, fournir un guide concis :

📋 **Comment utiliser cette score card :**

1. **Notation** : Attribuez une note de 1 à 5 pour chaque critère
2. **Commentaires** : Notez des observations factuelles et exemples concrets
3. **Score Global** : Calculez la somme et la moyenne pour une vue d'ensemble
4. **Décision** : Utilisez ce score comme aide à la décision, pas comme vérité absolue

**Échelle de notation :**

- 1 = Insuffisant | 2 = En dessous des attentes | 3 = Satisfaisant | 4 = Bon | 5 = Excellent

### 4. Export CSV

**Important** : Proposer systématiquement un export CSV prêt à l'emploi, au format brut sans balises Markdown ni backticks :

```
Catégorie,Critère,Note,Commentaire
Hard Skills,[Compétence 1],,
Hard Skills,[Compétence 2],,
...
```

📥 Version CSV (à copier-coller dans Excel/Google Sheets) : [CONTENU CSV ICI]

## Règles
1. **Collecter les informations manquantes** de manière structurée, en un seul message
2. **Adapter les critères** précisément au contexte (poste, secteur, niveau seniority)
3. **Nommer les hard skills de façon spécifique** (pas "compétence technique 1" mais "Maîtrise de Python/Django" ou "Gestion de budget >1M€")
4. **Être concis** : les critères doivent être clairs et non ambigus
5. **Générer 10-15 critères maximum** : qualité > quantité
6. **Proposer systématiquement** : le tableau Markdown ET l'export CSV brut
7. **Expliquer brièvement** pourquoi ces critères sont pertinents pour ce poste spécifique

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Fiche de poste absente** : Utiliser le job title pour inférer les compétences standard du marché pour ce type de poste
- **Contexte minimal** (juste entreprise + job title) : Générer un template générique mais pertinent pour ce type de poste
- **Entreprises comparables fournies** : Les mentionner dans l'introduction et utiliser pour contextualiser le niveau d'exigence
- **Site internet fourni** : L'analyser rapidement pour adapter les critères "Match Entreprise" aux valeurs/culture de l'entreprise
- **Poste atypique ou hybride** : Décomposer les différentes facettes du rôle et répartir les critères en conséquence

## Détails complémentaires
### Structure du Template de Score Card

### Principes d'Évaluation

Le template doit permettre d'évaluer :
1. **Hard Skills** : Compétences techniques mesurables requises pour le poste
2. **Soft Skills** : Compétences comportementales et relationnelles
3. **Match Entreprise/Culture** : Adéquation avec les valeurs et le contexte de l'entreprise
4. **Expérience & Parcours** : Pertinence et cohérence du parcours professionnel
5. **Potentiel d'évolution** : Capacité d'apprentissage et trajectoire de carrière

### Échelle de Notation

Utiliser une échelle de 1 à 5 pour chaque critère :

- **1** : Insuffisant / Ne correspond pas
- **2** : Partiellement satisfaisant / En dessous des attentes
- **3** : Satisfaisant / Correspond aux attentes minimales
- **4** : Bon / Au-dessus des attentes
- **5** : Excellent / Dépasse significativement les attentes

### Adaptation des Critères

Les critères d'évaluation doivent être **adaptés dynamiquement** selon :
- Le niveau du poste (junior, mid, senior, executive)
- Le secteur d'activité de l'entreprise
- Les compétences mentionnées dans la fiche de poste (si fournie)
- Les standards du marché (basés sur les entreprises comparables si fournies)
- Le contexte spécifique de l'entreprise (culture, valeurs si site internet fourni)

Exemples d'adaptation :

- **Poste tech (ex: Software Engineer)** : Privilégier langages, frameworks, architecture, problem-solving
- **Poste commercial (ex: Sales Manager)** : Négociation, closing, gestion pipeline, relations clients
- **Poste créatif (ex: Designer)** : Maîtrise outils, vision créative, portfolio, itération
- **Poste stratégique (ex: Product Manager)** : Priorisation, data-driven, stakeholder management, vision produit

### Nombre de Critères

Générer **10-15 critères au total**, répartis approximativement :
- **4-6 Hard Skills** spécifiques au poste
- **3-4 Soft Skills** clés pour réussir dans ce rôle
- **2-3 Match Entreprise** (culture, motivation, alignement valeurs)
- **2-3 Parcours & Potentiel** (expérience, trajectoire, capacité d'apprentissage)

### Exemple d'Usage

**User :** Je veux créer une score card pour un poste de Product Manager

**Assistant :** Je vais créer un modèle de grille d'évaluation pour votre poste de Product Manager.

Pour quelle entreprise créez-vous cette score card ?

**[Optionnel]** Pouvez-vous me fournir :
- Un one-liner ou description de l'entreprise
- L'URL du site internet
- 2-3 noms d'entreprises comparables
- Une fiche de poste complète

[Le template est généré directement sur la base des informations reçues.]

**Voici votre template. Souhaitez-vous :**
1. Que je l'ajuste davantage ?
2. Que je le teste avec un exemple concret de candidat ?
