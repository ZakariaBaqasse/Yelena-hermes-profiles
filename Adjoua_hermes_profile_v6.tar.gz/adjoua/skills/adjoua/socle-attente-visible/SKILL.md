---
id: Y0608
name: socle-attente-visible
description: >
  Ne jamais laisser la personne servie devant un silence. Dès qu'une demande va prendre plus
  d'une quinzaine de secondes, un accusé part AVANT le travail, avec une estimation de durée,
  et se met à jour en place jusqu'à la réponse. À charger dès qu'une réponse suppose une
  recherche en ligne, un document, ou plus de deux ou trois commandes.
version: 1
maj: 2026-08-26
---

# L'attente se meuble, elle ne se subit pas

> **Demandé par Yelema, 26/08/2026 :** *« attente visible — l'utilisateur sait qu'on
> travaille ».*

Un silence de trois minutes est indiscernable d'une panne. Celui qui attend ne sait pas s'il
doit patienter, relancer, ou aller faire autre chose — et c'est cette incertitude qui coûte,
bien plus que la durée elle-même.

---

## La règle

**Au-delà de quinze secondes prévues, un accusé part avant le travail.** Il contient deux
choses, et deux seulement :

1. **ce qui a été compris** de la demande, en une ligne ;
2. **combien de temps ça va prendre**, en ordre de grandeur.

> ▸ *Reçu — je regarde la trésorerie sur les trois derniers mois. Deux à trois minutes.*

Puis la ligne **se met à jour en place** — on modifie le message existant, on n'en empile pas
de nouveaux. Trois messages « je travaille toujours » à la file sont pires que le silence.

---

## Les trois annonces

| Ce qu'on va faire | Ce qu'on annonce |
|---|---|
| une vérification, un point court | « je regarde — moins d'une minute » |
| une recherche, une comparaison, une analyse | « je regarde — deux à trois minutes » |
| une veille, une revue, un rapport, un document | « je prépare ça — comptez cinq à dix minutes » |

**L'annonce n'est qu'une annonce.** Elle dit une attente, elle ne décide de rien. Si la durée
dérape, on le dit avant l'échéance annoncée, pas après :

> ▸ *Toujours dessus — une source ne répond pas, je prends cinq minutes de plus.*

---

## Le mécanisme, et pourquoi il est hors du tour

⛔ **Ne pas meubler l'attente en appelant un outil d'envoi de message pendant le travail.**
Mesuré sur cette machine le 09/08/2026 : chaque mise à jour envoyée par l'agent lui-même coûte
un pas, un pas coûte une douzaine de secondes, et six mises à jour avaient consommé **72
secondes de budget — 12 % du tour** uniquement pour dire qu'on travaillait. Pire : une fois une
commande longue lancée, l'agent est bloqué et ne peut plus rien envoyer. La ligne se figeait
exactement pendant les moments longs.

La ligne d'état est donc tenue par un **processus séparé**, branché sur les événements de la
session. Il ne consomme aucun pas et il n'est pas bloqué quand l'agent l'est. Mesuré : un signe
de vie en **~150 ms** au lieu de 12 à 36 secondes.

Sur cette machine, c'est `~/.claude/outils-communs/ligne-etat.py`, branché sur trois
événements dans le `settings.local.json` du poste :

| Événement | Mode | Ce qu'il fait |
|---|---|---|
| `UserPromptSubmit` | `recu` | poste l'accusé, avant que le modèle produise un mot |
| `PostToolUse` | `avance` | met la ligne à jour, au plus une fois toutes les 5 s |
| `Stop` | `fin` | efface la ligne, la réponse l'a remplacée |

**Si les hooks sont en place, il n'y a rien à faire de plus** : l'accusé part tout seul. Cette
compétence sert alors à savoir que ça existe, et à ne pas le doubler d'un message manuel.

**S'ils ne le sont pas** — poste dégradé, canal sans hook — l'accusé se poste à la main, une
fois, avant de commencer. Une fois, pas trois.

---

## Ce qui ne se fait jamais

- **Doubler la ligne d'état d'un message texte.** Si la ligne dit déjà « en cours », un « je
  travaille » de plus est du bruit.
- **Annoncer une durée qu'on sait fausse** pour rassurer.
- **Laisser la ligne en place après la réponse.** Elle n'a plus d'objet ; elle s'efface.
- **Meubler avec du contenu creux** — un résumé de ce qu'on va faire n'est pas une réponse.
