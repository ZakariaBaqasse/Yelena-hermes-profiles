---
id: Y0547
name: droit-du-travail-ci
description: Le socle juridique ivoirien du recrutement — embauche, période d'essai, classification et salaire minimum, préavis, cotisations sociales. À charger avant de rédiger une lettre d'engagement, de proposer une rémunération, de fixer une période d'essai ou de chiffrer un coût employeur.
version: 2
maj: 2026-09-22
---

# Droit du travail ivoirien — ce qu'un recruteur doit tenir

Constitué le 13/08/2026. **Chaque règle porte son texte et sa source.** Ce qui n'a pas été lu à la
source est marqué comme tel — et ne s'écrit pas dans un contrat.

⚠️ **Je ne suis pas juriste et ce référentiel ne remplace pas un avis juridique.** Il sert à ne pas
écrire de bêtise dans une fiche de poste, une lettre d'engagement ou une proposition de
rémunération, et à savoir quand appeler quelqu'un dont c'est le métier.

---

## Les trois textes de base

| Texte | Ce qu'il régit | État |
|---|---|---|
| **Loi n° 2015-532 du 20 juillet 2015**, Code du travail | tout | ✅ lu dans le texte intégral (04/08/2026) |
| **Convention collective interprofessionnelle du 19 juillet 1977** (AICI / UGTCI) | embauche, essai, préavis, classification | ✅ **lue intégralement, 26 pages** (13/08/2026) |
| **Décret n° 2024-900**, engagement à l'essai | durées de période d'essai | ⚠️ deux sources secondaires concordantes, texte non ouvert |
| **Arrêté n° 0050/MEPS/CAB du 19 mai 2023** | barème des salaires minima catégoriels conventionnels | ✅ **lu dans le texte scanné** (26/08/2026) |
| **Barème des salaires minima catégoriels conventionnels 2015** (patronat ivoirien) | grilles par secteur et catégorie, 79 pages | ✅ **lu** (26/08/2026) |
| **Code de prévoyance sociale**, loi n° 99-477 | cotisations, branches, assiettes | ✅ **lu** (26/08/2026) |

Archivés : `reference/droit-travail-ci/`. Code du travail :
<https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf>
Convention : <https://www.droitci.info/files/827.07.77c-Convention-interprofessionnelle-du-19-juillet-1977-entre-AICI-et-UGTCI.pdf>

---

## 1 · Ce qu'on ne peut pas demander à un candidat

**Article 4 du Code du travail** : interdiction de prendre en considération, notamment pour
l'embauchage, le **sexe**, l'**âge**, l'**ascendance nationale**, la **race**, la **religion**,
l'**opinion politique et religieuse**, l'**origine sociale**, l'**appartenance syndicale**, la
**séropositivité réelle ou présumée** et le **handicap**. L'article 18.15 qualifie d'abusif tout
licenciement pris en violation de l'article 4.

⚠️ **Ce qui se pratique sur le marché ne se recopie pas.** Des offres ivoiriennes lues le
04/08/2026 exigeaient « âgé de 30 à 55 ans » et « de nationalité ivoirienne ». Une annonce se relit
contre l'article 4 avant diffusion, même quand des employeurs respectables font autrement.

---

## 2 · L'embauche — ce que la lettre d'engagement doit porter

**Article 13 de la convention collective.** L'engagement doit **toujours** être constaté par une
lettre d'engagement ou un document en tenant lieu, indiquant :

- l'**identité** du travailleur ;
- la **date** de l'engagement ;
- la **classification professionnelle** ;
- le **salaire convenu**, qui ne peut « en aucune manière être inférieur au salaire minimum
  conventionnel de la classification » ;
- le cas échéant, les **conditions et la durée de la période d'essai**.

🔴 **En l'absence d'écrit, le contrat est réputé à durée indéterminée et l'engagement est considéré
comme définitif dès le jour de l'embauche.** C'est la conséquence la plus lourde et la plus
ignorée : pas d'écrit, pas de période d'essai, pas de CDD — un CDI définitif immédiat.

**Priorité de réembauche** : le travailleur congédié pour suppression d'emploi ou compression
conserve **deux ans** une priorité d'embauche dans la même catégorie d'emploi.

⚠️ **Dispositions périmées dans ce texte de 1977, signalées par le document lui-même** :
l'obligation de passer par l'Office de la Main-d'œuvre et l'interdiction de l'embauche directe sont
abrogées — le code de 1995 autorise l'embauche directe, et l'Office a été dissous. Une convention
de 1977 se lit avec ses notes de renvoi.

---

## 3 · La période d'essai

**Durées maximales** — identiques dans la convention collective (art. 14) et dans le décret
n° 2024-900 :

| Catégorie | Durée maximale |
|---|---|
| Travailleurs payés à l'heure ou à la journée | **8 jours** |
| Travailleurs payés au mois | **1 mois** |
| Agents de maîtrise, techniciens et assimilés | **2 mois** |
| Ingénieurs, cadres, techniciens supérieurs et assimilés | **3 mois** |
| **Cadres supérieurs** | **6 mois** |

**Règles qui vont avec, et qu'on oublie :**

1. L'essai est **stipulé obligatoirement par écrit**. Les dates de début, de fin et de
   renouvellement doivent être **indiquées par écrit**.
2. **Renouvelable une seule fois.**
3. **Le renouvellement se notifie par écrit AVANT la fin de l'essai**, avec un préavis :
   8 jours si l'essai est de 2 mois · 15 jours s'il est de 3 mois · 1 mois s'il est de 6 mois.
4. **Si l'employeur n'a pas prévenu dans ces délais** et veut quand même renouveler : soit il
   obtient l'accord du travailleur, soit il verse une **indemnité compensatrice** de 8 jours,
   15 jours ou 1 mois de salaire selon la durée.
5. Pendant l'essai, le travailleur reçoit **au moins le salaire minimum de la catégorie
   professionnelle** de l'emploi à pourvoir.
6. Rupture sans indemnité ni préavis de part et d'autre — **sauf** si l'essai a été renouvelé
   au-delà d'un mois ou si le travailleur a été déplacé par l'employeur : la rupture ouvre alors
   droit à une indemnité de préavis, et le travailleur déplacé au remboursement du voyage
   aller-retour.
7. **Article 15 : au-delà de la période d'essai, l'engagement est réputé définitif.** Et si
   l'employeur veut embaucher à des conditions autres que celles de l'essai, il les spécifie par
   écrit — elles ne peuvent en aucun cas être **moins avantageuses**.

⚠️ **Divergence non tranchée sur la date du décret n° 2024-900** : une source le date du
**16 octobre 2024**, une autre du **6 octobre 2024**, avec publication au Journal officiel le
13 février 2025. Le texte officiel n'a pas pu être ouvert (le dépôt qui l'héberge n'est pas
résolu depuis cette machine). **Citer le décret par son numéro, pas par sa date**, tant que ce
n'est pas confirmé.

---

## 3 bis · La classification et le minimum conventionnel — le chiffre opposable

C'est la pièce qui manquait jusqu'au 26/08/2026, et elle commande la lettre
d'engagement : sans catégorie, pas de salaire minimum légal, donc pas de contrat
régulier.

**Le mécanisme.** Chaque secteur d'activité a une grille de catégories, et chaque
catégorie a un montant plancher. Ce plancher se calcule ainsi :

    minimum en vigueur = barème catégoriel de 2015 × (1 + taux de revalorisation)

Le barème de 2015 couvre **tous les secteurs** (79 pages : industrie, bois,
textile, thon, polygraphie, hôtellerie, agriculture, sucre, transport, BTP,
commerce, banques, assurances, pétrole, recherche, transport de fonds, sécurité
privée, dockers, gens de maison). Les taux viennent de l'arrêté n° 0050.

**Les taux de revalorisation, lus dans l'arrêté** — prise d'effet au
1er janvier 2023, sur les 27 secteurs :

| Taux | Secteurs |
|---|---|
| **+18 %** | banque · assurance |
| **+15 %** | BTP et activités connexes · industrie de transformation du thon |
| **+14 %** | transport aérien |
| **+13 %** | industrie textile |
| **+12,5 %** | industrie mécanique, alimentaire, corps gras, chimique, transport · mines et carrières |
| **+12 %** | industrie polygraphique · industrie du bois · hôtellerie-tourisme · nettoyage et salubrité |
| **+11 %** | **commerce, distribution, négoce et professions libérales** · agricole, élevage, foresterie |
| **+10 %** | pétrole distribution · pétrole exploration-production · éducation-formation confessionnel |
| **+9 %** | auxiliaires du transport |
| variable | production agricole · gens de maison · dockers · sécurité privée · industrie du sucre · instituts de recherche · maritime pêche fraîche · enseignement privé laïc |

**Trois règles que l'arrêté pose lui-même :**
1. **Article 2** — les augmentations déjà octroyées depuis 2015 et les « à valoir »
   sur augmentations légales s'imputent sur le nouveau barème. Un employeur qui a
   augmenté entre-temps ne paie pas deux fois.
2. **Un employeur qui applique déjà un barème égal ou supérieur n'a rien à faire**
   (note explicative n° 1351/MEPS/CAB-00/CE-tna, signée du ministre).
3. **Article 3** — le barème s'étend aux secteurs **non régis** par la convention
   collective interprofessionnelle.

**Outil** : `python3 tools/smcc.py <secteur> [catégorie]`. Les grilles du commerce
et de la banque y sont saisies ; les autres secteurs renvoient au PDF archivé.

**🔴 Ce qu'un minimum conventionnel N'EST PAS.** Le plafond de la grille cadre du
commerce est à **230 918 FCFA** après revalorisation, et celui de la banque à
**235 304 FCFA**. Aucun cadre confirmé d'Abidjan ne signe à ce niveau. C'est un
**plancher légal opposable**, pas un repère de marché — le confondre avec une
proposition de rémunération, c'est faire une offre insultante en croyant citer un
texte. Les repères de marché se cherchent ailleurs (voir `canaux-sourcing-ci`).

⚠️ Une catégorie basse peut tomber **sous le SMIG** : la catégorie 1A du commerce
donne 66 600 FCFA après revalorisation, contre 75 000 de SMIG. Le SMIG l'emporte.
L'outil le signale.

⚠️ Divergence de date sur la convention interprofessionnelle : elle est datée du
**19 juillet 1977** sur le texte lui-même, du **20 juillet 1977** dans l'article 3
de l'arrêté n° 0050. Sans conséquence pratique, mais ne pas trancher.

---

## 4 · Le préavis (article 34 de la convention)

| Catégorie | Ancienneté | Préavis |
|---|---|---|
| Payés à l'heure ou à la journée | jusqu'à 6 mois | 8 jours |
| | 6 mois à 1 an | 15 jours |
| | 1 à 6 ans | 1 mois |
| | 6 à 11 ans | 2 mois |
| | 11 à 16 ans | 3 mois |
| | au-delà de 16 ans | 4 mois |
| Payés au mois, 5 premières catégories | jusqu'à 6 ans | 1 mois |
| | 6 à 11 ans | 2 mois |
| | 11 à 16 ans | 3 mois |
| | au-delà de 16 ans | 4 mois |
| **Classés en 6ᵉ catégorie et au-delà** (cadres) | au-delà de 16 ans | **2 fois le délai normal** |

Pendant le préavis, le travailleur peut s'absenter **3 heures par jour ou 2 jours par semaine**
pour chercher un emploi — heures payées et groupables en fin de préavis s'il ne les utilise pas.

**Pourquoi cela concerne le recrutement, et pas seulement la paie** : le préavis du candidat chez
son employeur actuel détermine **la date de prise de poste réaliste**. Un cadre confirmé, c'est un
à trois mois. Annoncer « prise de poste dès que possible » sans le demander en entretien produit
des dates fausses dans un plan de recrutement.

---

## 5 · Ce que coûte réellement un salarié

**Salaire minimum interprofessionnel garanti : 75 000 FCFA par mois**, depuis le
1er janvier 2023, décret n° 2022-986 du 21 décembre 2022 (relèvement de 25 %
depuis 60 000 FCFA). Soit **432,7 FCFA de l'heure** sur la base conventionnelle
de 173,33 heures — chiffre confirmé par l'arrêté n° 0050 lui-même, qui le cite
pour l'industrie du sucre.
⚠️ Une source secondaire donne « environ 914 FCFA/heure pour 40 h » : c'est faux
et facilement vérifiable — 75 000 ÷ 173,33 = 432,7. Ne pas la reprendre.

**Taux et plafonds** — _taux : document officiel CNPS « Recouvrement », lu le
13/08/2026. Répartition employeur/salarié et plafonds : CLEISS, organisme public
français de liaison de sécurité sociale, page à jour au 1er janvier 2025, lue le
26/08/2026 — <https://www.cleiss.fr/docs/cotisations/cotedivoire.html>_

| Branche | Employeur | Salarié | Plafond mensuel |
|---|---|---|---|
| Retraite | **7,70 %** | **6,30 %** | **3 375 000 FCFA** |
| Prestations familiales | 5 % | — | 70 000 à 75 000 FCFA ⚠️ |
| Assurance maternité | 0,75 % | — | 70 000 à 75 000 FCFA ⚠️ |
| Accidents du travail | 2 à 5 % selon le risque | — | 70 000 à 75 000 FCFA ⚠️ |
| Couverture maladie universelle | 500 FCFA | 500 FCFA | forfait |

**✅ La question ouverte depuis le 13/08/2026 est tranchée.** Le plafond retraite
est de **3 375 000 FCFA/mois** (45 fois le SMIG), pas 1 647 315. Ce dernier
chiffre est un **plafond historique de la fin des années 1990** : le guide de
l'assuré social de la CNPS donne un plafond annuel de 19 767 780 FCFA pour les
années 1996 à 1999, soit précisément 1 647 315 par mois. C'était vrai il y a
vingt-cinq ans. Un chiffre juste au mauvais millésime est un piège classique.

⚠️ **Ce qui reste non tranché** : le plafond des branches courtes. CLEISS donne
70 000 FCFA, d'autres sources 75 000. L'écart sur le coût total est d'environ
330 FCFA par mois. Le calculateur retient 75 000 pour ne pas sous-estimer.

⚠️ **Le décret qui fixe ces plafonds n'a pas été ouvert.** L'article 21 du Code de
prévoyance sociale renvoie expressément à un décret sans en donner les montants.
Ce qui précède vient d'une source publique sérieuse, pas du texte réglementaire.
Un chiffrage remis à un client porte cette réserve.

**Outil** : `python3 tools/cout-employeur.py <brut mensuel> [--at <taux>]`.
Ordre de grandeur pour un cadre à 850 000 FCFA brut avec un taux accidents à 3 % :
**922 512 FCFA de coût employeur, soit 8,5 % de surcoût**. Le surcoût est faible
en pourcentage sur les hauts salaires, parce que trois branches sur quatre sont
plafonnées très bas.

### L'impôt sur les traitements et salaires

✅ **Couvert depuis le 22/09/2026.** L'ordonnance n° 2023-719 du 13 septembre 2023, applicable au
1er janvier 2024, a refondu l'ITS : elle **supprime l'abattement de 20 %** et fonde l'impôt sur le
total des rémunérations brutes. Un impôt unique remplace les anciens impôts multiples :
**IS = impôt brut − réduction pour charges de famille**.

Barème mensuel progressif par tranches (article 119 bis du CGI) :

| Tranche de revenu mensuel (FCFA) | Taux |
|---|---|
| 0 à 75 000 | 0 % |
| 75 001 à 240 000 | 16 % |
| 240 001 à 800 000 | 21 % |
| 800 001 à 2 400 000 | 24 % |
| 2 400 001 à 8 000 000 | 28 % |
| au-dessus de 8 000 000 | 32 % |

Réduction d'impôt pour charges de famille, par mois : 1 part 0 · 1,5 part 5 500 · 2 parts 11 000 ·
2,5 parts 16 500 · 3 parts 22 000 · 3,5 parts 27 500 · 4 parts 33 000 · 4,5 parts 38 500 ·
5 parts 44 000. Le nombre de parts dépend de la situation matrimoniale et des enfants à charge.

_Sources lues et archivées dans `reference/droit-travail-ci/` : ordonnance n° 2023-719
(`ordonnance-2023-719-reforme-its.pdf`) et note DGI n° 00026/MFB/DGI/DLCD du 3 janvier 2024
(`dgi-note-00026-2024-precisions-its.pdf`), qui donne les exemples chiffrés._

⚠️ **L'océrisation de l'ordonnance comporte des coquilles** : elle donne 27 600 pour 3,5 parts,
là où la note DGI, plus lisible, retient **27 500**. En cas de doute sur un montant, la note DGI
tranche. C'est la raison pour laquelle les deux textes sont archivés.

**Outil** : `python3 tools/its-ci.py --net 450000` ou `--brut 600000`, avec `--parts`. Il fait la
conversion dans les deux sens et reproduit l'exemple officiel de la DGI (500 000 de brut → 81 000
d'impôt brut, 27 500 de réduction pour 3,5 parts). `tools/cout-employeur.py` affiche maintenant le
net après impôt en plus du coût employeur.

⚠️ Ce calcul couvre l'ITS et la retenue retraite. Il ne remplace pas un bulletin de paie : primes
en nature, avantages et contribution employeur n'y sont pas. Un chiffre destiné à un contrat se
fait confirmer par un comptable.

---

## Ce qui manque encore, et qui se demande

1. **Le décret fixant les plafonds de cotisation**, pour confirmer 3 375 000 et
   trancher 70 000 contre 75 000.
2. **Le texte officiel du décret n° 2024-900** (durées de période d'essai).
3. **Le régime du travail des étrangers** : permis de travail, visa, contrat
   d'expatrié. Situation réelle sur les postes techniques, où le meilleur profil
   vit souvent hors de Côte d'Ivoire.
4. **Les règles de rattachement d'un poste à une catégorie.** Le barème donne les
   montants par catégorie ; il ne dit pas comment ranger un intitulé donné dans une
   catégorie. Cette partie vit dans les conventions de branche elles-mêmes, dont
   seul le texte interprofessionnel a été trouvé en ligne.

## Provenance

Compétence écrite le 13/08/2026, complétée le 26/08/2026 (classification,
minimum conventionnel, plafonds CNPS tranchés). Sept textes archivés dans
`reference/droit-travail-ci/`. Outils : `tools/smcc.py`, `tools/cout-employeur.py`.
Voir aussi `referentiel-metier-recruteur`, `promesse-embauche`, `optimisation-offre`.
