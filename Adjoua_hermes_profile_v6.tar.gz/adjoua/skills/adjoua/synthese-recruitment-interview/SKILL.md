---
id: Y0255
name: synthese-recruitment-interview
description: "Étape 5 du processus : retrouver un ou plusieurs entretiens de recrutement dans le service d'enregistrement des réunions branché au poste (Fireflies, par les scripts de son dossier integrations), puis en faire le compte rendu selon le gabarit du recruteur (réponses critère par critère, verdict proposé, points à vérifier), ou la synthèse en trois onglets, avec un brouillon de courriel pour les évaluateurs. Règle absolue : rien qui ne soit explicitement dit dans la transcription. À charger pour tout compte rendu d'entretien, et avant tout comparatif fondé sur les entretiens."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 5 : Entretiens · Synthèse d'entretien

À charger quand un entretien a été enregistré et transcrit, ou quand on te demande de retrouver
des entretiens enregistrés. Sinon, c'est `evaluation-candidat` qui prend la suite à partir des
notes de l'évaluateur.

## ⛔ Contrôle avant remise (23/09/2026)

Avant d'envoyer un compte rendu d'entretien, vérifie que :

1. il suit **le gabarit du recruteur** (section suivante), un compte rendu par entretien ;
2. chaque appréciation sur un critère s'appuie sur **une réponse réellement donnée**, citée
   brièvement avec sa minute dans l'enregistrement ;
3. aucune phrase n'est attribuée au candidat sans que l'attribution des voix ait été vérifiée
   (voir « Retrouver les entretiens », point 4) ;
4. il sort en Google Doc avec son PDF, et ne va jamais sur une page publiée : il contient des
   données personnelles.

Un point en échec : tu corriges avant de remettre.

## Retrouver les entretiens enregistrés

Quand le poste a une intégration d'enregistrement des réunions (dossier
`integrations/fireflies/`, lis son `README.md`), tout passe par ses scripts, en lecture seule :

```bash
python3 integrations/fireflies/entretiens.py recents --max 50            # les dernières réunions
python3 integrations/fireflies/entretiens.py chercher --titre "<poste>" [--mot "<mot>"] [--depuis AAAA-MM-JJ]
python3 integrations/fireflies/entretiens.py lire <id> --sortie <fichier.json>
```

1. **Chercher large, puis trier à la main.** Le service ne sait pas ce qu'est un entretien de
   recrutement : une réunion se classe comme entretien sur son titre, puis sur son résumé.
   « Les dix derniers entretiens » veut dire les dix dernières réunions **classées comme
   entretiens**, pas les dix dernières réunions.
2. **Montrer la liste avant de produire** : titre, date, durée, pourquoi tu la classes comme
   entretien. Ce qui est douteux se pose en QCM. Tu dis combien tu as trouvé, et où tu as
   cherché.
3. **Lire la transcription en entier** avant d'écrire, pas le résumé automatique seul.
4. **Vérifier qui parle.** Le service peut attribuer toutes les phrases à une seule personne.
   Si les voix ne sont pas séparées de façon fiable, tu le dis en tête du compte rendu, et tu
   n'attribues au candidat que ce que le contexte rend certain (une réponse à une question
   posée, un récit à la première personne sur son propre parcours).
5. **Un enregistrement presque vide** (quelques phrases, durée très courte) ne donne pas de
   compte rendu : tu le signales et tu passes au suivant.
6. **Cloisonnement.** L'espace d'enregistrement appartient à une entreprise : ce qui en sort
   ne sert qu'elle. Les transcriptions se rangent dans son dossier client, jamais sur une page
   publiée.

## Le gabarit du compte rendu, pour un recruteur

Ce qu'un recruteur veut trouver, dans cet ordre, sur deux pages au plus :

| Section | Contenu |
|---|---|
| En-tête | candidat, poste, date, durée, qui a mené l'entretien, lien de l'enregistrement (interne) |
| Verdict proposé | en une ligne, go, à discuter ou non, avec les deux ou trois raisons qui le fondent |
| Réponses par critère | un tableau : critère du cadrage, ce que le candidat a répondu (citation courte et minute), appréciation, ce qui reste à vérifier |
| Indicateurs du poste | ce que le candidat a dit de la façon dont il atteindrait les indicateurs de la fiche de poste |
| Motivations et conditions | motivation pour le poste, disponibilité, préavis, attentes, seulement si elles ont été dites |
| Points de vigilance | ce qui inquiète, les contradictions avec le CV, les questions restées sans réponse |
| À vérifier en références | les points précis que les références devront éclairer |
| Prochaine étape proposée | formulée comme une proposition, la décision revient au recruteur |

Dans le tableau des critères, un critère qui n'a pas été abordé s'écrit « non abordé en
entretien » : c'est une exception voulue à la règle d'omission ci-dessous, parce que le
comparatif a besoin de savoir que la question n'a pas été posée, et que la formule ne laisse
pas croire que le candidat n'a pas su répondre. Les autres sections restent soumises à la
règle d'omission.

La présentation en trois onglets décrite plus bas reste disponible quand l'entreprise utilise
ce modèle, ou quand un tableau de bord d'entretien est demandé.

Plusieurs entretiens pour un même poste : un compte rendu par entretien, puis le comparatif
fondé sur les entretiens (`evaluation-candidat`).

Transposé de l'agent `Synthese_Recruitment_Interview` du corpus d'origine du client, prompt lu le
04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | La transcription de l'entretien, ou son identifiant dans le service d'enregistrement · la liste **exacte** des destinataires |
| **Livrable** | Le compte rendu au gabarit du recruteur (ou le tableau de bord à trois onglets) et un brouillon de courriel de synthèse |
| **Critère de réussite** | Zéro information absente de la transcription, zéro répétition entre onglets |
| **Point de sortie** | Vers `evaluation-candidat` pour la notation formelle |

## 🛑 Les trois règles absolues du prompt d'origine

### 1. Interdiction d'inventer : bloquant

Interdit : inventer ou déduire une information absente de la transcription · extraire des adresses
électroniques de la transcription · déduire une adresse depuis un nom ou une entreprise · afficher un
champ (type de contrat, durée, formation, salaire) qui n'a pas été mentionné explicitement.

**Si l'information est absente : ne pas afficher le champ.** Ne pas écrire « non renseigné », ne pas
mettre de tiret. Simplement l'omettre. Seule exception : un champ structurel obligatoire, qui porte
alors « à définir ».

C'est plus strict que ma règle habituelle du `⟦à confirmer⟧`, et c'est justifié ici : un tableau de
bord d'entretien criblé de « non renseigné » donne l'impression que le candidat n'a pas répondu,
alors que la question n'a pas été posée.

### 2. Interdiction de répétition entre onglets : critique

Chaque information n'apparaît **qu'une fois**. Chaque onglet a un contenu exclusif.

### 3. Une seule source pour les destinataires

Les adresses viennent de la liste fournie, jamais de la transcription.

## Les trois onglets

### Onglet 1 : Synthèse et recommandation

Un seul bloc unifié, sections séparées par de fines lignes, dans cet ordre :

1. Profil général en une ou deux phrases, avec le verdict go / à discuter / non, côte à côte.
2. Points clés de l'entretien, sur deux colonnes.
3. Une citation marquante, en italique.
4. **Pourquoi ce verdict**, en trois colonnes : adéquation au poste · adéquation culturelle ·
   conclusion.
5. Points d'attention, s'il y en a.
6. Apports concrets et prochaines étapes, côte à côte.

### Onglet 2 : Profil et expériences

Contenu exclusif : vision technique présentée · compétences maîtrisées · comportement et leadership ·
expériences professionnelles mentionnées.

⚠️ N'afficher que les sections pour lesquelles la transcription contient réellement quelque chose.

### Onglet 3 : Motivations et évaluation

Contenu exclusif : motivations pour le poste · intérêt pour l'entreprise · vision du rôle et
aspirations · signaux positifs et points à vérifier · forces principales.

⚠️ **Pas de points d'attention ici** : ils sont dans l'onglet 1. **Pas d'adéquation culturelle
séparée** : elle est intégrée à l'onglet 1.

## Le déroulé, étape par étape

Le prompt d'origine distingue les étapes **bloquantes** des autres. C'est ce qui évite de produire un
document à partir de rien.

| # | Étape | Bloquante | Ce qui s'y passe |
|---|---|---|---|
| 0 | Validation des entrées | **oui** | Vérifier la source de la transcription et la liste des destinataires : non vide, format valide, doublons retirés. Si la validation échoue, on s'arrête avec l'erreur précise |
| 1 | Récupération de la transcription | **oui** | Extraire titre, date, durée, participants, transcription complète. **Transcription vide ou inaccessible : on s'arrête.** Transcription courte, moins de 500 mots : avertissement et on continue |
| 2 | Analyse et structuration | non | Structurer : candidat · compétences · expériences · motivations · évaluation · verdict · apports · prochaines étapes. ⚠️ Ne structurer que ce qui est explicitement dit |
| 3 | Création du tableau de bord | **oui** | Partir du modèle existant et n'éditer que les données du candidat, pour que la structure et l'habillage soient préservés. À défaut de modèle, produire la page en respectant l'architecture décrite |
| 4 | Récupération du lien | **oui** | Conserver l'adresse partageable pour le courriel |
| 5 | Rédaction du courriel | non | Brouillon aux destinataires. **Si l'envoi échoue, ne pas s'arrêter** : rendre le lien du tableau de bord à partager à la main |
| 6 | Confirmation | non | Rendre compte de ce qui a été produit |

⚠️ **Règles de rendu** : pas de barres de progression ni de pourcentages · pas de champ vide ni de
« non renseigné » : on omet ce qui n'a pas été détecté.

## Courriel de synthèse

Brouillon destiné aux évaluateurs, reprenant le verdict, les points clés et les prochaines étapes,
avec le lien vers le tableau de bord. **À valider avant envoi.**

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## ⚠️ Dépendances

Le prompt d'origine part d'un service de transcription automatique de réunions et d'un automate qui
lui transmet les destinataires.

- **Le service de transcription** est ouvert quand le poste a le dossier
  `integrations/fireflies/` : on retrouve et on lit les enregistrements par ses scripts (section
  « Retrouver les entretiens enregistrés »). Sans ce dossier, je travaille sur une transcription
  qu'on me colle ou un fichier qu'on me transmet, et je dis que la collecte n'est pas branchée.
- **L'automate des destinataires** ne m'est pas ouvert : la liste des destinataires se donne à la
  main.

## Provenance

| | |
|---|---|
| Agent d'origine | `Synthese_Recruitment_Interview` |
| Version lue | v21 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 13098 caractères |
| Empreinte | `497b22629e7e` |

Prompt archivé dans `reference/prompts-dust/Synthese_Recruitment_Interview.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant remise ; retrouver les entretiens dans le service
  d'enregistrement par les scripts de l'intégration, en vérifiant qui parle ; gabarit de compte
  rendu pour un recruteur ; tirets cadratins remplacés, séance Sync agents training.
