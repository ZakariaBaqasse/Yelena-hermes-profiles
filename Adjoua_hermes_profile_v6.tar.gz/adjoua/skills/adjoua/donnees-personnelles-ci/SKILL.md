---
id: Y0676
name: donnees-personnelles-ci
description: "La protection des données à caractère personnel telle qu'elle s'applique en Côte d'Ivoire : loi n° 2013-450 du 19 juin 2013, autorité de contrôle ARTCI, déclaration préalable, autorisation pour six catégories, droits des personnes, sécurité, sanctions. Existe parce que le régime ivoirien n'est pas un RGPD local : il y a une formalité préalable que le RGPD a supprimée, le silence de l'autorité vaut rejet, et la prospection sans consentement est un délit pénal. Le RGPD reste traité, mais comme l'exception qu'il est ici."
bucket: C
tags: [Legal, Côte d'Ivoire, Horizontal]
version: 2
maj: 2026-09-23
---

# En Côte d'Ivoire, le texte applicable est la loi 2013-450, pas le RGPD

## Pourquoi cette compétence existe

Le réflexe, quand on parle de données personnelles, est de raisonner en RGPD : base légale,
registre, analyse d'impact, notification de violation en 72 heures. Servi à une entreprise
ivoirienne, ce réflexe produit un conseil qui se trompe sur l'essentiel.

Le régime ivoirien tient de la loi n° 2013-450 du 19 juin 2013 relative à la protection des
données à caractère personnel, publiée au Journal officiel du 8 août 2013. Il diffère du RGPD
sur quatre points qui changent ce qu'il faut faire :

1. **Il y a une formalité préalable.** Le RGPD l'a supprimée en 2018 ; la loi ivoirienne la
   maintient. Aucun traitement ne démarre sans déclaration, et certains sans autorisation.
2. **Le silence de l'autorité vaut rejet**, pas acceptation.
3. **La prospection sans consentement préalable est un délit**, puni d'emprisonnement.
4. **Le transfert hors du pays est soumis à autorisation**, pas à un mécanisme de garanties
   choisi par le responsable.

Un conseil qui ne dit pas ça n'est pas incomplet : il est faux.

## Ce qu'il faut avoir sous la main avant d'écrire

1. **L'entité** : nom, secteur, pays où elle opère réellement.
2. **Ce qu'elle traite** : quelles données, de qui, pourquoi, qui y accède, où c'est hébergé,
   combien de temps, quels sous-traitants, quels transferts hors de Côte d'Ivoire.
3. **Le livrable attendu** : registre des traitements, politique de confidentialité, dossier
   de déclaration ou d'autorisation ARTCI, accord de sous-traitance, procédure de réponse aux
   droits des personnes, audit de conformité, réponse à une violation.
4. **Si des personnes situées dans l'Union européenne sont concernées** : alors le RGPD
   s'ajoute au droit ivoirien. Il ne le remplace jamais.

## L'autorité, et son nom exact

Les missions d'autorité de protection sont confiées par l'**article 46** à l'autorité
administrative indépendante en charge de la régulation des télécommunications et des
technologies de l'information et de la communication, soit l'**ARTCI**. Il n'existe pas
d'autorité distincte : l'ARTCI est le régulateur télécoms **et** l'autorité de protection.
Écrire « la CNIL ivoirienne » ou nommer une autorité séparée est une erreur de fait.

## Les formalités, dans l'ordre

### Le principe : déclaration préalable (art. 5)

Tout traitement est soumis à **déclaration préalable auprès de l'ARTCI**. La déclaration
comporte l'engagement que le traitement satisfait aux exigences de la loi. L'ARTCI délivre un
récépissé, le cas échéant par voie électronique. **Le demandeur peut mettre en œuvre le
traitement dès réception du récépissé**, et le récépissé ne l'exonère d'aucune de ses
responsabilités.

Plusieurs traitements d'un même organisme répondant à des finalités identiques ou liées
peuvent faire l'objet d'une **déclaration unique**.

### Les dispenses (art. 6)

Quatre cas sont dispensés de déclaration :

- traitement par une personne physique dans le cadre exclusif de ses activités personnelles,
  domestiques ou familiales ;
- traitement dont la publication est prescrite par une disposition légale ou réglementaire ;
- traitement ayant pour seul objet la tenue d'un registre destiné à un usage exclusivement
  privé ;
- traitement pour lequel le responsable a désigné un **correspondant à la protection des
  données**, chargé d'assurer de manière indépendante le respect des obligations de la loi.
  ⚠ Cette dispense **tombe** dès qu'un transfert vers un pays tiers est envisagé.

Le statut du correspondant est à l'**article 12** : qualifications requises, liste tenue par
l'ARTCI, et surtout il **ne peut faire l'objet d'aucune sanction de son employeur du fait de
l'accomplissement de ses missions**. Sa désignation est notifiée à l'ARTCI et portée à la
connaissance des instances représentatives du personnel.

### L'autorisation préalable (art. 7)

Six catégories exigent une **autorisation**, pas une simple déclaration, **avant toute mise
en œuvre** :

1. données génétiques, médicales, et recherche scientifique ;
2. données relatives aux infractions, condamnations ou mesures de sûreté ;
3. traitement portant sur un numéro national d'identification ou tout identifiant de même
   nature, **y compris les numéros de téléphone** ;
4. données biométriques ;
5. traitement d'intérêt public, notamment à des fins historiques, statistiques ou
   scientifiques ;
6. **transfert de données à destination d'un pays tiers**.

⚠ Le point 3 attrape bien plus d'entreprises qu'on ne le croit : un fichier client construit
autour du numéro de téléphone, ce qui est la norme dans la région, relève de l'autorisation.
Ne jamais classer un tel fichier en simple déclaration sans avoir posé la question.

### Le délai, et le piège (art. 11)

L'ARTCI se prononce dans un délai d'**un mois** à compter de la déclaration ou de la demande,
**prorogeable d'un mois** sur décision motivée.

⛔ **L'absence de réponse dans le délai imparti vaut REJET.** C'est l'inverse du réflexe
administratif courant. Un dossier sans réponse au bout de deux mois n'est pas un dossier
accepté : c'est un dossier rejeté, contre lequel le responsable peut exercer un recours devant
la juridiction compétente.

La déclaration ou la demande peut être adressée **par voie électronique**, par voie postale,
ou par tout moyen contre remise d'un accusé de réception (art. 10).

Toute modification des mentions déclarées (identité, finalités, données, destinataires, durée,
sécurité, sous-traitant, transferts) doit être **portée à la connaissance de l'ARTCI** (art. 9).

## Les principes de fond

| Principe | Article | Ce qu'il impose |
|---|---|---|
| Consentement | **14** | Le traitement est légitime si la personne donne **expressément** son consentement **préalable**. Quatre dérogations : obligation légale, mission d'intérêt public ou d'autorité publique, exécution d'un contrat ou de mesures précontractuelles prises à la demande de la personne, sauvegarde de son intérêt ou de ses droits et libertés fondamentaux |
| Licéité et loyauté | **15** | Collecte, enregistrement, traitement, stockage, transmission et interconnexion se font de manière licite et loyale |
| Finalité | **16** | Finalités déterminées, explicites et légitimes ; pas de traitement ultérieur incompatible ; données adéquates, pertinentes et non excessives ; conservation limitée à la durée nécessaire |
| Exactitude | **17** | Données exactes, complètes, mises à jour ; effacement ou rectification de ce qui est inexact |
| Transparence | **18** | Information obligatoire et claire de la part du responsable |
| Confidentialité | **19** | Données confidentielles et protégées, en particulier lors de transmissions en réseau |
| Sous-traitance | **20** et **40** | Le responsable choisit un sous-traitant qui apporte des garanties suffisantes. La responsabilité pèse sur **les deux** |

## Les deux interdits pénaux, à citer tels quels

⛔ **Article 21, données sensibles.** Il est interdit de collecter et de traiter les données
qui révèlent l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques,
les convictions religieuses ou philosophiques, l'appartenance syndicale, la vie sexuelle ou,
généralement, l'état de santé. Peine : **dix à vingt ans d'emprisonnement et 20 000 000 à
40 000 000 francs CFA d'amende** (texte du Journal officiel, art. 21).

L'interdiction tombe dans des cas limitativement énumérés par l'article : données
manifestement rendues publiques par la personne ; données génétiques ou de santé nécessaires à
la sauvegarde de ses intérêts vitaux quand elle est dans l'incapacité physique ou juridique de
consentir ; constatation, exercice ou défense d'un droit en justice ; procédure judiciaire ou
enquête pénale ; activités légitimes d'une fondation, association ou organisme à but non
lucratif à finalité politique, philosophique, religieuse, mutualiste ou syndicale, à la double
condition que le traitement porte sur les seuls membres et que rien ne soit communiqué à des
tiers sans leur consentement.

⛔ **Article 22, prospection directe.** Il est interdit de faire de la prospection directe, par
tout moyen de communication, en utilisant les données d'une personne physique **qui n'a pas
exprimé son consentement préalable à recevoir des prospections**. Peine : **un à cinq
ans d'emprisonnement et 1 000 000 à 10 000 000 francs CFA d'amende** (art. 22).

⚠ C'est la disposition que les projets de prospection heurtent le plus souvent. Une base de
numéros achetée, collectée en salon, aspirée d'un annuaire ou extraite d'un groupe de
messagerie **ne porte pas de consentement**. Avant d'écrire une séquence de prospection, la
question n'est pas « quel message » mais « d'où vient ce numéro et qu'a accepté son
titulaire ». Cela vaut pour le message texte, le message vocal, l'appel et le courriel.

## Les droits des personnes

| Droit | Article | Ce qu'il faut pouvoir faire |
|---|---|---|
| Information | **28** | Fournir, **au plus tard lors de la collecte** : identité du responsable, finalités, catégories de données, destinataires, possibilité de refuser de figurer au fichier, existence du droit d'accès et de rectification, durée de conservation, éventualité d'un transfert vers un pays tiers |
| Accès | **29** | Confirmer si des données sont traitées, les communiquer avec leur origine, dire les finalités, les catégories et les destinataires. Le responsable peut refuser une demande **manifestement abusive**, mais **la charge de la preuve de l'abus lui incombe** |
| Opposition | **30** | S'opposer pour motif légitime ; s'opposer **gratuitement** à un traitement à des fins de prospection ; être informé **avant** la première communication à des tiers à des fins de prospection, et pouvoir s'y opposer gratuitement |
| Rectification | **31** | Rectifier, compléter, mettre à jour, verrouiller ou supprimer les données inexactes, incomplètes, équivoques ou périmées |
| Effacement | **33 à 37** | Effacer et faire cesser la diffusion, en particulier pour des données rendues disponibles **quand la personne était mineure**. Motifs : données plus nécessaires, consentement retiré, délai de conservation expiré, opposition sans motif légal contraire, traitement non conforme |
| Portabilité | **38** | Remettre une copie dans un format électronique structuré et couramment utilisé, et ne pas faire obstacle à la transmission vers un autre système |

Deux précisions à ne pas manquer :

- **L'effacement se fait sans délai** (art. 35), sauf si la conservation est nécessaire à la
  liberté d'expression, à un motif d'intérêt général de santé publique, ou à une obligation
  légale de conservation.
- Quand le responsable a **rendu les données publiques**, il doit prendre toutes mesures
  raisonnables, y compris techniques, pour informer les tiers qui les traitent de la demande
  d'effacement des liens, copies et reproductions (art. 34).

## La sécurité, telle que la loi la formule

L'**article 41** énumère les mesures attendues. Ce n'est pas une liste de bonnes pratiques :
c'est le texte, et un audit se construit dessus.

- empêcher l'accès non autorisé aux installations ;
- empêcher la lecture, la copie, la modification ou le déplacement non autorisés des supports ;
- empêcher l'introduction non autorisée de données, ainsi que la prise de connaissance, la
  modification ou l'effacement non autorisés de ce qui est enregistré ;
- empêcher l'usage des systèmes par des personnes non autorisées via des installations de
  transmission ;
- empêcher l'usage des systèmes à des fins de blanchiment de capitaux et de financement du
  terrorisme ;
- garantir que les personnes autorisées n'accèdent qu'aux données relevant de leur
  autorisation ;
- garantir que l'identité des tiers destinataires puisse être vérifiée et constatée ;
- garantir la **traçabilité a posteriori** : qui a accédé, quelles données ont été introduites,
  modifiées, effacées, altérées, copiées ou lues, et à quel moment ;
- empêcher la lecture, la copie, la modification ou l'effacement non autorisés lors de la
  communication et du transport de supports ;
- sauvegarder les données par des copies de sécurité protégées.

S'y ajoutent : le traitement est **confidentiel** et effectué exclusivement par des personnes
agissant sous l'autorité du responsable et sur ses instructions (art. 39) ; le responsable
établit un **rapport annuel** pour l'ARTCI sur le respect de l'article 41 (art. 42) ; les
durées de conservation sont fixées par l'ARTCI selon les finalités de chaque type de
traitement (art. 43).

## Les transferts hors de Côte d'Ivoire

**Article 26.** Le transfert vers un pays tiers n'est possible que si ce pays assure un
**niveau de protection suffisant** de la vie privée et des libertés et droits fondamentaux.
Et, avant tout transfert, le responsable doit **obtenir préalablement l'autorisation de
l'ARTCI**.

⚠ Conséquence pratique que l'on oublie : héberger chez un fournisseur infonuagique étranger,
utiliser un outil de gestion de la relation client hébergé hors du pays, faire traiter une paie
par un prestataire étranger, tout cela est un transfert. Le sujet se pose au moment du choix de
l'outil, pas au moment de l'audit.

L'**interconnexion de fichiers** (art. 27) n'est autorisée que si elle sert des objectifs
légaux ou statutaires présentant un intérêt légitime, ne produit ni discrimination ni réduction
des droits, et s'accompagne de mesures de sécurité appropriées.

## Les sanctions

| Qui | Article | Quoi |
|---|---|---|
| ARTCI, premier niveau | **49** | Avertissement ; mise en demeure de faire cesser les manquements dans un délai qu'elle fixe |
| ARTCI, violation des droits et libertés | **50** | Après procédure contradictoire : interruption du traitement, verrouillage de certaines données, interdiction temporaire ou définitive |
| ARTCI, après mise en demeure | **51** | Retrait provisoire ou définitif de l'autorisation ; sanction pécuniaire **plafonnée à 10 000 000 FCFA**. En cas de manquement réitéré dans les cinq ans suivant une sanction devenue définitive : jusqu'à **100 000 000 FCFA**, ou pour une entreprise **5 % du chiffre d'affaires hors taxes du dernier exercice clos, dans la limite de 500 000 000 FCFA** |
| Pénal | **21, 22, 45** | Peines d'emprisonnement et amendes, **sans préjudice** des sanctions administratives |

L'article 45 punit d'un mois à deux ans d'emprisonnement et de 1 000 000 à 10 000 000 FCFA le
fait d'entraver l'action de l'ARTCI : s'opposer à ses missions, refuser de communiquer ou
dissimuler des documents, ou communiquer des informations non conformes aux enregistrements.
Le procureur de la République est informé sans délai de ces entraves.

## Où sont les textes

Base locale : `~/.claude/outils-communs/donnees-personnelles-ci/`

| Fichier | Texte |
|---|---|
| `loi-2013-450-donnees-personnelles.pdf` | Loi n° 2013-450 du 19/06/2013, **Journal officiel du 8 août 2013, pages 474 à 482** |
| `loi-2013-450-copie-onudc.pdf` | La même loi, autre numérisation |
| `loi-2013-451-cybercriminalite.pdf` | Loi n° 2013-451 du 19/06/2013 relative à la lutte contre la cybercriminalité |
| `loi-2013-546-transactions-electroniques.pdf` | Loi n° 2013-546 du 30/07/2013 relative aux transactions électroniques |

⛔ **Ces quatre fichiers sont des scans sans couche texte.** Aucune recherche plein texte n'y
fonctionne, et une extraction rend une page vide. On les **ouvre et on les lit** ; c'est
d'ailleurs la seule façon correcte de citer un article. La correspondance article vers page est
donnée ci-dessous.

| Articles | Page du Journal officiel | Page du PDF |
|---|---|---|
| 1 à 3 (définitions, champ) | 474 à 476 | 1 à 3 |
| 4 à 13 (formalités) | 476 à 477 | 3 à 4 |
| 14 à 25 (principes, interdits) | 477 à 478 | 4 à 5 |
| 26 à 38 (transferts, droits) | 479 à 480 | 6 à 7 |
| 39 à 45 (obligations, sécurité) | 480 à 481 | 7 à 8 |
| 46 à 54 (ARTCI, sanctions, final) | 481 à 482 | 8 à 9 |

## Ce que cette compétence ne couvre pas

- **Les décrets d'application** et les délibérations de l'ARTCI, qui fixent le détail des
  procédures de déclaration et d'autorisation, les durées de conservation par finalité, et les
  conditions du transfert transfrontalier. Ils ne sont pas dans la base locale. ⟦à récupérer⟧
- **Les normes simplifiées** que l'article 8 permet à l'ARTCI d'édicter pour les catégories les
  plus courantes de traitement, et qui peuvent exonérer de déclaration.
- **Le régime sectoriel** : santé, secteur bancaire, télécommunications, dont les textes
  propres s'ajoutent à celui-ci.
- **Le RGPD lui-même**, traité par la compétence `rgpd-data-protection`, qui reste la bonne
  porte dès que des personnes situées dans l'Union européenne sont concernées.
- **L'acte additionnel A/SA.1/01/10 de la CEDEAO** du 16 février 2010, que cette loi transpose.

## Trois réflexes qui évitent les erreurs qu'on voit le plus

1. **Demander d'où viennent les numéros avant d'écrire une prospection.** L'article 22 est
   pénal, et une base sans consentement ne se rattrape pas par la qualité du message.
2. **Compter le délai de l'article 11 depuis le dépôt, et traiter le silence comme un rejet.**
   Un client qui « attend la réponse de l'ARTCI » depuis trois mois est un client dont le
   dossier est rejeté.
3. **Citer l'article, ouvrir le scan, vérifier.** Le texte de cette compétence est un guide de
   lecture, pas la loi. Pour tout ce qui engage un client, la vérification se fait sur le
   Journal officiel, et le conseil opposable vient d'un avocat.

## Historique

- v2, 23/09/2026 : peines des articles 21 (dix à vingt ans) et 22 (un à cinq ans) corrigées sur le texte de la loi 2013-450, `~/.claude/outils-communs/donnees-personnelles-ci/loi-2013-450-donnees-personnelles.txt`, lignes 773 et 800. La v1 les minorait.
