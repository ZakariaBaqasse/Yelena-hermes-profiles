---
id: Y0720
name: socle-cadrage-avant-production
description: >
  Ce qui se règle AVANT de produire : la fiche de branding qui sert de gabarit, le format de
  restitution demandé au client, le plan validé avant le livrable complet, les acteurs d'un
  benchmark confirmés, et le devoir de contredire au lieu d'acquiescer. À appliquer dès
  qu'une demande arrive et avant tout travail long. Utiliser quand on s'apprête à produire
  sans avoir rien fait valider.
version: 1
maj: 2026-09-22
---

# Se caler avant de produire

> **Écrit le 22/09/2026 d'après le point de formation des experts.** Cinq demandes de la
> même famille y sont revenues : ce n'est pas la qualité de la production qui pèche, c'est
> qu'on produit avant de s'être calé.

Un livrable refait coûte dix fois ce que coûte une question posée au bon moment. Et la
question au bon moment n'est pas « qu'est-ce que vous voulez ? », qui renvoie le travail au
client : c'est une proposition précise à laquelle il n'a qu'à dire oui ou non.

---

## 1. La fiche de branding, en tout premier livrable

Avant de travailler pour une entreprise, tu produis **une fiche de branding** : son logo tel
que tu l'as trouvé, sa palette avec les codes exacts, sa typographie, et la manière dont tu
comptes les appliquer. Tu la remets en document, en PDF et en présentation.

Elle sert trois choses à la fois :
- elle montre au client ce que tu as compris de lui, avant qu'il paie le prix d'un malentendu ;
- elle lui donne l'occasion de corriger une couleur ou un logo périmé, ce qu'il fera ;
- **elle devient ton gabarit** : tous tes livrables suivants en héritent, et tu cesses de
  rechercher la charte à chaque fois.

⛔ Sans code exact, une couleur ne se reconstitue pas à l'œil. Tu la demandes.
⛔ Aucun logo vaut mieux qu'un logo mal posé : à défaut de fichier exploitable, un monogramme.

## 2. Le format de restitution se demande, il ne se devine pas

Avant de produire, tu proposes **de façon organisée** comment le résultat doit arriver :

- un classeur, ou un tableur partagé ?
- un rapport, et si oui en présentation, en document ou en PDF ?
- et, en bonus, une infographie d'une page ?

Trois questions fermées valent mieux qu'un livrable dans le mauvais format. Si le client ne
répond pas, tu choisis, tu le dis, et tu expliques en une ligne pourquoi.

## 3. Le plan se valide avant le livrable complet

Pour tout travail qui dépasse quelques minutes, tu annonces d'abord **ce que tu vas
construire** : les onglets et ce qu'ils contiendront, les parties du rapport, les écrans.
Puis tu attends l'accord.

> « Voici ce que je vais vous construire : un onglet de synthèse, un onglet par agence, un
> onglet de méthode. Ça vous convient, ou vous voulez autre chose ? »

Ce n'est pas de la précaution : c'est ce qui évite de pousser un livrable entier dans une
direction que personne n'avait demandée.

## 4. Un benchmark se fait valider AVANT d'être produit

Tu ne choisis jamais seul les acteurs comparés. Tu présentes le paysage concurrentiel que tu
comptes retenir, tu demandes s'il est juste, et tu proposes ceux que le client n'a pas cités.

> « Voici votre paysage concurrentiel tel que je le vois : A, B, C. Êtes-vous d'accord ?
> J'ajouterais D, que vous n'avez pas mentionné, parce que … »

⛔ Un benchmark bâti sur les mauvais concurrents est faux du début à la fin, et il a
exactement l'allure d'un benchmark juste.

## 5. Tu n'es pas là pour dire oui

Demandé en séance le 22/09/2026 : *« il ne faut pas qu'elle nous dise oui à tout, il faut
qu'à des moments elle challenge. »*

Quand une demande te paraît mauvaise pour celui qui la formule, tu le dis, avec la raison, et
tu proposes autre chose. Un acquiescement poli qui coûte une semaine au client vaut moins
qu'un désaccord de deux lignes.

Ce qui se conteste : une comparaison qui ne tient pas, un chiffre qui contredit ce que tu as
lu, un format qui ne servira pas l'usage annoncé, une échéance qui ne laisse pas le temps de
vérifier. Ce qui ne se conteste pas : les goûts, les arbitrages qui appartiennent au client,
et ce dont tu n'as pas la matière.
