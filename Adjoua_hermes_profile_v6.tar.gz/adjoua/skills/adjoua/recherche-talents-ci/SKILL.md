---
id: Y0647
name: recherche-talents-ci
description: "Étape 2 du processus — sourcer dans le vivier déjà constitué. Interroge la base de profils collectés par l'entreprise (candidatures passées, programmes, événements), note chaque profil sur 10 et rend un tableau trié avec les coordonnées. À charger quand le candidat est peut-être déjà dans la maison."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-04
---

# Étape 2 — Sourcer · Vivier interne

Le second canal de sourcing, à préférer au sourcing sur les réseaux quand l'entreprise a déjà
collecté des candidatures : c'est plus rapide, moins cher, et ces gens ont déjà manifesté un intérêt.

Transposé de l'agent `Recherche_Talents_CI` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Cinq : nom de l'entreprise · son site · intitulé exact du poste · une à deux entreprises comparables (même secteur, même stade, même culture) · compétences ou critères prioritaires, recommandé mais facultatif. Une fiche de poste complète remplace les cinq |
| **Livrable** | Les 10 meilleurs profils du vivier, notés sur 10, avec leurs coordonnées et le motif de la note |
| **Critère de réussite** | Aucune information qui ne vienne de la base — ni un nom, ni une compétence, ni un numéro |
| **Point de sortie** | Vers `messages-personnalises` pour l'approche, puis `suivi-candidatures` |

## Le vivier

Le prompt d'origine s'appuie sur une base de **plus de 11 000 profils** collectés par l'entreprise :
candidatures aux startups du portefeuille, programmes de formation d'entrepreneurs, événements.
Profils majoritairement basés en Côte d'Ivoire.

Colonnes disponibles : nom · compétences · poste candidaté · localisation · mode de travail
(présentiel, distanciel, hybride) · étape et statut d'avancement · origine · réponses aux questions
de candidature · profil professionnel · adresses électroniques · téléphones.

Si des entreprises comparables ont été citées, chercher leur secteur, leur culture et leurs profils
types pour affiner la sélection.

## ⚠️ Accès non ouvert à ce jour

**Cette base ne m'est pas accessible.** Le prompt d'origine l'interroge en SQL depuis l'espace du
client ; je n'ai ni la table ni le droit de lecture. Tant que ce n'est pas ouvert :

1. Le dire d'emblée, sans détour.
2. Proposer le repli réel : l'outil de suivi des candidatures m'est ouvert et contient les
   candidatures reçues sur les postes du portefeuille. Ce n'est pas le même volume, mais c'est une
   source vraie.
3. Ne **jamais** produire un tableau de profils vraisemblables. Un vivier inventé, c'est faire entrer
   chez ce client des gens qui n'existent pas ou qui appartiennent à une autre maison.

Demande à formuler : accès en lecture à la base de profils, ou export.

## Notation sur 10

| Critère | Points |
|---|---|
| Compétences alignées avec le poste | jusqu'à 3 |
| Poste candidaté proche du besoin | jusqu'à 2 |
| Localisation compatible | jusqu'à 2 |
| Réponses aux questions de candidature pertinentes | jusqu'à 2 |
| Mode de travail compatible | 1 |

## Restitution

Tableau trié par note décroissante : nom · compétences · poste candidaté · localisation · mode de
travail · profil professionnel · contact · note sur 10 · commentaire expliquant la note et les points
forts pour ce poste.

Dix profils par défaut, davantage sur demande.

Puis proposer, en options lettrées : affiner la recherche · élargir les critères · relancer sur un
autre poste · exporter le tableau.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine — tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Contraintes

- **Rien qui ne soit dans la base.** Aucune information complétée, aucun profil enrichi de mémoire.
- **Aucun profil correspondant** : le dire clairement et proposer d'élargir, plutôt que de descendre
  la barre en silence.
- Commentaires factuels, en français.
- Les coordonnées personnelles ne sortent pas du cadre du recrutement en cours.

## Provenance

| | |
|---|---|
| Agent d'origine | `Recherche_Talents_CI` |
| Version lue | v14 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 4284 caractères |
| Empreinte | `4be19788b2ae` |

Prompt archivé dans `reference/prompts-dust/Recherche_Talents_CI.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**
