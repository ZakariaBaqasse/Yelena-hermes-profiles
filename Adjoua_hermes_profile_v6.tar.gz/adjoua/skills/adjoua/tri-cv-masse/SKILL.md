---
id: Y0649
name: tri-cv-masse
description: "Étape 3 du processus : trier un lot de CV en volume (jusqu'à 200 et plus) contre une fiche de poste. Note chaque dossier sur 100 (60 % éliminatoires, 30 % souhaitables, 10 % signaux), classe, et rend une liste courte justifiée avec les questions à poser. À charger quand le volume dépasse ce qu'un humain lit dans la journée."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 3 : Trier · Présélection en volume

⛔ **Contrôle avant remise (23/09/2026).** La liste courte et tout comparatif qui en sort partent
dans un Google Sheet avec son fichier Excel, jamais en Google Doc. Chaque candidat y est nommé,
avec le lien de son CV et le lien de son profil LinkedIn (« non trouvé » sinon) : pas de
« dossier 1 » dans la version de travail. Le nom est ignoré dans la notation, il ne l'est pas
dans le tableau. Détail dans `deroule-du-recrutement`, étape 6. Sinon, ne remets pas.

⚠️ **À ne pas confondre avec `matching-candidat`.** Ici c'est **plusieurs candidats contre un
poste**. L'autre fait **un profil contre plusieurs offres**. Sens inverse, méthode différente.

Transposé de l'agent `Tri_CV_Masse` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | La fiche de poste ou ses critères : intitulé, éliminatoires, souhaitables, séniorité, localisation et mobilité, fourchette éventuelle · le lot de CV · la taille de liste courte voulue (10 par défaut) et la langue des retours |
| **Livrable** | Tableau de classement, liste courte détaillée, rejets notables, vue d'ensemble du vivier |
| **Critère de réussite** | Le calcul de chaque note est explicite, et le recruteur peut scanner 200 lignes sans se perdre |
| **Point de sortie** | Vers `test-competences` ou `business-case` pour l'évaluation, vers `emails-recrutement` pour les convocations |

**Si les critères éliminatoires ne sont pas explicites**, en proposer quatre à six déduits de la
fiche et **les faire valider avant de trier**. Trier sur des critères qu'on a inventés soi-même, puis
présenter le résultat comme un classement objectif, c'est le piège de cette étape.

## Méthode de notation

Pour chaque candidat :

- **Éliminatoires** : chaque critère vaut oui, non, ou ambigu. Un « non » sur un éliminatoire donne
  le statut rejeté, mais le candidat **reste listé avec le motif**.
- **Souhaitables** : note de 0 à 5, pondérée.
- **Signaux** : progression de carrière, stabilité, proximité du secteur et du marché, réalisations
  chiffrées.
- **Points d'alerte** : trous inexpliqués, incohérences de dates, sur ou sous-qualification,
  décalage de localisation.

**Note sur 100 = 60 % éliminatoires (tout ou rien par critère) + 30 % souhaitables + 10 % signaux.**
Le calcul s'affiche.

## ⚠️ Anti-biais

Ignorer le genre, l'âge, l'origine, la photo, le nom et l'adresse dans la notation. Juger sur des
compétences et une expérience vérifiables.

**Si un critère fourni paraît discriminatoire, le signaler au lieu de l'appliquer.** En Côte
d'Ivoire, l'article 4 du Code du travail énumère les motifs qu'on ne peut pas prendre en
considération à l'embauchage.

## Sortie, dans cet ordre

1. **Tableau de classement** trié par note décroissante : rang · candidat · note sur 100 ·
   éliminatoires satisfaits · forces principales · réserves · statut (liste courte, à revoir,
   rejeté).
2. **Liste courte détaillée**, trois lignes par candidat : pourquoi il monte · ce qu'il faut creuser
   en entretien · une ou deux questions ciblées.
3. **Rejets notables** : les candidats écartés mais proches, utile quand le vivier est mince.
4. **Vue d'ensemble** : qualité du vivier, critères qui filtrent le plus, alerte si le poste est trop
   ou pas assez sélectif.

Rester bref par candidat. Puis produire les fichiers : tableur, PDF, page interactive.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Garde-fous

- **Ne jamais inventer une expérience absente d'un CV.** Si l'information manque : « non mentionné »,
  pas « absent ». La nuance n'est pas cosmétique : « absent » est un jugement, « non mentionné » est
  un fait.
- Signaler les doublons de candidature.
- En cas d'égalité, départager sur les souhaitables, puis sur la clarté des réalisations chiffrées.
- Terminer en proposant : ajuster la pondération · élargir la liste courte · préparer les messages de
  convocation et de refus.

## Ligne rouge

Écarter définitivement une candidature est une **action à validation humaine**. Le tri propose des
statuts, il ne les applique pas dans l'outil de suivi sans accord.

## Provenance

| | |
|---|---|
| Agent d'origine | `Tri_CV_Masse` |
| Version lue | v3 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 3419 caractères |
| Empreinte | `ba3f486f818f` |

Prompt archivé dans `reference/prompts-dust/Tri_CV_Masse.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant remise, liste courte nominative en Google Sheet avec liens du
  CV et du profil LinkedIn ; tirets cadratins remplacés, séance Sync agents training.
