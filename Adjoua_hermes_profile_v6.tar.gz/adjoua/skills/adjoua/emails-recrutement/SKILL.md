---
id: Y0220
name: emails-recrutement
description: "Rédige tous les courriels du cycle de recrutement en voix employeur : approche candidat, invitation à un entretien, relance de planning, suivi après entretien, offre, refus, approche entrepreneur en résidence ou cofondateur. Deux variantes et deux objets à chaque fois. Aucun envoi automatique. Dès que les messages visent plusieurs candidats (campagne d'approche, invitations, refus en série), ils sortent OBLIGATOIREMENT dans un Google Sheet avec les colonnes e-mail, LinkedIn et WhatsApp. Sert aux étapes 2 et 6."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étapes 2 et 6 : Écrire aux candidats

Cette compétence sert deux fois dans le processus : à l'approche, et à la clôture (offre, refus).

Transposé de l'agent `Emails_Recrutement` du corpus d'origine du client, prompt lu le 04/08/2026.

## ⛔ Contrôle avant remise : plusieurs destinataires, un Google Sheet (23/09/2026)

Demandé le 22/09, redemandé le 23/09 parce que les messages sortaient encore en Google Doc.
Dès que des messages visent **plusieurs candidats**, avant d'envoyer, vérifie qu'ils sont dans
un **Google Sheet** (avec son fichier Excel), une ligne par candidat, avec au minimum :
nom, e-mail, lien LinkedIn, numéro WhatsApp, objet, message par canal, statut d'envoi.

- Une coordonnée connue est remplie ; une coordonnée inconnue laisse **la case vide**, et
  c'est le recruteur qui la complète. Jamais une adresse ou un numéro deviné.
- Les deux variantes et les deux objets restent dus : ils prennent deux colonnes.
- Pour les cinq premiers destinataires, tu affiches aussi les messages dans la conversation,
  sous le lien du Sheet.

Sinon, ne remets pas. Le détail des colonnes est dans `deroule-du-recrutement`, étape 5.

🔒 **On n'envoie jamais.** On produit des brouillons qu'un humain relit, valide et envoie. Cette
phrase est dans le prompt d'origine, elle n'est pas un ajout de ma part.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Type de courriel · le poste : intitulé, séniorité, contexte, lieu, ce qui le rend attractif · le candidat : nom, poste actuel, **pourquoi lui**, avec un signal concret · l'expéditeur · la langue · le ton · l'action attendue |
| **Livrable** | Deux variantes rédigées et deux objets, prêtes à copier |
| **Critère de réussite** | La personnalisation repose sur un fait réel du parcours du candidat, pas sur une flatterie interchangeable |
| **Point de sortie** | Validation humaine, puis envoi par un humain |

## Stratégie par type

| Type | Ce qui fait la différence |
|---|---|
| **Approche** | Très court, très personnalisé : pourquoi lui. Pourquoi l'entreprise : mission, impact, traction. Une seule proposition, douce : « quinze minutes pour en parler ? » Jamais de message interchangeable |
| **Invitation à un entretien** | L'étape, la durée, le format, les interlocuteurs, des créneaux proposés, le lien |
| **Relance de planning** | Rappel bref, nouveaux créneaux, pas de reproche |
| **Suivi après entretien** | Remerciement, prochaines étapes, délai annoncé |
| **Offre** | Enthousiasme, éléments clés : poste, démarrage, grandes lignes, **montants entre crochets, jamais inventés**, prochaines étapes et délai de réponse |
| **Refus** | Respectueux, précis si possible, porte laissée ouverte |
| **Entrepreneur en résidence ou cofondateur** | Vendre l'aventure : construire depuis zéro, capital, accompagnement du studio, portefeuille. Filtrer sur l'ambition. Ton direct et inspirant |

## Rédaction

- **Deux variantes, deux objets**, à chaque fois.
- Personnalisation réelle : une référence au parcours du candidat.
- Court, structuré, lisible sur téléphone. Une seule action demandée.
- **Crochets pour tout élément factuel** : salaire, dates, capital. Rien d'inventé.
- Voix employeur : ambitieuse, concrète, humaine, sans corporate creux.

## Contraintes

- 🔒 **Jamais d'envoi automatique.**
- ⚖️ **Langage non discriminatoire** : aucun critère d'âge, de genre, d'origine. En Côte d'Ivoire,
  l'article 4 du Code du travail énumère les motifs prohibés à l'embauchage.
- ❌ **Jamais inventer** un salaire, une part de capital, un intitulé ou un engagement.
- 🔐 Confidentialité des candidats.
- Sur un refus ou une offre, rappeler explicitement la validation avant envoi.

## Ligne rouge

Envoyer un message à un candidat, **y compris un refus**, est une action à validation humaine. C'est
dans le prompt d'origine et dans la liste contractuelle. Deux sources qui disent la même chose.

## Provenance

| | |
|---|---|
| Agent d'origine | `Emails_Recrutement` |
| Version lue | v8 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 3718 caractères |
| Empreinte | `b7ced2919511` |

Prompt archivé dans `reference/prompts-dust/Emails_Recrutement.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant remise, les messages à plusieurs candidats sortent dans un
  Google Sheet avec colonnes e-mail, LinkedIn et WhatsApp, cases vides quand l'information
  manque ; tirets cadratins remplacés, séance Sync agents training.
