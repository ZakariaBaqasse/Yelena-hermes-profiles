---
name: mission-control
description: S'active pour exécuter une tâche utilisateur soumise via le dashboard Mission Control (analyse, calcul, rapport, recherche, synthèse, comparaison, génération de contenu ou de fichiers, extraction de données, etc.). Le brief commence toujours par un en-tête `Task ID: <id>`. Déclencheurs typiques : "exécute cette tâche", "effectue", "analyse", "rédige", "calcule", "compare", "synthétise", "génère".
---

# Mission Control — Exécution d'une tâche (Claude Code)

Ce skill cadre l'exécution complète d'une tâche soumise via le dashboard Mission Control. Le dashboard reconstruit l'état de la tâche **uniquement** à partir de (1) tes appels au tool natif de gestion du plan (`TaskCreate` / `TaskUpdate`) et (2) des fichiers que tu déposes dans `~/.openclaw/workspace/mc/<taskId>/outputs/`. Aucun autre canal.

## Tool natif de plan — quelle API utiliser

Claude Code expose une API de gestion du plan qui change selon la version :

- **CC ≥ 2.1.142** (depuis mai 2026) — famille CRUD :
  - `TaskCreate({ subject, description?, activeForm? })` → crée une étape, ID implicite incrémental (`"1"`, `"2"`, …), statut initial `pending`.
  - `TaskUpdate({ taskId, status })` → change le statut (`"in_progress"` | `"completed"`).
- **CC ≤ 2.1.141** (legacy) — tool unique `TodoWrite({ todos: [{ content, activeForm, status }] })` qui remplace tout le plan à chaque appel.

**Détecte au démarrage** : si `TaskCreate` est disponible dans tes tools, utilise-le. Sinon, fallback sur `TodoWrite` (le contrat avec le dashboard est identique — c'est le parser qui gère les deux). Les exemples ci-dessous utilisent la nouvelle API.

**Règle native** : un seul step en `in_progress` à la fois. Le tool refusera les appels qui violent cette contrainte.

**Premier tool call obligatoire** :

```
ToolSearch({ query: "select:TaskCreate,TaskUpdate" })
```

Sans ça, `TaskCreate` échoue avec `InputValidationError`. Si `TaskCreate` n'existe toujours pas après, fallback sur `TodoWrite`.

## 0. Extraire le Task ID et préparer le workspace

Le brief commence par :

```
Task ID: <id>
Brief: <contenu libre rédigé par l'utilisateur>
```

Extrais `<id>` — il sert dans tous les chemins filesystem :

- Livrables finaux → `~/.openclaw/workspace/mc/<id>/outputs/`
- Intermédiaires (scripts, caches, builds) → `~/.openclaw/workspace/mc/<id>/work/`

Crée les deux dossiers en premier (`mkdir -p ~/.openclaw/workspace/mc/<id>/outputs ~/.openclaw/workspace/mc/<id>/work`).

**Jamais rien dans `/tmp/`** — purgé par systemd-tmpfiles sur Ubuntu.

## ⚠️ Règle absolue — ne JAMAIS bloquer pour demander une clarification

La phase de clarification a eu lieu **avant** dans le skill `mission-alignment`. Le brief est figé.

Si une ambiguïté apparaît pendant l'exécution :

- Prends la décision toi-même (hypothèse la plus raisonnable au regard du brief), continue.
- Documente l'hypothèse dans le livrable concerné (note, commentaire, section "Hypothèses retenues").
- Si plusieurs interprétations sont défendables, choisis-en une et mentionne les alternatives dans le livrable.

À éviter absolument : écrire "peux-tu préciser X ?" puis t'arrêter, laisser un step `in_progress` indéfiniment, demander confirmation avant d'écrire un livrable.

**Une tâche `in_progress` doit toujours se terminer par tous les steps en `completed`.** C'est la seule sortie acceptable.

## ⚠️ Règle absolue — AUCUN message texte intermédiaire dans le chat

Tout `text` que tu émets pendant la session apparaît **en direct** dans la bulle "Discussion" du dashboard, côté utilisateur. Cette bulle n'est **pas** un journal d'exécution — c'est un canal de conversation. Tes tool calls, eux, ne sont jamais affichés en chat (ils alimentent uniquement la timeline du plan et les livrables).

**Pendant l'exécution, tu enchaînes les tool calls SILENCIEUSEMENT.** N'émets aucun bloc texte entre les tool calls. Pas de "Je vais d'abord lire le brief.", pas de "Parfait, j'ai trouvé X, je passe à l'étape suivante.", pas de "Voici un récap intermédiaire :", pas de point d'étape, pas de pré-annonce du prochain tool call, pas de confirmation après un Write. **Rien.**

Ces commentaires sont du **spam** pour l'utilisateur, qui suit déjà la progression via la timeline du plan (`TaskCreate` / `TaskUpdate`) et les livrables dans `outputs/`. Tout ce qui se passe entre le premier `TaskCreate` et le dernier `TaskUpdate({status: "completed"})` doit être 100% tool calls — zéro texte assistant.

**Le SEUL bloc texte autorisé pendant la session est le message de clôture** (cf. section 3) émis APRÈS avoir passé la dernière étape en `completed`. Un seul, court, à la toute fin.

**Cas particulier des itérations** (request edits utilisateur ou retour QA) : même règle — tu enchaînes les tool calls en silence, et tu termines par un (seul) court message de clôture. Pas d'accusé de réception au début ("Je vais regarder ça"), pas de point d'étape au milieu.

Si tu sens l'envie de "tenir l'utilisateur informé" : c'est précisément ce qu'il NE veut PAS. Le plan et les livrables le tiennent informé. Le chat est réservé à ta seule prise de parole finale.

## 1. Démarrage — créer le plan

**Dès le premier tour** : `ToolSearch` pour charger les schémas, puis déclare toutes les étapes via `TaskCreate` (un appel par étape), puis passe la première en `in_progress`.

Exemple — tâche "Analyse 3 contrats et rédige un rapport comparatif" :

```
ToolSearch({ query: "select:TaskCreate,TaskUpdate" })
TaskCreate({ subject: "Lire les 3 contrats",            activeForm: "Lecture des 3 contrats" })
TaskCreate({ subject: "Extraire les clauses clés",      activeForm: "Extraction des clauses clés" })
TaskCreate({ subject: "Construire le tableau comparatif", activeForm: "Construction du tableau comparatif" })
TaskCreate({ subject: "Rédiger le rapport final",       activeForm: "Rédaction du rapport final" })
TaskUpdate({ taskId: "1", status: "in_progress" })
```

Les IDs sont attribués dans l'ordre de création (`"1"`, `"2"`, `"3"`, `"4"`). Garde-les en tête pour les updates suivants.

**Granularité** : 3 à 7 étapes macroscopiques visibles côté utilisateur — pas de micro-actions techniques.

**Règle dure : déclarer le plan est obligatoire, même pour une tâche triviale à 1 étape.** Sans signal de plan, le dashboard ne voit jamais la tâche démarrer ni finir.

## 2. Exécution — avancer le plan et déposer les livrables

### 2.a Avancer le plan

**Règle dure : appelle `TaskUpdate` APRÈS CHAQUE step complété, pas en bloc.** Chaque fin d'étape = 2 appels consécutifs : un pour fermer la précédente, un pour ouvrir la suivante. Ne regroupe jamais plusieurs steps terminés dans un seul tour — le dashboard affiche la progression en live.

Exemple après avoir lu les contrats :

```
TaskUpdate({ taskId: "1", status: "completed" })
TaskUpdate({ taskId: "2", status: "in_progress" })
```

Et ainsi de suite jusqu'à la dernière étape.

**Rappel anti-spam** : aucun texte assistant entre ces transitions. Pas de "Étape 1 terminée, je passe à l'étape 2." — c'est ce que la timeline montre déjà visuellement. Tool calls only.

### 2.b Fichiers — distinction stricte

**Livrables finaux** (ce que l'utilisateur consomme : rapport, analyse, CSV, image, dataset, etc.) :

→ `~/.openclaw/workspace/mc/<id>/outputs/<nom>.<ext>`

N'importe quel moyen : tool natif `Write`, script Python, `cp`, etc. Dès qu'un fichier apparaît, le dashboard le détecte.

**Intermédiaires** (scripts d'aide, caches, builds, tests, données extraites non finales, logs de debug) :

→ `~/.openclaw/workspace/mc/<id>/work/`. **Jamais dans `outputs/`**, **jamais dans `/tmp/`**.

**Règle dure** : `outputs/` ne contient **que** des livrables. Si tu hésites, va dans `work/`.

### 2.c Rapport final — OBLIGATOIRE pour toute tâche

Avant de fermer le plan, dépose **toujours** `~/.openclaw/workspace/mc/<id>/outputs/final-report.md`. Le dashboard l'affiche dans une carte dédiée "Rapport final" — synthèse consommable directement.

Deux cas :

- **Cas 1 — la tâche a produit d'autres livrables** : `final-report.md` est un **récap** (ce qui a été fait, méthode, hypothèses, pointeurs vers les livrables produits). Page de garde.
- **Cas 2 — pas d'autre fichier** (question conceptuelle, analyse, recommandation, audit, plan d'action…) : `final-report.md` **EST** le livrable. Tout le contenu attendu est ici.

**Format** :

- Markdown libre, **en français**.
- **Pas de frontmatter YAML** (ça c'est `qa-report.md`, pas `final-report.md`).
- `# Titre` en tête + sections `##` / `###`. Listes, tables, code blocks autorisés.
- Ton naturel, direct.
- N'écris JAMAIS le `Task ID`, le chemin filesystem brut, ni le nom du skill.

**Exemple — Cas 1** :

```markdown
# Analyse comparative des 3 contrats

## Synthèse

Les trois contrats divergent sur trois axes : durée, résiliation, pénalités.

## Tableau comparatif

| Critère   | Contrat A | Contrat B | Contrat C |
| --------- | --------- | --------- | --------- |
| Durée     | 36 mois   | 12 mois   | 24 mois   |
| Préavis   | 6 mois    | 1 mois    | 3 mois    |
| Pénalités | Aucune    | 10%       | Forfait   |

## Livrables

Tableau comparatif détaillé dans `tableau-comparatif.csv`, synthèse complète dans `synthese.pdf`.
```

**Exemple — Cas 2** :

```markdown
# Faut-il migrer vers PostgreSQL 16 ?

## Recommandation

Oui, migration recommandée Q3 pour profiter du parallélisme amélioré.

## Arguments

- Performance : +30% sur les agrégations grosse volumétrie.
- Logical replication : option `failover` qui simplifie le HA.
- Compatibilité : pas de breaking change sur les extensions utilisées.

## Risques

- Phase de test sur staging — au moins 2 semaines.
- L'extension `pg_partman` doit être upgrade en parallèle.
```

**Anti-exemples** : ne mentionne pas le Task ID, les chemins `~/.openclaw/...`, le skill ; ne fais pas une simple liste "I created: file1, file2" — c'est déjà visible côté Livrables ; pas de frontmatter YAML.

## 3. Clôture

Quand tout est terminé (toutes les étapes faites, tous les livrables dans `outputs/`, **`final-report.md` écrit**), passe **toutes les étapes en `completed`** :

```
TaskUpdate({ taskId: "4", status: "completed" })
```

(et ainsi de suite pour toutes celles qui restaient en `in_progress` ou `pending`).

Ce dernier `completed` sur la dernière étape = **signal de fin** pour le dashboard. Pas d'API call, pas de fichier marker, pas de tool de notification spécial.

### Message de clôture dans le chat

Termine par **un court message texte en français** (peu importe la langue du brief — le dashboard est francophone). Affiché dans la bulle "Discussion".

**C'est le SEUL message texte de toute la session.** Si tu en as émis d'autres avant (point d'étape, accusé de réception, commentaire intermédiaire), tu as violé la règle anti-spam — relis la section "AUCUN message texte intermédiaire" plus haut.

**Règles** :

- 2-4 phrases max. Ton naturel, humain.
- Dis ce que tu as livré et où le trouver **dans le langage de l'utilisateur** (ex. "le rapport comparatif", "le fichier CSV"), **pas le chemin filesystem brut**.
- **Ne mentionne JAMAIS** : Task ID (UUID), chemins absolus (`~/.openclaw/...`), noms de dossiers internes (`outputs/`, `work/`), nom du skill, détails du runtime.
- Pas de liste à puces "I created:" — la liste des fichiers est déjà visible dans le dashboard.
- Si pertinent : "n'hésite pas à me demander des ajustements".

**À éviter** :

```
Done. ✅
Task **869b5c10-...** is complete.
I created:
- `~/.openclaw/workspace/mc/869b5c10-.../outputs/`
Livrable generated:
- `outputs/test-result.txt`
```

**À faire** :

> C'est terminé. J'ai produit le fichier `test-result.txt` que tu retrouves dans les livrables. Dis-moi si tu veux que j'ajuste quelque chose.

> Voilà, le rapport comparatif des 3 contrats est prêt — il met en évidence les clauses qui divergent (durée, résiliation, pénalités).

> Analyse terminée. J'ai trouvé 47 doublons dans le dataset et exporté la version nettoyée. Si tu veux que je creuse un critère, demande.

## Itération humaine ou retour QA automatique

Tu peux recevoir un nouveau message dans la **même session** dans deux cas — marche à suivre **identique** (étendre le plan, pas le recréer) :

- **Request edits utilisateur** — bouton "Request edits" ou commentaire libre.
- **Retour QA automatique** — message système commençant par `🛡️ **Retour QA — score X/100 …**` quand `scores.global < 80` (sous le cap de 3 retries). Embarque le `qa-report.md` complet. À traiter comme une demande de correction prioritaire.

Dans les deux cas :

> **⚠️ Règle dure : déclare les nouvelles étapes AVANT de toucher aux livrables.** Premier tool call à la réception d'une itération **doit être `TaskCreate`** (pas `Write`, pas `Bash`). Sans nouveau step déclaré, le dashboard voit un fichier surgir sans contexte. Pas de raccourci, même pour une itération triviale.

**Anti-exemple réel** (cas observé en prod) :

> User : *"fais un hello world 2"*
> Agent : *"Voici 👇"* → écrit directement `hello-world-2.py` sans aucun `TaskCreate`.

Interdit. **Bonne séquence** :

1. `TaskCreate({ subject: "Créer hello-world-2.py", activeForm: "Création de hello-world-2.py" })` → nouveau step (disons ID `"5"`).
2. `TaskUpdate({ taskId: "5", status: "in_progress" })`.
3. `Write` du fichier dans `outputs/hello-world-2.py`.
4. `TaskUpdate({ taskId: "5", status: "completed" })`.
5. Petit message texte de clôture.

Au minimum **1 nouveau step déclaré** + son transition `pending → in_progress → completed`, même pour 3 lignes de Python.

**Rappel anti-spam** : entre les étapes 1 et 5 ci-dessus, zéro texte. Pas de "OK, je m'en occupe.", pas de "Voilà, le fichier est créé." avant la clôture. Tool calls only, puis un seul message de clôture à la fin.

Tu peux écraser les fichiers existants dans `outputs/` pendant l'itération. Garde le même Task ID — c'est toujours la même tâche, la même session.

## Résumé — règles à retenir

1. Extraire le `Task ID`. Créer `outputs/` et `work/` sous `~/.openclaw/workspace/mc/<id>/`.
2. Premier tool call : `ToolSearch({query: "select:TaskCreate,TaskUpdate"})`. Puis `TaskCreate` pour chaque étape, puis `TaskUpdate({taskId:"1", status:"in_progress"})`. (Fallback `TodoWrite` si `TaskCreate` indisponible.)
3. `TaskUpdate` **après CHAQUE step complété** (pas en bloc), 1 seul `in_progress` à la fois.
4. Livrables finaux → `~/.openclaw/workspace/mc/<id>/outputs/`. Reste → `work/`. **Jamais `/tmp/`.**
5. **`final-report.md` obligatoire dans `outputs/`** avant la clôture. Récap si autres livrables, sinon il EST le livrable.
6. Dernier `TaskUpdate` qui passe la dernière étape en `completed` = signal de fin.
7. **Jamais bloquer pour demander une clarification.** Décide, documente l'hypothèse, finis.
8. **Aucun message texte intermédiaire** : tu enchaînes les tool calls en silence, un seul message texte autorisé = celui de clôture à la toute fin. Même règle en itération (request edits / retour QA).
