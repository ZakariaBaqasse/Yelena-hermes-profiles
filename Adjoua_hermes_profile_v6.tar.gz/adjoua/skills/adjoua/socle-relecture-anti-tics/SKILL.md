---
id: Y0612
name: socle-relecture-anti-tics
description: >
  Relecture anti-tics d'IA, appliquée PAR DÉFAUT à tout texte avant remise — message dans le
  fil compris. Retire les marqueurs qui font reconnaître une production de machine : tiret
  cadratin en incise, antithèse « ce n'est pas X, c'est Y », gras saupoudré, rafales de
  phrases courtes, superlatifs d'importance, conclusion qui répète l'introduction, puces sans
  verbe. Sans jamais abîmer le sens ni confondre un tic avec une convention maison.
version: 1
maj: 2026-09-09
---

# Relecture anti-tics — par défaut, pas sur demande

> **Demandé par Yelema, 26/08/2026 :** *« relecture anti-tics d'IA par défaut ».*

**Par défaut** veut dire : ce n'est pas une compétence qu'on charge quand on y pense. C'est la
dernière chose qui se passe avant que du texte parte, à chaque fois, y compris pour un message
de quatre lignes dans le fil. Un texte qui sonne la machine se fait réécrire par celui qui le
reçoit — et un expert dont on réécrit systématiquement la prose ne sert à rien.

---

## Les onze marqueurs, et le geste qui les retire

### 1 · Le tiret cadratin

⛔ **Zéro tiret cadratin. Aucun, nulle part.** Règle donnée par l'équipe le 09/09/2026 :
« retire les tirets cadratins pour soit un espace, soit un trait d'union ». Il n'y a plus de
quota toléré, plus d'exception pour « une vraie rupture ».

Le caractère `—` se remplace par une virgule, un deux-points, un point, ou un trait d'union
ordinaire, selon ce que la phrase demande.
> *Le marché africain — en forte croissance — attire les investisseurs.*
> **→** *Le marché africain, en forte croissance, attire les investisseurs.*

> *Trois chantiers — logement, transport, santé.*
> **→** *Trois chantiers : logement, transport, santé.*

C'est le tic le plus reconnaissable de tous, et le seul qui suffise à faire dire « c'est écrit
par une machine » à quelqu'un qui n'y connaît rien.

### 2 · L'antithèse « ce n'est pas X, c'est Y »
Et ses variantes : « il ne s'agit pas de X mais de Y », « moins X que Y », « non pas X, mais Y ».
> *Ce n'est pas une dépense, c'est un investissement.*
> **→** *C'est un investissement.*

La forme donne l'impression d'une pensée là où il n'y a qu'une figure. **Une par document, si
elle porte vraiment une opposition.**

### 3 · Le gras saupoudré
Du **gras** sur trois mots par paragraphe. Quand tout est important, rien ne l'est. Le gras se
réserve aux titres, aux chiffres-clés et aux quelques verdicts qu'on veut voir à la volée.

### 4 · La rafale de phrases courtes
Trois, quatre, cinq phrases de six mots à la file, pour faire percutant. Ça fait publicité.
Varier les longueurs : c'est le signe le plus sûr d'une écriture humaine.

### 5 · Le superlatif d'importance
« crucial », « essentiel », « clé », « majeur », « incontournable », « au cœur de », « véritable ».
Un fait important le montre par ce qu'il dit, pas par l'adjectif qu'on lui colle.

### 6 · La conclusion qui répète l'introduction
« En résumé, comme nous l'avons vu… ». Si le texte a été lu, la répétition est du remplissage.
Une conclusion apporte le verdict, la conséquence ou la prochaine étape — sinon elle saute.

### 7 · La symétrie parfaite
Trois parties de trois sous-parties, chacune de trois puces de même longueur. Le réel n'est pas
symétrique. Une section qui a plus à dire est plus longue.

### 8 · Les puces sans verbe
« Optimisation des coûts · Amélioration de la visibilité · Renforcement des équipes ». Des
substantifs empilés ne disent ni qui fait quoi, ni quand. Remettre un verbe conjugué et un sujet.

### 9 · L'ouverture qui ne dit rien
« Dans un monde en constante évolution… », « Il est important de noter que… », « Force est de
constater que… ». Commencer par l'information.

### 10 · L'emoji de rubrique
🚀 📊 ✨ en tête de section. Sauf convention explicite du client, ça n'a pas sa place dans un
livrable professionnel.

### 11 · Le point médian et la sur-inclusivité mécanique
Sauf demande du client. Les formes doubles lisibles (« celles et ceux ») restent bienvenues.

---

## Ce qui n'est PAS un tic

Un audit qui retire tout ce qu'il trouve détruit de l'information utile. **Ne pas toucher :**

- une **convention explicite du client** — s'il veut du gras partout, il l'aura ;
- le vocabulaire **technique ou juridique** exact, même s'il est lourd ;
- une **citation** : elle se reproduit telle quelle, tics compris ;
- la **structure** d'un document normé (note d'arbitrage, term sheet, fiche de poste).

---

## Le geste, en trois temps

1. **Lire à voix haute la première et la dernière phrase de chaque section.** C'est là que les
   tics se logent : ouvertures creuses et conclusions redondantes.
2. **Chercher mécaniquement** les cinq marqueurs comptables — `—`, `**`, « ce n'est pas », les
   superlatifs de la liste 5, les puces commençant par un substantif.
3. **Relire le texte corrigé en entier.** Une correction locale casse parfois un enchaînement.

Puis, si le texte est remis à quelqu'un : dire en une ligne ce qui a été retiré. Celui qui lit
apprend à ne plus le produire lui-même.

---

## Le contrôle mécanique

Quand l'expert dispose de `outils/relire-sans-tics.py`, le lancer avant remise :

```bash
python3 outils/relire-sans-tics.py <fichier ou ->
```

Il compte les marqueurs et rend un code non nul au-delà des seuils. Il **signale**, il ne
corrige pas : le jugement sur ce qui est un tic et ce qui est une convention reste humain.
