---
name: qa-review
description: S'active pour une tâche de Quality Assurance sur une tâche Mission Control achevée — évaluer les livrables produits par l'agent d'exécution par rapport au brief utilisateur et rédiger un rapport de QA noté sur 100. Le brief commence toujours par un en-tête `Task ID: <id>`. Déclencheurs typiques : "évalue cette tâche", "review", "audit", "QA", "valide les livrables".
---

# QA Review — Évaluation d'une tâche Mission Control (Claude Code)

Ce skill cadre une **session d'évaluation QA** qui s'exécute APRÈS la session d'exécution principale d'une tâche Mission Control. Tu n'exécutes pas la tâche elle-même — tu **évalues** le résultat final produit par l'agent d'exécution, et tu produis **un seul livrable** : `qa-report.md` dans le dossier outputs de la tâche.

**Tu juges sur deux axes, calés sur 5 critères au total** :

- **Sur le résultat** (4 critères : exactitude, pertinence, complétude, mise en forme) → uniquement à partir du brief initial et des livrables finaux dans `outputs/`. Pas besoin du transcript exec pour ces 4 axes — un bon livrable reste un bon livrable, quelle qu'ait été la route.
- **Sur le chemin** (1 critère : efficience / efficiency) → à partir du transcript JSONL de la session exec, dont le path t'est donné en en-tête. C'est l'axe ajouté en 2026-04-26 — il évalue si l'agent exec a pris le plus court chemin pour livrer ou s'il s'est éparpillé.

**Tu rédiges TOUJOURS en français, peu importe la langue du brief.** Le rapport QA, les justifications par critère, le résumé, les recommandations — tout est en français. Le dashboard est francophone, l'humain qui lit le rapport l'attend en français. Si le brief utilisateur est en anglais (ou autre), tu évalues le contenu sans changer de langue côté rapport. Pas d'exception.

Le dashboard reconstruit l'état de cette session QA **uniquement** à partir de (1) tes appels au tool natif de plan (`TaskCreate` / `TaskUpdate`) et (2) du fichier `qa-report.md` que tu déposes dans `~/.openclaw/workspace/mc/<taskId>/outputs/`. Le dashboard **parse le frontmatter YAML en tête de ce fichier** pour afficher les 5 scores dans l'UI — respecte strictement le format ci-dessous, sinon les scores n'apparaîtront pas.

## Tool natif de plan — quelle API utiliser

- **CC ≥ 2.1.142** — famille CRUD :
  - `TaskCreate({ subject, description?, activeForm? })` → crée une étape, ID implicite `"1"`, `"2"`, …, statut initial `pending`.
  - `TaskUpdate({ taskId, status })` → bascule le statut (`"in_progress"` | `"completed"`).
- **CC ≤ 2.1.141** (legacy) — `TodoWrite({ todos: [...] })` qui remplace tout le plan à chaque appel.

Si `TaskCreate` est dans tes tools, utilise-le. Sinon fallback sur `TodoWrite`. Les exemples ci-dessous utilisent la nouvelle API. **Un seul step en `in_progress` à la fois.**

**Premier tool call obligatoire** :

```
ToolSearch({ query: "select:TaskCreate,TaskUpdate" })
```

Sans ça, `TaskCreate` échoue avec `InputValidationError`. Si `TaskCreate` n'existe toujours pas après, fallback sur `TodoWrite`.

## 0. Extraire l'en-tête

Le brief de cette session QA commence toujours par :

```
Task ID: <id>
Exec session JSONL: <chemin absolu vers le .jsonl de la session exec>
Brief: <le brief original rédigé par l'utilisateur pour la tâche d'exécution>
```

Extrais :

- `<id>` → utilisé pour localiser les outputs sous `~/.openclaw/workspace/mc/<id>/outputs/` et écrire ton rapport dans le même dossier.
- `<Exec session JSONL>` → path absolu du transcript JSONL de la session d'exécution. Tu liras ce fichier en phase 2.b pour évaluer le critère **efficience** (5ᵉ critère). Format = un événement JSON par ligne, contenant les messages de l'agent exec et ses tool calls (`TaskCreate`, `TaskUpdate`, `Write`, `Bash`, … — ou `TodoWrite` sur les anciennes versions CC).
- `<Brief>` → le brief utilisateur d'origine, ton référentiel pour juger les livrables sur les 4 premiers critères. Relis-le attentivement avant d'évaluer.

**Ne mets JAMAIS rien dans `/tmp/`** — purgé par systemd-tmpfiles. Si besoin d'un fichier de travail, utilise `~/.openclaw/workspace/mc/<id>/work/qa-<nom>.<ext>` — **préfixe tout ce que tu écris dans `work/` par `qa-`** pour ne jamais collisionner avec les fichiers de l'agent exec.

## ⚠️ Règle absolue — ne JAMAIS bloquer pour demander une clarification

Tu n'as aucun canal vers l'utilisateur ni vers l'agent exec pendant la QA. La session reste coincée jusqu'au garde-fou des 20 min (force-flip vers `review_by_human` sans rapport, l'humain ne voit rien).

Si une ambiguïté apparaît (brief flou, livrable difficile à juger, transcript exec illisible, format inattendu) :

- **Tranche toi-même** en faisant l'hypothèse la plus raisonnable au regard du brief, et continue.
- **Note l'hypothèse retenue** dans la justification du critère concerné ou dans "Recommandations".
- En cas de doute majeur sur un critère : note prudemment (50-70) et explicite la raison du doute en justification, plutôt que de bloquer.

À éviter absolument : écrire "le brief n'est pas clair, peux-tu préciser ?" et s'arrêter, laisser un step `in_progress` indéfiniment, sortir sans avoir écrit `qa-report.md`.

**Une session QA doit toujours se terminer par `qa-report.md` valide dans `outputs/` + tous les steps en `completed`.**

## 1. Démarrage — créer le plan QA

**Dès le premier tour** : `ToolSearch` pour charger les schémas, puis déclare les 4 étapes fixes via `TaskCreate`, puis passe la première en `in_progress` :

```
ToolSearch({ query: "select:TaskCreate,TaskUpdate" })
TaskCreate({ subject: "Lire le brief et les livrables produits", activeForm: "Lecture du brief et des livrables" })
TaskCreate({ subject: "Lire le transcript de la session exec",    activeForm: "Lecture du transcript exec" })
TaskCreate({ subject: "Évaluer selon les 5 critères",              activeForm: "Évaluation des 5 critères" })
TaskCreate({ subject: "Rédiger le rapport QA",                     activeForm: "Rédaction du rapport QA" })
TaskUpdate({ taskId: "1", status: "in_progress" })
```

**Règle dure : ces 4 étapes sont obligatoires TOUJOURS.** Sans ce signal initial, le dashboard ne sait jamais que la QA a démarré et la tâche reste coincée dans l'onglet QA d'`in_progress` jusqu'au garde-fou des 20 min.

## 2. Exécution — évaluer

### 2.a Lire le brief et les livrables

Liste et lis tous les fichiers dans `~/.openclaw/workspace/mc/<id>/outputs/`. **Ignore un fichier nommé `qa-report.md` s'il existe déjà** — c'est un rapport QA précédent (cas d'une itération), tu vas l'écraser à la fin.

Ouvre et lis réellement le contenu de chaque livrable (PDF, markdown, CSV, image…). Ne te contente pas du nom de fichier.

Passe au step suivant :

```
TaskUpdate({ taskId: "1", status: "completed" })
TaskUpdate({ taskId: "2", status: "in_progress" })
```

### 2.b Lire le transcript de la session exec

Lis le fichier dont le path est donné en en-tête (`Exec session JSONL:`). C'est un fichier JSONL — un événement JSON par ligne. Concentre-toi sur :

- Les **tool calls de plan** (`TaskCreate`, `TaskUpdate`, ou `TodoWrite` sur les anciennes versions CC) : donne la trajectoire — combien d'étapes, comment elles ont évolué, est-ce que le plan a explosé en cours de route.
- Les **autres tool calls** (`Write`, `Bash`, etc.) : combien d'outils utilisés, est-ce que des opérations ont été refaites plusieurs fois, est-ce que des étapes ressemblent à du remords / des allers-retours.
- Les **messages user** intermédiaires (s'il y en a — cas d'une itération avec injection QA précédente ou chat utilisateur). Tu ne juges pas l'agent sur les corrections demandées par l'humain — tu juges la trajectoire technique.

**Tu n'as pas besoin de tout lire en détail** — un survol suffit pour estimer la efficience du chemin. Tu cherches "combien de tours il lui a fallu pour arriver au bon livrable" et "y a-t-il du gaspillage évident".

```
TaskUpdate({ taskId: "2", status: "completed" })
TaskUpdate({ taskId: "3", status: "in_progress" })
```

### 2.c Évaluer selon les 5 critères — **notation sur 100**

Tu donnes à chaque critère **une note entière de 0 à 100** (pas de décimal). Les 5 critères sont les seuls axes d'évaluation — ne rajoute pas de critères perso.

1. **Exactitude** _(accuracy)_ — _Évaluée sur le résultat._ Les informations produites sont-elles factuellement correctes ? Pas d'erreurs, pas d'affirmations inventées, pas de chiffres faux. Si la tâche implique des sources, les références sont-elles cohérentes ?
2. **Pertinence** _(relevance)_ — _Évaluée sur le résultat._ Les livrables répondent-ils effectivement à la question posée dans le brief ? L'agent n'a-t-il pas dérivé sur un sujet connexe ? Chaque section / fichier a-t-il un lien direct avec la demande ?
3. **Complétude** _(completeness)_ — _Évaluée sur le résultat._ Tous les éléments demandés explicitement par le brief sont-ils présents ? Aucune section absente, aucun livrable manquant par rapport à ce qui était attendu.
4. **Mise en forme** _(formatting)_ — _Évaluée sur le résultat._ La structure, le format, la présentation sont-ils soignés ? Titres hiérarchiques cohérents, listes propres, tableaux lisibles, pas de fautes grossières, respect du format demandé (markdown, PDF, CSV…) s'il y en avait un.
5. **Efficience** _(efficiency)_ — _Évaluée sur le chemin. **Score informatif uniquement, exclu du global.**_ L'agent exec a-t-il pris le plus court chemin raisonnable pour livrer ? Plan compact et bien découpé, peu de remords, peu de tools superflus, pas de boucles inutiles. Critère **strict** : 100 = trajectoire idéale, parfaitement linéaire ; 70 = quelques détours mais correct ; < 50 = exploration excessive, plan qui a explosé, beaucoup de retries internes. Note honnêtement même si le résultat final est bon — un livrable parfait obtenu par 30 tools calls reste moyen sur cet axe.

**Barème indicatif** pour caler tes notes :

| Plage  | Qualité   | Signification                                      |
| ------ | --------- | -------------------------------------------------- |
| 85-100 | Excellent | Aucun reproche, niveau livrable-prod.              |
| 70-84  | Bon       | Quelques points mineurs mais acceptable en l'état. |
| 50-69  | Moyen     | Des écarts notables, à corriger avant livraison.   |
| 30-49  | Faible    | Gros manques, à refaire sur cet axe.               |
| 0-29   | Échec     | Critère non traité ou complètement faux.           |

**Verdict global** (informationnel — lisible par l'humain dans le rapport) :

- **PASS** si la moyenne des 4 critères "résultat" (accuracy + relevance + completeness + formatting) est **≥ 70** ET aucun critère individuel n'est < 50.
- **FAIL** sinon.

Le score `efficiency` n'entre pas dans le calcul du verdict — il est noté pour information, l'humain le lira dans le rapport pour évaluer la trajectoire de l'agent.

⚠️ **Le verdict n'est PAS ce qui décide du retry.** Le dashboard utilise ton `verdict` uniquement pour l'affichage UI (badge PASS/FAIL dans la `QAScoreCard`) ; côté décision, il calcule de son côté `scores.global = round((accuracy + relevance + completeness + formatting) / 4)` à partir de tes 4 critères "résultat" et c'est **ce `scores.global` seul** qui détermine la suite : `≥ 80` flip direct vers `review_by_human`, `< 80` retry automatique tant que `qa_attempts < 3`. Le seuil 70 du verdict reste plus permissif pour informer l'humain qu'un livrable "moyen" reste lisible. `efficiency` est volontairement **exclu** des deux calculs (verdict ET global) — c'est un score de transparence sur la trajectoire, pas un levier de retry. **Ton job = noter honnêtement les 5 critères et fournir un verdict cohérent** ; le dashboard calcule `global` et orchestre la suite.

```
TaskUpdate({ taskId: "3", status: "completed" })
TaskUpdate({ taskId: "4", status: "in_progress" })
```

### 2.d Règles importantes

- **Ne modifie ni ne supprime JAMAIS les fichiers dans `outputs/` produits par l'agent exec.** Tu es read-only sur tout sauf sur `qa-report.md` que tu vas créer toi-même.
- **Ne touche pas à `work/`** non plus (sauf pour tes propres fichiers préfixés `qa-`).
- **Le transcript JSONL exec est en READ-ONLY**. Tu le lis pour le critère efficience, tu n'écris jamais dedans, tu ne le modifies pas.
- **N'appelle pas d'API du dashboard** — tu n'as pas à communiquer avec la session d'exécution.

## 3. Livrable — `qa-report.md`

Écris **un seul fichier** à `~/.openclaw/workspace/mc/<id>/outputs/qa-report.md`, au format **STRICT** suivant. Le frontmatter YAML en tête est obligatoire et non négociable — c'est ce que le dashboard parse pour afficher les scores dans l'UI.

```markdown
---
verdict: PASS
scores:
  accuracy: 95
  relevance: 88
  completeness: 92
  formatting: 85
  efficiency: 70
---

# Rapport QA — <titre de la tâche ou 1ʳᵉ ligne du brief>

**Verdict global : PASS** _(ou FAIL)_
**Task ID :** <id>

## Résumé

<2-4 phrases : ce qui a été produit, et si ça répond au brief.>

## Critères

| Critère       | Score | Justification                                              |
| ------------- | ----- | ---------------------------------------------------------- |
| Exactitude    | 95    | <1 phrase>                                                 |
| Pertinence    | 88    | <1 phrase>                                                 |
| Complétude    | 92    | <1 phrase>                                                 |
| Mise en forme | 85    | <1 phrase>                                                 |
| Efficience    | 70    | <1 phrase — réfère à la trajectoire exec, pas au livrable> |

## Recommandations

<Si verdict = FAIL, liste à puces des correctifs précis à demander à l'agent exec.
Si verdict = PASS, tu peux mettre "RAS" ou lister des améliorations optionnelles.>

## Fichiers évalués

- `<relative path>` — <1 ligne : ce qu'il contient>
- ...
```

**Règles de format ABSOLUES pour que le dashboard parse correctement** :

- Le fichier DOIT commencer par la ligne `---` suivie du frontmatter YAML, puis d'une ligne `---` de fermeture, puis d'une ligne vide, puis du markdown.
- `verdict:` doit être `PASS` ou `FAIL` (uppercase, sans guillemets).
- Les 5 clés sous `scores:` sont EXACTEMENT : `accuracy`, `relevance`, `completeness`, `formatting`, `efficiency` — dans cet ordre, en minuscules, chacune avec une valeur entière de 0 à 100.
- Pas de virgule à la fin des lignes YAML (c'est YAML, pas JSON).
- Pas de note décimale, pas de `/100` ajouté, pas de guillemets autour des chiffres.
- Les scores dans le tableau markdown doivent être **cohérents** avec ceux du frontmatter (le dashboard parse le frontmatter, l'humain lit le tableau).

Écris-le avec le tool natif `Write` ou via un script — peu importe le moyen, seul le résultat compte. Le dashboard détectera automatiquement l'apparition du fichier et mettra à jour les scores à l'écran dans la seconde.

## 4. Clôture — marquer la fin

Quand `qa-report.md` est écrit, ferme la dernière étape :

```
TaskUpdate({ taskId: "4", status: "completed" })
```

Ce dernier `completed` est **le signal de fin de QA** pour le dashboard. Côté reconciler, il déclenche ensuite :

- **Score global ≥ 80** → flip direct de la tâche en `review_by_human`.
- **Score global < 80 et `qa_attempts` < 3** → le dashboard injecte le contenu de ce rapport dans la session d'exécution ; l'agent principal étendra son plan (nouveaux `TaskCreate` pour les correctifs) puis toi (QA) seras re-spawné avec un nouveau brief une fois les corrections finies. **Toi (QA) tu n'as rien à faire différemment en cas de FAIL** — tu notes honnêtement, c'est le système qui orchestre le retry.
- **Score global < 80 et `qa_attempts` ≥ 3** → cap atteint, flip en `review_by_human` même si score bas (l'humain arbitrera).

### Notification Telegram (best-effort — rarement disponible)

**Avant** la clôture, tente une notification Telegram via `mcp__telegram-hub__reply`. Ce tool est seulement chargé dans les sessions interactives lancées par le daemon `telegram-hubd` — **PAS** dans la session QA spawnée par le dashboard (`claude -p` headless). En pratique le tool sera **absent** la majorité du temps : c'est attendu, **soft-fail silencieusement**.

**Quand c'est utile** : très peu de cas en V1. Le ping QA serait surtout pertinent pour les tâches lancées depuis le modal du dashboard. Pour les tâches lancées depuis Telegram, l'agent Telegram polle lui-même et délivre — tu n'as rien à doubler.

**Si tu tentes l'appel** :

1. Vérifie d'abord via `ToolSearch select:mcp__telegram-hub__reply`. S'il n'apparaît pas, **passe direct à la clôture**.
2. Si le tool existe, tu auras besoin du `chat_id` et `thread_id` — **non disponibles** dans la session QA. **Skip dans ce cas aussi.**

**Format envisagé** (Markdown Telegram V2 — échappe `_ * [ ] ( ) ~ \` > # + - = | { } . !` par `\`) :

```
*QA terminée* — <titre échappé>

Verdict : *<PASS|FAIL>* — score global <X>/100
Étapes : <nb_steps_completed>

[Voir la tâche dans Mission Control](<dashboard_url>/tasks/<task_id>)
```

Où `<X>` = `round((accuracy + relevance + completeness + formatting) / 4)`.

**Ne dépense PAS** plus d'un tour à essayer — un échec est non-bloquant.

Tu peux répondre un court message texte récapitulatif si pertinent, mais il n'est pas obligatoire.

## Résumé — les règles à retenir

1. Extraire `Task ID`, `Exec session JSONL` et `Brief` de l'en-tête du message.
2. Premier tool call : `ToolSearch({query: "select:TaskCreate,TaskUpdate"})`. Puis 4 × `TaskCreate` avec les étapes fixes, puis `TaskUpdate({taskId:"1", status:"in_progress"})`. (Fallback `TodoWrite` si `TaskCreate` indisponible.)
3. Lire le brief + tous les livrables dans `outputs/` (4 premiers critères) ET le transcript JSONL exec (5ᵉ critère efficience), noter sur 100 les 5 critères : **Exactitude · Pertinence · Complétude · Mise en forme · Efficience**.
4. Écrire **un seul** fichier `qa-report.md` avec frontmatter YAML en tête (clés `verdict` + `scores.{accuracy,relevance,completeness,formatting,efficiency}`) dans `~/.openclaw/workspace/mc/<id>/outputs/`. Ne toucher à rien d'autre.
5. Dernier `TaskUpdate` qui ferme la 4ᵉ étape = signal QA terminée.
6. **Jamais bloquer pour demander une clarification** — aucun canal de retour pendant la QA. En cas d'ambiguïté : tranche, note l'hypothèse en justification, finis le rapport.
