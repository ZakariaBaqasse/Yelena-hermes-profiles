---
id: Y0743
name: verification-d-antecedents
description: "Étape 6 du processus, postes sensibles seulement : vérification d'antécédents (background check) d'un candidat finaliste sur sources publiques, cadrée par la loi ivoirienne n° 2013-450 sur les données à caractère personnel. À charger dès qu'un client parle de vérifier un candidat, de background check, d'enquête de moralité, de casier judiciaire ou de ce qu'on trouve sur internet au sujet d'une personne. Donne quand on le fait et quand on refuse, les sources permises et les gestes interdits, le texte qui informe le candidat, la fiche factuelle à remettre, la destruction des résultats, et le contrôle avant remise. Jamais par défaut, jamais à l'insu du candidat."
bucket: B
tags: [Recrutement, Côte d'Ivoire, Legal]
version: 1
maj: 2026-09-23
---

# Vérification d'antécédents d'un candidat à un poste sensible

## Contrôle avant tout geste, à relire avant chaque vérification

Avant de lancer la moindre recherche, vérifie les quatre conditions ci-dessous. Si une seule
manque, tu ne cherches pas : tu dis laquelle manque et qui doit la lever.

1. Le client a demandé la vérification **par écrit**, pour **un poste nommé**, et a dit en une
   phrase pourquoi ce poste est sensible.
2. Le poste relève de la finance ou de la direction (voir section 1).
3. Le candidat a reçu le texte d'information de la section 3 **avant** la vérification, et on
   sait quand et par quel canal.
4. Le candidat est finaliste : la vérification ne porte jamais sur toute une liste de
   candidatures.

Avant de remettre la fiche, passe le contrôle de la section 6. Sinon, ne remets pas.

## Pourquoi cette compétence existe

Un recruteur qui confie un poste de trésorerie ou de direction veut savoir si le candidat
traîne une affaire publique qui compte pour ce poste. La demande est légitime. Elle touche
pourtant à une catégorie de données que la loi ivoirienne encadre de près, et une vérification
mal faite expose le client (collecte déloyale, données sur un homonyme, conservation sans fin,
décision prise sur une rumeur).

Le cadre retenu : on le fait pour les postes sensibles, sur données publiques, et le candidat
est informé dans le processus que l'entreprise procède à ces vérifications. Aucune vérification
cachée.

## Les textes, et où ils sont

Tout ce qui suit se cite depuis ces fichiers, article par article, jamais de mémoire :

| Texte | Fichier |
|---|---|
| Loi n° 2013-450 du 19 juin 2013 relative à la protection des données à caractère personnel | `~/.claude/outils-communs/donnees-personnelles-ci/loi-2013-450-donnees-personnelles.pdf` (Journal officiel du 8 août 2013), texte lisible dans `loi-2013-450-copie-onudc.txt` |
| Loi n° 2013-451 du 19 juin 2013 relative à la lutte contre la cybercriminalité | `~/.claude/outils-communs/donnees-personnelles-ci/loi-2013-451-cybercriminalite.pdf` |
| Loi n° 2015-532 du 20 juillet 2015 portant Code du travail | `~/.claude/outils-communs/droit-travail-ci/code-du-travail-2015-532.txt` |

Le mode d'emploi général de la loi 2013-450 (formalités, droits, sécurité) est dans la
compétence `donnees-personnelles-ci` : on s'y reporte, on ne le recopie pas ici. Les `.txt`
sont des reconnaissances de caractères : pour une valeur qui engage le client, rouvrir le PDF.

Ce qui suit ne remplace pas un avis juridique. Les points que les textes présents ne
tranchent pas sont regroupés en section 7, **à faire valider par l'expert juridique**.

## 1. Quand elle s'applique, et quand elle ne s'applique pas

**Elle s'applique** quand les trois conditions sont réunies :

- un poste de finance (maniement de fonds, trésorerie, comptabilité, signature bancaire,
  achats à gros montants) ou de direction (dirigeant, mandataire social, membre du comité de
  direction) ;
- une demande explicite du client pour ce poste-là ;
- un candidat arrivé en fin de processus, avec la prise de références, avant toute offre.

La raison tient à la loi 2013-450 : les données doivent être collectées pour des finalités
déterminées, explicites et légitimes, et rester « adéquates, pertinentes et non excessives au
regard des finalités » (art. 16). Vérifier tous les candidats, ou un poste qui ne manie ni
fonds ni pouvoir, n'a pas de finalité qui le justifie.

**Elle ne s'applique pas**, et on le dit au client :

- par défaut, ou « pour voir », ou parce que le candidat a éveillé une impression ;
- à un poste sans lien avec la finance ou la direction : on renvoie à `prise-references` ;
- à tous les candidats d'une liste, ou avant le tri ;
- à un salarié déjà en poste, à un associé, à un proche du candidat : ce sont d'autres
  situations, hors de cette compétence ;
- quand le client veut que le candidat n'en sache rien. On refuse, parce que le responsable
  du traitement doit informer la personne « au plus tard, lors de la collecte » (art. 28) et
  que la collecte doit être « licite et loyale » (art. 15).

## 2. Ce qu'on vérifie, où, et ce qu'on ne fait jamais

### Ce qu'on cherche

Des faits publics qui ont un lien direct avec le poste :

- la cohérence du parcours déclaré : employeurs, fonctions, dates, diplômes annoncés ;
- les sociétés que le candidat dit avoir dirigées ou fondées : existence, dénomination, date
  d'immatriculation ;
- les affaires publiques qui touchent aux fonctions visées (gestion de fonds, direction
  d'entreprise), telles que la presse ou une décision publiée les rapportent.

### Où on cherche, et seulement là

| Source | Ce qu'elle peut établir |
|---|---|
| Presse publiée, signée et datée | qu'un fait a été rapporté, à telle date, par tel titre. Un article établit ce qu'il rapporte, pas que le fait est jugé |
| Décisions de justice publiées | ce que la décision dit, à la date où elle le dit. On note la juridiction, la date et le lien vers la page ouverte |
| Registres publics d'entreprises | l'existence d'une société, sa dénomination, sa date d'immatriculation. Méthode et limites : `~/.claude/outils-communs/entreprises-ci/ANNUAIRES.md` |
| Présence en ligne professionnelle, publique et sans compte | profil professionnel public, publications, interventions, nominations annoncées |

Les outils et l'ordre de recherche sont ceux de `aller-chercher`, avec une limite en plus : on
ne lit que ce qu'une personne sans compte ni mot de passe peut lire.

### Ce qu'on ne fait JAMAIS

| Geste interdit | Texte |
|---|---|
| Accéder à une donnée non publique : profil privé, groupe fermé, espace qui demande un compte, contournement d'une connexion | loi 2013-451, art. 4 : puni quiconque « accède ou tente d'accéder frauduleusement à tout ou partie d'un système d'information » |
| Se faire passer pour quelqu'un, créer un faux profil, demander une mise en relation sous une fausse identité | loi 2013-451, art. 19 : puni quiconque « utilise frauduleusement un ou des éléments d'identification d'une personne physique ou morale par le biais d'un système d'information » ; loi 2013-450, art. 15 (collecte licite et loyale) |
| Se servir d'une base divulguée ou piratée, même trouvée en accès libre | loi 2013-451, art. 11 : puni quiconque « fait usage, en connaissance de cause, de données informatiques frauduleusement obtenues » ; art. 24 : traitement de données « par un moyen frauduleux, déloyal ou illicite » |
| Contacter l'entourage, un ancien employeur non cité comme référence, un voisin, sans l'accord du candidat | loi 2013-450, art. 15 et 28. Les références se prennent avec `prise-references`, et contacter une référence reste un arrêt obligatoire du processus |
| Noter l'origine ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses ou philosophiques, l'appartenance syndicale, la vie sexuelle, la santé | loi 2013-450, art. 21 : collecte et traitement interdits et punis pénalement. Code du travail, art. 4 : l'employeur ne peut prendre en considération, pour l'embauche, « le sexe, l'âge, l'ascendance nationale, la race, la religion, l'opinion politique et religieuse, l'origine sociale », l'appartenance syndicale, la séropositivité ou le handicap |
| Collecter la vie privée sans lien avec le poste : famille, relations, loisirs, domicile, patrimoine personnel | loi 2013-450, art. 16 (données non excessives au regard de la finalité) |
| Obtenir un casier judiciaire autrement que remis par le candidat lui-même | voir section 3 et section 7 |
| Relever un numéro de téléphone, un numéro d'identification nationale | loi 2013-450, art. 7 : un traitement portant sur ces identifiants est soumis à autorisation préalable de l'ARTCI. La fiche n'en a pas besoin |

L'exception de l'article 21 pour les « données manifestement rendues publiques par la personne
concernée » ne rouvre rien ici : même publiques, ces données n'ont aucun lien avec un poste
(art. 16), et l'article 4 du Code du travail interdit d'en tenir compte à l'embauche.

### Le cas des données judiciaires

La loi range « les poursuites, les sanctions pénales ou administratives » parmi les données
sensibles (art. 1er, définition des données sensibles), et soumet à autorisation préalable de
l'ARTCI « le traitement des données à caractère personnel portant sur des données relatives aux
infractions, aux condamnations ou aux mesures de sûreté prononcées par les juridictions »
(art. 7).

Conséquence pratique, en attendant l'avis de l'expert juridique (section 7, question 1) : le
volet judiciaire de la fiche (poursuites, condamnations, mesures de sûreté) ne se consigne que
si le client confirme par écrit qu'il est couvert par une autorisation de l'ARTCI. Sans cette
confirmation, la vérification porte sur le reste (parcours, sociétés, présence professionnelle),
et la fiche dit en une ligne que le volet judiciaire n'a pas été traité et pourquoi.

## 3. L'information du candidat

### Le texte type

À insérer, au choix du client, dans l'annonce, dans le formulaire de candidature ou dans
l'accusé de réception. Il doit parvenir au candidat avant la vérification. Il couvre les huit
informations que l'article 28 impose : identité du responsable, finalité, catégories de
données, destinataires, possibilité de refuser, droits d'accès et de rectification, durée de
conservation, transfert éventuel hors CEDEAO.

> **Vérifications pour ce poste.** Ce poste comporte des responsabilités [financières / de
> direction]. Si votre candidature arrive en phase finale, [Nom de l'entreprise], responsable
> du traitement, pourra vérifier des informations publiques vous concernant, dans le seul but
> d'évaluer votre candidature à ce poste : presse, décisions de justice publiées, registres
> publics d'entreprises et présence en ligne professionnelle. Aucune donnée non publique ne
> sera recherchée, et personne de votre entourage ne sera contacté sans votre accord.
> Les résultats sont consultés uniquement par [fonction de la personne qui décide] et
> [cabinet de recrutement, le cas échéant], et détruits [durée validée, voir section 5].
> [Si l'hébergement est hors CEDEAO : ils peuvent être hébergés hors de la zone CEDEAO.]
> Vous pouvez refuser cette vérification, en le signalant à [adresse]. Vous pouvez aussi
> demander à consulter les résultats et à faire rectifier une information inexacte, à la
> même adresse.

Les crochets se remplissent avec le client, jamais par défaut. Tant que la durée de
conservation n'est pas fixée, le texte ne part pas.

Le texte informe. La loi fait du consentement exprès et préalable la règle (art. 14) et le
définit comme une volonté « expresse, non équivoque, libre, spécifique et informée » (art. 1er).
Tant que l'expert juridique n'a pas dit si l'information suffit (section 7, question 2), on
ajoute au formulaire ou à l'accusé de réception une case non cochée d'avance :
« J'ai lu l'information ci-dessus et j'accepte ces vérifications si ma candidature arrive en
phase finale. » Sans case cochée, pas de vérification ; on ne conclut rien de ce refus, on le
signale au décideur.

### L'extrait de casier judiciaire

Si le client estime que le poste le justifie, on demande au candidat de **remettre lui-même**
un extrait de son casier judiciaire. Formulation type :

> Pour ce poste, nous demandons aux candidats en phase finale de nous présenter un extrait de
> leur casier judiciaire. Il sera consulté par [fonction] puis vous sera rendu ou détruit ; nous
> ne conservons que la date à laquelle il a été présenté.

Règles :

- on ne le cherche jamais par un autre canal que le candidat ;
- on consigne « extrait présenté le [date], consulté par [fonction] », sans recopier son
  contenu dans la fiche, parce que c'est une donnée relative aux condamnations (art. 7) et que
  la date de présentation suffit à la finalité (art. 16) ;
- la seule mention d'un casier que porte le Code du travail présent sur le disque vise le
  travail temporaire (décret n° 96-194 du 7 mars 1996, article 12, annexé au fichier du Code :
  une déclaration sur l'honneur « dans certains cas ») ; pour un recrutement ordinaire, la
  possibilité de l'exiger est la question 4 de la section 7.

## 4. Le livrable : la fiche de vérification

Une fiche factuelle, courte, qui peut être montrée au candidat tel quel : il a le droit
d'obtenir la communication des données le concernant et de leur origine (art. 29) et de faire
rectifier ce qui est inexact (art. 31). Écris chaque ligne en sachant qu'il la lira.

### Structure

```
FICHE DE VÉRIFICATION, CONFIDENTIELLE
Poste : [intitulé]                     Motif de sensibilité : [la phrase du client]
Demande du client : [qui, date]         Candidat : [référence dans l'outil de suivi]
Information du candidat : [date, canal]  Acceptation : [date, ou « case non cochée »]
Vérification faite le : [date]           Par : [nom de l'expert ou du recruteur]
Destruction prévue le : [date]

1. Sources consultées (y compris celles qui n'ont rien donné)
| Source | Requête ou page | Date de consultation | Résultat |

2. Faits établis
| Fait, en une phrase neutre | Source (titre, auteur) | Date de publication | Lien | Rattachement au candidat (éléments concordants) | Lien avec le poste |

3. Ce qui n'est pas établi
| Élément | Pourquoi il n'est pas établi |

4. Écarts avec le dossier de candidature
| Déclaré par le candidat | Constaté | Source |

5. Homonymie
[N] résultats au même nom non rattachés au candidat, non décrits.

6. Volet judiciaire
[traité sous autorisation confirmée le …] ou [non traité : autorisation non confirmée]

Décision : elle appartient à [fonction du décideur]. Cette fiche ne recommande rien.
```

### Règles de rédaction

- **Un fait par ligne, avec sa source.** « Le [titre de presse] du [date] rapporte que … ».
  Jamais « le candidat a … » quand seule la presse l'affirme.
- **L'état d'une affaire se dit tel que la source le dit**, avec sa date : une mise en cause
  n'est pas une condamnation, une décision de première instance n'est pas définitive, et une
  source ancienne ne dit rien de la suite.
- **Homonymie traitée explicitement.** Un résultat n'est rattaché au candidat que si, en plus
  du nom, **deux éléments indépendants** tirés de son dossier concordent (employeur à la date,
  fonction, ville, établissement de formation). Sinon il va en ligne 5, compté et non décrit :
  les données d'un homonyme sont celles d'une autre personne, que rien n'autorise à collecter.
  La loi exige des données exactes et l'effacement de celles qui sont inexactes (art. 17).
- **Aucune conclusion morale**, aucun qualificatif (« douteux », « sérieux », « fiable »),
  aucune note, aucun code couleur, aucun avis sur l'embauche. Aucune décision d'appréciation
  d'un comportement ne peut avoir pour seul fondement un traitement automatisé qui définit le
  profil ou la personnalité de l'intéressé (art. 25) : la fiche rapporte, un humain décide.
- **Rien trouvé est un résultat**, qui se dit avec la liste des sources consultées. Une
  absence de résultat n'établit pas une absence de fait.
- Hypothèse ou supposition : interdites dans cette fiche. Ce qui n'est pas établi va en
  section 3.

### Remise

- Un seul exemplaire, remis à la personne que le client a désignée pour décider.
- La fiche ne va pas dans le comparatif des candidats, ni dans un tableau de bord partagé, ni
  dans un fil de discussion de groupe : le traitement est confidentiel et effectué par les
  seules personnes qui agissent sous l'autorité du responsable (art. 39). Dans le fil, on écrit
  seulement « fiche remise à [fonction], le [date] ».
- Le dépôt automatique de livrables dans un dossier partagé ne s'applique pas à cette fiche.
  Son lieu de stockage se décide avec le client, et un hébergement hors CEDEAO est la question
  3 de la section 7.

## 5. Conservation et destruction

La loi pose que les données sont conservées pendant une durée qui « n'excède pas la période
nécessaire aux finalités » (art. 16), que cette durée est fixée par l'ARTCI selon les
finalités de chaque type de traitement (art. 43), et que l'effacement se fait « sans délai »
quand il est dû (art. 35). La durée fixée par l'ARTCI pour le recrutement n'est pas dans la
base locale.

La règle retenue jusqu'à l'avis de l'expert juridique (section 7, question 5) :

1. La finalité s'éteint quand la décision sur le poste est prise. À cette date, on détruit la
   fiche, ses brouillons, ses captures d'écran et ses extraits, pour tous les candidats
   vérifiés, retenu compris.
2. On détruit partout : dossier local du poste, stockage en ligne (corbeille vidée comprise),
   pièces jointes envoyées. On demande au client de confirmer la destruction de l'exemplaire
   remis.
3. Rien ne passe dans la mémoire du poste : ni dans `MEMORY.md`, ni dans le journal, ni dans
   un index de livrables. Le journal note au plus « vérification faite pour le poste [intitulé],
   le [date], fiche détruite le [date] », sans nom ni résultat.
4. Si le candidat demande l'accès (art. 29), la rectification (art. 31) ou l'effacement
   (art. 33) avant la destruction, on prépare la réponse et on s'arrête : c'est au client, en
   tant que responsable du traitement, de répondre.

## 6. Contrôle avant remise

Avant de remettre la fiche, vérifie chaque point. Un seul « non », et tu ne remets pas : tu
corriges, ou tu dis ce qui bloque.

1. La demande écrite du client, le poste et son motif de sensibilité figurent en tête.
2. La date d'information du candidat est antérieure à la date de vérification, et
   l'acceptation est notée.
3. Chaque fait porte une source, une date de publication, un lien vers la page ouverte et une
   date de consultation.
4. Chaque fait rattaché au candidat cite ses deux éléments concordants ; les homonymes sont
   comptés, pas décrits.
5. Aucune donnée de l'article 21 ni de l'article 4 du Code du travail, aucun numéro de
   téléphone ou d'identification, rien sur la famille ou la vie privée.
6. Aucune source non publique, aucune page lue derrière une connexion.
7. Le volet judiciaire est traité sous autorisation confirmée, ou déclaré non traité.
8. Aucun qualificatif, aucune note, aucune recommandation ; la phrase finale laisse la
   décision au décideur nommé.
9. La date de destruction est écrite, et le destinataire est une personne nommée, pas un
   dossier partagé.
10. Le texte passe `python3 ~/.claude/outils-communs/relire-sans-tics.py <fiche>`.

## 7. À faire valider par l'expert juridique

Les textes présents sur le disque ne tranchent pas ces points. Ils se posent à l'expert
juridique, et ce qui est écrit ci-dessus en attendant est une mesure de prudence, pas une
règle de droit.

1. **Autorisation de l'ARTCI pour le volet judiciaire.** Une vérification qui relève dans la
   presse ou dans une décision publiée une poursuite ou une condamnation constitue-t-elle un
   « traitement portant sur des données relatives aux infractions, aux condamnations ou aux
   mesures de sûreté » soumis à autorisation préalable (art. 7) ? Si oui, qui doit la détenir :
   l'employeur, le cabinet qui vérifie, ou les deux ? À faire valider par l'expert juridique.
2. **Fondement du traitement.** L'information du candidat suffit-elle, ou faut-il son
   consentement exprès et préalable (art. 14) ? La dérogation de l'article 14 pour les
   « mesures précontractuelles prises à sa demande » peut-elle s'appliquer, sachant qu'elle
   suppose un responsable « dûment autorisé » ? Un consentement donné par un candidat à un
   emploi est-il « libre » au sens de l'article 1er ? À faire valider par l'expert juridique.
3. **Hébergement et outils hors CEDEAO.** Stocker la fiche ou faire la recherche avec des outils
   hébergés hors de la zone CEDEAO est-il un transfert vers un pays tiers soumis à autorisation
   (art. 26 et art. 7) ? À faire valider par l'expert juridique.
4. **Extrait de casier judiciaire.** Un employeur privé peut-il exiger un extrait de casier d'un
   candidat à un poste de finance ou de direction, hors travail temporaire ? Peut-il écarter un
   candidat qui refuse ? Quel volet de l'extrait peut être demandé ? Le code de procédure
   pénale n'est pas dans la base locale. À faire valider par l'expert juridique.
5. **Durée de conservation.** L'ARTCI a-t-elle fixé une durée pour les traitements de
   recrutement (art. 43) ? La destruction à la décision est-elle compatible avec un éventuel
   contentieux du candidat écarté ? Une trace minimale (poste, date, destruction) est-elle
   admise ? À faire valider par l'expert juridique.
6. **Formalités du client.** La déclaration préalable de l'employeur pour ses traitements de
   recrutement (art. 5) couvre-t-elle cette vérification, ou faut-il la compléter (art. 9 :
   toute modification des mentions déclarées est portée à l'ARTCI) ? Le cabinet qui vérifie
   pour le compte du client est-il sous-traitant (art. 20 et 40) ? À faire valider par
   l'expert juridique.
7. **Refus du candidat.** Si le candidat refuse la vérification, ce que l'article 28 lui permet
   (« la possibilité de refuser de figurer sur le fichier »), l'employeur peut-il en tenir
   compte dans sa décision ? À faire valider par l'expert juridique.

Tant qu'une réponse n'est pas revenue, la section concernée reste appliquée telle qu'écrite.
Quand elle revient, on met à jour cette compétence avec l'article et la date de l'avis.

## Articles cités

| Texte | Article | Objet |
|---|---|---|
| Loi 2013-450 | art. 1er | définitions du consentement et des données sensibles (dont poursuites et sanctions pénales) |
| Loi 2013-450 | art. 5 | déclaration préalable auprès de l'ARTCI |
| Loi 2013-450 | art. 7 | autorisation préalable : infractions, condamnations, mesures de sûreté ; identifiants dont numéros de téléphone ; transfert vers un pays tiers |
| Loi 2013-450 | art. 9 | mentions de la déclaration, dont la durée de conservation ; modifications portées à l'ARTCI |
| Loi 2013-450 | art. 14 | consentement exprès et préalable, et ses dérogations |
| Loi 2013-450 | art. 15 | collecte licite et loyale |
| Loi 2013-450 | art. 16 | finalité, pertinence, durée limitée |
| Loi 2013-450 | art. 17 | exactitude, effacement de l'inexact |
| Loi 2013-450 | art. 20 et 40 | sous-traitant |
| Loi 2013-450 | art. 21 | données dont la collecte est interdite |
| Loi 2013-450 | art. 25 | pas de décision fondée sur le seul traitement automatisé d'un profil |
| Loi 2013-450 | art. 26 | transfert vers un pays tiers |
| Loi 2013-450 | art. 28 | information de la personne, au plus tard lors de la collecte |
| Loi 2013-450 | art. 29, 31, 33 | accès, rectification, effacement |
| Loi 2013-450 | art. 35 | effacement sans délai |
| Loi 2013-450 | art. 39 | confidentialité du traitement |
| Loi 2013-450 | art. 43 | durée de conservation fixée par l'ARTCI |
| Loi 2013-451 | art. 4 | accès frauduleux à un système d'information |
| Loi 2013-451 | art. 11 | usage de données frauduleusement obtenues |
| Loi 2013-451 | art. 19 | usage frauduleux d'éléments d'identification d'autrui |
| Loi 2013-451 | art. 24 | traitement par un moyen frauduleux, déloyal ou illicite |
| Code du travail 2015-532 | art. 4 | critères interdits à l'embauche |
| Décret 96-194 | art. 12 | déclaration sur l'honneur de non-condamnation, travail temporaire seulement |

## Compétences liées

- `processus-recrutement` : étape 6, avec la prise de références, avant toute offre.
- `prise-references` : ce qui passe par des personnes, avec l'accord du candidat.
- `donnees-personnelles-ci` : le régime complet de la loi 2013-450.
- `aller-chercher` : l'ordre des outils de recherche.

## Historique

- v1, 23/09/2026 : création, séance Sync agents training.
