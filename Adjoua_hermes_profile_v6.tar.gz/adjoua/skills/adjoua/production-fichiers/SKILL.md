---
id: Y0380
name: production-fichiers
description: "Ce que je peux réellement produire sur cette machine, et comment : tableur avec menus déroulants et formules, document modifiable, PDF, page interactive. À charger avant de promettre un format à un recruteur. Contient les commandes exactes, vérifiées le 04/08/2026."
bucket: A
tags: [Recrutement, Outillage]
version: 1
maj: 2026-08-04
---

# Production de fichiers — capacités réelles

Beaucoup de compétences promettent « un tableur », « un document modifiable », « une page
interactive ». Cette fiche dit **ce qui est réellement possible ici**, avec la commande. Une
promesse de format qu'on ne peut pas tenir se découvre au pire moment : quand le recruteur attend
le fichier.

Toutes les capacités ci-dessous ont été **testées le 04/08/2026**, pas supposées.

## Tableur — `.xlsx`

Moteur : `openpyxl` dans `/home/openclaw/.venv-office`. Installé le 04/08/2026 ; **rien ne
permettait de produire un tableur avant cette date**, alors que six compétences en promettaient un.

```bash
/home/openclaw/.venv-office/bin/python mon_script.py
```

Vérifié comme fonctionnel : **menu déroulant** sur une colonne (`DataValidation` en liste),
**formule** calculée et visible, **couleur de fond** par catégorie, **commentaire de cellule** pour
porter les ancrages de notation, **plusieurs onglets**, largeur de colonnes.

C'est exactement ce qu'exige `grille-evaluation` : les 15 critères en couleurs par catégorie, la note
en liste déroulante de 1 à 5, les ancrages « ce qui vaut 5 / ce qui vaut 2 » en commentaire, la note
pondérée par formule, et l'onglet de comparaison entre candidats.

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment
dv = DataValidation(type="list", formula1='"1,2,3,4,5"', allow_blank=True)
ws.add_data_validation(dv); dv.add(cellule)
cellule.comment = Comment("5 = …\n2 = …", "grille")
```

⚠️ **Ne jamais rendre un bloc de valeurs séparées par des virgules à recopier** quand un tableur est
attendu. Les prompts d'origine l'interdisent explicitement, et ils ont raison : personne ne recopie.

## Document modifiable — `.docx`

Moteur : `python-docx`, même environnement. Pour les livrables que l'équipe doit retoucher — guide
d'entretien, modèle de contrat.

## PDF

Moteur : `weasyprint` dans `/home/openclaw/.venv-weasyprint`. On écrit du HTML autonome, on rend.

```bash
/home/openclaw/.venv-weasyprint/bin/weasyprint fichier.html fichier.pdf
pdfinfo fichier.pdf | grep -i pages
pdftoppm -png -r 92 fichier.pdf /tmp/apercu     # relire avant d'envoyer
```

Voir `livrable-html-pdf` pour les pièges de rendu et la feuille d'impression.

⚠️ **Les emojis ne sont pas dessinés** dans le PDF : aucune police couleur n'est installée. Ils
restent dans le texte mais n'apparaissent pas. Ne pas en mettre dans les intertitres d'un document
destiné au PDF.

## Page interactive

HTML autonome, tout inclus, aucune ressource externe. Convient aux tableaux triables et filtrables
que promettent `recrutement-linkedin` et `evaluation-candidat`.

## Ce qui n'est pas disponible

| Format | État | Repli |
|---|---|---|
| Conversion bureautique automatique | ni convertisseur bureautique ni convertisseur universel | Produire directement dans le bon format |
| Bibliothèque de traitement d'image | aucune installée | Décodeur PNG en Python pur, via `zlib` — méthode éprouvée pour relever les couleurs d'un logo |
| Polices emoji couleur | absentes | Ne pas compter dessus dans un PDF |

## Lecture web — ce qui passe et ce qui ne passe pas

| Source | État vérifié le 04/08/2026 |
|---|---|
| Outil de suivi des candidatures | ✅ lecture et écriture |
| Sites d'emploi ivoiriens | ✅ lecture |
| Sites d'entreprises, textes réglementaires | ✅ lecture |
| **Profils de réseaux professionnels** | ❌ **mur d'authentification** — la page se charge mais rend un écran de connexion, pas le profil |

Ce dernier point est structurant : voir `recrutement-linkedin`.
