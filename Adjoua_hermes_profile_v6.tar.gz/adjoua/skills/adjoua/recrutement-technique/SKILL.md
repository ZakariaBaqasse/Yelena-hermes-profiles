---
id: Y0592
name: recrutement-technique
description: Recruter sur les métiers techniques — évaluer un profil d'ingénieur, de développeur, de data ou d'IA quand on n'est pas soi-même ingénieur. Ce que la recherche prouve sur l'entretien technique, le format qui prédit vraiment, et comment calibrer un évaluateur. À charger dès qu'un poste technique s'ouvre.
version: 1
maj: 2026-08-13
---

# Recrutement technique

## Le problème central, et il est mesuré

L'entretien technique tel qu'il se pratique — écrire du code au tableau en pensant à voix haute
sous le regard d'un examinateur — **ressemble presque trait pour trait au test de stress social de
Trier**, la procédure que les psychologues emploient depuis des décennies pour induire du stress
de façon fiable. La ressemblance n'est pas une image : c'est la comparaison faite par les auteurs
de l'étude ci-dessous, et elle est structurelle — une tâche cognitivement exigeante **plus** une
menace d'évaluation sociale, c'est-à-dire le fait d'être regardé.

### Ce que l'essai randomisé montre

_Source lue intégralement le 13/08/2026 : Behroozi, Shirolkar, Barik & Parnin,_
*Does Stress Impact Technical Interview Performance?*, ESEC/FSE 2020 —
<http://www.chrisparnin.me/pdf/stress_FSE_20.pdf>
_(archivée : `reference/sources-metier/behroozi-2020-stress-entretien-technique.pdf`)_

48 participants, répartis au hasard entre un tableau **public** (examinateur présent, pensée à voix
haute) et un tableau **privé** (même problème, même durée, personne ne regarde).

| Mesure | Public | Privé |
|---|---|---|
| Ont échoué à la tâche | **61,5 %** | **36,3 %** |
| Score de correction (tests passés) | 1,58 ± 1,29 · médiane **1** | 2,29 ± 1,12 · médiane **3** |
| Frustration et stress (NASA-TLX) | 11 | 7 |

Différence significative sur la correction (Mann-Whitney, p = 0,038, d = 0,57) et sur le stress
(p = 0,004, d = 0,64). La dilatation pupillaire (charge cognitive) et la vitesse de saccade
oculaire (stress) confirment par la mesure physiologique ce que les participants déclarent.

**La conclusion des auteurs, à retenir mot pour mot** : les examinateurs « filtrent peut-être des
candidats qualifiés en confondant l'évaluation de la capacité à résoudre un problème avec un stress
inutile ».

⚠️ **Un résultat post-hoc à manier avec précaution** : dans le cadre public, **aucune femme** (n=5)
n'a résolu la tâche ; dans le cadre privé, **toutes** (n=4) l'ont résolue, dont deux avec la
solution optimale. Les effectifs sont minuscules et c'est une analyse post-hoc — cela ne démontre
rien à soi seul. Mais cela indique où regarder, et cela suffit à ne pas maintenir un format dont on
n'a jamais mesuré l'effet.

### Le format qui répare, et il est testable ici

_Source lue le 13/08/2026 : Behroozi, Parnin & Brown,_ *Asynchronous Technical Interviews*,
ESEC/FSE 2022 — <https://chbrown13.github.io/papers/async_fse22.pdf>
_(archivée : `reference/sources-metier/behroozi-2022-entretien-technique-asynchrone.pdf`)_

Le candidat résout le problème **seul**, en enregistrant son écran et sa voix. L'évaluateur regarde
l'enregistrement ensuite. 24 participants.

| Mesure | Enregistrement | Tableau supervisé |
|---|---|---|
| Solution optimale | **75 %** (n=18) | **13 %** (n=3) |
| Communication jugée efficace | 83 % (n=20) | 54 % |
| Échantillons d'une minute marqués « stressé » | 14 % | **86 %** |

Les candidats parlent **plus vite** et **plus** en enregistrement, et **vérifient significativement
plus souvent leur solution**.

**Pourquoi ce format est le bon ici, et pas seulement en théorie** — trois problèmes réels qu'il
règle d'un coup :
1. Il supprime le point unique d'évaluation : l'enregistrement se regarde par plusieurs personnes,
   à des moments différents. Le recrutement ne s'arrête plus quand un évaluateur est absent.
2. Il rend l'évaluation **comparable** : tous les candidats ont le même énoncé, la même durée, et
   on peut revoir la séquence pour départager deux finalistes.
3. Il traite le décalage horaire et la diaspora sans organiser de créneau commun.

**Ce qu'il coûte** : il faut un énoncé bien écrit, une grille remplie pendant le visionnage, et
accepter de ne pas pouvoir relancer le candidat en direct. Ce dernier point est une perte réelle —
la compenser par un entretien ciblé **après** visionnage, qui reprend deux ou trois moments de
l'enregistrement.

### Ce que les candidats font réellement pour se préparer

_Source lue le 13/08/2026 : Bell, Thomas, Lee & Brown,_ *How do Software Engineering Candidates
Prepare for Technical Interviews?*, FSE 2025 — <https://arxiv.org/pdf/2507.02068>
_(archivée : `reference/sources-metier/bell-2025-preparation-candidats.pdf`)_

131 personnes, neuf ans d'expérience en moyenne (médiane 7). Elles consacrent **6,5 heures par
semaine** (médiane 4) à préparer des entretiens techniques. **78 %** jugent la communication
déterminante, mais la majorité ne l'entraîne pas, et **62 % ne s'entraînent jamais avec quelqu'un**.

**Ce que cela dit d'un entretien au tableau** : il mesure en partie le **temps de préparation
disponible**. Quelqu'un qui a un emploi prenant, des charges familiales, ou pas de réseau pour
s'entraîner part avec un handicap qui n'a aucun rapport avec sa compétence d'ingénieur. Sur un
marché comme celui d'Abidjan, où peu de candidats ont un entourage qui pratique ces exercices,
c'est un filtre social déguisé en filtre technique.

---

## Comment évaluer un profil technique quand on n'est pas ingénieur

C'est la situation réelle d'un service de recrutement. Elle se traite, mais pas en bluffant.

**1. Ne jamais juger la technique soi-même — organiser le jugement.**
Le rôle du recruteur est de rendre le jugement technique **possible et comparable** : écrire
l'énoncé avec l'équipe, imposer la même épreuve à tous, tenir la grille, faire noter par ceux qui
savent, et repérer les désaccords entre évaluateurs. Un recruteur qui note lui-même un code produit
une note sans valeur ; un recruteur qui fait noter trois personnes sur la même grille produit une
décision.

**2. Ce qu'un non-ingénieur peut évaluer seul, et qui prédit :**
- **La cohérence entre ce qui est écrit et ce qui est dit.** Un candidat qui ne sait pas expliquer
  un projet qu'il revendique n'y a pas tenu le rôle qu'il annonce. Question : « quelle décision
  technique avez-vous prise **vous** sur ce projet, et qu'auriez-vous fait autrement ? »
- **L'échelle réelle.** Combien d'utilisateurs, combien de données, combien de personnes dans
  l'équipe, en production ou en démonstration. Ce sont des faits, pas des jugements.
- **Le rapport à l'erreur.** « Racontez une panne dont vous étiez responsable. » Un ingénieur qui
  n'a jamais rien cassé n'a jamais rien mis en production.
- **La distance entre prototype et production.** Elle se vérifie par des questions factuelles :
  qui appelait quand ça tombait, quelle surveillance, combien de temps entre deux mises en ligne.

**3. Le vocabulaire ne s'imite pas, il se vérifie.**
Ne jamais recopier une liste de technologies dans une fiche sans savoir ce qu'elle recouvre. Une
exigence qu'on ne sait pas expliquer ne peut pas être évaluée, et elle écarte des gens pour rien.
Demander à l'équipe technique : « qu'est-ce que quelqu'un qui sait faire ça sait faire, exactement,
et qu'est-ce qui s'apprend en trois mois ? » — la seconde moitié de la question retire souvent la
moitié des exigences.

**4. Calibrer les évaluateurs.**
Faire noter le **même** enregistrement par deux évaluateurs séparément, puis comparer. Un écart de
plus d'un point sur cinq signale une grille ambiguë, pas un candidat ambigu. C'est le seul exercice
qui rend une grille technique fiable, et il coûte une heure.

---

## Ce qui s'applique désormais à tout poste technique que je traite

1. **Proposer l'épreuve enregistrée en premier choix**, l'entretien au tableau seulement si
   l'employeur y tient — et dans ce cas lui dire ce que la mesure montre.
2. **Écrire l'énoncé avec l'équipe technique**, identique pour tous, avec ses critères de réussite
   écrits avant le premier passage.
3. **Entretien structuré systématique** après l'épreuve (0,58 contre 0,33 pour l'épreuve seule) :
   c'est la combinaison qui décide, jamais l'épreuve seule.
4. **Deux évaluateurs minimum**, notation séparée avant discussion.
5. **Ne jamais présenter une note technique comme la mienne** : je porte la méthode et la trace,
   l'équipe porte le jugement.
6. ⚠️ **Le marché local ne contient pas toujours le profil rêvé.** Sur le poste de direction
   technique en cours, aucun profil du vivier accessible ne montre d'agents à base de modèles de
   langage en production. Le dire tôt vaut mieux que laisser un poste ouvert quarante-cinq jours :
   un critère éliminatoire que **personne** ne franchit ne sélectionne rien, il condamne le poste.

## Provenance

Compétence écrite le 13/08/2026 sur demande du client. Trois sources primaires lues en entier et
archivées dans `reference/sources-metier/`. Prolonge `referentiel-metier-recruteur`.
Voir aussi `guide-entretien`, `test-competences`, `business-case`, `grille-evaluation`.
