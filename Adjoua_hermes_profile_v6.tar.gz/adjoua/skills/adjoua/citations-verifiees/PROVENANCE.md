# Identifiant Yelema : Y0731

# Provenance

Cette compétence n'a pas été écrite par nous. Elle vient du dépôt public
**NousResearch/hermes-agent** (https://github.com/NousResearch/hermes-agent), dossier
`skills/research/grounded-citations`, version amont 1.2.0, récupérée le **23/09/2026** et
posée au catalogue le **24/09/2026**.

- Licence : **MIT** (fichier `LICENSE` de ce dossier, Nous Research). Redistribution permise
  en gardant le fichier `LICENSE`.
- Nom changé en `citations-verifiees` : une compétence externe ne remplace jamais une des
  nôtres (règle de la direction, 23/09/2026).
- Adaptations locales : voir `ADAPTATIONS.md`, qui prime sur `SKILL.md`.
- Script `scripts/sources.py` relu : bibliothèque standard seulement, aucun appel réseau.
