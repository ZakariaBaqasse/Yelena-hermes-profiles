# Adaptations locales (citations-verifiees)

Ce fichier prime sur `SKILL.md`.

## Le geste, en cinq temps, avec nos outils

Le script : `python3 <dossier de cette compétence>/scripts/sources.py`. Le registre se crée
dans `cache/citations/ledger.json` du poste courant.

1. `sources.py reset` au début d'une tâche qui produira une réponse ou un livrable sourcé.
2. Au moment où une page est ouverte (WebFetch, `integrations/web-public/`, Brave, un texte
   de la couche locale), `sources.py add <url> --title "<titre>"` : il rend le numéro `[n]`.
   Jamais après coup, jamais de mémoire.
3. Écrire en citant phrase par phrase avec les numéros rendus, trois au plus par phrase.
4. `sources.py render --cited-in <brouillon>` engendre la liste des sources. On ne retape
   jamais une adresse.
5. `sources.py verify <brouillon>` avant de livrer. Il échoue sur un numéro inconnu ou une
   liste de sources qui ne correspond pas au registre.

## Mode vérification, obligatoire pour le juridique, le chiffré et le sensible

Droit, paie, fiscalité, chiffre de marché, citation d'une personne, fait contesté : on
enregistre le texte de la page dans un fichier, puis
`sources.py quote <n> --text "<phrase exacte>" --from <fichier>`. La citation est refusée si
elle n'y figure pas mot pour mot. Puis `verify --evidence`.

## Ce qui change par rapport au texte amont

- `[unverified]` s'écrit `[non vérifié]` dans nos livrables, et reste l'exception :
  `socle-anti-hallucination` prime (un marquage se mérite après la recherche, trois
  marquages sur une page veulent dire que le livrable est inachevé). Le script ne reconnaît
  que `[unverified]` : pour son contrôle de couverture, remplacer à la fin, pas pendant
  l'écriture.
- Les sections « Multi-Platform Sweeps » (Reddit, X, YouTube, `gh`) ne s'appliquent pas :
  l'échelle de recherche est celle de la compétence `aller-chercher`.
- Dans un livrable Google Docs, Slides ou PDF, la liste des sources va en fin de document
  (ou sur une diapositive « Sources ») : voir `references/citation-formats.md`.
- Français, aucun tiret cadratin, aucun chiffre sans source (socles).
