"""Adaptation locale (24/09/2026) : le registre des sources vit dans le poste qui travaille.

L'amont rangeait le registre sous ~/.hermes. Ici, get_hermes_home() rend le dossier courant,
qui est le workspace de l'expert : le registre tombe donc dans ./cache/citations/ledger.json,
un dossier qui n'entre ni dans les exports ni dans les paquets. HERMES_HOME reste accepté
pour forcer un autre endroit.
"""

from __future__ import annotations

import os
from pathlib import Path


def get_hermes_home() -> Path:
    val = os.environ.get("HERMES_HOME", "").strip()
    return Path(val) if val else Path.cwd()
