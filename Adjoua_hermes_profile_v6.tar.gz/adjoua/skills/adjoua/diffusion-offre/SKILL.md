---
id: Y0369
name: diffusion-offre
description: "Décline une fiche de poste en annonces réellement publiables, une par canal — LinkedIn, sites d'emploi locaux, écoles et associations d'anciens, groupes WhatsApp et Facebook professionnels, cooptation interne, message d'approche directe pour les profils qui ne postulent jamais — avec calendrier de publication, de relance et suivi de ce qui rapporte quoi. Jamais un copier-coller de la fiche de poste d'un canal à l'autre."
bucket: A
tags: [Recrutement, RH, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Diffusion de l'offre — publier là où sont les gens

## Ce qu'il faut avoir sous la main
- **La fiche de poste** (ou son contenu : intitulé, missions, profil recherché, ce qui est proposé).
- **Les canaux auxquels tu as accès** : LinkedIn entreprise ou personnel, jobboards abonnés, groupes WhatsApp ou Facebook professionnels, écoles ou associations d'anciens, réseau de cooptation interne.
- **Comment postuler concrètement** : e-mail, formulaire, numéro WhatsApp, personne à contacter.
- **La date limite de candidature**, ou l'urgence réelle du poste.
- **Ce que tu peux dire ou non sur la rémunération** dans l'annonce publique.
- **Si la cooptation est incentivée** (prime, avantage) ou non.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Lire la fiche de poste comme la lirait quelqu'un qui ne connaît pas l'entreprise

Repère ce qui, dans la fiche, est du jargon interne (intitulé de service, sigle, grade) et ce qui parlerait vraiment à un candidat externe : le métier réel au quotidien, ce qui est proposé, ce qui rend le poste different des dix autres offres similaires. Une fiche de poste écrite pour un comité de validation interne et publiée telle quelle en annonce est le premier signe d'une diffusion bâclée — elle se reconnaît à ses phrases qui commencent par « le titulaire du poste sera amené à… ».

Extrait de cette lecture les deux ou trois éléments qui doivent apparaître dans **toutes** les déclinaisons, quel que soit le canal : l'intitulé compréhensible, l'essentiel de la mission, et l'appel à l'action. Le reste change de forme selon le canal.

### Étape 2 — Cartographier les canaux pertinents pour ce poste précis, pas pour tous les postes

Tous les canaux ne se valent pas pour tous les profils. Un poste de finance senior se trouve rarement dans un groupe WhatsApp généraliste ; un poste de terrain junior à Abidjan se trouve rarement sur un jobboard international. Avant de décliner quoi que ce soit, tranche : parmi les canaux disponibles, lesquels touchent réellement le public visé, et lesquels seraient une perte de temps pour ce poste précis.

Si l'entreprise n'a accès à aucun canal pertinent pour le profil recherché, dis-le explicitement plutôt que de forcer une diffusion sur ce qui est disponible mais mal ciblé — c'est un signal à remonter, pas à masquer par une annonce de plus.

### Étape 3 — Décliner canal par canal : format, ton, appel à l'action

C'est ici que le copier-coller tue le recrutement. Une même offre recopiée à l'identique sur LinkedIn, dans un groupe WhatsApp métier et dans un mail à un responsable de filière d'école ne rate pas seulement le ton attendu — elle signale au lecteur une entreprise qui n'a pas fait l'effort de s'adresser à lui spécifiquement, et ça se retourne contre l'attractivité du poste avant même d'être lu jusqu'au bout.

Pour chaque canal retenu, produis une version distincte :
- **LinkedIn** : format long autorisé, ton professionnel, structure lisible (mission, profil, ce qui est proposé, comment postuler), peut inclure un mot sur la culture d'entreprise.
- **Jobboard local** : format qui respecte les champs imposés par la plateforme (titre, résumé, description), pensé pour la recherche par mot-clé — l'intitulé doit contenir les termes qu'un candidat taperait, pas un intitulé interne créatif.
- **Groupe WhatsApp ou Facebook professionnel** : quatre à six lignes maximum, ton direct et humain, pas de jargon RH, appel à l'action immédiat (numéro, lien court) — ce message se lit sur un téléphone entre deux tâches, il doit se comprendre du premier coup d'œil.
- **École ou association d'anciens** : mail ou message adressé à une personne nommée (responsable de filière, référent asso), qui explique pourquoi ce poste convient à leurs profils spécifiquement, pas une annonce générique transférée telle quelle.

Chaque déclinaison porte les mêmes trois invariants de l'étape 1, mais rien d'autre n'est recopié tel quel d'un canal à l'autre.

### Étape 4 — Le message de cooptation interne

La cooptation ne s'adresse pas à un candidat, elle s'adresse à un salarié à qui on demande de mobiliser son réseau. Le message est donc différent dans son fond : il rappelle en une phrase le poste, dit clairement ce qu'on attend du salarié (transférer, recommander, mettre en relation), et si une prime ou un avantage de cooptation existe, l'indique sans ambiguïté — un salarié qui coopte sans savoir s'il y a une contrepartie coopte une fois, pas deux.

Ce message doit être copiable-collable en un geste par le salarié — s'il faut qu'il réécrive ou résume, il ne le fera pas.

### Étape 5 — Le message d'approche directe pour les profils qui ne cherchent pas

La plupart des bons candidats pour un poste à responsabilité ou une compétence rare ne consultent aucune annonce : ils sont en poste, satisfaits ou non, et ne cherchent pas activement. Compter uniquement sur la publication d'une offre pour les atteindre, c'est attendre que quelqu'un qui ne regarde pas la vitrine entre dans le magasin.

Pour ces profils, produis un message d'approche directe (LinkedIn, e-mail, ou WhatsApp si le contact existe déjà) qui n'est **pas** un résumé de l'annonce : il commence par ce qui, dans le profil de la personne, a motivé le contact, avant de présenter l'opportunité — un message qui ouvre par « nous recrutons un… » sonne comme un mailing de masse et se ferme aussi vite qu'il s'est ouvert. Précise aussi la façon la plus discrète de répondre : beaucoup de candidats passifs hésitent à répondre publiquement à une sollicitation professionnelle.

### Étape 6 — Le calendrier de publication, de relance et le mode de candidature

Une annonce publiée sans dire jusqu'à quand ni comment postuler perd des candidats non par désintérêt mais par confusion — quelqu'un qui hésite entre répondre au post, envoyer un e-mail ou chercher un formulaire renonce souvent avant d'avoir tranché. Chaque déclinaison doit porter **une seule voie de candidature clairement désignée**, même si elle redirige ensuite vers un formulaire central.

Construis le calendrier : quel canal publie en premier, quand chaque déclinaison sort, à quel moment une relance est envisagée si le volume de candidatures est insuffisant, et jusqu'à quelle date la diffusion reste active. La date limite et le seuil de volume qui déclenche une relance sont des décisions de l'équipe recrutement — tu poses la structure du calendrier, la date et le seuil restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés.

### Étape 7 — Le suivi de ce qui rapporte quoi

Prévois, canal par canal, ce qui doit être compté pour savoir ce qui a fonctionné : nombre de candidatures reçues par voie d'entrée, si l'information est disponible. Ce n'est pas un tableau à remplir avec des chiffres inventés pour faire joli — c'est une grille vide tant que les données réelles ne sont pas remontées, avec la question à laquelle elle doit répondre : quel canal continuer, lequel abandonner pour le prochain poste similaire.

## Format de sortie
- **Livrable** : le kit de diffusion — une version prête à publier par canal retenu, le message de cooptation interne, le message d'approche directe pour profils passifs, le calendrier de publication et de relance, et la grille de suivi de ce qui a rapporté quoi.
- **Structure** : Markdown, une section par canal avec le texte prêt à copier-coller, clairement délimité ; le calendrier sous forme de tableau ; la grille de suivi sous forme de tableau à colonnes vides tant que les données ne sont pas fournies.
- **Longueur** : chaque déclinaison respecte le format réel du canal — un message WhatsApp ne s'étire pas parce que le document Markdown le permet.
- **Les dates et seuils sont un input**, pas une production : la skill livre la structure du calendrier et de la grille de suivi ; la date limite, la date de relance et le seuil de volume restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés.
- **Règle 0 invention** : aucun chiffre de rémunération, de volume de candidatures ou de statistique de canal inventé. Information manquante marquée « à confirmer / [placeholder] ».

## Règles
1. **Jamais deux canaux avec le même texte.** Chaque déclinaison est réécrite pour son format et son public ; un copier-coller signale une entreprise qui n'a pas fait l'effort, et ça coûte des candidatures avant même d'être lu en entier.
2. **L'annonce seule ne suffit jamais pour les profils rares ou en poste.** Si le poste est à responsabilité, technique ou rare, le kit inclut obligatoirement un message d'approche directe — compter uniquement sur la publication revient à attendre que des gens qui ne cherchent pas tombent dessus par hasard.
3. **Chaque déclinaison porte une voie de candidature unique et une échéance visible.** Une annonce sans « comment » ni « jusqu'à quand » perd des candidats par confusion, pas par désintérêt.
4. **0 chiffre inventé.** Aucun volume de candidatures attendu, aucun taux de conversion par canal, aucune prime de cooptation n'est produit sans être fourni : `⟦à renseigner⟧` sinon.
5. **Le canal WhatsApp et les groupes Facebook professionnels sont des canaux de recrutement à part entière**, pas un pis-aller par rapport à LinkedIn — dans beaucoup de métiers en Côte d'Ivoire, c'est là que circule l'information sur les postes disponibles avant tout jobboard.
6. **Vigilance sur les mentions discriminatoires.** Si la fiche de poste contient des critères d'âge, de sexe, de situation familiale non justifiés par le poste, tu le signales avant diffusion plutôt que de les recopier tel quel dans l'annonce publique — sans citer de texte de loi que tu n'as pas reçu.
7. **La rémunération ne s'affiche que si l'entreprise l'autorise.** Tu ne mentionnes jamais un montant dans une annonce publique sans confirmation explicite que ce montant peut être communiqué.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un kit de diffusion ; publier réellement une annonce, envoyer un message d'approche à un candidat nommé ou solliciter le réseau interne est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un poste ou d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fiche de poste incomplète** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun canal précisé** — tu proposes les canaux plausibles pour ce type de poste en les marquant `[hypothèse]`, et tu demandes confirmation avant de livrer les déclinaisons finales.
- **Rémunération non communicable** — tu rédiges les annonces sans montant, avec une formulation neutre (« rémunération selon profil ») plutôt que d'inventer une fourchette.
- **Date limite non donnée** — le calendrier est livré avec la date en `⟦à renseigner⟧`, et tu signales que sans échéance, la diffusion risque de traîner sans relance.
- **Poste ouvert à la cooptation sans incitation définie** — tu rédiges le message de cooptation sans mentionner de prime, et tu signales explicitement l'absence d'incitation plutôt que d'en inventer une.
- **Demande hors périmètre** (rédaction de la fiche de poste elle-même, définition de la grille salariale, tri des candidatures reçues) — tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (publier réellement, envoyer le message d'approche à un contact nommé, lancer la cooptation) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Canal fourni mais inaccessible ou obsolète** (lien de groupe expiré, jobboard qui a changé de format) — tu le signales et tu travailles avec les canaux confirmés restants.
