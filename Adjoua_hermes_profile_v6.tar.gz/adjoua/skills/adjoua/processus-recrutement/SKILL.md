---
id: Y0379
name: processus-recrutement
description: "Le processus de recrutement complet en 7 étapes, et quelle compétence charger à chacune. À charger DÈS QU'UN RECRUTEUR ARRIVE avec un besoin, avant toute autre compétence : elle dit où on en est, ce qui vient ensuite, et ce qui peut être sauté. Trois points ne se sautent pas : un formulaire de candidature avec chaque fiche de poste, un tableau de bord tenu par défaut pour chaque recrutement suivi, et les références prises AVANT toute validation ou offre."
bucket: A
tags: [Recrutement]
version: 3
maj: 2026-09-23
---

# Le processus de recrutement : les 7 étapes

Cette compétence est le point d'entrée. Quand quelqu'un arrive avec un besoin de recrutement, on
commence ici : on situe où il en est, on annonce le chemin, on charge la compétence de l'étape.

**Arrêté avec le client le 04/08/2026**, à partir des 19 agents de son espace de travail dont les
prompts ont été lus un par un et transposés en compétences locales.

## Règle d'usage : la flexibilité prime

**Le processus est une proposition, pas un rail.** Un recruteur qui a déjà sa fiche de poste et veut
juste trier ses CV n'a pas à repasser par l'étape 1. On lui demande où il en est, on prend le
processus en cours de route.

Ce qui ne se négocie pas, en revanche : **l'ordre logique des dépendances**. On ne trie pas des CV
contre une fiche de poste qui n'existe pas, on ne construit pas une offre sans avoir évalué, on ne
mesure pas un tunnel dont on n'a pas les dates.

Quand plusieurs chemins sont possibles, les présenter en options lettrées et laisser choisir.

## ⛔ Trois points qui ne se sautent pas (23/09/2026)

Avant de proposer ou de dérouler un processus, vérifie qu'il contient ces trois points ;
sinon, tu les ajoutes avant de le remettre.

1. **Un formulaire de candidature avec chaque fiche de poste** (étape 1,
   `formulaire-de-candidature`).
2. **Un tableau de bord du recrutement, tenu par défaut** dès la publication de l'annonce et
   jusqu'à la clôture, sans qu'on le demande (étape 3, `deroule-du-recrutement` étape 8).
3. **Les références en avant-dernière étape** : après les entretiens, avant toute validation du
   candidat et avant toute offre (étape 6, `prise-references`). Un processus qui place la
   décision ou l'offre avant les références est faux, même s'il est proposé par le client :
   tu le signales et tu proposes l'ordre juste.

Le déroulé attendu par l'équipe, dans sa forme (formats, comparatif, messages), est dans
`deroule-du-recrutement`.

## Étape 1 : Définir le besoin

| Compétence | Ce qu'elle produit |
|---|---|
| `fiche-de-poste` | La fiche : responsabilités, compétences, critères de sélection |
| `audit-inclusif` | Les biais, le langage, les critères qui filtrent à tort, plus la fiche réécrite |
| `job-scorecard` | Ce que le poste doit produire : mission, résultats attendus, compétences |
| `formulaire-de-candidature` | Ce qu'on demande au candidat quand il postule : champs du poste, questions bloquantes, pièces obligatoires ou facultatives |

Dans cet ordre. La scorecard accompagne désormais **chaque** fiche de poste sans qu'on la demande
(arrêté par le client le 03/08/2026).

⚠️ **Avant tout** : l'entreprise a-t-elle son propre modèle de fiche de poste ? S'il existe, on le
reproduit exactement, forme et fond. S'il n'existe pas, on le demande explicitement avant de
produire.

## Étape 2 : Sourcer les candidats

Choisir le canal, ou combiner :

| Compétence | Quand |
|---|---|
| `recrutement-linkedin` | Le candidat est sur les réseaux professionnels : 20 profils notés sur 100 |
| `recherche-talents-ci` | Le candidat est peut-être déjà dans la maison : vivier de candidatures passées |
| `plan-de-sourcing` | Le besoin n'est pas encore cadré avec le manager |
| `diffusion-offre` | L'annonce doit être déclinée par canal de publication |
| `emails-recrutement` | Le premier message d'approche |
| `messages-personnalises` | Le candidat **a répondu** : conduire la conversation jusqu'à l'entretien |

⚠️ **Ne pas confondre** : `emails-recrutement` et `recrutement-linkedin` écrivent le **premier**
message. `messages-personnalises` prend le relais **après** la réponse du candidat.

## Étape 3 : Trier et présélectionner

| Compétence | Quand |
|---|---|
| `suivi-candidatures` | Toujours : c'est le pilotage qui tourne en fond pendant tout le processus, avec le tableau de bord du recrutement tenu par défaut |
| `tri-cv-masse` | Beaucoup de CV contre **un** poste |
| `matching-candidat` | **Un** profil contre plusieurs postes ouverts |

## Étape 4 : Évaluer les compétences

**Les deux sont alternatives, on n'en prend qu'une :**

| Compétence | Quand |
|---|---|
| `test-competences` | Le travail se montre : technique, données, rédaction, support, comptabilité |
| `business-case` | Mise en situation stratégique, commerciale, financière ou opérationnelle |

## Étape 5 : Préparer et conduire les entretiens

| Compétence | Ordre |
|---|---|
| `guide-entretien` | Avant : questions structurées, grille rapide, coordination des rendez-vous |
| `grille-evaluation` | Avant : l'outil de notation, si plusieurs personnes notent |
| `evaluation-candidat` | Après : la notation et la recommandation |
| `synthese-recruitment-interview` | Après : si l'entretien a été transcrit |
| `coordination-entretiens` | En parallèle : qui voit le candidat, quand |

⚠️ `grille-evaluation` fabrique l'outil, `evaluation-candidat` s'en sert. Dans cet ordre.

## Étape 6 : Finaliser la décision

Dans cet ordre : les références d'abord, la décision et l'offre ensuite. Aucune validation de
candidat et aucune offre tant que les références ne sont pas prises.

| Compétence | Ce qu'elle produit |
|---|---|
| `prise-references` | En premier : le kit complet, messages, profils à interroger, questions, grille de synthèse |
| `verification-d-antecedents` | Postes de finance ou de direction seulement, sur demande écrite du client : vérification sur sources publiques, candidat informé d'avance, fiche factuelle sans avis |
| `optimisation-offre` | Le package de rémunération : benchmark, trois scénarios, objections |
| `negociation-offre` | La dernière ligne droite, ce qui motive réellement le candidat |
| `promesse-embauche` | Lettre d'offre et contrat, conformes OHADA et droit local |
| `emails-recrutement` | Le courriel d'offre, de confirmation, de refus ou de clôture |
| `experience-candidat` | Les candidats non retenus et la réputation d'employeur |

## Étape 7 : Mesurer la performance

| Compétence | Ce qu'elle produit |
|---|---|
| `analyse-recrutement` | Délai d'embauche, conversion par étape, efficacité par source, actions chiffrées |
| `onboarding-plan-30-60-90` | Le plan d'intégration, une fois la personne recrutée |

## 🔒 Les six arrêts obligatoires

À ces six endroits, on prépare entièrement et **on s'arrête**. Ils traversent tout le processus :

1. **Publier une annonce** sous le nom de l'entreprise, étape 2.
2. **Envoyer un message à un candidat**, y compris un refus, étapes 2, 5, 6.
3. **Transmettre une offre de rémunération ou un montant**, étape 6.
4. **Contacter une référence** fournie par un candidat, étape 6.
5. **Écarter définitivement une candidature**, étape 3.
6. **Signer ou envoyer un contrat de travail**, étape 6.

Cette liste est **contractuelle**, arrêtée au cadrage. Une action de cette liste exécutée sans accord
est une faute **même si le résultat est bon** : ce que le client a acheté, c'est la garantie.

## Trois écarts entre la roadmap et les prompts réels

Constatés en lisant les 19 prompts un par un, signalés au client le 04/08/2026.

| Agent | Ce que dit la roadmap | Ce que fait le prompt |
|---|---|---|
| `Optimisation_Offre` | « Améliore l'offre d'emploi pour la rendre plus attractive » | Construit le **package de rémunération** d'un candidat nommé. Étape 6, pas étape 1 |
| `Messages_Personnalisés` | « Rédige les messages d'approche pour les candidats passifs » | Prend le relais **quand le candidat a répondu**. L'approche est ailleurs |
| `Matching_Candidat` | Outil du recruteur | Écrit pour servir **le candidat** : il produit ses lettres de motivation. Reste utile au recruteur multi-postes |

**Ne jamais déduire la fonction d'un agent depuis son nom.** Trois sur dix-neuf ne font pas ce que
leur nom annonce, et on ne peut pas savoir lesquels sans lire.

## Règle de demande : ce qui manque se demande ouvertement

Arrêtée par le client le 04/08/2026. Un accès ou une donnée qui manque ne se signale pas en note de
bas de page : **il se demande, au recruteur, au moment où le manque apparaît.**

- Nommer précisément la chose demandée, pas la catégorie.
- Dire **quelle étape est bloquée** tant qu'elle manque.
- Proposer le repli qui permet de continuer en attendant, s'il en existe un.

L'ordre est toujours : chercher d'abord dans ce qu'on a : fichiers en main, site de l'entreprise,
outil de suivi, page publique de l'offre. Puis demander. Jamais déclarer manquant sans avoir cherché,
jamais rester silencieux après avoir cherché.

## Un manque demandé n'est pas un blocage

Corrigé par le client le 04/08/2026. Le tableau ci-dessous liste ce qui n'est pas ouvert : **ce ne
sont pas des murs**. Ce sont des données qui s'obtiennent en les demandant au recruteur, dans le fil
du travail, au moment où le manque apparaît.

- On **demande**, on **continue de produire**, on livre la structure avec ses trous nommés.
- On ne s'arrête pas, on ne s'excuse pas, on ne présente pas le manque comme une limite de ce qu'on
  sait faire.
- Le seul vrai défaut serait de **ne pas demander**, ou de demander en fin de course.

## Ce qui manque pour dérouler le processus en entier

| Manque | Étape bloquée |
|---|---|
| Base de profils du vivier | 2 : `recherche-talents-ci` fonctionne à vide |
| Agenda des évaluateurs | 5 : on rédige les invitations, on ne pose rien |
| Boîte de recrutement | 2, 5, 6 : on ne voit pas les réponses des candidats |
| Grille salariale interne | 6 : le benchmark reste public, sans repère maison |
| Modèles de contrat | 6 : structure conforme, mais pas celle de la maison |
| Service de transcription des entretiens | 5 : ouvert quand le poste a `integrations/fireflies/` (voir `synthese-recruitment-interview`) ; sinon, synthèse à partir d'un fichier collé |

L'outil de suivi des candidatures, lui, est ouvert en lecture et en écriture : c'est la source de
vérité du pipeline.

## Historique

- v2, 23/09/2026 : renvoi vers `verification-d-antecedents` à l'étape 6, et tirets cadratins remplacés, séance Sync agents training.
- v3, 23/09/2026 : trois points qui ne se sautent pas (formulaire de candidature avec chaque
  fiche, tableau de bord par défaut, références avant toute validation ou offre), séance Sync
  agents training.
