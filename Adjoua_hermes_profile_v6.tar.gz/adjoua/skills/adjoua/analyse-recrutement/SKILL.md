---
id: Y0378
name: analyse-recrutement
description: "Étape 7 du processus : mesurer la performance du recrutement. Calcule délai d'embauche, taux de conversion par étape, efficacité par source et taux d'acceptation, identifie où le tunnel fuit, et propose trois à cinq actions chiffrées. Rapport au format allégé, en anglais quand la direction destinataire ne lit pas le français. À charger pour un comité, un bilan, un rapport de recrutements pour une direction, ou quand un poste s'enlise."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 7 : Mesurer la performance

Dernière étape du processus, et celle qui alimente les comités. C'est aussi elle qui dit si les six
précédentes ont servi à quelque chose.

Transposé de l'agent `Analyse_Recrutement` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Les données du pipeline, idéalement une ligne par candidature avec les dates d'étape, la source, le poste et le statut final · la période et le périmètre · la question posée, si elle existe |
| **Livrable** | Tableau de bord, lecture du tunnel, recommandations chiffrées, limites |
| **Critère de réussite** | Chaque taux porte sa taille d'échantillon, et aucune conclusion n'est tirée sur trois candidatures |
| **Point de sortie** | Vers `suivi-candidatures` pour agir sur ce qui bloque |

Si aucune question précise n'est posée, produire le panorama standard.

## Les indicateurs

Calculer, quand la donnée le permet :

- **Délai d'embauche** et **délai de pourvoi** : médiane **et** moyenne, la médiane prime. Une seule
  embauche très lente déforme une moyenne et fait paraître un processus mauvais alors qu'il est sain.
- **Taux de conversion par étape** : candidature → filtrage → entretien → offre → embauche, avec le
  taux de chute de chaque étape.
- **Efficacité par source** : volume, taux de conversion, coût si fourni, et surtout **qualité**,
  c'est-à-dire la progression en aval du tunnel, pas le volume d'entrée. Une source qui apporte 200
  candidatures dont aucune ne passe le filtrage est une mauvaise source, pas une bonne.
- **Taux d'acceptation des offres** et motifs de refus.
- **Coût par embauche** si les coûts sont fournis.
- **Diversité du tunnel** si les données le permettent, **sans jamais individualiser** ni exposer une
  donnée sensible.

**Toujours indiquer la taille d'échantillon derrière chaque taux.**

## Sortie

1. 📊 **Tableau de bord** : les indicateurs clés en tête, avec la tendance par rapport à la période
   précédente.
2. 🔎 **Lecture du tunnel** : où ça fuit, où c'est sain, l'étape à corriger en priorité.
3. 🎯 **Recommandations** : trois à cinq actions concrètes, classées par rapport impact sur effort,
   **chacune reliée à un chiffre**.
4. ⚠️ **Limites** : données manquantes, biais d'échantillon, ce qu'il faut instrumenter pour la
   prochaine fois.

Être honnête sur l'incertitude : « signal faible, à confirmer » vaut mieux qu'une fausse précision.

Le tableau de bord de ce rapport part des tableaux de bord par recrutement, tenus par défaut
(`deroule-du-recrutement`, étape 8) : les chiffres du rapport et ceux des tableaux de bord
doivent être les mêmes.

### Contrôle avant envoi du rapport (23/09/2026)

- **Mise en forme allégée** : le contrôle de `livrable-html-pdf` s'applique (une famille de
  police, 11 pt au moins en impression, parties espacées, rien de superflu). Un comité lit
  l'essentiel en trois minutes.
- **Français simple** : phrases courtes, peu de virgules, termes du métier expliqués ; les
  recommandations sont des propositions, pas des ordres (`yelema-voix`).

### Rapport pour une direction qui ne lit pas le français

Quand le rapport va à une direction ou à un conseil qui ne lit pas le français, il se rédige
**en anglais**, entièrement : titres, tableaux, légendes, recommandations. Les montants restent
dans leur devise, les intitulés de poste gardent leur libellé d'origine entre parenthèses
quand la traduction pourrait tromper. Le rapport peut résumer chaque candidature en anglais.

Hors périmètre : réécrire, traduire ou mettre en forme le CV d'un candidat. Ce travail sert le
candidat, pas le recruteur ; il relève d'un assistant personnel. Tu le dis en une phrase et tu
n'en produis pas de version.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Garde-fous

- **Jamais inventer une donnée absente.** Un indicateur non calculable se dit « données
  insuffisantes », avec la liste de ce qui manque.
- **Ne pas ré-identifier un candidat** dans une analyse agrégée.
- **Distinguer corrélation et causalité** dans les recommandations. Le poste le plus lent n'est pas
  forcément le plus mal géré : il est peut-être le plus rare sur le marché.
- Terminer en proposant un zoom sur une source, un poste ou une étape, ou la mise en place de ce
  tableau de bord en automatisation récurrente.

## ⚠️ Règle de lecture de l'outil de suivi

**L'étape d'un candidat ne dit pas s'il a été traité.** Le drapeau d'écartement est un champ distinct
de l'étape. Compter les « postulé » comme des dossiers en souffrance produit une alerte fausse, et
un indicateur faux dans un comité coûte plus cher qu'un indicateur absent.

Voir `suivi-candidatures` et `lecture-recruitee` pour le détail de la règle et l'erreur qui l'a
motivée.

## Définition à figer

⚠️ **Le délai d'embauche n'a pas encore de définition arrêtée chez ce client** : ouverture du poste
jusqu'à signature, ou première candidature jusqu'à signature ? Question posée le 03/08/2026, sans
réponse à ce jour. Tant qu'elle n'est pas tranchée, **annoncer la définition retenue avec le
chiffre**, sinon deux comités successifs compareront des nombres qui ne mesurent pas la même chose.

## Provenance

| | |
|---|---|
| Agent d'origine | `Analyse_Recrutement` |
| Version lue | v5 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 3551 caractères |
| Empreinte | `efdcc5c87bfb` |

Prompt archivé dans `reference/prompts-dust/Analyse_Recrutement.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant envoi (mise en forme allégée, français simple) ; rapport en
  anglais pour une direction non francophone, CV des candidats hors périmètre ; chiffres
  alignés sur les tableaux de bord par recrutement ; tirets cadratins remplacés, séance Sync
  agents training.
