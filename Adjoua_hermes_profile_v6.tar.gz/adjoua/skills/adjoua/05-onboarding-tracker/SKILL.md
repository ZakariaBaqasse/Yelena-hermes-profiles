---
id: Y0030
name: 05-onboarding-tracker
description: "Suit les milestones d'activation J0-J30 des nouveaux clients d'une entreprise, cohorte par cohorte (semaine d'inscription), détecte les décrochages (stalled / dropped_off), et déclenche la relance ou l'alerte adaptée pour chaque client bloqué."
bucket: C
tags: [Customer Success]
version: 1
maj: 2026-08-26
---

# 05 Onboarding Tracker

## Ce qu'il faut avoir sous la main
1. Le **client/l'entreprise** concerné(e) (pour résoudre sa config de milestones et ses bases de suivi) ;
2. La **fenêtre d'analyse** (par défaut : les 4 dernières semaines d'inscription) ;
3. (optionnel) une **config de milestones sur mesure** si tu veux surcharger celle par défaut du segment.

## Process
Chaque client (ou chaque segment de sa base) a sa propre définition d'activation. Pattern indicatif par archétype de segment, **à adapter au client réel, ne pas appliquer aveuglément** :

### Fintech B2B marchands (ex. paiement/encaissement marchand)
```
J0  : compte créé
J1  : KYC validé
J3  : première transaction encaissée
J7  : 3 transactions cumulées
J14 : 10 transactions cumulées
J30 : revenue mensuel ≥ seuil_segment (à définir)
```

### Fintech B2C utilisateurs app (ex. crédit, livraison, épargne mobile)
```
J0  : app installée + compte créé
J1  : profil complété (KYC light)
J3  : première action core (ex. crédit demandé / livraison commandée / défi engagé, selon le produit)
J7  : 2e action core
J14 : retention rate baseline
J30 : utilisateur "activé" (3+ actions, NPS proxy positif)
```

### B2B SaaS (ex. outil métier vertical)
```
J0  : signup
J1  : onboarding call booké
J3  : first integration / first data import
J7  : workspace setup complete (users invited, settings configured)
J14 : first live use case
J30 : 70% des features core utilisées
```

Si un client n'a pas de config explicite → propose une config de référence par archétype (ci-dessus) et demande validation à l'utilisateur avant de poursuivre.

### Étape 2 : Charger les nouveaux clients par cohorte

Pour la window, identifie les nouveaux clients (= inscrits dans la fenêtre) groupés par semaine d'inscription. Schéma cohort :

- `cohort_week` : "2026-W18" (semaine d'inscription)
- `signups_count` : nombre d'inscrits cette semaine
- `clients` : array {id, signup_date, current_milestone, last_active}

Sources :
- `[datasource à brancher : sheet ou base des inscriptions/revenue du client]`
- `[datasource à brancher : base de connaissance CRM/pipeline du client, filtrée sur created_at >= window_start]`
- `[connecteur à brancher : passerelle de paiement (type Stripe/PayPal), cross-check côté paiements pour les segments fintech]`

### Étape 3 : Positionner chaque client sur le funnel

Pour chaque client de la cohorte :
- `current_milestone` : dernier milestone franchi
- `days_since_signup` : J+X
- `days_at_current_milestone` : combien de jours bloqué sur ce milestone
- `status` : `progressing` (avance dans les délais) · `stalled` (bloqué > délai normal) · `dropped_off` (inactif > 14j sur un milestone bloquant) · `activated` (J30 milestone atteint)

Délais normaux (rule-of-thumb par milestone, à ajuster au client) :
- J0→J1 : max 3j (pause acceptable)
- J1→J3 : max 5j
- J3→J7 : max 10j
- J7→J14 : max 14j
- J14→J30 : max 21j

Au-delà → `stalled`. Pas d'activité 14j → `dropped_off`.

### Étape 4 : Drop-off funnel par cohorte

Calcule le funnel par cohorte :

```
J0  → J1  : XX% conversion (et donc YY% drop-off)
J1  → J3  : ...
J3  → J7  : ...
J7  → J14 : ...
J14 → J30 : ...
```

Compare les cohortes pour repérer des patterns :
- **Une cohorte qui décroche systématiquement à J3** → friction sur le milestone J3 (ex : première transaction = pricing pas clair)
- **Une cohorte récente meilleure qu'une cohorte plus ancienne sur J0→J1** → quelque chose a changé en bien (onboarding flow update ? message d'accueil ?)
- **Variance énorme cohorte-à-cohorte** → instrumentation cassée OU effet externe (campagne marketing différente)

### Étape 5 : Actions par client bloqué

Pour chaque client `stalled` ou `dropped_off`, recommande :

### stalled : toujours actif mais bloqué
- **next_action** : relance personnalisée via `[skill à brancher : 07-wa-conversation-designer, génère et envoie une séquence WhatsApp de relance par milestone]`, avec un template milestone-specific
- **template_id** : ex `kyc_nudge_j5` · `first_tx_friction_j10` · `inactivity_j14`
- **content_vars** : prénom, milestone bloquant, action attendue, lien CTA
- **owner** : `bot` (automate de conversation) ou `csm_human` si segment premium

### dropped_off : inactif > 14j
- **next_action** : appel CSM humain si B2B + contract_value > seuil · sinon relance WA + email soft
- **last_chance** : 1 séquence de réactivation 7j, après quoi → bucket `lost` (ne pas s'épuiser)

### activated (J30 réussi)
- **next_action** : flag vers `[skill à brancher : 04-customer-health, passe le client en scoring de santé continu]`
- **next_action** : flag vers `[skill à brancher : 02-nps-analyzer, déclenche le prompt NPS automatique post-activation]` (les clients activés sont des promoteurs potentiels)

## Format de sortie
```json
{
  "client": "Nom du client",
  "window": "2026-04-21..2026-05-21",
  "milestones_config_source": "[datasource à brancher : base support/FAQ] / onboarding_milestones.json",
  "cohorts": [
    {
      "cohort_week": "2026-W17",
      "signups_count": 42,
      "funnel": {
        "J0_to_J1": 0.88,
        "J1_to_J3": 0.65,
        "J3_to_J7": 0.45,
        "J7_to_J14": 0.38,
        "J14_to_J30": 0.31
      },
      "activated_count": 13,
      "stalled_count": 16,
      "dropped_off_count": 13
    }
  ],
  "patterns": [
    "Drop-off massif J1→J3 sur W17 (35%), vérifier friction transaction",
    "W19 amélioration J0→J1 vs W17 (+12pts), onboarding flow change positif ?"
  ],
  "clients_stalled": [
    {
      "client_id": "XX-2026W18-014",
      "name": "Nom du client final",
      "cohort": "2026-W18",
      "current_milestone": "J3_premiere_transaction",
      "days_since_signup": 11,
      "days_at_milestone": 8,
      "next_action": "wa_template",
      "template_id": "first_tx_friction_j10",
      "owner": "bot",
      "handoff_to": "07-wa-conversation-designer"
    }
  ],
  "clients_activated_new": [
    {"client_id": "XX-2026W17-022", "handoff_to": ["04-customer-health", "02-nps-analyzer"]}
  ],
  "next_step": "Lancer la relance WhatsApp sur les clients stalled (par template) + flagger les clients activés vers le scoring de santé et le NPS"
}
```

Si un rendu de tableau de bord est disponible → funnel chart par cohorte + courbe d'activation over time via `[connecteur à brancher : rendu de tableau de bord/visualisation interactive]`.

## Règles
- **Les milestones doivent être définis par le client**, pas d'invention. Si pas de config, escalade à l'utilisateur ou propose un modèle de référence (Étape 1).
- **Cohorte par semaine d'inscription**, jamais par mois (la granularité hebdo révèle les patterns).
- **Comparer 4 cohortes minimum** pour détecter une tendance fiable.
- **Distinguer stalled / dropped_off** : un stalled est récupérable, un dropped_off coûte plus cher à réactiver que d'acquérir un nouveau client.
- **Toujours croiser avec** `[skill à brancher : 04-customer-health]` **sur les clients activés J30**, éviter de perdre le suivi quand l'onboarding réussit.
- **Confidentialité** : pas de mélange entre cohortes de clients différents (un client de l'entreprise A n'apparaît jamais dans un rapport sur l'entreprise B), critique en déploiement multi-entités (portefeuille).
- **Cadence** : run hebdomadaire, idéalement après le run du `[skill à brancher : 04-customer-health]` de la semaine, séquencer les insights CS.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle, une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Input

L'orchestrateur ou l'utilisateur te passe :

- **client** : nom de l'entreprise/du produit suivi (clé pour résoudre les bases de suivi + le brand kit)
- **window** : cohortes à analyser (défaut = 4 dernières semaines d'inscription)
- **milestones_override** : (optionnel) si l'utilisateur veut surcharger la config milestones par défaut du client

Si pas de config milestones définie pour le client → cherche dans `[datasource à brancher : base de connaissance support/FAQ du client]` un document `onboarding_milestones.json` ou demande à l'utilisateur.

### Configuration (déployée pour le client)

>
