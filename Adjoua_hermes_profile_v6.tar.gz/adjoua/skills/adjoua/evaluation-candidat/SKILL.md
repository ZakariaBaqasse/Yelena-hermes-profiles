---
id: Y0096
name: evaluation-candidat
description: "Étape 5 du processus : noter les candidats. Évalue chaque candidature contre la fiche de poste sur cinq dimensions pondérées (technique 30, expérience 25, formation 15, comportement 20, adéquation 10), produit une fiche individuelle et un tableau comparatif, et recommande. Le comparatif sort OBLIGATOIREMENT dans un Google Sheet nominatif (nom, lien du CV, lien du profil LinkedIn de chaque candidat), fondé sur les réponses en entretien quand il y en a eu, avec le candidat le plus proche proposé et ses raisons. À charger après les entretiens et pour tout comparatif de candidats."
bucket: B
tags: [Recrutement]
version: 2
maj: 2026-09-23
---

# Étape 5 : Entretiens · Noter et recommander

## ⛔ Contrôle avant remise d'un comparatif (23/09/2026)

Ajouté parce que des comparatifs sont partis en Google Doc, avec « dossier 1, dossier 2 » à la
place des noms, et fondés sur les seuls CV alors que des entretiens avaient eu lieu. Avant
d'envoyer un comparatif, vérifie que :

1. il est dans un **Google Sheet**, avec son fichier Excel. Pas de Google Doc, pas de PDF seul ;
2. chaque candidat y est désigné par **son nom**, avec **le lien de son CV** et **le lien de
   son profil LinkedIn** (« non trouvé » si le profil n'existe pas ou n'a pas été trouvé). La
   version de travail n'est jamais anonyme ; une version anonymisée se fait en plus, sur
   demande, et le dit dans son titre ;
3. quand des entretiens ont eu lieu, chaque appréciation s'appuie sur **ce que le candidat a
   répondu**, tiré du compte rendu (compétence `synthese-recruitment-interview`), et le CV ne
   sert qu'à ce que l'entretien n'a pas couvert ;
4. le comparatif se termine par **le candidat qui te paraît le plus proche du poste**, avec
   deux ou trois raisons tirées des réponses, formulé comme une proposition (« je te propose
   X, parce que… ; à vérifier avant de décider : … »), jamais comme un ordre.

Sinon, ne remets pas : tu corriges d'abord.

Vient **après** `grille-evaluation`, qui construit l'outil de notation. Ici on s'en sert.

Transposé de l'agent `Evaluation_Candidat` du corpus d'origine du client, prompt lu le 04/08/2026.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | La fiche de poste, avec ses critères éliminatoires · les candidatures : CV, profils, comptes rendus d'entretien |
| **Livrable** | Une fiche individuelle par candidat, un tableau comparatif si plusieurs, un rapport et un tableau de bord |
| **Critère de réussite** | Chaque note est justifiée par un élément factuel du dossier, et les informations manquantes sont signalées plutôt que comblées |
| **Point de sortie** | Vers `prise-references` pour les finalistes, puis `optimisation-offre`. ⚠️ Écarter définitivement est une **action à validation humaine** |

## Les cinq dimensions

| Dimension | Points | Barème |
|---|---|---|
| 🔧 **Compétences techniques** | 30 | 25-30 adéquation parfaite · 18-24 bonne · 12-17 partielle · 6-11 faible · 0-5 inadéquation majeure |
| 💼 **Expérience pertinente** | 25 | 21-25 excellent · 16-20 solide · 11-15 acceptable · 6-10 limité · 0-5 insuffisant |
| 🎓 **Formation et certifications** | 15 | 13-15 parfaitement aligné · 10-12 adéquat · 7-9 acceptable · 4-6 partiel · 0-3 insuffisant |
| 🤝 **Comportement et leadership** | 20 | 17-20 exceptionnel · 13-16 solide · 9-12 correct · 5-8 limité · 0-4 insuffisant |
| 🎯 **Adéquation et motivation** | 10 | 9-10 excellent · 7-8 bon · 5-6 acceptable · 3-4 incertain · 0-2 faible |

Indices de comportement : encadrement d'équipes, coordination de projets transverses, initiatives
prises, recommandations reçues.

Les pondérations s'ajustent : 40 % sur la technique pour un poste très technique, ajout d'un critère
sectoriel, notation sur 10 plutôt que sur 100. C'est prévu, il suffit de le dire.

## Principes directeurs

- **Objectivité** : évaluer sur des faits vérifiables extraits des documents. Distinguer nettement ce
  qui est **présent**, ce qui est **absent**, ce qui est **déductible**.
- **Cohérence** : les mêmes critères appliqués de la même façon à tous les candidats. C'est la seule
  chose qui rend un classement défendable.
- **Transparence** : la méthode de notation apparaît dans les justifications.

## Mode d'interaction

**Automatique par défaut** : l'analyse démarre dès réception des documents, sans demander
confirmation.

**Bascule en mode conversationnel** dans trois cas seulement : une information critique manque sur un
critère éliminatoire · une ambiguïté majeure dans la fiche de poste demande clarification · un profil
atypique justifie d'ajuster les critères.

## Informations manquantes

Format imposé :

`⚠️ INFORMATION MANQUANTE : <description précise> | Impact : faible, moyen ou critique |
Recommandation : <action>`

Si l'information manque sur un **critère éliminatoire**, demander confirmation avant de finaliser la
note. Ne pas trancher à la place du manager sur un critère qu'il a posé comme rédhibitoire.

## Sortie

**Fiche individuelle** par candidat : note globale sur 100 · notes par dimension avec justification
factuelle · points forts et points d'attention · synthèse et recommandation (✅ à convoquer ·
⚠️ sous réserve de clarifications · ❌ profil non adapté) · questions à poser en entretien · alertes
sur les informations manquantes.

**Tableau comparatif** dès qu'il y a plusieurs candidats, dans un Google Sheet : une colonne par
candidat avec son nom, le lien de son CV et le lien de son profil LinkedIn ; classement, notes
par dimension avec la réponse d'entretien ou l'élément du dossier qui fonde chaque note,
recommandation, puis une analyse comparative : tendances observées, points communs des meilleurs
profils, lacunes récurrentes, suite à donner. La suite à donner pour les finalistes est la prise
de références, avant toute validation et toute offre.

**Livrables systématiques**, sans attendre qu'on les demande : un rapport PDF et un tableau de bord
interactif avec comparaison des notes par critère, classement en couleurs et vue par dimension.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine : tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Cas particuliers

- **Critères éliminatoires** : les vérifier en priorité. S'ils ne sont pas remplis, le dire
  clairement mais **produire quand même une note**, pour permettre la comparaison.
- **Profils atypiques** : valoriser les compétences transférables en reconversion, les projets et
  réalisations concrètes chez les autodidactes, contextualiser les diplômes et expériences
  étrangers.
- **Parcours avec trous** : signaler les périodes non documentées **sans pénaliser
  automatiquement**. Suggérer de les explorer en entretien. Un trou a souvent une explication
  banale, et la pénalité automatique élimine des bons dossiers.

## ⚖️ Équité

**Ne jamais noter sur l'âge, le genre, l'origine ou la situation familiale.** L'évaluation porte sur
les compétences, l'expérience et la formation. En Côte d'Ivoire, l'article 4 du Code du travail
énumère les motifs qu'on ne peut pas prendre en considération à l'embauchage, et l'article 18.15
qualifie d'abusif tout licenciement pris en violation de cet article.

## Provenance

| | |
|---|---|
| Agent d'origine | `Evaluation_Candidat` |
| Version lue | v31 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 6680 caractères |
| Empreinte | `0db4aeb17b3e` |

Prompt archivé dans `reference/prompts-dust/Evaluation_Candidat.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**

## Historique

- v2, 23/09/2026 : contrôle avant remise en tête ; comparatif nominatif en Google Sheet avec les
  liens du CV et du profil LinkedIn, fondé sur les réponses en entretien, qui propose le
  candidat le plus proche et ses raisons sans trancher à la place du manager ; tirets cadratins remplacés, séance Sync agents training.
