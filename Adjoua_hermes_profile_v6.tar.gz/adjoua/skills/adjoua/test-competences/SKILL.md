---
id: Y0650
name: test-competences
description: "Étape 4 du processus — évaluer par mise en situation. Conçoit un test pratique ancré dans une situation réelle du poste ET sa grille de correction, livrés en DEUX fichiers séparés pour que la grille ne fuite pas vers le candidat. Alternative au business case, pas son complément."
bucket: B
tags: [Recrutement]
version: 1
maj: 2026-08-04
---

# Étape 4 — Évaluer · Test pratique

**Alternative à `business-case`, pas complément.** Le test pratique convient aux métiers où le
travail se montre : technique, données, rédaction, support, comptabilité. Le business case convient
aux mises en situation stratégiques, commerciales, financières ou opérationnelles. On choisit, on ne
cumule pas.

Transposé de l'agent `Test_Compétences` du corpus d'origine du client, prompt lu le 04/08/2026.

Principe directeur : **tester ce que la personne fera vraiment au poste**, pas des connaissances
théoriques hors sol.

## Le moule de l'étape

| | |
|---|---|
| **Entrées requises** | Poste et séniorité (junior, confirmé, senior, encadrant) · **trois à cinq compétences clés** à évaluer · le format voulu, ou « propose le plus adapté » · le temps candidat visé (45 à 90 minutes par défaut) et le mode : à distance ou en direct |
| **Livrable** | Deux fichiers séparés : le test remis au candidat, la grille gardée par l'évaluateur |
| **Critère de réussite** | Un évaluateur qui n'a pas conçu le test note de la même façon que celui qui l'a conçu |
| **Point de sortie** | Vers `grille-evaluation` pour harmoniser la notation entre évaluateurs, puis `evaluation-candidat` |

## 🛑 Règle d'arrêt non contournable

Si les compétences clés n'ont **pas** été listées explicitement — par exemple si on ne vous a donné
qu'une fiche de poste ou un lien :

1. En déduire une liste de trois à cinq.
2. **S'arrêter là.**
3. Soumettre cette liste pour validation, avec une option explicite pour modifier ou ajouter.

**Ne jamais produire le test complet sur des compétences seulement déduites**, même quand le contexte
paraît évident. C'est le point où l'on fabrique un test qui mesure autre chose que ce que le manager
voulait mesurer, et personne ne s'en aperçoit avant les résultats.

## Choix du format

Quand le format est laissé ouvert :

- **Ne pas appliquer par défaut l'étude de cas écrite en asynchrone.** C'est le réflexe, et il est
  souvent mauvais.
- Si le poste a une dimension d'encadrement, de relation ou de leadership — management d'équipe,
  négociation, relation client — proposer explicitement un **format hybride** : cas écrit court de 30
  à 45 minutes en asynchrone, plus un entretien structuré ou une mise en situation en direct de 15 à
  20 minutes, pour capter ce que l'écrit seul ne mesure pas.
- **Expliquer le choix de format en deux ou trois phrases** avant de produire le test, plutôt que de
  trancher en silence.

## Conception du test

- **Ancrer dans une situation réelle du poste** — un vrai problème que la personne rencontrera, pas
  un casse-tête artificiel.
- Calibrer la difficulté sur la séniorité visée.
- Rendre la consigne autonome : contexte, tâche, livrable attendu, contraintes, temps imparti, ce qui
  est autorisé — outils d'IA, documentation.
- Prévoir une variante courte si le temps est compté.
- Éviter ce qui avantage un profil hors compétence : culture d'entreprise, jargon interne, pièges
  inutiles.

## Grille de correction

Exploitable par un évaluateur qui n'a pas conçu le test.

- **Critères alignés un pour un** sur les compétences ciblées, chacun avec son poids.
- **Échelle par critère**, par exemple de 1 à 4, avec des **descripteurs comportementaux** : à quoi
  ressemble concrètement un niveau 1, un 3, un 4.
- **Réponse de référence** : ce que contient un bon livrable, et les pièges classiques.
- **Exemple annoté obligatoire** : sur un ou deux critères clés, un court extrait de réponse fictive
  annoté ligne par ligne, justifiant la note. C'est le socle de l'harmonisation entre évaluateurs.
- **Note totale et seuil** : passe, à discuter, non.
- **Zone de notes libres** pour l'évaluateur.

## Livrables — deux fichiers, jamais un seul

1. **Test candidat** — uniquement le bloc à remettre au candidat.
2. **Grille évaluateur** — la grille et la note d'administration.

⚠️ **Ne jamais mélanger les deux dans un même fichier.** C'est une mesure anti-fuite : une grille de
correction qui arrive chez le candidat rend le test inutile, et on ne s'en rend compte qu'après.

## Production du fichier

Le format promis ici est réellement produisable sur cette machine — tableur avec menus déroulants,
formules et couleurs, document modifiable, PDF, page interactive. La chaîne exacte est dans
`production-fichiers`. **Jamais un bloc de valeurs à recopier quand un fichier est attendu.**

## Restitution

Trois blocs nettement séparés, en plus des deux fichiers :

1. 🧑‍💻 **À remettre au candidat** — consigne complète et autoportante.
2. ✅ **Grille évaluateur** — critères, échelle, descripteurs, réponse de référence, exemple annoté,
   seuil.
3. 🛠️ **Note d'administration** — temps, mode, matériel, conseils d'équité : mêmes conditions pour
   tous, biais à éviter.

Terminer en proposant une variante plus courte, un autre format, ou une adaptation au barème maison.

## Garde-fous

- **Vérifier que le test est passable dans le temps annoncé.** Le faire soi-même mentalement.
- **Neutralité** : aucune tâche qui désavantage selon la langue maternelle, un handicap ou l'accès au
  matériel — sauf si c'est une vraie exigence du poste, et alors on le dit.
- **Jamais de travail gratuit exploitable en production.** Le test reste un échantillon borné. Un
  candidat à qui on fait produire un livrable réel a le droit de le dire, et il le dira.

## Valeur prédictive — à savoir avant de vendre l'exercice

Les épreuves pratiques ont une valeur prédictive mesurée à **0,33**, contre **0,58** pour l'entretien
structuré et **0,65** pour un test d'aptitude générale. Leur apport au-delà d'un test d'aptitude est
quasi nul. _Source lue intégralement le 04/08/2026 : Schmidt, Oh et Shaffer, sur un siècle de
recherche en psychologie du personnel._

Conséquence de méthode : **un test ne décide pas d'une embauche.** Il éclaire le raisonnement et
alimente un entretien ciblé. La qualité de décision vient de la combinaison test, entretien
structuré, prise de références.

## Provenance

| | |
|---|---|
| Agent d'origine | `Test_Compétences` |
| Version lue | v5 |
| Date de lecture | 04/08/2026 |
| Longueur du prompt | 6801 caractères |
| Empreinte | `2c56747f13b5` |

Prompt archivé dans `reference/prompts-dust/Test_Compétences.md`. **Si l'empreinte change, l'agent a été
modifié côté client : relire le prompt avant de se fier à cette compétence.**
