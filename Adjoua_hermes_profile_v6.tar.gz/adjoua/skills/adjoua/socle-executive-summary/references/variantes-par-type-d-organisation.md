# Les cinq variantes, par type d'organisation

La charpente en cinq blocs ne bouge pas. Ce qui bouge : **ce que le lecteur regarde en
premier**, **le chiffre qui le décide**, **le vocabulaire**, et **le délai dans lequel la
décision tombe**. Se tromper de variante ne rend pas la page fausse, elle la rend inutile.

⚠ **La variante se lit dans le dossier du client, jamais dans le secteur.** Une entreprise de
quarante personnes peut se piloter comme une PME ou comme une startup. Sans dossier, on demande
deux choses : qui signe, et devant quelle instance. Puis on l'écrit dans la mémoire du poste.

## Vue d'ensemble

| | Qui décide | Le chiffre qui décide | Le délai | Le mot à ne pas employer |
|---|---|---|---|---|
| **TPE, auto-entrepreneur** | le dirigeant, seul | la sortie de trésorerie ce mois-ci | le jour même | « stratégique » |
| **PME** | le dirigeant, avec un ou deux relais | l'effet sur l'exploitation et sur qui fait le travail | une à deux semaines | « disruption » |
| **Startup** | les fondateurs, parfois le conseil | les mois de trésorerie, l'hypothèse testée | quelques jours | « rentabilité » comme préalable |
| **Grand groupe** | un comité, sur arbitrage entre projets | le retour, le budget déjà voté, la conformité | le prochain comité, daté | « on verra en faisant » |
| **Secteur public** | une chaîne, avec un ordonnateur | le coût par bénéficiaire, la soutenabilité | le calendrier budgétaire | « retour sur investissement » |

## 1 · TPE et auto-entrepreneur

Le lecteur est celui qui paie, de sa poche, et qui fera le travail lui-même. Il n'a pas de
comité, pas de budget annuel, et sa contrainte est la trésorerie de ce mois-ci.

- **Première phrase** : ce que ça coûte ce mois, et quand l'argent revient.
- **Les chiffres** : trois au plus, en francs, jamais en pourcentage seul. « 18 % d'économie »
  ne dit rien, « 45 000 FCFA par mois » se décide.
- **Le risque** : ce qui arrive s'il ne peut pas payer une échéance. On le dit.
- **Le temps du dirigeant** est un coût : « deux heures par semaine » se compte dans le total.
- ⛔ **Aucun vocabulaire de comité.** Pas de « stratégique », pas de « transformation », pas de
  « feuille de route ». Ce sont des mots qui font payer un conseil, pas des mots qui aident.
- **Longueur** : une demi-page suffit souvent, et vaut mieux.

## 2 · PME

Le lecteur dirige, mais il délègue l'exécution. Sa vraie question n'est pas « est-ce une bonne
idée » mais « qui va faire ça, et qu'est-ce qu'il arrête de faire pendant ce temps ».

- **Première phrase** : la décision, son montant, et la personne dont le temps est engagé.
- **Les chiffres** : l'effet sur l'exploitation (délai, volume, marge), pas sur le marché.
- **Le bloc à ajouter** : *qui fait le travail*, nommément, et ce que cela déplace dans son mois.
- **Le risque** : la dépendance à une personne, presque toujours. Une PME qui perd sa
  responsable administrative perd le projet ; la parade se dit.
- **Le calendrier** : compté en semaines, avec les périodes basses de l'activité prises en compte.

## 3 · Startup

Le lecteur compte en mois de trésorerie et en hypothèses testées. Un projet qui n'apprend rien
et ne rapproche pas de la levée suivante ne se défend pas, même s'il est rentable.

- **Première phrase** : ce que ça consomme de trésorerie et ce que cela permet d'apprendre ou
  de prouver.
- **Les chiffres** : trésorerie restante avant et après, effet sur la traction, coût
  d'acquisition ou de rétention selon ce qui est en jeu.
- **Le bloc à ajouter** : *l'hypothèse testée* et **le signal qui dit qu'on arrête**. Un projet
  sans condition d'arrêt n'est pas une expérience, c'est un engagement déguisé.
- **Le lecteur second** est le conseil ou l'investisseur : la page doit tenir telle quelle dans
  un point mensuel, sans réécriture.
- ⛔ Ne pas poser la rentabilité comme préalable là où l'entreprise est encore en apprentissage :
  c'est la question de l'étape d'après, et la poser trop tôt fait passer la synthèse pour hors
  sujet.

## 4 · Grand groupe

Le lecteur ne décide pas seul et ne décide pas sur le fond seulement : il arbitre entre des
projets qui se valent, devant des gens qui ont un avis. Ce qui emporte la décision est autant
la solidité du dossier que son alignement avec ce qui est déjà voté.

- **Première phrase** : la décision, le montant, **la date du comité** et le sponsor interne.
- **Les chiffres** : retour attendu, ligne budgétaire d'imputation, écart avec le budget voté.
- **Les blocs à ajouter** :
  - *l'alignement* avec le plan ou la feuille de route en cours, nommé ;
  - *la conformité* : achats, juridique, données personnelles, sécurité, selon le sujet ;
  - *ce qui a été écarté*, avec la raison. Un comité qui ne voit qu'une option en cherche une
    autre lui-même, et la trouve moins bonne.
- **Le risque** : celui qui ferait revenir le sujet au comité suivant.
- **Le ton** : impersonnel, vérifiable, sans emphase. ⛔ Aucun « on verra en faisant » : la phrase
  disqualifie un dossier en séance.

## 5 · Secteur public

Le lecteur engage de l'argent public, sous le regard d'un contrôle, dans un calendrier qui
n'est pas le nôtre. La décision se justifie autant qu'elle se prend, et elle se justifiera
encore dans trois ans.

- **Première phrase** : l'objet, le montant, la base réglementaire ou la décision qui autorise,
  et l'échéance administrative.
- **Les chiffres** : coût total, **coût par bénéficiaire**, soutenabilité sur l'exercice et le
  suivant, part cofinancée s'il y en a une.
- **Les blocs à ajouter** :
  - *l'intérêt général servi*, en une phrase, et pour combien de personnes ;
  - *l'égalité de traitement* : qui est couvert, qui ne l'est pas, et pourquoi ;
  - *le calendrier de la dépense*, qui suit la chaîne engagement, liquidation, ordonnancement,
    paiement, et non le calendrier du projet.
- ⛔ **Ne pas écrire « retour sur investissement ».** On écrit le service rendu, le coût évité,
  le délai réduit pour l'usager. Le vocabulaire d'entreprise fait perdre l'argument au lieu de
  le porter, et prête le flanc au reproche de gestion privée d'un service public.
- **Les sources** : un chiffre public se cite avec son document d'origine et sa date. Un chiffre
  invérifiable ne monte pas dans la page, quelle que soit sa vraisemblance.
- **Le risque** : la rupture de financement en cours d'exercice, presque toujours, et ce qu'on
  fait des engagements déjà pris.

## Ce qui ne change jamais, quelle que soit la variante

La décision en première phrase. Trois à cinq chiffres, tous sourcés et datés. Une option
écartée nommée. Un risque et sa parade. Une page. Et la réponse à la question que personne ne
pose : **ce qui se passe si l'on ne décide rien.**
