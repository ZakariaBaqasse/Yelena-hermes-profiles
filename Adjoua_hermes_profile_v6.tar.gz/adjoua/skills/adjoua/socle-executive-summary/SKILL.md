---
id: Y0673
name: socle-executive-summary
description: >
  Écrire la page qui se lit seule et qui suffit à décider : la décision demandée en première
  phrase, la situation en trois chiffres sourcés, la proposition, ce qu'elle coûte et rapporte,
  le risque principal et la parade. Avec la variante qui convient au lecteur, selon qu'il dirige
  une TPE, une PME, une startup, un grand groupe ou une administration. À charger dès qu'un
  document dépasse deux pages, et avant tout comité, conseil ou remise à un dirigeant.
version: 1
maj: 2026-09-17
---

# L'executive summary

> **Demandé par Yelema, 17/09/2026 :** *« Une autre grosse compétence, c'est comment
> écrire des executive summaries, en milieu professionnel, en milieu entrepreneurial, et
> peut-être même avec une variante quand tu es une start-up, quand tu es une PME, quand tu es
> un auto-entrepreneur, quand tu es un grand groupe, quand tu es du secteur public. Cette
> compétence doit être sur tous les experts. »*

La règle de fond tient en une phrase : **le lecteur qui ne lira que cette page doit pouvoir
décider.** Ce n'est pas un résumé du document, c'est le document dont le reste est l'annexe. Un
résumé raconte ce qu'on a fait, un executive summary dit ce qu'il faut faire.

**Quand la charger** : dès qu'un livrable dépasse deux pages, avant un comité, un conseil, une
présentation à un dirigeant ou un envoi à un financeur. Aussi quand on nous demande « un point
rapide » sur un dossier lourd.

**Quand ne pas la charger** : pour un document qui ne porte aucune décision (un référentiel, un
mode d'emploi, un compte rendu factuel). Là, c'est un sommaire qu'il faut, pas une synthèse.

**Les cinq variantes** (TPE, PME, startup, grand groupe, secteur public) et ce qu'elles
changent vivent dans `references/variantes-par-type-d-organisation.md`. Elles sont l'essentiel
de cette compétence : la charpente ne bouge pas, ce qui bouge est ce que le lecteur regarde en
premier et le chiffre qui le décide.

**Ce qu'elle ne tient pas** : les structures détaillées côté investisseurs et comité
d'investissement (analyse de pitch, due diligence, portfolio update) vivent dans `exec-summary`,
qui reste la compétence spécialisée. On ne recopie pas ses gabarits ici.

## Ce qu'il faut avoir sous la main

1. **Le type d'organisation du lecteur**, qui commande la variante. Il se lit dans le dossier
   du client, pas dans le secteur : une entreprise de 40 personnes peut se piloter comme une
   PME ou comme une startup, et cela change tout le document.
2. **La décision attendue**, formulée comme une question fermée : engage-t-on 12 M FCFA sur
   douze mois, oui ou non ?
3. **Qui décide, et quand.** Un comité a une date ; un dirigeant de TPE décide le soir même.
4. **Trois à cinq chiffres**, chacun avec sa source et sa date de relevé. Un chiffre sans
   source ne monte pas dans la page.
5. **Ce qui se passe si l'on ne décide rien.** C'est souvent l'argument le plus fort, et c'est
   presque toujours celui qui manque.

## La charpente, cinq blocs, une page

**1 · La décision demandée**, en première phrase, avec le montant et l'échéance.
> *Nous demandons l'accord du comité pour engager 12 M FCFA sur douze mois afin d'internaliser
> le support client, décision attendue le 30/09.*

**2 · La situation, en trois chiffres.** Pas un historique : l'état des lieux qui rend la
décision nécessaire, chiffres sourcés et datés.

**3 · Ce qu'on propose**, en deux ou trois phrases, et ce qu'on a écarté en une. Une option
présentée seule n'est pas une proposition, c'est une demande d'approbation.

**4 · Ce que ça coûte et ce que ça rapporte**, dans l'unité qui parle au lecteur : francs et
mois pour une TPE, effet sur l'exploitation pour une PME, mois de trésorerie pour une startup,
retour et conformité pour un grand groupe, coût par bénéficiaire pour une administration.

**5 · Le risque principal et la parade.** Un seul, le vrai, avec ce qu'on fait s'il survient.
Une synthèse sans risque n'est pas rassurante, elle est suspecte : le lecteur sait qu'il y en a
un, et il se demande lequel on lui cache.

**Longueur** : une page, 350 à 400 mots. Ce n'est pas une contrainte de forme. Au-delà, le
lecteur arbitre lui-même ce qu'il lit, et il n'arbitre pas comme nous l'aurions fait.

## Ce qui n'y figure jamais

- **L'historique du projet** et la liste de ce qu'on a fait pour en arriver là. Le lecteur
  paie le résultat, pas le chemin.
- **La méthodologie.** Elle rassure celui qui écrit, elle n'aide pas celui qui décide. En
  annexe, où elle sera lue si la décision est contestée.
- **Le suspense.** On ne garde pas la conclusion pour la fin. Ce n'est pas un récit.
- **Les remerciements, les précautions oratoires, les rappels de contexte connus du lecteur.**
- **Un chiffre sans source**, un marquage `⚠ À VÉRIFIER`, un `non disponible` sur une donnée
  centrale. Une page de décision ne se remet pas inachevée : on va chercher, ou on dit
  clairement que la décision ne peut pas être prise en l'état et pourquoi.

## Le contrôle, trois tests

1. **Le test du lecteur pressé.** On masque tout le reste du document. La page suffit-elle à
   dire quoi faire lundi ? Sinon, ce qui manque n'est pas dans le document, il est dans la page.
2. **Le test des chiffres.** Chacun a-t-il une source nommée et une date ? Sont-ils au plus
   cinq ? Un sixième chiffre fait baisser la mémoire des cinq autres.
3. **Le test de la contradiction.** Quelqu'un qui n'est pas d'accord trouve-t-il dans la page
   de quoi discuter, ou seulement de quoi se sentir contourné ? Une synthèse qui cache
   l'objection la ramène en séance, et plus fort.

## Les pièges de ce travail

- ⛔ **Résumer au lieu de trancher.** Le réflexe est de raccourcir le document ; le travail est
  d'en extraire la décision. Ce ne sont pas les mêmes gestes, et le premier produit une page
  qui n'aide personne.
- ⛔ **Prendre la variante sur le secteur.** Le secteur ne dit pas comment on décide. On lit le
  dossier du client ; sans dossier, on demande qui décide et devant quel comité, et on le note.
- ⛔ **Parler retour sur investissement à une administration.** Le vocabulaire y fait perdre
  l'argument plutôt que de le porter. Voir la variante dédiée.
- ⛔ **Mettre un tableau de dix lignes.** Trois chiffres dans une phrase se retiennent, dix dans
  un tableau se relisent plus tard, c'est-à-dire jamais.
- ⛔ **Recopier la synthèse d'un dossier voisin.** Deux décisions ne se ressemblent que pour
  celui qui ne les prend pas.
