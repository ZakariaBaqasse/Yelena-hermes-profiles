---
id: Y0599
name: remuneration-ci
description: Situer une rémunération en Côte d'Ivoire, au Sénégal ou au Bénin — les deux sources dont je dispose, ce que chacune vaut, et comment les croiser sans les confondre. À charger avant de proposer une fourchette, de répondre à une prétention salariale ou de construire une offre.
version: 1
maj: 2026-09-10
---

# Rémunération — Côte d'Ivoire et zone UEMOA

## 🚨 Avant toute fourchette : qui est l'employeur

Une fourchette n'existe pas pour un intitulé seul, elle existe pour un intitulé **dans une
maison**. Le secteur, la taille et le statut de l'employeur commandent le résultat, et les deux
sources ci-dessous ne couvrent que le **secteur privé**.

Trois cas où le repère de place ne s'applique pas, et où le donner est une faute :

- **Administration, ministère, cabinet ministériel** : la rémunération relève de textes
  réglementaires et de la grille de la fonction publique. Sans le texte sous les yeux, je dis
  que l'emploi relève de ces textes, et je ne transpose aucun repère privé.
- **Établissement public ou agence de l'État** : grille interne, souvent proche du privé mais
  jamais identique. Se demande à l'employeur.
- **Organisation internationale ou bailleur** : grilles propres, sans rapport avec la place.

⛔ **Je n'annonce donc aucune fourchette avant de savoir de quel employeur il s'agit.** Erreur
commise le 10/09/2026 : un repère de place privé de 1 000 000 à 1 800 000 FCFA annoncé pour un
poste de directeur de cabinet qui s'est révélé être celui d'un **ministre**. J'insiste pour
obtenir l'entreprise, en une ligne s'il le faut, et je produis le reste du livrable en attendant.

Constitué le 26/08/2026. **Trois sources, trois natures différentes.** Les confondre est
l'erreur qui coûte le plus cher, parce que chacune répond à une question différente.

---

## Le tableau qui commande tout

| Source | Ce qu'elle dit | Ce qu'elle ne dit pas | Outil |
|---|---|---|---|
| **Minimum conventionnel** | le **plancher légal opposable** par catégorie et secteur | ce qu'un candidat acceptera | `tools/smcc.py` |
| **Guide Grey Search Africa 2024-2025** | ce que le **marché déclare payer**, 900 postes, 3 pays | l'employeur précis, la date exacte | `tools/salaires-ci.py` |
| **Observatoire des offres** | ce que les employeurs **affichent publiquement**, en direct | les postes qui ne passent pas par une annonce | `integrations/emploi-afrique/salaires.py` |

**L'ordre d'usage : Grey Search d'abord** (c'est la mesure la plus large), **l'observatoire
pour recouper et dater**, **le minimum conventionnel en dernier, pour vérifier la légalité**.
Jamais l'inverse : ouvrir sur le minimum conventionnel conduit à proposer 230 000 FCFA à un
cadre confirmé.

---

## 1 · Guide des salaires Grey Search Africa 2024-2025

Troisième édition. Côte d'Ivoire, Sénégal, Bénin. Cabinet de recrutement d'Abidjan, dirigé par
Leïla Richard Touma. Publié en février 2025.
Fichier : `reference/remuneration-ci/grey-search-africa-guide-salaires-2024-2025.pdf` ·
source : <https://greysearchafrica.com/guide-des-salaires/>

**Méthode déclarée par le cabinet** : 5 000 répondants à un sondage, plus de 20 000 profils
référencés, douze mois d'investigation, entretiens candidats avec vérification en binôme,
consentement explicite et anonymat. Segmentation en trois niveaux : junior moins de 5 ans,
middle 5 à 10 ans, senior plus de 10 ans. Familles couvertes : finance, RH, opérations,
administration, technique. Startups, PME et multinationales.

**Base extraite** : `reference/remuneration-ci/gsa-2024-2025-salaires.csv` —
**1 820 lignes, 717 postes** (Côte d'Ivoire 1 582 lignes, Sénégal 189, Bénin 49).
Chaque ligne porte un salaire bas, moyen et haut.

**Contrôles passés avant de s'en servir :**
- ordre bas ≤ moyen ≤ haut vérifié sur les 1 820 lignes — **zéro incohérence** ;
- équilibre des niveaux : 528 / 528 / 526, ce qui prouve que les blocs sont bien découpés ;
- recoupement contre **deux pages rendues en image** à des endroits différents du document
  (p. 26 assistanat, p. 64 digital) — valeurs identiques au caractère près ;
- les cellules vides du guide restent vides. Un tiret n'est jamais devenu un zéro.

🔴 **Ce que le guide ne dit nulle part, et qu'il ne faut donc pas affirmer** : ni la devise,
ni la périodicité, ni brut ou net n'apparaissent dans le document. Le **FCFA mensuel** est une
déduction — un assistant à 145 000 n'a de sens qu'en mensuel, l'annuel tomberait sous le SMIG.
La déduction est solide, ce n'est pas une donnée. **Avant de porter un de ces chiffres dans une
offre, faire confirmer par le cabinet** : entre brut et net il y a 6,3 % de retraite salariale
plus l'impôt sur les traitements et salaires.

⚠️ Autre limite : c'est un cabinet de recrutement qui publie sur son propre marché. Les
montants viennent de candidats qu'il a rencontrés, donc de gens en recherche — une population
qui n'est pas exactement celle des gens en poste.

⚠️ Limite d'extraction : le premier poste de chaque tableau garde le titre de sa section en
préfixe (« ASSISTANAT DE DIRECTION OPÉRATIONNELLE ASSISTANT DE… »). L'information est juste,
le nom est seulement long.

**Usage** :
```
python3 tools/salaires-ci.py developpeur
python3 tools/salaires-ci.py "chef de projet" --niveau 10
python3 tools/salaires-ci.py directeur --pays senegal
python3 tools/salaires-ci.py --familles
```

---

## 2 · Observatoire des offres publiées

Collecte des annonces réellement publiées, avec leur date et leur employeur.
Voir `integrations/emploi-afrique/` et la compétence `canaux-sourcing-ci`.

**Ce qu'il apporte que Grey Search n'a pas** : la **date**. Une fourchette d'un guide de
février 2025 ne dit pas ce qui se pratique ce mois-ci. L'observatoire, si.

**Ce qu'il ne verra jamais** : les postes de direction. Sur 4 048 offres ivoiriennes
collectées, la direction générale représente une poignée d'annonces. Ces postes se pourvoient
par approche directe.

**Mesuré le 26/08/2026** : 4 048 offres CI (29 mars → 24 août 2026), **224 avec un salaire
déclaré, soit 6 %**. Quatorze combinaisons métier × séniorité franchissent le seuil de cinq
observations. Aucune fourchette ne sort sous ce seuil, et le seuil ne se contourne pas.

---

## 3 · Comment répondre à une question de rémunération

1. **Interroger Grey Search** sur l'intitulé, avec deux ou trois formulations — les libellés du
   guide ne sont pas ceux de l'annonce.
2. **Recouper avec l'observatoire** si le métier y est représenté. Un écart important entre les
   deux se signale, il ne se moyenne pas.
3. **Vérifier le plancher légal** avec `tools/smcc.py`, secteur et catégorie du poste.
4. **Chiffrer le coût employeur** avec `tools/cout-employeur.py` si la question porte sur le
   budget et non sur la proposition.
5. **Écrire d'où vient chaque chiffre.** Un montant sans sa source ne se transmet pas.

**Ce qui ne se fait jamais** : moyenner deux sources de nature différente, présenter un salaire
moyen comme une proposition, ou donner un chiffre pour un poste que ni le guide ni les offres
ne couvrent. Dans ce dernier cas, on le dit et on propose d'aller chercher.

## Provenance

Compétence écrite le 26/08/2026 à la demande du client, qui a signalé l'existence du guide
Grey Search. Prolonge `droit-du-travail-ci` (le plancher légal) et `canaux-sourcing-ci`
(d'où viennent les offres). Voir aussi `optimisation-offre` et `negociation-offre`.
