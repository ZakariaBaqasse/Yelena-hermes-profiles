---
id: Y0730
name: formulaire-de-candidature
description: "Construit le formulaire de candidature qui accompagne CHAQUE fiche de poste : les questions posées à tous (disponibilité, préavis, lieu de résidence, coordonnées), les champs propres au poste (lien GitHub pour un poste technique, portfolio pour un designer, réalisations pour un commercial), une question fermée par critère bloquant du cadrage, et pour chaque pièce, obligatoire ou facultative. Rendu en Google Sheet prêt à être saisi dans un outil de formulaire ou poussé dans le logiciel de suivi des candidatures. À charger dès qu'une fiche de poste est rédigée ou qu'une annonce va être publiée."
bucket: A
tags: [Recrutement, Processus, Nouveau]
version: 1
maj: 2026-09-23
---

# Le formulaire de candidature, avec chaque fiche de poste

> **Écrit le 23/09/2026 d'après le point de formation.** La fiche de poste était faite, mais
> rien ne disait ce qu'on demande au candidat quand il postule. Or c'est ce formulaire qui
> alimente le logiciel de suivi des candidatures, et c'est lui qui permet de trier les
> premières candidatures sans les rouvrir une à une.

---

## ⛔ Contrôle avant remise

Avant de remettre une fiche de poste, vérifie que son formulaire de candidature part avec
elle. Avant de remettre le formulaire, vérifie que :

1. chaque champ dit s'il est **obligatoire ou facultatif**, et pourquoi on le demande ;
2. chaque critère bloquant du cadrage a **sa question fermée** (oui ou non, ou choix dans une
   liste), pour que le tri se fasse sur la réponse ;
3. le poste a **ses champs propres** (voir la table plus bas), et pas seulement le CV ;
4. aucune question ne porte sur un motif que la loi interdit de prendre en compte à l'embauche
   (section « Ce qu'on ne demande pas ») ;
5. le formulaire porte la mention d'information sur l'usage des données.

Un point en échec : tu corriges avant de remettre.

---

## 1. Les questions posées à tous

Elles reviennent à chaque poste, pour que les réponses se comparent d'un recrutement à
l'autre.

| Champ | Type | Par défaut | Pourquoi |
|---|---|---|---|
| Nom et prénom | texte court | obligatoire | identifier la candidature |
| Adresse e-mail | e-mail | obligatoire | répondre au candidat |
| Numéro de téléphone, et s'il est joignable sur WhatsApp | texte court + oui/non | obligatoire | convenir d'un entretien |
| Ville de résidence habituelle | texte court | obligatoire | temps de trajet, relocalisation éventuelle |
| Date à laquelle tu peux commencer | date | obligatoire | la comparer à la date de démarrage du cadrage |
| Es-tu tenu par un préavis, et de combien de temps ? | choix + texte court | obligatoire | c'est le préavis qui décide de la date réelle |
| CV | fichier | obligatoire | la pièce de base |
| Lien du profil LinkedIn | lien | facultatif | recouper le CV (compétence `tri-de-cv-et-nuance`) |
| Lettre de motivation | fichier ou texte long | facultatif | sauf si l'entreprise l'exige |
| Comment as-tu connu l'offre ? | choix dans une liste | facultatif | mesurer ce que rapporte chaque canal |

Une question de disponibilité à horizon fixe (« disponible d'ici trois mois ? ») se pose
quand le cadrage fixe une date ; sinon la date de démarrage suffit.

## 2. Les champs propres au poste

Tu pars de la famille du poste, puis tu ajustes au cadrage.

| Famille | Champs à ajouter | Par défaut |
|---|---|---|
| Technique (développement, données, direction technique) | lien GitHub ou GitLab, projet dont le candidat est fier et son rôle dedans | lien : obligatoire pour un poste qui code |
| Design, création | lien du portfolio | obligatoire |
| Contenu, communication | deux ou trois exemples publiés | obligatoire |
| Commercial | une réalisation chiffrée qu'il peut raconter en entretien | facultatif |
| Finance, comptabilité | logiciels comptables pratiqués, référentiel comptable maîtrisé | obligatoire si le cadrage en fait un critère bloquant |
| Encadrement, direction | taille de la plus grande équipe encadrée | obligatoire |
| Poste à langue | niveau dans la langue exigée, sur une échelle déclarée | obligatoire si la langue est bloquante |

Un champ propre au poste qui ne sert à aucun critère du cadrage n'a rien à faire dans le
formulaire : chaque question en plus fait perdre des candidats.

## 3. Une question fermée par critère bloquant

Pour chaque critère bloquant du cadrage, une question fermée : « As-tu déjà déposé seul des
déclarations fiscales ? Oui / Non ». Elle permet le premier tri sans ouvrir le CV. La réponse
ne vaut pas preuve : elle se vérifie en entretien. Une réponse « non » à un critère bloquant
ne met pas le dossier à l'écart tout seul : écarter une candidature reste une décision humaine.

## 4. Les références, dès le dépôt

Tu proposes à l'entreprise un bloc facultatif « deux personnes qui peuvent parler de ton
travail » : nom, fonction au moment de la collaboration, entreprise, lien avec le candidat,
coordonnées. C'est ce qui permet de prendre les références avant toute offre sans perdre de
temps (compétence `prise-references`). Le formulaire dit qu'elles ne seront appelées qu'aux
dernières étapes et avec l'accord du candidat.

## 5. Ce qu'on ne demande pas

Le Code du travail ivoirien (loi n° 2015-532, article 4, texte sur disque dans
`~/.claude/outils-communs/droit-travail-ci/code-du-travail-2015-532.txt`) interdit à
l'employeur de prendre en considération, pour l'embauche, notamment le sexe, l'âge,
l'ascendance nationale, la race, la religion, l'opinion politique, l'origine sociale,
l'activité syndicale, la séropositivité et le handicap. Le formulaire ne pose donc ni
question ni case sur ces sujets, et ne demande ni photo, ni date de naissance, ni situation
de famille. Hors Côte d'Ivoire, tu vérifies le texte du pays avant de reprendre la liste.

## 6. La mention d'information sur les données

En bas du formulaire, une mention courte dit qui reçoit les données, à quoi elles servent
(ce recrutement, et le vivier si le candidat l'accepte par une case à part), combien de temps
elles sont gardées, et à qui écrire pour les consulter ou les faire retirer. Le cadre
applicable est dans la compétence `donnees-personnelles-ci` : tu t'y réfères, tu ne cites
pas un article que tu n'as pas lu.

## 7. Où vit le formulaire

- **Dans le logiciel de suivi des candidatures**, quand l'entreprise en a un : les champs se
  saisissent dans le formulaire de l'offre, pour que chaque réponse arrive dans la fiche du
  candidat. C'est le cas le plus utile : les premiers tris se font sur les réponses.
- **Dans un outil de formulaire en ligne**, sinon, avec le lien mis dans le bloc « Pour
  postuler » de l'annonce.

⛔ Tout appel à un de ces services passe par un script de son dossier `integrations/`. Si
aucun script du poste ne sait créer ce formulaire, tu remets la spécification, tu dis qu'il
manque ce script, et tu n'appelles pas le service à la main. Publier un formulaire au nom de
l'entreprise est une publication : elle se valide avant.

## Format de sortie

- **Un Google Sheet** (et son fichier Excel) : une ligne par champ, avec les colonnes
  libellé tel que le candidat le lira, type de champ (texte court, texte long, choix unique,
  choix multiple, oui/non, date, fichier, lien, e-mail), obligatoire ou facultatif, options
  de réponse, critère du cadrage servi, pourquoi on le demande.
- **Un aperçu** du formulaire tel que le candidat le verra, dans l'ordre : coordonnées,
  disponibilité, champs du poste, questions bloquantes, pièces, références, mention sur les
  données. Dix à quinze champs au total : au-delà, les candidats abandonnent.
- Le message de remise dit où le formulaire va vivre et ce qui reste à faire pour le mettre
  en ligne.

## Règles

1. **Pas de fiche de poste sans formulaire de candidature.**
2. **Chaque champ se justifie par un critère du cadrage**, ou il sort.
3. **Chaque critère bloquant a sa question fermée.**
4. **Obligatoire ou facultatif, toujours dit.**
5. **Aucune question sur un motif interdit à l'embauche.**
6. **Rien n'est publié sans validation.**

## Cas limites

- **L'entreprise a déjà son formulaire** : tu le reprends tel quel et tu proposes seulement
  ce qui manque au regard du cadrage, en le signalant.
- **Pas de cadrage** : tu produis le formulaire avec les questions communes et les champs de
  la famille du poste, et tu marques les questions bloquantes `[à confirmer]`.
- **Poste sensible, avec vérification d'antécédents** : la vérification se fait à la fin du
  processus, pas au dépôt. Le formulaire porte seulement le texte d'information et la case
  non cochée d'avance que prévoit la compétence `verification-d-antecedents` (section 3),
  remplis avec le client. Aucun extrait de casier n'est demandé au dépôt.
- **Candidature par WhatsApp ou par e-mail seulement** : tu rends la liste des pièces et des
  réponses attendues sous forme de message type, avec les mêmes champs obligatoires.

## Historique

- v1, 23/09/2026 : création, séance Sync agents training.
