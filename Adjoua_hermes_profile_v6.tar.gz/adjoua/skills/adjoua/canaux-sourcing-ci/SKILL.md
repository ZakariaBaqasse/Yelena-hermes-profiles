---
id: Y0516
name: canaux-sourcing-ci
description: Où trouver des candidats en Côte d'Ivoire et dans l'espace UEMOA — les sites d'emploi qualifiés un par un, les écoles et leurs guichets employeurs, les communautés professionnelles, et ce que chaque canal rapporte réellement. À charger avant de diffuser une annonce ou d'ouvrir un sourcing, pour ne pas rejouer LinkedIn par défaut.
version: 1
maj: 2026-08-26
---

# Canaux de sourcing — Côte d'Ivoire et UEMOA

Qualifié le 26/08/2026. **Chaque canal listé ici a été ouvert.** Ce qui n'a pas
répondu est marqué comme tel, et ne se recommande pas.

---

## 1 · Sites d'emploi — l'état réel, testé

| Canal | Accès | Volume constaté | Salaires ? | Verdict |
|---|---|---|---|---|
| **GoAfricaOnline** <https://www.goafricaonline.com/ci/emploi> | ✅ 200 | 510 offres CI actives | **oui, 6 %** | **le seul exploitable en machine** |
| **Novojob CI** <https://www.novojob.com/cote-d-ivoire/> | ⚠️ instable | 209 offres | non | diffusion oui, collecte non |
| **Educarriere** <https://emploi.educarriere.ci/> | ⚠️ partiel | ⟦non mesuré⟧ | non | pages internes cassées le 26/08 |
| **Emploi.ci** <https://www.emploi.ci/> | ❌ 403 | — | — | inaccessible depuis nos machines |
| **AEJ** (Agence Emploi Jeunes) <https://agenceemploijeunes.ci/> | ✅ 200 | ⟦non lisible⟧ | — | site répond, contenu non exploré |
| **UMO Intérim** <https://www.umo-interim.com/jobs/> | ✅ 200 | ⟦non mesuré⟧ | ⟦non mesuré⟧ | régional, six pays UEMOA |
| **ProJobIvoire** <https://projobivoire.com/> | ✅ 200 | ⟦non mesuré⟧ | ⟦non mesuré⟧ | à qualifier |
| **JobIvoire** <https://www.jobivoire.ci/> | ✅ 200 | ⟦non mesuré⟧ | ⟦non mesuré⟧ | à qualifier |
| **BeBee CI** <https://bebee.com/ci/jobs/location/abidjan> | ✅ 200 | ⟦non mesuré⟧ | ⟦non mesuré⟧ | agrégateur, doublons probables |

🔴 **Emploi.ci est cité partout comme la référence ivoirienne et nous est
inaccessible** (403 sur toutes ses URL). Ne jamais l'annoncer à un client comme
un canal que nous couvrons. Si la diffusion doit y passer, c'est un humain qui
publie.

**Pourquoi GoAfricaOnline est à part** : ses pages d'offre portent un bloc
`schema.org/JobPosting`, donc des champs déclarés par l'employeur — intitulé,
date, organisation, ville, secteur, niveau d'études, années d'expérience,
et parfois le salaire. C'est la seule source qui permet une lecture de marché
en machine plutôt qu'à l'œil. Voir `integrations/emploi-afrique/`.

**Couverture régionale du même canal** : `ci` · `sn` · `bf` · `ml` · `tg` ·
`bj` · `ne` · `gn` · `cm` · `cd` · `cg` · `ga` · `cf` · `ao`. Un poste ouvert à
la zone se source sur plusieurs pays sans changer d'outil.

---

## 2 · Écoles — le guichet employeur, pas la page d'accueil

Une école ne se contacte pas par son standard : elle a un service qui existe
pour ça, et c'est lui qui a les diplômés.

**INP-HB** (Yamoussoukro) — la référence ivoirienne en ingénierie.
🎯 **Centre carrière : <https://www.careercenter.inphb.ci/>** — guichet unique
avec espace recruteur, création de compte entreprise et dépôt d'offre en ligne.
`careercenter@inphb.ci` · [numéro retiré] / 07 07 23 21 20.
_C'est le canal le plus directement actionnable de cette fiche : il ne demande
ni introduction ni relation préalable._

**ESATIC** (Treichville, Abidjan) — établissement public dédié aux TIC, créé en
2012. Ingénieurs en informatique, télécoms et cybersécurité, plus des licences,
masters et classes préparatoires. Revendique plus de 700 partenaires et une
employabilité à trois mois. `direction.esatic@esatic.edu.ci` ·
+225 27 21 21 81 00 · <https://esatic.ci/>
⚠️ Aucun service relations entreprises identifié sur le site : le contact passe
par la direction, il faut donc une demande écrite et non un dépôt d'offre.

**Université Virtuelle de Côte d'Ivoire** — <https://uvci.online/> (le domaine
`uvci.edu.ci` redirige vers ce portail). ⟦Guichet employeur non identifié⟧.

**UFR Mathématiques-Informatique, Université Félix Houphouët-Boigny** —
⟦non ouvert, à qualifier⟧.

---

## 3 · Communautés et écosystème

**French Tech Abidjan** — <https://frenchtechabidjan.com/> (répond).
Association de l'écosystème tech. Utile pour un poste de direction technique ou
produit, où l'annonce ne suffit jamais. ⟦Modalités de diffusion d'une offre non
vérifiées⟧.

⚠️ **Jokkolabs Abidjan** et **Orange Fab Côte d'Ivoire** reviennent dans les
sources secondaires comme les hubs de référence, mais **leurs sites n'ont pas
répondu** le 26/08/2026. Ne pas les citer à un client comme des canaux ouverts
tant qu'un point de contact vivant n'a pas été trouvé.

---

## 4 · Ce que cette fiche ne dit pas, et qu'il faut savoir

1. **Les postes de direction ne passent pas par les annonces.** Sur 540 offres
   ivoiriennes collectées, six relèvent de la direction générale. Un poste de
   direction se source par approche directe et par réseau — l'annonce est une
   formalité, pas un canal.
2. **Les groupes WhatsApp professionnels sont le canal réel du marché ivoirien**
   pour beaucoup de métiers, et nous n'y avons aucun accès. C'est une limite
   structurelle : elle se compense par les personnes de la maison, pas par un
   outil.
3. **Les associations d'anciens élèves** ne sont pas instruites. Elles sont
   souvent le meilleur canal sur les profils de cinq à dix ans d'expérience.
4. Un canal ⟦non mesuré⟧ ci-dessus n'est pas un canal recommandé : il est
   seulement vivant. Le qualifier prend dix minutes et évite d'annoncer un
   vivier qui n'existe pas.

## Provenance

Fiche établie le 26/08/2026 à la demande du client, chaque adresse testée en
HTTP le jour même. Voir `integrations/emploi-afrique/` pour la collecte et
`droit-du-travail-ci`, `recrutement-uemoa` pour le cadre juridique.
