---
id: Y0721
name: remise-de-livrable-lisible
description: La forme du message qui accompagne un livrable, pour que l'interlocuteur sache en trois secondes ce qu'il reçoit, où cliquer et ce qu'il doit en faire.
version: 1
maj: 2026-09-22
---

# Remettre un livrable de façon lisible

Un livrable bien fait qui arrive dans un message confus arrive mal. L'interlocuteur ouvre
Telegram entre deux réunions : il doit comprendre en trois secondes **ce qu'il reçoit**,
**où il clique**, et **ce qu'on attend de lui**.

Cette forme n'est pas une préférence de style. La direction l'a demandée le 22/09/2026 après avoir
vu la remise d'ADJOUA : « avec les liens, les icônes, c'est facile à suivre. C'est comme ça
que tous les experts doivent remettre les livrables. »

## 1 · La structure, dans cet ordre

```
*Titre du livrable · repère de date ou de version*
🔗 [Ouvrir le document](lien) · PDF ci-joint · 3 pages

Deux ou trois phrases : ce que contient le document, et ce qu'on y trouve d'utile.

La phrase qui compte : ce qui doit être décidé, ou ce qui manque, ou la réserve.
```

Ce qui fait la lisibilité, point par point :

- **une ligne de titre en gras**, qui nomme le livrable, pas la tâche. « Rapport
  d'avancement · 22 septembre », pas « voici le travail demandé » ;
- **une ligne d'accès** juste dessous : une icône, le lien cliquable **avec un libellé**
  (jamais l'URL nue), puis les repères séparés par des points médians. Format, nombre de
  pages, ce qui est joint ;
- **du texte court ensuite**, deux à quatre phrases. Pas un résumé du document : ce qu'il
  faut en savoir pour décider de l'ouvrir ou non ;
- **plusieurs livrables = plusieurs blocs**, chacun avec sa ligne d'accès. Jamais une liste
  de liens en fin de message.

## 2 · Les icônes, une par nature de pièce

Toujours les mêmes, pour qu'elles se reconnaissent sans être lues.

| Icône | Ce qu'elle annonce |
|---|---|
| 🔗 | un document à ouvrir (Doc, Sheet, Slides) |
| 📄 | un PDF |
| 📊 | un tableur ou un tableau de bord |
| 🖼 | un visuel, une planche, une maquette |
| 📂 | un dossier, ou un lot de pièces |
| 🎬 | une vidéo ou une animation |

Une icône par ligne d'accès. Jamais deux qui se suivent, jamais une icône décorative dans le
corps du texte.

## 3 · Le lien porte un libellé, et il s'ouvre

⛔ **Jamais d'URL nue dans un message.** `[Ouvrir le rapport](https://…)`, pas
`https://docs.google.com/…`. Une URL nue est illisible sur mobile et ne dit pas ce qu'elle
ouvre.

⛔ **Un lien remis s'ouvre sans demande d'accès.** Le vérifier avant d'envoyer, pas après.
Un lien qui demande une autorisation renvoie l'interlocuteur vers nous et annule le gain.

⚠ Un lien qui s'ouvre sans connexion **peut être transféré**. Ce qui est nominatif ou
confidentiel part en pièce jointe, pas en lien ouvert, et on le dit dans le message.

## 4 · Ce que le message dit toujours, et qu'on oublie

- **la réserve, s'il y en a une.** Ce qui n'a pas été fait, ce qui n'a pas pu être vérifié,
  le chiffre qui manque. C'est la phrase la plus utile du message ;
- **ce qui est attendu de l'interlocuteur**, quand quelque chose l'est : une décision, une
  validation, une information. Nommée, pas suggérée ;
- **rien d'autre.** Pas de récapitulatif de la demande, pas de « j'espère que cela
  conviendra », pas de liste de ce qu'on a fait pour y arriver.

## 5 · Le contre-exemple

> Bonjour, comme demandé j'ai préparé le document. Vous trouverez ci-dessous le lien vers
> le rapport ainsi que le PDF. https://docs.google.com/document/d/1CsrmX… N'hésitez pas si
> vous avez des questions.

Trois défauts : on ne sait pas ce qu'on reçoit avant d'avoir cliqué, l'URL est nue, et le
message ne dit ni ce qu'il y a dedans ni ce qu'on doit en faire.
