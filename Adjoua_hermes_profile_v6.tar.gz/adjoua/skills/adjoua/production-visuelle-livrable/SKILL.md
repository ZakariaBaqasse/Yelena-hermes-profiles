---
id: Y0716
name: production-visuelle-livrable
description: >
  Comment un visuel se remet, avec un contrôle avant remise OBLIGATOIRE : chaque affirmation
  porte sa source, les polices se vérifient page par page sur le rendu, un carrousel part en
  lien + PDF + PNG, un flyer en JPEG + PNG + PDF, les bannières de profil LinkedIn et Facebook,
  le favicon et les icônes suivent leurs contrôles. Aussi : images téléchargeables une par une,
  réseau et dimensions confirmés, objets promotionnels en trois typologies, charte qui porte sa
  typographie, artefacts montrés et non décrits, benchmark visuel qui déduit au lieu de décrire.
  À charger avant d'envoyer toute création graphique : flyer, carrousel, bannière, favicon,
  icônes, charte, benchmark, deck, fiche, écran ou déclinaison de marque.
version: 2
maj: 2026-09-23
---

# Remettre un visuel

> **Écrit le 22/09/2026 d'après la revue de production du point de formation.** Les visuels
> étaient jugés bons ; ce qui n'allait pas, c'est la façon dont ils arrivaient chez le client.

---

## ⛔ Contrôle avant remise, obligatoire (23/09/2026)

Ajouté parce que des erreurs ont été vues trop tard chez le client : des affirmations sans
source, et un problème de police sur certaines pages. Ces contrôles se font **sur le fichier
que le client va recevoir**, juste avant l'envoi. Un seul en échec : tu ne remets pas, tu
corriges d'abord. Le message de remise dit en une ligne ce qui a été contrôlé.

1. **Chaque affirmation porte sa source.** Un chiffre, une date, un fait sur une entreprise,
   une citation, un classement : la source est sur la page, ou sur une page « Sources » en fin
   de document, avec l'adresse et la date de consultation. Tu relis page par page en posant la
   question à chaque phrase qui affirme. Ce qui n'a pas de source ouverte sort du document, ou
   devient une hypothèse écrite comme telle.
2. **Les polices se vérifient page par page, sur le rendu.** Tu rends chaque page en image
   (`pdftoppm -r 50 -png <fichier.pdf> <préfixe>`), tu la regardes, et tu compares à la police
   prévue : titres, corps, boutons, tableaux, pieds de page. `pdffonts` ne suffit pas : il dit
   qu'une police est incorporée, pas que c'est la bonne, et une graisse absente peut être
   remplacée puis incorporée sous le nom de la police prévue. Tu refuses une police de
   substitution, un texte à empattements là où la charte n'en a pas, une police de type 3 sur un
   texte qui devait rester vectoriel, une page qui ne porte pas les mêmes polices que les autres.
   Après une conversion (Slides, Doc, page publiée), tu contrôles la version convertie telle que
   le client l'ouvre : la conversion remplace les polices qu'elle ne connaît pas. Sur une page
   publiée, aucune police ne se charge (voir `publication-frames`) : un nom de marque dessiné
   dans une police spéciale s'y pose en image.
3. **Un carrousel part en trois formes** : le lien de la page publiée, le PDF (une planche par
   page, dans l'ordre), et un PNG par planche, numérotés dans l'ordre
   (`<slug>_v<N>_planche-01.png`, `-02`…). Les trois sont joints ou déposés avec le message de
   remise. Le lien seul n'est pas une remise : le client doit pouvoir publier tel quel.
4. **Un flyer part en JPEG, PNG et PDF**, une image par fichier (section suivante).
5. **Bannière de profil, favicon, icônes** : leurs contrôles sont dans la section qui leur est
   consacrée plus bas. Tant qu'un de ces contrôles n'est pas fait, le fichier ne part pas.

---

## Ce qui part, et sous quelle forme

**Une image par fichier.** Jamais une planche où cinq propositions sont collées les unes à
côté des autres. Le client veut en prendre une, la poser dans un support, la faire imprimer :
une planche l'oblige à découper. Chaque visuel se télécharge séparément.

**Trois formats par défaut pour un flyer** : JPEG, PNG et PDF. Le JPEG pour les messageries,
le PNG quand il faut de la transparence ou du texte net, le PDF pour l'impression. Tu les
fournis sans qu'on te les demande.

**Le réseau et les dimensions se confirment avant de produire.** Une publication n'a pas le
même format sur un fil, en story, en bannière ou en carrousel. Tu demandes pour quel réseau,
tu annonces la taille que tu vas appliquer, et tu produis ensuite.

**Les bannières se livrent par lot.** LinkedIn et Facebook au minimum, aux dimensions
officielles de chaque réseau, cohérentes entre elles. Voir plus bas « Bannières de profil,
favicon, icônes ».

**Un carrousel est une suite d'idées, pas un document découpé.** Une idée par page, lisible
sur un téléphone tenu à bout de bras, une page de fin qui dit quoi faire. Il se remet en lien,
en PDF et en PNG (contrôle 3 ci-dessus), jamais en lien seul.

---

## La charte et le système de marque

**Une charte sans typographie n'est pas une charte.** Les couleurs ne suffisent pas : il faut
les familles, les graisses, les tailles et ce qu'on fait quand la police n'est pas disponible.

**Deux univers proposés doivent être deux univers.** Si l'un est l'autre avec une couleur
changée, tu n'as proposé qu'un choix. Ils doivent différer par le registre, pas par la teinte.

**Les artefacts et les motifs se montrent.** Décrire un motif dans un paragraphe ne sert à
rien : le client ne peut ni le juger ni l'utiliser. Tu le rends, à l'échelle, sur un fond
réel, et tu montres comment il se répète.

**Un système de design est un document qu'un tiers applique sans toi** : usage du logo et ses
interdits, palette et ses rôles, typographies, boutons et leurs états, espacements. Si un
prestataire extérieur ne peut pas s'en servir seul, ce n'est pas encore un système.

---

## Les objets promotionnels

Ils couvrent bien plus que le mug et le stylo : bouteilles, autocollants, carnets, textiles,
sacs, signalétique. Tu proposes **trois typologies** et le client choisit :

| Typologie | Ce qu'elle dit |
|---|---|
| Professionnelle | sobre, logo discret, usage en clientèle |
| Amusante | jeu sur le motif, couleur franche, usage en interne ou en salon |
| Moderne | matière et forme d'abord, marque en retrait |

Le catalogue complet des objets courants et le contrôle avant remise des objets
promotionnels vivent dans `goodie-forge`, à charger pour toute demande d'objets.

⛔ **Le logo suit ses propres règles sur un objet.** Grossi pour remplir la surface, il casse
la marque au lieu de la servir. Sa taille se calcule sur la zone de protection, pas sur la
place disponible.

---

## Le benchmark visuel : déduire, pas inventorier

Un benchmark qui liste ce que font les autres n'apprend rien. Le tien compare, puis conclut.

Ce qui se compare : logos, palettes, **couleurs d'accent**, typographies, taglines, présence
par réseau, et la manière de parler, expressions comprises.

Ce qui se conclut, et c'est la seule partie qui a de la valeur : **ce qui distingue cette
marque des autres**, ce qu'elle occupe que personne n'occupe, et ce qu'elle partage avec tout
le monde sans le savoir.

⛔ Les acteurs comparés se font valider avant, jamais après : voir
`socle-cadrage-avant-production`.

---

## L'outil se choisit selon ce qu'on produit

Tu ne produis pas un écran avec l'outil d'une affiche. Avant de commencer, tu regardes le
référentiel des outils de la maison et tu prends celui qui correspond à ce que tu fabriques.
Quand un outil attendu n'est pas disponible, **tu le dis** au lieu de produire avec un autre
en silence : « je n'ai pas accès à tel outil en ce moment, je te le fais avec tel autre, voilà
ce que ça change ».

## Les générateurs : cinq règles tirées de la nuit du 22-23/09/2026

1. **Un générateur ne touche jamais une image qui porte la marque.** Magnific a redessiné le
   logo d'une marque en l'agrandissant ; Stitch en refabrique un quand on ne le lui donne pas. Ordre :
   le générateur fait le vierge, l'agrandisseur travaille le vierge, le logo se pose en dernier
   depuis le fichier vectoriel.
2. **Un générateur devant une zone vide y met quelqu'un.** L'extension de cadre Magnific est
   partie d'un comptoir vide et a rendu une femme blanche en tailleur dans une boutique
   d'Abidjan. Ne s'emploie que sur une surface sans sujet possible.
3. **Un appel en erreur se vérifie au solde avant d'être rejoué.** Un 504 a masqué une opération
   aboutie et facturée (50 crédits).
4. **Une sortie de générateur se capture en entier, dans un fichier.** Trois générations Stitch
   perdues le 22/09 pour une sortie tronquée à l'écran.
5. **Stitch explore, il ne livre pas.** Mesuré : 38 couleurs hors charte sur 45, un jeton
   `primary` qui n'est pas la couleur de marque, 1,61 Mo de ressources extérieures, des icônes
   qui impriment leur nom de code hors réseau, et des variantes qui rejouent les mêmes défauts.

⛔ Un écran se conçoit dans un outil de maquette, pas dans un outil d'image. Le client doit
pouvoir cliquer dedans.

---

## Bannières de profil, favicon, icônes (22/09, puis 23/09/2026)

Demandé le 22/09, redemandé le 23/09 parce que rien n'avait été produit entre les deux.

**Bannière de profil** : la couverture d'une page ou d'un profil LinkedIn, d'une page Facebook.
À ne pas confondre avec une bannière de campagne payante (`bannieres-publicitaires-multiformats`).
Avant de remettre, tu vérifies que :
- les dimensions viennent de la page d'aide officielle du réseau, ouverte le jour même, lien cité
  dans la remise. Aucune dimension de mémoire ;
- rien d'important ne passe sous la photo de profil ni hors du recadrage sur téléphone : tu poses
  sur le rendu un cercle à l'emplacement de la photo, puis tu regardes la version recadrée ;
- LinkedIn et Facebook sortent ensemble, même message, recomposés et non étirés ;
- chaque bannière part en PNG et en JPEG.

**Favicon et icône d'application.** Avant de remettre, tu vérifies que :
- le dessin part du symbole seul (voir `systeme-de-logo`), jamais du logo complet réduit, où le
  nom devient illisible ;
- les tailles viennent de la documentation des navigateurs et des magasins d'applications, lue
  le jour même ;
- le rendu à la plus petite taille se reconnaît, sur un onglet clair et sur un onglet sombre.
  S'il ne se reconnaît pas, on simplifie le dessin ;
- la remise porte le SVG source, les PNG aux tailles relevées, et les lignes HTML qui les
  déclarent.

**Jeu d'icônes dessiné.** Avant de remettre, tu vérifies que :
- toutes les icônes partagent une grille, une épaisseur de trait, un rayon et les mêmes bouts de
  trait ;
- aucun symbole ne contredit le contexte du client (une devise qui n'est pas la sienne, un geste
  qui ne se lit pas localement) ;
- la remise porte le SVG couleur et monochrome, les PNG aux tailles demandées, et une planche où
  toutes les icônes se voient côte à côte à la plus petite taille d'usage.
Pour choisir une famille existante plutôt que dessiner : `bibliotheque-icones`.

---

## Historique

- v1, 22/09/2026 : écrit d'après la revue de production du point de formation.
- v2, 23/09/2026 : contrôle avant remise obligatoire en tête (sources sur chaque affirmation,
  polices vérifiées page par page sur le rendu, carrousel en lien + PDF + PNG), section
  bannières de profil, favicon et icônes, renvoi vers `goodie-forge`, séance Sync agents training.
