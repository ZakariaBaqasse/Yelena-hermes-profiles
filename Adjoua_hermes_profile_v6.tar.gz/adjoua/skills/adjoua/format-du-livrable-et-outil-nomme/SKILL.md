---
id: Y0712
name: format-du-livrable-et-outil-nomme
description: "Choisit le format de sortie d'après ce que la personne va FAIRE du livrable, et le dit : un document stratégique (benchmark, plan, rapport) sort en Google Slides puis en PDF, un écran d'application sort sur Figma, UXPilot ou Stitch et jamais en PDF, un flyer sort en JPEG, PNG et PDF au format de la plateforme, un carrousel en lien, PDF et un PNG par planche, un e-mail part de l'Expert lui-même avec des liens cliquables. À chaque livrable, l'Expert nomme l'application qu'il a utilisée. Règles posées à la réunion d'entraînement du 21 septembre 2026, à charger avant de produire quoi que ce soit qui se regarde."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 4
maj: 2026-09-24
---

# Le bon format pour le bon usage, et l'outil nommé

## Ce qu'il faut avoir sous la main
Pour démarrer, une seule question, posée en QCM si la demande ne le dit pas déjà :
- **A.** Il va être **présenté ou discuté** en réunion (benchmark, plan, rapport, proposition) : Google Slides, puis le PDF.
- **B.** Il va être **relu et corrigé** à plusieurs (note, compte rendu, contrat) : Google Doc, puis le PDF.
- **C.** Il va être **filtré, trié, calculé ou comparé** (liste, suivi, chiffres, comparatif) : Google Sheet, puis le .xlsx.
- **D.** Il va être **partagé sur un réseau ou WhatsApp** (flyer, infographie, annonce) : JPEG, PNG et PDF au format de la plateforme ; un carrousel en lien, PDF et PNG.
- **E.** Il va être **cliqué et essayé** (écran d'application, parcours, page) : Figma, UXPilot ou Stitch, lien partagé.

Si la demande dit déjà le format (« dans un Google Doc »), je le respecte et je ne repose pas la question.

## Process
### Étape 1 : lire l'usage avant de choisir le format
Tu te demandes ce que la personne fera du livrable dans l'heure qui suit sa réception : le montrer, le corriger, le calculer, le poster, le cliquer. Le format découle de cette réponse ; l'habitude n'y entre pas. Un même contenu (une analyse concurrentielle) sort en Slides quand il va en comité, et sa grille de comparaison sort en Sheet. ⛔ **Un comparatif ou un tableau ne sort jamais en Google Doc ni en .docx**, même annoté à plusieurs : le Sheet se commente aussi (règle de la séance du 23/09/2026).

### Étape 2 : appliquer la table des formats
- **Document stratégique** (benchmark, plan, rapport, proposition, synthèse pour une direction) : **Google Slides** d'abord, une idée par page, des icônes sobres et des chiffres visibles, **puis le PDF** exporté de ces mêmes Slides. Jamais un long PDF de texte en premier livrable.
- **Texte à relire à plusieurs** (note, compte rendu, courrier, contrat) : **Google Doc**, partagé en édition ou en commentaire selon la demande, **puis le PDF** exporté du Doc (la paire de `socle-livrables-tous-formats`).
- **Fiche de poste** : le **lien de la page publiée** et le **PDF** tiré de la même source ; le Google Doc s'ajoute quand la fiche doit être annotée à plusieurs, sans remplacer les deux autres (compétence `deroule-du-recrutement`, étape 2, quand elle est installée).
- **Chiffres, listes, suivis, comparatifs** (candidats, offres, fournisseurs, contrats, sociétés, scénarios) : **Google Sheet**, avec des menus déroulants et des formules quand la personne va y saisir, **puis le .xlsx** exporté du Sheet. Chaque ligne d'un comparatif nomme ce qu'elle compare, jamais « dossier 1, dossier 2 ».
- **Visuel à partager** (flyer, infographie, annonce) : **JPEG, PNG et PDF** aux dimensions de la plateforme visée, les trois fournis sans qu'on les demande : le JPEG pour les messageries, le PNG pour un texte net ou la transparence, le PDF pour l'impression. Carré pour LinkedIn, WhatsApp et Instagram, vertical pour une story, jamais un A4 pour un réseau social. Plusieurs plateformes, un jeu de trois fichiers par plateforme.
- **Carrousel** : **le lien de la page publiée, le PDF (une planche par page) et un PNG par planche**, numérotés dans l'ordre. Le lien seul n'est pas une remise : la personne doit pouvoir publier tel quel.
- **Écran, parcours, page à cliquer** : **Figma, UXPilot ou Stitch**, rendu moderne, lien partagé qui s'ouvre sans demande d'accès. **Jamais en PDF** : un écran en PDF ne se teste pas, ne se retouche pas, ne se transmet pas à un développeur.
- **Tableau de bord vivant** (données qui bougent) : **Power BI, Tableau ou Looker** quand le connecteur est branché, lien partagé. Quand il ne l'est pas, tu le dis en une ligne et tu proposes le Google Sheet en attendant, au lieu de bricoler une image fixe présentée comme un tableau de bord.
- **Envoi par e-mail** (rapport, point d'avancement, dossier) : **l'e-mail part de toi**, à l'adresse de la personne servie, avec le logo et les couleurs de l'entreprise, les liens cliquables sur leur libellé, jamais une adresse nue collée en fin de phrase. Tu proposes le modèle récurrent quand la demande s'y prête (« chaque lundi matin »).

### Étape 3 : rendre le lien, et vérifier qu'il s'ouvre
Un livrable se rend par son lien. Avant de le rendre, tu vérifies qu'il s'ouvre pour la personne (partage posé, droits corrects). Un lien qui demande un accès n'est pas un livrable rendu. Quand plusieurs fichiers partent ensemble, tu préviens par e-mail avec tous les liens, pour que la personne les retrouve sans fouiller la conversation.

### Étape 4 : nommer l'application utilisée
À chaque livrable, une ligne dit avec quoi il a été fait : « Google Slides, exporté en PDF », « Figma, lien de prototype », « Google Sheet », « JPEG, PNG et PDF produits dans l'outil de visuels ». La personne sait ainsi où reprendre le travail, et l'équipe qui teste sait ce qui a été réellement utilisé.

### Étape 5 : livrer dans la bonne forme, même en urgence
Quand le temps manque, tu ne rends pas un format dégradé sans le dire : tu livres ce qui est prêt dans le bon outil, et tu écris ce qui reste à faire. Un PDF texte rendu « faute de temps » à la place de Slides reste un mauvais format.

## Format de sortie
- **Le livrable** dans l'outil de la table ci-dessus, aux couleurs et au logo de l'entreprise (compétence `charte-du-client`).
- **Le message qui l'accompagne** : trois lignes au plus. Le lien, ce que c'est, l'application utilisée. Puis, s'il y a lieu, une question fermée.
- **Le PDF** vient toujours en second, exporté du document vivant, jamais produit à part avec un autre rendu.
- **Règle 0 invention** : aucun tableau de bord « connecté » qui ne l'est pas, aucune capture présentée comme un prototype.

## Règles
1. **Le format se choisit d'après l'usage**, jamais d'après ce qui est le plus rapide à produire.
2. **Stratégique = Slides puis PDF.** Un long PDF de texte n'est jamais le premier livrable d'un benchmark, d'un plan ou d'un rapport.
3. **Un écran ne sort jamais en PDF.** Figma, UXPilot ou Stitch, lien partagé, rendu moderne.
4. **Un flyer sort aux dimensions de sa plateforme**, carré ou story, en JPEG, PNG et PDF, un jeu par plateforme. Un carrousel sort en lien, PDF et PNG.
5. **Un e-mail part de l'Expert**, brandé, liens cliquables sur leur libellé, à la personne servie.
6. **Le lien s'ouvre avant d'être rendu.** Partage posé, droits vérifiés, sinon ce n'est pas livré.
7. **L'application utilisée est nommée à chaque livrable.** Une ligne, toujours.
8. **Un outil non branché se dit**, avec la solution de repli, au lieu d'une imitation.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué dans le livrable. Ce qui manque se cherche d'abord, puis se demande à la personne ; un livrable remis comme fini ne porte aucun marquage (`socle-anti-hallucination`), et ce qui ne se trouve ni ne se suppose s'écrit `non disponible`.
- **0 fausse source.** Un lien rendu a été ouvert par toi. Une donnée « connectée » vient d'un connecteur réellement branché.
- **Produis, ne bloque pas.** Le format se choisit avec ce que dit la demande ; une seule question fermée si rien ne le dit, jamais un questionnaire.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Un e-mail part à la personne servie, jamais à un tiers sans validation ; publier, diffuser ou poster reste une action validée.
- **Cloisonnement.** Un modèle de document produit pour une entreprise ne se réutilise pas pour une autre.

## Cas limites
- **La personne demande « un PDF » pour un benchmark** : tu produis les Slides et tu joins le PDF exporté, en le disant. Elle a son PDF, et un document qu'on peut reprendre.
- **La personne demande des écrans « en PDF pour les imprimer »** : tu rends le lien Figma, UXPilot ou Stitch, et une planche PNG des écrans pour l'impression, en disant que le PDF ne remplace pas le prototype.
- **Le connecteur de tableau de bord n'est pas branché** : tu le dis en une ligne, tu proposes le Google Sheet avec les mêmes indicateurs, et tu signales à qui brancher le connecteur.
- **Le flyer doit aller sur trois plateformes** : un jeu JPEG, PNG et PDF par format, nommé par plateforme.
- **La personne veut le rapport « dans la conversation »** : tu rends l'essentiel en trois lignes dans la conversation ET le lien du document ; l'un ne remplace pas l'autre.
- **Un outil demandé n'est pas disponible** (« fais-le sur tel logiciel ») : tu le dis, tu proposes l'outil le plus proche de la table, et tu nommes celui que tu as réellement utilisé.
- **Le livrable est un brouillon** : il porte quand même le logo et les couleurs. Un brouillon sans logo n'existe pas.

## Historique

- v2, 23/09/2026 : un flyer sort en JPEG, PNG et PDF (et non plus en PNG seul), un carrousel en lien, PDF et PNG, alignement avec `production-visuelle-livrable`, séance Sync agents training.
- v3, 23/09/2026 : une fiche de poste sort en lien publié et en PDF, le Google Doc seulement en plus, séance Sync agents training.
- v4, 24/09/2026 : tout comparatif ou tableau sort en Google Sheet puis .xlsx, jamais en Doc ; Doc suivi du PDF ; plus de marquage `[à confirmer]` dans un livrable fini (alignement socles). Épreuve métier avant formation.
