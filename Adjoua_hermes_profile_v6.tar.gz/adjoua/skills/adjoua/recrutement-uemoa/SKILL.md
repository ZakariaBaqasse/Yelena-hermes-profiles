---
id: Y0593
name: recrutement-uemoa
description: Recruter à l'échelle de l'UEMOA et de la CEDEAO — ce qui est commun aux huit pays et ce qui ne l'est pas, la libre circulation des travailleurs, les salaires minimums comparés. À charger dès qu'un poste peut être pourvu par un candidat d'un autre pays de la zone, ou qu'un client recrute hors de Côte d'Ivoire.
version: 1
maj: 2026-08-13
---

# Recruter dans l'espace UEMOA

Constitué le 13/08/2026. Ce qui n'a pas été lu à la source est marqué comme tel.

---

## 1 · Le fait qui commande tout : il n'existe pas de droit du travail commun

**L'Acte uniforme OHADA relatif au droit du travail n'a jamais été adopté.** Les travaux ont
commencé vers 1995, un avant-projet a été transmis aux gouvernements des États parties, et il est
resté là. La raison est politique et non technique : le droit du travail est en grande partie
social, et **c'est la dimension collective des relations de travail** — syndicats, représentation,
conflits — qui bloque l'harmonisation. Un acte limité au contrat individuel serait probablement
passé.

_Sources consultées le 13/08/2026 : la page de l'OHADA sur l'Acte uniforme relatif au droit du
travail (<https://www.ohada.com/actualite/2909/acte-uniforme-ohada-relatif-au-droit-du-travail.html>)
et l'avant-projet lui-même (<https://www.ohada.com/uploads/actualite/141/avant-projet-droit-travail-ohada.pdf>).
⚠️ Constat établi sur les notices et la littérature, **l'avant-projet n'a pas été lu ligne à
ligne** — ce qui est sans conséquence ici, puisqu'il n'est pas en vigueur._

**Ce que cela emporte, et il faut le dire à un client qui recrute dans plusieurs pays :**

1. **Huit codes du travail différents.** Période d'essai, préavis, indemnité de licenciement,
   forme du contrat : rien n'est garanti identique d'un pays à l'autre. Ce qui est vrai à Abidjan
   ne se transpose pas à Dakar sans vérification.
2. **Une fiche de poste, une offre ou une promesse d'embauche se refont par pays**, elles ne se
   traduisent pas.
3. **En revanche, le droit des affaires est harmonisé** (sociétés, sûretés, procédures
   collectives). Confondre les deux est l'erreur classique : « on est en zone OHADA donc c'est
   pareil » est vrai pour la société, faux pour le salarié.

---

## 2 · Mais les personnes circulent — le cadre CEDEAO

**Protocole A/P1/5/79 du 29 mai 1979** (Dakar) sur la libre circulation des personnes, le droit de
résidence et le droit d'établissement, décidé par les chefs d'État de la CEDEAO. Mise en œuvre
prévue en **trois étapes de cinq ans** : droit d'entrée et suppression du visa (1980-1985), droit
de résidence (1985-1990), droit d'établissement (1990-1995). Le protocole garantit **l'entrée sans
visa pour un séjour n'excédant pas 90 jours**, sur présentation de documents de voyage valides.
Protocoles additionnels : A/SP1/7/85 du 6 juillet 1985 (code de conduite d'application) et
A/SP.1/7/86 du 1ᵉʳ juillet 1986 (mise en œuvre de la deuxième étape, droit de résidence).

⚠️ **Le texte du protocole n'a pas pu être ouvert** : le site qui l'héberge refuse la connexion
depuis cette machine. Ce qui précède vient de sources concordantes de seconde main. **La procédure
exacte de titre de séjour et de droit au travail se vérifie auprès de l'employeur ou d'un conseil
avant d'engager un candidat étranger** — ne jamais promettre à quelqu'un qu'il « peut travailler
sans formalité » sur la foi de cette note.

**Ce qui est utile en pratique** : un candidat ressortissant d'un pays CEDEAO n'est pas dans la
même situation qu'un candidat hors zone. C'est une question à poser tôt en entretien, parce
qu'elle conditionne la date de prise de poste — au même titre que le préavis.

---

## 3 · Les salaires minimums comparés

| Pays | SMIG | Dernière revalorisation | Texte cité |
|---|---|---|---|
| **Côte d'Ivoire** | **75 000 FCFA** | 1ᵉʳ janvier 2023 | ⚠️ voir note |
| Sénégal | 64 223 FCFA | 2023 | art. L.137 du Code du travail |
| Togo | 52 500 FCFA | 1ᵉʳ janvier 2023 | convention collective amendée |
| Bénin | 52 000 FCFA | 1ᵉʳ janvier 2023 | décret du 7 décembre 2022 |
| Burkina Faso | 45 000 FCFA | 20 novembre 2023 | décret du 20 novembre 2023 |
| Niger | 42 000 FCFA | incertaine | art. 165 du Code du travail |
| Mali | 40 000 FCFA | 2016 | art. L.102 du Code du travail |

_Source : AfricaPaieRH, page mise à jour au 7 août 2026, lue le 13/08/2026 —
<https://africapaierh.com/juridique/le-smig-en-afrique-de-louest/>. Guinée-Bissau absente de ce
tableau._

🔴 **À manier avec précaution, et voici précisément pourquoi :**

- **Aucun de ces décrets nationaux n'a été ouvert.** C'est une source secondaire spécialisée, pas
  un recueil officiel.
- **Les sources se contredisent entre elles.** Sur le Bénin : 52 000 ici, 55 000 ailleurs. Sur le
  Sénégal : 64 223 ici, 60 000 ailleurs. Sur la Côte d'Ivoire, ce tableau cite un décret de 2013
  amendé, alors que le texte que j'ai identifié pour le relèvement à 75 000 FCFA est le
  **décret n° 2022-986 du 21 décembre 2022**. Le montant concorde, pas le fondement.
- **Deux pays ont des données visiblement anciennes** — Mali (2016) et Niger — la page le signale
  elle-même.

**Règle** : ce tableau sert à donner un ordre de grandeur et à situer un marché. **Il ne sert pas à
fixer une rémunération.** Pour un recrutement réel dans un de ces pays, on ouvre le décret national
avant d'écrire un chiffre.

**Ce que ces montants disent, et ne disent pas.** La Côte d'Ivoire a le SMIG le plus élevé de la
zone — presque le double du Mali. C'est un argument d'attractivité réel sur les emplois d'exécution.
Cela ne dit **rien** des salaires de cadres et d'ingénieurs, qui se forment sur un marché
international et non sur le minimum légal. Ne jamais extrapoler un écart de SMIG en écart de
rémunération cadre.

---

## 4 · Ce qui reste à instruire

1. **Ouvrir les codes du travail de la zone**, au moins Sénégal et Burkina Faso — les deux marchés
   les plus proches en volume de profils qualifiés. Période d'essai, préavis, forme du contrat.
2. **Le texte du protocole CEDEAO** et surtout la procédure ivoirienne d'emploi d'un étranger :
   permis de travail, visa de long séjour, contrat d'expatrié. C'est la situation réelle du dossier
   de direction technique en cours, dont le candidat le plus avancé vit en France — **hors CEDEAO**,
   donc hors du régime décrit ci-dessus.
3. **La convention multilatérale de sécurité sociale** de la zone (portabilité des droits à
   retraite d'un pays à l'autre) : non instruite. Elle compte pour un cadre qui a cotisé ailleurs.

## Provenance

Compétence écrite le 13/08/2026. Prolonge `droit-du-travail-ci`, qui porte le socle ivoirien —
lui, lu dans les textes.
