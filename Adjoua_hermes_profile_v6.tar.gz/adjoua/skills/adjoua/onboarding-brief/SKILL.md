---
id: Y0203
name: onboarding-brief
description: "Handoff sales → CSM/fondateur quand un lead passe en closed_won dans le pipeline commercial d'un client : reconstitue l'historique de vente depuis la ligne du pipeline, charge le contexte commercial et le pricing agréé, et génère un doc de transition en Markdown 1 page (le client, le deal, pourquoi il a signé, les risques, le plan des 30 premiers jours), sans jamais inventer un pricing ou un champ manquant."
bucket: C
tags: [Sales]
version: 1
maj: 2026-08-26
---

# Onboarding Brief

## Ce qu'il faut avoir sous la main
1. Le **client/l'entreprise** concerné(e) (pour résoudre sa config commerciale et son pipeline) ;
2. La **ligne complète du pipeline** pour ce lead (toutes les colonnes disponibles) ;
3. *(optionnel)* des **notes de closing** ajoutées après la signature.

## Process
Depuis la ligne du pipeline, reconstruire :
- Identification : nom, titre, boîte, contacts (email/LinkedIn/WhatsApp)
- Touchpoints : J0 envoyé quand, J3, J7, meeting booké quand, replies
- Signal d'achat initial qui a déclenché le sourcing
- Reply qui a confirmé l'intérêt
- Meeting `[connecteur à brancher : Calendly (ou équivalent), récupération du meeting booké, si disponible]`

### Étape 2 : Charger contexte client + pricing agréé

Lire `[datasource à brancher : config commerciale du client (onglet « Startups_Config » du pipeline), value prop initialement vendue, Calendly utilisé, cas client référence]`.

Demander à l'utilisateur (opérateur ou fondateur du client) si pas déjà dans `outcome_notes` :
- **Pricing agréé** : montant + tier + cadence
- **Clauses spéciales** : engagement durée, conditions de sortie, SLAs
- **Périmètre** : modules inclus, exclusions
- **Date de démarrage prévue**
- **Persona day-1** : qui sera le contact ops côté client ?

### Étape 3 : Générer le handoff doc

Format : Markdown structuré, 1 page max.

```markdown
# Handoff sales → CS · {Boîte} ({Client})

**Date de closing** : {meeting_booked_date}
**Sales owner** : {opérateur / pipeline commercial automatisé}
**Statut** : 🟢 closed_won, démarrage prévu {date_démarrage}

---

### Étape 4 : Actions dérivées

Proposer à l'orchestrateur :
- ✅ Créer une page « Client {boîte} » via `[connecteur à brancher : écriture dans une base de connaissances structurée (type Notion), création de page, sous le sous-espace du client résolu par le Registry]`
- ✅ Créer un canal d'équipe `#client-{slug}` via `[connecteur à brancher : messagerie d'équipe (type Slack), optionnel, si le client en dispose]`
- ✅ Programmer le kickoff call via `[connecteur à brancher : Calendly (ou équivalent) du fondateur/CSM]`
- ✅ Préparer l'email de bienvenue (template par client) via `[connecteur à brancher : envoi d'email, génère un brouillon uniquement, jamais un envoi direct ; soumis à validation humaine avant expédition effective]`

### Étape 5 : Rapport

```json
{
  "client": "le fonds",
  "boite": "FoodCorp CI",
  "handoff_doc_md": "<full markdown>",
  "missing_info": ["pricing_agréé", "contact_ops_email"],
  "suggested_actions": ["create_page_client", "create_team_channel", "schedule_kickoff"]
}
```

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Ne JAMAIS inventer un pricing** : si pas dans `outcome_notes` ou en input, demander à l'opérateur/fondateur du client.
- **Pré-remplir intelligemment** : ce qui est dans la ligne du pipeline doit auto-peupler le doc.
- **Marquer les blancs** : tout champ inconnu = « À CONFIRMER » en majuscules (pas de placeholder muet).
- **Ton** : pro, opérationnel, factuel. Pas de « Félicitations pour ce closing 🎉 », c'est un doc de travail.
- **Confidentialité** : un handoff peut contenir des clauses sensibles (pricing, conditions de sortie) → applique un tag de confidentialité minimum (type « accès restreint ») sur la page/le document créé, selon le système de tags du déploiement.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Connecteurs & datasources requis
- **Registre central des clients**, pour résoudre, par client, son sous-espace de connaissance, sa config commerciale, et le lien vers son pipeline commercial.
- **Pipeline commercial du client** (ligne du lead `closed_won`, `lead_row`), source de l'historique de vente à reconstituer (Étape 1).
- **Config commerciale du client** (onglet « Startups_Config » ou équivalent), value prop vendue, Calendly utilisé, cas client référence (Étape 2).

### Connecteurs requis

- **Calendly (ou équivalent)**, récupération du meeting booké (Étape 1) et programmation du kickoff call (Étape 4).
- **Base de connaissances structurée (type Notion)**, création de la page « Client {boîte} » sous le sous-espace résolu par le Registry (Étape 4).
- **Messagerie d'équipe (type Slack)**, création optionnelle du canal `#client-{slug}` (Étape 4).
- **Envoi d'email**, brouillon de l'email de bienvenue, jamais d'envoi automatique (Étape 4).

## Détails complémentaires
### Résolution des ressources : Registry

Pour retrouver la config commerciale du client (Étape 2) et créer sa page de suivi (Étape 4), résous les ressources via `[datasource à brancher : registre central des clients, répertorie, pour chaque client, son sous-espace de connaissance (où créer la page « Client »), sa config commerciale (value prop vendue, Calendly, cas client référence), et le lien vers son pipeline commercial]`.

**Règle de création** : crée toujours la page de suivi client **sous le sous-espace du client** résolu via le registre, jamais en standalone, jamais ailleurs. Si ce sous-espace est absent du registre, demande à l'utilisateur où créer la page avant de continuer.

### Input

L'orchestrateur (ou l'utilisateur) te passe :

- **client** : nom (clé de résolution dans le registre / la config commerciale)
- **lead_row** : la ligne complète du pipeline commercial pour ce lead (toutes colonnes)
- **outcome_notes** : *(optionnel)* notes ajoutées par l'équipe commerciale après le closing

Déclencheur type : dans le pipeline commercial, un lead qui bascule en `closed_won` voit son identifiant de handoff CS écrit dans une colonne dédiée du pipeline, c'est ce moment qui invoque cette skill.

### 🎯 Le client

- **Boîte** : {boîte}, {secteur}, {pays}
- **Taille** : ~{taille} employés
- **Décideur principal** : {nom_lead} ({titre})
- **Contact ops day-1** : {nom_contact_ops}, {email_ops} ({rôle}) ← À CONFIRMER
- **Canal préféré** : {LinkedIn / Email / WhatsApp / les 3}

### 💼 Le deal

| Champ | Valeur |
|---|---|
| Tier | {tier} |
| Pricing | {pricing_agréé} |
| Modules inclus | {liste} |
| Exclusions | {liste} |
| Engagement | {durée} |
| Cadence facturation | {mensuelle/trimestrielle/annuelle} |
| SLA contractuel | {réponse 4h ouvrées / 99% uptime / etc.} |

### 🔥 Pourquoi ils ont signé (use case central)

{2-3 phrases : le pain point qui a fait tilt, basé sur signal_achat + replies}

### 🛠️ Setup technique attendu

- {Liste des intégrations à prévoir}
- {Données à collecter du client avant kickoff}
- {Pré-requis side client}

### ⚠️ Risques / points de vigilance

- {Si le client a hésité sur X → on lui doit Y}
- {Si une promesse spécifique a été faite → la tracker}
- {Si le décideur n'est pas l'utilisateur day-1 → risque adoption}

### 📅 Premiers 30 jours : plan d'action

| Jour | Action | Owner |
|---|---|---|
| J+1 | Email de bienvenue + kickoff call programmé | CSM |
| J+3 | Kickoff call (1h) | CSM + fondateur/référent client |
| J+7 | Setup technique terminé | Équipe tech client |
| J+14 | Premier check d'adoption + résolution blockers | CSM |
| J+30 | Bilan + plan de scale-up | CSM + opérateur |

### 🔗 Refs

- LinkedIn lead : {linkedin_url}
- Email thread : {email_message_id si dispo}
- Page de suivi client : (à créer)
- Canal d'équipe : (à créer #client-{slug})
```
