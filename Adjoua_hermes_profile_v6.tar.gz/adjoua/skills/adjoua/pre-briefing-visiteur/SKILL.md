---
id: Y0481
name: pre-briefing-visiteur
description: >
  Complète la fiche d'un visiteur de la Clinique IA avant qu'il arrive devant la borne, quand
  il n'a rempli qu'une partie du formulaire du QR code. Va chercher dans ce qu'il a écrit en
  clair, dans son audio et dans ses images d'abord ; puis en ligne — le site de l'entreprise,
  la page LinkedIn, la page Facebook — pour que l'Expert sache à qui il parle avant la première
  phrase. Marque tout ce qui est déduit comme déduit, et s'arrête à un plafond de recherche.
bucket: A
tags: [Salon, Borne, Accueil, Recherche, Horizontal]
version: 1
maj: 2026-09-09
---

# Arriver en sachant déjà à qui on parle, sans rien inventer pour y arriver

## Process

**1 · Épuiser ce qu'il a déjà donné, avant toute recherche.**
C'est l'étape que l'on saute et c'est la plus rentable. Le script ne lit que les lignes
`Clé : valeur`, il ne comprend pas les phrases. La moitié du temps, l'entreprise, le secteur
et le besoin sont écrits en clair juste à côté, dans le texte libre ou dans l'audio.

- **Le texte libre.** « Je vends des pantalons tissus, mon entreprise s'appelle COMPLET et
  situé aux deux plateaux » remplit trois champs à lui seul. C'est déclaré, donc ça s'écrit
  sans réserve.
- **L'audio.** Il est déjà transcrit dans la sortie. Relis-le : on y trouve souvent le besoin
  réel, qui n'est jamais dans le formulaire.
- **Les images.** Ouvre-les toi-même : le script en donne le chemin et ne sait pas ce
  qu'elles montrent. Un logo donne le nom exact et souvent la baseline ; une capture d'écran
  donne le compte Instagram, le site, parfois le chiffre d'affaires ; une carte de visite
  donne tout.

⛔ **Une image se lit UNE fois.** Tu écris en une ligne ce qu'elle montre, et tu ne la rouvres
plus de la journée. Une image pèse dans la session autant qu'un long rapport et elle y reste :
c'est ce qui a fait passer une borne à 340 Mo d'historique le 09/09, et ralenti chacune de ses
réponses. Si tu as besoin de l'image plus tard, relis ta ligne, pas le fichier.

**2 · Chercher en ligne, dans cet ordre, et pas au-delà.**
Le nom de l'entreprise suffit à lancer une recherche. L'ordre compte, parce qu'il va du plus
sûr au plus douteux :

| Ce que je cherche | Ce qui vaut preuve | Ce qui ne vaut rien |
|---|---|---|
| Le site officiel | Le nom exact et la ville concordent | Un site au nom voisin, dans un autre pays |
| La page LinkedIn | La ville, le secteur et le dirigeant concordent | Une page homonyme sans localisation |
| La page Facebook | Souvent le seul « site » réel en Côte d'Ivoire | Un groupe, une page de fan |

⚠ Beaucoup de petites entreprises ivoiriennes n'ont pas de site, et c'est normal. Leur
présence réelle est une page Facebook ou un compte WhatsApp Business. Écrire « pas de site
web » n'est pas un manque à combler, c'est un fait à noter, et pour l'Expert Marketing c'est
souvent le sujet de la conversation.

**3 · Faire le benchmark, avant de proposer quoi que ce soit.**
Règle de la direction, 09/09 : on ne répond jamais à froid. Le secteur du visiteur commande une
comparaison, et c'est la comparaison qui nourrit la cible, le persona, le design, l'offre.

Trois comparables au maximum, choisis dans cet ordre :

| Rang | Qui | Pourquoi lui |
|---|---|---|
| 1 | Un concurrent **local** direct, même ville si possible | C'est à lui que le visiteur se compare vraiment |
| 2 | Un acteur **ivoirien ou régional** qui réussit dans le même métier | Il prouve que ça marche ici, avec les mêmes contraintes |
| 3 | Une **référence connue**, seulement si elle éclaire | Elle donne le vocabulaire et le niveau d'exigence |

⚠ Le rang 1 vaut plus que le rang 3. Pour un vendeur de pantalons aux Deux Plateaux, ce que
fait une grande maison européenne n'est pas transposable : ni le canal, ni le panier, ni le
mode de paiement. Un benchmark hors sol se voit tout de suite et décrédibilise le reste.

**Commence par le corpus déjà là.** ADJOUA, KOUASSI, KOFFI et FATIMA portent un référentiel
local dans `memory/reference/`, avec la compétence `referentiel-local` : 132 publications de
grandes marques ivoiriennes, le canal réel de la vente, des captures d'applications locales.
C'est gratuit, c'est déjà vérifié, et ça ne consomme pas le plafond de recherche. Ce corpus
porte aussi un fait utile : les grandes marques ivoiriennes ont très peu d'interaction sur
leurs publications, ce qui relativise l'idée de les imiter.

Pour chaque comparable, tu notes seulement trois choses : ce qu'il vend et à qui, par quel
canal il vend, et ce qu'il fait que le visiteur ne fait pas. Rien d'autre.

⛔ **Ce que tu dis d'un comparable vient d'une page que tu as ouverte**, pas de ce que tu crois
savoir. Un chiffre de mémoire sur une entreprise connue est une invention comme une autre, et
c'est celle qui passe le plus facilement.

**4 · Trancher l'homonymie plutôt que la subir.**
Deux entreprises portent le même nom : tu ne choisis pas la plus grosse, ni la première du
moteur. Tu retiens celle dont la ville, le secteur ou le dirigeant concordent avec ce que le
visiteur a écrit. Si rien ne départage, tu écris les deux et tu laisses l'Expert poser la
question en dix secondes.

**5 · Écrire la fiche, avec les niveaux de certitude visibles.**
Trois marques, et une seule par ligne :

- rien : le visiteur l'a déclaré lui-même. C'est le seul niveau sans réserve.
- `déduit, à confirmer` : tu l'as trouvé en ligne et la concordance est bonne.
- `⟦introuvable⟧` : tu as cherché et tu n'as rien trouvé de fiable. C'est un résultat.

**6 · S'arrêter.**
Le plafond est de **cinq recherches** et **six pages ouvertes** par visiteur, benchmark
compris. Au-delà, tu
livres ce que tu as. Un visiteur parfaitement documenté qui arrive après son passage à la borne
n'a servi à personne, et pendant ce temps trois autres attendaient.

## Format de sortie

```
<Entreprise>  ·  <Nom du visiteur>  ·  <ville si connue>
Borne : <Expert>            Arrivé : <heure>

Ce qu'il fait      <une ligne, ses mots à lui quand il les a donnés>
Ce qu'il demande   <une ligne — le besoin réel, souvent dans l'audio, pas dans le formulaire>
En ligne           site : … · LinkedIn : … · Facebook : …   (déduit, à confirmer)
Ce qu'il a envoyé  <logo / capture / document, et ce qu'on y voit>

Benchmark          1. <local>      : vend … à … , par … , et fait … qu'il ne fait pas
                   2. <ivoirien>   : …
                   3. <référence>  : …
Ce que j'en tire   <une ligne : ce que le benchmark change pour LUI, concrètement>

À vérifier en premier : <la seule question qui change le livrable>
```

La dernière ligne est la plus utile de la fiche. Elle nomme **la** question dont la réponse
change ce que l'Expert va produire. Pas trois questions, une.

## Règles

1. **Déclaré et déduit ne se mélangent jamais sur la même ligne.** Un pré-briefing dont on ne
   sait plus ce qui vient du visiteur et ce qui vient de toi est plus dangereux qu'une fiche
   vide : l'Expert le récite avec assurance devant la personne.
2. **Une case vide coûte moins cher qu'une case fausse.** Briefer sur la mauvaise entreprise se
   voit en dix secondes et détruit la démonstration. Dans le doute, `⟦introuvable⟧`.
3. **Ce qui est écrit dans le formulaire prime sur ce que tu trouves en ligne.** Si le visiteur
   dit « secteur : agroalimentaire » et que le site dit « logistique », tu gardes le sien et tu
   signales l'écart : c'est peut-être une activité nouvelle, et donc le sujet.
4. **Cinq recherches, six pages, puis on livre.** Le plafond est un engagement de temps, pas
   une suggestion.
5. Les pages bloquées aux robots passent par `integrations/apify/extraire.py`, avec
   `--accord`. Chaque page chargée consomme le compte de l'agence. Jamais un `curl`
   improvisé, jamais un moissonnage, jamais un mur de connexion franchi.
6. **Aucune donnée personnelle au-delà du professionnel.** Tu cherches une entreprise, pas une
   personne. Le domicile, la famille, la vie privée du visiteur ne rentrent pas dans la fiche,
   même trouvés en une recherche.
7. Tu n'écris pas au visiteur, ni pour vérifier, ni pour prévenir. La borne parle, pas toi.
8. **Le benchmark se montre, il ne se sous-entend pas.** L'Expert nomme les comparables qu'il
   a regardés et dit ce qu'il en tire. Une recommandation qui tombe sans son appui se reçoit
   comme un avis ; la même, adossée à trois acteurs nommés, se reçoit comme un conseil.
9. Le pré-briefing ne remplace pas la conversation : il fait gagner les trois premières
   minutes, il ne dit pas à l'Expert ce que la personne veut vraiment.

**Garde-fous durs**

- **0 invention.** Aucun chiffre d'affaires, effectif, ancienneté ou client inventé, même
  plausible, même « pour donner du contexte ».
- 0 confusion d'homonymes silencieuse. Deux candidats, tu écris les deux.
- 🔒 **Aucune action sortante.** Tu lis et tu écris une fiche. Aucun message, aucune connexion,
  aucune demande de contact.
- Produis, ne bloque pas. Formulaire quasi vide et rien en ligne : tu rends la fiche avec
  ce que tu as et la question à poser en premier. C'est déjà utile.

## Cas limites

- **Le visiteur n'a rempli que la première ligne** (« Clinique IA, Design ») tu as quand même
  son numéro et l'expert choisi. La fiche tient en deux lignes et la question à poser en
  premier devient « qu'est-ce qui vous amène ? ». Ne va pas chercher en ligne sur un nom que
  tu n'as pas.
- **Il a envoyé un logo et rien d'autre** ouvre-le : le nom y est presque toujours. C'est
  souvent suffisant pour retrouver la page Facebook et donc le secteur.
- **Le nom d'entreprise est un mot courant** (« COMPLET », « Le Bon Choix ») la recherche va
  rendre du bruit. Ajoute la ville et le secteur au nom, et si ça ne donne rien de net,
  `⟦introuvable⟧` : c'est le cas où deviner coûte le plus cher.
- **Deux entreprises du même nom** tu écris les deux, avec ce qui les distingue.
- **Le site trouvé est mort ou en construction** tu le notes tel quel. C'est une information
  pour l'Expert Design et pour l'Expert Marketing, pas un échec.
- **Le visiteur est déjà devant la borne** tu ne fais pas de recherche. Tu lis ce qu'il a
  envoyé et tu passes la main : la personne est là, elle répondra plus vite que le web.
- **Rien n'arrive dans la file alors qu'on scanne le QR** le message du visiteur doit porter
  « Clinique IA » pour entrer dans la file : c'est ce qui le distingue du courrier privé de la
  ligne. S'il a tout effacé avant d'envoyer, il n'apparaît pas : c'est voulu, et l'accueil
  humain reste la porte de secours.
- **Aucun comparable trouvé** (métier très étroit, ou nom trop vague) tu élargis d'un cran :
  le métier plutôt que le produit, la région plutôt que la ville. Si ça ne donne toujours rien,
  tu le dis en une ligne. Deux comparables honnêtes valent mieux que trois dont un inventé.
- **Deux visiteurs depuis le même numéro** (un téléphone prêté sur le stand) le second écrase
  le premier dans la fiche. Tu le signales à l'Expert au lieu de fusionner deux entreprises.
