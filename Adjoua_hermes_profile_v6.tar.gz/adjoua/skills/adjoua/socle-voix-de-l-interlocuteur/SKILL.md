---
id: Y0614
name: socle-voix-de-l-interlocuteur
description: >
  Écrire dans le ton de la personne servie, pas dans celui de l'IA. Recueille sa voix pendant
  l'onboarding — échantillons réels, tournures, ce qu'elle ne dit jamais — et la restitue dans
  tout texte qu'elle signera ou prononcera. À charger à l'onboarding, puis avant tout texte
  destiné à sortir sous son nom.
version: 1
maj: 2026-08-26
---

# La voix de l'interlocuteur

> **Demandé par Yelema, 26/08/2026 :** *« rajouter dans l'onboarding : voix de
> l'interlocuteur (écrire dans son ton). Sans elle, tout texte sort dans la voix de l'IA — le
> premier motif de réécriture par l'utilisateur. »*

C'est le diagnostic le plus juste du lot. Un texte factuellement parfait qui ne ressemble pas à
celui qui le signe **est réécrit intégralement**. Le travail est refait, et l'expert n'a fait
perdre du temps qu'à celui qu'il devait en faire gagner.

---

## 1 · Le recueil, à l'onboarding

⛔ **Ne pas déduire la voix de quelqu'un de son métier.** Deux directeurs financiers n'écrivent
pas pareil. La voix se recueille, elle ne se suppose pas.

**Demander trois échantillons réels** — c'est le cœur de l'exercice, et rien ne le remplace :

> *« Envoie-moi trois textes que tu as écrits toi-même et que tu trouves réussis : un message
> court, un texte plus long, et quelque chose que tu as dit à l'oral si tu en as la trace.
> Peu importe le sujet — c'est ta manière que je regarde, pas le fond. »*

**Puis six questions**, pas plus. Au-delà, on obtient des réponses de formulaire.

1. **Tutoiement ou vouvoiement**, et avec qui l'un plutôt que l'autre ?
2. **Le « je »** — assumé, ou plutôt « nous » / impersonnel ?
3. **Longueur** — trois lignes qui tranchent, ou le raisonnement déroulé ?
4. **Trois mots ou tournures que tu emploies souvent** ?
5. **Trois choses que tu ne dirais jamais** — un mot, une formule, un registre ?
6. **Le désaccord** : frontal, ou enveloppé ?

## 2 · Ce qu'on en extrait

Écrire la fiche dans `memory/reference/voix.md`, et la relire avant tout texte signé :

```markdown
# Voix de <prénom>

- Adresse : <tutoie l'équipe, vouvoie l'extérieur>
- Personne : <« je » assumé / « nous » d'équipe>
- Longueur : <phrases moyennes, paragraphes de 3 à 4 lignes>
- Registre : <direct, sans jargon / soutenu à l'écrit>
- Tournures récurrentes : « … », « … », « … »
- Proscrit : « … », « … », « … »
- Désaccord : <frontal, avec la raison énoncée>
- Ponctuation : <peu de points d'exclamation, jamais d'emoji en écrit pro>

## Échantillons
<les trois textes, collés tels quels — c'est l'étalon>
```

## 3 · La restitution

Avant de remettre un texte qui sortira sous son nom : **relire la fiche, puis relire le texte
en se demandant « est-ce qu'il dirait ça comme ça ? »**

Les quatre écarts les plus fréquents :

| L'écart | Le symptôme |
|---|---|
| **Le registre monte** | l'expert écrit plus soutenu que la personne. Un « il convient de » chez quelqu'un qui dit « il faut ». |
| **Le « je » disparaît** | quelqu'un qui assume ses décisions se retrouve derrière un « nous » ou une tournure passive. |
| **Le désaccord s'enveloppe** | quelqu'un de frontal reçoit un texte qui prend trois précautions avant de dire non. |
| **La longueur double** | trois lignes suffisaient. |

## 4 · Ce qui ne se copie pas

Écrire dans la voix de quelqu'un n'est pas parler à sa place.

- **Aucun engagement** — accord, promesse, chiffre, date — n'est pris dans un texte à son nom
  sans qu'il l'ait dit lui-même.
- **Les fautes ne se reproduisent pas.** Une tournure familière est une voix ; une faute
  d'accord est une faute.
- **Un texte écrit dans sa voix reste un projet**, présenté comme tel, jusqu'à ce qu'il le
  valide.

## 5 · L'entretien de la fiche

À chaque fois qu'un texte revient corrigé : **regarder ce qui a été changé au style**, et
l'inscrire. Trois corrections de même nature valent une ligne de plus dans la fiche. C'est ce
qui fait qu'au bout d'un mois, on ne réécrit plus.
