# Référentiel — fiche de poste

Ce fichier est le socle de qualité de la compétence `fiche-de-poste`. Il se lit **avant** d'écrire
une fiche, pas après. Il compte trois couches, par ordre d'importance décroissante.

---

## Couche 1 — Le corpus du client (la plus importante, la seule que personne d'autre n'a)

Une fiche de poste qui ignore les conventions de la maison se repère au premier coup d'œil par les
candidats du secteur. **Avant d'écrire, on lit ce que l'entreprise a déjà publié.**

### Ce qu'il faut réunir

| Élément | À quoi il sert |
|---|---|
| 3 à 5 fiches ou annonces déjà publiées par l'entreprise | Niveau de recrutement réel, vocabulaire maison, structure attendue |
| 2 à 3 annonces de concurrents directs sur des postes comparables | Positionnement : recrute-t-on au-dessus ou en dessous du marché local |
| Les conventions de candidature | Adresse, objet du courriel, pièces demandées, délais |
| Le contrat type de la maison | Période d'essai pratiquée, statut, primes |

### Ce qu'on en extrait, systématiquement

1. **Le niveau réel** : diplôme minimum, années d'expérience exigées. À comparer au concurrent —
   l'écart est une information de pilotage, pas un détail.
2. **Le vocabulaire** : les référentiels cités (TPM, 5S, HACCP, ISO…), les mots d'ordre du groupe
   (Ownership, Leadership…), la langue exigée. Les reprendre, ce n'est pas du remplissage : c'est
   ce que les candidats du secteur reconnaissent.
3. **La structure** : dans quel ordre la maison présente mission, responsabilités, profil, conditions.
4. **Les conventions de candidature**, à reprendre telles quelles.

### État du corpus

⟦**Non fourni à ce jour.**⟧ Demandé au client le 03/08/2026, sans réponse. Tant qu'il manque, toute
fiche produite est structurellement correcte mais **non située**, et cela doit être dit.

---

## Couche 2 — Le référentiel local : Côte d'Ivoire

### Non-discrimination — le socle légal, cité au mot

> **Article 4 du Code du travail** — « Sous réserve des dispositions expresses du présent Code ou de
> tout autre texte de nature législative ou règlementaire protégeant les femmes et les enfants,
> ainsi que des dispositions relatives à la condition des étrangers, **aucun employeur ne peut
> prendre en considération le sexe, l'âge, l'ascendance nationale, la race, la religion, l'opinion
> politique et religieuse, l'origine sociale, l'appartenance ou la non-appartenance à un syndicat et
> l'activité syndicale, la séropositivité ou VIH ou le Sida avérés, ou présumés, le handicap des
> travailleurs pour arrêter ses décisions en ce qui concerne, notamment, l'embauchage**, la conduite
> et la répartition du travail, la formation professionnelle, l'avancement, la promotion, la
> rémunération, l'octroi d'avantages sociaux, la discipline, ou la rupture du contrat de travail. »

_Source : loi n° 2015-532 du 20 juillet 2015 portant Code du travail, texte intégral téléchargé et
lu le 03/08/2026 — <https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf>_

**Ce que ça implique concrètement dans une fiche de poste.** Le sexe et l'âge sont nommément visés,
et l'embauchage est nommément visé. Une exigence de sexe ou d'âge dans une annonce n'est donc pas
une maladresse : c'est une violation de l'article 4, et l'article 18.15 du même Code qualifie
d'abusif tout licenciement pris en violation de l'article 4 — ce qui donne la mesure de la gravité
attachée à ce texte.

**La table de conversion à appliquer sans discuter :**

| Formulation interdite | Ce qu'elle cherche vraiment | Formulation qui tient |
|---|---|---|
| « Homme », « de préférence un homme » | Poste physique | Exigences physiques réelles écrites + aptitude médicale au poste |
| « Moins de 35 ans », « jeune » | Endurance, potentiel, coût | Aptitude médicale, années d'expérience, niveau de poste |
| « Bonne condition physique » | Tenue au poste | Charges manipulées, station debout, environnement, prononcé par la médecine du travail |
| « Totale disponibilité » | Travail posté ou astreinte | Régime horaire écrit noir sur blanc, astreinte chiffrée |
| « Célibataire », « sans enfants » | Disponibilité | Rien. Aucune reformulation ne rend cette exigence légitime. |
| « De nationalité ivoirienne » | — | Ne se justifie que par une disposition expresse sur la condition des étrangers, à vérifier |

### Contrat et période d'essai

- **Le CDI est la forme normale** de la relation de travail. Le CDD est réservé aux cas énumérés par
  la loi (surcroît temporaire, remplacement, travail saisonnier). ⟦à recouper article par article⟧
- **La durée maximale de la période d'essai est fixée par décret**, non par le Code lui-même
  (art. 14.5). ⚠️ Les durées de 6 mois pour les cadres, 3 mois pour agents de maîtrise et employés,
  1 mois pour ouvriers **circulent largement mais proviennent de résumés secondaires** — elles
  n'ont pas été vérifiées dans le décret d'application. **Ne pas les écrire dans un document sans
  les avoir confirmées.**
- La période d'essai doit figurer **par écrit** dans le contrat ou la lettre d'embauche (art. 14.5).
- Les **conventions collectives de branche** peuvent imposer une période d'essai et fixer les
  classifications. ⟦Convention applicable au client : à identifier⟧

### Ce qui manque encore à cette couche

⟦Convention collective interprofessionnelle et conventions de branche — à récupérer et à lire.⟧
⟦Grille SMIG et minima de branche en vigueur — à sourcer et à dater.⟧

---

## Couche 3 — Les standards internationaux

### Ce qui distingue une bonne fiche d'une fiche correcte

1. **Une raison d'être, pas une liste de tâches.** La fiche commence par ce que le poste produit et
   pourquoi il existe. Un candidat choisit un problème à résoudre, pas un intitulé.
2. **Des responsabilités écrites en résultats.** « Assurer le suivi » ne veut rien dire.
   « Garantir que 100 % des cycles de nettoyage sont tracés » se vérifie.
3. **Des résultats attendus datés.** Ce qu'on attend à 3, 6 et 12 mois, avec un indicateur par ligne.
   C'est ce qui permet à la grille d'évaluation d'exister, et à l'évaluation annuelle d'être juste.
4. **Le positionnement**, pas seulement le rattachement : qui sont les interfaces quotidiennes,
   quelle autonomie réelle, qui a un droit de veto. Un poste sans autorité réelle se repère et
   fait fuir les bons profils.
5. **Les conditions écrites** : régime horaire, site, transport, rémunération. Ce qui n'est pas écrit
   se découvre à l'offre et produit des désistements — invisibles dans les statistiques, ils
   apparaissent comme des « candidats qui ont refusé ».
6. **Une grille d'évaluation liée**, qui reprend les responsabilités dans le même ordre. Une fiche
   sans grille ne sert qu'à publier.

### Le test de relecture, en six questions

- Un candidat du métier reconnaît-il sa maison dans le vocabulaire employé ?
- Chaque exigence du profil est-elle vérifiable en entretien ou en test ?
- Une seule ligne du document est-elle discriminante au sens de l'article 4 ?
- Les conditions sont-elles toutes écrites, ou en manque-t-il une que le candidat découvrira ?
- La grille d'évaluation couvre-t-elle toutes les responsabilités annoncées ?
- Le document est-il diffusable **tel quel**, sans une seule note interne dedans ?

### Longueur

Une fiche de poste utile fait **trois à cinq pages**. En dessous de deux, elle n'est pas située :
elle pourrait servir à n'importe quelle entreprise du secteur, et c'est exactement le défaut à
éviter.

---

## Règle de forme — un livrable, un destinataire

⚠️ **Établie le 03/08/2026 après remarque du client.**

Un document destiné à être partagé **ne contient aucune note interne** : ni interrogation, ni
réserve sur les sources, ni « ce que je remonte au manager », ni annexe de benchmark, ni
commentaire de méthode.

Quand un travail produit les deux, il produit **deux fichiers** :

| Fichier | Contenu | Destinataire |
|---|---|---|
| `<slug>_vN.pdf` | La fiche seule, propre. Les champs non arbitrés restent des champs à compléter, sans commentaire autour. | Diffusable : candidat, site d'emploi, manager |
| `<slug>_vN_note-interne.pdf` | Les réserves, les sources, le benchmark, les questions ouvertes, les arbitrages à rendre | Le service recrutement seul |

La règle ne dispense jamais de signaler ce qui manque : elle déplace le signalement dans le bon
document.
