# Couche locale : Adjoua · Recrutement et talents

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-ADJOUA-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci/
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Socle commun, identique aux seize postes. Note à fabriquer : qui décide quoi. Pour elle, les interlocuteurs utiles sont le ministère de l'Emploi, la CNPS et l'Agence Emploi Jeunes. ✅ 17/09, balayage de la flotte : LA PIÈCE EXISTE DÉJÀ. memory/reference/gouvernement-2026.md chez LOKOLI donne la composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 » (1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués), relevée le 10/09 sur le portail officiel, avec la réserve : rouvrir la page avant de citer un ministre. À reprendre plutôt qu'à refaire. Et pour savoir quelle source fait foi quand deux divergent, watchlist-sources-ci.md chez BENKAN, YIRIWA et LOKOLI porte une hiérarchie de fiabilité (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, INS, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA). ⚠ Les trois versions diffèrent.

### CL-ADJOUA-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Socle commun. Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021. Utile ici pour une raison précise : 95,8 % des offres du corpus sont à Abidjan, donc un poste en région se décrit autrement. MISE À JOUR DU 18/09, ET CE JEU EST ANTÉRIEUR AU CHANGEMENT : le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026 (référence établie sur le recensement mensuel d'Ivoire-Juriste, cohérence vérifiée contre son récapitulatif de janvier). La presse ne l'a relevé que le 18/03. L'écart noté plus haut sur les districts est donc tranché : UN LIVRABLE ÉCRIT DEUX DISTRICTS AUTONOMES, JAMAIS DOUZE NI QUATORZE. L'écart sur les communes, 201 contre 197, reste ouvert. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-ADJOUA-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://fr.wikipedia.org/wiki/F%C3%AAtes_et_jours_f%C3%A9ri%C3%A9s_en_C%C3%B4te_d'Ivoire
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Socle commun, mais NUANCE DE MÉTIER : chez elle ce n'est pas du confort de planning, c'est du process. Les périodes d'essai, les préavis et les délais de déclaration se comptent en jours, et un férié déplace une date d'effet. Base légale : article 24.2 du Code du travail (loi 2015-532) et décret 96-205 du 07/03/1996 modifié par le 2011-371. Saisons : sodexam.com. ✅ La réponse précise existe déjà chez DJÉNÉBA (memory/reference/droit/JOURS-FERIES.md) : c'est l'ARTICLE 64 de la convention de 1977 qui liste les fériés chômés PAYÉS. Le 7 août et le 1er mai sont payés même un dimanche ; les autres (1er janvier, Korité, Tabaski, 1er novembre, Noël, Ascension, Assomption) ne le sont pas s'ils tombent un dimanche. Il faut avoir accompli la dernière journée avant et la première après le férié pour y avoir droit, l'absence autorisée conservant le droit. ARTICLE 65 pour les autres fériés : majoration de 100 % pour les payés à l'heure qui travaillent ce jour-là.

## Zone UEMOA

### CL-ADJOUA-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Socle commun. uemoa.int répond mais sa chaîne de certificat est incomplète, les scripts tombent et le navigateur passe. Utile ici pour la libre circulation CEDEAO et le recrutement régional, voir CL-ADJOUA-19.

### CL-ADJOUA-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Socle commun. Elle a déjà mieux que des ordres de grandeur généraux : son corpus donne le plancher médian annoncé (150 000 XOF, Q1 75 000, Q3 200 000) et la compétence simulation-salaire fait le net-brut. Aucun SMIG relevé ici, à faire sur source officielle. MISE À JOUR DU 18/09 : les chiffres de base sont désormais relevés sur bceao.int, huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. LE SMIG RESTE NON RELEVÉ, c'est un manque transverse distinct et il n'est pas comblé par cette mise à jour.

## Droit des affaires

### CL-ADJOUA-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/actes-uniformes/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Socle commun, et À DIRE FRANCHEMENT : l'OHADA ne sert presque à rien à une recruteuse. Le droit du travail ivoirien est NATIONAL, pas régional. L'OHADA n'entre ici que par la marge, pour la forme juridique de l'employeur. Sa vraie ligne juridique est CL-ADJOUA-14 et 15.

## Langue

### CL-ADJOUA-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Socle commun, déjà chez elle : compétence parler-ivoirien (Y0487), 122 mots nouchis. Nuance de métier : comprendre un candidat qui répond dans son registre, sans prendre une tournure correcte d'ici pour une faute de français.

## Canaux

### CL-ADJOUA-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : LinkedIn à 1,3 % interdit d'en faire le canal principal d'un sourcing grand public ici. Il reste pertinent sur les profils cadres et techniques, à dire comme tel.

## Marché du travail

### CL-ADJOUA-11 · Grilles de salaire observées par métier et par niveau
- **Pourquoi** : Un repère de rémunération inventé fait perdre un candidat ou coûte cher
- **Où chercher** : Agence Emploi Jeunes (l'AGEPE est dissoute depuis 2015), corpus marche-emploi-ci, conventions collectives de branche
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://rhmag.ci/
- **Pièce, ici** : references/pieces/1IMGQ6zF_0IHCAO-PsdDCMT3F7cxFZ6WX.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Guide des salaires Afrique de l'Ouest 2024-2025 (Grey Search Africa, 3e édition, avec le bureau Afrique de l'Ouest et centrale de HEC Paris) RÉCUPÉRÉ EN ENTIER, 79 pages, ~1 600 montants, grille par métier et par niveau pour la Côte d'Ivoire, le Sénégal et le Bénin, plus les secteurs qui recrutent le plus. Méthode déclarée : 5 000 répondants, 20 000+ profils référencés, 5 familles de métiers, 3 tailles d'entreprise, junior sous 5 ans. ⚠ GRATUIT, récupéré sur rhmag.ci qui l'héberge en accès libre : cas d'école de la règle du co-éditeur, le document cherché chez son auteur se trouve chez celui qui l'a relayé. ⛔ CE QU'IL MESURE : ce que le marché PAIE, par déclaration de candidats et de cabinets. PAS ce que les gens GAGNENT (revenus réels, informel compris : c'est l'EHCVM), PAS ce qui est DÛ (conventions collectives). Trois grandeurs distinctes, jamais dans le même tableau. ⚠ BIAIS DE CONSTITUTION : un guide de cabinet voit le marché qui passe par des cabinets, donc les postes qualifiés et formels d'Abidjan. Rien sur le reste du pays ni sur l'informel. ℹ À CROISER avec marche-emploi-ci.md (4 136 offres publiées par les employeurs eux-mêmes). || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || POINTEUR CORRIGÉ LE 17/09 : la colonne « où chercher » envoyait à l'AGEPE, DISSOUTE EN 2015 avec le Fonds national de la jeunesse au profit de l'Agence Emploi Jeunes. Chercher chez un organisme qui n'existe plus garantit de revenir les mains vides. CE QU'ELLE A DÉJÀ, ET QUI VAUT MIEUX QUE TOUTE GRILLE PUBLIÉE : memory/reference/marche-emploi-ci.md, 4 136 offres ivoiriennes réelles lues dans les blocs schema.org/JobPosting des employeurs. Le salaire n'est annoncé que dans 5,5 % des offres (229 sur 4 136) ; quand il l'est, plancher médian 150 000 XOF, Q1 75 000, Q3 200 000. Plus la compétence simulation-salaire (Y0232), net-brut et charges sur bulletins réels de décembre 2025, intégrant la réforme 2025. ÉCARTÉ : les grilles de salaires de cabinets et d'agrégateurs, contenus commerciaux sans méthode publiée, moins bons que son propre corpus.

### CL-ADJOUA-12 · Les écoles et filières qui forment ici, et leur réputation réelle
- **Pourquoi** : Lire un CV ivoirien sans connaître INP-HB, ESATIC ou l'UFHB, c'est lire à l'aveugle
- **Où chercher** : Sites des établissements, classements locaux
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://bac.mesrs-ci.net/offres/ets-prives
- **Pièce, ici** : references/pieces/1C2TXuRTfbM3p3O-LkrS6ZZ9SYUqb_UFNWS3z7oJCwe4.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET LA LISTE EST MAINTENANT CHIFFRÉE. Note neuve bases-locales/marche-travail-ci/DIPLOMES-ET-ETABLISSEMENTS.md, avec le relevé brut et son script de rafraîchissement. ⛔ LES DEUX NIVEAUX RESTENT À NE JAMAIS CONFONDRE, mais le premier est désormais outillé. CE QUI SE VÉRIFIE : le ministère de l'Enseignement supérieur publie son RÉPERTOIRE DES ÉTABLISSEMENTS AUTORISÉS sur bac.mesrs-ci.net, relevé le 22/09 : 145 UNIVERSITÉS PRIVÉES et 615 GRANDES ÉCOLES PRIVÉES, soit 760 établissements. CE QUI N'Y FIGURE PAS N'EST PAS RECONNU PAR L'ÉTAT, et la vérification est gratuite et immédiate. Chaque ligne porte la ville, la commune, la capacité, les frais d'inscription et les filières ; les frais sont renseignés pour 77 des 145 universités et 487 des 615 écoles, donc un établissement sans frais publiés n'est pas une anomalie. ⚠ LA GÉOGRAPHIE EST ÉCRASANTE : 111 des 145 universités et 430 des 615 écoles sont à Abidjan, soit 71 à 77 %, et COCODY SEULE en concentre 75 et 167. Un candidat formé hors d'Abidjan vient d'un vivier étroit, ce qui est un fait de géographie et pas un signal de qualité. Adresses publiques vérifiées : inphb.edu.ci (⚠ l'INP-HB A CHANGÉ DE DOMAINE, inphb.ci redirige), esatic.ci, univ-fhb.edu.ci. Le CAMES ajoute un second niveau de reconnaissance, régional, distinct de l'autorisation nationale. ⛔ CE QUI NE SE VÉRIFIE PAS, ET LA RÈGLE NE BOUGE PAS : il n'existe AUCUN CLASSEMENT IVOIRIEN AVEC MÉTHODE PUBLIÉE. Ce qui circule vient de sites d'orientation commerciaux, qui vivent de la mise en relation avec les écoles qu'ils classent. NE PAS LES CITER DANS UN LIVRABLE. La hiérarchie de prestige se recueille auprès des employeurs du secteur concerné, se date, et se présente comme une PERCEPTION, jamais comme une mesure. ⛔ RESTE DÛ : la liste des établissements PUBLICS, dont la page équivalente n'a rendu aucun tableau.

### CL-ADJOUA-13 · Les canaux où les candidats sont vraiment : groupes, pages, écoles
- **Pourquoi** : Publier une offre au mauvais endroit ne produit aucune candidature
- **Où chercher** : Relevé des groupes Facebook et WhatsApp d'emploi
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.educarriere.ci/
- **Pièce, ici** : references/pieces/1K7exMgkJSW7vEo9YY7ZOGrD5G4ifrSbwHkaOjWgysDk.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Note neuve bases-locales/marche-travail-ci/CANAUX-DE-RECRUTEMENT.md. LES PORTAILS ET LEURS PIÈGES D'ACCÈS : Agence Emploi Jeunes (public, GRATUIT, numéro court 98 197, six entrées dont Offres diaspora, 2 900 offres et plus le 22/09, agences régionales) ⚠ site en JavaScript qui NE REND RIEN À UN SCRIPT ; educarriere.ci ; emploi.ci qui répond mais FILTRE LES SCRIPTS EN 403 et s'ouvre au navigateur ; AGEFOP. ⚠ Deux de ces trois sites refusent un outil automatique : un relevé d'offres se fait au navigateur, et un script qui échoue là-dessus n'est pas cassé, il est filtré. LES COMPTES DE DIFFUSION AVEC LEUR AUDIENCE MESURÉE, relevé du 06/09 : Agence Emploi Jeunes 10 643 abonnés, Jeunes d'Avenirs 8 608, AGEFOP CI 499. ⛔ CE CHIFFRE RELATIVISE TOUT LE RESTE : le premier diffuseur institutionnel du pays plafonne à onze mille abonnés. Une offre qui compte sur la seule diffusion en ligne touche un public étroit, et l'emploi n'est pas un sujet à forte audience organique ici. ⛔ LA LIMITE STRUCTURELLE, ET ELLE NE SE CONTOURNE PAS : les groupes WhatsApp d'emploi sont fermés et non indexés. Ils concentrent une part réelle de la circulation des offres, et ON N'Y ENTRE PAS PAR UN OUTIL, on y entre par un humain ou pas du tout. Aucune estimation ne sera écrite là-dessus. CONSÉQUENCE POUR UN CLIENT : la diffusion d'une offre passe aussi par relais humain, et un plan de sourcing qui n'énumère que des portails est incomplet par construction. ⛔ NON COUVERT : la pénétration réelle de LinkedIn en Côte d'Ivoire, non mesurée ; le coût d'une publication sur les portails privés ; les cabinets de recrutement de la place.

### CL-ADJOUA-21 · Le stage, l'apprentissage et les dispositifs jeunes
- **Pourquoi** : Tout ce qui n'est pas un CDI est hors norme locale et doit être justifié dans l'annonce
- **Où chercher** : Agence Emploi Jeunes, AGEFOP
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.agenceemploijeunes.ci/site/
- **Pièce, ici** : references/pieces/1gaOXiPa3JcmjzLvOMXaADsjGnJMTg-rIb3mNYfYqu8g.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Note neuve bases-locales/marche-travail-ci/STAGES-ET-DISPOSITIFS.md, écrite sur le Code du travail et l'ordonnance 2021-902 que nous détenons. ⛔ QUATRE FORMES DISTINCTES, ET LES CONFONDRE DANS UNE ANNONCE EST UNE PROMESSE FAUSSE. (1) APPRENTISSAGE, art. 13.1 : écrit obligatoire RÉDIGÉ EN LANGUE FRANÇAISE, exempt de droits de timbre, attestation et examen à la fin. ⚠ L'ORDONNANCE 2021-902 A ABAISSÉ DE 21 À 18 ANS l'âge requis pour recevoir des apprentis mineurs (art. 13.3 nouveau) : le Code seul dit encore 21, ne pas le citer sans l'ordonnance. (2) STAGE-ÉCOLE, art. 13.11, pour valider un diplôme : ⛔ IL N'EST PAS RÉMUNÉRÉ, l'entreprise peut allouer une indemnité dont elle fixe librement le montant, et il prend fin sans indemnité ni préavis. (3) STAGE DE QUALIFICATION OU D'EXPÉRIENCE, art. 13.14, pour un DEMANDEUR D'EMPLOI et non un étudiant : DOUZE MOIS MAXIMUM renouvellements compris, le bénéficiaire n'est pas salarié MAIS L'ENTREPRISE EST TENUE DE LUI VERSER UNE INDEMNITÉ FORFAITAIRE, c'est la différence nette avec le stage-école, plus SIX MOIS DE PRIORITÉ D'EMBAUCHE et une attestation obligatoire. (4) CHANTIER-ÉCOLE, art. 13.21, dont les modalités sont renvoyées à un texte réglementaire non téléchargé. ⛔ LE PIÈGE LE PLUS COÛTEUX, VALABLE POUR LES DEUX STAGES : SANS ÉCRIT, LA CONVENTION EST RÉPUTÉE ÊTRE UN CDI. ⚠ Et TOUTE ENTREPRISE A L'OBLIGATION de recevoir des stagiaires, pour la validation d'un diplôme comme pour la qualification. À CONNAÎTRE EN NÉGOCIATION : la formation continue est un droit du travailleur ET une exigence possible de l'employeur, à la charge de ce dernier, salaire intégral maintenu (art. 13.23 et 13.24). DISPOSITIFS PUBLICS : Agence Emploi Jeunes, TOUS SERVICES GRATUITS, numéro court 98 197, six entrées dont OFFRES DIASPORA, 2 900 offres et plus affichées le 22/09, agences régionales. ⚠ Son site est en JavaScript et NE REND RIEN À UN SCRIPT, il a fallu l'option navigateur. ⛔ CE QUI RESTE DÛ : THIMO et FNER sont nommés sur la page d'accueil mais leurs sigles n'y sont pas développés, ne pas les expliquer à un client sans les avoir ouverts ; et les textes réglementaires d'application des trois formes de stage restent à récupérer.

### CL-ADJOUA-23 · Le recrutement dans le secteur public et parapublic
- **Pourquoi** : On n'entre pas dans un établissement public comme dans une entreprise
- **Où chercher** : Fonction publique, statuts des établissements publics
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Ses configurations de sourcing visent déjà l'ANSUT, l'ANSSI, l'ARTCI et l'AIGF : elle travaille sur cette cible sans en détenir les règles. À documenter : concours, statut, plafonds de rémunération, calendrier.

### CL-ADJOUA-25 · Où sont les femmes du vivier, et ce que ça change à un sourcing
- **Pourquoi** : Un sourcing qui ne sait pas où elles sont les manque sans le savoir
- **Où chercher** : ANStat, écoles, réseaux et collectifs professionnels
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Le sujet est déjà dans son travail, une de ses configurations de sourcing s'appelle abidjanaises-in-tech, mais sans référentiel derrière. À documenter avec des chiffres mesurés et non des intentions : part des femmes par filière et par niveau, réseaux et collectifs réels.

## Droit social

### CL-ADJOUA-14 · Code du travail ivoirien : essai, préavis, rupture
- **Pourquoi** : Une promesse d'embauche mal cadrée engage l'employeur
- **Où chercher** : Journal officiel, Code du travail
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base droit du travail sur disque : Code du travail loi 2015-532, ordonnance 2021-902 qui le modifie, convention interprofessionnelle de 1977, taux de cotisation CNPS, et JOURS-FERIES.md. ⛔ UNE DIVERGENCE À NE PAS LISSER, écrite dans le LISEZ-MOI : les deux textes ne donnent pas le même seuil de bascule des heures supplémentaires. ⚠ L'extraction texte de l'ordonnance 2021-902 est vide, c'est un document numérisé : on la cite depuis le PDF. || Trouvé à la source : loi 2015-532 du 20/07/2015 portant Code du travail, PDF sur un domaine gouvernemental, vérifié le 17/09. Ce qu'il encadre : période d'essai plafonnée à 6 mois pour les cadres, 3 mois pour les agents de maîtrise et employés, 1 mois pour les ouvriers, rupture pendant l'essai sans préavis ni indemnité ; préavis selon la catégorie et l'ancienneté, de 8 jours (ouvrier de moins d'un an) à 6 mois (cadre de plus de dix ans). ATTENTION : ces durées viennent de sources secondaires concordantes, PAS de ma lecture du texte. Le PDF est là, la pièce se fabrique en le lisant, une heure de travail.⛔ CORRECTION DU 17/09, APRÈS COUP : le Code du travail SEUL N'EST PAS À JOUR. L'ordonnance n° 2021-902 du 22/12/2021 modifie les articles 13.3, 16.6, 16.11, 18.11, 18.14, 23.1, 23.13, 25.2 et 73.2 (chômage technique, licenciement collectif, congé de maternité et de paternité). Les trois textes sont déjà sur le disque de DJÉNÉBA, en PDF et en texte extrait : memory/reference/droit/. ⚠ L'extraction texte de l'ordonnance est dégradée (scan) : pour citer un article modifié, ouvrir le PDF, pas le .txt. ⚠ DIVERGENCE SUR LE PRÉAVIS, signalée et non tranchée : l'échelle indiquée ci-dessus (8 jours à 6 mois) vient de sources secondaires. L'article 34 de la convention interprofessionnelle de 1977 dit autre chose pour les mensualisés des cinq premières catégories : 1 mois jusqu'à 6 ans d'ancienneté, 2 mois de 6 à 11, 3 mois de 11 à 16, 4 mois au-delà. Et l'article 18.4 du Code RENVOIE à la convention, donc c'est elle qui fixe la durée là où elle s'applique. ⚠ La ligne « catégorie 6 et au-delà » est illisible dans l'extraction : ne jamais citer de valeur pour un cadre sans avoir rouvert le PDF. ✅ 17/09, fait : les textes sont désormais en BASE COMMUNE, ~/.claude/outils-communs/droit-travail-ci/ (Code, ordonnance 2021-902, convention 1977, JOURS-FERIES.md, LISEZ-MOI qui cite article par article), et liés dans ce poste sous memory/reference/droit/. Un texte de loi n'appartient à aucun poste.

### CL-ADJOUA-15 · CNPS : affiliation, cotisations, déclaration d'un nouvel entrant
- **Pourquoi** : Un recrutement ne s'arrête pas à la signature
- **Où chercher** : CNPS
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Taux de cotisation CNPS sur disque. ⚠ La répartition de la vieillesse entre employeur (7,70 %) et salarié (6,30 %) NE FIGURE PAS dans le document de la CNPS : elle vient de sources secondaires concordantes, et se dit comme telle. || Trouvé, et LU DANS LE DOCUMENT DE LA CNPS lui-même, pas repris d'un tiers. Taux : prestations familiales 5 %, assurance maternité 0,75 %, accidents du travail et maladies professionnelles 2 à 5 % selon le secteur, assurance vieillesse 14 %. Les obligations de calendrier, qu'on oublie toujours : immatriculation dans les 48 HEURES suivant la première embauche ; cotisations payées mensuellement au-dessus de 20 salariés, trimestriellement en dessous, dans les 15 premiers jours suivant la période ; Déclaration individuelle des salaires annuels (DISA) au plus tard le 31 MARS de l'année suivante, avec la DASC signée sur papier. Guide employeur : cnps.ci/wp-content/uploads/2021/04/GUIDE-EMPLOYEUR.pdf. Démarches sur servicepublic.gouv.ci. RÉSERVE : le document date de 2020, actualité à confirmer avant d'en faire un chiffre opposable. ÉCARTÉ : les comparateurs annonçant 6,30 % salarié et 14,15 à 17,15 % employeur, ce sont des blogs et j'ai la source.

### CL-ADJOUA-19 · Le contrat de travail des étrangers et la main-d'oeuvre non nationale
- **Pourquoi** : La question tombe dès qu'un client a une filiale régionale
- **Où chercher** : Ministère de l'Emploi, textes CEDEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://loidici.biz/2018/08/23/arrete-n-4810-mefpps-agepe-du-21-avril-1997-portant-reglementation-du-recrutement-et-des-frais-detablissement-du-formulaire-de-visa-du-contrat-de-travail-des-personnels-non-ivoiriens/lois-article-par-article/codes/le-code-du-travail/1373/naty/
- **Pièce, ici** : references/pieces/1Ow9ilIK0CukP0d24Rgo5Cb4eIJ2I9x5S__eX02YNju8.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Arrêté n° 4810 MEFPPS/AGEPE du 21/04/1997, texte intégral sur disque. TROIS OBLIGATIONS, DANS CET ORDRE. (1) ART. 2 : tout poste doit être ANNONCÉ PENDANT DEUX MOIS auprès des organismes de placement agréés ; ce n'est QU'AU TERME de cette période, et si le poste n'est pas pourvu par un Ivoirien, que l'employeur peut recruter un non-national. ⚠ C'est la règle la plus oubliée et elle est CHRONOLOGIQUE : un recrutement d'expatrié décidé sans ces deux mois est irrégulier dès l'origine, il faut en garder la preuve. (2) ART. 1er : contrat ou lettre d'embauche VISÉ PAR LE MINISTRE chargé de l'Emploi, sur formulaire dédié, OBTENU AVANT L'ADMISSION sur le territoire. (3) CARTE DE TRAVAIL demandée dans les TROIS MOIS de l'embauche, renouvelable une fois par an, exigible à tout contrôle. FRAIS DE FORMULAIRE (art. 4), selon origine et catégorie, en FCFA : CEDEAO direction 100 000, cadre 80 000, agent de maîtrise 60 000, ouvrier qualifié 40 000, manœuvre 10 000 · AFRICAIN HORS CEDEAO 300 000 / 200 000 / 100 000 / 60 000 / 20 000 · NON AFRICAIN 750 000 / 500 000 / 300 000 / 100 000 / 40 000. ⚠ ÉCART DE 7,5 ENTRE UN DIRECTEUR CEDEAO ET UN DIRECTEUR NON AFRICAIN : c'est un argument de sourcing à dire au client qui hésite sur son vivier. ⛔ DEUX RÉSERVES AVANT DE CITER CES MONTANTS. (a) L'arrêté a VINGT-NEUF ANS et nous n'avons pas vérifié qu'il est toujours en vigueur à ce tarif ; une source secondaire mentionne un DÉCRET N° 6421 DU 15/06/2004 sur le même objet, non rapatrié. Un barème administratif de cet âge se reconfirme avant d'être servi. (b) L'art. 7 confie l'exécution au directeur de l'AGEPE, DISSOUTE EN 2015 : le texte nomme une administration qui n'existe plus, ce qui ne l'abroge pas mais montre qu'il n'a pas été toiletté. NE JAMAIS ÉCRIRE « AGEPE » DANS UN LIVRABLE ; l'interlocuteur est le ministère chargé de l'Emploi et l'Agence Emploi Jeunes. PAR-DESSUS, LE CODE DU TRAVAIL : art. 26.8, le contrat ne fait pas obstacle à la réglementation sur l'admission et le séjour des étrangers, les deux droits SE CUMULENT ; et le placement à l'étranger d'un travailleur ivoirien SANS VISA PRÉALABLE entraîne la RUPTURE du contrat à la charge de l'employeur. ⛔ NON COUVERT : le décret de 2004, le régime du séjour (visas, titres, durées), le traitement fiscal et social de l'expatrié (détachement contre expatriation, non double imposition), et les accords CEDEAO de libre circulation qui pourraient alléger ces formalités. || Ajout du 17/09, validé par l'équipe. À documenter : visa, autorisation de travail, contrat visé, et ce que la libre circulation CEDEAO change ou ne change pas. Recruter un non-Ivoirien ne se fait pas aux mêmes conditions.

### CL-ADJOUA-20 · Les conventions collectives sectorielles
- **Pourquoi** : Le Code fixe le plancher, la convention fixe le réel
- **Où chercher** : Ministère de l'Emploi, organisations patronales de branche
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1CW9Hw4MyQKtE2Bpp-9ONYdonvwfUZfqSs0cdqEpfbXI.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. ⛔ LA QUESTION ÉTAIT MAL POSÉE, ET C'EST LA TROUVAILLE : les conventions sectorielles n'existent PAS branche par branche. L'arrêté n° 1 MTIC, CAB, du 3 janvier 1978 rend la convention interprofessionnelle du 19/07/1977 OBLIGATOIRE pour tous les employeurs et travailleurs de DOUZE branches, y compris les non-signataires (art. 2) : industries et commerces de toute nature, mécanique générale, BÂTIMENT ET TRAVAUX PUBLICS, distribution de produits pétroliers, auxiliaires de transports, transports urbains et interurbains, transports routiers, secteur automobile, transports maritime aérien et lagunaire (sauf Marine marchande), BANQUES ASSURANCES CRÉDITS IMMOBILIER, HÔTELLERIE, électricité gaz eau service sanitaire. Dire « il n'y a pas de convention pour le BTP » est donc faux : il est couvert et l'employeur ne peut pas s'y soustraire. ✅ EN PLUS, deux textes de branche : Mines & Carrières 2023 (GPMCI/FISMECA, 12/05/2023, 81 pages, RÉCUPÉRÉE EN ENTIER, seule grille de branche complète que nous ayons : classification art. 62, catégories art. 69, barème art. 70) et la convention annexe « journaliers » (indemnité de précarité de 3 % du salaire horaire minimum de la catégorie au-delà de 3 mois). ⛔ CE QUI MANQUE : le TEXTE de la convention bancaire signée le 20/08/2025 entre l'APBEF-CI et le SYNABEFA-CI n'est pas publié, seule la presse en rend compte ; il se demande à l'APBEF-CI. D'ici là, pour une banque, on applique 1977 et on DIT qu'un texte plus récent existe sans l'avoir lu. Manquent aussi les grilles de branche autres que les mines : ce qui circule sur les sites d'emploi n'est pas une source conventionnelle. ⚠ OÙ L'ON A REGARDÉ : emploi.gouv.ci (403, y compris par navigateur, et ce n'est PAS un filtrage d'agent, ni code 1010 ni _cf_chl_opt), travail.gouv.ci (domaine inexistant), droit-afrique.com (403 de serveur mal configuré, « unable to read htaccess file »), droitci.info, loidici.biz (d'où vient l'arrêté de 1978), chambredesmines.org (d'où vient la convention minière), cgeci.com et la presse économique. || Ajout du 17/09. LE PLUS UTILE DES SEPT. Classifications, grilles, primes d'ancienneté, congés : un préavis ou un salaire discuté sans la convention de branche est discuté à côté. C'est ce qui manque pour que ses repères de rémunération soient opposables et pas seulement observés. ✅ TROUVÉE le 17/09 : Convention interprofessionnelle du 19/07/1977, déjà sur le disque de DJÉNÉBA (memory/reference/droit/, PDF + texte extrait, 1 809 lignes). Son article 34 porte les durées de préavis, son article 64 les fériés payés. ⚠ Conclue sous le Code de 1964 : articulation avec celui de 2015 à faire dire par un juriste. ✅ 17/09, fait : les textes sont désormais en BASE COMMUNE, ~/.claude/outils-communs/droit-travail-ci/ (Code, ordonnance 2021-902, convention 1977, JOURS-FERIES.md, LISEZ-MOI qui cite article par article), et liés dans ce poste sous memory/reference/droit/. Un texte de loi n'appartient à aucun poste.

### CL-ADJOUA-22 · L'impôt sur les traitements et salaires, après la réforme 2025
- **Pourquoi** : Un simulateur dont on ne peut pas produire le texte devient invérifiable dès qu'on le conteste
- **Où chercher** : Direction générale des impôts
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dgi.gouv.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Annexe fiscale à la loi de finances n° 2025-987 du 19/12/2025 (budget 2026), 148 pages, 41 mesures, sur disque avec couche texte. C'est là que se lit l'état de l'impôt sur les traitements et salaires après la réforme, et non dans un article de presse. || Ajout du 17/09. La compétence simulation-salaire porte déjà le calcul, avec la suppression de l'impôt sur salaire de 1,20 % côté salarié et la contribution nationale patronale fixe. Ce qui manque est la SOURCE OFFICIELLE DGI à côté du calcul. Une réforme fiscale se cite, elle ne se retient pas de mémoire.

## Entretien

### CL-ADJOUA-16 · Les questions qui ne se posent pas ici, et pourquoi
- **Pourquoi** : Une question anodine ailleurs peut être intrusive ou illégale ici
- **Où chercher** : Code du travail, usages relevés en entretien
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || LE PLUS INTÉRESSANT DES HUIT. Le Code du travail interdit de prendre en compte le sexe, l'âge, l'origine sociale, la race, la religion, l'opinion politique et religieuse, le handicap, l'appartenance ou non à un syndicat ; l'article 12 vise explicitement la discrimination fondée sur le sexe. ET L'ARTICLE 4 DE LA CONSTITUTION AJOUTE CE QUI EST PROPRE AU PAYS : ethnie, clan, tribu, région, différence culturelle ou linguistique, fortune, condition physique ou mentale. POURQUOI ÇA NE SE DÉDUIT D'AUCUNE FORMATION EUROPÉENNE : demander à quelqu'un d'où il vient, son village, sa région d'origine, est une question de conversation courante en Côte d'Ivoire, et elle touche trois critères protégés nommément. Un recruteur formé ailleurs pense à ne pas demander l'âge ; il ne pense pas à ça.⛔ CORRECTION DU 17/09, APRÈS COUP : le Code du travail SEUL N'EST PAS À JOUR. L'ordonnance n° 2021-902 du 22/12/2021 modifie les articles 13.3, 16.6, 16.11, 18.11, 18.14, 23.1, 23.13, 25.2 et 73.2 (chômage technique, licenciement collectif, congé de maternité et de paternité). Les trois textes sont déjà sur le disque de DJÉNÉBA, en PDF et en texte extrait : memory/reference/droit/. ⚠ L'extraction texte de l'ordonnance est dégradée (scan) : pour citer un article modifié, ouvrir le PDF, pas le .txt.

### CL-ADJOUA-24 · La vérification d'un diplôme et d'un antécédent
- **Pourquoi** : La reconnaissance d'un diplôme et l'authenticité d'un document sont deux gestes différents
- **Où chercher** : CAMES, établissements, ministère de l'Enseignement supérieur
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.servicepublic.gouv.ci/accueil/detaildemarcheparticulier/1/408/142
- **Pièce, ici** : references/pieces/1C2TXuRTfbM3p3O-LkrS6ZZ9SYUqb_UFNWS3z7oJCwe4.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, avec les guichets, les pièces et les tarifs. Même note : bases-locales/marche-travail-ci/DIPLOMES-ET-ETABLISSEMENTS.md, section 3. ⛔ LE POINT DE LA LIGNE EST CONFIRMÉ : vérifier qu'un établissement est reconnu et vérifier qu'un DOCUMENT est authentique sont deux gestes distincts, auprès de deux administrations différentes. AUTHENTIFICATION d'une licence, d'une maîtrise ou d'un DESS : DIRECTION DE L'ENSEIGNEMENT SUPÉRIEUR, Abidjan Plateau, immeuble Lamblin, rez-de-chaussée. 10 000 FCFA LA PREMIÈRE DEMANDE, 5 000 FCFA LES SUIVANTES. Pièces : baccalauréat, relevés de notes, diplômes intermédiaires et diplôme à authentifier, CHACUN EN ORIGINAL PLUS DEUX COPIES, photocopie de la pièce d'identité, CV, extrait de naissance, formulaire. Contacts : +225 27 20 32 21 13, 27 20 33 54 64, 27 20 21 06 79. ÉQUIVALENCE d'un diplôme étranger de niveau inférieur ou égal au bac : DECO, sous-direction de l'homologation et de l'authentification, service des équivalences, 1 000 FCFA, avec demande manuscrite, originaux et photocopies, autorisation de recherche, enveloppe timbrée et coupon-réponse. PRINCIPE QUI ORDONNE LES DEUX GESTES : l'authentification suppose que les études aient été faites dans un ÉTABLISSEMENT ACCRÉDITÉ, donc on consulte le répertoire du MESRS d'abord et on va au guichet ensuite. L'authenticité de l'homologation SE CONSTATE PAR L'APPOSITION DU SCEAU DU MINISTRE chargé de l'Enseignement supérieur sur le diplôme. ⚠ POINT PRATIQUE QUI CHANGE LE PROCESSUS DE RECRUTEMENT : c'est LE CANDIDAT qui détient les originaux, et la démarche exige aussi son CV et son extrait de naissance. UN EMPLOYEUR NE PEUT PAS LANCER SEUL UNE AUTHENTIFICATION : on la DEMANDE au candidat, on ne la fait pas à sa place. ⛔ LE DÉLAI DE TRAITEMENT N'EST PUBLIÉ NULLE PART, ni pour l'authentification ni pour l'équivalence : ne pas en promettre un à un client. ⚠ Des plateformes en ligne existent, eda.edemarches.gouv.ci et le portail DEXCO, mais leurs pages ne servent aucun contenu à un outil et leur périmètre reste à confirmer. ⛔ NON COUVERT : la vérification d'antécédents autre que le diplôme, casier judiciaire et emplois antérieurs.

## Références

### CL-ADJOUA-17 · Modèles d'offres d'emploi réellement publiées en Côte d'Ivoire
- **Pourquoi** : Copier une offre américaine donne une annonce que personne ne lit
- **Où chercher** : Corpus visuels-offres-ci déjà constitué
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || DÉJÀ CHEZ ELLE : memory/reference/visuels-offres-ci.md, 36 visuels réels relevés sur trois comptes ivoiriens de diffusion, avec _index.json qui donne pour chacun sa légende, sa date et son nombre de mentions. Le document va jusqu'au gabarit : l'Agence Emploi Jeunes publie sur un modèle rigoureusement identique d'une offre à l'autre, qui donne les quatre informations sur lesquelles le candidat décide, en un coup d'oeil et sans lire. Et le corpus de 4 136 offres dit le reste en texte : 99,9 % de CDI plein temps, 95,8 % à Abidjan, Bac+2 37,8 %, 2 à 5 ans d'expérience 40,4 %, description médiane 168 mots (au-delà de 250 on est hors format local).

### CL-ADJOUA-18 · Les employeurs les plus attractifs du moment, et sur quoi
- **Pourquoi** : Se comparer sans savoir à qui on se compare
- **Où chercher** : Enquêtes locales, presse économique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.glassdoor.fr/
- **Pièce, ici** : references/pieces/1-CzizrH_n_sQ9ppGYBH5Syz1WSI5WShaL7Uut_IGO4Q.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09 EN SOURCE D'APPOINT, validé par la direction, réserves comprises. RELEVÉ MESURÉ, entité par entité : Air Côte d'Ivoire 32 avis 3,4/5 · Compagnie Ivoirienne d'Électricité 27 avis 3,9/5 · Wave CI 26 avis 4,9/5 · MTN CI 13 avis · Nestlé filtre Abidjan 5 avis · SG Technologies CI 0 avis et 1 salaire · SODECI aucune fiche. Soit ~100 avis sur les cinq plus gros employeurs ivoiriens identifiables. ⛔ CE QUE LA PIÈCE NE COUVRE PAS, et la ligne reste donc partiellement ouverte : elle ne dit PAS quels employeurs sont les plus attractifs ni sur quoi. Cent avis ne classent pas un marché. Elle sert à lire UNE entreprise nommée avant un entretien, jamais à comparer. ⛔ LE PIÈGE PRINCIPAL : Glassdoor agrège au niveau du GROUPE. Orange affiche 4 240 avis mais il n'existe AUCUNE entité Orange Côte d'Ivoire ; Ecobank ~680 avis est pan-africain, prouvé par l'existence de pages distinctes Nigeria, Lagos et Port Harcourt. Lire ces notes comme un signal ivoirien, c'est le chiffre juste rapporté à la mauvaise base. ⚠ WAVE À 4,9/5 SUR 26 AVIS : ne pas s'en servir, une note pareille ne s'observe pas sur un employeur réel, avis vraisemblablement sollicités. ⚠ HOMONYME ÉCARTÉ : une fiche « Cie » à 39 avis existe, ce N'EST PAS la Compagnie Ivoirienne d'Électricité, qui a sa propre fiche à 27 avis. ⚠ NON RÉSOLU : le compte d'avis d'Ecobank apparaît à la fois comme 870 et comme 680 selon les pages ; citer la fourchette, pas un des deux nombres. ⛔ GLASSDOOR NE SE LIT PAS À LA MACHINE : page d'attente « Un instant… » en noindex à toute connexion automatisée, navigateur sans interface compris, SANS aucun marqueur Cloudflare (ni error code 1010, ni _cf_chl_opt, ni Ray ID) et sans signature Kasada, PerimeterX, DataDome, Imperva ou Akamai. Aucune veille automatisée possible, aucun contournement à chercher. Le relevé passe par ce que le moteur a indexé. ℹ À CROISER avec memory/reference/marche-emploi-ci.md, 4 136 offres publiées par les employeurs eux-mêmes, qui est la source principale. || LE POINT FAIBLE DES HUIT, et il faut le dire net : L'ENQUÊTE D'ATTRACTIVITÉ IVOIRIENNE N'EXISTE PAS. Aucune enquête locale avec méthode publiée. Ce que le web propose à la place est AUTRE CHOSE, et les confondre serait une erreur de fond : (1) des classements de taille ou de rentabilité, qui sont un fait économique et pas une préférence de candidat ; (2) des certifications payantes obtenues sur candidature de l'entreprise (Top Employers Institute, Great Place to Work), qui sont un label et pas un classement ; (3) des panoramas de cabinets de recrutement, contenu commercial. CE QU'ELLE A DE MIEUX : son fichier memory/reference/ancrages.md, fiches employeur de première main construites en lisant les sites, sources datées et réserves écrites (il y est noté par exemple qu'Orabank est inaccessible depuis cette machine, filtrage Cloudflare identifié le 08/09, et que rien ne doit en être publié tel quel). La pièce honnête est un relevé maison sur un échantillon nommé, qui dit sur quoi il repose.

## Droit et conventions

### CL-ADJOUA-26 · Conventions collectives sectorielles de Côte d'Ivoire
- **Pourquoi** : Les catégories et les minima ne sortent pas du Code du travail mais de la convention du secteur. Commerce et négoce et bâtiment n'ont ni les mêmes catégories ni les mêmes salaires catégoriels : une grille bâtie sans elle est fausse.
- **Où chercher** : Ministère de l'Emploi et de la Protection sociale, textes déposés ; organisations patronales de branche ; Journal officiel
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : ⛔ DOUBLON, ET IL EST INSTRUCTIF. Cette ligne a été ajoutée au point de formation du 22/09/2026, le jour même où la question était traitée sous CL-ADJOUA-20. La réponse est là-bas : les conventions sectorielles n'existent PAS branche par branche, l'arrêté n° 1 MTIC, CAB, du 3 janvier 1978 rend la convention interprofessionnelle de 1977 OBLIGATOIRE pour douze branches dont le commerce, le BTP, la banque-assurance et l'industrie, y compris pour les non-signataires. Les quatre branches demandées ici sont donc déjà couvertes. Seules les mines et carrières ont un texte propre (2023, récupéré) et les banques un texte de 2025 non publié. ⚠ CE QUE LE DOUBLON RÉVÈLE : deux sessions ont ouvert la même question le même jour sans se voir. Avant d'ajouter une ligne, relire l'onglet du poste. || Demandé au point de formation du 22/09/2026. Chercher en priorité commerce et négoce, bâtiment et travaux publics, banque et assurance, industrie.

### CL-ADJOUA-27 · Base de calcul des congés payés, calendaire et ouvré
- **Pourquoi** : Le taux d'acquisition diffère selon la base retenue, environ 2,5 jours par mois en calendaire contre 2,2 en ouvré. Annoncer un nombre sans dire la base fait croire à un avantage qui n'existe pas.
- **Où chercher** : Code du travail ivoirien, partie congés ; majorations prévues par chaque convention de branche
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET LA RÉPONSE ÉTAIT DÉJÀ SUR DISQUE. ⛔ LE CONGÉ SE COMPTE EN JOURS OUVRABLES, JAMAIS CALENDAIRES : le Code du travail ne connaît pas le jour calendaire pour le congé annuel, et écrire « calendaires » dans un contrat change le résultat de plusieurs jours par an. Loi 2015-532 art. 25.1 : 2,2 JOURS OUVRABLES PAR MOIS de service effectif, soit 26,4 jours pour douze mois. ⚠ « Sauf disposition plus favorable des conventions collectives ou du contrat » : c'est un PLANCHER, une branche peut donner plus, jamais moins. MAJORATIONS D'ANCIENNETÉ (art. 25.2) : +1 jour après 5 ans, +2 après 10, +3 après 15, +5 après 20, +7 après 25, +8 après 30. SITUATION DE FAMILLE (art. 25.2), pour la FEMME salariée ou apprentie seulement, bascule à 21 ans révolus au dernier jour de la période de référence : moins de 21 ans, 2 jours ouvrables par enfant à charge DÈS LE PREMIER ; plus de 21 ans, 2 jours par enfant À COMPTER DU QUATRIÈME. Plus 1 jour pour la médaille d'honneur du travail, et 2 semaines pour le travailleur logé astreint à 24 h de présence continue. NE SE DÉDUISENT PAS du congé acquis (art. 25.3) : accident du travail, maladie professionnelle, formation syndicale, repos de la femme en couches, et la maladie constatée par un médecin agréé DANS LA LIMITE DE SIX MOIS. ⚠ NE PAS CONFONDRE DURÉE ET INDEMNITÉ : l'indemnité vaut le douzième de la rémunération totale de la période de référence. Deux questions, deux articles. ⚠ LES CONGÉS POUR ÉVÉNEMENT FAMILIAL NE SONT PAS DU CONGÉ ANNUEL : la convention de 1977 en accorde jusqu'à 10 jours ouvrables par an, NON DÉDUCTIBLES du congé réglementaire (mariage 4 jours, décès du conjoint 5, décès d'un enfant ou d'un parent 5, frère ou soeur 2). Ils s'ajoutent, ils ne se retranchent pas. || Demandé au point de formation du 22/09/2026. Vérifier aussi les majorations pour ancienneté et situation de famille, qui varient d'une convention à l'autre.
