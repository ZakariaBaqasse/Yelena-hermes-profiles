# 260922_Stage, apprentissage et dispositifs jeunes en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 41 lignes non vides =====

# Stage, apprentissage et dispositifs jeunes en Côte d'Ivoire
Écrite le 22/09/2026 sur le Code du travail de 2015 et l'ordonnance 2021-902, tous deux dans droit-travail-ci/. Elle sert une annonce : un stage ou une alternance sortent de la norme du marché ivoirien, où le CDI plein temps représente 99,9 % des offres visibles dans notre corpus. Le candidat se demande donc ce qui se cache derrière, sauf si l'annonce nomme la forme exacte et ce qu'elle donne.

⛔ Quatre formes distinctes, qui n'ont ni la même durée, ni la même rémunération, ni les mêmes suites. Les confondre dans une annonce est une promesse fausse.
## 1. Le contrat d'apprentissage, art. 13.1 à 13.10
Un chef d'établissement industriel, commercial ou agricole, un artisan ou un façonnier s'oblige à donner une formation professionnelle méthodique et complète.

- Écrit obligatoire, rédigé en langue française, exempt de tous droits de timbre et d'enregistrement.
- ⚠ Âge du maître d'apprentissage : 18 ans au moins pour recevoir des apprentis mineurs. L'ordonnance 2021-902 a abaissé ce seuil de 21 à 18 ans (article 13.3 nouveau). Le Code seul dit encore 21 : ne pas le citer sans l'ordonnance.
- Le maître doit prévenir sans retard les parents, traiter l'apprenti en bon père de famille et lui enseigner progressivement.
- À la fin, une attestation, et l'apprenti passe un examen.
- Rompre pour conclure ailleurs expose à une indemnité au profit du maître abandonné.
## 2. Le contrat stage-école, art. 13.11 à 13.13
Un élève ou un étudiant reçoit une formation pratique en vue de la validation de son diplôme.

- ⛔ Écrit obligatoire. À défaut, la convention est réputée être un contrat de travail à durée indéterminée. C'est le piège le plus coûteux de cette section.
- ⛔ Il n'est pas rémunéré. L'entreprise peut allouer une indemnité dont elle fixe librement le montant. Une annonce qui parle de « stage rémunéré » sans chiffre ne dit rien.
- Il prend fin au terme convenu, sans indemnité ni préavis.
- ⚠ Toute entreprise a l'obligation de recevoir en stage des élèves ou étudiants pour la validation de leur diplôme.
## 3. Le stage de qualification ou d'expérience professionnelle, art. 13.14 à 13.20
Pour un demandeur d'emploi, pas pour un étudiant : acquérir une qualification ou une première expérience.

- Douze mois maximum, renouvellements compris.
- ⛔ Écrit obligatoire, à défaut c'est un CDI.
- Le bénéficiaire n'est pas un salarié, mais ⚠ l'entreprise est tenue de lui verser une indemnité forfaitaire. C'est la différence nette avec le stage-école.
- Il est soumis au règlement intérieur de l'entreprise.
- ✅ Six mois de priorité d'embauche sur un emploi correspondant à sa qualification, s'il y est reconnu apte.
- Attestation obligatoire au terme, indiquant la qualification, l'objet et la durée.
- ⚠ Toute entreprise a l'obligation d'en recevoir.
## 4. Le chantier-école, art. 13.21 et 13.22
Action collective de formation par la production. Modalités et statut des personnes renvoyés à un texte réglementaire, non téléchargé. ⟦à récupérer⟧
## La formation continue, art. 13.23 et 13.24
Utile à connaître dans une négociation d'embauche : le travailleur est en droit de bénéficier de la formation continue que nécessite son emploi ; l'employeur est en droit d'exiger qu'il suive ces formations ; le coût est à la charge de l'employeur, et le travailleur perçoit son salaire intégral pendant la formation.
## Les dispositifs publics
Agence Emploi Jeunes, agenceemploijeunes.ci. Relevé le 22/09/2026.

- ⚠ Le site ne rend rien à un script : il est construit en JavaScript et ne sert du texte qu'à un vrai navigateur. Le relevé a demandé l'option navigateur de integrations/web-public/telecharger.py.
- Tous les services sont gratuits, l'agence l'affiche en tête. Inscription sur le site. Numéro court : 98 197.
- Six entrées : Emploi direct · Stage · Formation · Entrepreneuriat · Programmes spéciaux · Offres diaspora.
- Deux dispositifs nommés sur la page d'accueil : THIMO, avec une liste de bénéficiaires 2025, et FNER. ⚠ Leur contenu exact n'a pas été relevé, et les sigles ne sont pas développés sur la page : ne pas les expliquer à un client sans les avoir ouverts. ⟦à faire⟧
- Volumétrie affichée le 22/09 : 2 900 offres d'emploi et plus et 6 600 opportunités. Des agences régionales servent de filtre, ce qui confirme une présence hors Abidjan.
## Ce que cette fiche ne couvre pas
- Les textes réglementaires d'application du stage-école, du stage de qualification et du chantier-école, tous renvoyés par le Code et non téléchargés.
- Le détail de THIMO et de FNER, et les autres dispositifs publics au-delà de l'Agence Emploi Jeunes.
- Les aides ou exonérations éventuellement attachées à l'embauche d'un jeune. ⟦à vérifier dans l'annexe fiscale, fiscalite-ci/⟧

À recontrôler le 22/03/2027.
