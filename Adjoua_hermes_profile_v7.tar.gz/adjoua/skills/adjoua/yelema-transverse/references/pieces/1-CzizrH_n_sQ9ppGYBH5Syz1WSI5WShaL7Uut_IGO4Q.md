# 260922_Avis employeurs CI, source d appoint

===== onglet t.0 · Tab 1 · 34 lignes non vides =====

# Les avis d'employés sur les entreprises ivoiriennes
Relevé du 22/09/2026, demandé par la direction. Source d'appoint, jamais une source principale.
## Ce que ça vaut, en une phrase
Environ cent avis couvrent les cinq plus gros employeurs ivoiriens identifiables sur Glassdoor. C'est assez pour lire ce qui se dit sur une entreprise nommée avant un entretien. Ce n'est pas assez pour comparer des employeurs entre eux, et ça ne le sera pas avant longtemps.
## Ce qui est vraiment ivoirien
Entités ayant leur propre fiche, ou un filtre pays qui isole la Côte d'Ivoire.

| Employeur | Avis | Note |
| Air Côte d'Ivoire | 32 | 3,4 / 5 |
| Compagnie Ivoirienne d'Électricité | 27 | 3,9 / 5 |
| Wave Côte d'Ivoire | 26 | 4,9 / 5 ⚠ |
| MTN Côte d'Ivoire | 13 | non relevée |
| Nestlé, filtre ville Abidjan | 5 | non relevée |
| Société Générale des Technologies de Côte d'Ivoire | 0 avis, 1 salaire | - |
| SODECI | aucune fiche trouvée | - |

⚠ Wave à 4,9 sur 5 : ne pas s'en servir. Une note pareille ne s'observe pas sur un employeur réel. Jeune entreprise, avis vraisemblablement sollicités auprès des salariés. Une note extrême sur un petit nombre d'avis dit quelque chose sur la collecte, pas sur l'employeur.
## ⛔ Le piège principal : Glassdoor agrège au niveau du GROUPE
Ces chiffres-là existent, et aucun ne concerne la Côte d'Ivoire :

| Groupe | Avis | Portée |
| Orange | 4 240 | mondial. Il n'existe pas d'entité Orange Côte d'Ivoire |
| Ecobank | ~680, 3,4 / 5 | pan-africain, une trentaine de pays |
| Bolloré Logistics | 383 | mondial |
| Africa Global Logistics | 14 | mondial |

Prendre le 3,4 d'Ecobank pour un signal sur Ecobank Côte d'Ivoire est le chiffre juste rapporté à la mauvaise base. La preuve que la filiale n'y est pas : Glassdoor sert des pages distinctes « Ecobank Reviews in Nigeria », « in Lagos », « in Port Harcourt ». Ce qui n'est pas filtré par pays est un agrégat dont la Côte d'Ivoire ne représente qu'une fraction inconnue.

ℹ Le nombre d'avis d'Ecobank est apparu à la fois comme 870 et comme 680 selon les pages. Cet écart n'est pas expliqué : citer la fourchette, pas un des deux nombres.
## ⛔ Ce qui se vérifie avant de citer un homonyme
Une fiche « Cie » portant 39 avis existe. Ce n'est pas la Compagnie Ivoirienne d'Électricité, qui a sa propre fiche à 27 avis sous son nom complet. Un nom court et générique n'identifie pas une entreprise : vérifier le nom entier et le pays avant de compter.
## Comment relever, et pourquoi c'est à la main
Glassdoor ne se lit pas à la machine. Il sert une page d'attente Un instant… en noindex à toute connexion automatisée, navigateur sans interface compris, et elle ne porte aucun marqueur Cloudflare connu. Aucun comptage systématique, aucune veille automatisée n'est possible dessus, et il n'y a pas de contournement à chercher.

Le relevé ci-dessus a été obtenu par ce que le moteur de recherche a indexé des pages Glassdoor. Pour refaire le relevé sur un employeur donné, chercher le nom complet de l'entreprise avec glassdoor en restreignant aux domaines glassdoor.com et glassdoor.fr, et lire le compte d'avis dans le titre de la page.
## Le geste, avant de citer ceci à un client ou à un candidat
- Vérifier que l'entité est bien ivoirienne, pas le groupe.
- Regarder combien d'avis portent la note. En dessous de dix, on ne cite pas de note.
- Écarter une note extrême sur un petit effectif.
- Dire que c'est une source d'appoint, déclarative et anonyme, et la croiser avec ce que disent les 4 136 offres de marche-emploi-ci.md, qui sont, elles, publiées par les employeurs eux-mêmes.
