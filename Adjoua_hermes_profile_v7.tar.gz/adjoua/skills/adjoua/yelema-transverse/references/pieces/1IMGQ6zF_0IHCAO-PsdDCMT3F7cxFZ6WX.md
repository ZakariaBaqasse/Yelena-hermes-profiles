LE   GUIDE DES
SALAIRES




                 CÔTE D’IVOIRE
                 S É N É G A L
                 B   É   N   I   N
                 2024-2025
SECRETS DE FABRICATION :
NOTRE MÉTHODOLOGIE
Pour garantir la fiabilité de cette étude, notre équipe suit une méthodologie
rigoureuse de collecte et d’analyse des données basée sur ces 3 paramètres :




             5 000                               20 000+                             3
             RÉPONDANTS                          PROFILS                             PAYS
             AU SONDAGE                          RÉFÉRENCÉS                          COUVERTS




  BASE DE DONNÉES                                                 SEGMENTATION PAR
  ET ÉCHANTILLONNAGE                                              NIVEAU D’EXPÉRIENCE
  •       Côte d’Ivoire, Sénégal et Bénin                         •    Junior :      < 5 ans d’expérience
  •       Finance, RH, Opérations, Admin, Tech                    •    Middle :      ± 5/10 ans d’expérience
  •       Startups, PME, multinationales                          •    Senior :      > 10 ans d’expérience




  PROCESSUS                                                       PROTECTION
  DE COLLECTE                                                     ET ÉTHIQUE
  •       Entretiens candidats traditionnels                      •    Anonymat garanti
  •       Vérification en binôme                                  •    Sécurisation des informations
  •       Consentement explicite                                  •    Confidentialité stricte




préface                                                                                                        3
        REGARDS                                                                                                                         PREMIER OBSERVATOIRE
     SUR L’AVENIR                                                                                                                       DES RÉMUNÉRATIONS
Le
dans
       Guide
         une
                 des
                troisième
                          Salaires
                              édition
                                          2024/2025
                                           enrichie,
                                                          revient
                                                         incluant
                                                                                                                                        EN AFRIQUE DE L’OUEST
pour     la    première     fois     le    marché       béninois.
                                                                                                                                        Pionnier de l’intelligence RH en Afrique de l’Ouest, Grey Search Africa est le premier cabinet
Notre ambition reste inchangée : offrir une référence
                                                                                                                                        à cartographier les tendances salariales à l’échelle tri-nationale. Notre expertise s’appuie
qualitative au service des recruteurs et des talents.
                                                                                                                                        sur une équipe passionnée et un réseau solide.

Nos investigations révèlent trois tendances majeures qui
redessinent le paysage du recrutement en Afrique :

                                                                                                                                        NOTRE FORCE
Un marché de “l’emploi qualifié” où les talents ont
l’avantage. Suite aux restructurations dans le secteur
technologique en 2023, les équipes RH font face
à un double défi : des ressources limitées et une
concurrence accrue pour attirer les meilleurs profils.                                                                                     15 EXPERTS EN           + DE 50 000 TALENTS        250+ ENTREPRISES               UN HUB          8 ANNÉES
                                                                                                                                          CAPITAL HUMAIN               DANS NOTRE              ACCOMPAGNÉES                STRATÉGIQUE     D’EXCELLENCE
                                                                                                                                          À VOTRE SERVICE            RÉSEAU AFRICAIN            EN CONSEIL RH               À ABIDJAN    SUR LE CONTINENT

L’arrivée massive de la génération Z, qui représentera
30% de la main-d’œuvre d’ici 2025. Cette nouvelle
génération privilégie le sens, la diversité et l’équilibre
vie    professionnelle-personnelle,        n’hésitant    pas   à                                                                        NOTRE ENGAGEMENT
décliner les opportunités qui ne correspondent
pas à ses valeurs.                                                                                                                      Transformer les ambitions de nos partenaires en succès durables.



La révolution de l’IA dans les processus RH. Si elle
                                                                    Merci à tous les contributeurs qui ont partagé leur
répond au besoin d’optimisation des ressources,
                                                                    expertise pour éclairer ces évolutions.
elle soulève aussi de nouveaux enjeux. L’accélération
technologique créé un décalage entre les innovations
                                                                    Leïla RICHARD TOUMA
et la capacité d’adaptation des équipes.                            Directrice du cabinet de recrutement Grey Search Africa




4                                                                                                                             préface   préface                                                                                                             5
SOMMAIRE


P006    LES ATTENTES DES SALARIÉS

P008    L’ESSENTIEL DES NOUVEAUX MÉTIERS

 P010   INTERVIEW RÉGIS BAMBA


P013    CÔTE D’IVOIRE GRILLE SALARIALE
 P106   INTERVIEW BIRAHIM DIOP


P109    SÉNÉGAL GRILLE SALARIALE
 P136   INTERVIEW CLÉLI AZOKPOTA


P139    BÉNIN GRILLE SALARIALE
 P150   INTERVIEW LONGA ANDREA MBUYAMBA




P152    REMERCIEMENTS
                    SALAIRE OU SENS
                                                                                    La Dynamique de la Fidélisation
                                                                                    Bien que la rémunération reste significative, elle

      LES NOUVELLES ATTENTES DES TALENTS AFRICAINS
                                                                                    ne suffit plus à garantir l’engagement durable
                                                                                    des collaborateurs. L’environnement de travail
                                                                                    et l’équilibre vie professionnelle-personnelle
                                       Notre dernière étude, menée auprès de        s’imposent      désormais       comme     des   piliers
                                   professionnels en Afrique de l’Ouest, révèle     essentiels de la rétention des talents, reflétant
                                        une transformation profonde dans les        une maturité croissante du marché du travail en
                                 aspirations des talents. Si le salaire conserve    Afrique de l’Ouest.
                                   sa place de premier critère d’attractivité, la
                                différence avec les autres facteurs s’amenuise      L’Émergence d’une Nouvelle Vision
                                          considérablement. Les perspectives        L’opportunité de carrière constitue aujourd’hui
                                      d’évolution et l’environnement de travail     la première motivation pour un changement
                                     démontrent l’émergence d’une vision plus       professionnel,        devançant      significativement
                                holistique de l’épanouissement professionnel.       l’attrait salarial. Cette nouvelle génération de
                                                                                    professionnels africains, hautement qualifiée et
                                                                                    ambitieuse, recherche des organisations dont
                                                                                    les valeurs résonnent avec leurs aspirations
                                                                                    personnelles.


                                                                                    Les Implications pour les Entreprises
                                                                                    Pour attirer et retenir les meilleurs talents, les
                                                                                    entreprises     doivent    transcender      l’approche
                                                                                    traditionnelle centrée sur la rémunération.
                                                                                    Les organisations qui sauront articuler une
                                                                                    proposition      de    valeur     équilibrée,   mêlant
                                                                                    rémunération attractive, culture d’entreprise forte
                                                                                    et opportunités d’évolution, se démarqueront
                                                                                    dans la course aux talents. Plus qu’un simple
                                                                                    emploi, les professionnels africains recherchent
                                                                                    aujourd’hui une aventure porteuse de sens.




008                                                                    focus gsa    focus gsa                                                 009
                                                                                                       LES          14
                                                                                                       SECTEURS LES
                                                                                                       PLUS DYNAMIQUES
                                                             L’ESSENTIEL DES
                                                                                                       EN RECRUTEMENT
       NOUVEAUX MÉTIERS
       TOP INDUSTRY HIRING EN CÔTE D’IVOIRE
                     DE MAI 2023 À MAI 2024
        Cette analyse présente un histogramme des données de recrutement en Côte d'Ivoire entre
      mai 2023 et mai 2024, illustrant les secteurs ayant enregistré le plus d'embauches et mettant
                  en lumière les tendances clés qui inﬂuencent le marché de l'emploi dans le pays.




                                                                                SOURCE
           https://directiongeneraleemploi.ci/grands-dossiers/observation-du-marche-du-travail



                                                                                RÉSUMÉ
      Le secteur du commerce, avec 43 795 recrutements (35,26%), domine largement le marché
       de l'emploi en Côte d'Ivoire, suivi par l'industrie manufacturière avec 19 946 recrutements
                (16,06%), qui témoigne d'une volonté de renforcer la production locale, et le BTP,
              qui enregistre 16 998 recrutements (13,69%) en raison des projets d'infrastructure
                                                                  et des besoins de construction.




010                                                                 L’ESSENTIEL DES NOUVEAUX MéTIERS   L’ESSENTIEL DES NOUVEAUX MéTIERS   011
                                                                   RÉGIS BAMBA
                                                                                                        INTERVIEW



                                           Titulaire d’un Master en informatique de l’Université de Townson aux États-Unis, Régis
                                            Bamba, après une expérience professionnelle chez MTN, fonde en 2020 avec Hassan
                                                                                                                                           CRÉER DES
                                                                                                                                        CHALLENGES
                                                                                                                                       QUI VONT MO-
                                                                                                                                                    ̏
                                                                                                                                      TIVER LES COL-
                                         Bourgi la ﬁntech Djamo, une solution fintech qui permet d’effectuer des transactions en
                                            ligne grâce à une carte bancaire Visa. En d’autres termes, Djamo fournit des services



                                                                                                                                      LABORATEURS
                                        ﬁnanciers aux personnes bancarisées et non bancarisées. En novembre 2022, la start-up
                                           réussit une levée de fonds de 14 millions de dollars pour poursuivre le développement
                                                     de sa gamme de produits et s’étendre à de nouveaux marchés. Entrepreneur
                                        particulièrement innovant, Régis nous explique la place des nouvelles technologies dans
                                                                                   sa structure et ce qu’il attend de ses équipes.       À TOUJOURS
                                                                                                                                      SE SURPASSER
Pouvez-vous d’abord nous expliquer l’importance de la                   Donc oui, définitivement, aujourd'hui l'IA nous aide à           je pense, d'attirer les bons profils. Pour vous donner un   plus ces derniers qui correspondent le mieux : des per-
digitalisation chez Djamo ?                                             mieux fonctionner au sein de Djamo. Nous l’utilisons,            exemple, nous sommes face à des challenges avec le          sonnes qui sont toujours en train d'essayer d'aller de
      « Aujourd'hui, tout est digitalisé chez Djamo ! Depuis            par exemple, pour de meilleures réponses aux clients,            volume de données que nous traitons et, en général,         l'avant. Le challenge, c'est justement de maintenir cet
      le recrutement et le processus d'entretien jusqu’à l’or-          pour détecter de la fraude ou pour prédire le comporte-          nous mettons cela en avant lorsque nous avons des           environnement-là qui est très stimulant et boostant
      ganisation en interne, nous avons des logiciels de réa-           ment de certains clients par rapport à certains usages           entretiens pour justement susciter un peu cette envie       pour les équipes pour que tout le temps elles soient en
      justement pour évaluer la performance, pour définir les           sur le produit. Aujourd’hui, nous sommes capables de             chez le candidat de venir voir un peu ce qui se passe       train d'essayer de progresser.
      objectifs, pour gérer toutes les tâches administratives.          générer du contenu, que ce soit de l'image, de l'audio,          chez nous.                                                  Donc moi, mon défi aujourd'hui, c'est de continuer à
      Et tout ça permet vraiment un gain de temps pour tout             des vidéos, et je pense que pour les industries créa-            Aujourd'hui, je pense que les cursus scolaires et l'école   créer un environnement sain et très stimulant pour nos
      le monde, que ce soit pour les candidats, pour les col-           tives, ce sont des opportunités pour générer du contenu          classique ne sont pas forcément adaptés à ce type de        équipes, leur donner des challenges, leur donner les
      laborateurs ou pour l'employeur… Il n'y a vraiment au-            beaucoup plus rapidement… Et obtenir peut-être un go-            technologie et donc ce que j’attends vraiment des can-      ressources pour faire face à ces challenges. Et toujours
      cune raison de ne pas aller vers la digitalisation aujour-        to-market beaucoup plus rapide. »                                didats, c'est d'être autodidacte et de continuellement      bien définir la vision dans laquelle tout le monde doit
      d'hui. »                                                                                                                           se former, de rester à la page. Cela demande discipline     s'inscrire au sein de l'entreprise.»
                                                                    Parlons maintenant ressources humaines. Quelles straté-              et détermination. Les candidats avec ce genre de moti-
Avez-vous profité du développement de l’Intelligence Ar-            gies utilisez-vous pour attirer les bons profils ?                   vation sont encore trop rares. »
tificielle pour développer votre business ?                             « C'est très compliqué de trouver les bons talents. Il
      « Grâce à l'intelligence artificielle, aujourd'hui, nous          faut d’abord construire une bonne marque employeur            Comment faites-vous pour conserver les talents au sein
      avons l'opportunité d'agrandir notre productivité au              et créer un environnement de travail sain. Et il faut déjà    de Djamo ?
      sein des équipes. Nous arrivons à faire des tâches que            avoir du talent : c'est paradoxal, mais le talent attire le      « Les candidats ont tous des profils différents : on a
      nous ne faisions pas ou pour lesquelles nous prenions             talent ! Il faut également créer des challenges qui vont         des personnes qui vont vouloir plus de stabilité et on a
      beaucoup plus de temps. Nous les faisons beaucoup                 motiver les collaborateurs à toujours se surpasser. Et           d'autres profils qui vont vouloir vraiment tout le temps
      plus rapidement et le rendu est de meilleure qualité.             il faut parler, exposer ce qu'on fait… Tout cela permet,         être challengés. Je pense que pour des startups, c'est


012                                                                                                L’ESSENTIEL DES NOUVEAUX MéTIERS   L’ESSENTIEL DES NOUVEAUX MéTIERS                                                                                    013
         CÔTE
     D'IVOIRE
         GRILLE SALARIALE




14                  côte d'ivoire
ACCUEIL                                                                                                ACHATS
& SERVICES                                                                                             & SUPPLY CHAIN

       FONCTIONS                                                                                              BUYING
                         EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN           SALAIRE HAUT                                                EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DE SERVICES                                                                                        & PROCUREMENT


                           < 5 ans      75,000         178,000                  410,000                                                      < 5 ans      142,000        263,000         433,000

       OPÉRATEUR
                          5-10 ans      109,000        329,000                  654,000                    ACHETEUR BTP                      5-10 ans     250,000        420,000         512,000
        DE SAISIE

                          > 10 ans      132,000        391,000                  759,000                                                      > 10 ans     400,000        638,000         900,000


                                                                                                                                             < 5 ans      210,000        365,000         610,000

                                                                                                        ACHETEUR GRANDE
                                                                                                                                             5-10 ans     293,000        588,000         850,000
        GESTION &                                                                                         DISTRIBUTION
     TRAITEMENT DE       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN           SALAIRE HAUT
     L’INFORMATION                                                                                                                           > 10 ans     450,000        900,000        1,500,000


                           < 5 ans      150,000        226,000                  500,000                                                      < 5 ans      226,000        488,000         772,000

       ARCHIVISTE                                                                                             ACHETEUR
                          5-10 ans      157,000        279,000                  780,000                                                      5-10 ans     370,000        615,000        1,100,000
     DOCUMENTALISTE                                                                                          INDUSTRIEL

                          > 10 ans         -              -                          -                                                       > 10 ans     421,000        724,000        1,420,000


                                                                                                                                             < 5 ans      207,000        361,000         574,000

                                                                                                            ACHETEUR IT
                                                                                                                                             5-10 ans     345,000        440,000         727,000
                                                                                                            & TÉLÉCOMS
      HÔTESSARIAT        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN           SALAIRE HAUT                                                     > 10 ans     473,000        577,000        1,100,000


                           < 5 ans      100,000        204,000                  375,000                                                      < 5 ans      170,000        404,000        1,100,000
                                                                                                             ACHETEUR
     HÔTE D’ACCUEIL
                          5-10 ans      150,000        238,000                  417,000                      MATIÈRES                        5-10 ans     254,000        475,000        1,300,000
     STANDARDISTE
                                                                                                             PREMIÈRES
                          > 10 ans         -              -                          -                                                       > 10 ans     411,000        849,000        1,500,000


                           < 5 ans      175,000        226,000                  410,000                                                      < 5 ans      225,000        296,000         415,000
     HÔTE D’ACCUEIL
     STANDARDISTE                                                                                            ACHETEUR
                          5-10 ans      205,000        329,000                  448,000                                                      5-10 ans     318,000        401,000         622,000
         (ANGLAIS                                                                                           SERVICES/FM
     COURANT/BILINGUE)
                          > 10 ans         -              -                          -                                                       > 10 ans     440,000        584,000         879,000




16                                                                  Accueil& Services CÔTE D'IVOIRE   CÔTE D'IVOIRE Achats& Supply Chain                                                           17
       BUYING &                                                                                         FONCTIONS DE
                    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                               EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     PROCUREMENT                                                                                          DIRECTION


                      < 5 ans      271,000        481,000                     620,000                                                     < 5 ans         -               -              -
      ACHETEUR
     TRANSPORT/      5-10 ans      363,000        608,000                     852,000                DIRECTEUR ACHATS                     5-10 ans        -               -              -
     LOGISTIQUE
                     > 10 ans      478,000        772,000                    1,143,000                                                    > 10 ans    1,500,000       2,089,000      3,350,000


                      < 5 ans      235,000        465,000                     650,000                                                     < 5 ans         -               -              -

      ASSISTANT                                                                                           DIRECTEUR
                     5-10 ans      386,000        488,000                     820,000                                                     5-10 ans        -               -              -
       ACHATS                                                                                             D’AGENCE

                     > 10 ans         -               -                            -                                                      > 10 ans    1,080,000       2,840,000      8,200,000


                      < 5 ans         -               -                            -                                                      < 5 ans         -               -              -
     COMMODITY
                                                                                                      DIRECTEUR DE LA
      MANAGER/       5-10 ans      350,000        680,000                    1,200,000                                                    5-10 ans        -               -              -
                                                                                                     RELATION CLIENTS
     LEAD BUYER
                     > 10 ans      690,000        976,000                    1,810,000                                                    > 10 ans     989,000        1,611,000      2,380,000


                      < 5 ans      158,000        355,000                     700,000                                                     < 5 ans         -               -              -

     GESTIONNAIRE                                                                                       DIRECTEUR
                     5-10 ans      197,000        658,000                    1,400,000                                                    5-10 ans        -               -              -
        ACHATS                                                                                        DES OPÉRATIONS

                     > 10 ans      350,000        773,000                    1,720,000                                                    > 10 ans    1,420,000       2,591,000      8,200,000


                      < 5 ans      200,000        741,000                    1,800,000                                                    < 5 ans         -               -              -

     RESPONSABLE                                                                                          DIRECTEUR
                     5-10 ans      250,000        767,000                    2,000,000                                                    5-10 ans        -               -              -
       ACHATS                                                                                          D'EXPLOITATION

                     > 10 ans      400,000        966,000                    3,000,000                                                    > 10 ans    1,444,000       2,214,000      4,353,000


                      < 5 ans         -               -                            -                                                      < 5 ans         -               -              -

   RESPONSABLE                                                                                            DIRECTEUR
                     5-10 ans      300,000        698,000                    1,600,000                                                    5-10 ans        -               -              -
 MOYENS GÉNÉRAUX                                                                                          LOGISTIQUE

                     > 10 ans      700,000        1,048,000                  2,000,000                                                    > 10 ans    1,850,000       2,550,000      4,000,000


                                                                                                                                          < 5 ans         -               -              -

                                                                                                        DIRECTEUR
                                                                                                                                          5-10 ans        -               -              -
                                                                                                     MOYENS GÉNÉRAUX

                                                                                                                                          > 10 ans     800,000        1,954,000      2,600,000




18                                                            Achats& Supply Chain CÔTE D'IVOIRE   CÔTE D'IVOIRE Achats& Supply Chain                                                           19
      FONCTIONS DE                                                                                           LOGISTICS &
                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                               EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        DIRECTION                                                                                           SUPPLY CHAIN


                          < 5 ans         -               -                            -                                                      < 5 ans         -               -              -

       DIRECTEUR                                                                                              CONTRACT
                         5-10 ans         -               -                            -                                                      5-10 ans     560,000        1,127,000      1,600,000
      SUPPLY CHAIN                                                                                            MANAGER

                         > 10 ans     1,869,000       2,969,000                  4,920,000                                                    > 10 ans     806,000        1,440,000      1,880,000


                          < 5 ans         -               -                            -                                                      < 5 ans      106,000        368,000         850,000

        DIRECTEUR                                                                                          COORDINATEUR
                         5-10 ans         -               -                            -                                                      5-10 ans     120,000        421,000         950,000
       TRANSPORTS                                                                                           LOGISTIQUE

                         > 10 ans     1,645,000       2,196,000                  2,940,000                                                    > 10 ans     250,000        563,000        1,500,000


                                                                                                                                              < 5 ans      440,000        830,000        1,200,000
                                                                                                         DEMAND PLANNER/
                                                                                                            CUSTOMER                          5-10 ans     500,000        1,120,000      1,600,000
                                                                                                             PLANNER
       LOGISTICS &
                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                                    > 10 ans     630,000        1,311,000      1,875,000
      SUPPLY CHAIN


                          < 5 ans      120,000        240,000                     410,000                                                     < 5 ans         -               -              -

          AGENT                                                                                             DISTRIBUTION
                         5-10 ans      190,000        276,000                     507,000                                                     5-10 ans        -               -              -
     DE PLANIFICATION                                                                                         MANAGER

                         > 10 ans         -               -                            -                                                      > 10 ans     850,000        1,484,000      3,000,000


                          < 5 ans      150,000        343,000                     451,000                                                     < 5 ans         -               -              -
                                                                                                           GESTIONNAIRE
 AGENT LOGISTIQUE/
                         5-10 ans      281,000        474,000                     830,000                 APPROVISIONNE-                      5-10 ans     250,000        563,000        1,210,000
    LOGISTICIEN
                                                                                                              MENTS
                         > 10 ans      300,000        565,000                    1,000,000                                                    > 10 ans     387,000        749,000        1,738,000


                          < 5 ans      200,000        321,000                     650,000                                                     < 5 ans      85,000         319,000         600,000

       ASSISTANT                                                                                            GESTIONNAIRE
                         5-10 ans      297,000        375,000                     724,000                                                     5-10 ans     100,000        370,000         830,000
       LOGISTIQUE                                                                                           FLUX & STOCKS

                         > 10 ans         -               -                            -                                                      > 10 ans     220,000        424,000         950,000


                          < 5 ans         -               -                            -                                                      < 5 ans         -               -              -
      CHEF DE PROJET                                                                                          INGÉNIEUR
       INGÉNIERIE &      5-10 ans      378,000        849,000                    1,320,000                    MÉTHODES                        5-10 ans     410,000        630,000        1,240,000
     IMPLÉMENTATION                                                                                          LOGISTIQUES
                         > 10 ans      480,000        1,045,000                  1,958,000                                                    > 10 ans     587,000        861,000        1,580,000




20                                                                Achats& Supply Chain CÔTE D'IVOIRE   CÔTE D'IVOIRE Achats& Supply Chain                                                           21
       LOGISTICS &                                                                                         LOGISTICS &
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                               EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      SUPPLY CHAIN                                                                                        SUPPLY CHAIN


                        < 5 ans      60,000         182,000                     400,000                                                     < 5 ans         -               -              -
      MAGASINIER/                                                                                         RESPONSABLE
     MANUTENTION-      5-10 ans      80,000         314,000                     750,000                    PRÉVISION                        5-10 ans     640,000        847,000        1,200,000
        NAIRE                                                                                              DES VENTES
                       > 10 ans      157,000        289,000                     950,000                                                     > 10 ans     710,000        911,000        1,315,000


                        < 5 ans         -               -                            -                                                      < 5 ans      120,000        309,000         500,000
      RESPONSABLE                                                                                         RESPONSABLE
     APPROVISIONNE-    5-10 ans      280,000        754,000                    1,300,000                      S&OP                          5-10 ans     150,000        673,000        1,000,000
                                                                                                        (SALES & OPERATIONS
         MENTS                                                                                               PLANNING)
                       > 10 ans      800,000        1,228,000                  2,250,000                                                    > 10 ans     300,000        880,000        2,250,000


                        < 5 ans         -               -                            -                                                      < 5 ans      200,000        478,000         900,000
      RESPONSABLE
                                                                                                          RESPONSABLE
       D'ENTREPÔT/     5-10 ans      175,000        643,000                    1,500,000                                                    5-10 ans     200,000        1,164,000      2,410,000
                                                                                                          SUPPLY CHAIN
     D'ENTREPOSAGE
                       > 10 ans      320,000        771,000                    2,000,000                                                    > 10 ans     300,000        1,606,000      3,834,000


                        < 5 ans         -               -                            -                                                      < 5 ans         -               -              -

      RESPONSABLE
                       5-10 ans      510,000        875,000                    1,340,000                  SHIP MANAGER                      5-10 ans     620,000        902,000        1,200,000
     DES OPÉRATIONS

                       > 10 ans      669,000        1,210,000                  2,100,000                                                    > 10 ans     850,000        1,105,000      1,600,000


                        < 5 ans         -               -                            -

      RESPONSABLE
                       5-10 ans      179,000        653,000                    1,200,000
      EXPLOITATION

                       > 10 ans      350,000        983,000                    1,823,000                    TRANSPORT                  EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                        < 5 ans      200,000        353,000                     750,000                                                     < 5 ans      161,000        357,000         500,000
                                                                                                             AGENT
     RESPONSABLE
                       5-10 ans      240,000        438,000                     952,000                  D’EXPLOITATION                     5-10 ans     175,000        376,000         800,000
     FLUX & STOCKS
                                                                                                           TRANSPORT
                       > 10 ans      310,000        583,000                    1,137,000                                                    > 10 ans        -               -              -


                        < 5 ans      200,000        430,000                     820,000                                                     < 5 ans      170,000        252,000         350,000

      RESPONSABLE
                       5-10 ans      200,000        642,000                    1,500,000                AGENT DE DOUANE                     5-10 ans     210,000        304,000         400,000
       LOGISTIQUE

                       > 10 ans      380,000        1,476,000                  3,936,000                                                    > 10 ans        -               -              -




22                                                              Achats& Supply Chain CÔTE D'IVOIRE   CÔTE D'IVOIRE Achats& Supply Chain                                                           23
       TRANSPORT       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN            SALAIRE HAUT                    TRANSPORT                  EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                         < 5 ans      90,000         243,000                   425,000                                                     < 5 ans         -               -              -
                                                                                                        RESPONSABLE
 AGENT DE TRANSIT       5-10 ans      150,000        261,000                   600,000                PARC AUTOMOBILE                      5-10 ans     200,000        610,000        1,000,000
                                                                                                          ET ENGINS
                        > 10 ans      300,000        463,000                   860,000                                                     > 10 ans     250,000        922,000        1,750,000


                         < 5 ans      130,000        225,000                   325,000                                                     < 5 ans         -               -              -

                                                                                                         RESPONSABLE
     AGENT TRACKING     5-10 ans      150,000        252,000                   400,000                                                     5-10 ans     426,000        1,044,000      1,800,000
                                                                                                         TRANSPORTS

                        > 10 ans      180,000        328,000                   520,000                                                     > 10 ans     500,000        1,288,000      2,200,000


                         < 5 ans         -              -                           -                                                      < 5 ans         -               -              -
                                                                                                        RESPONSABLE/
       CHAUFFEUR
                        5-10 ans         -              -                           -                   CHEF DÉPARTE-                      5-10 ans     300,000        523,000         900,000
       CHALLENGER
                                                                                                        MENT TRANSIT
                        > 10 ans      150,000        267,000                   455,000                                                     > 10 ans     542,000        1,008,000      1,510,000


                         < 5 ans         -              -                           -

     CHAUFFEUR ENGIN
                        5-10 ans         -              -                           -
     DE MANUTENTION

                        > 10 ans      300,000        607,000                  1,200,000


                         < 5 ans         -              -                           -

    CHAUFFEUR
                        5-10 ans      120,000        181,000                   250,000
 TRACTEUR ROUTIER

                        > 10 ans      150,000        227,000                   375,000


                         < 5 ans      150,000        237,000                   300,000

       DÉCLARANT
                        5-10 ans      250,000        380,000                   550,000
        DOUANES

                        > 10 ans      300,000        425,000                   600,000


                         < 5 ans      120,000        171,000                   280,000

        PASSEUR
                        5-10 ans      180,000        223,000                   350,000
       EN DOUANE

                        > 10 ans      200,000        261,000                   410,000




24                                                             Achats& Supply Chain CÔTE D'IVOIRE   CÔTE D'IVOIRE Achats& Supply Chain                                                           25
ADMINISTRATIF, ASSISTANAT                                                                                            ASSISTANAT
                                                                                                                    DE DIRECTION                 EXPÉRIENCE                    SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT

& OFFICE MANAGEMENT                                                                                                OPÉRATIONNELLE

                                                                                                                                                     < 5 ans                     80,000         145,000         380,000
                                                                                                                      ASSISTANT
                                                                                                                  DE BUSINESS UNIT/
                                                                                                                                                    5-10 ans                     116,000        336,000         715,000
                                                                                                                   DÉPARTEMENT/
                                                                                                                        ÉQUIPE
     ADMINISTRATIF      EXPÉRIENCE   SALAIRE BAS           SALAIRE MOYEN               SALAIRE HAUT                                                 > 10 ans                     132,000        388,000         820,000


                          < 5 ans      122,000                   277,000                    600,000                                                  < 5 ans                     100,000        317,000         810,000

       ASSISTANT                                                                                                      ASSISTANT
                         5-10 ans      150,000                   362,000                    800,000                                                 5-10 ans                     115,000        412,000         926,000
     ADMINISTRATIF                                                                                                   DE DIRECTION

                         > 10 ans      285,000                   477,000                   1,050,000                                                > 10 ans                     250,000        531,000        1,100,000


                          < 5 ans      150,000                   322,000                    742,000                                                  < 5 ans                     218,000        482,000         810,000
       ASSISTANT                                                                                                      ASSISTANT
     ADMINISTRATIF       5-10 ans      247,000                   418,000                    869,000                  DE DIRECTION                   5-10 ans                     230,000        474,000        1,111,000
     ANGLAIS COURANT/                                                                                               ANGLAIS COURANT/
         BILINGUE                                                                                                       BILINGUE
                         > 10 ans      388,000                   573,000                   1,116,000                                                > 10 ans                     283,000        690,000        1,510,000


                          < 5 ans      150,000                   232,000                    665,000                                                  < 5 ans                     80,000         187,000         350,000
       ASSISTANT
                                                                                                                     ASSISTANT
     ADMINISTRATIF       5-10 ans      180,000                   378,000                    904,000                                                 5-10 ans                     130,000        271,000         545,000
                                                                                                                   POLYVALENT PME
       SPÉCIALISÉ
                         > 10 ans      304,000                   526,000                   1,081,000                                                > 10 ans                     164,000        329,000         724,000


                          < 5 ans         -                          -                          -                                                    < 5 ans                     110,000        219,000         421,000
                                                                                                                     ASSISTANT
       DIRECTEUR                                                                                                   POLYVALENT PME
                         5-10 ans         -                          -                          -                                                   5-10 ans                     178,000        344,000         664,000
     ADMINISTRATIF                                                                                                  ANGLAIS COURANT/
                                                                                                                        BILINGUE
                         > 10 ans     1,420,000                 2,267,000                  3,000,000                                                > 10 ans                     222,000        424,000         842,000


                          < 5 ans         -                          -                          -

     RESPONSABLE                                                                                                    ASSISTANAT DE
                         5-10 ans      300,000                   577,000                    912,000
     ADMINISTRATIF                                                                                                   HAUT NIVEAU
                                                                                                                                                 EXPÉRIENCE                    SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                                       & OFFICE
                         > 10 ans      458,000                   840,000                   1,856,000                 MANAGEMENT


                                                                                                                                                     < 5 ans                     160,000        338,000         824,000
                                                                                                                      ASSISTANT
                                                                                                                     DE PRÉSIDENT/
                                                                                                                                                    5-10 ans                     191,000        469,000         977,000
                                                                                                                       DIRECTION
                                                                                                                       GÉNÉRALE
                                                                                                                                                    > 10 ans                     375,000        614,000        1,100,000




26                                                 Administratif, Assistanat& Office Management CÔTE D'IVOIRE   CÔTE D'IVOIRE Administratif, Assistanat& Office Management                                                27
     ASSISTANAT DE
      HAUT NIVEAU
        & OFFICE
                        EXPÉRIENCE   SALAIRE BAS          SALAIRE MOYEN               SALAIRE HAUT
                                                                                                               ADV
      MANAGEMENT
                                                                                                               & RELATION CLIENTS
       ASSISTANT          < 5 ans      195,000                 412,000                    900,000
      DE PRÉSIDENT/
        DIRECTION        5-10 ans      287,000                 507,000                   1,042,000
        GÉNÉRALE
     ANGLAIS COURANT/
         BILINGUE        > 10 ans      330,000                 736,000                   1,600,000                IMPORT/EXPORT                  EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                          < 5 ans      150,000                 335,000                    600,000                                                     < 5 ans         -               -              -

                                                                                                                   GESTIONNAIRE
     OFFICE MANAGER      5-10 ans      200,000                 542,000                   1,300,000                                                    5-10 ans     220,000        474,000         826,000
                                                                                                                      EXPORT

                         > 10 ans      241,000                 665,000                   1,740,000                                                    > 10 ans     250,000        618,000         950,000


                          < 5 ans      164,000                 374,000                    855,000                                                     < 5 ans         -               -              -
     OFFICE MANAGER                                                                                                GESTIONNAIRE
     ANGLAIS COURANT/    5-10 ans      235,000                 733,000                   1,700,000                                                    5-10 ans     210,000        466,000         798,000
         BILINGUE                                                                                                     IMPORT

                         > 10 ans      263,000                 923,000                   2,296,000                                                    > 10 ans     255,000        621,000         950,000


                                                                                                                                                      < 5 ans         -               -              -

                                                                                                                   GESTIONNAIRE
                                                                                                                                                      5-10 ans     250,000        490,000         774,000
                                                                                                                 IMPORT & EXPORT
      ASSISTANAT
                        EXPÉRIENCE   SALAIRE BAS          SALAIRE MOYEN               SALAIRE HAUT                                                    > 10 ans     250,000        638,000         974,000
      SPÉCIALISÉ


                          < 5 ans      80,000                  227,000                    358,000                                                     < 5 ans         -               -              -
       ASSISTANT/
                                                                                                                   RESPONSABLE
       SECRÉTAIRE        5-10 ans      125,000                 271,000                    413,000                                                     5-10 ans     250,000        437,000         800,000
                                                                                                                      EXPORT
        JURIDIQUE
                         > 10 ans      150,000                 302,000                    580,000                                                     > 10 ans     488,000        1,083,000      1,850,000


                          < 5 ans      100,000                 310,000                    616,000                                                     < 5 ans         -               -              -
       ASSISTANT/
       SECRÉTAIRE                                                                                                  RESPONSABLE
                         5-10 ans      180,000                 361,000                    745,000                                                     5-10 ans     250,000        674,000         881,000
       MARKETING/                                                                                                IMPORT & EXPORT
     COMMUNICATION
                         > 10 ans      250,000                 423,000                    791,000                                                     > 10 ans     320,000        854,000        1,754,000


                          < 5 ans      90,000                  131,000                    195,000
       ASSISTANT/
       SECRÉTAIRE        5-10 ans      118,000                 149,000                    261,000
        MÉDICALE
                         > 10 ans      148,000                 211,000                    414,000




28                                               Administratif, Assistanat& Office Management CÔTE D'IVOIRE   CÔTE D'IVOIRE ADV & Relation Clients                                                           29
         SALES                                                                                              SALES
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN            SALAIRE HAUT                                                 EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     ADMINISTRATION                                                                                     ADMINISTRATION


                         < 5 ans      176,000        223,000                    371,000                                                      < 5 ans         -              -               -

                                                                                                         RESPONSABLE
       ADV LOCAL        5-10 ans      205,000        424,000                    625,000                                                      5-10 ans     405,000        639,000        1,050,000
                                                                                                        SERVICE CLIENTS

                        > 10 ans         -              -                           -                                                        > 10 ans     500,000        774,000        1,200,000


                         < 5 ans      80,000         141,000                    190,000

        AGENT
                        5-10 ans      125,000        178,000                    285,000
      CALL CENTER

                        > 10 ans         -              -                           -                    SALES SUPPORT                  EXPÉRIENCE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                         < 5 ans      147,000        200,000                    320,000                                                      < 5 ans      175,000        251,000         350,000

     ASSISTANT ADV      5-10 ans         -              -                           -                       ASSISTANT                        5-10 ans     200,000        319,000         525,000
                                                                                                           COMMERCIAL
                        > 10 ans         -              -                           -                                                        > 10 ans        -              -               -


                         < 5 ans      240,000        402,000                    544,000
         CHARGÉ
      DE CLIENTÈLE      5-10 ans      288,000        541,000                    800,000
         B-TO-B
                        > 10 ans      300,000        700,000                   1,500,000


                         < 5 ans      110,000        187,000                    300,000
      CHEF D'ÉQUIPE
      /SUPERVISEUR      5-10 ans      130,000        232,000                    350,000
       CALL CENTER
                        > 10 ans         -              -                           -


                         < 5 ans      278,000        411,000                    749,000

      GESTIONNAIRE
                        5-10 ans      361,000        512,000                    944,000
     SERVICE CLIENTS

                        > 10 ans         -              -                           -


                         < 5 ans         -              -                           -

 RESPONSABLE ADV        5-10 ans      300,000        604,000                   1,000,000

                        > 10 ans      494,000        833,000                   1,200,000




30                                                             ADV & Relation Clients CÔTE D'IVOIRE   CÔTE D'IVOIRE ADV & Relation Clients                                                           31
ASSURANCE


      ASSURANCE                                                                                FONCTIONS
                     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DE BIENS                                                                               DE DIRECTION


                       < 5 ans      155,000        338,000          610,000                                           < 5 ans         -               -              -
     GESTIONNAIRE                                                                              DIRECTEUR
     DE PRODUCTION    5-10 ans      310,000        530,000          780,000                  ADMINISTRATIF           5-10 ans         -               -              -
        IARD/DAB                                                                              ET FINANCIER
                      > 10 ans         -              -                  -                                           > 10 ans     1,700,000       2,475,000      3,100,000


                       < 5 ans      80,000         308,000          498,000                                           < 5 ans         -               -              -
     GESTIONNAIRE
                                                                                              DIRECTEUR DE
     DE SINISTRES     5-10 ans      250,000        661,000         1,500,000                                         5-10 ans         -               -              -
                                                                                             LA CONFORMITÉ
       IARD/DAB
                      > 10 ans         -              -                  -                                           > 10 ans     1,680,000       2,641,000      4,000,000


                       < 5 ans         -              -                  -                                            < 5 ans         -               -              -
                                                                                              DIRECTEUR DE
     RESPONSABLE
                                                                                             LA CONFORMITÉ
       SINISTRES      5-10 ans      378,000        542,000         1,144,000                                         5-10 ans         -               -              -
                                                                                             ET DU CONTRÔLE
       IARD/DAB
                                                                                               PERMAMENT
                      > 10 ans      410,000        718,000         1,880,000                                         > 10 ans     1,500,000       2,100,000      2,988,000


                                                                                                                      < 5 ans         -               -              -

                                                                                                DIRECTEUR
                                                                                                                     5-10 ans         -               -              -
                                                                                                FINANCIER
      ASSURANCE
                     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                         > 10 ans     1,500,000       2,221,000      3,000,000
     DE PERSONNES


                       < 5 ans      178,000        298,000          450,000                                           < 5 ans         -               -              -
     GESTIONNAIRE
                                                                                                DIRECTEUR
     DE SINISTRES     5-10 ans      220,000        345,000          642,000                                          5-10 ans         -               -              -
                                                                                                MARKETING
      CORPORELS
                      > 10 ans         -              -                  -                                           > 10 ans     1,328,000       2,047,000      2,650,000


                       < 5 ans      185,000        286,000          510,000                                           < 5 ans         -               -              -
     GESTIONNAIRE
                                                                                                DIRECTEUR
        SANTÉ/        5-10 ans      230,000        365,000          625,000                                          5-10 ans         -               -              -
                                                                                                TECHNIQUE
      PRÉVOYANCE
                      > 10 ans         -              -                  -                                           > 10 ans     1,100,000       2,040,000      3,500,000




32                                                              Assurance CÔTE D'IVOIRE   CÔTE D'IVOIRE Assurance                                                             33
      FONCTIONS                                                                                FONCTIONS
                     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      SUPPORTS                                                                                TRANSVERSES


                       < 5 ans      150,000        524,000         1,000,000                                          < 5 ans      400,000        677,000         950,000

 AUDITEUR INTERNE     5-10 ans      346,000        768,000         1,120,000                     ACTUAIRE            5-10 ans      550,000        926,000        1,313,000

                      > 10 ans      520,000        973,000         1,530,000                                         > 10 ans      750,000        1,034,000      1,500,000


                       < 5 ans      130,000        461,000         1,000,000                                          < 5 ans      120,000        302,000         550,000

         CHARGÉ                                                                                ASSISTANT
                      5-10 ans      362,000        765,000         1,270,000                                         5-10 ans         -               -              -
     DE CONFORMITÉ                                                                            SOUSCRIPTION

                      > 10 ans         -               -                 -                                           > 10 ans         -               -              -


                       < 5 ans      200,000        347,000          450,000                                           < 5 ans      366,000        572,000         800,000

      COMPTABLE                                                                             CHARGÉ D’ÉTUDES
                      5-10 ans      360,000        564,000          800,000                                          5-10 ans      451,000        675,000         930,000
      TECHNIQUE                                                                              ACTUARIELLES

                      > 10 ans      577,000        695,000          900,000                                          > 10 ans         -               -              -


                       < 5 ans      380,000        498,000          850,000                                           < 5 ans         -               -              -

      CONTRÔLEUR                                                                              RESPONSABLE
                      5-10 ans      400,000        617,000         1,050,000                                         5-10 ans      580,000        804,000        1,500,000
       DE GESTION                                                                              ACTUARIAT

                      > 10 ans      500,000        790,000         1,350,000                                         > 10 ans      850,000        982,000        1,740,000


                       < 5 ans      300,000        425,000         1,204,000                                          < 5 ans      200,000        363,000         500,000

      CONTRÔLEUR                                                                              SOUSCRIPTEUR
                      5-10 ans      378,000        712,000         1,500,000                                         5-10 ans      268,000        411,000         760,000
        INTERNE                                                                                TECHNIQUE

                      > 10 ans      485,000        794,000         1,754,000                                         > 10 ans         -               -              -


                       < 5 ans         -               -                 -

     RESPONSABLE
                      5-10 ans      489,000        966,000         1,640,000
      COMPTABLE

                      > 10 ans      580,000        1,331,000       3,500,000




34                                                              Assurance CÔTE D'IVOIRE   CÔTE D'IVOIRE Assurance                                                             35
AUDIT, CONSEIL
& EXPERTISE

     CABINETS D’AUDIT                                                                                          CABINETS D’AUDIT
                            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                   EXPÉRIENCE    SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       HORS TOP 4                                                                                                   TOP 4


                              < 5 ans      115,000        289,000                     450,000                                                      < 5 ans      200,000        405,000         662,000
         AUDITEUR                                                                                                   AUDITEUR
          JUNIOR             5-10 ans         -               -                            -                       JUNIOR (A1)                     5-10 ans        -               -              -
     < 2 ANS D'EXPÉRIENCE                                                                                        1 AN D'EXPÉRIENCE

                             > 10 ans         -               -                            -                                                       > 10 ans        -               -              -


                              < 5 ans      150,000        443,000                     885,000                                                      < 5 ans      246,000        528,000         778,000
         AUDITEUR                                                                                                  AUDITEUR
         CONFIRMÉ            5-10 ans         -               -                            -                     CONFIRMÉ (A2)                     5-10 ans        -               -              -
     2-5 ANS D’EXPÉRIENCE                                                                                       2 ANS D’EXPÉRIENCE

                             > 10 ans         -               -                            -                                                       > 10 ans        -               -              -


                              < 5 ans         -               -                            -                                                       < 5 ans      310,000        730,000        1,050,000
     CHEF DE MISSION
                             5-10 ans      260,000        801,000                    1,750,000                        SENIOR                       5-10 ans        -               -              -
         SENIOR                                                                                                3-4 ANS D'EXPÉRIENCE
     6-9 ANS D’EXPÉRIENCE

                             > 10 ans         -               -                            -                                                       > 10 ans        -               -              -


                              < 5 ans         -               -                            -                                                       < 5 ans         -               -              -
        DIRECTEUR
                             5-10 ans         -               -                            -                          SENIOR                       5-10 ans     487,000        986,000        1,400,000
        DE MISSION                                                                                             5-6 ANS D'EXPÉRIENCE
 > 10 ANS D’EXPÉRIENCE

                             > 10 ans      500,000        1,384,000                  3,600,000                                                     > 10 ans        -               -              -


                                                                                                                                                   < 5 ans         -               -              -

                                                                                                                    MANAGER                        5-10 ans     600,000        1,340,000      2,350,000
                                                                                                               7-9 ANS D'EXPÉRIENCE

                                                                                                                                                   > 10 ans        -               -              -


                                                                                                                                                   < 5 ans         -               -              -

                                                                                                               SENIOR MANAGER                      5-10 ans        -               -              -
                                                                                                               > 10 ANS D’EXPÉRIENCE

                                                                                                                                                   > 10 ans     980,000        2,370,000      3,500,000




36                                                                Audit, Conseil& Expertise CÔTE D'IVOIRE   CÔTE D'IVOIRE Audit, Conseil& Expertise                                                      37
                                                                                                      BANQUE

                                                                                                            ACTIVITÉS
                                                                                                          DE MARCHÉ &
       CABINETS                                                                                           FINANCEMENT        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      D’EXPERTISE    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                       AM/BFI &
      COMPTABLE                                                                                         ASSET MANAGEMENT


                       < 5 ans      77,000         167,000                     300,000                                         < 5 ans      350,000        659,000        1,100,000

      ASSISTANT                                                                                            ANALYSTE
                      5-10 ans      185,000        338,000                     550,000                                        5-10 ans      550,000        1,022,000      1,450,000
      COMPTABLE                                                                                        FINANCIER JUNIOR

                      > 10 ans         -               -                            -                                         > 10 ans         -               -              -


                       < 5 ans      150,000        221,000                     350,000                                         < 5 ans         -               -              -
                                                                                                        CHEF DE SERVICE
     COLLABORATEUR
                      5-10 ans      174,000        274,000                     477,000                     MARCHÉS            5-10 ans         -               -              -
       COMPTABLE
                                                                                                         DES CAPITAUX
                      > 10 ans         -               -                            -                                         > 10 ans     1,594,000       2,615,000      3,300,000


                       < 5 ans         -               -                            -                                          < 5 ans         -               -              -

        EXPERT                                                                                              DIRECTEUR
                      5-10 ans         -               -                            -                                         5-10 ans         -               -              -
      COMPTABLE                                                                                        DE L'ORGANISATION

                      > 10 ans      720,000        1,652,000                  2,945,000                                       > 10 ans     1,800,000       2,286,000      2,800,000


                                                                                                                               < 5 ans      511,000        1,235,000      2,875,000
                                                                                                          GESTIONNAIRE
                                                                                                           BACK-OFFICE        5-10 ans      760,000        1,654,000      3,600,000
                                                                                                            MARCHÉS
                                                                                                                              > 10 ans         -               -              -


                                                                                                                               < 5 ans      477,000        972,000        1,670,000

                                                                                                         GESTIONNAIRE
                                                                                                                              5-10 ans      641,000        1,248,000      2,104,000
                                                                                                        DE PORTEFEUILLE

                                                                                                                              > 10 ans         -               -              -


                                                                                                                               < 5 ans      544,000        964,000        1,985,000

                                                                                                             INGÉNIEUR
                                                                                                                              5-10 ans      880,000        1,343,000      2,224,000
                                                                                                             FINANCIER

                                                                                                                              > 10 ans     1,048,000       1,624,000      2,600,000




38                                                         Audit, Conseil& Expertise CÔTE D'IVOIRE   CÔTE D'IVOIRE Banque                                                             39
        ACTIVITÉS
      DE MARCHÉ &
      FINANCEMENT       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
          AM/BFI &                                                                                 BANQUE
                                                                                                                  EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     ASSET MANAGEMENT                                                                            D'AFFAIRES


                          < 5 ans      366,000        428,000         870,000                                       < 5 ans      762,000        1,527,000      2,688,000

      MIDDLE OFFICE      5-10 ans      441,000        660,000        1,055,000                   ASSOCIATE         5-10 ans      975,000        1,975,000      3,778,000

                         > 10 ans         -               -               -                                        > 10 ans     1,145,000       2,479,000      4,354,000


                          < 5 ans         -               -               -                                         < 5 ans         -               -              -
      M&A/ECM/DCM
       ASSOCIATE/VP/     5-10 ans     1,200,000       2,847,000      4,795,000              SENIOR ASSOCIATE       5-10 ans     1,273,000       2,289,000      3,944,000
         DIRECTOR

                         > 10 ans     1,432,000       3,120,000      5,123,000                                     > 10 ans     1,354,000       2,774,000      4,651,000


                          < 5 ans      650,000        893,000        1,200,000                                      < 5 ans         -               -              -

      RELATIONSHIP
                         5-10 ans      850,000        1,246,000      2,280,000                    VP SENIOR        5-10 ans     1,459,000       2,770,000      4,215,000
        MANAGER

                         > 10 ans     1,040,000       1,671,000      2,640,000                                     > 10 ans     1,654,000       3,181,000      4,836,000


                          < 5 ans      640,000        1,040,000      1,500,000                                      < 5 ans         -               -              -
                                                                                                 DIRECTEUR
         TRADER          5-10 ans      800,000        1,172,000      1,745,000                   CORPORATE         5-10 ans         -               -              -
                                                                                                  BANKING
                         > 10 ans      922,000        1,411,000      2,100,000                                     > 10 ans     1,770,000       3,104,000      5,320,000




                                                                                                  BANQUE
          BANQUE                                                                                 DE RÉSEAU        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        D'AFFAIRES                                                                              DÉTAIL/EN LIGNE


                          < 5 ans         -               -               -                                         < 5 ans      220,000        465,000        1,150,000

         ANALYSTE
                         5-10 ans      622,000        1,181,000      1,766,000               ANALYSTE CRÉDIT       5-10 ans      274,000        610,000        1,363,000
     FINANCIER SENIOR

                         > 10 ans      714,000        1,284,000      2,017,000                                     > 10 ans         -               -              -


                          < 5 ans      427,000        662,000         977,000                                       < 5 ans         -               -              -

         CHARGÉE                                                                              CHEF DE PROJET
                         5-10 ans      468,000        810,000        1,100,000                                     5-10 ans      878,000        1,260,000      1,600,000
        D'AFFAIRES                                                                              MONÉTIQUE

                         > 10 ans      525,000        939,000        1,455,000                                     > 10 ans     1,300,000       1,634,000      2,000,000




40                                                                  Banque CÔTE D'IVOIRE   CÔTE D'IVOIRE Banque                                                             41
        BANQUE
       DE RÉSEAU        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                  FONCTIONS
                                                                                                                  EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      DÉTAIL/EN LIGNE                                                                           DE DIRECTION


                          < 5 ans         -               -               -                                         < 5 ans         -               -              -

     CHEF/DIRECTEUR                                                                            DIRECTEUR
                         5-10 ans      600,000        710,000         837,000                                      5-10 ans         -               -              -
        D'AGENCE                                                                             DES OPÉRATIONS

                         > 10 ans      735,000        1,055,000      1,450,000                                     > 10 ans     1,500,000       2,204,000      3,734,000


       FONCTIONS                                                                                                    < 5 ans         -               -              -
                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      DE DIRECTION
                                                                                                 DIRECTEUR
                                                                                                                   5-10 ans         -               -              -
                                                                                                DES RISQUES
                          < 5 ans         -               -               -
       DIRECTEUR                                                                                                   > 10 ans     1,020,000       2,797,000      5,500,000
     ADMINISTRATIF       5-10 ans     1,500,000       2,409,000      3,800,000
      ET FINANCIER
                                                                                                                    < 5 ans         -               -              -
                         > 10 ans     1,854,000       3,113,000      5,300,000                    DIRECTEUR
                                                                                                DU CONTRÔLE
                                                                                                                   5-10 ans         -               -              -
                                                                                                   INTERNE/
                          < 5 ans         -               -               -
                                                                                                 PERMANENT
        DIRECTEUR                                                                                                  > 10 ans     1,025,000       2,214,000      4,200,000
      D'INVESTISSE-      5-10 ans         -               -               -
      MENT/FONDS
                                                                                                                    < 5 ans         -               -              -
                         > 10 ans     1,500,000       3,981,000      7,500,000
                                                                                                 DIRECTEUR
                                                                                                                   5-10 ans         -               -              -
                                                                                                 FINANCIER
                          < 5 ans         -               -               -
                                                                                                                   > 10 ans     2,000,000       3,213,000      6,500,000
      DIRECTEUR DE
                         5-10 ans         -               -               -
     LA CONFORMITÉ
                                                                                                 FONCTIONS
                         > 10 ans     1,560,000       2,473,000      4,000,000                                    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                 SUPPORTS


                          < 5 ans         -               -               -                                         < 5 ans      300,000        567,000         875,000
      DIRECTEUR DE
     LA CONFORMITÉ
                         5-10 ans         -               -               -                 ANALYSTE RISQUES       5-10 ans      433,000        731,000        1,100,000
     ET DU CONTRÔLE
       PERMAMENT
                         > 10 ans     1,335,000       2,690,000      3,500,000                                     > 10 ans         -               -              -


                          < 5 ans         -               -               -                                         < 5 ans      450,000        608,000         840,000

      DIRECTEUR DE
                         5-10 ans         -               -               -                 AUDITEUR INTERNE       5-10 ans      500,000        925,000        1,800,000
     LA TRÉSORERIE

                         > 10 ans     1,424,000       2,124,000      2,856,000                                     > 10 ans      750,000        1,108,000      2,017,000


                          < 5 ans         -               -               -

     DIRECTEUR
                         5-10 ans         -               -               -
 DE L'AUDIT INTERNE

                         > 10 ans     2,000,000       2,738,000      3,500,000



42                                                                  Banque CÔTE D'IVOIRE   CÔTE D'IVOIRE Banque                                                             43
       FONCTIONS                                                                               FONCTIONS
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                   EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       SUPPORTS                                                                                SUPPORTS


                        < 5 ans      120,000        344,000         550,000                                       < 5 ans         -               -              -

         CHARGÉ                                                                              RESPONSABLE
                       5-10 ans      340,000        535,000         900,000                                      5-10 ans      487,000        937,000        1,500,000
     DE CONFORMITÉ                                                                            COMPTABLE

                       > 10 ans         -               -               -                                        > 10 ans      560,000        1,153,000      1,650,000


                        < 5 ans      200,000        388,000         700,000                                       < 5 ans         -               -              -
       CHARGÉ DE                                                                             RESPONSABLE
     COMMUNICATION/    5-10 ans      315,000        584,000        1,200,000                 CONTRÔLE DE         5-10 ans      720,000        1,377,000      2,450,000
       MARKETING                                                                               GESTION
                       > 10 ans         -               -               -                                        > 10 ans      940,000        1,583,000      2,811,000


                        < 5 ans      350,000        550,000         818,000                                       < 5 ans         -               -              -
                                                                                             RESPONSABLE
      COMPLIANCE                                                                               CONTRÔLE
                       5-10 ans      500,000        783,000        1,500,000                                     5-10 ans      830,000        1,220,000      1,740,000
        OFFICER                                                                                INTERNE/
                                                                                              PERMANENT
                       > 10 ans         -               -               -                                        > 10 ans     1,100,000       1,683,000      2,800,000


                        < 5 ans      394,000        518,000         872,000                                       < 5 ans         -               -              -

      CONTRÔLEUR                                                                           RESPONSABLE DE
                       5-10 ans      500,000        822,000        1,350,000                                     5-10 ans      813,000        1,154,000      1,600,000
       DE GESTION                                                                          LA CONFORMITÉ

                       > 10 ans         -               -               -                                        > 10 ans      989,000        1,579,000      2,684,000


                        < 5 ans      200,000        489,000         954,000                                       < 5 ans         -               -              -
      CONTRÔLEUR
                                                                                             RESPONSABLE
       INTERNE/        5-10 ans      300,000        773,000        1,300,000                                     5-10 ans      623,000        1,216,000      2,100,000
                                                                                              DES RISQUES
      PERMANENT
                       > 10 ans         -               -               -                                        > 10 ans     1,200,000       1,604,000      2,700,000


                        < 5 ans         -               -               -                                         < 5 ans         -               -              -
 RCCI/RESPONSABLE
 DE LA CONFORMITÉ                                                                            RESPONSABLE
                       5-10 ans         -               -               -                                        5-10 ans      800,000        1,182,000      2,500,000
  ET DU CONTRÔLE                                                                              TRÉSORERIE
      INTERNE
                       > 10 ans     1,250,000       1,694,000      2,400,000                                     > 10 ans     1,200,000       1,666,000      2,700,000


                        < 5 ans         -               -               -                                         < 5 ans      370,000        543,000         850,000

      RESPONSABLE
                       5-10 ans      750,000        1,579,000      2,000,000                   TRÉSORIER         5-10 ans      450,000        670,000        2,100,000
      AUDIT INTERNE

                       > 10 ans     1,104,000       1,876,000      2,465,000                                     > 10 ans      529,000        718,000        2,500,000




44                                                                Banque CÔTE D'IVOIRE   CÔTE D'IVOIRE Banque                                                             45
COMMERCIAL


       ASSURANCE       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                   ASSURANCE             EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                         < 5 ans      70,000         127,000            275,000                                           < 5 ans         -               -              -
       ASSISTANT
                                                                                                 RESPONSABLE
      COMMERCIAL/       5-10 ans      130,000        264,000            440,000                                          5-10 ans      496,000        828,000        1,456,000
                                                                                                 COMMERCIAL
        D’AGENCE
                        > 10 ans         -               -                  -                                            > 10 ans      610,000        1,220,000      1,790,000


                         < 5 ans      70,000         214,000            450,000                  RESPONSABLE              < 5 ans      280,000        571,000         850,000
         CHARGÉ
                                                                                                  COURTAGE/
      DE CLIENTÈLE/
                        5-10 ans      135,000        379,000            820,000                  RESPONSABLE             5-10 ans      410,000        727,000        1,680,000
       CONSEILLER
                                                                                                 COMMERCIAL
        CLIENTÈLE
                        > 10 ans      500,000        868,000           1,700,000                  COURTAGE               > 10 ans      592,000        1,165,000      2,400,000


                         < 5 ans      70,000         217,000            512,000                                           < 5 ans      213,000        434,000         650,000

      COMMERCIAL                                                                                RESPONSABLE
                        5-10 ans      158,000        378,000            664,000                                          5-10 ans      230,000        539,000         817,000
      PARTICULIERS                                                                            D’ÉQUIPE/PLATEAU

                        > 10 ans      309,000        514,000            850,000                                          > 10 ans         -               -              -


                         < 5 ans      187,000        353,000            612,000                                           < 5 ans         -               -              -
       COMMERCIAL
                                                                                                RESPONSABLE
     PROFESSIONNELS/    5-10 ans      235,000        444,000            800,000                                          5-10 ans      622,000        911,000        1,300,000
                                                                                               GRANDS COMPTES
         PME/PMI
                        > 10 ans      366,000        582,000           1,100,000                                         > 10 ans      780,000        1,128,000      1,650,000


                         < 5 ans      125,000        207,000            376,000                                           < 5 ans      65,000         225,000         350,000
        COURTIER/
                                                                                               TÉLÉCONSEILLER
       COMMERCIAL       5-10 ans      180,000        252,000            427,000                                          5-10 ans         -               -              -
                                                                                                EN ASSURANCE
        COURTAGE
                        > 10 ans         -               -                  -                                            > 10 ans         -               -              -


                         < 5 ans         -               -                  -

        DIRECTEUR
                        5-10 ans         -               -                  -
       COMMERCIAL

                        > 10 ans     1,600,000       2,488,000         3,500,000




46                                                                Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             47
                                                                                                  GRANDE
                                                                                              CONSOMMATION/             EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
         BANQUE        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT
                                                                                              GMS/CHR/RHF/GDS


                         < 5 ans      140,000        374,000            700,000                                           < 5 ans         -               -              -
                                                                                               CHEF DE SECTEUR
     ASSISTANT SALES    5-10 ans         -               -                  -                   GMS/CHR/GSB/             5-10 ans      304,000        550,000         780,000
                                                                                                  GSA/GSS
                        > 10 ans         -               -                  -                                            > 10 ans      420,000        719,000         977,000


                         < 5 ans      440,000        642,000           1,100,000                                          < 5 ans         -               -              -
         CHARGÉ
                                                                                               CHEF DES VENTES
       D’AFFAIRES
                        5-10 ans      618,000        853,000           1,540,000                  RÉGIONAL               5-10 ans      150,000        549,000        1,000,000
        GRANDES
                                                                                                  GMS/CHD
      ENTREPRISES
                        > 10 ans      755,000        1,150,000         1,736,000                                         > 10 ans      500,000        963,000        1,500,000


                         < 5 ans      300,000        550,000           1,000,000                                          < 5 ans         -               -              -
         CHARGÉ
                                                                                                   DIRECTEUR
       D’AFFAIRES       5-10 ans      450,000        1,096,000         1,834,000                                         5-10 ans         -               -              -
                                                                                                  COMMERCIAL
        PME/PMI
                        > 10 ans      620,000        1,015,000         1,843,000                                         > 10 ans     1,688,000       2,626,000      4,300,000


                         < 5 ans         -               -                  -                                             < 5 ans         -               -              -
     CHEF DE SERVICE                                                                              DIRECTEUR
       CLIENTÈLES       5-10 ans      645,000        1,450,000         2,100,000                   NATIONAL              5-10 ans         -               -              -
        PME/PMI                                                                                   DES VENTES
                        > 10 ans      800,000        1,810,000         3,600,000                                         > 10 ans      800,000        2,325,000      4,000,000


                         < 5 ans      200,000        350,000            600,000                                           < 5 ans         -               -              -
       CONSEILLER
                                                                                                 RESPONSABLE
        CLIENTÈLE       5-10 ans      230,000        441,000            800,000                                          5-10 ans      250,000        481,000        1,440,000
                                                                                                 COMMERCIAL
      PARTICULIERS
                        > 10 ans      389,000        504,000            920,000                                          > 10 ans      410,000        659,000        1,876,000


                         < 5 ans      233,000        388,000            741,000                                           < 5 ans         -               -              -
       CONSEILLER
                                                                                                 RESPONSABLE
        CLIENTÈLE       5-10 ans      298,000        470,000            919,000                                          5-10 ans      200,000        649,000        1,600,000
                                                                                                  DES VENTES
     PROFESSIONNELS
                        > 10 ans      410,000        557,000           1,144,000                                         > 10 ans      380,000        1,154,000      2,887,000


                         < 5 ans         -               -                  -                                             < 5 ans      150,000        337,000         650,000
       CONSEILLER                                                                                  TECHNICO-
       EN GESTION       5-10 ans      488,000        737,000           1,037,000                  COMMERCIAL             5-10 ans      196,000        374,000         846,000
      DE PATRIMOINE                                                                                ITINÉRANT
                        > 10 ans      721,000        1,030,000         1,450,000                                         > 10 ans      231,000        408,000         941,000




48                                                                Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             49
       HIGH TECH/                                                                                  HIGH TECH/
       SOFTWARE/        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                   SOFTWARE/             EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     HARDWARE/WEB                                                                                HARDWARE/WEB


         BUSINESS         < 5 ans      420,000        950,000           1,500,000                                          < 5 ans      135,000        547,000        1,050,000
       DEVELOPER/
                                                                                                  RESPONSABLE
        INGÉNIEUR        5-10 ans      538,000        1,320,000         2,530,000                                         5-10 ans      316,000        665,000        1,345,000
                                                                                                  COMMERCIAL
       COMMERCIAL
          B-TO-B         > 10 ans      668,000        1,973,000         4,100,000                                         > 10 ans      500,000        984,000        1,700,000


                          < 5 ans         -               -                  -                                             < 5 ans      150,000        328,000         650,000
                                                                                                    TECHNICO-
     CHEF DES VENTES/
                         5-10 ans      322,000        724,000           1,050,000                  COMMERCIAL             5-10 ans      200,000        548,000        1,200,000
      SALES MANAGER
                                                                                                    ITINÉRANT
                         > 10 ans      620,000        966,000           1,200,000                                         > 10 ans      418,000        832,000        2,032,000


                          < 5 ans      310,000        504,000            911,000
   COMMERCIAL
 GRANDS COMPTES/
                         5-10 ans      382,000        653,000           1,222,000
    ACCOUNT
    MANAGER                                                                                       HÔTELLERIE &
                         > 10 ans      450,000        976,000           2,032,000                                        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                 RESTAURATION


                          < 5 ans      130,000        314,000            850,000                                           < 5 ans      210,000        343,000         650,000
       COMMERCIAL
       SÉDENTAIRE/       5-10 ans      167,000        378,000           1,030,000                  COMMERCIAL             5-10 ans      244,000        398,000         836,000
       INSIDE SALES
                         > 10 ans         -               -                  -                                            > 10 ans      374,000        466,000        1,054,000


                          < 5 ans         -               -                  -                                             < 5 ans         -               -              -
        INGÉNIEUR
                                                                                                  RESPONSABLE
       COMMERCIAL        5-10 ans      344,000        588,000           1,122,000                                         5-10 ans      400,000        886,000        1,444,000
                                                                                                  COMMERCIAL
          B-TO-B
                         > 10 ans      471,000        863,000           1,847,000                                         > 10 ans      528,000        1,279,000      2,060,000


                          < 5 ans         -               -                  -                                             < 5 ans         -               -              -

        INGÉNIEUR                                                                                   DIRECTEUR
                         5-10 ans      470,000        994,000           2,500,000                                         5-10 ans         -               -              -
        D’AFFAIRES                                                                                 COMMERCIAL

                         > 10 ans      650,000        1,266,000         2,710,000                                         > 10 ans      800,000        1,781,000      2,884,000


                          < 5 ans         -               -                  -

        DIRECTEUR
                         5-10 ans         -               -                  -
       COMMERCIAL

                         > 10 ans     1,200,000       2,394,000         4,000,000




50                                                                 Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             51
     IMMOBILIER    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                    INDUSTRIE            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                     < 5 ans      150,000        292,000            522,000                      CHEF                 < 5 ans         -               -              -
                                                                                            DE TERRITOIRE
      ATTACHÉ
                    5-10 ans      210,000        343,000            831,000                   DE VENTES/             5-10 ans      300,000        638,000        1,450,000
     COMMERCIAL
                                                                                           TERRITORY SALES
                    > 10 ans         -               -                  -                      MANAGER               > 10 ans      500,000        927,000        2,000,000


                     < 5 ans         -               -                  -                                             < 5 ans      180,000        414,000        1,566,000
                                                                                             CHEF DE ZONE
      DIRECTEUR                                                                               DE VENTES/
                    5-10 ans         -               -                  -                                            5-10 ans      298,000        676,000        2,000,000
     COMMERCIAL                                                                               AREA SALES
                                                                                               MANAGER
                    > 10 ans     1,000,000       2,156,000         3,700,000                                         > 10 ans      300,000        1,071,000      3,000,000


                     < 5 ans         -               -                  -                                             < 5 ans         -               -              -

     RESPONSABLE                                                                             CHEF DE ZONE
                    5-10 ans      410,000        768,000           1,574,000                                         5-10 ans      424,000        667,000        1,300,000
     COMMERCIAL                                                                                EXPORT

                    > 10 ans      640,000        1,127,000         2,463,000                                         > 10 ans      577,000        969,000        1,711,000


                     < 5 ans      100,000        257,000            520,000                                           < 5 ans         -               -              -

      TECHNICO-                                                                                DIRECTEUR
                    5-10 ans      135,000        355,000            850,000                                          5-10 ans         -               -              -
     COMMERCIAL                                                                               COMMERCIAL

                    > 10 ans      248,000        512,000           1,440,000                                         > 10 ans     1,000,000       2,528,000      5,000,000


                                                                                                                      < 5 ans         -               -              -
                                                                                              DIRECTEUR
                                                                                              NATIONAL
                                                                                                                     5-10 ans         -               -              -
                                                                                             DES VENTES/
                                                                                            SALES DIRECTOR
      INDUSTRIE    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                                          > 10 ans     1,320,000       2,466,000      3,500,000


                     < 5 ans         -               -                  -                                             < 5 ans         -               -              -
                                                                                             DIRECTEUR
       BUSINESS                                                                             RÉGIONAL DES
                    5-10 ans      764,000        1,416,000         2,100,000                                         5-10 ans         -               -              -
      DEVELOPER                                                                            VENTES/CLUSTER
                                                                                           SALES DIRECTOR
                    > 10 ans      914,000        1,948,000         3,000,000                                         > 10 ans     1,470,000       2,774,000      4,077,000


                     < 5 ans         -               -                  -                                             < 5 ans      220,000        569,000        1,400,000

        CHARGÉ                                                                               RESPONSABLE
                    5-10 ans      200,000        441,000            840,000                                          5-10 ans      245,000        748,000        1,740,000
      D’AFFAIRES                                                                             COMMERCIAL

                    > 10 ans      310,000        682,000           1,377,000                                         > 10 ans      311,000        1,347,000      3,773,000




52                                                            Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             53
                                                                                                   SERVICES/
        INDUSTRIE     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                      B-TO-B/            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                    MÉDIAS

                        < 5 ans         -               -                  -                                             < 5 ans         -               -              -

      RESPONSABLE
                       5-10 ans      350,000        516,000            853,000                CHEF DES VENTES           5-10 ans      275,000        577,000        1,600,000
     GRANDS COMPTES

                       > 10 ans      415,000        790,000           1,300,000                                         > 10 ans      386,000        1,160,000      2,100,000


      RESPONSABLE       < 5 ans         -               -                  -                                             < 5 ans      75,000         196,000         500,000
        NATIONAL
                                                                                                 COMMERCIAL
       DES VENTES/     5-10 ans      250,000        913,000           2,740,000                                         5-10 ans      130,000        285,000         774,000
                                                                                                   B-TO-C
     COUNTRY SALES
        MANAGER        > 10 ans      615,000        1,579,000         4,300,000                                         > 10 ans      185,000        413,000         922,000


       RESPONSABLE      < 5 ans         -               -                  -                                             < 5 ans      241,000        445,000         600,000
         RÉGIONAL
                                                                                                COMMERCIAL
        DES VENTES/    5-10 ans      460,000        904,000           2,140,000                                         5-10 ans      288,000        622,000        1,200,000
                                                                                              GRANDS COMPTES
      CLUSTER SALES
         MANAGER)      > 10 ans      606,000        1,491,000         2,887,000                                         > 10 ans      315,000        720,000        1,500,000


                        < 5 ans      100,000        336,000           1,000,000                                          < 5 ans      80,000         185,000         410,000
       TECHNICO-
                                                                                                 COMMERCIAL
      COMMERCIAL       5-10 ans      233,000        463,000           1,220,000                                         5-10 ans      100,000        274,000         533,000
                                                                                                 SÉDENTAIRE
       ITINÉRANT
                       > 10 ans      500,000        588,000           1,750,000                                         > 10 ans      115,000        304,000         700,000


                                                                                                                         < 5 ans         -               -              -

                                                                                                 CONSULTANT
                                                                                                                        5-10 ans         -               -              -
        SERVICES/                                                                                COMMERCIAL
         B-TO-B/      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT
                                                                                                                        > 10 ans      400,000        1,681,000      5,904,000
         MÉDIAS

                        < 5 ans      70,000         373,000           1,110,000                                          < 5 ans         -               -              -
 ATTACHÉ/DÉLÉGUÉ/
                                                                                                  DIRECTEUR
   COMMERCIAL          5-10 ans      150,000        455,000           1,478,000                                         5-10 ans      450,000        1,463,000      3,115,000
                                                                                                 COMMERCIAL
      B-TO-B
                       > 10 ans      160,000        609,000           1,641,000                                         > 10 ans      787,000        2,421,000      4,860,000


                        < 5 ans      200,000        916,000           1,379,000                                          < 5 ans         -               -              -

        BUSINESS                                                                                  DIRECTEUR
                       5-10 ans      330,000        1,204,000         2,647,000                                         5-10 ans         -               -              -
       DEVELOPER                                                                                 DE CLIENTÈLE

                       > 10 ans      410,000        1,453,000         2,952,000                                         > 10 ans     1,500,000       2,125,000      5,200,000




54                                                               Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             55
        SERVICES/                                                                                  SERVICES/
         B-TO-B/      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                      B-TO-B/            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
         MÉDIAS                                                                                     MÉDIAS

                        < 5 ans         -               -                  -                                             < 5 ans      150,000        205,000         330,000
       DIRECTEUR
                                                                                                SUPERVISEUR/
       NATIONAL
                       5-10 ans         -               -                  -                    RESPONSABLE             5-10 ans      167,000        337,000         650,000
      DES VENTES/
                                                                                                 TÉLÉVENTE
     SALES DIRECTOR
                       > 10 ans     1,127,000       2,083,000         3,100,000                                         > 10 ans         -              -               -


        DIRECTEUR       < 5 ans         -               -                  -                                             < 5 ans      100,000        308,000         650,000
        RÉGIONAL                                                                                  TECHNICO-
       DES VENTES/     5-10 ans         -               -                  -                     COMMERCIAL             5-10 ans      150,000        499,000        1,300,000
      CLUSTER SALES                                                                               ITINÉRANT
        DIRECTOR       > 10 ans     1,200,000       2,641,000         4,861,000                                         > 10 ans      180,000        618,000        1,584,000


                        < 5 ans      250,000        446,000           1,500,000                                          < 5 ans      70,000         132,000         300,000

       INGÉNIEUR
                       5-10 ans      270,000        780,000           1,720,000               TÉLÉCONSEILLER            5-10 ans      118,000        203,000         424,000
      COMMERCIAL

                       > 10 ans      350,000        972,000           2,000,000                                         > 10 ans         -              -               -


                        < 5 ans         -               -                  -

      RESPONSABLE
                       5-10 ans      175,000        654,000           1,300,000
       CLIENTÈLE

                       > 10 ans      380,000        761,000           1,425,000


                        < 5 ans      200,000        568,000           2,450,000

      RESPONSABLE
                       5-10 ans      200,000        854,000           3,600,000
      COMMERCIAL

                       > 10 ans      250,000        1,165,000         5,100,000


                        < 5 ans      450,000        538,000            750,000

      RESPONSABLE
                       5-10 ans      500,000        740,000           1,000,000
     GRANDS COMPTES

                       > 10 ans      652,000        1,637,000         2,384,000


      RESPONSABLE       < 5 ans         -               -                  -
        NATIONAL
       DES VENTES/     5-10 ans      360,000        726,000           1,318,000
     COUNTRY SALES
        MANAGER        > 10 ans      614,000        1,393,000         2,000,000




56                                                               Commercial CÔTE D'IVOIRE   CÔTE D'IVOIRE Commercial                                                             57
CONSTRUCTION


      ARCHITECTURE
        & BUREAUX        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT                     BÂTIMENT              EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DE CONTRÔLE

                           < 5 ans      410,000        775,000             2,100,000                                            < 5 ans      150,000        220,000         500,000
 ARCHITECTE MOEX                                                                                  CHEF DE CHANTIER
      MAITRISE D'ŒUVRE    5-10 ans      743,000        1,074,000           2,844,000                                           5-10 ans      244,000        355,000         740,000
        D'EXÉCUTION                                                                                  BÂTIMENT

                          > 10 ans         -               -                    -                                              > 10 ans      361,000        420,000        1,004,000


                           < 5 ans         -               -                    -                                               < 5 ans         -               -              -

       ARCHITECTE                                                                                  CHEF DE PROJETS
                          5-10 ans     1,660,000       2,488,000           4,000,000                                           5-10 ans      350,000        758,000        1,350,000
         SENIOR                                                                                       BÂTIMENT

                          > 10 ans      250,000        735,000             1,700,000                                           > 10 ans      480,000        1,144,000      2,100,000


                           < 5 ans         -               -                    -                                               < 5 ans      150,000        439,000         940,000
                                                                                                      CONDUCTEUR
     COLLABORATEUR
                          5-10 ans      100,000        307,000              600,000                   DE TRAVAUX               5-10 ans      310,000        523,000        1,560,000
       ARCHITECTE
                                                                                                       BÂTIMENT
                          > 10 ans      300,000        388,000              867,000                                            > 10 ans         -               -              -


                           < 5 ans         -               -                    -                                               < 5 ans         -               -              -
                                                                                                      DIRECTEUR
      DESSINATEUR
                          5-10 ans      384,000        577,000             1,100,000                  DE PROJETS               5-10 ans         -               -              -
       PROJETEUR
                                                                                                       BÂTIMENT
                          > 10 ans      511,000        833,000             1,475,000                                           > 10 ans     1,250,000       2,846,000      5,904,000


                           < 5 ans      185,000        407,000              600,000                                             < 5 ans         -               -              -
                                                                                                       DIRECTEUR
      RESPONSABLE
                          5-10 ans         -               -                    -                     DE TRAVAUX               5-10 ans      900,000        1,740,000      2,700,000
     BUREAU D’ÉTUDES
                                                                                                       BÂTIMENT
                          > 10 ans                                                                                             > 10 ans     1,100,000       2,340,000      4,460,000


                           < 5 ans      100,000        237,000              420,000                                             < 5 ans         -               -              -

       TECHNICIEN                                                                                      DIRECTEUR
                          5-10 ans      185,000        407,000              600,000                                            5-10 ans         -               -              -
     ÉTUDES DE PRIX                                                                                    TECHNIQUE

                          > 10 ans         -               -                    -                                              > 10 ans     1,500,000       2,550,000      4,500,000




58                                                                  Construction CÔTE D'IVOIRE   CÔTE D'IVOIRE Construction                                                             59
        BÂTIMENT        EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN       SALAIRE HAUT              TRAVAUX PUBLICS             EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                          < 5 ans         -               -                    -                                               < 5 ans         -               -              -
        INGÉNIEUR                                                                                   DIRECTEUR
        PRINCIPAL        5-10 ans      500,000        1,277,000           1,888,000                DE PROJETS                 5-10 ans         -               -              -
     GRANDS PROJETS                                                                              TRAVAUX PUBLICS
                         > 10 ans      656,000        1,518,000           3,149,000                                           > 10 ans     2,800,000       4,016,000      6,560,000


                          < 5 ans         -               -                    -                                               < 5 ans         -               -              -

      RESPONSABLE                                                                                    DIRECTEUR
                         5-10 ans      427,000        878,000             1,890,000                                           5-10 ans     1,103,000       1,996,000      3,164,000
       DE TRAVAUX                                                                                  DE TRAVAUX TP

                         > 10 ans      533,000        1,218,000           2,748,000                                           > 10 ans     1,469,000       2,634,000      4,133,000


                          < 5 ans         -               -                    -                                               < 5 ans         -               -              -

      RESPONSABLE                                                                                     DIRECTEUR
                         5-10 ans      275,000        567,000             1,404,000                                           5-10 ans         -               -              -
       TECHNIQUE                                                                                      TECHNIQUE

                         > 10 ans      440,000        897,000             1,864,000                                           > 10 ans     2,140,000       3,210,000      7,708,000


                                                                                                                               < 5 ans      420,000        620,000         946,000

                                                                                                      INGÉNIEUR
                                                                                                                              5-10 ans      512,000        722,000        1,142,000
                                                                                                       TRAVAUX
     TRAVAUX PUBLICS    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN       SALAIRE HAUT                                           > 10 ans      671,000        883,000        1,745,000


                          < 5 ans      201,000        317,000              570,000                                             < 5 ans         -               -              -

     CHEF DE CHANTIER                                                                               RESPONSABLE
                         5-10 ans      246,000        424,000              750,000                                            5-10 ans      542,000        963,000        2,000,000
     TRAVAUX PUBLICS                                                                                 DE TRAVAUX

                         > 10 ans      345,000        522,000              974,000                                            > 10 ans      854,000        1,278,000      3,280,000


                          < 5 ans         -               -                    -                                               < 5 ans         -               -              -

     CHEF DE PROJETS                                                                                RESPONSABLE
                         5-10 ans      430,000        812,000             1,446,000                                           5-10 ans      508,000        751,000         994,000
     TRAVAUX PUBLICS                                                                                 TECHNIQUE

                         > 10 ans      541,000        1,233,000           2,444,000                                           > 10 ans      617,000        1,104,000      1,740,000


                          < 5 ans      200,000        474,000              900,000                                             < 5 ans      280,000        428,000         800,000

       CONDUCTEUR
                         5-10 ans      376,000        660,000             1,488,000                  TOPOGRAPHE               5-10 ans      342,000        548,000        1,200,000
      DE TRAVAUX TP

                         > 10 ans      581,000        876,000             1,842,000                                           > 10 ans         -               -              -




60                                                                 Construction CÔTE D'IVOIRE   CÔTE D'IVOIRE Construction                                                             61
                                                                                            DIGITAL, MARKETING
                                                                                            & COMMUNICATION

      IMMOBILIER    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT                COMMUNICATION                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                      < 5 ans      150,000        220,000              600,000                                                  < 5 ans          110,000        268,000         450,000

     GESTIONNAIRE                                                                               CHARGÉ DE
                     5-10 ans      250,000        368,000              830,000                                                 5-10 ans          186,000        381,000         800,000
      IMMOBILIER                                                                              COMMUNICATION

                     > 10 ans         -              -                     -                                                   > 10 ans             -               -              -


                      < 5 ans      150,000        400,000              600,000                                                  < 5 ans          160,000        330,000         549,000
                                                                                                   CHARGÉ
     GESTIONNAIRE                                                                              DES RELATIONS
                     5-10 ans      300,000        700,000             1,000,000                                                5-10 ans          190,000        507,000         800,000
       LOCATIF                                                                                   PUBLIQUES
                                                                                                  & PRESSE
                     > 10 ans                                                                                                  > 10 ans          230,000        670,000        1,000,000


                      < 5 ans         -              -                     -                                                    < 5 ans          188,000        311,000         844,000

     RESPONSABLE                                                                                   CHARGÉ
                     5-10 ans      350,000        680,000             1,251,000                                                5-10 ans          200,000        446,000        1,200,000
      IMMOBILIER                                                                               D'ÉVÉNEMENTIEL

                     > 10 ans      477,000        838,000             1,600,000                                                > 10 ans             -               -              -


                                                                                                                                < 5 ans             -               -              -

                                                                                                DIRECTEUR
                                                                                                                               5-10 ans             -               -              -
                                                                                              COMMUNICATION

                                                                                                                               > 10 ans          900,000        2,350,000      4,100,000


                                                                                                                                < 5 ans             -               -              -
                                                                                                DIRECTEUR
                                                                                                 D'AGENCE
                                                                                                                               5-10 ans             -               -              -
                                                                                              COMMUNICATION/
                                                                                                MARKETING
                                                                                                                               > 10 ans         1,200,000       2,300,000      4,000,000


                                                                                                                                < 5 ans          150,000        500,000        1,200,000

                                                                                               RESPONSABLE
                                                                                                                               5-10 ans          300,000        721,000        1,500,000
                                                                                              COMMUNICATION

                                                                                                                               > 10 ans          550,000        1,142,000      2,626,000




62                                                             Construction CÔTE D'IVOIRE   CÔTE D'IVOIRE Digital, Marketing& Communication                                                63
 DESIGN & CRÉATION     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                      DIGITAL                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                         < 5 ans         -                -                          -                                                    < 5 ans          250,000        380,000         640,000

       DIRECTEUR                                                                                         CHEF DE PROJET
                        5-10 ans      450,000        1,037,000                 2,250,000                                                 5-10 ans          400,000        579,000         850,000
       ARTISTIQUE                                                                                         WEB/DIGITAL

                        > 10 ans      650,000        1,385,000                 2,670,000                                                 > 10 ans          517,000        663,000        1,105,000


                         < 5 ans      200,000        338,000                    700,000                                                   < 5 ans          80,000         257,000         525,000

                                                                                                           COMMUNITY
       GRAPHISTE        5-10 ans      250,000        408,000                    832,000                                                  5-10 ans          150,000        376,000         660,000
                                                                                                            MANAGER

                        > 10 ans      398,000        513,000                   1,017,000                                                 > 10 ans          370,000        588,000        1,000,000


                         < 5 ans      110,000        311,000                    550,000                                                   < 5 ans          370,000        408,000        1,400,000

     INFOGRAPHISTE      5-10 ans      150,000        428,000                    760,000                   DATA ANALYST                   5-10 ans          400,000        567,000        2,300,000

                        > 10 ans      330,000        555,000                   1,300,000                                                 > 10 ans             -               -              -


                         < 5 ans      150,000        365,000                    600,000                                                   < 5 ans          350,000        446,000         650,000

                                                                                                        DIGITAL CONTENT
     MOTION DESIGNER    5-10 ans      285,000        528,000                    878,000                                                  5-10 ans          410,000        565,000         940,000
                                                                                                            MANAGER

                        > 10 ans         -                -                          -                                                   > 10 ans             -               -              -


                         < 5 ans      220,000        383,000                    650,000                                                   < 5 ans          220,000        392,000         850,000

                                                                                                          RESPONSABLE
      UI/UX DESIGNER    5-10 ans      404,000        620,000                   1,000,000                                                 5-10 ans          250,000        554,000        1,000,000
                                                                                                             DIGITAL

                        > 10 ans         -                -                          -                                                   > 10 ans          427,000        1,045,000      1,650,000


                                                                                                                                          < 5 ans          250,000        380,000         650,000

                                                                                                          SOCIAL MEDIA
                                                                                                                                         5-10 ans          360,000        514,000         775,000
                                                                                                            MANAGER
         DIGITAL       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                 > 10 ans          441,000        627,000         994,000


                         < 5 ans      250,000        370,000                    710,000                                                   < 5 ans          260,000        410,000         650,000
       CHARGÉ DE
     COMMUNICATION      5-10 ans      440,000        466,000                    900,000                   WEB DESIGNER                   5-10 ans          300,000        464,000         802,000
        DIGITALE
                        > 10 ans         -                -                          -                                                   > 10 ans          377,000        552,000        1,013,000




64                                                 Digital, Marketing& Communication CÔTE D'IVOIRE   CÔTE D'IVOIRE Digital, Marketing& Communication                                                65
        DIGITAL       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                    MARKETING                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                        < 5 ans      179,000        330,000                    505,000                                                   < 5 ans          300,000        640,000        1,200,000

                                                                                                           CATEGORY
      WEBMASTER        5-10 ans      275,000        402,000                    678,000                                                  5-10 ans          410,000        956,000        1,750,000
                                                                                                           MANAGER

                       > 10 ans      369,000        496,000                    945,000                                                  > 10 ans          500,000        1,168,000      1,833,000


                                                                                                                                         < 5 ans          120,000        509,000        1,509,000

                                                                                                       CHARGÉ D'ÉTUDES
                                                                                                                                        5-10 ans          275,000        731,000        1,800,000
                                                                                                         MARKETING
       MARKETING      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                 > 10 ans             -               -              -


                        < 5 ans      275,000        388,000                    600,000                                                   < 5 ans          220,000        421,000         801,000

       ANALYSTE                                                                                        CHARGÉ DE TRADE
                       5-10 ans      350,000        455,000                    900,000                                                  5-10 ans          300,000        556,000        1,106,000
       MARKETING                                                                                         MARKETING

                       > 10 ans         -                -                          -                                                   > 10 ans          330,000        673,000        1,300,000


                                                                                                                                         < 5 ans          234,000        375,000         840,000
                        < 5 ans      100,000        280,000                    600,000
                                                                                                            CHARGÉ
     ASSISTANT CHEF                                                                                                                     5-10 ans          340,000        511,000        1,100,000
                       5-10 ans      180,000        406,000                    705,000                     MARKETING
      DE PRODUITS
                                                                                                                                        > 10 ans          397,000        704,000        1,462,000
                       > 10 ans         -                -                          -

                                                                                                                                         < 5 ans          370,000        778,000        1,200,000
                        < 5 ans      85,000         189,000                    405,000
                                                                                                       CHEF DE PRODUIT
       ASSISTANT                                                                                                                        5-10 ans          550,000        1,023,000      1,500,000
                       5-10 ans         -                -                          -                    INDUSTRIEL
       MARKETING
                                                                                                                                        > 10 ans          714,000        1,336,000      1,886,000
                       > 10 ans         -                -                          -

                                                                                                                                         < 5 ans          275,000        646,000        1,100,000
                        < 5 ans      120,000        275,000                    460,000
                                                                                                       CHEF DE PRODUIT
    ASSISTANT                                                                                                                           5-10 ans          480,000        934,000        1,430,000
                       5-10 ans      242,000        390,000                    600,000                    SERVICES
 TRADE MARKETING
                                                                                                                                        > 10 ans          700,000        1,181,000      1,800,000
                       > 10 ans         -                -                          -

                                                                                                                                         < 5 ans          250,000        593,000        1,425,000
                        < 5 ans      200,000        642,000                   1,350,000

                                                                                                       CHEF DE PROJETS                  5-10 ans          300,000        709,000        1,650,000
     BRAND MANAGER     5-10 ans      250,000        975,000                   3,000,000

                                                                                                                                        > 10 ans          500,000        911,000        2,295,000
                       > 10 ans      537,000        1,491,000                 4,000,000




66                                                Digital, Marketing& Communication CÔTE D'IVOIRE   CÔTE D'IVOIRE Digital, Marketing& Communication                                                67
                                                                                                    DISTRIBUTION
                                                                                                    & RETAIL SPÉCIALISÉ

                                                                                                          FONCTIONS
     MARKETING       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                          SUPPORTS


                       < 5 ans      175,000        387,000                    600,000                                                     < 5 ans      80,000         187,000         320,000

 CHEF DE PUBLICITÉ    5-10 ans      300,000        573,000                   1,200,000                 MERCHANDISER                      5-10 ans      110,000        212,000         373,000

                      > 10 ans      410,000        728,000                   1,622,000                                                   > 10 ans      166,000        295,000         510,000


                       < 5 ans         -                -                          -                                                      < 5 ans      85,000         145,000         245,000

     DIRECTEUR                                                                                          PRÉPARATEUR
                      5-10 ans      300,000        1,331,000                 4,000,000                                                   5-10 ans      110,000        184,000         291,000
     MARKETING                                                                                          DE COMMANDE

                      > 10 ans      811,000        2,310,000                 5,000,000                                                   > 10 ans         -               -              -


                       < 5 ans      200,000        855,000                   3,000,000

     RESPONSABLE
                      5-10 ans      250,000        1,030,000                 1,890,000
      MARKETING
                                                                                                            GRANDE
                      > 10 ans      550,000        1,268,000                 2,000,000                                                EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                         DISTRIBUTION


                       < 5 ans         -                -                          -                                                      < 5 ans         -               -              -

   RESPONSABLE                                                                                             DIRECTEUR
                      5-10 ans      476,000        1,011,000                 2,240,000                      MAGASIN                      5-10 ans         -               -              -
 TRADE MARKETING                                                                                          HYPERMARCHÉ

                      > 10 ans      675,000        1,354,000                 2,600,000                                                   > 10 ans      870,000        1,364,000      2,440,000


                                                                                                                                          < 5 ans         -               -              -
                                                                                                           DIRECTEUR
                                                                                                            MAGASIN                      5-10 ans         -               -              -
                                                                                                          SUPERMARCHÉ

                                                                                                                                         > 10 ans      429,000        941,000        2,000,000


                                                                                                                                          < 5 ans         -               -              -
                                                                                                            CHEF
                                                                                                      DE DÉPARTEMENT/                    5-10 ans      357,000        508,000         844,000
                                                                                                      CHEF DE SECTEUR
                                                                                                          HYPERMARCHÉ
                                                                                                                                         > 10 ans      510,000        782,000        1,330,000




68                                               Digital, Marketing& Communication CÔTE D'IVOIRE   CÔTE D'IVOIRE Distribution & Retail Spécialisé                                                69
          GRANDE                                                                                                   GRANDE
                           EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                 EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DISTRIBUTION                                                                                             DISTRIBUTION


                             < 5 ans         -              -                            -                                                       < 5 ans      85,000         110,000         166,000
           CHEF                                                                                                   VENDEUR
     DE DÉPARTEMENT/        5-10 ans      336,000        440,000                    725,000                      & ÉQUIPIER                     5-10 ans      100,000        137,000         200,000
     CHEF DE SECTEUR                                                                                            POLYVALENT
        SUPERMARCHÉ
                            > 10 ans      469,000        623,000                    940,000                                                     > 10 ans      122,000        177,000         260,000


                             < 5 ans         -              -                            -                                                       < 5 ans         -               -              -
                                                                                                                 DIRECTEUR
       RESPONSABLE
                                                                                                                D’EXPANSION/
         MAGASIN            5-10 ans      248,000        479,000                    737,000                                                     5-10 ans         -               -              -
                                                                                                               DU DÉVELOPPE-
       DE PROXIMITÉ
                                                                                                                    MENT
                            > 10 ans      400,000        717,000                   1,000,000                                                    > 10 ans     1,300,000       2,114,000      4,000,000


                             < 5 ans         -              -                            -                                                       < 5 ans         -               -              -
     MANAGER D'UNITÉ                                                                                          DISTRIBUTION
      COMMERCIALE           5-10 ans      288,000        343,000                    550,000                      SALES                          5-10 ans      362,000        531,000         985,000
       MANAGER RAYON
     & MANAGER BOUTIQUE                                                                                      REPRESENTATIVE
                            > 10 ans      340,000        466,000                    700,000                                                     > 10 ans      400,000        703,000        1,550,000


                             < 5 ans         -              -                            -                                                       < 5 ans         -               -              -
 MANAGER ADJOINT                                                                                               RESPONSABLE
        HYPERMARCHÉ,                                                                                            D’EXPANSION/
     SUPERMACHÉ, MARKET     5-10 ans      180,000        240,000                    364,000                                                     5-10 ans      350,000        1,020,000      1,818,000
         & ENSEIGNE                                                                                            DU DÉVELOPPE-
         DE MARQUES                                                                                                 MENT
                            > 10 ans      231,000        338,000                    547,000                                                     > 10 ans      500,000        1,274,000      2,211,000


                             < 5 ans         -              -                            -

 MANAGER ADJOINT            5-10 ans      140,000        186,000                    260,000
 MAGASIN DE PROXIMITÉ

                            > 10 ans      175,000        222,000                    375,000                 RETAIL SPÉCIALISÉ                EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                             < 5 ans      147,000        178,000                    255,000                                                      < 5 ans         -               -              -
                                                                                                               RESPONSABLE
       SUPERVISEUR
                            5-10 ans      170,000        195,000                    330,000                      ENSEIGNE                       5-10 ans         -               -              -
     ET CHEF D'ÉQUIPE
                                                                                                                DE MARQUES
                            > 10 ans         -              -                            -                                                      > 10 ans     1,100,000       1,660,000      2,400,000


                             < 5 ans      90,000         127,000                    220,000                                                      < 5 ans         -               -              -
         EMPLOYÉ                                                                                              RESPONSABLE
        SPÉCIALISÉ          5-10 ans      120,000        154,000                    288,000                 ADJOINT ENSEIGNE                    5-10 ans      321,000        482,000         745,000
     BOUCHER, BOULANGER,
         CAISSIER…                                                                                             DE MARQUES
                            > 10 ans      145,000        191,000                    413,000                                                     > 10 ans      522,000        724,000        1,110,000




70                                                        Distribution & Retail Spécialisé CÔTE D'IVOIRE   CÔTE D'IVOIRE Distribution & Retail Spécialisé                                                71
FACILITY MANAGEMENT
& SERVICES GÉNÉRAUX

     FM/SERVICES                                                                                           MAINTENANCE
                    EXPÉRIENCE   SALAIRE BAS     SALAIRE MOYEN               SALAIRE HAUT                                              EXPÉRIENCE              SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      GÉNÉRAUX                                                                                             & ENTRETIEN


                      < 5 ans      200,000             267,000                    480,000                                                  < 5 ans               300,000        619,000        1,200,000
      ASSISTANT                                                                                             INGÉNIEUR
       SERVICES      5-10 ans      282,000             322,000                    600,000                  MAINTENANCE                    5-10 ans               440,000        763,000        1,600,000
      GÉNÉRAUX                                                                                                 FM
                     > 10 ans         -                    -                          -                                                   > 10 ans               625,000        887,000        2,020,000


                      < 5 ans         -                    -                          -                                                    < 5 ans                  -              -               -
                                                                                                          RESPONSABLE
 FACILITY MANAGER    5-10 ans      350,000             573,000                   1,100,000               DE MAINTENANCE                   5-10 ans               432,000        716,000        1,443,000
                                                                                                               FM
                     > 10 ans      488,000             776,000                   1,600,000                                                > 10 ans               611,000        928,000        1,870,000


                      < 5 ans         -                    -                          -                                                    < 5 ans                  -              -               -

     RESPONSABLE                                                                                           RESPONSABLE
                     5-10 ans      540,000             733,000                   1,200,000                                                5-10 ans               400,000        670,000        1,100,000
     DES CONTRATS                                                                                             DE SITE

                     > 10 ans      777,000            1,040,000                  1,500,000                                                > 10 ans               475,000        796,000        1,480,000


                      < 5 ans         -                    -                          -
     RESPONSABLE
       SERVICES      5-10 ans      455,000             677,000                   1,410,000
      GÉNÉRAUX
                     > 10 ans      583,000             820,000                   1,650,000




      FONCTIONS
                    EXPÉRIENCE   SALAIRE BAS     SALAIRE MOYEN               SALAIRE HAUT
     TRANSVERSES


                      < 5 ans         -                    -                          -

     RESPONSABLE
                     5-10 ans      400,000             854,000                   1,500,000
       D'ÉTUDES

                     > 10 ans      476,000            1,005,000                  1,900,000




72                                             Facility Management & Services Généraux CÔTE D'IVOIRE   CÔTE D'IVOIRE Facility Management & Services Généraux                                                73
FINANCE
& COMPTABILITÉ

       FONCTIONS                                                                                             FONCTIONS
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                                EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      COMPTABLES                                                                                            COMPTABLES


                        < 5 ans      90,000         165,000                      400,000                                                      < 5 ans      100,000        308,000         850,000

                                                                                                             COMPTABLE
     AIDE-COMPTABLE    5-10 ans         -               -                             -                                                       5-10 ans     140,000        346,000         910,000
                                                                                                              GÉNÉRAL

                       > 10 ans         -               -                             -                                                       > 10 ans     240,000        510,000        1,113,000


                        < 5 ans      280,000        520,000                      910,000                                                      < 5 ans      185,000        260,000         450,000
         CHEF/
                                                                                                           COMPTABLE
      RESPONSABLE      5-10 ans      310,000        829,000                     2,100,000                                                     5-10 ans     216,000        380,000         516,000
                                                                                                         IMMOBILISATIONS
       COMPTABLE
                       > 10 ans      480,000        1,417,000                   3,500,000                                                     > 10 ans     288,000        464,000         800,000


                        < 5 ans      250,000        446,000                      700,000                                                      < 5 ans      160,000        264,000         448,000
         CHEF/
      RESPONSABLE
                       5-10 ans      300,000        773,000                     1,441,000                COMPTABLE PAIE                       5-10 ans     221,000        411,000         680,000
       COMPTABLE
        ADJOINT
                       > 10 ans      430,000        1,100,000                   2,200,000                                                     > 10 ans     403,000        651,000        1,300,000


                        < 5 ans      120,000        237,000                      550,000                                                      < 5 ans         -               -              -
                                                                                                            COMPTABLE
       COMPTABLE
                       5-10 ans      180,000        285,000                      700,000                   SUPERVISEUR/                       5-10 ans     200,000        520,000        1,500,000
       ANALYTIQUE
                                                                                                         SENIOR/CONFIRMÉ
                       > 10 ans      250,000        374,000                      915,000                                                      > 10 ans     325,000        770,000        1,800,000


                        < 5 ans      180,000        255,000                      403,000                                                      < 5 ans      235,000        366,000         622,000

       COMPTABLE                                                                                             COMPTABLE
                       5-10 ans      240,000        361,000                      670,000                                                      5-10 ans     250,000        445,000         850,000
        CLIENTS                                                                                              TRÉSORERIE

                       > 10 ans      315,000        585,000                     1,000,000                                                     > 10 ans     315,000        688,000        1,300,000


                        < 5 ans      175,000        269,000                      450,000                                                      < 5 ans         -               -              -
                                                                                                           RESPONSABLE
       COMPTABLE                                                                                              DE PÔLE
                       5-10 ans      260,000        370,000                      600,000                                                      5-10 ans     400,000        733,000        1,215,000
      FOURNISSEURS                                                                                         COMPTABILITÉ
                                                                                                             GÉNÉRALE
                       > 10 ans      300,000        542,000                      870,000                                                      > 10 ans     850,000        1,413,000      2,200,000




74                                                              Finance & Comptabilité CÔTE D'IVOIRE   CÔTE D'IVOIRE Finance & Comptabilité                                                           75
  FONCTIONS CON-                                                                                        FONCTIONS CON-
 TRÔLE DE GESTION,                                                                                     TRÔLE DE GESTION,
                     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                                EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
  CONSOLIDATION                                                                                         CONSOLIDATION
  & AUDIT INTERNE                                                                                       & AUDIT INTERNE


                       < 5 ans      150,000        380,000                      700,000                                                      < 5 ans         -               -              -
      ASSISTANT
                                                                                                        CONTRÔLEUR DE
     CONTRÔLEUR       5-10 ans         -               -                             -                                                       5-10 ans     700,000        1,520,000      3,000,000
                                                                                                        GESTION GROUPE
      DE GESTION
                      > 10 ans         -               -                             -                                                       > 10 ans    1,100,000       2,152,000      4,500,000


                       < 5 ans      200,000        378,000                      730,000                                                      < 5 ans      200,000        645,000        1,000,000
                                                                                                           CONTRÔLEUR
      ASSISTANT
                      5-10 ans      230,000        462,000                      900,000                     DE GESTION                       5-10 ans     250,000        738,000        2,200,000
      DE GESTION
                                                                                                            INDUSTRIEL
                      > 10 ans      250,000        533,000                     1,070,000                                                     > 10 ans     392,000        1,023,000      2,800,000


                       < 5 ans      195,000        367,000                      645,000                                                      < 5 ans      266,000        484,000        1,500,000

      ASSISTANT                                                                                            CONTRÔLEUR
                      5-10 ans      250,000        558,000                      987,000                                                      5-10 ans     300,000        591,000        2,100,000
      FINANCIER                                                                                             FINANCIER

                      > 10 ans         -               -                             -                                                       > 10 ans     553,000        1,216,000      2,560,000


                       < 5 ans      140,000        681,000                     1,249,000                                                     < 5 ans      200,000        504,000        1,000,000

                                                                                                           CONTRÔLEUR
 AUDITEUR INTERNE     5-10 ans      260,000        832,000                     1,650,000                                                     5-10 ans     280,000        772,000        1,264,000
                                                                                                             INTERNE

                      > 10 ans      410,000        913,000                     1,911,000                                                     > 10 ans     390,000        1,101,000      2,400,000


                       < 5 ans      140,000        311,000                      540,000                                                      < 5 ans      300,000        638,000        1,100,000
                                                                                                         RESPONSABLE
        CHARGÉ
                      5-10 ans      154,000        576,000                      700,000                  ADMINISTRATIF                       5-10 ans     350,000        960,000        2,125,000
     DE REPORTING
                                                                                                          ET FINANCIER
                      > 10 ans      300,000        688,000                      856,000                                                      > 10 ans     412,000        1,403,000      3,000,000


                       < 5 ans      200,000        565,000                     1,378,000                                                     < 5 ans         -               -              -

     CONTRÔLEUR                                                                                           RESPONSABLE
                      5-10 ans      250,000        789,000                     1,800,000                                                     5-10 ans     700,000        1,163,000      1,850,000
      DE GESTION                                                                                          AUDIT INTERNE

                      > 10 ans      350,000        923,000                     2,750,000                                                     > 10 ans     750,000        1,670,000      3,000,000


                       < 5 ans         -               -                             -                                                       < 5 ans      480,000        922,000        1,300,000
     CONTRÔLEUR                                                                                           RESPONSABLE
      DE GESTION      5-10 ans      621,000        1,355,000                   2,500,000                   CONTRÔLE                          5-10 ans     650,000        1,205,000      2,000,000
     CORPORATE                                                                                             DE GESTION
                      > 10 ans     1,100,000       1,873,000                   3,737,000                                                     > 10 ans     720,000        1,688,000      2,300,000




76                                                             Finance & Comptabilité CÔTE D'IVOIRE   CÔTE D'IVOIRE Finance & Comptabilité                                                           77
  FONCTIONS CON-                                                                                         FONCTIONS CREDIT
 TRÔLE DE GESTION,                                                                                         MANAGEMENT,
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                                EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
  CONSOLIDATION                                                                                             TRÉSORERIE
  & AUDIT INTERNE                                                                                         & FINANCEMENT


                         < 5 ans         -               -                             -                                                       < 5 ans         -               -              -
      RESPONSABLE
                                                                                                            RESPONSABLE
       CONTRÔLE         5-10 ans      500,000        1,525,000                   3,000,000                                                     5-10 ans     250,000        613,000        1,350,000
                                                                                                             TRÉSORERIE
       FINANCIER
                        > 10 ans     1,215,000       2,452,000                   3,560,000                                                     > 10 ans     500,000        860,000        1,600,000


                         < 5 ans         -               -                             -                                                       < 5 ans      170,000        331,000         550,000

      RESPONSABLE
                        5-10 ans      450,000        1,190,000                   2,300,000                    TRÉSORIER                        5-10 ans     250,000        555,000        1,322,000
       FINANCIER

                        > 10 ans      855,000        2,047,000                   5,000,000                                                     > 10 ans     250,000        874,000        2,500,000




 FONCTIONS CREDIT
   MANAGEMENT,
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT
    TRÉSORERIE                                                                                              FONCTIONS DE
                                                                                                                                         EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
  & FINANCEMENT                                                                                               DIRECTION


                         < 5 ans      150,000        211,000                      277,000                                                      < 5 ans         -               -              -

          AGENT                                                                                           DAF FILIALE/SITE/
                        5-10 ans      170,000        253,000                      375,000                                                      5-10 ans     500,000        1,887,000      3,100,000
     DE FACTURATION                                                                                        BUSINESS UNIT

                        > 10 ans      200,000        328,000                      450,000                                                      > 10 ans     825,000        2,748,000      8,200,000


                         < 5 ans      150,000        258,000                      650,000                                                      < 5 ans         -               -              -
                                                                                                             DIRECTEUR
      CHARGÉ                                                                                               ADMINISTRATIF
                        5-10 ans      240,000        442,000                      950,000                                                      5-10 ans        -               -              -
 DE RECOUVREMENT                                                                                            ET FINANCIER
                                                                                                               GROUPE
                        > 10 ans      322,000        544,000                     1,300,000                                                     > 10 ans    1,200,000       3,724,000     10,000,000


                         < 5 ans         -               -                             -                                                       < 5 ans         -               -              -
                                                                                                             DIRECTEUR
     CHEF DE SERVICE                                                                                        COMPTABLE/
                        5-10 ans      381,000        731,000                     1,450,000                                                     5-10 ans        -               -              -
      FACTURATION                                                                                          DIRECTEUR DES
                                                                                                           COMPTABILITÉS
                        > 10 ans      402,000        904,000                     1,800,000                                                     > 10 ans     750,000        1,960,000      4,500,000


                         < 5 ans         -               -                             -                                                       < 5 ans         -               -              -
      RESPONSABLE
                                                                                                             DIRECTEUR
     RECOUVREMENT       5-10 ans      250,000        518,000                     1,200,000                                                     5-10 ans        -               -              -
                                                                                                         DE L’AUDIT INTERNE
     ET CONTENTIEUX
                        > 10 ans      405,000        692,000                     1,793,000                                                     > 10 ans     850,000        2,117,000      3,500,000




78                                                               Finance & Comptabilité CÔTE D'IVOIRE   CÔTE D'IVOIRE Finance & Comptabilité                                                           79
                                                                                                     HÔTELLERIE, RESTAURATION
                                                                                                     & TOURISME

     FONCTIONS DE
                    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                     HÔTELLERIE                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DIRECTION


                      < 5 ans         -               -                             -                                                     < 5 ans          180,000        251,000         650,000
      DIRECTEUR
                                                                                                             CHEF
     DU CONTRÔLE     5-10 ans         -               -                             -                                                    5-10 ans          210,000        376,000         950,000
                                                                                                         DE RÉCEPTION
      DE GESTION
                     > 10 ans      762,000        1,968,000                   3,000,000                                                  > 10 ans             -               -              -


                      < 5 ans         -               -                             -                                                     < 5 ans             -               -              -

      DIRECTEUR                                                                                            DIRECTEUR
                     5-10 ans     1,000,000       1,669,000                   4,000,000                                                  5-10 ans             -               -              -
      FINANCIER                                                                                         D'EXPLOITATION

                     > 10 ans     1,220,000       3,170,000                   6,595,000                                                  > 10 ans          600,000        1,242,000      2,500,000


                      < 5 ans         -               -                             -                                                     < 5 ans             -               -              -

     DIRECTEUR                                                                                             DIRECTEUR
                     5-10 ans         -               -                             -                                                    5-10 ans             -               -              -
 FINANCIER GROUPE                                                                                           D’HÔTEL

                     > 10 ans     2,750,000       4,188,000                   7,000,000                                                  > 10 ans          350,000        1,180,000      3,280,000


                                                                                                                                          < 5 ans             -               -              -

                                                                                                             GÉRANT                      5-10 ans          250,000        676,000        2,465,000

                                                                                                                                         > 10 ans          400,000        1,333,000      3,300,000


                                                                                                                                          < 5 ans          150,000        357,000         550,000

                                                                                                          GOUVERNANT                     5-10 ans          240,000        405,000         610,000

                                                                                                                                         > 10 ans          250,000        442,000         700,000


                                                                                                                                          < 5 ans          90,000         180,000         327,000

                                                                                                       RÉCEPTIONNISTE                    5-10 ans          110,000        208,000         430,000

                                                                                                                                         > 10 ans             -               -              -




80                                                            Finance & Comptabilité CÔTE D'IVOIRE   CÔTE D'IVOIRE Hôtellerie, Restauration
& Tourisme                                                81
                                                                                                             RESTAURATION
       HÔTELLERIE         EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                               EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                            TRADITIONNELLE


                            < 5 ans      180,000         244,000                    430,000                                                    < 5 ans          150,000        224,000         400,000
     RÉCEPTIONNISTE
      BILINGUE ANGLAIS-    5-10 ans      240,000         383,000                    640,000                       BARMAN                      5-10 ans          220,000        343,000         620,000
           FRANÇAIS

                           > 10 ans         -                -                           -                                                    > 10 ans             -              -               -


                            < 5 ans         -                -                           -                                                     < 5 ans             -              -               -

      RESPONSABLE
                           5-10 ans      150,000         984,000                   1,800,000                  CHEF BARMAN                     5-10 ans          300,000        419,000         838,000
     D'EXPLOITATION

                           > 10 ans      400,000        1,184,000                  2,300,000                                                  > 10 ans          370,000        505,000        1,040,000


                            < 5 ans         -                -                           -                                                     < 5 ans             -              -               -

      YIELD/REVENUE
                           5-10 ans         -                -                           -                   CHEF DE CUISINE                  5-10 ans          190,000        426,500         945,000
         MANAGER

                           > 10 ans      800,000        1,366,000                  2,250,000                                                  > 10 ans          200,000        612,000        1,200,000


                                                                                                                                               < 5 ans             -              -               -

                                                                                                              RESPONSABLE
                                                                                                                                              5-10 ans          400,000        754,000        1,354,000
                                                                                                                DE SALLE
      RESTAURATION
                          EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN              SALAIRE HAUT                                                  > 10 ans          500,000        900,000        1,500,000
         RAPIDE


                            < 5 ans      220,000         376,000                    645,000
        ASSISTANT
         MANAGER
                           5-10 ans      280,000         428,000                    755,000
     DE RESTAURATION
          RAPIDE
                           > 10 ans         -                -                           -


                            < 5 ans      150,000         350,000                    500,000
         MANAGER
     DE RESTAURATION       5-10 ans      180,000         476,000                    850,000
          RAPIDE
                           > 10 ans      200,000         641,000                   1,355,000




82                                                    Hôtellerie, Restauration
& Tourisme CÔTE D'IVOIRE   CÔTE D'IVOIRE Hôtellerie, Restauration
& Tourisme                                                83
INDUSTRIE :
INGÉNIEURS & TECHNICIENS
                                                                                                              APRÈS-VENTE/
     APPELS D’OFFRES/
                                                                                                             INSTALLATION/                  EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      DEVIS/SUPPORT     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT
                                                                                                             COMMISSIONING
        TECHNIQUE

                                                                                                                                                < 5 ans             -               -              -
                          < 5 ans         -                 -                           -
                                                                                                             RESPONSABLE
     CHEF DE PROJET                                                                                                                            5-10 ans          250,000        447,000         800,000
                         5-10 ans      750,000        1,041,000                   1,400,000                PIÈCES DÉTACHÉES
       INDUSTRIEL
                                                                                                                                               > 10 ans          355,000        618,000        1,260,000
                         > 10 ans      880,000        1,344,000                   1,729,000


                          < 5 ans         -                 -                           -

        INGÉNIEUR
                         5-10 ans      600,000         883,000                    1,600,000                    FONCTIONS
        D’AFFAIRES
                                                                                                             TRANSVERSES À                  EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                         > 10 ans      700,000        1,321,000                   2,150,000                  LA PRODUCTION

                                                                                                                                                < 5 ans          220,000        469,000         933,000
                                                                                                               INGÉNIEUR
                                                                                                               MÉTHODES/
                                                                                                                PROCESS/                       5-10 ans          430,000        658,000        1,545,000
      APRÈS-VENTE/                                                                                            AMÉLIORATION
     INSTALLATION/      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                     CONTINUE                       > 10 ans          500,000        844,000        1,860,000
     COMMISSIONING

                          < 5 ans         -                 -                           -                                                       < 5 ans             -               -              -

      DIRECTEUR SAV                                                                                           RESPONSABLE
                         5-10 ans         -                 -                           -                                                      5-10 ans          230,000        401,000         750,000
        INDUSTRIEL                                                                                               GMAO

                         > 10 ans     1,377,000       2,038,000                   3,100,000                                                    > 10 ans          300,000        554,000        1,100,000


                          < 5 ans      140,000         257,000                     474,000                    RESPONSABLE                       < 5 ans             -               -              -
                                                                                                               MÉTHODES/
   GESTIONNAIRE
                         5-10 ans      195,000         315,000                     675,000                      PROCESS/                       5-10 ans          450,000        889,000        1,850,000
 PIÈCES DÉTACHÉES
                                                                                                              AMÉLIORATION
                         > 10 ans         -                 -                           -                       CONTINUE                       > 10 ans          940,000        1,414,000      2,000,000


                          < 5 ans         -                 -                           -                                                       < 5 ans             -               -              -

 RESPONSABLE SAV                                                                                              RESPONSABLE
                         5-10 ans      420,000        1,116,000                   2,465,000                                                    5-10 ans          375,000        988,000        1,600,000
    INDUSTRIEL                                                                                               TRAVAUX NEUFS

                         > 10 ans      505,000        1,480,000                   4,733,000                                                    > 10 ans          410,000        1,206,000      1,780,000




84                                                   Industrie : Ingénieurs & Techniciens CÔTE D'IVOIRE   CÔTE D'IVOIRE Industrie : Ingénieurs & Techniciens                                                85
       FONCTIONS
     TRANSVERSES À    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                   MAINTENANCE
                                                                                                                                          EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     LA PRODUCTION                                                                                          INDUSTRIELLE


                        < 5 ans      165,000         372,000                     612,000                                                      < 5 ans          400,000        575,000        1,350,000

                                                                                                              INGÉNIEUR
 TECHNICIEN GMAO       5-10 ans      225,000         459,000                     766,000                                                     5-10 ans          577,000        854,000        1,558,000
                                                                                                            AUTOMATISME

                       > 10 ans         -                 -                           -                                                      > 10 ans          660,000        932,000        1,804,000


      TECHNICIEN        < 5 ans      130,000         315,000                     500,000                                                      < 5 ans          250,000        583,000        1,200,000
      MÉTHODES/
                                                                                                             INGÉNIEUR
       PROCESS/        5-10 ans      180,000         351,000                     650,000                                                     5-10 ans          550,000        821,000        1,660,000
                                                                                                            MAINTENANCE
     AMÉLIORATION
       CONTINUE        > 10 ans      250,000         445,000                     800,000                                                     > 10 ans             -               -              -


                        < 5 ans      120,000         295,000                     510,000                                                      < 5 ans          224,000        625,000        1,200,000

       TECHNICIEN                                                                                         RESPONSABLE DE
                       5-10 ans      148,000         342,000                     635,000                                                     5-10 ans          278,000        890,000        2,310,000
     TRAVAUX NEUFS                                                                                         MAINTENANCE

                       > 10 ans      200,000         403,000                     750,000                                                     > 10 ans          300,000        1,205,000      3,100,000


                                                                                                                                              < 5 ans          200,000        407,000         810,000
                                                                                                          RESPONSABLE DE
                                                                                                           MAINTENANCE                       5-10 ans          250,000        521,000        1,400,000
                                                                                                             ADJOINT
     MAINTENANCE
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                                                    > 10 ans          288,000        663,000        1,919,000
     INDUSTRIELLE


                        < 5 ans         -                 -                           -                                                       < 5 ans          150,000        506,000        1,306,000

     CHEF D'ATELIER                                                                                         RESPONSABLE
                       5-10 ans      300,000         622,000                    1,400,000                                                    5-10 ans          377,000        974,000        1,881,000
     MAINTENANCE                                                                                             TECHNIQUE

                       > 10 ans      457,000         821,000                    3,000,000                                                    > 10 ans          400,000        1,360,000      3,000,000


                        < 5 ans      133,000         396,000                     450,000                                                      < 5 ans          150,000        238,000         480,000

     CHEF D'ÉQUIPE                                                                                           TECHNICIEN
                       5-10 ans      181,000         496,000                     800,000                                                     5-10 ans          198,000        364,000         633,000
     MAINTENANCE                                                                                            AUTOMATISME

                       > 10 ans      250,000         524,000                     962,000                                                     > 10 ans             -               -              -


                        < 5 ans         -                 -                           -                                                       < 5 ans          105,000        265,000         500,000
                                                                                                           TECHNICIEN DE
       DIRECTEUR
                       5-10 ans         -                 -                           -                    MAINTENANCE                       5-10 ans          155,000        333,000         711,000
       TECHNIQUE
                                                                                                          MULTITECHNIQUE
                       > 10 ans      850,000        2,674,000                   8,200,000                                                    > 10 ans             -               -              -




86                                                 Industrie : Ingénieurs & Techniciens CÔTE D'IVOIRE   CÔTE D'IVOIRE Industrie : Ingénieurs & Techniciens                                                87
      MAINTENANCE                                                                                            PRODUCTION/
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                                                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      INDUSTRIELLE                                                                                           EXPLOITATION


                         < 5 ans      150,000         282,000                     550,000                                                      < 5 ans          262,000        312,000         580,000
        TECHNICIEN
                                                                                                            CHEF DE QUART
     DE MAINTENANCE/    5-10 ans      220,000         357,000                     630,000                                                     5-10 ans          300,000        503,000         705,000
                                                                                                            DE PRODUCTION
        ÉLECTRICIEN
                        > 10 ans      250,000         432,000                     850,000                                                     > 10 ans          345,000        568,000         840,000


                         < 5 ans      137,000         266,000                     658,000                                                      < 5 ans          130,000        273,000         500,000
        TECHNICIEN
     DE MAINTENANCE/                                                                                          CONDUCTEUR
                        5-10 ans      214,000         344,000                     778,000                                                     5-10 ans          210,000        359,000         660,000
      ÉLECTROMÉCA-                                                                                              DE LIGNE
          NICIEN
                        > 10 ans      244,000         454,000                     904,000                                                     > 10 ans          240,000        411,000         743,000


                         < 5 ans      120,000         271,000                     583,000                                                      < 5 ans             -               -              -
        TECHNICIEN
     DE MAINTENANCE/    5-10 ans      195,000         348,000                     705,000                 DIRECTEUR D’USINE                   5-10 ans         1,000,000       2,159,000      6,000,000
      ÉLECTRONICIEN
                        > 10 ans      267,000         476,000                     846,000                                                     > 10 ans         1,200,000       2,635,000      9,500,000


                         < 5 ans      110,000         223,000                     650,000                                                      < 5 ans             -               -              -
        TECHNICIEN
                                                                                                              DIRECTEUR
     DE MAINTENANCE/    5-10 ans      150,000         441,000                     800,000                                                     5-10 ans          600,000        1,524,000      3,000,000
                                                                                                            DE PRODUCTION
        MÉCANICIEN
                        > 10 ans      200,000         530,000                     821,000                                                     > 10 ans         1,100,000       1,976,000      4,200,000


                                                                                                                                               < 5 ans             -               -              -

                                                                                                              DIRECTEUR
                                                                                                                                              5-10 ans          600,000        1,912,000      3,823,000
                                                                                                            DES OPÉRATIONS
      PRODUCTION/
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                                                    > 10 ans          700,000        2,645,000      5,360,000
      EXPLOITATION


                         < 5 ans         -                 -                           -                                                       < 5 ans          407,000        653,000        1,100,000

      CHEF D’ÉQUIPE                                                                                           INGÉNIEUR
                        5-10 ans      240,000         347,000                     555,000                                                     5-10 ans          500,000        716,000        1,313,000
       PRODUCTION                                                                                           DE PRODUCTION

                        > 10 ans      300,000         490,000                     800,000                                                     > 10 ans          634,000        890,000        1,546,000


                         < 5 ans         -                 -                           -                                                       < 5 ans          300,000        716,000        2,000,000

     CHEF DE CENTRE                                                                                          RESPONSABLE
                        5-10 ans      381,000         777,000                    1,500,000                                                    5-10 ans          328,000        917,000        2,420,000
      EMPLISSEUR                                                                                            DE PRODUCTION

                        > 10 ans      404,000        1,014,000                   2,200,000                                                    > 10 ans          360,000        1,079,000      2,888,000




88                                                  Industrie : Ingénieurs & Techniciens CÔTE D'IVOIRE   CÔTE D'IVOIRE Industrie : Ingénieurs & Techniciens                                                89
      PRODUCTION/
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                    QUALITÉ/HSE                  EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      EXPLOITATION


                        < 5 ans      350,000         420,000                     864,000                                                      < 5 ans          300,000        546,000         985,000
      RESPONSABLE
                                                                                                            RESPONSABLE
     DE PRODUCTION     5-10 ans      410,000         556,000                    1,243,000                                                    5-10 ans          377,000        889,000        1,500,000
                                                                                                                HSE
        ADJOINT
                       > 10 ans      450,000         673,000                    1,500,000                                                    > 10 ans          800,000        1,336,000      3,500,000


                        < 5 ans         -                 -                           -                                                       < 5 ans          230,000        453,000        1,075,000

      RESPONSABLE                                                                                           RESPONSABLE
                       5-10 ans      400,000         718,000                    1,310,000                                                    5-10 ans          450,000        702,000        1,335,000
     DES OPÉRATIONS                                                                                             QHSE

                       > 10 ans      500,000        1,075,000                   2,000,000                                                    > 10 ans          600,000        951,000        1,600,000


                        < 5 ans      211,000         420,000                     850,000                                                      < 5 ans             -               -              -

      SUPERVISEUR                                                                                           RESPONSABLE
                       5-10 ans      300,000         588,000                    1,110,000                                                    5-10 ans          250,000        578,000        1,100,000
     DE PRODUCTION                                                                                            QUALITÉ

                       > 10 ans      400,000         773,000                    1,485,000                                                    > 10 ans          410,000        882,000        1,380,000


                        < 5 ans      130,000         221,000                     400,000                                                      < 5 ans          115,000        314,000         706,000

       TECHNICIEN                                                                                             TECHNICIEN
                       5-10 ans      150,000         282,000                     515,000                                                     5-10 ans          210,000        452,000         975,000
     DE PRODUCTION                                                                                               HSE

                       > 10 ans      203,000         323,000                     643,000                                                     > 10 ans             -               -              -


                                                                                                                                              < 5 ans          160,000        247,000         478,000

                                                                                                              TECHNICIEN
                                                                                                                                             5-10 ans          187,000        341,000         616,000
                                                                                                               QUALITÉ
      QUALITÉ/HSE     EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                                                    > 10 ans             -               -              -


                        < 5 ans      377,000         493,000                    1,008,000

       INGÉNIEUR
                       5-10 ans      541,000         746,000                    1,350,000
         QHSE                                                                                                 R&D/
                                                                                                         BUREAU D’ÉTUDES/                 EXPÉRIENCE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                       > 10 ans      700,000         957,000                    1,612,000                    ESSAIS

                        < 5 ans      300,000         849,000                    2,400,000                                                     < 5 ans          315,000        474,000         945,000

       INGÉNIEUR                                                                                         INGÉNIEUR BUREAU
                       5-10 ans      386,000        1,125,000                   2,664,000                                                    5-10 ans          422,000        725,000        1,200,000
        QUALITÉ                                                                                            D’ÉTUDES/R&D

                       > 10 ans      420,000        1,462,000                   2,900,000                                                    > 10 ans          544,000        846,000        1,342,000




90                                                 Industrie : Ingénieurs & Techniciens CÔTE D'IVOIRE   CÔTE D'IVOIRE Industrie : Ingénieurs & Techniciens                                                91
                                                                                                         JURIDIQUE
                                                                                                         & FISCAL
      R&D/
 BUREAU D’ÉTUDES/      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN               SALAIRE HAUT                     FONCTION
                                                                                                                                            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
     ESSAIS                                                                                                    DE JUSTICE


                         < 5 ans      280,000         381,000                     500,000                                                     < 5 ans      100,000        238,000         480,000
        INGÉNIEUR
                                                                                                            COLLABORATEUR
      LABORATOIRE/      5-10 ans      300,000         403,000                     620,000                                                    5-10 ans      150,000        311,000         600,000
                                                                                                              JURIDIQUE
          ESSAIS
                        > 10 ans      410,000         543,000                     785,000                                                    > 10 ans         -              -               -


                         < 5 ans         -                 -                           -                                                      < 5 ans      200,000        384,000         720,000

      RESPONSABLE                                                                                              FISCALISTE
                        5-10 ans      450,000         854,000                    1,900,000                                                   5-10 ans      250,000        457,000         840,000
     BUREAU D’ÉTUDES                                                                                          D'ENTREPRISE

                        > 10 ans      510,000        1,067,000                   2,424,000                                                   > 10 ans         -              -               -


                         < 5 ans         -                 -                           -                                                      < 5 ans      200,000        342,000         650,000
      RESPONSABLE
      LABORATOIRE/      5-10 ans      312,000         775,000                    1,100,000                        JURISTE                    5-10 ans      300,000        518,000         830,000
         ESSAIS
                        > 10 ans      350,000        1,072,000                   1,800,000                                                   > 10 ans      320,000        612,000         945,000


                         < 5 ans      135,000         247,000                     765,000                                                     < 5 ans      210,000        407,000         750,000
       TECHNICIEN
                                                                                                                JURISTE
      LABORATOIRE/      5-10 ans      200,000         394,000                    1,000,000                                                   5-10 ans      321,000        512,000         844,000
                                                                                                              ASSURANCES
         ESSAIS
                        > 10 ans         -                 -                           -                                                     > 10 ans      442,000        679,000        1,115,000


                                                                                                                                              < 5 ans      200,000        344,000         688,000

                                                                                                          JURISTE BANCAIRE                   5-10 ans      282,000        440,000         798,000

                                                                                                                                             > 10 ans      460,000        559,000         890,000


                                                                                                                                              < 5 ans      285,000        493,000         900,000

                                                                                                                 JURISTE
                                                                                                                                             5-10 ans      325,000        613,000        1,300,000
                                                                                                               FISCALISTE

                                                                                                                                             > 10 ans      402,000        768,000        1,514,000




92                                                  Industrie : Ingénieurs & Techniciens CÔTE D'IVOIRE   CÔTE D'IVOIRE Juridique & Fiscal                                                             93
                                                                                                  MÉCANIQUE & AUTOMOBILE
      FONCTION
                    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN          SALAIRE HAUT                     AUTOMOBILE                 EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      DE JUSTICE


                      < 5 ans         -               -                         -                                                        < 5 ans        -               -              -

     RESPONSABLE                                                                                     CHEF D'ATELIER
                     5-10 ans      510,000        822,000                 1,440,000                                                  5-10 ans        300,000        676,000        1,500,000
        FISCAL                                                                                        MÉCANIQUE

                     > 10 ans      660,000        1,028,000               1,800,000                                                  > 10 ans        320,000        841,000        2,492,000


                      < 5 ans         -               -                         -                                                        < 5 ans     175,000        321,000         668,000

     RESPONSABLE                                                                                       ÉLECTRICIEN
                     5-10 ans      540,000        1,140,000               2,300,000                                                  5-10 ans        190,000        432,000         875,000
       JURIDIQUE                                                                                       AUTOMOBILE

                     > 10 ans      565,000        1,842,000               3,000,000                                                  > 10 ans        220,000        566,000        1,100,000


                                                                                                                                         < 5 ans     150,000        256,000         480,000

                                                                                                       MÉCANICIEN
                                                                                                                                     5-10 ans        165,000        308,000         647,000
                                                                                                       AUTOMOBILE
      FONCTIONS
                    EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN          SALAIRE HAUT                                                   > 10 ans        200,000        463,000         925,000
     DE DIRECTION


                      < 5 ans         -               -                         -

      DIRECTEUR
                     5-10 ans         -               -                         -
     COMPLIANCE
                                                                                                        SERVICES
                     > 10 ans      850,000        1,713,000               2,830,000                                               EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                      AUTOMOBILES


                      < 5 ans         -               -                         -                                                        < 5 ans        -               -              -

      DIRECTEUR
                     5-10 ans         -               -                         -                    DIRECTEUR SAV                   5-10 ans           -               -              -
      JURIDIQUE

                     > 10 ans     1,116,000       2,433,000               7,000,000                                                  > 10 ans       1,665,000       2,566,000      4,068,000


                      < 5 ans         -               -                         -                                                        < 5 ans     150,000        386,000         900,000

     SECRÉTAIRE                                                                                        MÉCANICIEN
                     5-10 ans         -               -                         -                                                    5-10 ans        170,000        472,000        1,200,000
      GÉNÉRAL                                                                                         POIDS LOURDS

                     > 10 ans     1,245,000       2,544,000              11,650,000                                                  > 10 ans        233,000        588,000        1,400,000


                                                                                                                                         < 5 ans        -               -              -

                                                                                                       RESSOURCES
                                                                                                                                     5-10 ans        375,000        763,000        1,551,000
                                                                                                        HUMAINES

                                                                                                                                     > 10 ans        543,000        1,001,000      2,000,000




94                                                             Juridique & Fiscal CÔTE D'IVOIRE   CÔTE D'IVOIRE Mécanique & Automobile                                                          95
RESSOURCES HUMAINES


        AFFAIRES                                                                                      DÉVELOPPEMENT
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN            SALAIRE HAUT                                              EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        SOCIALES                                                                                            RH


                        < 5 ans         -               -                          -                                                    < 5 ans      275,000        391,000         650,000

                                                                                                           CHARGÉ
     CHARGÉ DE C&B     5-10 ans      550,000        868,000                   1,200,000                                                 5-10 ans     350,000        488,000         826,000
                                                                                                        DE FORMATION

                       > 10 ans      700,000        965,000                   1,800,000                                                 > 10 ans     400,000        585,000         950,000


                        < 5 ans      150,000        288,000                    650,000                                                  < 5 ans      150,000        315,000         800,000
        CHARGÉ/
                                                                                                           CHARGÉ
      GESTIONNAIRE
                       5-10 ans      190,000        414,000                    830,000                DE RECRUTEMENT/                   5-10 ans     260,000        453,000        1,050,000
     ADMINISTRATION
                                                                                                         RECRUTEUR
         ET PAIE
                       > 10 ans      211,000        506,000                   1,200,000                                                 > 10 ans     300,000        566,000        1,200,000


                        < 5 ans         -               -                          -                                                    < 5 ans      208,000        352,000         650,000
      RESPONSABLE
                                                                                                          CHASSEUR
     ADMINISTRATION    5-10 ans      460,000        906,000                   1,300,000                                                 5-10 ans     270,000        546,000         860,000
                                                                                                           DE TÊTES
         ET PAIE
                       > 10 ans      550,000        1,142,000                 2,100,000                                                 > 10 ans     410,000        772,000        1,670,000


                                                                                                                                        < 5 ans      150,000        445,000         940,000

                                                                                                      RESPONSABLE DE
                                                                                                                                        5-10 ans     310,000        588,000        1,650,000
                                                                                                       LA FORMATION
     DÉVELOPPEMENT
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN            SALAIRE HAUT                                                  > 10 ans     330,000        702,000        1,844,000
           RH


                        < 5 ans      277,000        374,000                    724,000                                                  < 5 ans      150,000        363,000         776,000
       CHARGÉ DE
                                                                                                       RESPONSABLE
     COMMUNICATION     5-10 ans      315,000        504,000                    900,000                                                  5-10 ans     240,000        516,000         993,000
                                                                                                      DE RECRUTEMENT
       RH/INTERNE
                       > 10 ans         -               -                          -                                                    > 10 ans     311,000        769,000        1,421,000


                        < 5 ans      150,000        484,000                    750,000                                                  < 5 ans         -               -              -
       CHARGÉ DE                                                                                       RESPONSABLE
     DÉVELOPPEMENT     5-10 ans      330,000        632,000                    900,000                DÉVELOPPEMENT                     5-10 ans    1,000,000       1,362,000      2,170,000
           RH                                                                                               RH
                       > 10 ans      386,000        747,000                   1,300,000                                                 > 10 ans    1,200,000       2,529,000      4,570,000




96                                                              Ressources Humaines CÔTE D'IVOIRE   CÔTE D'IVOIRE Ressources Humaines                                                           97
      GÉNÉRALISTE                                                                                         GÉNÉRALISTE
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN            SALAIRE HAUT                                              EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
          RH                                                                                                  RH


                         < 5 ans      70,000         281,000                    800,000                                                  < 5 ans      300,000        540,000        1,181,000

      ASSISTANT RH      5-10 ans      96,000         372,000                    950,000                        HRBP                      5-10 ans     370,000        717,000        1,600,000

                        > 10 ans         -               -                          -                                                    > 10 ans     525,000        1,166,000      2,000,000


                         < 5 ans      150,000        314,000                    650,000                                                  < 5 ans      250,000        643,000        1,400,000

       CHARGÉ RH        5-10 ans      200,000        487,000                   1,500,000               RESPONSABLE RH                    5-10 ans     280,000        869,000        2,500,000

                        > 10 ans         -               -                          -                                                    > 10 ans     350,000        1,230,000      2,843,000


                         < 5 ans      200,000        369,000                    860,000                                                  < 5 ans         -               -              -

                                                                                                            RRH SITE
 COORDINATEUR RH        5-10 ans      345,000        782,000                   1,400,000                                                 5-10 ans     484,000        1,203,000      2,790,000
                                                                                                           INDUSTRIEL

                        > 10 ans      450,000        928,000                   3,000,000                                                 > 10 ans     825,000        1,820,000      3,500,000


                         < 5 ans         -               -                          -

      DIRECTEUR RH      5-10 ans      760,000        1,896,000                 3,000,000

                        > 10 ans      800,000        2,649,000                 4,570,000              MÉTIERS DE LA RSE              EXPÉRIENCE     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                         < 5 ans         -               -                          -                                                    < 5 ans      130,000        227,000         384,000

      DIRECTEUR RH
                        5-10 ans      920,000        1,365,000                 2,200,000                  CHARGÉ RSE                     5-10 ans     150,000        319,000         548,000
         ADJOINT

                        > 10 ans     1,100,000       1,890,000                 2,740,000                                                 > 10 ans        -               -              -


                         < 5 ans         -               -                          -                                                    < 5 ans         -               -              -

      DIRECTEUR RH
                        5-10 ans         -               -                          -                 RESPONSABLE RSE                    5-10 ans     390,000        867,000        1,145,000
         GROUPE

                        > 10 ans     1,483,000       2,885,000                 5,224,000                                                 > 10 ans     550,000        1,056,000      1,562,000


                         < 5 ans      180,000        331,000                    660,000

     GESTIONNAIRE RH    5-10 ans      315,000        580,000                   1,100,000

                        > 10 ans      380,000        766,000                   2,440,000




98                                                               Ressources Humaines CÔTE D'IVOIRE   CÔTE D'IVOIRE Ressources Humaines                                                           99
SYSTÈMES D’INFORMATION


                                                                                                           ÉTUDES &
        DATA & IA      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                              EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                        DÉVELOPPEMENT


                         < 5 ans      385,000        577,000                    880,000                                                      < 5 ans     280,000        554,000        1,430,000
                                                                                                         CHEF DE PROJET
      DATA ANALYST      5-10 ans      450,000        775,000                   1,400,000                  FONCTIONNEL                    5-10 ans        355,000        803,000        1,800,000
                                                                                                            ERP, CRM, BI…

                        > 10 ans         -               -                           -                                                   > 10 ans        450,000        991,000        2,000,000


                         < 5 ans      480,000        753,000                   1,046,000                                                     < 5 ans     350,000        588,000        1,150,000
                                                                                                        CHEF DE PROJET
      DATA ENGINEER     5-10 ans      626,000        984,000                   1,742,000               INFRASTRUCTURES                   5-10 ans        390,000        745,000        1,370,000
                                                                                                              IT
                        > 10 ans         -               -                           -                                                   > 10 ans        500,000        1,025,000      1,622,000


                         < 5 ans      400,000        809,000                   1,200,000                                                     < 5 ans     184,000        348,000         607,000

                                                                                                         CHEF DE PROJET
      DATA SCIENTIST    5-10 ans      528,000        1,074,000                 1,661,000                                                 5-10 ans        300,000        486,000         871,000
                                                                                                              SAP

                        > 10 ans         -               -                           -                                                   > 10 ans        344,000        569,000        1,046,000


                         < 5 ans      144,000        503,000                   1,100,000                                                     < 5 ans     380,000        717,000        1,200,000
        DBA/                                                                                               INGÉNIEUR
  ADMINISTRATEUR                                                                                          D’ÉTUDES ET
                        5-10 ans      200,000        676,000                   1,327,000                                                 5-10 ans        412,000        883,000        1,810,000
      DE BASE                                                                                           DÉVELOPPEMENT
    DE DONNÉES                                                                                         C#/.NET, JAVA, PHP, JS…
                        > 10 ans      342,000        822,000                   1,550,000                                                 > 10 ans        475,000        1,043,000      2,012,000


                                                                                                                                             < 5 ans     384,000        587,000         850,000

                                                                                                        INGÉNIEUR TESTS/
                                                                                                                                         5-10 ans        410,000        684,000        1,000,000
                                                                                                           RECETTES
     ÉTUDES &
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                                 > 10 ans        439,000        702,000        1,400,000
  DÉVELOPPEMENT


                         < 5 ans      200,000        620,000                   1,850,000                                                     < 5 ans     378,000        561,000         945,000
        BUSINESS
        ANALYST         5-10 ans      360,000        794,000                   2,031,000                PRODUCT OWNER                    5-10 ans        410,000        712,000        1,213,000
           IT
                        > 10 ans         -               -                           -                                                   > 10 ans        442,000        846,000        1,450,000




100                                                            Systèmes d’Information CÔTE D'IVOIRE   CÔTE D'IVOIRE Systèmes d’Information                                                          101
       FONCTIONS                                                                                          FONCTIONS
                      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                              EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      DE DIRECTION                                                                                       DE DIRECTION


                        < 5 ans         -               -                           -                                                       < 5 ans        -               -              -
   DIRECTEUR DES
 INFRASTRUCTURES                                                                                         RESPONSABLE
                       5-10 ans         -               -                           -                                                   5-10 ans        350,000        563,000        1,278,000
      ET DE LA                                                                                            TECHNIQUE
  PRODUCTION/CTO
                       > 10 ans     1,200,000       2,332,000                 3,465,000                                                 > 10 ans        501,000        754,000        1,666,000


                        < 5 ans         -               -                           -
         DIRECTEUR
      DES SYSTÈMES     5-10 ans         -               -                           -
      D’INFORMATION
                                                                                                          FONCTIONS
                       > 10 ans      910,000        2,491,000                 8,200,000                                              EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                         TRANSVERSES


                        < 5 ans         -               -                           -                                                       < 5 ans     400,000        638,000        1,000,000

        DIRECTEUR                                                                                           AUDITEUR
                       5-10 ans         -               -                           -                                                   5-10 ans        460,000        733,000        1,500,000
      INFORMATIQUE                                                                                             IT

                       > 10 ans      875,000        2,122,000                 3,473,000                                                 > 10 ans        522,000        894,000        1,665,000


                        < 5 ans         -               -                           -                                                       < 5 ans     350,000        577,000         800,000
                                                                                                         PMO/PROJECT
       DIRECTEUR
                       5-10 ans         -               -                           -                    MANAGEMENT                     5-10 ans        411,000        881,000        1,550,000
       TECHNIQUE
                                                                                                           OFFICER
                       > 10 ans      515,000        1,449,000                 2,945,000                                                 > 10 ans        469,000        1,214,000      2,480,000


                        < 5 ans         -               -                           -
 RESPONSABLE DES
 INFRASTRUCTURES
                       5-10 ans      470,000        776,000                   1,342,000
      ET DE LA
    PRODUCTION                                                                                        INFRASTRUCTURES
                       > 10 ans      665,000        1,156,000                 2,847,000                                              EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                        & PRODUCTION


                        < 5 ans         -               -                           -                                                       < 5 ans     180,000        455,000         930,000
       RESPONSABLE                                                                                     ADMINISTRATEUR
      DES SYSTÈMES     5-10 ans      492,000        816,000                   1,500,000                  SYSTÈMES/                      5-10 ans        244,000        672,000        1,500,000
      D’INFORMATION                                                                                       RÉSEAUX
                       > 10 ans      594,000        1,091,000                 1,800,000                                                 > 10 ans        367,000        958,000        1,950,000


                        < 5 ans      190,000        485,000                    844,000                                                      < 5 ans     200,000        448,000        1,100,000

       RESPONSABLE                                                                                       DÉVELOPPEUR
                       5-10 ans      200,000        758,000                   2,116,000                                                 5-10 ans        366,000        786,000        1,587,000
      INFORMATIQUE                                                                                          MOBILE

                       > 10 ans      400,000        1,059,000                 3,500,000                                                 > 10 ans        400,000        992,000        1,984,000




102                                                           Systèmes d’Information CÔTE D'IVOIRE   CÔTE D'IVOIRE Systèmes d’Information                                                          103
 INFRASTRUCTURES                                                                                              SÉCURITÉ
                         EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN             SALAIRE HAUT                                              EXPÉRIENCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
   & PRODUCTION                                                                                           & CYBERSÉCURITÉ


                           < 5 ans      150,000        412,000                    800,000                                                      < 5 ans     222,000        534,000        1,246,000
                                                                                                              ANALYSTE
 DÉVELOPPEUR WEB          5-10 ans      250,000        652,000                   1,054,000                  SÉCURITÉ/SOC/                  5-10 ans        250,000        775,000        1,500,000
                                                                                                                SIEM
                          > 10 ans      325,000        827,000                   1,420,000                                                 > 10 ans        400,000        1,040,000      1,950,000


                           < 5 ans      94,000         219,000                    505,000                                                      < 5 ans     250,000        498,000         945,000

                                                                                                             INGÉNIEUR
      INFORMATICIEN       5-10 ans      155,000        364,000                    774,000                                                  5-10 ans        388,000        738,000        1,287,000
                                                                                                           CYBERSÉCURITÉ

                          > 10 ans      223,000        483,000                    943,000                                                  > 10 ans        414,000        857,000        1,500,000


                           < 5 ans      300,000        550,000                    850,000                                                      < 5 ans     150,000        410,000         850,000
                                                                                                             INGÉNIEUR
 INGÉNIEUR DEVOPS         5-10 ans      450,000        653,000                    988,000                     SÉCURITÉ                     5-10 ans        200,000        656,000        1,312,000
                                                                                                          INFRASTRUCTURE
                          > 10 ans      510,000        725,000                   1,100,000                                                 > 10 ans        408,000        954,000        2,100,000


                           < 5 ans      250,000        485,000                    920,000                                                      < 5 ans     170,000        457,000         875,000
                                                                                                              INGÉNIEUR
        INGÉNIEUR
                                                                                                               SÉCURITÉ
        SYSTÈMES/         5-10 ans      310,000        639,000                   1,168,000                                                 5-10 ans        210,000        637,000        1,227,000
                                                                                                           DES SYSTÈMES
         RÉSEAUX
                                                                                                           D’INFORMATION
                          > 10 ans      394,000        792,000                   1,390,000                                                 > 10 ans        375,000        924,000        1,975,000


                           < 5 ans      345,000        523,000                   1,100,000                                                     < 5 ans     380,000        657,000        1,334,000
                                                                                                            RESPONSABLE
      RESPONSABLE
                                                                                                             SÉCURITÉ ET
        SUPPORT/          5-10 ans      416,000        764,000                   1,312,000                                                 5-10 ans        423,000        766,000        1,510,000
                                                                                                           DES SYSTÈMES
        HELPDESK
                                                                                                           D’INFORMATION
                          > 10 ans      485,000        1,093,000                 2,100,000                                                 > 10 ans        510,000        991,000        1,872,000


                           < 5 ans      120,000        345,000                    770,000

        TECHNICIEN
                          5-10 ans      190,000        427,000                    865,000
      D’EXPLOITATION

                          > 10 ans      228,000        608,000                   1,188,000


                           < 5 ans      150,000        311,000                    650,000
       TECHNICIEN
        SUPPORT
          HELPDESK/       5-10 ans      250,000        406,000                    950,000
      INFRASTRUCTURES/
         DE PROXIMITÉ
                          > 10 ans      325,000        517,000                   1,115,000




104                                                              Systèmes d’Information CÔTE D'IVOIRE   CÔTE D'IVOIRE Systèmes d’Information                                                          105
TOP MANAGEMENT
        COMMERCE                                                                                         IT
                       EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN         SALAIRE HAUT                                            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      & DISTRIBUTION                                                                               & TECHNOLOGIES


                         < 5 ans         -               -                      -                                                 < 5 ans         -               -              -
         COUNTRY                                                                                      COUNTRY
         MANAGER/       5-10 ans         -               -                      -                     MANAGER/                   5-10 ans         -               -              -
      DIRECTEUR PAYS                                                                               DIRECTEUR PAYS
                        > 10 ans     1,500,000       4,550,000             8,600,000                                             > 10 ans     1,845,000       3,321,000      8,798,000


                         < 5 ans         -               -                      -                                                 < 5 ans         -               -              -

        DIRECTEUR                                                                                      DIRECTEUR
                        5-10 ans         -               -                      -                                                5-10 ans         -               -              -
         GÉNÉRAL                                                                                        GÉNÉRAL

                        > 10 ans     1,840,000       4,247,000             7,645,000                                             > 10 ans     2,500,000       4,101,000      8,000,000


        REGIONAL         < 5 ans         -               -                      -                       SERVICES
                                                                                                                                EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        MANAGER/                                                                                        & B-TO-B
        DIRECTEUR       5-10 ans         -               -                      -
        RÉGIONAL/
                                                                                                                                  < 5 ans         -               -              -
      SOUS-RÉGIONAL     > 10 ans     2,117,000       5,456,000            13,465,000
                                                                                                      COUNTRY
                                                                                                      MANAGER/                   5-10 ans         -               -              -
                                                                                                   DIRECTEUR PAYS
                                                                                                                                 > 10 ans     1,470,000       3,073,000      8,677,000


                                                                                                                                  < 5 ans         -               -              -
        INDUSTRIE      EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN         SALAIRE HAUT
                                                                                                       DIRECTEUR
                                                                                                                                 5-10 ans         -               -              -
                                                                                                        GÉNÉRAL
                         < 5 ans         -               -                      -
                                                                                                                                 > 10 ans     1,000,000       3,560,000      9,381,000
         COUNTRY
         MANAGER/       5-10 ans         -               -                      -
      DIRECTEUR PAYS
                                                                                                      REGIONAL                    < 5 ans         -               -              -
                        > 10 ans     1,500,000       4,249,000            12,000,000
                                                                                                      MANAGER/
                                                                                                      DIRECTEUR                  5-10 ans         -               -              -
                                                                                                      RÉGIONAL/
                         < 5 ans         -               -                      -
                                                                                                    SOUS-RÉGIONAL                > 10 ans     1,992,000       4,787,400     10,452,000
        DIRECTEUR
                        5-10 ans         -               -                      -
         GÉNÉRAL
                                                                                                       START-UP
                        > 10 ans     2,319,000       4,898,000            10,935,000                                            EXPÉRIENCE   SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                       & FINTECH


                         < 5 ans         -               -                      -                                                 < 5 ans         -               -              -

     DIRECTEUR                                                                                         DIRECTEUR
                        5-10 ans         -               -                      -                                                5-10 ans         -               -              -
  GÉNÉRAL ADJOINT                                                                                       GÉNÉRAL

                        > 10 ans     1,988,000       4,133,000             9,754,000                                             > 10 ans     2,321,000       3,199,000      7,545,000




106                                                               Top Management CÔTE D'IVOIRE   CÔTE D'IVOIRE Top Management                                                             107
                                                                                                                                      ̏   F AIRE VENIR DES TALENTS
                                                                                                                                          DE DIVERS HORIZONS…
                                                                                                         INTERVIEW
                                                                    BIRAHIM DIOP
          Birahim Diop est, comme il se qualiﬁe lui-même, « un entrepreneur africain » et ce n’est pas son curriculum vitae qui va
        le démentir : CEO de Petrostock Oil Senegal, co-fondateur de O’Royal et co-Directeur académique du programme de HEC
      Paris « Challenge+ Afrique » à Dakar. Il est donc aux premières loges pour apporter une vision réaliste de l’innovation et de
                                                                       l’évolution du marché du travail dans son pays, le Sénégal.




En tant que leader dans un secteur clé (le pétrole et l'in-          La digitalisation a-t-elle changé vos critères de sélection
dustrie agroalimentaire), comment inspirez-vous et gui-              lors du recrutement de nouveaux talents ? Quelles nou-
dez-vous l'innovation au sein de votre entreprise ? Quelles          velles compétences digitales privilégiez-vous ?
sont les priorités en termes de technologies à adopter ?                 « Les compétences digitales sont aujourd’hui transver-
      « L’innovation pour toute entreprise est un facteur de             sales à tous les corps de métier, au même titre que la
      succès, voire d’existence. C’est réellement un must !              micro-informatique à la fin du 20ème siècle. »
      À travers toutes mes activités, nos innovations sont le
      fruit d’une mûre réflexion adossée à une vision claire et      Dans un secteur où la pénurie de compétences techniques
      un plan stratégique détaillé. La priorité est à la digital-    est forte, comment faites-vous pour attirer et retenir les       En tant qu’acteur clé de l’économie sénégalaise, comment           Que pensez-vous des formations professionnelles et
      isation et à l’intelligence artificielle. »                    talents dans les domaines IT et numériques ?                     évaluez-vous le rôle des leaders du secteur privé dans             académiques au Sénégal et en Afrique de l’Ouest ? En
                                                                         « À notre échelle, pour les compétences pointues, l’ex-      l'accélération de la transformation digitale du pays ?             tant qu’acteur clé du développement économique, quels
Les profils traditionnels de l'industrie pétrolière ont-ils              ternalisation demeure la meilleure alternative. Nous                « Au Sénégal, l’entreprise et l’entreprenariat n’occupent   conseils leur donneriez-vous pour qu’elle matche plus vos
du mal à s'adapter aux nouvelles exigences numériques ?                  collaborons avec des startups depuis plus de 10 ans,                pas encore la place qui sied à leur vocation. Cependant,    besoins de recrutement et de développement ?
Comment gérez-vous la montée en compétence de vos                        des pépites qui n’envient rien aux licornes aujourd’hui.            l’engagement des tech-entrepreneurs a abouti à la digi-        « La formation aux métiers est primordiale et devrait oc-
équipes sur ces aspects ?                                                A titre d’exemple, dans nos stations, la solution des               talisation de beaucoup de process publics, sans comp-          cuper 80% des adolescents et jeunes apprenants, avec
      « En plus de la formation, faire venir des talents de              cartes et bons carburants est à 360° l’œuvre d’une                  ter le rôle très impactant des fintechs.                       un retour au brevet et au baccalauréat professionnel en
      divers horizons nous donnent une capacité à évoluer et             tech-compagnie sénégalaise. »                                       Reste à consolider dans les secteurs de l’éducation, de        masse assortis de bourses motivantes.
      innover. Rajeunir les équipes fait intégrer des généra-                                                                                la santé et des services aux citoyens (état civil…) pour       La formation universitaire irait plus à la recherche,
      tions déjà à niveau pour les outils technologiques. »                                                                                  entrer pleinement dans l’ère du digital. »                     l’éducation et la santé… Entre les deux, des passerelles. »




108                                                                                                                Top Management         Top Management                                                                                                            109
      SÉNÉGAL
         GRILLE SALARIALE




110                   sénégal
ACHATS
& SUPPLY CHAIN
          BUYING                                                                                 FONCTIONS
                            SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT                                                 SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      & PROCUREMENT                                                                             DE DIRECTION

        ACHETEUR
       GÉNÉRALISTE                                                                              DIRECTEUR
                              255,000        477,000             1,705,000                                                 1,675,000       2,328,000      9,062,000
    MP/INDUSTRIEL/IT/                                                                          SUPPLY CHAIN
 SERVICES/TL/DISTRIBUTION




        ASSISTANT
                              134,000        272,000              787,000
         ACHATS

                                                                                                 LOGISTICS
                                                                                                                          SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                              & SUPPLY CHAIN
      GESTIONNAIRE
                              205,000        564,000             1,548,000
         ACHATS
                                                                                            AGENT LOGISTIQUE/
                                                                                                                            74,000         196,000         710,000
                                                                                               LOGISTICIEN

      RESPONSABLE
                              340,000        778,000             2,709,000
        ACHATS
                                                                                           CONTRACT MANAGER                 394,000        1,107,000      1,942,000


    RESPONSABLE
                              297,000        696,000             1,935,000
  MOYENS GÉNÉRAUX
                                                                                               COORDINATEUR
                                                                                                                            352,000        618,000        1,214,000
                                                                                                LOGISTIQUE




                                                                                             DEMAND PLANNER                 443,000        757,000        1,345,000
        FONCTIONS
                            SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT
       DE DIRECTION


        DIRECTEUR                                                                              GESTIONNAIRE
                             1,005,000       1,826,000           5,289,000                                                  108,000        289,000         968,000
         ACHATS                                                                                FLUX & STOCKS




       DIRECTEUR                                                                               MAGASINIER
                              670,000        2,034,000           6,192,000                                                  88,000         181,000         387,000
       LOGISTIQUE                                                                           MANUTENTIONNAIRE



                                                                                               RESPONSABLE
     DIRECTEUR
                              670,000        1,345,000           3,870,000                    APPROVISIONNE-                235,000        590,000        2,322,000
  MOYENS GÉNÉRAUX
                                                                                                  MENTS




112                                                       Achats& Supply Chain SÉNÉGAL   SÉNÉGAL Achats& Supply Chain                                                113
                                                                                       ADMINISTRATIF, ASSISTANAT
                                                                                       & OFFICE MANAGEMENT
          LOGISTICS
                         SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT                      ADMINISTRATIF                    SALAIRE BAS       SALAIRE MOYEN   SALAIRE HAUT
       & SUPPLY CHAIN


       RESPONSABLE                                                                            ASSISTANT
                           302,000        879,000             2,812,000                                                         178,000           328,000         535,000
        LOGISTIQUE                                                                          ADMINISTRATIF



                                                                                              ASSISTANT
       RESPONSABLE
                           256,000        1,209,000           2,770,000                     ADMINISTRATIF                       194,000           377,000         647,000
       SUPPLY CHAIN
                                                                                              SPÉCIALISÉ




                                                                                             ASSISTANAT
        TRANSPORT        SALAIRE BAS   SALAIRE MOYEN      SALAIRE HAUT                      DE DIRECTION                     SALAIRE BAS       SALAIRE MOYEN   SALAIRE HAUT
                                                                                           OPÉRATIONNELLE


                                                                                              ASSISTANT
      AGENT DE TRANSIT     127,000        261,000              533,000                                                          116,000           331,000        1,143,000
                                                                                             DE DIRECTION



                                                                                              ASSISTANT
 DÉCLARANT DOUANES         101,000        264,000              645,000                       DE DIRECTION                       224,000           417,000        1,450,000
                                                                                            ANGLAIS COURANT/
                                                                                                BILINGUE




                                                                                            ASSISTANT
  PASSEUR EN DOUANE        120,000        239,000              474,000                                                          172,000           374,000         976,000
                                                                                          POLYVALENT PME



        RESPONSABLE                                                                         ASSISTANT
      PARC AUTOMOBILE      168,000        689,000             2,258,000                   POLYVALENT PME                        230,000           434,000        1,342,000
                                                                                            ANGLAIS COURANT/
          ET ENGINS                                                                             BILINGUE




       RESPONSABLE                                                                         OFFICE MANAGER
                           300,000        705,000             2,110,000                     ANGLAIS COURANT/                    235,000           417,000        1,200,000
        TRANSPORT                                                                               BILINGUE




    RESPONSABLE/
  CHEF DÉPARTEMENT         201,000        623,000             1,548,000
       TRANSIT




114                                                    Achats& Supply Chain SÉNÉGAL   SÉNÉGAL Administratif, Assistanat & Office Management                                  115
                                                                                                   AUDIT, CONSEIL
                                                                                                   & EXPERTISE
 ASSISTANAT DE HAUT
   NIVEAU & OFFICE       SALAIRE BAS   SALAIRE MOYEN                  SALAIRE HAUT                    CABINETS D’AUDIT
                                                                                                                                        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
    MANAGEMENT                                                                                          HORS TOP 4



      OFFICE MANAGER       128,000        385,000                         1,043,000                    AUDITEUR JUNIOR                    198,000        386,000         874,000
                                                                                                       < 2 ANS D'EXPÉRIENCE




      OFFICE MANAGER                                                                                 AUDITEUR CONFIRMÉ
      ANGLAIS COURANT/     235,000        417,000                         1,200,000                    2-5 ANS D’EXPÉRIENCE
                                                                                                                                          264,000        478,000        1,270,000
          BILINGUE




                                                                                                       CHEF DE MISSION
                                                                                                           SENIOR                         385,000        544,000        1,543,000
                                                                                                       6-9 ANS D’EXPÉRIENCE




                                                                                                         DIRECTEUR DE
                                                                                                            MISSION                       570,000        876,000        2,341,000
                                                                                                      > 10 ANS D’EXPÉRIENCE




                                                                                                      CABINETS D’AUDIT
                                                                                                                                        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                           TOP 4


                                                                                                           AUDITEUR
                                                                                                          JUNIOR (A1)                     207,000        343,000         558,000
                                                                                                        1 AN D'EXPÉRIENCE




                                                                                                          AUDITEUR
                                                                                                        CONFIRMÉ (A2)                     230,000        416,000         742,000
                                                                                                        2 ANS D’EXPÉRIENCE




                                                                                                             SENIOR                       270,000        524,000         903,000
                                                                                                       3-4 ANS D'EXPÉRIENCE




                                                                                                             SENIOR                       308,000        724,000        1,524,000
                                                                                                       5-6 ANS D'EXPÉRIENCE




116                                        Administratif, Assistanat & Office Management SÉNÉGAL   SÉNÉGAL Audit, Conseil
& Expertise                                                117
                                                                                                 BANQUE

                                                                                                        ACTIVITÉS
                                                                                                       DE MARCHÉ
                                                                                                     & FINANCEMENT        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      CABINETS D’AUDIT                                                                                     AM/BFI
                              SALAIRE BAS   SALAIRE MOYEN          SALAIRE HAUT
           TOP 4                                                                                    & ASSET MANAGEMENT



          MANAGER               616,000        1,044,000              2,032,000                   ANALYSTE FINANCIER        847,000        1,131,000      1,905,000
      3-4 ANS D'EXPÉRIENCE




      SENIOR MANAGER           1,078,000       1,827,000              3,701,000                    ANALYSTE MARCHÉ          462,000        826,000        1,795,000
      > 10 ANS D’EXPÉRIENCE                                                                          BUY SIDE/SELL SIDE




                                                                                                     DATA SCIENTIST         462,000        624,000        1,016,000
          CABINETS
         D’EXPERTISE          SALAIRE BAS   SALAIRE MOYEN          SALAIRE HAUT
         COMPTABLE


         ASSISTANT
                                97,000         330,000                 726,000
         COMPTABLE                                                                                 BANQUE DE RÉSEAU
                                                                                                       DÉTAIL/EN LIGNE
                                                                                                                          SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT




 ASSISTANT JURIDIQUE            93,000         222,000                 608,000                      ANALYSTE CRÉDIT         162,000        389,000         889,000




                                                                                                     CHEF DE PROJET
                                                                                                                            308,000        831,000        2,032,000
                                                                                                       MONÉTIQUE




                                                                                                  DIRECTEUR D'AGENCE        501,000        888,000        1,905,000




118                                                         Audit, Conseil
& Expertise SÉNÉGAL   SÉNÉGAL Banque                                                        119
         FONCTIONS                                                                     FONCTIONS
                         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                  SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        DE DIRECTION                                                                   SUPPORTS


         DIRECTEUR
                                                                                     RESPONSABLE
       ADMINISTRATIF      1,053,000       2,645,000      6,768,000                                     462,000        957,000        1,905,000
                                                                                      TRÉSORERIE
        ET FINANCIER



        DIRECTEUR DE                                                             RESPONSABLE AUDIT
                          1,075,000       2,117,000      4,159,000                                     770,000        957,000        1,524,000
       LA CONFORMITÉ                                                                  INTERNE



    DIRECTEUR DU                                                                     RESPONSABLE
  CONTRÔLE INTERNE/        851,000        2,399,000      5,215,000                    CONTRÔLE         770,000        1,017,000      1,651,000
     PERMANENT                                                                        DE GESTION



                                                                                   RESPONSABLE DE
 DIRECTEUR FINANCIER      1,446,000       2,773,000      5,554,000                                     539,000        813,000        1,651,000
                                                                                  LA COMMUNICATION




                                                                                   RESPONSABLE DE
                                                                                                       963,000        1,436,000      3,048,000
                                                                                   LA CONFORMITÉ

         FONCTIONS
                         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
         SUPPORTS
                                                                                     RESPONSABLE
                                                                                                       924,000        1,545,000      3,175,000
                                                                                      DES RISQUES
  ANALYSTE RISQUES         308,000        430,000         889,000


                                                                                     RESPONSABLE
                                                                                                       847,000        1,349,000      2,540,000
                                                                                      MARKETING
      AUDITEUR INTERNE     278,000        467,000        1,023,000




        CONTRÔLEUR
                           539,000        987,000        2,032,000
         DE GESTION




     CONTRÔLEUR
                           270,000        565,000        1,353,000
 INTERNE/PERMANENT




120                                                            Banque SÉNÉGAL   SÉNÉGAL Commercial                                                121
COMMERCIAL

                                                                                      GRANDE
        ASSURANCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                CONSOMMATION/      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                  GMS/CHR/RHF/GDS


       COMMERCIAL                                                                 CHEF DE SECTEUR
       PARTICULIERS       176,000        365,000         974,000                   GMS/CHR/GSB/        280,000        639,000        1,222,000
        & PME/PMI                                                                    GSA/GSS



        DIRECTEUR                                                               DIRECTEUR NATIONAL
                          994,000        1,477,000      2,540,000                                      586,000        1,212,000      2,820,000
       COMMERCIAL                                                                   DES VENTES




       RESPONSABLE                                                                  RESPONSABLE
                          620,000        1,133,000      1,764,500                                      310,000        685,000        1,500,000
       COMMERCIAL                                                                   COMMERCIAL




                                                                                      DIRECTEUR
                                                                                                       743,000        1,200,000      2,556,000
                                                                                     COMMERCIAL

          BANQUE        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT




      ASSISTANT SALES     308,000        407,000         762,000                     HIGH TECH/
                                                                                     SOFTWARE/       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                   HARDWARE/WEB

  CHARGÉ D’AFFAIRES                                                             BUSINESS DEVELOPER
                          462,000        609,000        1,016,000
      PME/PMI                                                                        INGÉNIEUR         616,000        1,218,000      2,921,000
                                                                                COMMERCIAL B-TO-B


   CHEF DE SERVICE                                                              COMMERCIAL GRANDS
                          385,000        975,000        1,905,000
 CLIENTÈLES PME/PMI                                                             COMPTES - ACCOUNT      144,000        511,000        1,660,000
                                                                                    MANAGER

        CONSEILLER
         CLIENTÈLE        208,000        517,000        1,105,000                    COMMERCIAL
      PROFESSIONNELS                                                                 SÉDENTAIRE/       120,000        354,000         678,000
                                                                                     INSIDE SALES



                                                                                      DIRECTEUR
                                                                                                       616,000        1,305,000      3,175,000
                                                                                     COMMERCIAL



122                                                       Commercial SÉNÉGAL   SÉNÉGAL Commercial                                                 123
        HIGH TECH/
        SOFTWARE/          SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                    SERVICES/
                                                                                                                        SALAIRE BAS     SALAIRE MOYEN   SALAIRE HAUT
      HARDWARE/WEB                                                                     B-TO-B/MÉDIAS

                                                                                    CHEF DE TERRITOIRE
       RESPONSABLE                                                                      DE VENTES/
                             197,000        890,000        2,600,000                                                       154,000         378,000         889,000
       COMMERCIAL                                                                    TERRITORY SALES
                                                                                         MANAGER


         TECHNICO-
        COMMERCIAL           135,000        447,000        1,225,000                 CHEF DES VENTES                       231,000         470,000        1,042,000
         ITINÉRANT



                                                                                        COMMERCIAL
                                                                                                                           100,000         289,000         600,000
                                                                                          B-TO-C
         INDUSTRIE         SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


  CHEF DE TERRITOIRE
      DE VENTES/                                                                       COMMERCIAL
                             308,000        897,000        1,905,000                                                       308,000         566,000        1,016,000
   TERRITORY SALES                                                                   GRANDS COMPTES
       MANAGER


       CHEF DE ZONE
                                                                                         DIRECTEUR
      DE VENTES/AREA         270,000        826,000        2,921,000                                                       770,000         1,158,000      2,096,000
                                                                                        COMMERCIAL
      SALES MANAGER



         DIRECTEUR                                                                       INGÉNIEUR
                            1,309,000       2,671,000      6,985,000                                                       462,000         827,000        1,905,000
        COMMERCIAL                                                                      COMMERCIAL



       RESPONSABLE
                                                                                       RESPONSABLE
      ADMINISTRATION         400,000        728,000        1,800,000                                                       347,000         731,000        1,905,000
                                                                                       COMMERCIAL
        DES VENTES


       RESPONSABLE
         RÉGIONAL            350,000        627,000        1,700,000                  TÉLÉCONSEILLER                           77,000      151,000         279,000
        DES VENTES
      AREA SALES MANAGER



         TECHNICO-
        COMMERCIAL           122,000        367,000         850,000
         ITINÉRANT




124                                                          Commercial SÉNÉGAL   SÉNÉGAL Digital, Marketing & Communication                                           125
DIGITAL, MARKETING
& COMMUNICATION

      COMMUNICATION    SALAIRE BAS   SALAIRE MOYEN                  SALAIRE HAUT                          DIGITAL                      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT



        CHARGÉ DE                                                                                    CHEF DE PROJET
                         193,000        363,000                          889,000                                                          231,000       378,000         889,000
      COMMUNICATION                                                                                   WEB/DIGITAL




        DIRECTEUR                                                                                       COMMUNITY
                         660,000        1,335,000                       3,000,000                                                         138,000       198,000         356,000
      COMMUNICATION                                                                                      MANAGER




       RESPONSABLE
                         539,000        932,000                         1,905,000                     DATA ANALYST                        308,000       522,000        1,143,000
      COMMUNICATION




                                                                                                    DIGITAL CONTENT
                                                                                                                                          154,000       696,000        1,524,000
                                                                                                        MANAGER
  DESIGN & CRÉATION    SALAIRE BAS   SALAIRE MOYEN                  SALAIRE HAUT



        DIRECTEUR                                                                                     RESPONSABLE
                         616,000        842,000                         1,524,000                                                         385,000       465,000         762,000
        ARTISTIQUE                                                                                       DIGITAL




        GRAPHISTE        193,000        305,000                          635,000
                                                                                                        MARKETING                      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT



                                                                                                        ANALYSTE
      INFOGRAPHISTE      154,000        295,000                          635,000                                                          350,000       580,000        1,500,000
                                                                                                        MARKETING




      UI/UX DESIGNER     154,000        253,000                          635,000                     BRAND MANAGER                        655,000       1,112,000      2,286,000




126                                                 Digital, Marketing & Communication SÉNÉGAL   SÉNÉGAL Digital, Marketing & Communication                                         127
                                                                                                    FINANCE
                                                                                                    & COMPTABILITÉ
                                                                                                           FONCTIONS
         MARKETING        SALAIRE BAS   SALAIRE MOYEN                  SALAIRE HAUT                                                  SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                          COMPTABLES


                                                                                                      CHEF/RESPONSABLE
 CATEGORY MANAGER           924,000        1,305,000                       2,223,000                                                   270,000        1,078,000      2,540,000
                                                                                                         COMPTABLE




          CHARGÉ                                                                                     CHEF/RESPONSABLE
                            340,000        655,000                         1,303,000                                                   347,000        544,000        1,080,000
      TRADE MARKETING                                                                                COMPTABLE ADJOINT




                                                                                                           COMPTABLE
      CHEF DE PROJETS       231,000        522,000                         1,270,000                                                   270,000        401,000         800,000
                                                                                                           ANALYTIQUE




      CHEF DE PUBLICITÉ     470,000        684,000                         1,250,000                 COMPTABLE CLIENTS                 216,000        331,000         623,000




         DIRECTEUR                                                                                        COMPTABLE
                           1,118,000       1,896,000                       3,500,000                                                   270,000        360,000         635,000
         MARKETING                                                                                       FOURNISSEURS




        RESPONSABLE
                            231,000        957,000                         2,540,000                 COMPTABLE GÉNÉRAL                 193,000        395,000        1,334,000
         MARKETING




        RESPONSABLE
                            388,000        761,000                         1,400,000                    FONCTIONS CON-
      TRADE MARKETING
                                                                                                       TRÔLE DE GESTION,
                                                                                                                                     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                                        CONSOLIDATION
                                                                                                        & AUDIT INTERNE


                                                                                                           ASSISTANT
                                                                                                                                       270,000        343,000         635,000
                                                                                                           FINANCIER




                                                                                                          CONTRÔLEUR
                                                                                                                                       293,000        589,000        1,080,000
                                                                                                           DE GESTION




128                                                    Digital, Marketing & Communication SÉNÉGAL   SÉNÉGAL Finance & Comptabilité                                                129
                                                                                         INDUSTRIE :
                                                                                         INGÉNIEURS & TECHNICIENS
       FONCTIONS CON-
      TRÔLE DE GESTION,
                          SALAIRE BAS   SALAIRE MOYEN       SALAIRE HAUT
       CONSOLIDATION                                                                           MAINTENANCE
                                                                                                                                 SALAIRE BAS      SALAIRE MOYEN   SALAIRE HAUT
       & AUDIT INTERNE                                                                         INDUSTRIELLE


        RESPONSABLE                                                                            CHEF D'ÉQUIPE
                            462,000        811,000             1,905,000                                                                732,000      1,044,000      2,159,000
         FINANCIER                                                                             MAINTENANCE



       RESPONSABLE
                                                                                                 DIRECTEUR
       ADMINISTRATIF        308,000        989,000             3,175,000                                                            1,348,000        1,991,000      4,445,000
                                                                                                 TECHNIQUE
        ET FINANCIER


      FONCTIONS CREDIT
        MANAGEMENT,                                                                           RESPONSABLE
                          SALAIRE BAS   SALAIRE MOYEN       SALAIRE HAUT                                                                251,000      817,000        2,286,000
         TRÉSORERIE                                                                          DE MAINTENANCE
       & FINANCEMENT


                                                                                               TECHNICIEN
           AGENT
                            130,000        188,000              318,000                     DE MAINTENANCE/                             231,000      320,000         672,000
      DE FACTURATION
                                                                                               ÉLECTRICIEN


                                                                                               TECHNICIEN
           CHARGÉ
                            135,000        283,000              953,000                     DE MAINTENANCE/                             228,000      317,000         704,000
      DE RECOUVREMENT
                                                                                               MÉCANICIEN



    GESTIONNAIRE
                            200,000        480,000             1,000,000
 DE COMPTES CLIENTS

                                                                                               PRODUCTION/
                                                                                                                                 SALAIRE BAS      SALAIRE MOYEN   SALAIRE HAUT
                                                                                               EXPLOITATION
       RESPONSABLE
      RECOUVREMENT          316,000        620,000             1,524,000
      ET CONTENTIEUX                                                                           DIRECTEUR
                                                                                                                                    1,155,000        1,426,000      2,302,000
                                                                                             DES OPÉRATIONS
         FONCTIONS
                          SALAIRE BAS   SALAIRE MOYEN       SALAIRE HAUT
        DE DIRECTION


                                                                                            DIRECTEUR D’USINE                           616,000      1,577,000      2,871,000
      DAF FILIALE/SITE/
                            616,000        1,901,000           4,763,000
       BUSINESS UNIT


                                                                                               RESPONSABLE
                                                                                                                                        116,000      1,148,000      7,620,000
         DIRECTEUR                                                                            DE PRODUCTION
                           1,386,000       2,267,000           3,810,000
         FINANCIER



130                                                     Finance & Comptabilité SÉNÉGAL   SÉNÉGAL Industrie : Ingénieurs & Techniciens                                            131
                                                                                                   RESSOURCES HUMAINES

        QUALITÉ/HSE      SALAIRE BAS   SALAIRE MOYEN                SALAIRE HAUT

                                                                                                     AFFAIRES SOCIALES           SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT

      INGÉNIEUR QHSE       231,000        596,000                       1,143,000
                                                                                                          CHARGÉ
                                                                                                     ADMINISTRATION DU             212,000        342,000         699,000
                                                                                                        PERSONNEL

  INGÉNIEUR QUALITÉ        135,000        487,000                       1,905,000
                                                                                                        CHARGÉ DE
                                                                                                      COMPENSATION &               616,000        790,000        2,667,000
                                                                                                         BENEFITS

      RESPONSABLE HSE      193,000        535,000                       2,616,000

                                                                                                         CHARGÉ PAIE               231,000        308,000         521,000



  RESPONSABLE QHSE         270,000        586,000                       3,445,000
                                                                                                       GESTIONNAIRE
                                                                                                     ADMINISTRATION ET             270,000        453,000        1,016,000
                                                                                                           PAIE

       RESPONSABLE
                           174,000        604,000                       2,351,000
         QUALITÉ                                                                                       RESPONSABLE
                                                                                                     ADMINISTRATION DU             316,000        585,000        1,143,000
                                                                                                        PERSONNEL

      TECHNICIEN QHSE      154,000        324,000                        985,000
                                                                                                       RESPONSABLE
                                                                                                     ADMINISTRATION ET             185,000        690,000        1,778,000
                                                                                                           PAIE
  TECHNICIEN QUALITÉ       101,000        315,000                        635,000


                                                                                                     RESPONSABLE PAIE              308,000        552,000        1,016,000
           R&D/
      BUREAU D’ÉTUDES/   SALAIRE BAS   SALAIRE MOYEN                SALAIRE HAUT
          ESSAIS


       RESPONSABLE
       LABORATOIRE/        231,000        535,000                       1,055,000
          ESSAIS                                                                                     DÉVELOPPEMENT RH            SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                                                                                                       CHARGÉ DE
        TECHNICIEN
                                                                                                    COMMUNICATION RH/
       LABORATOIRE/        154,000        276,000                        508,000                                                   233,000        661,000        1,600,000
                                                                                                     COMMUNICATION
          ESSAIS
                                                                                                        INTERNE



132                                                 Industrie : Ingénieurs & Techniciens SÉNÉGAL   SÉNÉGAL Ressources Humaines                                                133
  DÉVELOPPEMENT RH      SALAIRE BAS   SALAIRE MOYEN     SALAIRE HAUT                    GÉNÉRALISTE RH              308,000        479,000        826,000



          CHARGÉ
                          233,000        661,000           1,600,000                       CHARGÉ RH                193,000        468,000        1,524,000
       DE FORMATION



           CHARGÉ
      DE RECRUTEMENT/     193,000        327,000            699,000                      DIRECTEUR RH               231,000        1,368,000      3,302,000
         RECRUTEUR




  CHASSEUR DE TÊTES       231,000        585,000           1,905,000                   GESTIONNAIRE RH              231,000        446,000        1,048,000




       RESPONSABLE
                          231,000        513,000           1,215,000                          HRBP                  326,000        979,000        2,286,000
      DE LA FORMATION




       RESPONSABLE
                          447,000        768,000           2,540,000                 RRH SITE INDUSTRIEL            308,000        622,000        1,524,000
      DE RECRUTEMENT




    RESPONSABLE
                          193,000        496,000           1,143,000                   RESPONSABLE RH               116,000        813,000        1,715,000
  DÉVELOPPEMENT RH




       RESPONSABLE
                          597,000        958,000           1,905,000
         MOBILITÉ

                                                                                      MÉTIERS DE LA RSE           SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT




                                                                                          CHARGÉ RSE                154,000        437,000         972,000
      GÉNÉRALISTE RH      308,000        479,000            826,000




       ASSISTANT RH       116,000        221,000            445,000                    RESPONSABLE RSE              616,000        1,325,000      3,810,000




134                                                   Ressources Humaines SÉNÉGAL   SÉNÉGAL Ressources Humaines                                                135
SYSTÈMES D’INFORMATION


                                                                                         INFRASTRUCTURES
        DATA & IA      SALAIRE BAS   SALAIRE MOYEN        SALAIRE HAUT                                                   308,000        479,000        826,000
                                                                                           & PRODUCTION


                                                                                         ADMINISTRATEUR
      DATA ANALYST       270,000        752,000              2,794,000                                                   216,000        492,000        1,207,000
                                                                                        SYSTÈMES/RÉSEAUX




                                                                                           DÉVELOPPEUR
      DATA ENGINEER      386,000        714,000              1,460,000                                                   280,000        643,000        1,540,000
                                                                                            MOBILE/WEB




                                                                                       INGÉNIEUR RÉSEAUX/
      DATA SCIENTIST     231,000        596,000              1,778,000                                                   215,000        512,000        1,180,000
                                                                                           SYSTÈMES




        FONCTIONS                                                                            SÉCURITÉ
                       SALAIRE BAS   SALAIRE MOYEN        SALAIRE HAUT                                                 SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
       DE DIRECTION                                                                      & CYBERSÉCURITÉ


         DIRECTEUR
                                                                                       ANALYSTE SÉCURITÉ/
      DES SYSTÈMES      1,155,000       1,849,000            3,810,000                                                   308,000        588,000        1,397,000
                                                                                           SOC/SIEM
      D’INFORMATION



       RESPONSABLE                                                                          INGÉNIEUR
                         424,000        978,000              2,667,000                                                   308,000        1,125,000      3,175,000
      INFORMATIQUE                                                                        CYBERSÉCURITÉ



     RESPONSABLE
  INFRASTRUCTURES/       770,000        1,291,000            2,435,000
  SYSTÈMES RÉSEAUX




136                                                  Systèmes d’Information SÉNÉGAL   SÉNÉGAL Systèmes d’Information                                                137
                   CLÉLI
               AZOKPOTA
                                         INTERVIEW

                                                                                                                                                 ̏   L'AFRIQUE A UN POTENTIEL
                                                                                                                                                     CRÉATIF ET AUDIOVISUEL
          DIRECTRICE GÉNÉRALE DE A+                                                                                                                  IMMENSE !
                                                                                                                                                        objectifs clairs et mesurables pour chaque membre de               Quels rôles les nouvelles technologies (comme l'IA ou la réalité
Titulaire d’un diplôme de Commerce International à NEOMA
                                                                                                                                                        l'équipe. Un suivi régulier et des évaluations constructives       augmentée) pourraient-elles jouer dans l'avenir des médias
Business School et d’un Mastère en Marketing Management                                                                                                 permettent de valoriser les réussites et d'identifier les axes     africains ?
       par la Qualité à SKEMA Lille, Cléli Azokpota cumule plus                                                                                         d'amélioration. Enfin, en renforçant l’engagement des équipes          « Des rôles cruciaux en matière d’analyse de données à
   de 15 ans d’expérience dans l’audiovisuel en Europe et en                                                                                            et en inspirant plus de rigueur. »                                     travers des analyses approfondies sur les tendances de
        Afrique. Aujourd’hui, en tant que Directrice générale de                                                                                                                                                               consommation et le comportement des audiences, de

       la chaîne A+ Bénin, elle a pour mission de faire rayonner                                                                                 Quels principes de leadership appliquez-vous pour maintenir une               production de contenu améliorée en automatisant certaines
                                                                                                                                                 dynamique de travail positive et performante dans un secteur                  tâches de production, et de formation en offrant des
      les talents, ainsi que les cultures béninoises et africaines
                                                                                                                                                 aussi créatif et en constante évolution ?                                     simulations réalistes pour apprendre des compétences
           à travers des programmes ﬁdélisant de fiction et de
                                                                             atouts cruciaux dans mon secteur d’activité.                               « Le premier principe : encourager une culture où les idées            pratiques. »
 divertissement… Une position idéale pour livrer une analyse
                                                                             Je suis une battante et crois en la capacité à se réinventer               nouvelles sont valorisées. En outre, j’essaie de partager une
          précise et encourageante d’un secteur qu’elle connaît              quels que soient les défis et obstacles ! »                                vision claire et de communiquer de façon transparente. Cela        Quel message souhaitez-vous transmettre aux jeunes Africains,
                                             particulièrement bien.                                                                                     inclut le partage des objectifs, des défis et des succès, afin     notamment aux jeunes femmes ?
                                                                         Vous êtes aux premières loges pour analyser le marché                          que chacun se sente impliqué et informé. Il s’agit également           « Voici une série de conseils qui m’ont beaucoup aidée :
Pouvez-vous, dans un premier temps, nous retracer votre                  audiovisuel béninois…                                                          de promouvoir le travail en équipe et les projets collaboratifs.       • Croyez en vous-même, ayez confiance en vos compétences
parcours dans l’audiovisuel et, plus particulièrement, au sein du            « C’est un écosystème jeune et en plein essor, notamment                   La reconnaissance et la valorisation sont essentielles, il est         et en votre vision.
Groupe Canal+ ?                                                              avec l’arrivée de la TNT qui va permettre une croissance de                important de célébrer les succès individuels et collectifs.            • Soyez audacieuses, n'hésitez pas à prendre des risques et à
      « J’ai débuté ma carrière chez TV5MONDE en tant que                    l’offre de contenus produits localement. Les enjeux sont                   Flexibilité et adaptabilité… Il faut être prêt à ajuster les           saisir des opportunités.
      Responsable Distribution Europe à Paris, avant de rejoindre le         multiples :                                                                stratégies et les processus en fonction des évolutions du              • Cherchez des mentors, entourez-vous de personnes qui
      Groupe RTI (Radio Télédiffusion Ivoirienne) en Côte d’Ivoire en        • Identifier, détecter, développer et accompagner les talents              secteur et des besoins de l'équipe.                                    vous inspirent.
      tant que Responsable Business Développement. J’ai ensuite              pour trouver des projets locaux, des histoires universelles et             Enfin, je préconise le soutien au développement personnel, en          • Investissez dans votre éducation.
      intégré le Groupe Canal+ en 2018 en tant que Directrice des            originales qui pourront voyager et faire voyager les cultures              encourageant la formation continue et le développement des             • Réseautez et engagez-vous dans des communautés.
      Acquisitions et des coproductions de fiction des chaînes A+.           béninoises et africaines ;                                                 compétences. Investir dans les talents de l’équipe contribue à         • Soyez résilientes, le chemin vers le leadership peut être
      J’ai alors participé activement au lancement de la chaîne              • Initier des partenariats stratégiques en collaborant avec des            son épanouissement et à la performance globale ! »                     semé d’embûches. Apprenez à rebondir après les échecs et à
      A+IVOIRE en développant des marques programmes fortes                  producteurs locaux et panafricains pour renforcer la qualité                                                                                      considérer chaque défi comme une opportunité de croissance.
      ("Les coups de la vie", "La bataille des chéries", "Charles            des productions ;                                                   Comment percevez-vous l'évolution de l'industrie des médias en                • Engagez-vous pour les autres, encouragez et inspirez les
      Ornel", "La dernière voix"…). En juillet 2024, j’ai été nommé          • Avoir une vraie implication au niveau formation pour              Afrique pendant les dix prochaines années ?                                   autres à poursuivre leurs rêves…
      Directrice générale de la chaîne A+ BÉNIN. »                           renforcer les talents locaux et les équipes techniques. »                  « Prometteuse, avec plusieurs changements majeurs à                    Et sachez que chaque pas que vous faites pave la voie pour
                                                                                                                                                        anticiper : la diversification du contenu, une digitalisation          celles qui viendront après vous. Soyez fières de votre parcours
Quels sont les atouts que vous avez mis en avant pour évoluer            Quelles sont vos priorités en matière de gestion des talents et de             accrue, le renforcement des lois anti piratages pour                   et continuez à avancer avec détermination et passion. L'avenir
ainsi professionnellement ?                                              développement d'une équipe performante ?                                       protéger les créateurs de contenus et le développement                 vous appartient ! »
      « Je pense que mes points forts sont les suivants :                    « La culture de collaboration et du résultat, en favorisant un             d’une technologie immersive et interactive. L'industrie des
      • Mettre l’humain au centre de tout . Nous sommes au cœur              environnement de travail où la collaboration et l’esprit d’équipe          médias en Afrique devrait ainsi connaître une transformation       Pour que l'Afrique devienne un acteur majeur dans l'industrie
      d’une industrie créative au sein de laquelle il est essentiel de       sont encouragés dans le but d’atteindre des résultats, à travers           dynamique, portée par l'innovation, la créativité et une volonté   mondiale des médias, selon Cléli Azokpota :
      comprendre les équipes et savoir les accompagner                       des ateliers créatifs, des projets transversaux et des réunions            croissante de raconter les histoires du continent. »               investir dans la formation, promouvoir la diversité culturelle,
      • Le sens de l’organisation et de la rigueur                           régulières pour partager des idées et des retours d’expérience.                                                                               créer des partenariats internationaux, renforcer les réseaux
      • Une grande flexibilité et une capacité d’adaptation, des             Ensuite, la gestion des performances, en établissant des                                                                                      professionnels.


138                                                                                                                  Systèmes d’Information          Systèmes d’Information                                                                                                                  139
      BÉNIN
       GRILLE SALARIALE




140                  bénin
ACHATS
& SUPPLY CHAIN
          BUYING                                                                               LOGISTICS
                            SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                                               SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
      & PROCUREMENT                                                                         & SUPPLY CHAIN

        ACHETEUR
       GÉNÉRALISTE                                                                          MAGASINIER/
                              247,000        413,000          1,059,000                                                 84,000         239,000         389,000
    MP/INDUSTRIEL/IT/                                                                     MANUTENTIONNAIRE
 SERVICES/TL/DISTRIBUTION



                                                                                             RESPONSABLE
 ACHETEUR MATIÈRES
                              396,000        531,000           888,000                        D'ENTREPÔT/               220,000        307,000         511,000
     PREMIÈRES
                                                                                            D'ENTREPOSAGE



                                                                                          RESPONSABLE FLUX
  ASSISTANT ACHATS            92,000         299,000           533,000                                                  194,000        378,000         777,000
                                                                                              & STOCKS




      GESTIONNAIRE                                                                            RESPONSABLE
                              175,000        495,000           984 000                                                  308,000        546,000        1,332,000
         ACHATS                                                                                LOGISTIQUE




      RESPONSABLE
                              264,000        941,000          2,775,000
        ACHATS

                                                                                               TRANSPORT              SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT



                                                                                          AGENT DE TRANSIT/
                                                                                                                        97,000         252,000         888,000
         LOGISTICS                                                                           AFFRÊTEUR
                            SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT
      & SUPPLY CHAIN


                                                                                            RESPONSABLE/
  AGENT LOGISTIQUE/
                              220,000        448,000          1,554,000                   CHEF DÉPARTEMENT              308,000        536,000        1,055,000
     LOGISTICIEN
                                                                                               TRANSIT



       ASSISTANT
                              88,000         279,000           655,000
       LOGISTIQUE




 GESTIONNAIRE FLUX &
                              88,000         192,000           533,000
       STOCKS




142                                                       Achats & Supply Chain BÉNIN   BÉNIN Achats & Supply Chain                                                143
COMMERCIAL
                                                                                     HIGH TECH/
                                                                                     SOFTWARE/       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                                                                                   HARDWARE/WEB
        ASSURANCE       SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


                                                                                    RESPONSABLE
                                                                                                       282,000        720,000        1,845,000
        COMMERCIAL                                                                  COMMERCIAL
                          92,000         242,000         678,000
       B-TO-B/B-TO-C


                                                                                      TECHNICO-
                                                                                     COMMERCIAL        80,000         249,000         712,000
       RESPONSABLE                                                                    ITINÉRANT
                          220,000        441,000        1,044,000
       COMMERCIAL


                                                                                      INDUSTRIE      SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
          BANQUE        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT


  CHARGÉ D’AFFAIRES                                                                   DIRECTEUR
                                                                                                       352,000        1,202,000      3,308,000
      GRANDES             502,000        650,000        1,110,000                    COMMERCIAL
    ENTREPRISES

                                                                                DIRECTEUR NATIONAL
      CHEF DE SERVICE                                                               DES VENTES/        880,000        971,000        1,776,000
        CLIENTÈLES        537,000        869,000        1,554,000                 SALES DIRECTOR
         PME/PMI


          GRANDE                                                                    RESPONSABLE
      CONSOMMATION/     SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                                     154,000        283,000        1,554,000
                                                                                    COMMERCIAL
      GMS/CHR/RHF/GDS


         DIRECTEUR                                                                    TECHNICO-
                          664,000        1,615,000      3,830,000                    COMMERCIAL        84,000         217,000         601,000
        COMMERCIAL
                                                                                      ITINÉRANT


                                                                                  SERVICES/B-TO-B/
        DIRECTEUR                                                                                    SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
                          440,000        1,214,000      3,330,000                     MÉDIAS
        MARKETING

                                                                                     COMMERCIAL
                                                                                                       31,000         193,000         611,000
                                                                                    B-TO-B/B-TO-C
       RESPONSABLE
                          154,000        434,000        2,196,000
       COMMERCIAL

                                                                                     CONSULTANT
 HIGHTECH/SOFTWARE/                                                                                    75,000         248,000         444,000
                        SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT                   COMMERCIAL
    HARDWARE/WEB


         DIRECTEUR                                                                  RESPONSABLE
                          418,000        1,132,000      3,083,000                                      88,000         415,000         888,000
        COMMERCIAL                                                                  COMMERCIAL




144                                                         Commercial BÉNIN   BÉNIN Commercial                                                   145
DIGITAL, MARKETING
& COMMUNICATION

      COMMUNICATION   SALAIRE BAS   SALAIRE MOYEN                 SALAIRE HAUT                        MARKETING                      SALAIRE BAS    SALAIRE MOYEN   SALAIRE HAUT



      CONSULTANT EN
                        88,000         182,000                        333,000                      CHEF DE PROJETS                        106,000      235,000         555,000
      COMMUNICATION




       RESPONSABLE                                                                                   RESPONSABLE
                        159,000        443,000                       1,332,000                                                            88,000       330,000         777,000
      COMMUNICATION                                                                                   MARKETING




         DIGITAL      SALAIRE BAS   SALAIRE MOYEN                 SALAIRE HAUT


       CHARGÉ
  DE COMMUNICATION      115,000        275,000                        777,000
       DIGITALE



       COMMUNITY
                        88,000         152,000                        333,000
        MANAGER




       CONSULTANT
                        176,000        350,000                        777,000
       SEA/SEO/SEM




       RESPONSABLE
                        440,000        516,000                        777,000
          DIGITAL




       WEBMASTER        88,000         273,000                        555,000




146                                                 Digital, Marketing
& Communication BÉNIN   BÉNIN Digital, Marketing
& Communication                                            147
FINANCE                                                                                RESSOURCES HUMAINES
& COMPTABILITÉ
         FONCTIONS
                          SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT                      GÉNÉRALISTE RH          SALAIRE BAS   SALAIRE MOYEN   SALAIRE HAUT
        COMPTABLES


  CHEF/RESPONSABLE
                            154,000        684,000           1,665,000                      ASSISTANT RH             154,000        320,000         555,000
     COMPTABLE




 COMPTABLE GÉNÉRAL          132,000        253,000            555,000                         CHARGÉ RH              132,000        402,000         847,000




         COMPTABLE
                            220,000        414,000            733,000                       DIRECTEUR RH            1,320,000       1,802,000      4,440,000
         TRÉSORERIE




       FONCTIONS CON-                                                                     RESPONSABLE RH             286,000        555,000        1,443,000
      TRÔLE DE GESTION,
                          SALAIRE BAS   SALAIRE MOYEN    SALAIRE HAUT
       CONSOLIDATION
       & AUDIT INTERNE



      AUDITEUR INTERNE      440,000        600,000            888,000




        CONTRÔLEUR
                            352,000        780,000           1,443,000
         DE GESTION



       RESPONSABLE
       ADMINISTRATIF        176,000        528,000           1,665,000
        ET FINANCIER




148                                                     Finance& Comptabilité BÉNIN   BÉNIN Ressources Humaines                                                149
                                                                                                                                                                                                    ̏   J E VOIS
                                                                                                                                                                                                        QUOTIDIENNEMENT
                                                                                                     INTERVIEW                                                                                          DES FEMMES
LONGA ANDREA MBUYAMBA                                                                                                                                                                                   QUI IMPACTENT
      Longa Andrea Mbuyamba est consultante en transformation digitale & gender advisor. Elle est la Fondatrice d'Abidjanaises
                                                                                                                                                                                                        LEUR COMMUNAUTÉ
          In Tech, une organisation qui veut renforcer et promouvoir la participation des femmes dans le domaine du numérique
 en Côte d’Ivoire, elle est également fondatrice d’Africaines In Tech le réseau d'expertise panafricain composé de plus de 550
                                                                                                                                                                                                        GRÂCE AU
femmes réparties entre Abidjan, Dakar et Lomé. Entre 2021 et 2023, elle a occupé le poste de Head of Organisation & Change
Management au sein du groupe COFINA. Vous l’avez compris, le numérique et la place de la femme dans le marché du travail                                                                                NUMÉRIQUE
                                                                                                  ouest-africain, elle connait !




Pouvez-vous, dans un premier temps, nous détailler                 Avez-vous noté des contributions particulières des              Qu’attendez-vous maintenant comme évolution, comme               Un dernier conseil pour les jeunes talents femmes qui vont
votre perception de la place des femmes dans l'industrie           femmes dans ce secteur ?                                        changements en faveur des femmes ?                               vous lire ?
numérique en Côte d'Ivoire ?                                          « Étant dans une communauté de femmes expertes                  « Je suis un peu rêveuse… Et mon rêve, c'est vraiment              « Il est impossible d’ignorer le numérique : de nom-
      « Je suis une femme dans le domaine du numérique qui            en technologie, les contributions, je les vois vraiment         qu'on arrive à créer de l’impact dans toute l'Afrique fran-        breuses opportunités émergeront dans ce domaine à
      évolue dans l'écosystème "tech" ivoirien depuis main-           quotidiennement. Je vois des femmes qui créent des              cophone en connectant les femmes. J'ai vu le pouvoir               travers tout le continent. Il est essentiel de s’y intéresser,
      tenant trois ans et je peux vous dire qu'il y a beaucoup        applications. Je vois des femmes qui proposent des              de la sororité numérique à notre échelle et j'aimerais             même sans forcément envisager une carrière dans le
      d'opportunités pour les femmes. ! C'est un écosystème           solutions grâce à des technologie de pointe. Je vois            vraiment qu'on arrive à dupliquer cette échelle, à la ren-         numérique, car peu importe le secteur d’activité, chacun
      qui est en pleine ébullition, il y a vraiment la lumière        des femmes qui impactent leur communauté grâce au               dre panafricaine, pour permettre à toutes les "women               sera impacté. Cette curiosité est cruciale, et il ne faut
      sur la "tech" en Côte d'Ivoire, ce qui ouvre de très nom-       numérique. Je vois des femmes qui sont très engagées            in tech" qui sont partout de créer des synergies et faire          pas hésiter à se tourner vers des communautés prêtes
      breuses opportunités dans tous les secteurs d'activité          dans la formation des jeunes, des communautés mar-              des projets. Aujourd’hui, nous connaissons beaucoup                à vous accompagner dans l’accès au numérique. Beau-
      en termes de carrière, d'emploi, d'affaires… Mais ce que        ginalisées. Je vois des femmes qui prennent la parole           plus de modèles de réussite et la réussite telle que               coup d’aspects peuvent sembler complexes, mais ils ne
      j'ai pu voir aussi très rapidement, c'est qu’au sein de         à l'international pour représenter la Côte d'Ivoire dans        nous la définissons ce n'est pas le succès ! La réussite,          le sont pas forcément. Le numérique peut être acces-
      tous les différents acteurs qui composent cet écosys-           des débats de très haut niveau. Je vois également               ce sont des expériences et des trajectoires de vie qui             sible à tous, à condition de démystifier ce qui semble
      tème, la femme n’est encore pas assez représentée. »            des femmes qui proposent des médias suivis par des              mènent à l'épanouissement. Et il existe de plus en plus            intimidant.
                                                                      milliers de personnes et qui mettent en avant justement         de modèles qui font qu’un nombre croissant de jeunes               Se former, bien entendu, et toujours rester en veille sur
                                                                      toutes ces contributions. Je vois des femmes qui diri-          filles pourront se référer à des héroïnes du quotidien             les réseaux sociaux, suivre des pages sur l'actualité
                                                                      gent des entreprises technologiques, des grandes en-            inspirantes, surtout dans le domaine du numérique. »               technologique, sur l'actualité des entreprises qui vous
                                                                      treprises, des PME qui fonctionnent, des femmes qui                                                                                intéressent, et surtout apprendre à développer et animer
                                                                      forment des employés, des talents de qualité… Et ça je                                                                             son réseau… Parce que même à l’ère du digital, le rela-
                                                                      le vois vraiment quotidiennement ! »                                                                                               tionnel humain demeure essentiel et reste la véritable
                                                                                                                                                                                                         clé pour créer des opportunités. »


150                                                                                                                   interview    interview                                                                                                                       151
                                                                           REMERCIEMENTS
                                                                           Sans les idées, le savoir-faire et l'engagement de prestataires extérieurs, cette nouvelle édition
                                                                           du Guide des Salaires de Grey Search Africa n'aurait certainement pas vu le jour.
                                                                           Je tiens donc à souligner la qualité du travail et de l'implication de :


                                                                           SOPHIA EL HAJAJ GNASSOUNOU
                                                                           Consultante gestion de projet GSA
                                                                           Consultante Entrepreneuriat et Innovation HEC Paris
                                                                           selhajaj@gmail.com




L'ÉDITION
                                                                           sophia.el-hajaj@external-hec.fr
            La perfection naît souvent de l'amélioration continue.
            Réinventer l'existant représente un déﬁ plus exigeant que
                                                                           HEC PARIS
            la création initiale, car chaque modiﬁcation porte en elle



    DE LA
                                                                           Partenaire principal du Guide des Salaires - 3ème édition
            l'ambition du progrès.
                                                                           Bureau Afrique de l'Ouest et Afrique Centrale
                                                                           migan@hec.fr



MATURITÉ
            Les deux premières éditions du Guide des Salaires
                                                                           chanthavong@hec.fr
            témoignaient déjà de l'excellence et de l'engagement
            remarquable de l'équipe Grey Search Africa. Cette
                                                                           SEBASTIEN GAVINI
            troisième édition franchit un nouveau cap en élargissant
                                                                           Copywriting
            son horizon : aux analyses approfondies s'ajoute
                                                                           sebgavini@hotmail.com
            désormais le Bénin, enrichissant notre exploration à côté
            de la Côte d'Ivoire et du Sénégal.
                                                                           CLELIA BENARD
                                                                           Couverture vidéo
            À vous, chers collègues et partenaires, qui avez transformé
                                                                           clelia.benard@gmail.com
            ce guide en un outil toujours plus complet et pertinent,
            j'exprime ma plus sincère gratitude. Votre engagement
                                                                           JENNIFER LIVERSAIN
            et votre expertise ont donné naissance à ce que nous
                                                                           Direction artistique et création graphique
            pouvons ﬁèrement appeler "L'édition De La Maturité".
                                                                           jliversain@lessignes-ci.com




152                                                        REMERCIEMENTS   REMERCIEMENTS                                                                                        153
   Retrouvez-nous sur
www.greysearchafrica.com
