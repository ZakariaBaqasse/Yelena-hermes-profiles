# 260922_Conventions collectives sectorielles CI

===== onglet t.0 · Tab 1 · 38 lignes non vides =====

# Les conventions collectives sectorielles ivoiriennes
Relevé du 22/09/2026, demandé par la direction pour FATOU (paie) et ADJOUA (recrutement).
## ⛔ Le point qui change la question
On cherchait « toutes les conventions sectorielles ». Elles n'existent pas branche par branche, et c'est voulu. L'arrêté n° 1 MTIC, CAB, du 3 janvier 1978 rend la convention interprofessionnelle du 19 juillet 1977 obligatoire pour tous les employeurs et tous les travailleurs de douze branches, y compris ceux qui ne l'ont pas signée (article 2). Pour ces branches, la convention applicable EST l'interprofessionnelle, et nous l'avons déjà sur disque.

Les douze branches couvertes par l'extension, recopiées du texte :

- Industries et commerces de toute nature
- Mécanique générale
- Bâtiment, travaux publics et entreprises connexes
- Entreprises de distribution de produits pétroliers
- Auxiliaires de transports (mer, terre, air)
- Transports urbains et interurbains
- Transports routiers
- Entreprises du secteur automobile
- Transports maritime, aérien et lagunaire, sauf le personnel relevant du code de la Marine marchande
- Banques, assurances, crédits, affaires immobilières
- Hôtellerie
- Électricité, gaz, eau, service sanitaire, et les organisations connexes

⚠ Conséquence pratique, à ne pas rater : « il n'y a pas de convention pour le BTP » est faux. Le BTP est à la ligne 3, il est couvert, et un employeur du BTP ne peut pas s'y soustraire au motif qu'il n'a rien signé.
## Ce qui existe EN PLUS, par branche
| Branche | Texte | Chez nous |
| Mines et carrières | Convention collective Mines & Carrières 2023, signée le 12/05/2023 entre le GPMCI et la FISMECA, annexe à la convention de 1977 | ✅ convention-mines-et-carrieres-2023.pdf, 81 pages, texte intégral |
| Banques et établissements financiers | Convention sectorielle signée le 20/08/2025 entre l'APBEF-CI et le SYNABEFA-CI | ⛔ texte non publié. Seule la presse en rend compte |
| Travailleurs occasionnels dits « journaliers » | Convention annexe à celle de 1977 | ✅ dans arrete-1-1978-extension-conv-interpro.txt |
## Ce que chaque pièce apporte, et ce qu'elle ne donne pas
convention-mines-et-carrieres-2023.pdf porte la classification professionnelle (art. 62), les catégories (art. 69) et le barème des salaires (art. 70). C'est la seule grille de branche complète que nous ayons. Elle ne vaut que pour les mines et carrières : l'appliquer ailleurs serait une faute.

arrete-1-1978-extension-conv-interpro.txt porte l'extension et la convention annexe « journaliers », qui fixe l'indemnité de précarité : 3 % du salaire horaire minimum de la catégorie majoré de la gratification, au-delà de trois mois de présence. Utile à FATOU dès qu'un bulletin concerne un journalier.

⛔ Ce que nous n'avons pas, et qui ne se télécharge pas :

- Le texte de la convention bancaire 2025. Il se demande à l'APBEF-CI ou au SYNABEFA-CI. D'ici là, pour une banque, on applique l'interprofessionnelle de 1977 (branche 10) et on dit qu'un texte plus récent existe sans qu'on l'ait lu.
- Les grilles de salaires de branche autres que celle des mines. Les barèmes catégoriels circulent sur des sites d'emploi et des agrégateurs ; ce ne sont pas des sources conventionnelles et ils ne se citent pas comme telles.
- Le site du ministère de l'Emploi (emploi.gouv.ci) répond 403 à toute connexion, y compris par navigateur, au 22/09/2026. Ce n'est pas un filtrage d'agent : la réponse ne porte ni error code: 1010 ni _cf_chl_opt. droit-afrique.com rend un 403 de serveur mal configuré (« unable to read htaccess file »), pas un refus qui nous viserait.
## Où l'on a regardé
emploi.gouv.ci (403) · travail.gouv.ci (le domaine n'existe pas) · droit-afrique.com (403 serveur) · droitci.info · loidici.biz (l'extension de 1978 vient de là) · chambredesmines.org (la convention minière vient de là) · cgeci.com et la presse économique pour la convention bancaire.
## Le geste, pour un dossier de paie ou de recrutement
- Identifier la branche de l'employeur dans la liste des douze.
- Si c'est mines et carrières, ouvrir la convention de 2023 : classification et barème y sont.
- Si c'est banques, assurances, crédits, immobilier, appliquer 1977 et signaler qu'une convention de 2025 existe, non lue.
- Sinon, appliquer la convention interprofessionnelle de 1977, dans ../convention-interprofessionnelle-1977.pdf, avec le Code du travail 2015-532 et l'ordonnance 2021-902 par-dessus.
- Ne jamais servir une grille trouvée sur un site d'emploi comme un minimum conventionnel.
