# 260922_Diplomes et etablissements en Cote d'Ivoire - ce qui se verifie

===== onglet t.0 · Tab 1 · 37 lignes non vides =====

# Diplômes et établissements : ce qui se vérifie, et ce qui ne se vérifie pas
Écrite le 22/09/2026. ⛔ Deux niveaux à ne jamais confondre : la reconnaissance, qui est un fait vérifiable, et la réputation, qui n'en est pas un. Un recruteur qui les mélange fonde une décision sur une rumeur.
## 1. La reconnaissance : elle se vérifie, et la liste est publique
Le ministère de l'Enseignement supérieur publie son répertoire des établissements autorisés sur bac.mesrs-ci.net. Relevé le 22/09/2026, données brutes dans releves/ :

| Catégorie | Nombre d'établissements autorisés |
| Universités privées | 145 |
| Grandes écoles privées | 615 |
| Total privé | 760 |

⛔ Ce qui ne figure pas dans ce répertoire n'est pas reconnu par l'État ivoirien. C'est le premier geste de vérification, et il est gratuit et immédiat.

Chaque ligne du répertoire porte la ville, la commune, la capacité d'accueil, les frais d'inscription et la liste des filières. Les frais sont renseignés pour 77 des 145 universités et 487 des 615 grandes écoles : un établissement sans frais publiés n'est pas une anomalie, mais ce n'est pas une information disponible.

La géographie est écrasante :

|  | Abidjan | Cocody seule | Bouaké | Yamoussoukro |
| Universités privées | 111 sur 145 | 75 | 9 | 6 |
| Grandes écoles privées | 430 sur 615 | 167 | 29 | 22 |

Soit 71 à 77 % des établissements privés à Abidjan, et Cocody à elle seule en concentre plus de la moitié. Un candidat formé hors d'Abidjan vient donc d'un vivier étroit, et ce n'est pas un signal de qualité, c'est un fait de géographie.

Les établissements publics de référence dont l'adresse a été vérifiée : inphb.edu.ci ⚠ l'INP-HB a changé de domaine, inphb.ci redirige · esatic.ci · univ-fhb.edu.ci.

Au niveau régional, le CAMES accrédite programmes et établissements. Une accréditation CAMES est un second niveau de reconnaissance, distinct de l'autorisation nationale.
## 2. La réputation : elle ne se vérifie pas
⛔ Il n'existe aucun classement ivoirien avec méthode publiée. Ce qui circule vient de sites d'orientation commerciaux, qui vivent de la mise en relation avec les écoles qu'ils classent.

Ne pas les citer dans un livrable. La hiérarchie de prestige se recueille auprès des employeurs du secteur concerné, se date, et se présente comme une perception, jamais comme une mesure.
## 3. L'authenticité d'un document : un autre guichet, un autre geste
Vérifier qu'un établissement est reconnu ne dit rien de la validité du diplôme présenté par un candidat. C'est une démarche distincte, auprès d'une autre administration.

| Démarche | Qui | Coût | Pièces |
| Authentification d'une licence, d'une maîtrise ou d'un DESS | Direction de l'enseignement supérieur, Abidjan Plateau, immeuble Lamblin, rez-de-chaussée | 10 000 FCFA la première demande, 5 000 FCFA les suivantes | baccalauréat, relevés de notes, diplômes intermédiaires et diplôme à authentifier, chacun en original plus deux copies, photocopie de la pièce d'identité, CV, extrait de naissance, formulaire de demande |
| Équivalence d'un diplôme étranger de niveau inférieur ou égal au bac | DECO, sous-direction de l'homologation et de l'authentification, service des équivalences | 1 000 FCFA | demande manuscrite, original et photocopie du diplôme et du relevé, pièce d'identité, autorisation de recherche, enveloppe timbrée et coupon-réponse, photo d'identité en couleur |

Conditions et principes :

- L'authentification suppose que les études aient été faites dans un établissement accrédité au niveau national. D'où l'enchaînement : d'abord le répertoire, ensuite le guichet.
- L'authenticité de l'homologation se constate par l'apposition du sceau du ministre chargé de l'Enseignement supérieur sur le diplôme.
- Contacts de la Direction de l'enseignement supérieur : +225 27 20 32 21 13 · 27 20 33 54 64 · 27 20 21 06 79.
- Des plateformes en ligne existent, eda.edemarches.gouv.ci et le portail DEXCO du MESRS, ⚠ mais leurs pages ne servent aucun contenu à un outil : elles n'ont pas pu être lues, et leur périmètre exact reste à confirmer.

⚠ Le délai de traitement n'est publié nulle part, ni pour l'authentification ni pour l'équivalence. Ne pas en promettre un à un client. ⟦à demander au guichet⟧

⚠ C'est le candidat qui détient les originaux. Un employeur ne peut pas lancer seul une authentification : la démarche suppose des originaux, un CV et un extrait de naissance. En pratique, on la demande au candidat, on ne la fait pas à sa place.
## Ce que cette fiche ne couvre pas
- La liste des établissements publics, dont la page équivalente n'a rendu aucun tableau. ⟦à reprendre⟧
- La vérification d'antécédents autre que le diplôme : casier judiciaire, emplois antérieurs. ⟦à documenter⟧
- Les équivalences de diplômes étrangers du supérieur, distinctes de celles de niveau bac.

Relevé du 22/09/2026, à rejouer avec releves/mesrs.py. À recontrôler le 22/03/2027 : le répertoire bouge à chaque rentrée.
