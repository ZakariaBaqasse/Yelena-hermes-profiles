# 260922_Ou sont vraiment les candidats en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 25 lignes non vides =====

# Où sont vraiment les candidats en Côte d'Ivoire
Écrite le 22/09/2026. Elle répond à une question de diffusion, pas de sourcing : où poster une offre pour qu'elle soit vue, et ce qui se ferme à un outil.
## Les portails, et leurs pièges d'accès
| Canal | Adresse | Ce qu'il faut savoir |
| Agence Emploi Jeunes | agenceemploijeunes.ci | Public et gratuit, numéro court 98 197. Six entrées dont Offres diaspora. Affichait 2 900+ offres et 6 600 opportunités le 22/09. ⚠ Site en JavaScript : ne rend rien à un script, il faut un navigateur |
| Educarrière | educarriere.ci | Portail privé historique, très utilisé |
| Emploi.ci | emploi.ci | Répond, mais filtre les scripts en 403. S'ouvre au navigateur |
| AGEFOP |  | Formation professionnelle |

⚠ Deux de ces trois sites refusent un outil automatique. Un relevé d'offres se fait au navigateur, et un script qui échoue là-dessus n'est pas cassé, il est filtré.
## Les comptes de diffusion, avec leur audience mesurée
Relevé le 06/09/2026, corpus de visuels d'offres.

| Compte | Abonnés |
| Agence Emploi Jeunes | 10 643 |
| Jeunes d'Avenirs | 8 608 |
| AGEFOP CI | 499 |

⛔ Ces chiffres relativisent tout le reste. Le premier diffuseur institutionnel du pays plafonne à onze mille abonnés. Une offre qui compte sur la seule diffusion en ligne touche un public étroit, et l'écart avec les audiences des grandes marques ivoiriennes (voir numerique-ci/) dit que l'emploi n'est pas un sujet à forte audience organique.
## ⛔ La limite structurelle, et elle ne se contourne pas
Les groupes WhatsApp d'emploi sont fermés et non indexés. Ils concentrent une part réelle de la circulation des offres, et on n'y entre pas par un outil : on y entre par un humain, ou pas du tout. Aucune mesure n'en est possible depuis cette machine, et aucune estimation ne sera écrite ici.

Conséquence pratique pour un client : la diffusion d'une offre se fait aussi par relais humain, et un plan de sourcing qui n'énumère que des portails est incomplet par construction.
## Ce que cette fiche ne couvre pas
- Les écoles comme canal, qui relèvent de la ligne sur les établissements de formation.
- LinkedIn et les réseaux professionnels, dont la pénétration réelle en Côte d'Ivoire n'a pas été mesurée ici. ⟦à mesurer⟧
- Le coût d'une publication sur les portails privés. ⟦à demander⟧
- Les cabinets de recrutement de la place.

À recontrôler le 22/03/2027.
