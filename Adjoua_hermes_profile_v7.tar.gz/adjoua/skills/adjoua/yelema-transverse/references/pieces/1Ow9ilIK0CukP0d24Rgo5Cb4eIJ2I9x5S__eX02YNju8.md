# 260922_Recruter un travailleur non ivoirien

===== onglet t.0 · Tab 1 · 28 lignes non vides =====

# Recruter un travailleur non ivoirien
Établi le 22/09/2026 pour ADJOUA (recrutement) et FATOU (paie). Texte intégral de l'arrêté dans arrete-4810-1997-visa-contrat-non-ivoiriens.txt.
## Les trois obligations, dans l'ordre où elles tombent
1. Publier le poste deux mois avant de regarder à l'étranger. Article 2 : tout poste doit faire l'objet d'une annonce pendant deux mois auprès des organismes de placement agréés par l'État ou par tout autre moyen approprié. Ce n'est qu'au terme de cette période, et si le poste n'est pas pourvu par un Ivoirien, que l'employeur est autorisé à recruter un candidat d'une autre nationalité.

⚠ C'est la règle que les dossiers oublient le plus, et elle est chronologique : un recrutement d'expatrié décidé sans ces deux mois d'annonce préalable est irrégulier dès l'origine. Il faut donc en garder la preuve.

2. Faire viser le contrat AVANT l'entrée sur le territoire. Article premier : tout travailleur d'une autre nationalité doit être titulaire d'un contrat de travail ou d'une lettre d'embauche visé par le ministre chargé de l'Emploi, sur un formulaire établi à cet effet, et ce document doit être obtenu avant l'admission du travailleur sur le territoire ivoirien.

3. Demander la carte de travail dans les trois mois. Toujours l'article premier : dans un délai de trois mois maximum à compter de la date d'embauche, le travailleur non ivoirien demande la délivrance d'une carte de travail à son nom. Elle est renouvelable une fois par an et exigible à tout contrôle.
## Les frais de formulaire, article 4
Ils dépendent de l'origine et de la catégorie professionnelle, et l'écart est considérable : d'un facteur 7,5 entre un directeur CEDEAO et un directeur non africain.

| Poste | CEDEAO | Africain hors CEDEAO | Non africain |
| Direction | 100 000 | 300 000 | 750 000 |
| Cadre | 80 000 | 200 000 | 500 000 |
| Agent de maîtrise | 60 000 | 100 000 | 300 000 |
| Ouvrier spécialisé ou employé qualifié | 40 000 | 60 000 | 100 000 |
| Manœuvre | 10 000 | 20 000 | 40 000 |

En francs CFA. Frais d'établissement du formulaire, quelle que soit la durée du contrat.

⚠ Le traitement de faveur CEDEAO est un argument de sourcing. À compétence égale, un candidat de la sous-région coûte trois à sept fois moins cher en frais de dossier qu'un candidat non africain. Cela se dit à un client qui hésite sur son vivier.
## ⛔ Deux réserves sérieuses avant de citer ces montants
L'arrêté date de 1997 et nous n'avons pas vérifié qu'il est toujours en vigueur au tarif indiqué. Une source secondaire mentionne un décret n° 6421 du 15 juin 2004 sur le même objet, que nous n'avons pas rapatrié. Un barème administratif de vingt-neuf ans se reconfirme avant d'être servi à un client.

L'article 7 confie l'exécution au directeur de l'Agence d'Études et de Promotion de l'Emploi. ⛔ L'AGEPE a été dissoute en 2015. Le texte nomme donc une administration qui n'existe plus, ce qui ne l'abroge pas mais signale qu'il n'a pas été toilette depuis. Pour l'interlocuteur réel aujourd'hui, se tourner vers le ministère chargé de l'Emploi et l'Agence Emploi Jeunes. Ne jamais écrire « AGEPE » dans un livrable.
## Ce que dit le Code du travail par-dessus
- Article 26.8 : les dispositions du contrat ne font pas obstacle à la réglementation sur les conditions d'admission et de séjour des étrangers. Le droit du travail et le droit du séjour se cumulent, ils ne se remplacent pas.
- Article 12 du titre sur le placement : le recrutement à l'étranger d'un travailleur non ivoirien par un bureau de placement payant ne peut se faire qu'après le visa du contrat, préalablement à l'admission sur le territoire. Et le placement à l'étranger d'un travailleur ivoirien sans visa préalable entraîne la rupture du contrat à la charge de l'employeur.
## Ce que cette note ne couvre pas
- Le décret n° 6421 du 15 juin 2004, non rapatrié, qui pourrait avoir actualisé le barème.
- Le régime du séjour : visas, titres de séjour, durées. C'est un autre corpus.
- Le traitement fiscal et social de l'expatrié : assiette, conventions de non double imposition, détachement contre expatriation.
- Les accords CEDEAO sur la libre circulation et le droit d'établissement, qui pourraient alléger certaines de ces formalités et que nous n'avons pas lus.
