# TOOLS.md — ce qui est branché sur cette machine

Chaque intégration a sa fiche dans `integrations/<nom>/README.md`, et son test
de santé `check.py`. Ce fichier ne les remplace pas : il dit ce qu'il faut
savoir **avant** d'ouvrir la fiche.

⛔ **Règle qui vaut pour toutes.** Un appel à un service extérieur passe
toujours par un script de son dossier `integrations/`. Jamais de `curl`
improvisé, jamais de bout de code écrit à la volée ailleurs, jamais une
requête recopiée dans un skill. Le jour où un service casse ou change de clé,
tout se répare à un seul endroit — un appel écrit ailleurs est invisible, et
il survivra à la réparation.

## Google — Drive, Slides, Docs, Sheets, Agenda, Gmail

**Ouvert le 14/08/2026.** Lecture **et écriture**.

```bash
integrations/google-gogcli/gog.sh drive ls --max 20
integrations/google-gogcli/deposer.sh deck.pptx <ID_DOSSIER> --slides
integrations/google-gogcli/deposer.sh deck.pptx <ID_DOSSIER> --verifier   # n'écrit rien
```

⚠️ **Ne cherche pas « la clé Google » dans `~/.config/agents/secrets/` — elle
n'y est pas, et son absence ne prouve rien.** L'autorisation tient dans des
jetons OAuth rangés dans un trousseau à part, `~/.config/gogcli/keyring/`,
chiffré avec un mot de passe **vide**. C'est exactement la méprise qui a fait
répondre, le matin du 14/08, « aucun accès Google sur cette machine » alors que
quatre comptes étaient connectés depuis le 20 juillet. Si un doute revient :
`python3 integrations/google-gogcli/check.py` tranche en 10 secondes.

⚠️ **N'appelle jamais `gog` directement** : il n'est pas sur le `PATH` des
shells non interactifs et répond `command not found`, ce qui ressemble à une
panne Google alors que rien n'est cassé. `gog.sh` règle le `PATH`, le mot de
passe du trousseau et le compte.

⛔ **`--dry-run` ment sur `drive upload`** : il annonce une simulation et crée
réellement le fichier (vérifié le 14/08, le test à blanc a dû être annulé à la
main). Pour contrôler sans écrire : `deposer.sh … --verifier`.

**Comptes.** Par défaut `[adresse interne]` — le compte de l'agence, c'est là
que vivent les dossiers de travail. `[adresse retirée]` est disponible au
même périmètre (Aicha Koné l'a autorisé le 10/08). Pour changer :
`--compte <adresse>`, ou la variable `KOFFI_COMPTE_GOOGLE`.

**Déposer est une diffusion**, et l'accès technique ne lève pas cette règle :
un dépôt se fait sur demande explicite d'une personne identifiée, jamais de ma
propre initiative.

## Stitch — maquettes d'interface

**Ouvert le 01/09/2026.** Lecture, et écriture sous accord.

```bash
integrations/stitch/stitch.sh doctor
integrations/stitch/stitch.sh tool list_projects -o json
integrations/stitch/stitch.sh tool get_screen_code -d '{"projectId":"…","screenId":"…"}'
```

⛔ **`stitch.sh` refuse sans `--accord`** les dix verbes qui consomment le quota du
compte ou modifient un projet — génération d'écran, variantes, création et
suppression de projet, systèmes de design. Une lecture passe sans rien demander.

⚠️ Le client en ligne de commande est un **paquet tiers** (`@_davideast/stitch-mcp`) :
aucun client officiel Google n'existe sur npm. Il reçoit la clé.

⚠️ **Aucun plafond ni tarif documenté** par Google. Un épuisement de quota se
découvrira à l'usage.

## Apify — atteindre une page publique bloquée aux robots

**Ouvert le 01/09/2026.** Compte `[compte interne]`, formule payante.

```bash
integrations/apify/check.py                                  # gratuit
integrations/apify/extraire.py <url> <sortie.html> --accord "…"
```

⛔ **Chaque page chargée consomme le compte de l'agence** : `extraire.py` refuse
sans `--accord`. Deux réseaux, `RESIDENTIAL` par défaut et `UNBLOCKER` pour les
protections que le premier ne passe pas.

⛔ **La limite est contractuelle, pas technique.** Ce réseau sert à atteindre
des pages **publiques** qu'une protection anti-robot bloque. Jamais à franchir
un mur de connexion, à moissonner en volume, ni à prendre des données
personnelles.

## Les autres

- **Canva** — lecture et écriture, compte `[adresse interne]`. Ne sait importer
  qu'un fichier déjà **public sur internet** : l'import d'un travail non publié
  se fait par glisser-déposer chez l'interlocuteur.
- **Figma** — lecture seule.
- **Magnific (Pikaso)** — génération d'images, **consomme des crédits** :
  aucune dépense sans accord.
- **Transcription vocale** — facturée à la minute.

Voir `integrations/<nom>/README.md` pour le détail et l'état vérifié de chacune.

## Quel outil pour quoi — doctrine d'Aicha Koné, 17/08/2026

Reçue par écrit. Elle prime sur mes habitudes : **on choisit l'outil selon le besoin
réel du livrable, pas par habitude.**

- **Figma** — outil principal pour l'UI/UX : systèmes de design, composants,
  prototypes, pages d'accueil, maquettes produit.
- **Canva** — supports de communication destinés à être repris par une équipe
  **non-designer** : réseaux sociaux, dépliants simples, affiches, présentations,
  gabarits.
- **Pexels** — **première source** pour une photographie ou une vidéo réelle. Une
  image réelle pertinente passe avant une scène générée.
- **OpenAI** — illustrations, concepts visuels, images impossibles à trouver
  correctement dans la banque, exploration de directions. **Jamais en remplacement
  automatique d'une photographie réelle.**
- **Magnific** — **finition seulement** : améliorer ou agrandir une image dont la
  définition ou la qualité ne suffit pas. Il ne rattrape ni un mauvais choix d'image,
  ni un mauvais design.

**Ordre de décision pour un visuel** : besoin d'une vraie photographie → Pexels → si
rien de satisfaisant, OpenAI → Magnific uniquement si une amélioration finale est
nécessaire.

**Règle générale** : ne pas multiplier les outils inutilement ; choisir le plus adapté
et livrer **dans le format source attendu**. Un outil ne décide jamais de la direction
artistique : le brief, le système de design et les assets existants de la marque
passent d'abord. Ne rien publier, acheter ni modifier d'un actif original sans
autorisation.

## Fabriquer un document — l'interpréteur et les bibliothèques

⚠ Le Python du système **ne porte aucune bibliothèque bureautique**. L'appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est le mauvais interpréteur.

| Ce que je fabrique | Avec quoi |
|---|---|
| Word, présentation, tableur, PDF, lecture d'un document | `~/.venv-office/bin/python` |
| — il porte | `docx` · `pptx` · `openpyxl` · `pandas` · `pypdf` · `weasyprint` · `markitdown` |
| Word ou deck côté Node (`docx-js`, `pptxgenjs`) | `NODE_PATH=~/.claude/outils-communs/node/node_modules node …` |
| Figer un document bureautique en PDF | `soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>` |

⛔ **`pandoc` n'est pas installé sur cette machine.** Toute recette qui en dépend est à écarter.
Lire un `.docx` : `markitdown` ou `python-docx`. Convertir en PDF : `soffice`, ci-dessus.

⛔ **LibreOffice n'a PAS Writer** (vérifié le 22/09/2026 : seuls `libreoffice-calc`, `-draw`,
`-impress`, `-base-core` sont installés). `soffice --convert-to pdf` sur un `.docx` répond
« source file could not be loaded », y compris sur un document vide : ce n'est jamais le fichier.
Pour contrôler un document texte, le déposer en Google Doc et exporter
`https://docs.google.com/document/d/<id>/export?format=pdf`.

ℹ LibreOffice porte Calc, Draw et Impress depuis le 08/09/2026. Si `soffice`
répond « source file could not be loaded » sur un classeur, c'est le paquet `libreoffice-calc`
qui manque — pas le fichier qui est cassé.

