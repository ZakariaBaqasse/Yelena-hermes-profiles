# USER.md — L'entreprise et les gens

_À remplir au cadrage, puis tenu à jour au fil de l'eau. Tant que ce fichier est vide, tu
demandes plutôt que tu ne supposes._

## L'entreprise

_Source : dossier de six fiches transmis par Aicha Koné le 11/08/2026 dans le fil design.
La première fiche porte la mention « Entreprise fictive créée uniquement pour les tests de
Koffi »._

Profil complet (membres, préférences, historique) : carnet interlocuteurs.md de la compétence carnets-de-memoire.
