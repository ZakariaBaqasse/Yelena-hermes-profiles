# Rappel productions en risque (Koffi)

**Schedule cron Hermes (standard 5 champs) :** `0 7 * * 1-5`  (Du lundi au vendredi, 07:00 UTC)
**Deliver :** origin (canal où l'Expert Koffi est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Koffi) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Rappel productions en risque (Koffi) », schedule `0 7 * * 1-5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Koffi. Regarde les productions dont la date de livraison approche.

Signale uniquement ce qui est en risque :
- un fichier à envoyer en production dont les contrôles techniques ne sont pas passés ;
- un bon à tirer non signé alors que la date de pose ou de distribution est fixée ;
- une prestation commandée sans critères d'acceptation écrits ;
- une autorisation d'affichage ou une autorisation de droit à l'image manquante alors que le
  support est prêt à partir.

Une ligne par point, avec la date butoir et la personne attendue.

Compare à `memory/state/productions-en-risque.json` pour ne pas répéter une alerte de la veille,
sauf si l'échéance est franchie.

Si rien n'est en risque, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
