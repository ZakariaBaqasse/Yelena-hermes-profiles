# 260922_Droit a l image en Cote d Ivoire

===== onglet t.0 · Tab 1 · 32 lignes non vides =====

# Le droit à l'image en Côte d'Ivoire
Établi le 22/09/2026 pour FATIMA (publication) et KOFFI (visuels). Articles vérifiés à l'œil sur la page du Journal officiel du 8 août 2013, page 478, pas seulement sur la reconnaissance de caractères.
## ⛔ Il n'y a pas de loi ivoirienne du droit à l'image
Chercher « loi sur le droit à l'image » ne donne rien, et ce n'est pas un manque de notre part : le régime se compose de deux étages.

- La loi n° 2013-450 du 19 juin 2013 sur les données à caractère personnel. Son article premier range « le son et l'image relative à une personne physique identifiable » dans les données à caractère personnel. Photographier une personne identifiable, c'est donc traiter une donnée personnelle, avec tout ce que la loi impose.
- Le code pénal et le droit de la presse, pour l'atteinte à la vie privée et à la réputation. L'article 24 de la loi de 2013 le dit expressément : elle ne fait pas obstacle aux textes sur la presse écrite, l'audiovisuel et au code pénal qui préviennent, limitent, réparent et répriment les atteintes à la vie privée et à la réputation des personnes physiques.
## Ce que ça impose avant de publier une photo
Le consentement, et il est défini. Article premier : « toute manifestation de volonté expresse, non équivoque, libre, spécifique et informée ». Quatre conséquences pratiques : un accord tacite ne vaut rien · un accord général « pour la communication » n'est pas spécifique · un accord obtenu sans dire à quoi servira l'image n'est pas informé · un accord d'un salarié envers son employeur mérite un examen sur le « libre ».

Les principes de traitement, articles 15 à 20 : collecte licite et loyale (15) · finalités déterminées, explicites et légitimes, données non excessives, durée de conservation limitée (16) · exactitude (17) · information obligatoire et claire de la personne (18) · confidentialité (19) · le sous-traitant doit offrir des garanties suffisantes et le responsable reste tenu (20).

⚠ L'article 16 est celui qu'on oublie : une image prise pour un reportage interne ne se réemploie pas dans une campagne publicitaire. C'est un changement de finalité, donc un nouveau consentement.
## ⛔ Les deux peines à connaître par cœur
| Article | Ce qui est puni | Peine |
| 21 | Collecte et traitement de données révélant l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses ou philosophiques, l'appartenance syndicale, la vie sexuelle, les données génétiques ou l'état de santé | 10 à 20 ans d'emprisonnement et 20 à 40 millions FCFA |
| 22 | Prospection directe par tout moyen de communication utilisant les données d'une personne qui n'a pas exprimé son consentement préalable | 1 à 5 ans d'emprisonnement et 1 à 10 millions FCFA |

⛔ L'article 21 concerne directement le travail d'image. Une photo qui identifie une appartenance ethnique ou religieuse, un reportage dans un lieu de culte, un visuel qui illustre une communauté : on est dans les données sensibles, avec la peine la plus lourde de la loi. Les exceptions de l'article 21 existent (données manifestement rendues publiques par la personne, sauvegarde d'intérêts vitaux, activités d'un organisme à but non lucratif envers ses seuls membres), elles sont étroites et se vérifient une par une.

⚠ Correction d'une erreur de la maison : une réponse antérieure annonçait « 1 an de prison » pour l'article 22. Le texte dit un à cinq ans. Vérifié sur la page du JO.
## L'exception qui ne couvre pas la publicité, article 23
Le traitement « réalisé aux fins de journalisme, de recherche, d'expression artistique ou littéraire » est admis lorsqu'il est mis en œuvre aux seules fins d'expression littéraire et artistique, ou de l'exercice à titre professionnel de l'activité de journaliste ou de chercheur, dans le respect des règles déontologiques de ces professions.

⛔ Une campagne de marque n'est ni du journalisme ni de l'art. Invoquer l'article 23 pour publier la photo d'un passant dans une publicité ne tient pas. L'exception protège le reportage et l'œuvre, pas la promotion.
## Le geste, avant toute publication d'une photo de personne
- La personne est-elle identifiable ? Si oui, c'est une donnée personnelle, point.
- Ai-je un consentement écrit, spécifique à cet usage-là, et la personne savait-elle à quoi servirait l'image ?
- L'image révèle-t-elle une donnée sensible de l'article 21 ? Si le doute existe, on ne publie pas sans avis.
- La finalité d'aujourd'hui est-elle celle du consentement d'hier ? Sinon, nouveau consentement.
- Pour un mineur : le consentement est celui du représentant légal, et il s'écrit.
## Ce que cette note ne couvre pas
- Le code pénal ivoirien n'est pas sur disque : les peines pour atteinte à la vie privée et à la réputation, que l'article 24 réserve, ne sont donc pas chiffrées ici.
- La loi sur la presse et le régime de l'audiovisuel ne sont pas rapatriés.
- Les formalités déclaratives auprès de l'Autorité de protection des données n'ont pas été relevées article par article.
- Aucune décision de justice ivoirienne n'a été consultée : ce qui est écrit est le texte, pas son application par les tribunaux.
## Sources
- ../donnees-personnelles-ci/loi-2013-450-donnees-personnelles.pdf, Journal officiel du 8 août 2013. Le .txt à côté est une reconnaissance de caractères : elle entrelace les deux colonnes de la page et se trompe sur les mots courts. Elle sert à chercher, pas à citer. Toute valeur citée se vérifie sur le PDF.
