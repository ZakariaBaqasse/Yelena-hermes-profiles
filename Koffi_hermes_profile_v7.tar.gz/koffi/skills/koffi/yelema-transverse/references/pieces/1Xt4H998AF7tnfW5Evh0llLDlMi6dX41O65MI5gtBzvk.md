# 260922_Symboles de la Republique de Cote d'Ivoire - lecture pour un graphiste

===== onglet t.0 · Tab 1 · 36 lignes non vides =====

# Les symboles de la République, et pourquoi ils ne sont pas neutres pour un graphiste
Écrite le 22/09/2026 sur les deux brochures officielles du ministère de la Fonction publique, présentes ici : 5_Symboles_Republique_CI2018.pdf (Secrétariat d'État chargé du Service civique, 2018) et Symboles_Republique_CI.pdf, toutes deux avec leur texte extrait.

⛔ Le point qu'aucune charte européenne ne dira : ces signes sont aussi politiques, et le document officiel l'écrit lui-même. Un éléphant, deux palmiers ou un tricolore orange-blanc-vert ne sont pas des choix graphiques neutres en Côte d'Ivoire.
## Le drapeau
Constitution du 8 novembre 2016, article 48 alinéa 1 : l'emblème national est le drapeau tricolore Orange, Blanc, Vert, en bandes verticales et d'égales dimensions. Créé par la loi 59-240 du 3 décembre 1959.

Le sens donné à la présentation à l'Assemblée législative : l'orange rappelle la terre riche et généreuse, le sens de la lutte ; le blanc, la paix, « mais la paix du droit » ; le vert, l'espérance et la certitude d'un devenir meilleur.

⚠ L'ordre compte, et l'erreur est classique : les bandes se lisent Orange, Blanc, Vert. Inversées, on obtient le drapeau irlandais. ⛔ En revanche, la brochure officielle ne dit rien d'un sens qui vaudrait signal de détresse ou marque d'irrespect : cette affirmation circule chez nous depuis le 17/09 et elle n'est pas dans le texte officiel. Ne pas la servir à un client comme une règle. ⟦à vérifier ailleurs si le sujet revient⟧
## Les armoiries, décret 64-237 du 26 juin 1964 modifiant le décret 60-78 du 8 février 1960
Blasonnement officiel, article 2 :

« Blason de Sinople à tête d'éléphant, l'écu surmonté d'un soleil hissant éclipsé d'or rayonnant de neuf (09) pièces or. A dextre et à senestre deux arbres or et l'inscription argent "République de Côte d'Ivoire", sur listel or ».

Six éléments et leurs couleurs institutionnelles, ce qui donne une palette officielle :

| Élément | Couleur |
| L'éléphant | argenté |
| Le soleil levant | doré |
| Les deux palmiers | dorés |
| Le blason ou écusson | vert ⚠ il était bleu à la création en 1960 |
| Le cordon ou listel | doré |
| L'inscription « République de Côte d'Ivoire » | argentée |

Le soleil rayonne de neuf pièces. Ce n'est pas un détail décoratif : c'est dans le décret.
## ⛔ Ce que la brochure officielle dit de la politique, et qu'il faut avoir lu
Texte officiel, mot pour mot :

« La tête de l'éléphant représente l'emblème du Parti Démocratique de Côte d'Ivoire. Les deux palmiers représentent quant à eux, l'emblème du parti progressiste. A l'indépendance, ces deux partis antagonistes ont accepté de se mettre ensemble. Cette union est matérialisée par le listel qui relie les deux emblèmes. »

Conséquences directes pour un travail graphique :

- Une tête d'éléphant n'est pas un animal, c'est un emblème de parti. Un logo qui en emploie une sera lu politiquement, quelle que soit l'intention.
- Deux palmiers non plus.
- Un contentieux a opposé le PDCI au RHDP sur l'emploi de ces signes, avec audience en janvier 2020, et un futur emblème RHDP a été annoncé en blanc, vert et orange. ⚠ Ces deux éléments viennent de la presse et ne sont pas confirmés sur source primaire ici.
- Le lien avec la publicité est direct : la propagande politique est interdite en publicité hors période électorale, et l'image et la voix des personnalités politiques sont interdites. Voir publicite-ci/.
- ⚠ Un symbole de l'État ne s'emploie pas dans un message publicitaire sans autorisation écrite des organismes compétents (projet de loi sur la communication publicitaire, art. 27, cité comme projet).
## La devise et l'hymne
Devise, article 48 alinéa 3 de la Constitution : UNION, DISCIPLINE, TRAVAIL. Les trois mots, dans cet ordre. L'union traduit la solidarité et la force du peuple, la discipline le respect des règles prescrites.

Hymne : l'Abidjanaise, adoptée par la loi 60-207 du 27 juillet 1960, dix jours avant l'indépendance, reprise à l'article 48 alinéa 2 de la Constitution de 2016. Texte de l'abbé Pierre Marie Coty, musique de l'abbé Pierre Michel Pango.
## Ce que cette fiche ne couvre pas
- Les codes couleur en valeurs numériques. Le décret donne des couleurs héraldiques, or et argent, pas des hexadécimaux. ⛔ Ne pas inventer un #FF7F00 officiel : il n'existe pas dans ces textes. ⟦à chercher : un éventuel manuel d'identité de l'État⟧
- Les règles de pavoisement : tailles, ordre des drapeaux, mise en berne.
- Les symboles non étatiques, couleurs et signes à charge culturelle ou religieuse, qui relèvent d'un autre relevé. ⟦à faire⟧

À recontrôler le 22/03/2027.
