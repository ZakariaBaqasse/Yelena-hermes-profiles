# 260922_Publicite en Cote d'Ivoire - le circuit avant le contenu

===== onglet t.0 · Tab 1 · 45 lignes non vides =====

# La publicité en Côte d'Ivoire : le circuit avant le contenu
Constituée le 22/09/2026. ⛔ Le point qui surprend tout le monde : ici, un message publicitaire est validé AVANT diffusion, quel que soit le support, et les métiers de la publicité s'exercent sous agrément. Ce n'est pas d'abord une question de bon goût ou de mentions légales, c'est un circuit administratif obligatoire. Une campagne pensée comme en Europe se heurte à cette étape, pas à ses arguments.
## Trois régulateurs, à ne pas confondre
| Organe | Périmètre |
| CSP, Conseil supérieur de la publicité | la publicité, toutes professions et tous supports. Guichet : csp.communication.gouv.ci (plateforme SIGCP) |
| HACA, Haute autorité de la communication audiovisuelle | l'audiovisuel, radios et télévisions |
| ANP, Autorité nationale de la presse | la presse écrite et en ligne |

Contact du CSP relevé sur son guichet : info.csp@communication.gouv.ci, +225 07 97 97 29 29 · +225 05 05 96 05 04 · +225 01 41 67 67 04.

⚠ Le CSP annonce sur son propre site un lien vers une « Autorité de la communication publicitaire » (acp-csp.com) : ce domaine ne résout plus. Vérifié le 22/09/2026. C'est l'indice d'une réforme engagée et non aboutie, voir plus bas.
## Ce qui est certain, parce que ça se voit sur le guichet
- Quatre professions sous agrément : agence-conseil en communication, régie publicitaire, courtier en publicité, société d'édition publicitaire.
- Six catégories d'agence-conseil : publicité, média, événementiel et relations publiques, marketing direct et promotion des ventes, interactive, intégrée. Une agence est agréée dans une catégorie, pas « en communication » en général.
- Le guichet gère trois objets distincts : le message, le support et l'agrément (premier agrément et renouvellement), plus la pige publicitaire.
- Acteurs institutionnels associés : ministère de la Communication, ministère chargé de l'entretien routier, ministère de l'Intérieur via les collectivités, HACA et ANP.
## ⛔ L'état du droit, et il faut le dire avant de citer quoi que ce soit
Le texte le plus complet accessible est projet-loi-communication-publicitaire.pdf, hébergé par l'Assemblée nationale (assnat.ci/IMG/pdf/loi_communication_publicitaire.pdf), 121 articles en neuf chapitres. C'est un projet de loi : son article premier dit « au sens du présent projet de loi », et ses articles pénaux renvoient au « présent projet de loi ».

Ce qu'on en sait : présenté par le ministre de la Communication à la commission des affaires économiques et financières de l'Assemblée nationale, adopté en commission le 9 décembre 2019. Il crée une Autorité de la communication publicitaire (ACP) en remplacement du CSP.

⛔ Sa promulgation n'a pas pu être établie le 22/09/2026, et le domaine de l'ACP ne répond pas. Conséquence pratique, à tenir : ce texte ne se cite jamais comme le droit en vigueur. Il sert à comprendre la logique du secteur et le vocabulaire officiel, il ne fonde aucune affirmation opposable à un client. ⟦à trancher : retrouver au Journal officiel si une loi portant régime juridique de la communication publicitaire a été promulguée, et sous quel numéro⟧
## Ce que le projet prévoit, utile comme carte du terrain
Cité ici en tant que projet, jamais comme règle en vigueur.

Le circuit : agrément obligatoire pour exercer (art. 13), validation des moyens de diffusion par l'organe de régulation (art. 15), enregistrement et identification de tout support (art. 16), signature de l'agence créatrice sur tout message (art. 21).

Les interdits de contenu : publicité mensongère ou trompeuse (art. 22) · induire en erreur par exagération, omission, moyen subliminal ou ambiguïté (art. 24) · exploiter l'inexpérience du consommateur, inciter à un comportement dangereux (art. 25) · discriminer en raison de la race, l'ethnie, le clan, la tribu, la couleur de peau, le sexe, la région, l'origine sociale, la religion, l'opinion, la fortune, la culture, la langue, la situation sociale, l'état physique ou mental (art. 26) · porter atteinte à l'unité nationale ou au crédit de l'État, et employer un symbole de l'État sans autorisation écrite (art. 27) · représenter une personne ou s'y référer sans son autorisation préalable (art. 28) · utiliser l'image ou la voix des journalistes et présentateurs des médias publics (art. 29) · produits contrefaits ou de contrebande (art. 30).

Les secteurs interdits ou encadrés : tabac et substituts, cigarette électronique et narghilé compris, y compris le rappel graphique du tabac et le parrainage (art. 34 à 37) · alcool, autorisé à des conditions fixées par décret (art. 38) · médicaments, pharmacopée traditionnelle, cosmétiques et hygiène corporelle, par décret (art. 39) · établissements sanitaires, morgues et effets mortuaires, interdits (art. 40) · armes à feu et explosifs, interdits (art. 41) · incitation à la consommation abusive d'énergie, sauf renouvelables (art. 42) · toute activité soumise à autorisation d'un ministère technique doit produire cette autorisation avant sa publicité (art. 43) · professions à ordre (art. 44) · image et voix des personnalités politiques, interdites (art. 45) · activités des partis et groupements politiques, interdites hors période électorale (art. 46).

L'affichage (art. 49) : interdit sur les monuments et sites classés ou en voie de classement, les bâtiments administratifs, les établissements d'enseignement, à moins de 100 m en rase campagne et 75 m en agglomération d'un monument ou site classé, sur les ponts, feux tricolores, poteaux électriques et de télécommunication, séparateurs et glissières, les clôtures et murs d'habitation non aveugles, les jardins et équipements publics de circulation, les parcs, réserves et arbres, les centres de loisirs pour enfants, les lieux de culte et les bâtiments d'associations politiques. L'affichage sauvage par affichette, banderole ou panonceau est interdit (art. 50).

Parrainage et publireportage : journaux et émissions d'information et à caractère politique exclus du parrainage, sport excepté (art. 51) · le mécénat n'autorise que la citation du nom et des signes distinctifs habituels (art. 52) · le téléachat s'annonce comme tel et est interdit au mineur (art. 53 et 54).

Les peines prévues, pour donner l'ordre de grandeur : exercer sans agrément, 2 mois à 1 an et 1 à 10 millions de francs (art. 105) · contrevenir aux art. 34 à 49, 2 mois à 1 an et 2 à 10 millions (art. 106) · atteinte à la sûreté ou à l'unité nationale, 6 mois à 2 ans et 2 à 50 millions (art. 107) · publicité mensongère, 2 à 15 mois et 2 à 15 millions (art. 110). ⚠ L'annonceur est responsable de l'infraction commise dans la publicité diffusée pour son compte, et le délit de publicité mensongère est constitué dès lors que la publicité est faite, reçue ou perçue en Côte d'Ivoire (art. 111).
## Ce qui circule dans la presse, et qui n'est pas vérifié
À traiter comme des pistes, jamais comme des règles. Chacune se confirme au guichet du CSP avant d'être servie à un client.

- Une validation des messages annoncée en 24 à 72 heures.
- Un seuil de 25 000 abonnés au-delà duquel un influenceur relèverait des règles de la communication audiovisuelle.
- Une réorganisation de l'affichage en 2026 : 157 axes routiers, plus de 2 000 emplacements, démantèlement des panneaux irréguliers.
- Un décret du 9 août 1996 portant création, organisation et fonctionnement du CSP, et un CSP créé le 28 mai 1979.
- Un décret 2007-676 du 28/12/2007 sur l'affichage publicitaire, dont l'article 28 fixerait les distances d'implantation à 100 m des intersections et sorties de courbe en agglomération et 150 m hors agglomération. ⟦à récupérer : ce décret n'a pas été trouvé en texte⟧
- Une transformation du CSP en Service de la communication publicitaire.
## Ce que cette base ne contient pas
- Le texte en vigueur, tant que la question de la promulgation n'est pas tranchée.
- Le décret 2007-676 et les décrets d'application sur l'alcool et les médicaments.
- Les tarifs et les délais réels du guichet : les pages « didacticiel » et « manquements aux obligations » du site sont des coquilles vides, vérifié le 22/09.
- La liste des agences agréées : la page existe mais ne sert que la nomenclature des six catégories, pas de liste nominative accessible sans compte.
## Ce que ça change pour un livrable
- On demande l'agrément avant de promettre une diffusion. Une agence non agréée dans la bonne catégorie ne peut pas porter la campagne, et l'annonceur reste responsable.
- On prévoit l'étape de validation dans le calendrier, en amont de l'achat d'espace.
- Un visuel qui emploie un symbole national, un personnage réel ou une personnalité politique se traite comme un risque, pas comme une idée créative. Voir droit-image-ci/ pour le consentement des personnes.
- L'affichage ne se dessine pas sans son emplacement : le format et le lieu sont contraints avant le graphisme.

À recontrôler le 22/03/2027, ou dès qu'un texte sur la communication publicitaire est publié.
