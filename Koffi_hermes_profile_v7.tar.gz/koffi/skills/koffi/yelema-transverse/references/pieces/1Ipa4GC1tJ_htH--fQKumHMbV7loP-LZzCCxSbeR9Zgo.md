# 260922_Le parc d'ecrans et d'appareils en Cote d'Ivoire

===== onglet t.0 · Tab 1 · 58 lignes non vides =====

# Le parc d'écrans et d'appareils en Côte d'Ivoire
Écrite le 22/09/2026. Elle répond à une question de conception : pour quel écran dessine-t-on ici ? Deux mesures existent, elles ne disent pas la même chose, et l'écart entre les deux est le vrai enseignement.
## ⛔ La règle, avant les chiffres
Ne jamais dimensionner une maquette sur StatCounter seul. Sa mesure ivoirienne décrit l'audience d'un parc de sites, pas le pays. La preuve tient en une ligne : StatCounter compte 49 % de pages vues depuis un ordinateur de bureau, quand l'enquête du régulateur trouve que 9,6 % des Ivoiriens ont touché un ordinateur en trois mois. Les deux chiffres sont justes, ils ne portent pas sur la même population.

Le réflexe : ARTCI pour savoir qui a quoi, StatCounter pour savoir ce qui se connecte aux sites. Une vitrine grand public se dessine sur le premier, un intranet d'entreprise ou un site de marque premium se rapproche du second.
## Mesure 1, le pays : enquête MSI 2024 de l'ARTCI
Enquête en ménages, population de 5 ans et plus estimée à 27,2 millions d'individus. Source sur disque : artci/msi-2024-resume-executif.pdf.
### Les individus
| Usage | Ensemble | Hommes | Femmes |
| Téléphone mobile | 72,4 % | 75,3 % | 69,5 % |
| Smartphone | 42,4 % | 45,8 % | 38,8 % |
| Internet | 41,4 % | 44,5 % | 38,3 % |
| Ordinateur, au cours des 3 derniers mois | 9,6 % | 12,4 % | 6,8 % |

⛔ Seuls 58,5 % des téléphones mobiles utilisés sont des smartphones. Autrement dit, plus de quatre Ivoiriens sur dix qui ont un téléphone n'ont pas d'écran capable d'afficher une page moderne. Un parcours qui suppose le smartphone exclut une part énorme du pays.

⚠ La fracture de genre est constante et se creuse sur l'ordinateur : 12,4 % contre 6,8 %, presque du simple au double. Une cible féminine se conçoit encore plus mobile.
### Les ménages, et l'évolution
| Indicateur | 2024 | 2023 | 2022 |
| Électricité | 96,2 % | 95,9 % | 95,4 % |
| Poste de radio | 99,3 % | 99,5 % | - |
| Poste de télévision | 81,1 % | 80,5 % | - |
| Accès au smartphone | 75,5 % | 74,0 % | 75,4 % |
| Accès à Internet | 75,1 % | - | - |
| Ordinateur | 15,0 % | 16,2 % | 14,4 % |
| Téléphone fixe | 3,9 % | 4,2 % | 4,1 % |

En volume 2024 : 5 644 199 ménages ont accès à un smartphone, 5 615 459 à Internet, 1 119 913 à un ordinateur, 290 893 à un téléphone fixe.

⚠ Le parc d'ordinateurs ne progresse pas : 14,4 puis 16,2 puis 15,0. Sur trois ans, c'est du bruit, pas une tendance. Rien n'autorise à parier sur une bascule vers le bureau.

⚠ Réserve sur l'électricité à 96,2 %. Le chiffre est nettement au-dessus des taux d'électrification habituellement publiés pour le pays. Il est cité tel que l'ARTCI le publie ; il signale peut-être un biais d'échantillon de l'enquête, et il ne se réemploie pas comme une donnée d'électrification. ⟦à recouper avec l'INS⟧
## Mesure 2, l'audience web : StatCounter, août 2026
Relevé du 22/09/2026, releves/statcounter-202608.json, refaisable par releves/statcounter.py. Ce sont des parts de pages vues, pas des appareils.

| Type d'appareil | Part |
| Mobile | 49,34 % |
| Ordinateur de bureau | 49,11 % |
| Tablette | 1,54 % |

Résolutions, les quatorze premières (47,26 % du trafic est en « autres », c'est-à-dire éclaté sur une longue traîne) :

| Écran | Part |  | Écran | Part |
| 1920x1080 | 10,76 % |  | 1536x864 | 3,27 % |
| 414x896 | 6,88 % |  | 393x873 | 2,81 % |
| 360x800 | 5,61 % |  | 1366x768 | 2,55 % |
| 384x832 | 4,22 % |  | 360x780 | 2,10 % |
| 1366x1366 | 4,05 % |  | 412x915 | 1,86 % |
| 390x844 | 3,42 % |  | 385x854 | 1,84 % |
|  |  |  | 1280x720 | 1,75 % |
|  |  |  | 375x812 | 1,62 % |

ℹ 1366x1366 est ce que rend le graphique. Une résolution carrée à cette part est inhabituelle, la valeur est reportée telle quelle et n'est pas expliquée.

Marques de mobiles : Apple 32,51 · Samsung 19,77 · Xiaomi 10,45 · inconnue 8,36 · Vivo 5,81 · Oppo 5,55 · Realme 4,14 · Motorola 4,10 · OnePlus 1,68 · Huawei 1,61 · autres 6,00.

⛔ Tecno, Infinix et itel, qui équipent massivement le marché d'entrée de gamme en Afrique de l'Ouest, sont ABSENTS de cette liste. C'est le signe le plus net que le panel de StatCounter n'est pas le pays : il voit la part de la population qui visite des sites équipés de son mouchard.

Systèmes : Android 38,56 · Windows 26,65 · iOS 19,11 · macOS 6,37 · OS X 4,89 · Linux 3,71 · autres 0,71. Navigateurs : Chrome 69,28 · Safari 15,92 · Edge 5,39 · Firefox 2,98 · Samsung Internet 2,02 · Opera 1,93 · UC Browser 0,62 · Brave 0,57 · Yandex 0,28 · autres 1,02.
## Ce qu'on en tire pour dessiner
- On dessine d'abord pour un écran de 360 à 414 px de large. C'est la famille la plus représentée côté mobile, et c'est cohérent avec les deux mesures.
- Le point de contrôle à 390 px du standard de rendu est le bon, et il est même généreux : 360x800 et 360x780 pèsent ensemble 7,7 % à eux seuls.
- Le poids de la page compte plus que sa beauté. 42,4 % de smartphones et un parc d'entrée de gamme absent des statistiques veut dire des appareils lents et des forfaits comptés.
- Prévoir le repli sans smartphone quand la cible est grand public : plus de quatre téléphones sur dix n'en sont pas.
- 1920x1080 reste le premier écran de bureau, mais il ne concerne qu'une audience professionnelle ou aisée. Ne pas en faire la maquette de référence.
## Ce que cette fiche ne couvre pas
- La part de marché réelle des marques en Côte d'Ivoire. Aucune source mesurée n'a été trouvée. Ne pas la déduire de StatCounter, qui ne voit pas l'entrée de gamme.
- Le débit et le coût réels de la connexion, qui décident du poids acceptable d'une page.
- Les versions d'Android en service, qui décident de ce qui s'affiche vraiment.

Relevé StatCounter d'août 2026, enquête ARTCI de 2024. À revérifier le 22/03/2027.
