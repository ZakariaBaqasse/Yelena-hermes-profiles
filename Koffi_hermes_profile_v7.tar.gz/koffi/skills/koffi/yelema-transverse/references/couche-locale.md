# Couche locale : Koffi · Design et identité visuelle

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-KOFFI-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci/
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Socle commun, identique aux seize postes. Note à fabriquer : qui décide quoi, centrée sur les régulateurs qui peuvent arrêter un visuel (CSP, HACA, Autorité de protection des données). La colonne H portait un lien de suivi des ventes [entreprise cliente], sans rapport avec cet élément : remplacé le 17/09. ✅ 17/09, balayage de la flotte : LA PIÈCE EXISTE DÉJÀ. memory/reference/gouvernement-2026.md chez LOKOLI donne la composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 » (1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués), relevée le 10/09 sur le portail officiel, avec la réserve : rouvrir la page avant de citer un ministre. À reprendre plutôt qu'à refaire. Et pour savoir quelle source fait foi quand deux divergent, watchlist-sources-ci.md chez BENKAN, YIRIWA et LOKOLI porte une hiérarchie de fiabilité (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, INS, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA). ⚠ Les trois versions diffèrent.

### CL-KOFFI-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Socle commun. Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021. Écart à ne pas lisser : ce jeu dit 31 régions et 201 communes, les sources encyclopédiques disent 197 communes, 14 districts, 111 départements, 510 sous-préfectures (loi 2014-451). MISE À JOUR DU 18/09, ET CE JEU EST ANTÉRIEUR AU CHANGEMENT : le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026 (référence établie sur le recensement mensuel d'Ivoire-Juriste, cohérence vérifiée contre son récapitulatif de janvier). La presse ne l'a relevé que le 18/03. L'écart noté plus haut sur les districts est donc tranché : UN LIVRABLE ÉCRIT DEUX DISTRICTS AUTONOMES, JAMAIS DOUZE NI QUATORZE. L'écart sur les communes, 201 contre 197, reste ouvert. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-KOFFI-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://fr.wikipedia.org/wiki/F%C3%AAtes_et_jours_f%C3%A9ri%C3%A9s_en_C%C3%B4te_d'Ivoire
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Socle commun. Base légale réelle, à substituer à Wikipédia : article 24.2 du Code du travail (loi 2015-532) et décret 96-205 du 07/03/1996 modifié par le décret 2011-371. Seuls le 1er mai et le 7 août sont chômés ET payés pour tous. Saisons : sodexam.com. Textes non ouverts, à confirmer au Journal officiel.

## Zone UEMOA

### CL-KOFFI-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Socle commun. Note à fabriquer : régional ou national. uemoa.int répond mais sa chaîne de certificat est incomplète, les scripts tombent et le navigateur passe (déjà constaté le 14/09).

### CL-KOFFI-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Socle commun. Source identifiée, aucun chiffre relevé : ni SMIG ni panier moyen. Les montants se relèvent à la passe de remplissage, sur source officielle. MISE À JOUR DU 18/09 : les chiffres de base sont désormais relevés sur bceao.int, huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. LE SMIG est fixé à 75000fcfa https://loidici.biz/2023/07/15/la-revalorisation-du-salaire-minimum-interprofessionel-garanti-en-abrege-smig-2/lois-article-par-article/codes/le-code-du-travail/44677/naty/

## Droit des affaires

### CL-KOFFI-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/actes-uniformes/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Socle commun, mais NUANCE DE MÉTIER : le droit qui concerne Koffi en premier est celui de la propriété intellectuelle, et il ne relève pas de l'OHADA mais de l'OAPI. Voir CL-KOFFI-16, qui est son vrai élément juridique. De l'OHADA il retient surtout la concurrence déloyale.

## Langue

### CL-KOFFI-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Socle commun, déjà chez lui : compétence parler-ivoirien (Y0487), 122 mots nouchis. Nuance de métier : un designer en a besoin pour savoir ce qu'une accroche en nouchi fait à une marque, pas seulement pour éviter de corriger une tournure juste.

## Canaux

### CL-KOFFI-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : 91,6 % des connexions se font par téléphone mobile. Tout visuel se juge d'abord à 390 px, ce que le standard de rendu impose déjà.

## Identité visuelle

### CL-KOFFI-11 · Logos des marques ivoiriennes et régionales de référence
- **Pourquoi** : Dessiner sans savoir à quoi ressemble le paysage local produit du hors-sol
- **Où chercher** : Corpus logos-marques-ci déjà constitué
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://brandfetch.com/
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || DÉJÀ CHEZ LUI, et c'est du regardé : memory/reference/logos-marques-ci.md, établi le 06/09/2026 sur 15 logos réels récupérés en haute définition, avec planche-contact. Orange CI, MTN CI, Moov Africa CI, Carrefour CI, Ecobank CI, Jumia CI, Djamo, Julaya, CinetPay, SODECI, SNEDAI, SOCIAM, ONECI, Société Générale CI, Abidjanshow. La note interne qui disait cet élément encore dû est périmée depuis le 06/09. ℹ 17/09 : brandfetch.com en colonne H (répond). ⚠ Réserve à porter : c'est un agrégateur tiers, pas la marque. Un logo pris là est une reproduction, pas le fichier officiel ; pour un livrable, le fichier vient de la marque ou de son site, et à défaut on le dit.

### CL-KOFFI-12 · Les codes couleur et les symboles qui portent un sens ici
- **Pourquoi** : Une couleur neutre ailleurs peut être connotée ici
- **Où chercher** : Relevés sur marques locales, iconographie publique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://fonctionpublique.gouv.ci/assets/rubriques/_documentation/5_Symboles_Republique_CI2018.pdf
- **Pièce, ici** : references/pieces/1Xt4H998AF7tnfW5Evh0llLDlMi6dX41O65MI5gtBzvk.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, sur les DEUX BROCHURES OFFICIELLES du ministère de la Fonction publique, rapatriées et extraites : bases-locales/protocole-ci/SYMBOLES-NATIONAUX.md. ⛔ LE POINT QU'AUCUNE CHARTE EUROPÉENNE NE DIRA EST CONFIRMÉ PAR LE DOCUMENT OFFICIEL LUI-MÊME, mot pour mot : « La tête de l'éléphant représente l'emblème du Parti Démocratique de Côte d'Ivoire. Les deux palmiers représentent quant à eux, l'emblème du parti progressiste. » Une tête d'éléphant n'est donc pas un animal, c'est un emblème de parti, et un logo qui en emploie une sera lu politiquement quelle que soit l'intention. LA PALETTE OFFICIELLE EXISTE, mais en couleurs héraldiques : décret 64-237 du 26/06/1964 modifiant le 60-78 du 08/02/1960, six éléments, éléphant ARGENTÉ, soleil levant DORÉ, deux palmiers DORÉS, blason VERT (il était BLEU à la création en 1960), listel DORÉ, inscription ARGENTÉE, et le soleil rayonne de NEUF PIÈCES, ce qui est dans le décret et non décoratif. DRAPEAU, article 48 alinéa 1 de la Constitution de 2016 : tricolore ORANGE, BLANC, VERT, bandes verticales d'égales dimensions, créé par la loi 59-240 du 03/12/1959. ⚠ Inversé, on obtient le drapeau irlandais. ⛔ MAIS CORRECTION D'UNE AFFIRMATION QUE NOUS PORTIONS DEPUIS LE 17/09 : la brochure officielle NE DIT RIEN d'un sens à l'envers qui vaudrait signal de détresse ou marque d'irrespect. Ce n'est pas dans le texte, donc ce n'est pas servi à un client. DEVISE, article 48 alinéa 3 : UNION, DISCIPLINE, TRAVAIL, dans cet ordre. HYMNE : l'Abidjanaise, loi 60-207 du 27/07/1960, texte de l'abbé Pierre Marie Coty, musique de l'abbé Pierre Michel Pango. ⚠ LIEN DIRECT AVEC LA PUBLICITÉ, voir bases-locales/publicite-ci : la propagande politique est interdite hors période électorale, l'image et la voix des personnalités politiques sont interdites, et un symbole de l'État ne s'emploie pas dans un message publicitaire sans autorisation ÉCRITE. ⛔ CE QUI N'EXISTE PAS ET QU'IL NE FAUT PAS INVENTER : des codes couleur en valeurs numériques. Le décret donne de l'or et de l'argent, pas des hexadécimaux. ⚠ Le contentieux PDCI contre RHDP et le futur emblème annoncé en blanc, vert et orange viennent de la presse, non confirmés sur source primaire.

### CL-KOFFI-26 · Photographier ici plutôt qu'illustrer : visages, décors et scènes d'ici
- **Pourquoi** : Une banque d'images occidentale produit des visuels que personne ne reconnaît
- **Où chercher** : À constituer : photographes et banques d'images locales
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Le corpus d'applications le montre déjà, mesuré : Djamo photographie des Ivoiriens réels en studio, et le document note que l'utilisateur se reconnaît, ce qu'aucune illustration ne produit. Il manque à Koffi de quoi le faire : où trouver des visages, des décors et des scènes d'ici, et à quel coût.

## Interfaces

### CL-KOFFI-13 · Écrans d'applications réellement utilisées en Côte d'Ivoire
- **Pourquoi** : Concevoir pour un mobile bas débit n'a rien à voir avec une maquette de studio
- **Où chercher** : Corpus ecrans-applis-ci déjà constitué
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || DÉJÀ CHEZ LUI : memory/reference/ecrans-applis-ci.md, 38 captures réelles tirées des fiches Google Play de cinq applications (Orange Max it, Wave, Djamo, Julaya, PayFlex), chiffres relevés le même jour, corpus jumeau ecrans-applis-us pour contraste. Le document porte ses propres limites et c'est ce qui le rend utilisable : les 50 M+ de Wave couvrent six pays, la note de Julaya repose sur sept avis, et le corpus est volontairement centré sur la finance, donc ni commerce, ni logistique, ni services publics. Complément manquant : les résolutions réellement utilisées, voir CL-KOFFI-21.

## Impression

### CL-KOFFI-14 · Ce que les imprimeurs d'Abidjan savent faire, et à quel format
- **Pourquoi** : Un livrable impossible à imprimer ici est un livrable mort
- **Où chercher** : Devis et contraintes relevés chez des imprimeurs
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://graphicolor-ci.com/atelier-impression/
- **Mis à jour** : 18/09/2026
- **Commentaire** : Externe à la maison, et non résolu. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. Une recherche Drive sur « imprimeur » et « devis » ne ramène que mes propres documents et les transcripts du salon. AUCUN DEVIS D'IMPRIMEUR N'EXISTE. Cette ligne ne se remplit pas par une recherche : il faut demander des devis à des imprimeurs d'Abidjan, ce qui est une démarche sortante et demande un accord.

### CL-KOFFI-15 · Supports physiques courants : kakémono, bâche, chasuble, goodies
- **Pourquoi** : Les supports d'ici ne sont pas ceux d'un kit de marque européen
- **Où chercher** : Corpus catalogue-goodies déjà constitué
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET CE N'ÉTAIT PAS UNE LIGNE DE RECHERCHE MAIS UNE LIGNE DE COMPTABILITÉ. Le marquage du 20/09 avait posé le même ⛔ sur toutes les lignes de cette famille, alors que la pièce était déjà posée au poste et vérifiée à l'usage. Contrôle du 22/09 : le fichier existe, il porte du mesuré, et la colonne « Posé chez l'expert » le nomme désormais. Ce qui suit est le constat d'origine, inchangé. || DÉJÀ CHEZ LUI : memory/reference/catalogue-goodies.md, établi le 06/09/2026 pour goodie-forge et preparation-fichiers-impression, doublé de mockups-goodies.md. Sa règle fondatrice est exactement ce qu'une couche locale doit contenir : une technique de marquage ne rend pas ce qu'un écran affiche. La broderie perd le dégradé, la sérigraphie perd le trait fin, la gravure perd la couleur. On demande l'objet et le procédé avant de dessiner, et à défaut on prépare la version la plus contrainte des deux.

### CL-KOFFI-22 · Le coût réel de fabrication locale : kakémono, bâche au m², brochure, jeu de cartes
- **Pourquoi** : Proposer un support sans savoir ce qu'il coûte, c'est engager le client à l'aveugle
- **Où chercher** : Devis réels demandés aux imprimeurs d'Abidjan
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://lexxprint.com/product/kakemono-prestige/
- **Mis à jour** : 18/09/2026
- **Commentaire** : Externe à la maison, et non résolu. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. Une recherche Drive sur « imprimeur » et « devis » ne ramène que mes propres documents et les transcripts du salon. AUCUN DEVIS D'IMPRIMEUR N'EXISTE. Cette ligne ne se remplit pas par une recherche : il faut demander des devis à des imprimeurs d'Abidjan, ce qui est une démarche sortante et demande un accord.

## Droit

### CL-KOFFI-16 · Protection d'une marque et d'un dessin en zone OAPI
- **Pourquoi** : Livrer une identité sans dire comment la protéger laisse le client exposé
- **Où chercher** : OAPI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://oapi.int/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OAPI sur disque. Le point qui commande tout : en Côte d'Ivoire IL N'EXISTE PAS de droit national des marques et des brevets à côté de l'Accord de Bangui, dont l'article 5 dit que l'Accord et ses Annexes « tiennent lieu de lois relatives aux matières qu'ils visent ». Un dépôt OAPI vaut pour les DIX-SEPT États membres, il n'y a pas de dépôt ivoirien séparé : conseiller « un dépôt national puis un dépôt régional » est une erreur de fait. ⚠ Exception : l'Annexe VII, propriété littéraire et artistique, n'est qu'un cadre minimal, le droit d'auteur reste pour partie national. || SON VRAI ÉLÉMENT JURIDIQUE, plus que l'OHADA de la ligne 06. Accord de Bangui du 02/03/1977, révisé le 24/02/1999 puis le 14/12/2015, valable dans 17 États membres, 10 annexes dont l'annexe III pour les marques et l'annexe IV pour les dessins et modèles industriels. Un dépôt produit ses effets dans chaque État : un dépôt, pas dix-sept. oapi.int publie la grille des taxes, le règlement d'application, les guides du déposant. ATTENTION, DÉTAIL TECHNIQUE : la base publique de recherche d'antériorité ne répond qu'en HTTP simple sur le port 9092 (http://siege.oapi.int:9092/wopublish-search/public/trademarks), la version chiffrée échoue. On y cherche, on n'y envoie rien de sensible. Chiffre déjà mesuré chez nous : 360 000 FCFA le dépôt hors honoraires. AJOUT DU 18/09 : LE TEXTE EST MAINTENANT SUR LA MACHINE, ~/.claude/outils-communs/oapi/, Accord de Bangui révisé le 14/12/2015 à Bamako avec ses dix annexes, et règlement d'application du 08/12/2020 pris sur oapi.int. Ce qui était dit de seconde main se cite désormais par article. Trois points à reprendre de la fiche : l'article 5 dit que l'Accord et ses annexes TIENNENT LIEU DE LOIS dans les États membres, donc pas de dépôt ivoirien séparé ; la marque se conserve sans limitation de durée par renouvellements TOUS LES DIX ANS, demandés au cours de la dernière année ; la révision de 2015 n'est en vigueur que DEPUIS LE 14 NOVEMBRE 2020, un titre antérieur relève de l'Acte de 1999. Le barème des taxes n'est pas dans le texte et se vérifie sur oapi.int avant tout chiffrage.

### CL-KOFFI-19 · Affichage urbain : où un panneau peut légalement être posé, et à quel format
- **Pourquoi** : Un visuel conçu pour un emplacement qui sera démonté est un visuel perdu
- **Où chercher** : Conseil Supérieur de la Publicité, décret 2007-676
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://csp.communication.gouv.ci/
- **Pièce, ici** : references/pieces/1ndBUjTXyl8nGUaNPq9eG1rI0mfbQrvHkhUUgpxw4DsM.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. Base neuve bases-locales/publicite-ci/, lisible par les quinze postes. ⛔ LE POINT QUI SURPREND, et il est de circuit avant d'être de contenu : en Côte d'Ivoire un message publicitaire est validé AVANT diffusion, quel que soit le support, et les quatre métiers de la publicité s'exercent sous agrément (agence-conseil dans SIX catégories distinctes, régie, courtier, éditeur). Une agence agréée « en communication » n'existe pas, elle est agréée dans une catégorie. Trois régulateurs à ne pas confondre : le CSP pour la publicité, la HACA pour l'audiovisuel, l'ANP pour la presse. ⛔ ET L'ÉTAT DU DROIT EST INCERTAIN, C'EST ÉCRIT EN TÊTE DE LA NOTE : le texte le plus complet accessible, 121 articles hébergés par l'Assemblée nationale, est un PROJET DE LOI (son propre article premier dit « au sens du présent projet de loi »), adopté en commission le 9 décembre 2019, qui crée une Autorité de la communication publicitaire en remplacement du CSP. Sa promulgation n'a pas pu être établie, et le domaine acp-csp.com lié depuis le site du CSP NE RÉSOUT PLUS (vérifié le 22/09). Il se cite donc comme carte du terrain, jamais comme règle opposable à un client. Les pages « didacticiel » et « manquements aux obligations » du guichet sont des coquilles vides : ni tarif ni délai officiel n'en sort. Ce qui circule dans la presse (validation en 24 à 72 h, seuil de 25 000 abonnés pour les influenceurs, 157 axes et 2 000 emplacements réorganisés, décret 2007-676 sur l'affichage, CSP devenant Service de la communication publicitaire) est rangé dans une section « non vérifié », à confirmer au guichet avant tout usage. POUR CETTE LIGNE EN PROPRE, l'affichage : la note porte la liste complète des emplacements interdits, et elle est longue. Monuments et sites classés ou en voie de classement, bâtiments administratifs, ÉTABLISSEMENTS D'ENSEIGNEMENT, moins de 100 m en rase campagne et 75 m en agglomération d'un monument ou site classé, ponts, feux tricolores, poteaux électriques et de télécommunication, séparateurs et glissières, clôtures et murs d'habitation non aveugles, jardins et équipements publics de circulation, parcs, réserves et arbres, CENTRES DE LOISIRS POUR ENFANTS, lieux de culte et bâtiments d'associations politiques. L'affichage sauvage par affichette, banderole ou panonceau est interdit. ⛔ CE QUE ÇA CHANGE POUR KOFFI : un panneau ne se dessine pas avant son emplacement, le lieu contraint le format. ⚠ Les distances d'implantation par rapport aux intersections et aux sorties de courbe (100 m en agglomération, 150 m hors agglomération) viennent d'une source de second rang sur le décret 2007-676, qui n'a pas été retrouvé en texte.

### CL-KOFFI-20 · Le dépôt du visuel au CSP : ce que la validation préalable exige d'un fichier
- **Pourquoi** : Livrer un visuel que le client ne pourra pas faire passer ne sert à rien
- **Où chercher** : Guichet en ligne du Conseil Supérieur de la Publicité
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://csp.communication.gouv.ci/
- **Pièce, ici** : references/pieces/1ndBUjTXyl8nGUaNPq9eG1rI0mfbQrvHkhUUgpxw4DsM.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, avec la même réserve que CL-FATIMA-20. Base neuve bases-locales/publicite-ci/, lisible par les quinze postes. ⛔ LE POINT QUI SURPREND, et il est de circuit avant d'être de contenu : en Côte d'Ivoire un message publicitaire est validé AVANT diffusion, quel que soit le support, et les quatre métiers de la publicité s'exercent sous agrément (agence-conseil dans SIX catégories distinctes, régie, courtier, éditeur). Une agence agréée « en communication » n'existe pas, elle est agréée dans une catégorie. Trois régulateurs à ne pas confondre : le CSP pour la publicité, la HACA pour l'audiovisuel, l'ANP pour la presse. ⛔ ET L'ÉTAT DU DROIT EST INCERTAIN, C'EST ÉCRIT EN TÊTE DE LA NOTE : le texte le plus complet accessible, 121 articles hébergés par l'Assemblée nationale, est un PROJET DE LOI (son propre article premier dit « au sens du présent projet de loi »), adopté en commission le 9 décembre 2019, qui crée une Autorité de la communication publicitaire en remplacement du CSP. Sa promulgation n'a pas pu être établie, et le domaine acp-csp.com lié depuis le site du CSP NE RÉSOUT PLUS (vérifié le 22/09). Il se cite donc comme carte du terrain, jamais comme règle opposable à un client. Les pages « didacticiel » et « manquements aux obligations » du guichet sont des coquilles vides : ni tarif ni délai officiel n'en sort. Ce qui circule dans la presse (validation en 24 à 72 h, seuil de 25 000 abonnés pour les influenceurs, 157 axes et 2 000 emplacements réorganisés, décret 2007-676 sur l'affichage, CSP devenant Service de la communication publicitaire) est rangé dans une section « non vérifié », à confirmer au guichet avant tout usage. POUR CETTE LIGNE EN PROPRE, le dépôt du VISUEL : le guichet traite le message et le support comme deux objets distincts, ce qui veut dire deux dépôts et non un. Tout message doit porter LA SIGNATURE DE L'AGENCE CRÉATRICE, tout support doit être enregistré et identifié comme tel, et un produit soumis à norme obligatoire doit être accompagné d'un certificat de qualité ou d'une attestation de conformité pour pouvoir faire l'objet d'une publicité. ⛔ CE QUI MANQUE : le format de fichier, le poids, les gabarits acceptés et le coût ne sont publiés nulle part, les pages prévues sont vides. Ce sont des questions pour le guichet, pas pour une recherche.

### CL-KOFFI-28 · Le droit à l'image : mettre une personne dans un visuel
- **Pourquoi** : Publier un visage sans consentement conforme expose le client, donc la maison
- **Où chercher** : Loi 2013-450, Journal officiel du 8 août 2013 ; code pénal pour la vie privée
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/images/stories/pdf/lois/loi_2013_450.pdf
- **Pièce, ici** : references/pieces/180zr1uHf3xoHciq3UzSAOS-E1yWLVK6dk2N0d4ErWls.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : AJOUTÉ ET INTÉGRÉ LE 22/09, sujet qui ne figurait dans AUCUN onglet alors qu'il porte un risque juridique direct. ⛔ IL N'Y A PAS DE LOI IVOIRIENNE DU DROIT À L'IMAGE : le régime a deux étages. (1) La loi 2013-450 du 19/06/2013 range en son article premier « le son et l'image relative à une personne physique identifiable » dans les DONNÉES À CARACTÈRE PERSONNEL : photographier quelqu'un d'identifiable, c'est traiter une donnée personnelle. (2) Son article 24 réserve expressément le CODE PÉNAL et le droit de la presse pour les atteintes à la vie privée et à la réputation. LE CONSENTEMENT EST DÉFINI À L'ARTICLE PREMIER : manifestation de volonté EXPRESSE, NON ÉQUIVOQUE, LIBRE, SPÉCIFIQUE ET INFORMÉE. Donc un accord tacite ne vaut rien, un accord général « pour la communication » n'est pas spécifique, et un accord donné sans savoir à quoi servira l'image n'est pas informé. ⛔ DEUX PEINES À CONNAÎTRE : art. 21, données révélant l'origine raciale, ethnique ou régionale, la filiation, les opinions politiques, les convictions religieuses, l'appartenance syndicale, la vie sexuelle, les données génétiques ou l'état de santé = 10 À 20 ANS et 20 à 40 MILLIONS FCFA. Cela vise directement le travail d'image : un reportage dans un lieu de culte ou un visuel illustrant une communauté tombe dans les données sensibles. Art. 22, prospection directe sans consentement préalable = 1 À 5 ANS et 1 à 10 millions FCFA. ⚠ CORRECTION : une réponse antérieure de la maison annonçait « 1 an » pour l'article 22 ; le texte dit UN À CINQ ANS, vérifié à l'œil sur la page du Journal officiel du 8 août 2013 p. 478. ⚠ L'ARTICLE 16 EST CELUI QU'ON OUBLIE : finalités déterminées. Une image prise pour un reportage interne NE SE RÉEMPLOIE PAS dans une campagne : changement de finalité, donc nouveau consentement. ⛔ L'EXCEPTION DE L'ARTICLE 23 NE COUVRE PAS LA PUBLICITÉ : elle vise le journalisme, la recherche et l'expression artistique ou littéraire, AUX SEULES FINS de celles-ci. Une campagne de marque n'est ni du journalisme ni de l'art. ⛔ CE QUE LA PIÈCE NE COUVRE PAS : le code pénal ivoirien n'est pas sur disque, donc les peines d'atteinte à la vie privée que l'art. 24 réserve ne sont pas chiffrées ; la loi sur la presse n'est pas rapatriée ; les formalités déclaratives à l'Autorité de protection des données ne sont pas relevées article par article ; aucune décision de justice ivoirienne n'a été consultée, c'est le texte et non son application.

## Références

### CL-KOFFI-17 · Chartes et systèmes de design d'institutions locales
- **Pourquoi** : Travailler pour une administration sans connaître ses codes
- **Où chercher** : Ministère de la Communication (charte unique de l'État), Trésor Public, MCA-CI, ANSUT
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : ÉLÉMENT À ZÉRO, et l'ancienne colonne « où chercher » le masquait : elle renvoyait au corpus chartes-modeles, qui contient Asana, Twitch et [entreprise cliente], trois maisons étrangères, et dont le README interdit d'en tirer autre chose qu'une façon de composer une page. Corrigée le 17/09. LA VRAIE MATIÈRE : le Conseil des ministres a validé en avril 2023 la charte graphique unique de la République ; toutes les interactions de l'administration avec des tiers doivent la porter, et un document public qui ne la porte pas n'est pas considéré comme officiel. ELLE N'EST PAS PUBLIÉE EN LIGNE, elle se demande au ministère de la Communication. Trois chartes ivoiriennes repérées : MCA-CI (PDF indexé, serveur en refus de connexion le 17/09), Trésor Public (connue par la presse), ANSUT (Koffi a déjà travaillé pour eux, references/ansut).

### CL-KOFFI-25 · Un répertoire des chartes d'institutions ivoiriennes, à constituer
- **Pourquoi** : Travailler pour une administration sans connaître ses codes
- **Où chercher** : Ministère de la Communication, Trésor Public, MCA-CI, ANSUT
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 17/09/2026
- **Commentaire** : Ajout du 17/09. Remplace l'usage détourné du corpus chartes-modeles, qui est étranger. À rassembler : la charte unique de l'État quand elle sera obtenue, celles du Trésor Public, du MCA-CI, de l'ANSUT, et deux ou trois établissements publics de plus. C'est le corpus qui manque le plus à un designer travaillant pour le secteur public ivoirien.

## Contraintes

### CL-KOFFI-18 · Polices et caractères : ce qui s'affiche vraiment sur les parcs locaux
- **Pourquoi** : Une police non embarquée casse le rendu chez le client
- **Où chercher** : Relevés sur les appareils et navigateurs courants
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://fonts.google.com/noto
- **Mis à jour** : 17/09/2026
- **Commentaire** : Matière partielle, et la conclusion est une règle plutôt qu'une donnée. Il a cinq familles en local avec provenance tracée (Merriweather, Fira Sans, Manrope, Montserrat, Noto Sans), toutes Google Fonts. La source mesurée pour les parcs est StatCounter Côte d'Ivoire, qui filtre les scripts en 403 et s'ouvre au navigateur. SUR LES POLICES RÉELLEMENT INSTALLÉES SUR LES APPAREILS IVOIRIENS IL N'EXISTE RIEN, et il n'existera rien : ce n'est pas mesurable à distance. Donc on embarque la police, on ne parie jamais dessus, et pour la couverture de caractères on s'appuie sur Noto, conçu pour ça.

### CL-KOFFI-21 · Le parc d'écrans et d'appareils réellement utilisés en Côte d'Ivoire
- **Pourquoi** : La taille de corps minimale et la zone sûre d'un visuel se déduisent des écrans réels
- **Où chercher** : StatCounter Côte d'Ivoire, relevés au navigateur
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://gs.statcounter.com/screen-resolution-stats/all/cote-d-ivoire
- **Pièce, ici** : references/pieces/1Ipa4GC1tJ_htH--fQKumHMbV7loP-LZzCCxSbeR9Zgo.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : FAIT le 22/09/2026, et ma conclusion du 20/09 était fausse. J'avais écrit que l'export de StatCounter était verrouillé derrière une session : le script ne rendait rien, la page au navigateur n'avait pas de tableau, et le point d'entrée CSV ne sortait que l'en-tête. C'était vrai de ces trois chemins et faux comme conclusion. Le graphique est un SVG rendu dans la page : en vue « barres » sur un seul mois, les pourcentages sont écrits en toutes lettres dans les balises <text>. Relevé fait, script rejouable dans numerique-ci/releves/statcounter.py, contrôle : chaque série somme à 100 %, et la légende du graphique confirme le pays et le mois.

CE QUE LA FICHE ÉTABLIT, et l'écart entre les deux mesures est le vrai enseignement. ARTCI, enquête MSI 2024, en ménages, 27,2 millions d'individus de 5 ans et plus : 72,4 % utilisent un téléphone mobile, 42,4 % un smartphone, 41,4 % Internet, et 9,6 % seulement ont touché un ordinateur en trois mois. Seuls 58,5 % des mobiles en service sont des smartphones. Côté ménages : 75,5 % ont accès à un smartphone, 15,0 % à un ordinateur, et ce dernier chiffre ne progresse pas depuis 2022. StatCounter, août 2026 : 49,34 % mobile, 49,11 % bureau, 1,54 % tablette ; premier écran 1920x1080 à 10,76 %, puis 414x896, 360x800, 384x832.

Les deux chiffres sont justes et ne portent pas sur la même population : 49 % de pages vues depuis un ordinateur dans un pays où 9,6 % des gens en ont touché un en trois mois. StatCounter mesure l'audience du parc de sites qui portent son mouchard, pas le pays. Preuve supplémentaire : Tecno, Infinix et itel, qui équipent le marché d'entrée de gamme ouest-africain, sont ABSENTS de sa liste de marques, où Apple sort premier à 32,5 %.

A NE PAS FAIRE : dimensionner une maquette grand public sur StatCounter. Le bon réflexe est ARTCI pour savoir qui a quoi, StatCounter pour un intranet ou un site de marque premium. Le point de contrôle à 390 px du standard de rendu est confirmé, et même généreux.

NON COUVERT : la part de marché réelle des marques ici, aucune source mesurée trouvée ; le débit et le coût de la connexion ; les versions d'Android en service. Réserve portée dans la fiche : l'électricité à 96,2 % des ménages annoncée par l'ARTCI est très au-dessus des taux d'électrification publiés ailleurs, à recouper avec l'INS avant tout réemploi.

## Contenu

### CL-KOFFI-23 · L'étiquetage et les mentions obligatoires sur un packaging
- **Pourquoi** : Un packaging magnifique et non conforme se réimprime entièrement
- **Où chercher** : Codinorm, normes ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.codinorm.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Loi n° 2016-412 sur la consommation, Livre 1, pour les mentions obligatoires. ⛔ Les normes CODINORM ne sont pas dans la base : la loi donne l'obligation, pas le détail normatif du packaging. || Ajout du 17/09. Ce sont ces textes qui décident de ce qui doit figurer sur l'emballage. Directement utile pour une cliente cosmétique comme Beauty Ivoire.

## Audience

### CL-KOFFI-24 · Le pictogramme comme réponse au niveau de lecture
- **Pourquoi** : Une partie du pays ne lit pas : l'image fait le travail que le mot ne fait pas
- **Où chercher** : Agence nationale de la statistique, RGPH
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.anstat.ci/
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/09/2027
- **Commentaire** : INTÉGRÉ LE 21/09, par l'intégration banque-mondiale. Note d'usage neuve : memory/reference/bases-locales/socle-local-ci/alphabetisation-et-niveau-de-lecture.md. ⛔ LE CHIFFRE EST PLUS BAS QU'ON NE CROIT : alphabétisation des adultes 50,0 % en 2021, hommes 60,2 %, femmes 40,3 %, jeunes de 15 à 24 ans 66,8 %. Le triplet 2021 est cohérent, sa moyenne retombe sur le total. ⚠ LA SÉRIE EST INSTABLE entre millésimes (56,96 % en 2019, 50,0 % en 2021, hommes 67,6 en 2019, 60,2 en 2021, 68,05 en 2022) : ce n'est pas un phénomène, ce sont des changements d'enquête. On cite le triplet 2021 en entier avec son année, et on ne compare pas deux millésimes. CE QUE ÇA COMMANDE : un adulte sur deux ne lit pas couramment, le pictogramme n'est donc pas une coquetterie mais le seul canal qui franchit la barrière, et la radio (99,3 % des ménages selon la MSI 2024) est le seul média qui ne demande pas de savoir lire. ⛔ NON COUVERT : le niveau de lecture par région et par langue, qui changerait un plan de diffusion. || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || Ajout du 17/09. RGPH 2014 : plus de la moitié de la population de 15 ans et plus ne lit ni n'écrit dans aucune langue, avec un écart de 30,1 % à Abidjan à 84,7 % dans le Folon. Pour une rédactrice c'est une contrainte de texte ; pour un designer c'est une commande. Chiffres de 2014, à réactualiser sur le RGPH 2021. anstat.ci filtre les scripts en 403, il s'ouvre au navigateur.

## Marque et identité

### CL-KOFFI-27 · Carte des design systems de l'espace Figma Yelema
- **Pourquoi** : Treize systèmes coexistent, un par marque du portefeuille, plus celui de la maison et un gabarit de démarrage. Sans cette carte, l'expert ne sait pas qu'un système existe pour la marque sur laquelle il travaille, et il invente des couleurs qui existent déjà.
- **Où chercher** : Espace Figma de l'équipe Yelema, relevé par integrations/figma/lister.py
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **Commentaire** : Demandé par la direction le 22/09/2026 (« prends les 13 »). Carte ENGENDRÉE, régénérable par integrations/figma/poser-design-systems.py. ⛔ Les codes couleur ne sont PAS dans la carte : ils se lisent dans le fichier de la marque, à l'ouverture.
