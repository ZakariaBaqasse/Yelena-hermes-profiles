---
id: Y0416
name: planche-d-inspiration
description: "Construit la direction artistique d'une marque avant qu'aucun logo n'existe : deux ou trois territoires visuels réellement distincts, chacun avec ce qu'il engage à signifier, sa projection sur les supports réels de l'entreprise, et le territoire à éviter — puis fait trancher la bonne personne avant que le dessin commence."
bucket: B
tags: [Design, Marque, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# La planche d'inspiration — se mettre d'accord avant de dessiner

## Ce qu'il faut avoir sous la main
- **L'entreprise et ce qu'elle fait** — le métier réel, pas le slogan.
- **À qui elle parle** : le client type, sa langue, son rapport à la marque (proximité, autorité, prix, confiance).
- **Ce qu'elle veut qu'on ressente** en la voyant — et surtout **à quoi elle ne veut pas ressembler**, y compris un concurrent ou un secteur précis à éviter.
- **Les supports réels** où la marque va vivre : enseigne, packaging, statuts WhatsApp, flyer imprimé chez un imprimeur de quartier, uniforme, véhicule — ce qui existe vraiment, pas une liste idéale.
- **Qui tranche** : la personne qui a le dernier mot sur le choix de direction.
- **Ce qui existe déjà** : un logo, une charte, un guide de marque, des couleurs déjà utilisées sur le terrain — même informelles.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Partir de la marque, pas des tendances

Avant de chercher une seule image, écris en une page ce que la marque est : ce qu'elle vend réellement, à qui elle parle, ce qu'elle veut qu'on ressente, et — surtout — à quoi elle ne veut pas ressembler. Cette dernière question est souvent la plus révélatrice : un dirigeant qui dit « pas comme telle enseigne du quartier » ou « pas comme une administration » te donne plus d'information qu'une liste de mots-clés positifs.

Si cette base manque, ne va pas chercher des images « qui pourraient plaire » — c'est le chemin qui produit une planche esthétique et hors sujet. Demande le minimum indispensable, ou construis l'hypothèse et marque-la comme telle.

### Étape 2 — Identifier qui tranche, avant de produire quoi que ce soit

Nomme la personne qui a le dernier mot sur le choix de direction. Une direction validée par un interlocuteur qui n'est pas décideur se rejoue entièrement au moment de la présentation au dirigeant, et le travail de construction repart de zéro avec un angle différent. Si l'entreprise cohabite avec une tutelle (publique, un partenaire, une maison mère), vérifie si cette tutelle a un droit de regard sur l'identité visuelle — le cas échéant, elle doit être dans la boucle de validation, pas découvrir la planche après coup.

Si le décideur n'est pas identifié, tu le signales avant de produire la planche complète : construire un territoire pour quelqu'un qui ne tranchera pas est un travail qui ne sert à rien.

### Étape 3 — Construire deux ou trois directions réellement distinctes

Jamais une, jamais sept. Une seule direction ne se choisit pas, elle se subit — le client n'a d'autre option que d'accepter ou de tout rejeter, ce qui ne fait pas avancer la décision. Sept directions diluent le choix et fabriquent un compromis mou, où la direction finale retenue est une moyenne de tout, donc l'identité de rien.

Chaque direction doit être un pari différent, pas une variation de teinte sur le même pari. Distingue-les sur ce qui compte réellement : le registre (institutionnel, populaire, artisanal, technologique…), pas seulement la palette de couleurs.

### Étape 4 — Expliciter ce que chaque direction engage à signifier

C'est le cœur de la planche, et c'est ce qui la sépare d'une collection d'images. Sous chaque direction, écris une phrase qui la résume, puis ce que la choisir engage à dire de l'entreprise, puis ses registres détaillés : couleur, forme, typographie, image, matière, mouvement. Termine par ce à quoi on renonce en la choisissant — chaque direction a un coût, et le nommer évite qu'on découvre le renoncement après la production du logo.

Une planche sans cette explicitation n'est pas incomplète, elle est inutile : elle obtient une réaction esthétique là où il faut une décision stratégique.

### Étape 5 — Projeter chaque direction sur les supports réels, y compris les plus pauvres

Une direction ne se juge jamais dans le vide, sur un écran haute définition dans un bureau climatisé. Projette chacune sur deux ou trois supports que l'entreprise utilise vraiment : une enseigne susceptible d'être peinte à la main plutôt qu'imprimée en numérique, un flyer tiré chez un imprimeur local avec les moyens dont il dispose, une image envoyée par WhatsApp et recompressée au passage, un écran de téléphone d'entrée de gamme lu en plein soleil.

Une direction construite sur des dégradés subtils, des photographies à faible contraste et des espacements très aérés peut être remarquable sur un grand écran et devenir illisible dès qu'elle rencontre ces conditions. Si un test de lisibilité ou de rendu est nécessaire (contraste, taille de lecture, fidélité des couleurs à l'impression), tu dis qu'il doit être fait avec les outils et référentiels de l'équipe — tu ne donnes jamais toi-même la valeur du seuil.

Interroge aussi la durée de vie attendue : une direction calquée sur l'esthétique du moment date vite, et une petite entreprise ne refait pas son identité fréquemment. Arbitre en conséquence, en le disant explicitement si une direction est plus « tendance » qu'« intemporelle ».

### Étape 6 — Tracer le territoire à éviter

Montre ce qui existe déjà dans le secteur et qui rendrait la marque indistincte — les codes que la concurrence directe utilise déjà, les tics visuels qui se ressemblent tous. Montre aussi les codes qui porteraient un message non voulu compte tenu du contexte : une esthétique qui évoquerait une administration alors que la marque veut être perçue comme proche, ou l'inverse.

Le territoire à éviter est aussi informatif que les directions proposées, souvent plus : il débloque des discussions enlisées en donnant au client un langage pour dire ce qu'il refuse, pas seulement ce qu'il aime.

### Étape 7 — Cadrer les droits sur les images et poser la question de validation

Rappelle explicitement dans le livrable que les images de la planche sont des références, pas la matière du visuel final — elles appartiennent à quelqu'un, et la planche doit le dire pour qu'on ne croie pas que ce qui est montré sera repris tel quel. Toute image dont la licence n'est pas connue est signalée comme telle, jamais présentée comme libre de droits par défaut.

Termine par la question de validation, posée nettement et adressée à la personne nommée à l'étape 2 : quelle direction est retenue, à quelle date la réponse est attendue, et ce qui se passe ensuite (déclinaison en logo, en charte, en supports). Une planche sans question de validation explicite reste un document esthétique — elle ne fait avancer aucune décision.

## Format de sortie
- **Livrable** : la planche d'inspiration — pour chaque direction (deux ou trois) : son nom, la phrase qui la résume, ce qu'elle engage à signifier, ses registres visuels (couleur, forme, typographie, image, matière, mouvement), sa projection sur deux ou trois supports réels de l'entreprise, et ce à quoi on renonce en la choisissant. Puis le territoire à éviter, avec la raison. Puis le rappel sur les droits des images de référence. Puis la question de validation, adressée à la personne nommée, avec la date attendue et la suite prévue.
- **Structure** : Markdown clair, une section par direction ; les registres et la projection sur supports en liste ou tableau pour rester lisibles à l'écran comme à l'impression.
- **Longueur** : proportionnée — chaque direction tient sur une portion resserrée, la planche complète ne s'étale pas en dizaines de pages.
- **Aucune image n'est produite ni collée par la skill** : elle décrit le territoire, les registres et la référence attendue ; le choix des visuels concrets et leur licence relèvent de l'équipe design ou d'une banque d'images identifiée.
- **Règle 0 invention** : aucune valeur chiffrée (contraste, résolution, poids de fichier, couleur exacte) n'est produite de mémoire. Si une mesure est nécessaire, elle est décrite comme une vérification à faire avec un outil ou un référentiel nommé, jamais comme un chiffre donné par la skill.

## Règles
1. **Aucune direction sans ce qu'elle engage à signifier.** Une planche qui montre des images sans dire ce qu'on en retient produit une réaction esthétique, pas une décision. Chaque direction porte sa phrase et son engagement de sens.
2. **Deux ou trois directions, jamais une, jamais sept.** Une seule ne se choisit pas, elle se subit. Trop de directions diluent le choix en compromis mou.
3. **Chaque direction est projetée sur les supports réels de l'entreprise**, y compris les plus pauvres : papier ordinaire, enseigne peinte à la main, téléphone d'entrée de gamme en plein soleil, image recompressée par une messagerie. Une direction qui ne survit qu'en haute définition n'est pas retenue sans le signaler.
4. **Le territoire à éviter fait partie du livrable**, pas une note en bas de page. Ce qui est refusé informe autant que ce qui est proposé.
5. **Les images de la planche sont des références, jamais la matière finale.** Ce rappel figure explicitement dans le document, et toute licence inconnue est signalée comme telle.
6. **La personne qui tranche est identifiée avant que la planche soit produite dans sa version complète.** Sans décideur nommé, tu le signales et tu avances avec l'hypothèse la plus probable, étiquetée.
7. **0 chiffre inventé.** Aucun seuil de contraste, aucune résolution, aucune valeur de couleur, aucun poids de fichier n'est produit de mémoire. Une vérification nécessaire est décrite comme une tâche pour l'équipe ou un outil, jamais comblée par une valeur plausible.
8. **Le contexte local n'est pas un décor.** Une direction pensée pour un écran haute définition et une lecture au calme ne se transpose pas telle quelle à une lecture en plein soleil, une diffusion par WhatsApp ou une impression chez un prestataire aux moyens limités.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer la planche au client, publier une image ou engager un achat de licence est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une marque ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Décideur non identifié** — tu signales le manque, tu avances avec l'hypothèse la plus probable en l'étiquetant, et tu marques la validation finale comme **provisoire** tant que la bonne personne n'a pas tranché.
- **Une seule direction demandée par le client** — tu rappels pourquoi une direction unique ne se choisit pas, tu proposes néanmoins deux variantes à l'intérieur de cette direction pour donner un minimum de choix, et tu le signales clairement.
- **Guide de marque ou charte déjà existants** — tu pars de ce document plutôt que de le contredire ; toute direction proposée doit dire explicitement si elle prolonge ou rompt avec l'existant, et pourquoi.
- **Tutelle publique ou partenaire ayant un droit de regard** — tu le signales dès l'étape 2, tu l'inclus dans la question de validation, et tu ne présentes pas la planche comme définitive sans son avis si ce droit de regard est confirmé.
- **Aucun support réel précisé** — tu le dis explicitement, tu proposes une projection sur les supports les plus probables pour ce type d'entreprise en les étiquetant `[hypothèse]`, et tu recommandes de vérifier la liste réelle avant la production finale.
- **Licence des images de référence inconnue** — tu ne présentes jamais une image comme libre de droits par défaut ; tu la marques `[licence à vérifier]` et tu rappelles que la planche sert de référence, pas de matière finale.
- **Demande de production du logo ou des supports finaux** — tu le signales comme hors périmètre de cette skill, tu livres la planche validée jusqu'à ce point, et tu orientes vers la compétence de déclinaison graphique.
- **Retours contradictoires entre plusieurs interlocuteurs** — tu exposes les deux positions sans trancher à leur place, et tu renvoies la décision à la personne identifiée comme décideur.
