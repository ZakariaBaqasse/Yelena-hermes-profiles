---
name: livrable-html-pdf
description: "Fabriquer et livrer un document destiné à la direction : HTML autonome soigné puis export PDF (format de livraison par défaut), contrôle visuel du rendu avant envoi, pièges WeasyPrint constatés, versionnage et règle de publication. À charger dès qu'un livrable est produit — revue de presse, veille, note, brief, relevé."
version: 1
maj: 2026-08-14
---

# Livrable HTML → PDF

Chaîne de fabrication de tout document destiné à la direction. Le fond passe par les skills métier
(revue de presse, note de décision, brief…) ; **celui-ci ne traite que la forme et la livraison.**

## Règle de format — arrêtée le 01/08/2026

**Le PDF est le format de livraison par défaut**, et depuis le 14/08/2026 il s'accompagne
**toujours du document Google brandé** dont il est issu : un document Google pour une note ou
un rapport, une présentation Google pour un jeu de diapositives. Le client reçoit donc les
deux — le PDF pour lire et faire circuler, le document vivant pour commenter et amender.

```
deliverables/<projet>/<slug>_vN.md      ← source
deliverables/<projet>/<slug>_vN.pdf     ← ce qu'on envoie
                                        ← + le lien du document Google, dans le fil
```
Même `N` pour les deux formats. Une révision = un nouveau `_v(N+1)`, jamais d'écrasement.

## Ce que le document doit porter

- **Bandeau** : entreprise, période couverte, heure d'arrêt, prochaine échéance connue.
- **Sources cliquables et datées** sur chaque affirmation — les liens restent actifs dans le PDF.
- **Un bloc « Pourquoi ça compte pour la direction »** par sujet.
- **Visa de contrôle** en fin de document (5 passes, compteurs, statuts revérifiés, réserves).
- **Pied de page** : mention « document interne — ne pas diffuser hors de l'entreprise ».

## Fabrication — deux chaînes, et la seconde est la nouvelle par défaut

### A. Document Google → PDF (par défaut depuis le 14/08/2026)

Aucun moteur de rendu PDF n'est installé sur cette machine et aucun gestionnaire de paquets
ne permet d'en ajouter. La chaîne qui marche passe donc par l'espace Google du client, et
elle a un avantage que l'ancienne n'avait pas : **le client reçoit un document vivant**,
commentable et modifiable, en plus du PDF.

```bash
# 1. le fond s'écrit en markdown, logo de la marque en première ligne :
#    ![](logo.png){width=150 height=88}   ← l'image doit être dans le même dossier
gog docs create "<Titre> (v<N>)" --file <slug>_vN.md --parent <dossier Drive>
gog docs export <docId> --format pdf --output <slug>_vN.pdf

# pour une présentation : diapositives composées ici, aux couleurs de la marque
python3 outils/deck-brande.py <spec>.json <dossier images>
gog slides create "<Titre> (v<N>)" --parent <dossier Drive>
gog slides add-slide <deckId> <image.png> --notes "<notes de l'orateur>"
gog slides export <deckId> --format pdf --output <slug>_vN.pdf
```

⚠️ `GOG_KEYRING_PASSWORD=""` **et** `GOG_ACCOUNT="<compte>"` sont tous les deux nécessaires,
sinon la commande échoue sur un compte manquant.

**Pourquoi les diapositives se composent en images et pas en markdown** : l'import markdown
de Google produit un thème Google, donc un document non brandé. En composant chaque
diapositive localement, on tient la couleur relevée sur le logo officiel, la typographie et
la place du logo. Les notes de l'orateur portent le texte en clair, et chaque diapositive
reste remplaçable une par une (`gog slides replace-slide`).

### B. HTML autonome → PDF

À garder pour les documents très mis en page — tableaux de bord, pages interactives — que
Google Docs ne sait pas rendre. Elle suppose un moteur de rendu installé, ce qui n'est pas
le cas ici aujourd'hui.

```bash
weasyprint <slug>_vN.html <slug>_vN.pdf
pdfinfo <slug>_vN.pdf | grep -i pages          # contrôle du volume
pdftoppm -png -r 68 -f 1 -l 2 <slug>_vN.pdf /tmp/apercu   # relecture visuelle avant envoi
```

**Dans les deux cas, on contrôle le PDF avant d'envoyer** : nombre de pages, et au moins la
première page relue. Un PDF qui sort à 14 pages à moitié vides ou sans son logo est un
livrable raté, et cela ne se voit pas dans la source.

## Pièges WeasyPrint — constatés, pas supposés

| Ce qui casse | Ce qu'il faut écrire |
|---|---|
| `linear-gradient` multi-arrêts | trois `<i>` en `display:flex` avec `background` plein |
| `grid-template-columns:repeat(auto-fit,minmax(...))` | `display:flex; flex-wrap:wrap` + `flex:1 1 110px` |
| `stroke` / `fill` / `stroke-width` en CSS sur un SVG | attributs de présentation sur la balise `<svg>` |
| `@media (max-width:520px)` | `@media screen and (max-width:520px)` |
| `@media (prefers-color-scheme: dark)` | ignoré en PDF — le rendu sort en thème clair, c'est voulu |
| `font-weight:650` | valeur non standard → `600` |
| `@page { bleed:3mm }` | déclare la BleedBox **sans étendre le dessin** : le fond et la photo s'arrêtent au trait de coupe. Étendre explicitement les aplats et images de 3 mm au-delà du format fini, puis mesurer au rendu (vécu le 23/09 sur les trois fichiers du kit [entreprise cliente]) |

## Feuille d'impression — sinon le volume double

Sans `@media print` resserré, un document de 8 pages en sort 14, à moitié vides : `break-inside:avoid`
sur des blocs d'une demi-page pousse chaque item sur une nouvelle page.

```css
@page{ size:A4; margin:14mm 13mm 16mm; }
@media print{
  body{font-size:9.6pt; line-height:1.5; background:#fff}
  .item, li{break-inside:auto}          /* PAS avoid sur les gros blocs */
  h3, h4{break-after:avoid}             /* le titre reste avec son texte */
  .facts, .encadre, .sources{break-inside:avoid}   /* avoid seulement sur les petits blocs */
}
```

## Publication

Le lien public (GitHub Pages) est réservé aux documents **bâtis sur sources publiques** :
revues de presse, veilles, fiches partenaires ou concurrents. **Ne jamais publier** une note de
décision, un cadrage de réunion, un relevé ou un brief de rendez-vous — ils sont remis en main
propre sur le canal de la direction. GitHub Pages est public : un dépôt privé ne sert pas de
site sans plan payant.

⚠ La publication suppose un jeton d'accès valide, rangé dans le magasin de secrets de la machine
(jamais en clair dans un script). Vérifier qu'il n'est pas expiré **avant** d'annoncer un lien :
un `401` se découvre sinon au moment de livrer.

## Message d'accompagnement

Le PDF part avec un message Telegram qui dit **ce qui a changé** depuis la version précédente et
**ce qui reste ouvert** — jamais un simple « voici le document ».

## Le lien de rendu accompagne chaque PDF — règle du 21/09/2026

Demande écrite de l'utilisateur dans le fil design, le 21/09/2026 à 12h00 UTC : « est ce que
tu peux rendre tous les livrables pdf aussi visibles en lien render par défaut ». Donc, **par
défaut**, tout livrable livré en PDF est aussi publié sur le service de pages partageables de la
maison, et le message porte le lien (en hyperlien texte) avant le fichier.

Chaîne, éprouvée ce jour sur deux livrables :

```bash
# 1. la source HTML porte un bloc @media screen (largeur max 900 px, captures et colonnes qui
#    passent en pile sous 700 px, tableaux en table-layout: fixed avec overflow-wrap: anywhere)
# 2. copie de travail avec des images allégées si le total dépasse ~1,5 Mo (limite service : 2 Mo)
python3 integrations/frames/autonomiser.py <copie>.html --sortie <copie>.render.html   # incorpore les images en data URI
python3 integrations/frames/publier.py <copie>.render.html --titre "<titre lisible>" --accord
# 3. contrôle SUR L'ADRESSE SERVIE, à 390 px et à 1200 px : pas de débordement horizontal
# 4. republier = même fichier + --id frm_<8 premiers caractères de l'UUID du lien>
```

- La demande de l'utilisateur vaut accord pour la publication des livrables qu'il a demandés
  dans le fil ; ce qui ne peut pas être public (nom de candidat, rémunération, note interne,
  donnée d'une autre maison) reste en PDF seul, et on le dit.
- Le service ne charge aucune police : le rendu sort en pile système. Les images passent.
- Un tableau à colonnes d'adresses déborde sur téléphone tant que les liens ne portent pas
  `overflow-wrap: anywhere` — c'est le défaut trouvé au premier contrôle.

## Retours du 21/09/2026 (Aicha Koné, par écrit) — priment sur ce qui précède

1. **Avant tout travail** : confirmer l'entreprise, montrer le logo et la palette, demander « A je pars là-dessus / B corrige », n'avancer qu'après la réponse.
2. **Relire la charte à chaque livrable** (couleurs, typographies, règles du logo) ; un support hors charte est à refaire.
3. **Trois niveaux de design à chaque proposition** : basique (texte, logo, motif), intermédiaire (avec image), sophistiqué ; chacun en carré et en story, jamais un seul A4.
4. **Un benchmark** est une analyse stratégique (positionnement, réseaux, campagnes, ton) qui sort en **Google Slides visuel** (icônes, chiffres) puis en PDF, jamais un long PDF de texte.
5. **Un écran d'application ne sort jamais en PDF** : Figma, UXPilot ou Stitch, rendu moderne, lien partagé, au niveau des applications de référence.
6. **Chaque livraison nomme l'application utilisée.**
7. **Messages courts** : une idée, deux au plus, QCM A/B/C pour tout choix, liens en avant.

Texte intégral et ce que chaque règle change contre le travail du 21/09 : `memory/regles-de-forme.md`.
