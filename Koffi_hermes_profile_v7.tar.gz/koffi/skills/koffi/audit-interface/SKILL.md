---
id: Y0418
name: audit-interface
description: "Audite un site ou une application déjà en service à partir des tâches que les gens viennent y accomplir, dans les conditions réelles du public (appareil, connexion, compte vide) : repère chaque friction, chaque rupture silencieuse, distingue le goût du défaut et le qualitatif du mesuré, puis rend un rapport hiérarchisé par gravité et coût de correction — sans jamais inventer un seuil, un contraste ou une donnée d'usage."
bucket: B
tags: [Design, Produit, Qualité, Nouveau]
version: 1
maj: 2026-08-13
---

# Auditer une interface qui tourne déjà

## Ce qu'il faut avoir sous la main
- **L'interface** : lien ou accès, et les écrans ou parcours à couvrir en priorité si tout n'est pas à auditer.
- **Les tâches principales** que les gens viennent accomplir — pas les fonctionnalités, les intentions réelles des utilisateurs.
- **Le public visé** et ses conditions réelles : appareils qu'il possède majoritairement, qualité et coût de sa connexion, niveau de familiarité avec le numérique, langue de lecture.
- **Ce que tu as déjà** : statistiques d'usage, retours utilisateurs, tickets de support, verbatims — même partiels.
- **Le contexte** : marque seule ou cohabitant avec une tutelle publique, contraintes de charte déjà fixées.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un accès partiel ou une description suffit, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant ce qui manque `⟦à mesurer⟧` ou `[à confirmer]`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Partir de la tâche, jamais de l'écran

Avant d'ouvrir la moindre page, liste ce que les gens viennent accomplir : s'inscrire, payer, retrouver une information, signaler un problème, comprendre un statut. Chaque tâche devient un parcours à parcourir de bout en bout — pas une collection d'écrans à commenter un par un.

Si la personne qui commande l'audit ne peut pas nommer les tâches, c'est déjà un signal : l'interface a probablement été construite écran par écran, sans que personne n'ait tenu le fil de ce que l'utilisateur cherche à faire.

### Étape 2 — Se placer dans les conditions réelles du public

C'est le piège le plus fréquent : auditer sur un grand écran, avec une connexion confortable, un compte déjà rempli de données, et une connaissance du produit que l'utilisateur réel n'a pas. Rien de ce que tu verras dans ces conditions ne ressemble à ce que vit un nouvel utilisateur.

Avant de parcourir quoi que ce soit, fixe les conditions à reproduire : l'appareil que le public possède réellement — souvent un téléphone d'entrée de gamme à écran modeste, pas le dernier modèle — la qualité et le coût de sa connexion (le public paie ses données, une page lourde a un coût réel, pas seulement un temps d'attente), la lecture possible en plein soleil sur un écran, et un compte **vide**, comme à la toute première visite, sans savoir ce que le produit est censé faire.

**Tu relèves ces conditions, tu ne les déduis pas du pays.** Elles se demandent en une ligne au commanditaire et se notent avec leur date. Un téléphone d'entrée de gamme, une connexion payée au volume, une lecture en plein soleil sont des cas **fréquents à vérifier**, pas des vérités régionales : les servir sans les avoir relevées, c'est faire passer une généralité pour une observation.

Si l'audit ne peut être fait que dans de meilleures conditions que celles du public, le dire explicitement dans le rapport plutôt que de laisser croire que le test est représentatif. Et si une condition n'a pas été relevée, elle apparaît dans le rapport comme hypothèse marquée, jamais comme constat.

### Étape 3 — Parcourir chaque parcours et situer chaque friction

Pour chaque tâche de l'étape 1, avance pas à pas comme le ferait quelqu'un qui découvre le produit. Note tout moment où il faut s'arrêter pour comprendre, où une action ne produit pas l'effet attendu, où il faut revenir en arrière, où deux interprétations sont possibles, où l'attente est longue sans indication de ce qui se passe.

Chaque friction est **située précisément** : quel écran, quel élément, à quelle étape du parcours — jamais « la navigation est confuse » en général. Un constat qui ne pointe pas un endroit exact ne peut pas être corrigé.

### Étape 4 — Chercher ce qui casse silencieusement

Certains défauts ne se voient que si on les cherche exprès, parce qu'ils n'apparaissent jamais dans une démonstration :
- **Le premier écran sans données** — ce que voit quelqu'un qui n'a encore rien créé, rien acheté, rien renseigné. Un écran vide sans indication de quoi faire perd la personne avant même qu'elle commence.
- **La connexion lente ou coupée** — ce qui se passe quand une page met du temps à charger, ou quand la connexion tombe en cours d'action : est-ce que la personne comprend qu'il faut attendre, ou croit-elle que rien ne fonctionne.
- **L'échec d'une opération** — paiement refusé, envoi échoué, session expirée : est-ce que le message dit ce qui s'est passé et **ce qu'il faut faire ensuite**, ou se contente-t-il de signaler une erreur.
- **Les formulaires qui perdent ce qui a été saisi** — un retour en arrière, un rechargement, une session coupée qui efface tout ce que la personne a déjà tapé est une des frictions les plus coûteuses en confiance.
- **Le rendu sur les appareils réels du public** — pas seulement l'appareil de test : ce qui déborde, ce qui devient illisible, ce qui disparaît hors de l'écran sur les tailles et résolutions réellement en usage.
- **La langue et le canal de diffusion** — si les visuels ou messages produits par le produit circulent au-delà de l'interface elle-même (capture partagée sur WhatsApp, par exemple), vérifie qu'ils restent compréhensibles hors contexte, sans le reste de l'écran autour.

### Étape 5 — Écrire chaque constat correctement

Un constat d'audit n'est jamais une préférence. « Je n'aime pas ce vert » n'est pas un constat ; « la couleur du bouton de validation ne se distingue pas du fond sur cet écran, à cet endroit du parcours, et des personnes hésitent avant de cliquer » en est un — parce qu'il s'appuie sur une conséquence observable, pas sur un goût.

Chaque constat suit la même forme : **observation** (ce qui a été vu, où exactement), **conséquence** (pour la personne, et pour l'entreprise — abandon, erreur, appel au support, perte de confiance), **correction proposée**, **ampleur de la correction** (immédiate, moyenne, refonte).

Deux séparations sont non négociables :
- **Qualitatif et mesuré ne se mélangent pas.** Dire qu'un texte semble trop petit ou qu'un contraste semble insuffisant demande une mesure faite avec un outil ou un référentiel nommé qui fixe le seuil. Sans l'un ou l'autre, tu écris le constat qualitatif et tu marques la valeur `⟦à mesurer⟧` — tu ne donnes jamais un chiffre de mémoire pour faire sérieux, même un chiffre qui « sonne juste » dans le métier.
- **Observation et donnée d'usage ne se confondent pas.** Ce que tu constates en parcourant l'interface est une expertise de parcours, pas une mesure de comportement réel. Si l'entreprise fournit des statistiques d'usage (taux d'abandon, pages de sortie, tickets de support), tu les cites et les distingues clairement de tes propres observations. Sans elles, tu écris franchement que le constat est qualitatif et tu proposes ce qu'il faudrait instrumenter pour le vérifier.

### Étape 6 — Hiérarchiser par gravité et coût de correction

Un rapport plat de trente constats sans ordre ne se traite pas. Croise deux axes pour chaque constat : la **gravité pour l'utilisateur** (empêche la tâche / la ralentit / l'irrite sans la bloquer) et le **coût de la correction** (immédiat / moyen / refonte). Ce qui est grave et peu coûteux à corriger monte en tête du rapport — c'est ce qu'une équipe avec peu de temps doit traiter en premier.

Ne laisse jamais un constat mineur mais spectaculaire (une couleur qui choque) prendre le pas sur un constat grave mais discret (un message d'erreur qui ne dit rien à faire). C'est l'inverse de ce que produit un regard non entraîné.

### Étape 7 — Protéger ce qui fonctionne

Un audit qui ne relève que des problèmes pousse l'équipe à tout remettre en cause, y compris ce qui marche. Nomme explicitement les parcours où les gens réussissent sans hésiter, les choix qui tiennent, les éléments à ne pas toucher en corrigeant le reste. C'est autant une partie du livrable que la liste des défauts.

## Format de sortie
- **Livrable** : le rapport d'audit — périmètre et conditions exactes du test (appareil, connexion, état du compte, date), parcours parcourus avec leurs frictions situées précisément, constats un par un (observation / conséquence / correction / ampleur) ordonnés par gravité et coût de correction, ce qui fonctionne et doit être protégé, et la liste de ce qui reste à mesurer faute de donnée disponible.
- **Structure** : Markdown clair — answer-first (les correctifs prioritaires d'abord, le détail ensuite) ; tableaux pour les constats et leur hiérarchie.
- **Longueur** : proportionnée au périmètre audité, sans remplissage. Un audit ciblé sur un ou deux parcours tient en quelques pages ; un audit complet peut être plus long, mais chaque ligne doit correspondre à un constat réel.
- **Les seuils mesurables sont un input**, pas une production : la skill nomme ce qu'il faudrait mesurer et avec quel outil ou référentiel, la valeur reste `⟦à mesurer⟧` tant qu'elle n'a pas été relevée.
- **Règle 0 invention** : aucun chiffre, seuil ou donnée d'usage inventé. Ce qui manque est marqué `⟦à mesurer⟧` ou `[à confirmer]`.

## Règles
1. **Le goût n'est pas un défaut.** Un constat s'appuie sur une conséquence observable — action ratée, information non trouvée, hésitation, erreur répétée, critère d'un référentiel nommé. « Je n'aime pas » n'entre jamais dans le rapport.
2. **L'audit se fait dans les conditions du public, pas dans les tiennes.** Appareil réel, connexion réelle, compte vide, absence de connaissance préalable du produit. Un audit fait dans de meilleures conditions le dit explicitement.
3. **0 seuil inventé.** Taille de texte, contraste, résolution, poids de fichier : jamais un chiffre de mémoire. Une mesure faite avec un outil, un référentiel nommé, ou `⟦à mesurer⟧`.
4. **Qualitatif et donnée d'usage ne se substituent jamais l'un à l'autre** dans le rapport. Ce qui est observé pendant le parcours est dit qualitatif ; ce qui vient de statistiques réelles est cité comme tel, avec sa source.
5. **Le rapport plat n'est pas un rapport.** Trente constats sans hiérarchie ne se traitent pas. La gravité pour l'utilisateur croisée au coût de correction fait apparaître ce qui se corrige tout de suite.
6. **Ce qui fonctionne est nommé.** Un audit qui ne liste que des problèmes pousse à casser ce qui marchait. Les parcours qui réussissent sont protégés autant que les défauts sont corrigés.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou mesurée est marquée `[à confirmer]` ou `⟦à mesurer⟧` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; publier une correction, déployer un changement ou contacter des utilisateurs est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un produit ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Accès partiel à l'interface** (captures seulement, pas d'accès interactif) — tu le signales, tu audites ce qui est visible, et tu marques explicitement les parcours que tu n'as pas pu parcourir toi-même.
- **Aucune statistique d'usage disponible** — tu produis le rapport entièrement qualitatif, tu le dis en toutes lettres, et tu listes ce qu'il faudrait instrumenter pour vérifier chaque constat majeur.
- **Impossible de reproduire les conditions réelles du public** (pas d'accès à un appareil ou une connexion représentatifs) — tu le signales avant de continuer, tu audites dans les conditions disponibles, et tu marques le rapport en conséquence plutôt que de le présenter comme représentatif.
- **Demande de note ou de score global** — tu rappelles que le rapport hiérarchise des constats, pas une note ; tu peux résumer en tête de rapport le nombre de constats par gravité, sans fabriquer un score chiffré global.
- **Interface partagée entre une marque et une tutelle publique** — tu le signales quand une correction touche des éléments qui ne relèvent pas de l'équipe produit (mentions obligatoires, identité visuelle imposée) et tu distingues ce qui se corrige librement de ce qui demande un arbitrage.
- **Demande hors périmètre** (refonte complète, nouvelle fonctionnalité) — tu le dis en une phrase, tu traites l'audit tel que défini, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (publication d'un correctif, envoi du rapport à un tiers) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources ou retours contradictoires** (l'équipe et le support ne décrivent pas le même problème) — tu exposes les deux versions dans le rapport et tu demandes l'arbitrage plutôt que de trancher seul.
