---
id: Y0407
name: preparation-fichiers-impression
description: "Met un fichier en conformité technique avant l'imprimeur : format et fonds perdus, marges de sécurité, mode colorimétrique, résolution, polices vectorisées, traits de coupe, export final — accompagné du questionnaire à poser au prestataire et du bon à tirer à signer. Zéro spécification technique inventée : formats, tolérances et profils viennent de l'imprimeur, jamais d'une règle générale supposée."
bucket: B
tags: [Design, Production, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Préparer un fichier pour l'imprimeur — ce qui se joue avant le bon à tirer

## Ce qu'il faut avoir sous la main
- **Le fichier source** (ou sa description précise) : format actuel, logiciel d'origine, contenu — texte, logo, photos.
- **Le format final imprimé** visé : dimensions, type de support (affiche, carte de visite, dépliant, bâche, packaging…).
- **L'imprimeur retenu**, si tu l'as déjà — et tout ce qu'il t'a déjà communiqué comme contrainte (format d'export, profil colorimétrique, tolérance de coupe, délai).
- **Les couleurs de marque** s'il y en a : référence exacte (Pantone, code hexadécimal, CMJN) si elle existe déjà.
- **Le degré d'urgence** : si le bon à tirer doit partir avant une date précise (salon, lancement, échéance commerciale).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Le questionnaire imprimeur, avant toute préparation

Le piège classique : préparer un fichier selon des règles générales trouvées quelque part, puis découvrir que l'imprimeur travaille autrement — et devoir tout refaire. Tu commences donc par lister ce qu'il faut lui demander, si ce n'est pas déjà fourni :
- Format d'export préféré (PDF, TIFF, natif) et version.
- Valeur exacte des fonds perdus et de la marge de sécurité qu'il exige.
- Mode colorimétrique accepté (CMJN, quadri, Pantone) et profil ICC à utiliser s'il en impose un.
- Contraintes de coupe, pliage, façonnage (agrafage, reliure, découpe spéciale) qui modifient le gabarit.
- Résolution minimale des images qu'il accepte en pratique.
- Délai de production et heure limite de dépôt du fichier — un imprimeur à Abidjan qui reçoit un fichier un vendredi après-midi ne le traite pas avant lundi.
- Mode de transmission du fichier : beaucoup de petits ateliers travaillent en clé USB ou dépôt physique plutôt qu'en envoi en ligne, faute de connexion assez rapide pour un fichier lourd.

Chaque case sans réponse reste `⟦à renseigner⟧` — tu ne la combles jamais par une valeur « standard ». Si l'imprimeur n'a pas encore répondu, tu le dis et tu prépares le fichier selon les meilleures pratiques générales en les marquant explicitement comme provisoires, à valider dès sa réponse.

### Étape 2 — Vérifier le fichier source : ce qui a été pensé pour l'écran ne tient pas sur papier

Un fichier conçu pour un écran est pensé en pixels, en RVB, en basse résolution relative. Tu vérifies :
- **Le format et l'échelle** : le fichier est-il construit à la taille réelle d'impression, ou agrandi depuis un format plus petit — auquel cas la résolution s'effondre à l'agrandissement.
- **La résolution des images** : une photo prélevée sur un site web ou une capture d'écran est presque toujours insuffisante pour l'impression, même si elle paraît nette à l'écran. Tu signales chaque image dont la résolution est en dessous de ce que l'imprimeur exige (étape 1), sans deviner un seuil universel.
- **Les éléments vectoriels vs images matricées** : un logo en vecteur (SVG, EPS, tracé) reste net à n'importe quelle taille ; un logo en JPEG agrandi ne le sera jamais. Tu identifies ce qui doit être revectorisé plutôt que redimensionné.

Le signal d'alerte : un fichier qui « a l'air bien » sur l'écran de contrôle du client ne dit rien de comment il sortira de la presse. C'est l'imprimeur qui juge la fabricabilité, pas l'œil sur écran.

### Étape 3 — Fonds perdus et marge de sécurité : la tolérance de coupe est une contrainte physique, pas une option

Toute machine de coupe a une tolérance — le trait ne tombe jamais exactement là où il est censé tomber. Deux règles en découlent, et les deux dépendent des valeurs fournies par l'imprimeur (étape 1), jamais d'une valeur par défaut :
- **Le fond perdu** : tout aplat de couleur ou image qui doit aller jusqu'au bord du support doit dépasser le format final de la valeur donnée par l'imprimeur, pour qu'une coupe légèrement décalée ne laisse jamais apparaître un liseré blanc.
- **La marge de sécurité** : tout texte ou élément important ne doit jamais être plus près du bord que la valeur de sécurité donnée par l'imprimeur. Un texte collé au bord sera rogné sur une partie du tirage — ce n'est pas un risque, c'est une certitude statistique sur un grand tirage.

Tu documentes dans la fiche technique : format final, format avec fonds perdus, position des marges de sécurité — avec la valeur exacte utilisée et sa source (« fournie par l'imprimeur le [date] » ou `⟦à renseigner⟧` si elle ne l'est pas encore).

### Étape 4 — Colorimétrie : ce que l'écran montre n'est pas ce que la presse imprime

Un écran affiche en RVB, lumière émise ; une presse imprime en CMJN (ou en tons directs Pantone), pigments déposés. Certaines couleurs vives et saturées à l'écran — en particulier certains bleus, verts fluo et oranges — sont **irréalisables en quadrichromie standard** et vireront systématiquement au terne ou au différent à l'impression. Tu signales chaque couleur du visuel qui présente ce risque, sans deviner comment elle rendra exactement — c'est un test d'épreuve physique chez l'imprimeur qui tranche, pas une estimation à l'écran.

Pour une **couleur de marque** (logo, charte graphique) : elle doit être fixée dans une référence stable — un code Pantone, un CMJN précis, un hexadécimal converti et validé une fois pour toutes — et cette référence doit être **la même à chaque commande, chez chaque imprimeur**. Un bleu de marque qui change d'un tirage à l'autre, ou d'un prestataire à l'autre, abîme la reconnaissance visuelle plus durablement qu'un visuel imparfait. Si la charte graphique du client ne fixe encore aucune référence stable, tu le signales comme un manque à combler avant la première impression officielle, pas après.

Tu appliques le mode colorimétrique et le profil ICC exigés par l'imprimeur (étape 1). S'il n'a rien précisé, tu le marques `⟦à renseigner⟧` et tu proposes de le lui demander avant l'export final — un export dans le mauvais espace colorimétrique se corrige rarement bien après coup.

### Étape 5 — Polices, traits de coupe, export final

- **Polices** : chaque police doit être vectorisée (convertie en tracés) ou intégrée (embed) dans le fichier final. Une police simplement « installée sur l'ordinateur du client » ne l'est pas forcément chez l'imprimeur — le texte se substitue alors par une police par défaut, souvent avec un résultat visuellement cassé.
- **Traits de coupe (crop marks)** : ils indiquent à la machine où couper. Tu les ajoutes s'ils sont demandés par l'imprimeur, avec l'écart au fond perdu qu'il précise — encore une valeur à ne jamais improviser.
- **Export final** : dans le format et les réglages exacts communiqués par l'imprimeur (compression des images, aplatissement des transparences, incorporation du profil colorimétrique). Tu listes chaque réglage appliqué dans la fiche technique, pour que ce soit vérifiable sans avoir à rouvrir le fichier.

### Étape 6 — Le bon à tirer : ce qui n'est pas signé n'engage personne

Tant qu'aucune version précise du fichier n'a été validée par écrit par la personne responsable côté client, personne n'est responsable de ce qui sort de la presse — et un désaccord après tirage ne se résout jamais en faveur du client si rien n'a été signé. Tu produis le bon à tirer comme un document autonome :
- Nom et version exacte du fichier envoyé (nom de fichier, date, heure).
- Aperçu ou description de ce que contient ce fichier précis.
- Confirmation explicite : format, couleurs, textes, quantités — tout ce qui doit être identique entre ce qui est validé et ce qui sera imprimé.
- Une ligne de signature et de date, à faire remplir avant l'envoi définitif à l'imprimeur.

Une modification après signature du bon à tirer repart en étape 5 avec une nouvelle version numérotée — jamais en écrasant discrètement le fichier validé.

## Format de sortie
- **Livrable** : le fichier prêt (ou les instructions précises pour le rendre prêt s'il n'est pas manipulable directement), accompagné de :
  - la **fiche technique** — format final, format avec fonds perdus, marges de sécurité, mode colorimétrique et profil, résolution des images, état des polices, traits de coupe, références de couleur de marque ;
  - le **questionnaire imprimeur**, rempli avec ce qui est connu et marqué `⟦à renseigner⟧` pour le reste ;
  - le **bon à tirer**, prêt à signer, avec version exacte et date.
- **Structure** : Markdown clair — answer-first (l'état de conformité du fichier d'abord : prêt / prêt sous réserve / non prêt, puis le détail).
- **Longueur** : proportionnée au support — une carte de visite ne demande pas la même fiche qu'une bâche grand format ou un packaging à façonnage complexe.
- **Règle 0 invention** : aucune valeur technique (fond perdu, tolérance, profil, délai) n'est produite sans être fournie par l'imprimeur ou explicitement marquée `⟦à renseigner⟧`.

## Règles
1. **Aucune spécification technique n'est inventée.** Fonds perdus, marges de sécurité, profil colorimétrique, tolérance de coupe, délai : ce sont des données propres à l'imprimeur retenu. Tant qu'elles ne sont pas fournies, elles restent `⟦à renseigner⟧` — jamais remplacées par une valeur « standard du métier ».
2. **Une image nette à l'écran n'est pas une preuve de résolution suffisante.** Tu vérifies la résolution réelle par rapport au format d'impression final, pas par rapport à son apparence sur un moniteur.
3. **Une couleur de marque a une référence unique et stable**, valable pour tous les tirages et tous les prestataires. Tu la fixes ou tu signales qu'elle manque — tu ne laisses jamais une couleur de marque « flotter » d'un fichier à l'autre.
4. **Le texte ne touche jamais le bord.** La marge de sécurité communiquée par l'imprimeur est une contrainte de fabrication, pas une préférence esthétique — tu la fais respecter même si le client la trouve trop généreuse.
5. **Rien ne part chez l'imprimeur sans bon à tirer signé.** Un fichier envoyé « pour test » ou « pour avoir une idée » sans validation écrite explicite n'est pas un bon à tirer, et tu le distingues clairement dans le livrable.
6. **Le contexte de transmission compte.** Un fichier de plusieurs centaines de mégaoctets ne s'envoie pas de la même façon avec une connexion lente et coûteuse qu'avec une fibre stable : tu proposes, si pertinent, une alternative de transmission (clé USB, dépôt physique, compression) plutôt que de supposer un envoi en ligne fluide.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer le fichier à l'imprimeur, valider un bon à tirer en son nom ou lancer une commande d'impression est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier (visuel, charte de marque, prestataire) ne fuite jamais vers un autre dossier traité dans la même conversation.

## Le contrôle se fait sur le RENDU — leçon du 23/09/2026

Deux fautes vécues le même jour, et aucune ne se voyait dans les propriétés du fichier :

- **Fond perdu déclaré et vide.** Les trois fichiers du kit terrain [entreprise cliente] portaient une
  BleedBox correcte de 3 mm, et l'encre s'arrêtait pile sur le trait de coupe. Lire les
  boîtes du PDF disait « conforme ». Il faut rendre la page et mesurer où l'encre s'arrête
  sur chaque bord, loin des traits de coupe.
- **Police incorporée, mais pas la bonne.** Sur un dossier client du 22/09, `pdffonts` listait
  « Inter » incorporée ; la graisse grasse était en réalité une police à empattements
  substituée à la conversion. Ma liste de contrôle a coché « Fait ». Il faut regarder le rendu
  de chaque page.
- **Page blanche.** Un recto de carte de visite dessinait le logo en blanc sur une page sans fond.
  Un fichier de 2 Ko sans texte extractible ni image se regarde avant d'être déclaré prêt.

Outils : `pdfinfo`, `pdffonts`, `pdfimages -list` (ppp à la taille placée), `pdftotext -bbox`
(distance de chaque mot au trait de coupe), `pdftoppm` ou Ghostscript pour le rendu,
`gs -sDEVICE=inkcov` (couverture d'encre, indicative seulement). **Une case « Fait » ne se
coche qu'après avoir regardé le rendu.**

## Cas limites
- **L'imprimeur n'a pas encore répondu au questionnaire** — tu prépares le fichier selon les meilleures pratiques générales en les marquant explicitement comme provisoires, et tu listes precisément ce qui devra être revérifié dès sa réponse.
- **Le fichier source ne contient pas de vecteurs pour le logo ou le texte** (image matricée uniquement) — tu le signales comme point bloquant pour la qualité d'impression, tu ne tentes pas de vectoriser automatiquement une image qui ne le permet pas proprement.
- **Une image fournie est en dessous de la résolution nécessaire et aucune version meilleure n'existe** — tu le dis clairement, tu proposes les options réalistes (réduire sa taille d'impression, la refaire, l'exclure) sans masquer le problème derrière un export qui « passera quand même ».
- **Une couleur de marque n'a jamais été fixée dans une référence stable** — tu le signales comme un manque à traiter avant l'impression, tu ne fixes pas toi-même une valeur arbitraire à sa place.
- **L'imprimeur change de spécification en cours de projet** (nouveau format, nouveau profil demandé après un premier envoi) — tu reprends la fiche technique depuis l'étape concernée, tu ne rafistoles pas l'ancienne version.
- **Une modification est demandée après signature du bon à tirer** — tu la traites comme une nouvelle version numérotée avec un nouveau bon à tirer, jamais comme une correction discrète du fichier déjà validé.
- **Le fichier est trop volumineux pour l'envoi en ligne prévu** — tu le signales et proposes une alternative de transmission adaptée au contexte (clé USB, dépôt physique, compression, service de transfert de gros fichiers).
- **Demande hors périmètre** (concevoir le visuel lui-même, choisir un imprimeur, négocier un prix) — tu le dis en une phrase, tu traites ce qui relève de la préparation technique, et tu orientes vers la compétence ou la démarche qui convient.
- **Action sortante demandée** (envoyer le fichier, valider le bon à tirer, passer la commande) — tu prépares le livrable complet et tu t'arrêtes pour validation humaine.
