---
id: Y0012
name: 01-mur-des-comparables
description: "Construit un mur visuel des comparables pour chaque startup du portefeuille de l'entreprise : capture les interfaces produits des concurrents (mobile, web, backoffice) et les range comme fichiers .png physiques dans le stockage de la startup."
bucket: D
tags: [Sourcing]
version: 1
maj: 2026-08-10
---

# 01-Mur des comparables

## Ce qu'il faut avoir sous la main
- **périmètre** : les 9 startups, une startup précise, ou « ajoute [COMPARABLE] à [STARTUP] »
- **mode** : run complet ou mise à jour (ne capturer que les .png manquants)


> Conçu à l'origine pour un rafraîchissement automatique trimestriel ; ici, **lancé à l'invocation** (le mode « mise à jour » ne recapture que les fichiers absents).


**Ce qu'elle suppose comme accès** : Liste officielle des comparables par startup, Stockage documentaire, État d'exécution, Capture d'écran web, Scraping App Store / Google Play, Recherche web, Programmation de posts. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### PHASE 1 — Collecte des comparables
1.1 Source de vérité = `[datasource à brancher : liste officielle des comparables par startup]`. Elle fait foi.
1.2 Structurer en JSON par startup : `{nom, site, play_store_id, app_store_id, backoffice_url, notes}`. Extraire les App IDs des liens Play (`?id=`) et App Store (`/app/…/idXXXX`). Consulter la table App IDs connus avant toute recherche.
1.3 Vérifier : 9 startups couvertes, ≥ 3 comparables chacune ; sinon rechercher « [STARTUP] [SECTEUR] comparable competitor Africa ».

### PHASE 2 — Capture & upload (startup par startup, comparable par comparable)
Après CHAQUE capture réussie, uploader **immédiatement** le .png dans le bon dossier.
- **2.0 Anti-doublon** : lister les fichiers existants ; `[COMP]_[type].png` présent → SKIP.
- **2A App Store & Play** : `details` (appIds connus) ou `search` (nom+secteur) ; télécharger chaque URL CDN → `[COMP]_playstore_01.png` / `[COMP]_appstore_01.png`.
- **2B Landing desktop** : full-page 1440×900 → `[COMP]_landing_desktop.png`.
- **2C Landing mobile** : full-page 390×844 → `[COMP]_landing_mobile.png`.
- **2D Backoffice/dashboard + interfaces réelles** : si `backoffice_url` null, rechercher « [COMP] dashboard / product tour / demo » ; capturer `/features` ou `/product` sinon. Chercher ≥ 2 interfaces réelles (LinkedIn, YouTube demo/walkthrough, X, Product Hunt, G2, Capterra, blog) → `[COMP]_backoffice_01.png`, `[COMP]_interface_real_01.png`.
- **2E Log** : `[COMP] | Play:✅/❌ | App Store:✅/❌ | Landing Desktop:✅/❌ | Landing Mobile:✅/❌ | Backoffice:✅/❌`.

**Filtrage obligatoire avant upload** : si la capture est une page 404/erreur/blanche → NE PAS uploader, logger ❌. Ne conserver que les écrans utiles (app mobile, landing, backoffice/dashboard).

### PHASE 3 — Organisation dans le stockage
`Mur_des_comparables/[Startup]/` → `.png`. Vérifier l'appartenance startup avant chaque upload. Collision de nom → suffixe `_v2`, `_v3`. Dossiers en PascalCase sans accents/espaces ; fichiers `[COMP]_[type]_[NN].png` (types : `playstore`, `appstore`, `landing_desktop`, `landing_mobile`, `backoffice`, `features`).

### PHASE 4 — Log final
Tableau récap : nombre de .png par startup + erreurs/manquants avec raison. Aucun fichier rapport/index créé.

### Standard qualité — sourcing/comparables

1. Activer capture web + scraping stores + recherche web par défaut : **vérifier avant d'écrire**, jamais deviner de mémoire.
2. Enchaîner aux skills amont/aval du pipeline (récupérer l'output amont, passer le relais) plutôt que copier-coller manuel.
3. **Zéro invention** : jamais un chiffre/nom/site/lien/score sans source → « n.d. »/vide/« à confirmer ». Case vide > donnée fausse.
4. **Données reçues d'abord** : partir de l'input vérifiable.
5. **Date + source** sur chaque chiffre ; signaler si > 18 mois.
6. **Pertinence au critère** : entité hors catégorie → « hors-cible ».
7. **Dédoublonner** (rebrand, filiale, produit vs société = 1 entité).
8. **Géo & identité exactes** (siège, homonymes), double-source si possible.
9. **Statut opérationnel** : actif / racheté / mort-absorbé ; jamais traiter une boîte morte comme vivante.
10. **Pas de livrable fantôme** : ne jamais prétendre avoir produit une image/fichier non réellement généré.
11. **Signaler les incertitudes**.

## Format de sortie
- **Livrable** : le livrable produit par « 01-Mur des comparables ».
- **Structure** : Markdown clair — titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] » — jamais présentée comme réelle.

## Règles
Chaque screenshot doit être **téléchargé et uploadé physiquement comme fichier .png** dans le dossier de la startup concernée. Interdit de stocker un lien URL à la place d'un fichier. Aucun rapport, aucun index, aucune liste de liens — uniquement des .png.

**MINIMUM 5 CAPTURES PAR COMPARABLE (non négociable)** : landing desktop (viewport), landing desktop full-page, landing mobile (390px), page pricing/fonctionnalités, screenshots app mobile (Play/App Store), backoffice/dashboard si accessible. Captures échouées → tenter des alternatives pour atteindre 5.

**ZÉRO DOUBLON** : avant chaque capture, vérifier que le fichier n'existe pas déjà (nom ou URL source). S'il existe → ne pas recapturer.

### Règles de comportement

1. Séquence des 4 phases, sans saut.
2. Startup par startup, complète avant la suivante.
3. Résilience : une capture échouée n'arrête jamais le run (log + continue).
4. Pas de doublon.
5. `fullPage: true` obligatoire sur toutes les captures.
6. Upload immédiat, pas en batch.
7. Parallélisme intelligent (captures + scraper stores en parallèle), upload séquentiel par startup.
8. Fallback de capture systématique.
9. Logging continu ✅/⚠️/❌.
10. App IDs connus en priorité ; jamais une URL CDN sans .png physique uploadé.
11. Filtrage des captures inutiles (404/erreur/blanc) obligatoire.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Portefeuille de l'entreprise — startups actives (9)

1. **Startup 1** — agritech / farm-to-table B2B
2. **Startup 2** — earned wage access / payroll
3. **Startup 3** — KYC / compliance / identité
4. **Startup 4** — financement B2B marchands
5. **Startup 5** — mobilité / financement VTC
6. **Startup 6** — construction / matériaux BTP Afrique
7. **Startup 7** — fintech / agency banking Mobile Money
8. **Startup 8** — fintech / paiement, agrégateur Mobile Money
9. **Startup 9** — économie circulaire, smartphones & ordinateurs reconditionnés

### App IDs connus (réutiliser en priorité)

Startup 8→Nomba `com.nomba.business` · Startup 2→Floatpays `com.floatpays`/`id1488315695`, Paymenow `com.paymenowgroup.app`/`id6443698868` · Startup 4→Zanifu `zanifultd.kioko.com` · Startup 5→Moove `io.moove.app` · Startup 6→Jumba `com.jumba.custmobile` · Startup 7→OPay `team.opay.pay`/`id1463776084` · Startup 9→Back Market `com.backmarket`/`id1458344336`, Cashify `com.reglobe.cashify` · Startup 3→iDenfy `com.idenfy.idenfyApp`.
