---
id: Y0408
name: declinaison-multiformat
description: "Transforme un visuel principal en tout le jeu de formats dont l'entreprise a besoin — carrés, verticaux, horizontaux, bannière, vignette, impression, affichage de rue, écran de point de vente — en redessinant plutôt qu'en recadrant, pour que le message survive au changement de taille. Livre la matrice des formats, les fichiers nommés et la hiérarchie visuelle documentée, sans jamais inventer une dimension, un poids limite ou une spécification de plateforme non fournie."
bucket: B
tags: [Design, Production, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Décliner un visuel — un message, tous les formats, sans le casser

## Ce qu'il faut avoir sous la main
- **Le visuel principal** : le fichier source, ou une description précise s'il n'est pas encore fait (composition, texte incrusté, logo, couleurs).
- **Le message central** qu'il doit porter — la phrase qu'on doit retenir même si on ne voit le visuel qu'une seconde.
- **La liste des formats et supports** demandés, avec leur usage réel : où seront-ils vus, sur quel appareil, dans quel contexte (fil qu'on défile, affiche fixe, écran de caisse, bannière de site).
- **La charte graphique** applicable : logo, couleurs, typographies, marges minimales, si elle existe.
- **Les spécifications connues** (dimensions, poids maximal, zone de sécurité) pour chaque support, si tu les as déjà — sinon je les marque à vérifier plutôt que de les supposer.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Établir la hiérarchie du visuel

Avant de décliner quoi que ce soit, décompose le visuel principal en couches de priorité : ce qui **doit survivre** à toutes les tailles (le message central, le logo, l'élément qui identifie la marque en une fraction de seconde), ce qui **peut se réduire** (illustration secondaire, mention légale, détail décoratif), et ce qui **peut disparaître** sans que le message change (fond, ornement, texte de contexte).

Si tu ne peux pas répondre à « qu'est-ce qui doit rester si je n'ai droit qu'à un carré de deux centimètres » sans hésiter, la hiérarchie n'est pas encore claire — et c'est elle qui doit se stabiliser avant toute déclinaison, pas l'inverse. Documente cette hiérarchie explicitement : c'est une pièce du livrable, pas une étape invisible de ton raisonnement.

### Étape 2 — Cadrer la liste des formats par leur usage réel, pas par leur nom

Un « format Instagram » ne veut rien dire tant qu'on ne sait pas s'il s'agit d'une publication au fil, d'une story, d'une image de couverture ou d'une vignette de miniature — chacun a un usage, un temps de visionnage et une zone masquée différents. Pour chaque format demandé, établis : où il est vu, sur quel type d'appareil, combien de temps il capte l'attention, et ce qui le recouvre à l'écran.

Les dimensions exactes, le poids maximal accepté et la zone de sécurité de chaque support sont des **spécifications techniques qui changent** — une plateforme modifie ses formats sans préavis, un imprimeur a ses propres marges de coupe. Tu ne les récites pas de mémoire : tu les demandes ou tu les vérifies auprès d'une source à jour fournie par l'équipe. Une spécification non confirmée reste `⟦à renseigner⟧` dans la matrice, jamais complétée par une valeur plausible.

### Étape 3 — Redessiner, format par format

Pour chaque format, recompose à partir de la hiérarchie de l'étape 1 : réorganise les éléments qui doivent survivre pour qu'ils occupent l'espace disponible correctement, plutôt que de couper le cadre source. Un visuel horizontal qui devient vertical n'est pas le même visuel recadré en hauteur — c'est une nouvelle composition qui porte le même message avec les mêmes éléments réorganisés.

Le texte incrusté se retravaille à chaque format : sa taille, sa longueur et parfois sa formulation changent selon l'espace disponible. Un texte qui tient sur trois lignes en bannière peut avoir besoin d'être raccourci à une phrase en vignette. Ne fige jamais le texte source comme une contrainte — c'est le message qui est fixe, pas sa mise en mots exacte.

### Étape 4 — Vérifier à la taille réelle d'affichage

Le piège le plus fréquent : valider un visuel en le regardant en plein écran sur un ordinateur, alors qu'il sera vu sur un téléphone dans un fil qu'on fait défiler en une fraction de seconde. Un texte lisible en pleine page peut devenir un bloc gris illisible sur un écran de six pouces, surtout sur un appareil d'entrée de gamme dont l'écran est moins net et moins lumineux.

Vérifie chaque format à sa taille d'affichage réelle — vignette réduite à la taille d'une vignette, bannière regardée à la largeur d'un écran de téléphone moyen, affiche projetée mentalement à la distance depuis laquelle elle sera lue dans la rue. Si un élément devient illisible à cette taille, il remonte dans la hiérarchie ou il grossit — il ne reste jamais tel quel au nom de la fidélité au visuel source.

### Étape 5 — Repérer les zones masquées par l'interface

Chaque support a des zones où quelque chose se superpose à l'image sans que le visuel les contrôle : bandeau de titre, avatar de profil, boutons d'action, sous-titres, cadre de découpe d'un support imprimé. Un élément important placé dans une de ces zones disparaît — pas dans l'aperçu, mais dans l'usage réel.

Ces zones de sécurité ne se devinent pas de mémoire : elles se demandent à l'équipe si elles sont documentées, ou se vérifient directement sur le support réel (l'application, le gabarit d'impression, l'écran de caisse) avant validation finale. Tant qu'elles ne sont pas confirmées, le fichier porte une zone de sécurité indicative marquée comme telle, pas une certitude.

### Étape 6 — Exporter au poids adapté à l'usage

Un visuel trop lourd ralentit une page, échoue à charger sur une connexion instable, et coûte de la donnée à quelqu'un qui paie son forfait au volume — dans un contexte où une partie significative de l'audience navigue avec un forfait limité, un visuel trop lourd n'est simplement jamais vu. Chaque format s'exporte à un poids cible cohérent avec son usage : léger pour un contenu vu au défilement, plus généreux pour un support d'impression qui exige la netteté.

Le poids cible exact par usage est une décision de l'équipe ou une contrainte de la plateforme — tu ne l'inventes pas, tu la demandes ou tu la marques `⟦à renseigner⟧` dans la matrice, puis tu compresses jusqu'à l'atteindre sans dégrader la lisibilité du texte incrusté vérifiée à l'étape 4.

### Étape 7 — Nommer et livrer

Le nommage fait partie du livrable, pas de l'intendance : un fichier appelé selon une convention claire (support, format, date ou version) permet à n'importe qui dans l'équipe de retrouver le bon fichier sans ouvrir chaque image. Établis la convention avec l'équipe si elle n'existe pas déjà, applique-la à l'identique sur tous les fichiers du jeu, et documente-la en tête de la matrice.

## Format de sortie
- **Livrable** : le jeu complet de déclinaisons — la matrice format par format (support, usage, dimensions, zone de sécurité, poids cible, statut de vérification), les fichiers exportés et nommés selon la convention retenue, la hiérarchie du visuel documentée (ce qui survit, ce qui se réduit, ce qui saute), et la liste des vérifications faites à la taille réelle d'affichage.
- **Structure** : Markdown clair pour la matrice et la documentation — answer-first (la matrice et les fichiers livrés d'abord, le détail des choix ensuite) ; tableau pour la matrice des formats.
- **Longueur** : proportionnée au nombre de formats demandés, sans remplissage.
- **Les spécifications techniques sont un input**, pas une production : dimensions exactes, poids maximal, zone de sécurité restent `⟦à renseigner⟧` tant qu'elles ne sont pas fournies ou vérifiées sur une source à jour.
- **Règle 0 invention** : aucune dimension, aucun poids limite, aucune spécification de plateforme inventée de mémoire. Si une information manque, la demander ou la marquer `[à confirmer]`.

## Règles
1. **On redessine, on ne recadre pas.** Chaque format est une composition reconstruite à partir de la hiérarchie du visuel, pas un découpage mécanique du fichier source. Un format livré par simple recadrage n'est pas un livrable terminé.
2. **0 spécification inventée.** Dimensions, poids maximal, zone de sécurité d'un support ne sont jamais récités de mémoire — ce sont des données qui changent. Elles viennent d'une source fournie ou vérifiée, sinon elles restent `⟦à renseigner⟧`.
3. **Le texte se vérifie à la taille réelle d'affichage**, pas en pleine page. Un format validé uniquement en grand format n'est pas validé.
4. **Les zones masquées se vérifient, ne se devinent pas.** Un élément important placé dans une zone d'interface non confirmée est un risque signalé, pas une supposition passée sous silence.
5. **Le poids du fichier fait partie du message.** Une image qui ne charge pas n'est jamais vue — le poids cible est traité comme une contrainte de conception, pas comme une étape de compression en fin de course.
6. **Le nommage est un livrable, pas une intendance.** Une convention de nommage cohérente et documentée accompagne tout jeu de fichiers, quelle que soit sa taille.
7. **Le contexte réel d'usage n'est pas un décor.** Écran d'entrée de gamme, connexion limitée, distance de lecture d'une affiche de rue, luminosité d'un écran de point de vente en plein jour : un visuel pensé pour un contexte idéal ne se transpose pas tel quel à un autre.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un jeu de fichiers de travail ; publier, diffuser, imprimer en série ou envoyer à un prestataire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une marque ou d'un projet ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Visuel source manquant ou incomplet** — tu travailles sur ce qui est décrit, tu étiquettes tes hypothèses de composition (`[hypothèse : …]`), et tu signales ce qui devra être vérifié une fois le fichier réel disponible.
- **Spécification de plateforme inconnue ou potentiellement obsolète** — tu ne la complètes jamais de mémoire ; tu la marques `⟦à renseigner⟧` et tu proposes le format sur une base standard signalée comme provisoire.
- **Texte imposé trop long pour rester lisible en petit format** — tu le signales explicitement plutôt que de le rétrécir jusqu'à l'illisible ; tu proposes une version raccourcie et tu demandes l'arbitrage sur le message à privilégier.
- **Contraintes de charte graphique contradictoires avec la lisibilité** (couleur imposée peu contrastée, logo trop petit imposé) — tu signales le conflit, tu ne tranches pas seul entre respect de la charte et lisibilité.
- **Zone de sécurité non documentée pour un support donné** — tu le dis, tu proposes une zone de sécurité indicative marquée comme telle, et tu recommandes une vérification sur le support réel avant diffusion.
- **Poids cible inatteignable sans perte de qualité visible** — tu le signales, tu livres la meilleure version obtenue avec le poids atteint noté, et tu laisses l'équipe trancher entre poids et qualité.
- **Format demandé qui n'existe plus ou a changé de spécification** — tu le dis explicitement plutôt que de produire sur une base périmée.
- **Demande de publication, d'impression en série ou d'envoi à un prestataire externe** — tu prépares les fichiers et tu t'arrêtes pour validation humaine.
- **Connecteur de gestion de marque (DAM, bibliothèque de charte) inaccessible** — tu signales le trou, tu travailles avec les éléments fournis directement, et tu ne fabriques jamais un logo ou une couleur de charte de mémoire.
