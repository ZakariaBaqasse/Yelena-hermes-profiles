---
id: Y0686
name: etiquette-et-packaging
description: "Conçoit l'étiquette ou l'emballage d'un produit à partir du gabarit de découpe fourni par le fabricant ou l'imprimeur, de la charte graphique et de la liste des mentions que l'entreprise fournit : face avant en trois directions créatives affirmées (contrôle avant remise OBLIGATOIRE : jamais trois emballages standards qui ne diffèrent que par la couleur) tranchée par un choix A/B, faces d'information hiérarchisées, contrôle de lisibilité imprimé à l'échelle un, codes testés avec un lecteur avant livraison, système de déclinaison pour une gamme, puis fichier d'impression prêt au profil de l'imprimeur (fond perdu, traits de coupe, finitions séparées) sans jamais inventer une mention réglementaire, un seuil technique ou une cote."
bucket: B
tags: [Design, Produit, Nouveau]
version: 2
maj: 2026-09-23
---

# L'étiquette et le packaging, un produit qui se reconnaît en rayon

## ⛔ Contrôle avant remise des pistes : pas d'emballage standard (23/09/2026)

Constat de séance : des emballages « normaux », qui posent la charte sur une forme courante
sans parti pris. Un designer reste créatif, et c'est à lui de proposer. Avant d'envoyer les
pistes, tu vérifies que :

1. chaque piste porte une idée nommée en une phrase (ce qu'elle raconte, pourquoi on la
   remarque en rayon), pas seulement une palette appliquée ;
2. au moins une piste joue sur autre chose que la surface imprimée : la forme, l'ouverture, la
   matière, une découpe, une fenêtre sur le produit, un geste que les emballages relevés du
   secteur n'ont pas. Sa faisabilité se vérifie ensuite avec le fabricant, elle ne se promet pas ;
3. au moins une piste est une rupture assumée, dite comme telle, à côté d'une piste plus sage ;
4. posée à côté des emballages concurrents relevés, aucune piste ne se confond avec eux ;
5. un emballage vierge de banque d'images sert au plus à présenter une piste, il n'en tient
   pas lieu.

Trois pistes qui ne diffèrent que par la couleur ou la place du logo : tu ne remets pas.

## Ce qu'il faut avoir sous la main
- **Le produit** : ce que c'est, où il se vend (rayon de supermarché, boutique de quartier, marché ouvert), et son contenant (bouteille, sachet, boîte, pot).
- **Le gabarit de découpe** fourni par le fabricant du contenant ou par l'imprimeur retenu, ou à défaut les cotes exactes prises sur l'objet réel.
- **La charte graphique** de la marque, si elle existe déjà : logo, couleurs, typographies.
- **La liste des mentions** à faire figurer, telle que ton équipe la fournit : nom, contenance, composition, origine, lot, date, codes, mentions légales.
- **Les spécifications de l'imprimeur retenu**, si tu les as déjà : profil couleur, finitions disponibles (vernis, dorure), format de fichier accepté.
- **Pour une gamme** : les autres produits qui partagent ce gabarit, et ce qui doit les distinguer entre eux.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) ; tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake partiel suffit pour démarrer. Un intake complet reste l'idéal.

## Process
### Étape 1 : Le gabarit, avant le premier trait

Ce qu'on cherche : un gabarit de découpe réel, celui du fabricant du contenant ou de l'imprimeur retenu, avec ses cotes exactes ; pour un contenant courbe (bouteille, pot, sachet souple), les zones où le texte se déforme (le raccord de l'étiquette, le pli du bouchon, la couture du sachet) ; pour une boîte, les traits de pliage et les rabats de collage. Un gabarit fourni en PDF ou en fichier vectoriel vaut mieux qu'une description à l'oral, mais des cotes exactes prises directement sur l'objet réel suffisent à démarrer si aucun fichier n'existe encore.

Le signal qui trahit un problème : une dimension donnée « de mémoire », sans mesure prise sur le contenant réel, ou un gabarit « standard » dont personne ne sait s'il correspond au contenant réellement commandé. Dans ce cas tu marques le livrable **provisoire** et tu poses la question qui débloque : à qui appartient ce contenant, qui peut en extraire le gabarit exact.

Un imprimeur local a en général son propre format de bobine ou de feuille et ses propres gabarits types pour les contenants qu'il produit déjà : demander directement le gabarit à l'imprimeur retenu, plutôt qu'à un fournisseur générique en ligne, évite de tout redessiner une fois le format réel connu.

### Étape 2 : La liste des mentions, et ce qui n'en relève pas

L'entreprise fournit la liste des mentions à faire figurer : nom du produit, contenance, composition, origine, numéro de lot, date, codes, éventuelles mentions légales propres à l'entreprise (par exemple un numéro d'immatriculation, harmonisé dans la zone OHADA, si l'entreprise en fournit un). Tu la ranges en deux blocs : ce que l'entreprise déclare obligatoire, et ce qui relève du marketing (accroche, promesse, slogan).

Le piège classique : inventer ou recopier d'un produit voisin une mention qui manque, parce qu'elle « doit sûrement exister ». Tu ne sais pas ce qui est réellement obligatoire pour ce produit, dans ce secteur, dans ce pays. Tu le dis en une ligne, et tu renvoies vers la personne responsable de la conformité pour trancher ce qui manque, sans jamais remplir la case à sa place.

Si l'origine ou le numéro de lot viennent d'un fournisseur informel (sans facture ni système de lot en place), la traçabilité affichée sur l'étiquette est bornée par ce que l'entreprise suit elle-même en interne : tu poses la question de comment elle compte tracer ses lots. Un système qui n'existe pas ne se présuppose pas.

### Étape 3 : La face avant, en trois pistes

Même logique que `du-brief-au-rendu-design` : trois pistes distinctes, soumises au contrôle en tête de cette compétence. Trois variantes du même parti pris ne suffisent pas. Ce qui les distingue : la manière de gagner cette seconde d'attention (par le nom, par un visuel fort, par une promesse courte). La couleur du fond ne les distingue pas.

Le piège du métier : une face avant bavarde. Le produit se voit une seconde, au milieu d'un mur de produits concurrents serrés sur une étagère de boutique ou un étal de marché en plein soleil. Un éclairage de studio isolé ne reproduit pas ces conditions. Le signal qui trahit le problème : une piste qui empile trop de messages à la fois, nom, promesse, visuel, puis encore autre chose. Passé ce point, l'œil ne fixe plus rien. Un test simple : réduis la piste à une taille minuscule à l'écran ; si le nom ne se détache plus du fond, il ne se détachera pas non plus en rayon.

Dans un marché où une partie du public lit peu, ou lit une langue différente du français à l'écrit, un visuel ou un pictogramme fort porte souvent plus qu'une ligne de texte supplémentaire : c'est un argument pour la piste qui mise sur l'image. Une case à cocher automatique ne remplace pas ce choix.

### Étape 4 : Le choix A/B, et ce qui se verrouille

Les trois pistes se resserrent à deux finalistes que tu présentes côte à côte, à la même échelle, dans le même contexte visuel, idéalement collées sur le gabarit. Un fond blanc isolé ne restitue pas ce contexte. Le choix appartient à l'entreprise : tu poses l'écart entre les deux options, ce que chacune gagne, ce que chacune perd. Trancher à sa place ne t'appartient pas.

Une fois la piste retenue, elle se verrouille : nom, position du logo, hiérarchie des éléments. Tout changement après ce point remonte le reste du travail (faces d'information, système de déclinaison), donc un choix qui revient sur la table après avoir été validé est un signal qu'il faut reposer la question avant d'aller plus loin. Continuer en espérant que ça se stabilise tout seul n'est pas une option.

### Étape 5 : Les faces d'information, la hiérarchie de ce qui n'est pas en face avant

Composition, mode d'emploi, mentions légales, code, contact : tout ce qui n'a pas trouvé sa place en face avant se range sur les autres faces, mais pas au hasard. Ce qu'on cherche : ce que le client cherche en premier quand il retourne le produit dans sa main (souvent le mode d'emploi ou ce qu'il contient), puis ce qu'il cherche seulement s'il a un doute ou une réclamation (contact, lot, date).

Le signal d'un problème : une face arrière qui reprend toutes les mentions dans l'ordre où elles ont été listées, sans hiérarchie de lecture. Une liste de mentions n'est pas une mise en page.

### Étape 6 : Les codes, testés avant d'être livrés

Un code-barres ou un QR garde la taille minimale et la zone blanche que le standard du code, ou le fournisseur du code, impose : ces cotes sont `⟦à renseigner⟧` tant que l'imprimeur ou le fournisseur ne les a pas données, jamais estimées à l'œil.

Le piège : un code posé trop petit, sans marge, ou sur un fond ou un vernis qui casse le contraste. Tu le testes avec un lecteur réel avant de livrer, si possible avec un téléphone d'entrée de gamme, dans une lumière ordinaire de boutique. L'éclairage parfait d'un bureau ne suffit pas : c'est l'appareil et la lumière que rencontrera le client. Des conditions idéales ne remplacent pas cette réalité.

Si le code pointe vers une page en ligne, garde la destination légère : une connexion coûte de l'argent au client qui scanne, et une page lourde à charger décourage le scan suivant. Un lien vers une conversation WhatsApp charge souvent plus vite et plus sûrement qu'un site complet, dans ce contexte.

### Étape 7 : Le contrôle à l'échelle un

Une maquette se contrôle imprimée à sa taille réelle. Un agrandissement à l'écran ne permet jamais ce contrôle. Le piège : un texte parfaitement lisible sur un moniteur de bureau devient un filet gris illisible une fois réduit à la hauteur réelle d'une étiquette. Tu imprimes la maquette à l'échelle un, tu la regardes à la distance à laquelle un client la regarde réellement, à bout de bras, et sous une lumière franche. Une maquette collée à l'œil sous un plafonnier tamisé ne restitue ni cette distance ni cette lumière.

Quand le format le permet, tu poses aussi un aperçu en volume ; à défaut, tu découpes et plies la maquette à plat à la main sur le gabarit réel. Une mise en page juste à plat peut se révéler fausse une fois courbée sur une bouteille (un mot coupé par le raccord) ou pliée en boîte (un visuel amputé par une arête).

### Étape 8 : Le fichier d'impression, prêt pour l'imprimeur réel

Le fichier repart par le protocole de `preparation-fichiers-impression` : profil couleur demandé par l'imprimeur, couleurs de la charte converties et vérifiées, fond perdu, traits de coupe, finitions (vernis, dorure) posées sur des calques séparés. Le piège à ne jamais reproduire : un fichier resté en RVB, dont les couleurs virent une fois sur presse.

Un aller-retour physique avec l'imprimeur prend du temps, entre les distances et la circulation d'Abidjan : mieux vaut viser un échange décisif, une épreuve numérique conforme puis une seule épreuve physique de contrôle, que plusieurs allers-retours d'essai-erreur qui font tourner le calendrier sans le faire avancer.

Avant de lancer un tirage en volume, vérifie aussi avec l'entreprise si le nom et le logo retenus sont protégés : l'OAPI a la charge de la protection des marques et des dessins dans la zone. Une fois des milliers d'étiquettes sorties de presse sous un nom pas encore sécurisé, l'erreur ne se rattrape plus.

### Étape 9 : Le système de déclinaison, pour une gamme

Quand plusieurs produits partagent le même gabarit, tu ne dessines pas une maquette par produit isolément : tu poses un système, ce qui change d'un produit à l'autre (couleur dominante, nom, visuel) et ce qui reste fixe (structure, position des mentions, logo). C'est ce système qui fait qu'un client reconnaît la gamme comme une famille en un coup d'œil, sur une étagère de kiosque dense et serrée comme sur un rayon plus spacieux.

Pour une édition limitée ou saisonnière au sein d'une gamme déjà établie, le système précise aussi ce qu'une variante temporaire a le droit de changer sans casser la reconnaissance de la famille au retour à la version courante.

## Format de sortie
- **Livrable** : la face avant en trois pistes, puis la piste retenue après le choix A/B ; la maquette à plat de toutes les faces posée sur le gabarit de découpe ; un aperçu en volume quand le format le permet ; la maquette à l'échelle un, prête à imprimer pour contrôle ; la liste de contrôle des mentions (chaque mention fournie, sa place, sa taille de police) ; le fichier d'impression final (PDF au profil de l'imprimeur, fond perdu, traits de coupe, finitions séparées).
- **Pour une gamme** : le système de déclinaison en une page, ce qui varie d'un produit à l'autre et ce qui reste fixe.
- **Message de livraison** : les liens vers les fichiers, l'application utilisée pour la maquette, et la liste de ce qui reste à confirmer par la personne en charge de la conformité avant impression.
- **Structure** : Markdown pour le raisonnement et les listes de contrôle ; fichiers visuels et fichier d'impression livrés en pièces jointes, nommés et versionnés.
- **Longueur** : proportionnée au support ; une étiquette simple ne demande pas le développement d'un emballage à quatre faces couplé à une gamme.
- **Les cotes techniques sont un input. Elles ne se produisent pas en interne** : taille minimale d'un code, valeur du fond perdu, résolution demandée par l'imprimeur restent `⟦à renseigner⟧` tant qu'elles ne sont pas données par l'imprimeur ou le fournisseur du code.
- **Règle 0 invention** : aucune mention réglementaire ni cote technique non fournie n'est ajoutée d'initiative. Si une information manque, elle est demandée ou marquée `[à confirmer]`.

## Règles
1. **Le gabarit prime sur tout.** Aucun trait avant d'avoir le gabarit de découpe réel ou des cotes exactes ; sans lui, le livrable reste provisoire et le dit explicitement.
2. **La face avant se gagne en une seconde.** Nom, promesse, un visuel : au-delà, tu es en train de perdre le regard du client plutôt que de le capter.
3. **Les mentions réglementaires ne s'inventent jamais.** Tu poses ce que l'entreprise fournit, tu signales ce qui manque, et tu renvoies systématiquement la décision vers la personne responsable de la conformité pour ce produit, dans ce pays.
4. **Le contrôle se fait imprimé, à l'échelle un.** Un écran agrandi ment sur la lisibilité réelle d'une étiquette ; seule une impression à taille réelle, regardée à la bonne distance, tranche.
5. **Le fichier d'impression part au profil de l'imprimeur, jamais en RVB.** Fond perdu, traits de coupe et finitions séparées suivent le protocole de `preparation-fichiers-impression`.
6. **Un code se teste avant de partir.** Taille minimale et zone blanche `⟦à renseigner⟧` par le standard du code ou par l'imprimeur, puis vérification avec un lecteur réel, dans une lumière ordinaire. Un éclairage de bureau ne suffit pas à ce test.
7. **Une gamme est un système. Une collection de maquettes isolées ne fait pas système.** Ce qui varie et ce qui reste fixe se posent ensemble, dès le premier produit de la famille.
8. **Le contexte local n'est pas un décor.** Lisibilité en plein soleil au milieu d'un mur de produits concurrents, tenue physique pendant le transport et la manipulation, coût d'une connexion pour un client qui scanne un code : un packaging pensé pour une étagère climatisée occidentale ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucune mention réglementaire, aucune cote technique, aucun taux ou seuil fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais une cote ou une mention comme « fournie par l'imprimeur » ou « exigée par la loi » sans que ce soit réellement le cas. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un fichier de travail ; envoyer le fichier à l'imprimeur, lancer un tirage ou engager une dépense d'impression est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un produit ou d'une marque ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Gabarit absent** : tu travailles sur les cotes exactes si elles sont données, tu marques le livrable **provisoire**, et tu poses la question qui débloque (à qui appartient le contenant, qui peut en extraire le gabarit).
- **Charte graphique absente** : tu proposes les trois pistes de la face avant en posant des hypothèses de couleurs et de typographies (`[hypothèse : …]`), sans jamais les faire passer pour une charte validée.
- **Liste de mentions incomplète** : tu produis avec ce qui est fourni, tu marques les manques `[à confirmer]`, et tu renvoies vers la personne responsable de la conformité plutôt que de compléter à sa place.
- **Refonte d'une étiquette existante** : tu pars de l'existant pour identifier ce qui porte la reconnaissance du produit en rayon (couleur, forme du logo, position) et ce qui peut changer sans perdre le client qui le reconnaît déjà.
- **Fichier fourni par l'imprimeur illisible ou incompatible** : tu le signales avant de continuer et tu demandes le format attendu, plutôt que de deviner les cotes qu'il contient.
- **Gamme sans gabarit commun** : tu traites chaque produit séparément et tu le dis ; un système de déclinaison suppose une structure partagée, tu ne le forces pas sur des formats différents.
- **Action sortante demandée** (envoyer le fichier à l'imprimeur, lancer un tirage, publier un visuel) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions de charte, deux gabarits différents pour le même produit) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (refonte complète de l'identité de marque, création du logo) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers `du-brief-au-rendu-design`.

## Historique

- v2, 23/09/2026 : contrôle avant remise obligatoire en tête (une idée nommée par piste, une
  piste qui joue sur la forme ou la matière, une rupture assumée, aucune piste confondue avec
  les concurrents, l'emballage de banque d'images n'est pas une direction), séance Sync agents
  training.
