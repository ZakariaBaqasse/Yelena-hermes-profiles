---
name: ecrans-stitch-vers-page-cliquable
description: "Produire des écrans d'application avec Google Stitch et les livrer en page cliquable publiée, quand Figma est en lecture seule et UXPilot absent. Pièges de l'API Stitch, corrections obligatoires de ce que Stitch invente, gel des écrans pour la CSP du service de pages (pas de Tailwind CDN, pas de polices, pas de Material Symbols). Contrôle avant remise OBLIGATOIRE : le parcours complet, cliquable de bout en bout, jamais un à trois écrans isolés. Appris le 22/09/2026 sur un dossier client."
version: 2
maj: 2026-09-23
---

# Écrans Stitch → page cliquable publiée

## ⛔ Contrôle avant remise : le parcours complet (23/09/2026)

Constat de la séance : parfois un écran, parfois trois, alors qu'une application en compte
bien plus. La maquette se parcourt comme un prototype d'outil de maquette : on y entre, on va
au bout, on revient.

**Avant de générer**, tu écris l'inventaire du parcours (étapes 1 et 2 de `script-ecrans`) :
du déclencheur au résultat, avec les écrans d'entrée et de retour, et les états qui comptent
(chargement, erreur, confirmation). Si la demande fixe un nombre d'écrans, tu le respectes, et
tu dis en une ligne quels écrans manquent pour que le parcours soit complet, proposés en A/B/C.

**Avant d'envoyer**, tu vérifies que :
1. l'inventaire est dans la remise, chaque écran livré ou marqué « hors de ce lot » ;
2. chaque élément qui a l'air cliquable mène à un écran livré, ou se voit inactif : aucun bouton
   mort sans le dire ;
3. le parcours se fait de bout en bout sur l'adresse servie, par un clic réel, à 390 px, retour
   compris ;
4. le parcours principal porte au moins un état d'erreur et son écran de confirmation ;
5. une vue d'ensemble montre tous les écrans côte à côte.

Un à trois écrans sans parcours autour : tu ne remets pas, tu complètes.

## Quand
Une demande d'écrans d'application « sur Figma ou UXPilot » avec lien. Figma n'est ouvert qu'en
lecture, UXPilot n'est pas branché : Stitch est le troisième outil de la règle 5 (21/09), et on le
dit à la personne dans le message de livraison, avec l'outil réellement utilisé.

## Process (une heure pour six écrans)
1. **Style commun** dans un fichier (`style.txt`) : couleurs de la charte en hexa, polices, rayons,
   registre (vouvoiement), « toute personne montrée est noire », « aucun frais, taux ni condition ».
   Il est préfixé à chaque prompt.
2. `stitch.sh tool create_project -d '{"title":"…"}' --accord` (l'accord = la demande écrite d'une
   personne identifiée ; aucun tarif documenté).
3. Par écran : `generate_screen_from_text -f s.json --accord`, JSON `{"projectId","deviceType":"MOBILE",
   "designSystem":"assets/<id du premier écran>","prompt"}`. ⚠ `deviceType` en MAJUSCULES sinon
   « invalid argument ». Un écran prend 1 à 2 min ; « service unavailable » se relance une fois.
4. Récupérer le code : parfois dans la réponse (`outputComponents[0].design.screens[0].htmlCode.downloadUrl`),
   sinon `get_screen -d '{"name":"projects/<p>/screens/<id>"}'` après 30 à 60 s. `list_screens` répond
   `{}` : ne pas s'y fier. Un prompt qui insiste sur une photo produit un écran `IMAGE` (1024×1024) :
   reformuler « a full mobile UI screen (not an image) ».
5. **Rendre soi-même** à 390×844 (Playwright, `shotfull.js`) : la capture Stitch est une vignette.
6. **Corriger ce que Stitch invente**, toujours les mêmes : slogans de classement (« N°1 »), variations
   chiffrées (« +12,4 % »), gammes de carte (« Platinum »), compatibilités, pièces acceptées, chiffrement,
   marques tierces dans les photos générées (« BANK OF AFRICA » en fond), wordmark redessiné → SVG réel,
   photo générée → Pexels avec un modèle noir. Retirer aussi le cadre de téléphone que certains écrans
   dessinent (`rounded-[44px] border-[8px]`, `body flex justify-center`).
7. **Geler** (`sources/client/ecrans/gel.py`) : CSS Tailwind généré extrait au navigateur (`freeze.js`
   lit les `<style>` injectés) et inliné ; scripts et liens externes retirés ; Material Symbols
   remplacés par leurs SVG (`fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined/<nom>/default/24px.svg`,
   `/fill1/` pour les pleins). Sans ça, la page servie affiche du HTML nu : la CSP du service de pages est
   `default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: https:`.
8. **Assembler** (`proto.py` + `proto-template.html`) : chaque écran en `<iframe srcdoc>`, images en
   data-URI, script de navigation injecté (clic sur « Continuer », « Ouvrir un compte… » → suivant,
   flèche retour → précédent, « Plus tard » → accueil, par `postMessage`), vue d'ensemble de tous les écrans.
   ⚠ Échapper `</` en `<\/` dans le JSON embarqué, sinon le premier `</script>` d'un écran coupe la page.
9. Publier (`integrations/frames/publier.py … --accord`), puis **vérifier sur l'adresse servie** avec un
   clic réel (`protoshot.js`) et une vue à 390 px. Livrer le lien, nommer l'outil, dire ce qui est fictif.

## Ce qui reste vrai
Un écran ne sort jamais en PDF ; le projet Stitch reste privé (aucun verbe de partage) : le lien
livrable est la page publiée. Aucune image d'aperçu dans le message (règle du 09/09).

## Historique

- v1, 22/09/2026 : écrit sur le premier dossier d'écrans produit avec Stitch.
- v2, 23/09/2026 : contrôle avant remise obligatoire en tête (inventaire du parcours, chaque
  clic mène quelque part, parcours testé sur l'adresse servie, états d'erreur et de
  confirmation, vue d'ensemble), séance Sync agents training.
