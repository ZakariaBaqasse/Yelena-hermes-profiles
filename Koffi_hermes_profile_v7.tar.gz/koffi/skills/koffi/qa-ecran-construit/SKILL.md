---
id: Y0423
name: qa-ecran-construit
description: "Compare l'écran réellement construit à sa spécification, écart par écart : valeurs, états, comportements au texte long et à l'écran étroit, messages affichés — puis rend une liste d'écarts hiérarchisée, en distinguant l'écart de construction de la spécification incomplète."
bucket: B
tags: [Design, Produit, Qualité, Nouveau]
version: 1
maj: 2026-08-13
---

# Contrôler l'écran construit contre sa spécification

## Ce qu'il faut avoir sous la main
- **L'écran construit** : accès à l'application, ou captures prises sur un appareil réel.
- **La spécification** qui fait foi, et sa version.
- **L'appareil** sur lequel les captures ont été prises, modèle et version du système.
- **Les états à couvrir** : par défaut, chargement, vide, erreur, texte long, droit manquant.

## Process
### Étape 1 — Contrôler les états, pas la capture d'accueil

L'écran par défaut est presque toujours juste, parce que c'est celui qu'on a sous les yeux en codant. Les écarts vivent ailleurs : chargement, liste vide, erreur, valeur très longue, droit manquant, connexion perdue. Le contrôle commence par ceux-là.

### Étape 2 — Mesurer sur la capture, ne pas apprécier à l'œil

Sur une capture prise à une densité connue, les valeurs se mesurent : espacements, hauteurs de composant, tailles de texte, épaisseurs, couleurs relevées au pixel. Un écart s'énonce en valeur attendue et valeur constatée, jamais en « ça paraît serré ».

### Étape 3 — Vérifier ce qui ne se voit pas sur une capture

Le comportement au texte agrandi, l'ordre de lecture, l'état de focus, la zone touchable réelle : ils ne se lisent pas sur une image. Ils passent au contrôle sur appareil, avec le protocole prévu pour cela.

### Étape 4 — Classer chaque écart par sa cause

Trois causes, et elles n'appellent pas la même correction : **écart de construction** — la spécification était claire et n'a pas été suivie ; **spécification muette** — le cas n'était pas prévu, et le développeur a tranché seul ; **spécification ambiguë** — deux lectures possibles. Les deux dernières se corrigent d'abord dans le référentiel.

### Étape 5 — Hiérarchiser par ce que ça coûte à l'utilisateur

Un texte coupé qui cache un montant passe avant un espacement faux de quatre points. La liste se lit de haut en bas et se corrige dans cet ordre.

### Étape 6 — Reboucler sur le référentiel

Tout écart de cause « muette » ou « ambiguë » produit une modification du système de design dans la foulée. Sans ce rebouclage, le même écart réapparaît au prochain écran, et le contrôle n'aura servi qu'une fois.

## Format de sortie
- **Livrable** : la liste des écarts — écran, état, valeur attendue, valeur constatée, cause, gravité, correction — puis la liste des modifications à apporter au référentiel.
- **Structure** : un bloc par écran, les états en lignes ; ce qui n'a pas pu être contrôlé listé nommément à la fin.
- **Longueur** : proportionnée au nombre d'écarts réels. Un contrôle sans écart se rend en trois lignes et c'est un bon résultat.

## Règles
1. **Valeur attendue et valeur constatée, toujours les deux.** Un écart sans ses deux nombres n'est pas exploitable.
2. **Aucune valeur de référence de mémoire** : elle se lit dans la spécification citée par sa version, ou elle n'est pas opposable.
3. **La cause avant la correction.** Un écart attribué au développeur alors que la spécification était muette est une erreur de diagnostic, et elle se paie en confiance.
4. **Ce qui ne se prouve pas sur capture ne se conclut pas sur capture.**
5. **On protège ce qui fonctionne** : un contrôle qui ne liste que des défauts fait refaire des choses justes.
6. **Le référentiel se corrige dans le même mouvement**, jamais « plus tard ».

## Cas limites
- **Pas d'accès à l'application** — travailler sur captures, et déclarer que le comportement dynamique n'a pas été contrôlé.
- **Spécification plus ancienne que le code** — c'est peut-être le code qui a raison ; poser la question avant de lister des écarts.
- **Écart volontaire décidé en cours de développement** — le noter comme décision à intégrer au référentiel, pas comme défaut.
- **Contrainte technique réelle** qui empêche d'appliquer la spécification — la spécification change, on ne demande pas l'impossible deux fois.
- **Capture de densité inconnue** — les mesures ne sont pas fiables ; demander la densité avant de mesurer plutôt que produire des valeurs fausses.
