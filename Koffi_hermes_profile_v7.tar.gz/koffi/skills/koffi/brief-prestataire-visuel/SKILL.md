---
id: Y0409
name: brief-prestataire-visuel
description: "Prépare la commande d'une prestation visuelle externe — photographe, vidéaste, imprimeur, sérigraphe : le brief qui décrit une commande et non une intention, la liste des prises attendues, les autorisations et le droit à l'image, le cadre de cession des droits, les critères d'acceptation, le plan de la journée de production avec son repli, et la grille de comparaison des devis — sans jamais fixer un tarif à la place de l'équipe."
bucket: B
tags: [Design, Production, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Briefer un prestataire — photographe, vidéaste, imprimeur, sérigraphe

## Ce qu'il faut avoir sous la main
- **Le type de prestation** : shooting photo, vidéo, impression, sérigraphie, ou plusieurs.
- **L'usage prévu** des visuels ou pièces produites : où ils seront diffusés, sur combien de temps, dans quel(s) pays.
- **Le lieu et les personnes** impliqués : local ou terrain, salariés, clients, figurants, mineurs éventuellement.
- **La date ou la fenêtre visée**, et les contraintes déjà connues (accès à un site, autorisation d'un tiers, saison).
- **Ce que tu as déjà** : moodboard, exemples, devis reçus, contrat-type d'un prestataire précédent.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Traduire l'intention en commande

Prends ce que le client a formulé (« des photos modernes et dynamiques », « une vidéo qui montre notre savoir-faire ») et interroge-le jusqu'à obtenir une commande : quel usage précis (site web, packaging, réseaux sociaux, affiche pour un salon), quel format de sortie, et ce qui doit obligatoirement apparaître (logo, produit, personne, lieu). Une intention qui ne se traduit pas en liste concrète après cette étape est un signal : le client n'a pas encore décidé ce qu'il veut, et le brief ne doit pas partir avant que ce soit tranché — sinon le prestataire livre quelque chose qui « ressemble » à la demande, et personne ne peut dire si c'est conforme.

### Étape 2 — La liste des prises ou des pièces attendues, une par une

Détaille chaque prise (photo), chaque plan (vidéo) ou chaque pièce (impression, sérigraphie) : son sujet, son cadrage ou son format, son usage prévu, et si elle est indispensable ou optionnelle. Pour l'impression et la sérigraphie, précise le support, les couleurs attendues (avec leur référence si elle existe — Pantone ou équivalent local du prestataire), le nombre d'exemplaires et le fichier source attendu en retour. Une liste qui reste au niveau « quelques photos de l'équipe » ne permet ni de produire, ni de refuser une livraison : elle doit descendre au niveau de la prise individuelle.

### Étape 3 — Contraintes de lieu, de temps, de personnes

Fixe le lieu (adresse, accès, horaires d'ouverture si c'est un site tiers — marché, usine, boutique), la fenêtre de temps disponible, et qui doit être présent (salarié à libérer, client à solliciter, figurant à trouver). Anticipe ce qui, à Abidjan comme ailleurs, change le programme sans prévenir : embouteillages qui retardent une équipe ou un client attendu à une heure précise, coupure d'électricité sur un site qui a besoin de lumière artificielle, accès à un lieu qui dépend d'une autorisation orale et non écrite. Note aussi si une autorisation formelle est nécessaire (tournage sur la voie publique, accès à un site industriel, présence dans un lieu appartenant à un tiers) — c'est une action à mener avant le jour J, pas pendant.

### Étape 4 — Le droit à l'image, avant la prise — pas après

Toute personne reconnaissable sur un visuel diffusé doit avoir donné son accord — salarié, client, passant, et à plus forte raison un enfant, dont l'accord relève de son représentant légal. Cet accord se recueille **au moment de la prise**, par écrit, pas après coup sur la base d'un souvenir de consentement oral. Produis le modèle d'autorisation : identité de la personne, description du visuel, usage et supports autorisés, durée, et possibilité ou non de retrait. Un visuel réussi sans cette autorisation est un visuel qu'on ne peut pas diffuser — c'est le piège le plus fréquent parce qu'il ne se voit qu'au moment de la publication, quand il est déjà trop tard pour le corriger.

### Étape 5 — Le cadre de cession des droits sur le visuel lui-même

Distingue deux choses que le client confond souvent : payer une prestation, et détenir le droit d'utiliser librement ce qui en résulte. Sauf cession explicite, le photographe ou le vidéaste conserve des droits sur son travail — le cadre de propriété littéraire et artistique dans la région relève de l'Accord de Bangui et de l'OAPI, sans que tu cites un article ou un délai précis de mémoire. Le brief doit donc fixer par écrit, avant la prestation : l'usage autorisé (quels supports), la durée (limitée ou illimitée), le territoire, et si le prestataire peut lui-même réutiliser le visuel dans son portfolio. Sans cette clause, l'entreprise se retrouve à devoir repayer pour réutiliser une photo qu'elle croyait déjà sienne — c'est le deuxième piège, le plus coûteux dans la durée parce qu'il ne se paie pas tout de suite.

### Étape 6 — Les critères d'acceptation, chiffrés

Fixe avant la prestation : le nombre de prises ou de pièces livrées, le format et la résolution attendus, le niveau de retouche inclus dans le prix, le délai de livraison, et le nombre d'allers-retours de correction compris avant qu'un supplément soit facturé. Ce sont des décisions de l'équipe, pas des standards du métier que tu connaîtrais : chaque valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée. Une livraison sans ces critères se discute à l'arrivée du fichier — trop tard pour négocier, trop tôt pour refuser sereinement.

### Étape 7 — Le plan de la journée de production, avec son repli

Ordonne les prises pour limiter les déplacements et les temps morts, liste le matériel et la tenue attendus (du prestataire et du client), et prévois le scénario de repli : que se passe-t-il si la lumière ou la météo change le programme (saison des pluies notamment), si l'accès au lieu est refusé au dernier moment, ou si une personne attendue n'est pas disponible. Un plan sans repli oblige à improviser le jour même, au moment où c'est le plus coûteux de le faire.

### Étape 8 — La grille de comparaison des devis

Construis la grille qui permet de comparer plusieurs prestataires sur les mêmes bases : ce qui est inclus (prises, retouche, allers-retours, droits cédés, délai), ce qui est en supplément, le mode de paiement proposé (acompte, solde, mobile money accepté ou non), et la facture attendue en retour. Tu ne remplis aucune colonne de prix : le tarif est ce que chaque devis apporte, comparé sur une base identique — ta grille est le cadre de comparaison, pas le résultat de la négociation.

## Format de sortie
- **Livrable** : le brief de prestation complet — objectif et usage, liste détaillée des prises ou pièces, contraintes de lieu/temps/personnes, modèle d'autorisation de droit à l'image, cadre de cession des droits, critères d'acceptation chiffrés, délais et allers-retours inclus — plus le plan de journée avec son scénario de repli, et la grille de comparaison des devis.
- **Structure** : Markdown clair, avec des listes et des tableaux pour la liste de prises, les critères d'acceptation et la grille de comparaison. Le brief doit pouvoir être envoyé tel quel à un prestataire, y compris par WhatsApp en plusieurs messages si c'est le canal utilisé.
- **Longueur** : proportionnée à la prestation — un shooting simple ne demande pas le même détail qu'une campagne multi-supports avec impression.
- **Les montants et les seuils sont un input**, jamais une production : prix, acomptes, pénalités de retard restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés ou négociés.
- **Règle 0 invention** : aucun tarif, aucun délai légal, aucune référence de droit d'auteur précise n'est produite sans être fournie ou sourcée.

## Règles
1. **Une commande décrit des prises, pas une intention.** « Moderne et dynamique » n'est jamais un critère de livraison. Chaque élément de la liste de prises doit être assez précis pour qu'on puisse dire, en la regardant, si elle a été livrée ou non.
2. **Les droits se règlent avant la prestation, pas après.** Le cadre de cession (usage, durée, supports, territoire) est écrit dans le brief, jamais négocié une fois les fichiers livrés.
3. **Le droit à l'image se recueille au moment de la prise.** Aucun visuel montrant une personne reconnaissable n'est diffusable sans son autorisation écrite — celle d'un mineur passe par son représentant légal.
4. **0 tarif inventé.** Aucun prix, aucun taux horaire, aucun montant d'acompte n'est produit par la skill : `⟦à renseigner⟧` sinon. La grille de comparaison des devis structure la négociation, elle ne la précède pas.
5. **0 référence légale inventée.** Tu peux nommer l'OAPI et le cadre de la propriété littéraire et artistique de la région ; tu ne cites aucun article, aucun délai de protection, aucun taux sans source vérifiée.
6. **Les critères d'acceptation sont écrits avant, jamais négociés à la livraison.** Nombre de pièces, résolution, retouches incluses, allers-retours compris : s'ils manquent, tu le signales avant de considérer le brief complet.
7. **Le contexte terrain change le plan, pas seulement le décor.** Accès à un site, coupure d'électricité, météo de saison des pluies, embouteillages sur le trajet du prestataire ou des figurants : le plan de journée doit prévoir un repli pour chacun s'il est pertinent.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter un prestataire, signer un contrat ou engager un paiement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une prestation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis le brief avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Usage des visuels non encore défini** — tu le signales comme point bloquant pour la cession des droits : sans usage connu, le cadre de cession ne peut être qu'un modèle générique à ajuster, et tu le dis explicitement.
- **Personnes mineures présentes sur le visuel** — tu signales que l'autorisation doit venir du représentant légal et tu adaptes le modèle en conséquence, sans jamais présumer qu'un accord oral suffit.
- **Devis déjà reçus** — tu les intègres à la grille de comparaison telle que fournie, sans inventer de colonne de prix manquante ; une case sans donnée reste vide, pas estimée.
- **Prestataire informel, sans facture normalisée** — tu le signales : le brief et les critères d'acceptation restent valables, mais tu recommandes de clarifier le mode de paiement et la preuve de livraison avant la prestation plutôt que d'improviser sur place.
- **Lieu appartenant à un tiers** (site industriel, marché, propriété privée) — tu marques l'autorisation d'accès comme préalable à obtenir, distincte de l'autorisation de droit à l'image des personnes présentes.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (contrat de prestation, plan média, identité visuelle).
- **Action sortante demandée** (envoi du brief, signature, paiement d'acompte) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions du besoin selon les interlocuteurs) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
