---
id: Y0736
name: portfolio-de-designer
description: "Constitue le portfolio d'un designer indépendant à partir de ses travaux réels : sélection tournée vers les clients qu'il vise, une étude de cas par projet (le problème, le parti pris, ce qui a été livré, le résultat s'il est connu), droits de diffusion vérifiés projet par projet, remise en PDF léger et en page web publiée. Ne fabrique jamais un projet, un client ou un résultat."
bucket: B
tags: [Design, Indépendant, Nouveau]
version: 1
maj: 2026-09-23
---

# Le portfolio d'un designer indépendant

Un portfolio sert à décrocher le client suivant, pas à tout archiver. Il montre peu de projets,
choisis pour les clients visés, et chacun explique ce que le designer a résolu.

## Ce qu'il faut avoir sous la main
- **Les travaux** : fichiers, liens, captures, avec une ligne par projet (pour qui, quand, ce
  que le designer a fait lui-même).
- **Les clients visés** : secteur, taille, type de mission recherchée.
- **Les droits** : pour chaque projet, l'accord du client pour le montrer, ou une clause de
  confidentialité.
- **Les résultats connus**, avec leur origine (chiffre donné par le client, mesure publique).
- **Où le portfolio sera vu** : envoyé en PDF, page web, plateforme de designers.

Sans aucun travail reçu, rien ne se fabrique : tu proposes en A/B d'envoyer les projets avec une
ligne chacun, ou le lien d'une page existante (site, plateforme de designers).

## ⛔ Contrôle avant remise, obligatoire

Avant d'envoyer, tu vérifies que :

1. **chaque projet montré a son accord de diffusion**, ou il est anonymisé (nom et marque
   retirés) et le designer l'a validé ainsi ;
2. **aucun projet, client ou résultat n'est inventé**, et chaque chiffre dit d'où il vient ;
3. **chaque projet se voit** : les visuels d'abord, un texte court ensuite, jamais un paragraphe
   à la place de l'image ;
4. **la sélection a été validée par le designer**, qui signe ce document ;
5. **la remise porte le PDF et la page publiée**, selon le contrôle de `sitecraft-ai` pour la
   page, et les contrôles de `production-visuelle-livrable` (polices, sources) pour le PDF.

Un point en échec : tu corriges avant d'envoyer.

## Process
### Étape 1 : l'inventaire
Tous les projets reçus, dans un tableau : client, date, rôle réel du designer, livrables, droits
de diffusion, résultat connu et sa source. Un projet où le designer n'a fait qu'une partie le
dit.

### Étape 2 : la sélection
Tu gardes les projets qui parlent aux clients visés, et tu écartes les redites : deux logos de
même style valent un seul. Tu proposes la sélection en A/B au designer, avec ce que chaque
option met en avant.

### Étape 3 : l'étude de cas
Pour chaque projet retenu, quatre temps : le problème posé, le parti pris et pourquoi, ce qui a
été livré (visuels à l'échelle, déclinaisons, avant et après s'il y en a), le résultat s'il est
connu. Le ton est celui du designer, à la première personne s'il le souhaite.

### Étape 4 : la présentation du designer
Une page : qui il est, ce qu'il fait, pour qui, comment le joindre. Aucune référence client
citée sans accord.

### Étape 5 : la mise en forme et la remise
Une mise en page sobre qui laisse la place au travail. PDF léger pour l'envoi par messagerie,
page web publiée pour le partage, les deux à partir de la même source.

## Format de sortie
- **Portfolio** : PDF et page publiée, même contenu.
- **Tableau d'inventaire** : Google Sheet, remis au designer pour qu'il le tienne à jour.
- La remise nomme l'outil utilisé et liste les projets écartés et pourquoi.

## Règles
1. **Le travail réel seulement** : aucun projet fictif présenté comme réalisé.
2. **Le droit de montrer passe avant l'envie de montrer.**
3. **Peu de projets, choisis pour le client visé.**
4. **Chaque projet explique ce qui a été résolu**, pas seulement ce qui a été dessiné.

**Garde-fous durs**
- 🔒 **Aucune publication sur une plateforme au nom du designer** sans sa validation écrite.
- **Cloisonnement** : les travaux d'un designer ne nourrissent jamais le portfolio d'un autre.

## Cas limites
- **Designer débutant sans client** : les projets personnels ou d'école se montrent comme tels,
  jamais comme des commandes.
- **Projet sous confidentialité** : il sort du portfolio, ou il est décrit sans visuel ni nom,
  avec l'accord du designer.
- **Travaux en basse définition** : tu le signales et tu demandes les fichiers source avant de
  mettre en page.

## Historique

- v1, 23/09/2026 : création (ligne 42 de la séance du 22/09, portfolio d'un designer
  indépendant), séance Sync agents training.
