---
id: Y0043
name: 09-3-generateur-d-hypothese
description: "Génère hypothèses UX testables persona."
bucket: A
tags: [Design]
version: 1
maj: 2026-08-10
---

# Générateur d'Hypothèses UX — Customer Discovery

## Ce qu'il faut avoir sous la main
1. Les **fiches de tous tes personas** (une fiche de définition persona suffit) ;
2. Ton **activité en 2 lignes** : secteur + proposition de valeur + marché cible ;
3. *(optionnel)* le **persona prioritaire** — pour l'ordre de présentation uniquement.

## Process
- **Contexte activité** : comprendre le secteur, les enjeux business, l'écosystème.
- **Segmentation personas** : identifier les variations internes à chaque persona.
- **Spécificités** : repérer les différences entre personas (rôles, contraintes, environnements).

Avant de générer, vérifier systématiquement :
- Nombre de personas identifiés : [X]
- Chaque persona aura ses 3 catégories d'hypothèses : OUI
- Persona prioritaire traité en premier si mentionné : OUI
- TOUS les personas seront couverts : OUI

**Règle impérative** : générer des hypothèses pour CHAQUE persona fourni, sans exception.
- Si 3 personas → 3 sections complètes
- Si 5 personas → 5 sections complètes
- Le persona prioritaire peut être en premier, mais TOUS doivent être traités

### Étape 2 — Génération d'hypothèses par persona

Pour CHAQUE persona (sans exception), générer le **nombre optimal d'hypothèses pertinentes** par catégorie :
- **Maximum** : 15 hypothèses par catégorie
- **Priorité** : qualité et pertinence > quantité
- **Couverture** : 3 catégories obligatoires par persona

### ⚙️ Hypothèses sur l'industrie
**Focus :** environnement, marché, normes, limitations, opportunités, pratiques courantes, réglementation, écosystème.

### 💢 Hypothèses sur les besoins, attentes, frustrations, freins
**Focus :** attentes, rejets, redoutes, problèmes à résoudre, facilitateurs de vie, motivations, obstacles.

### 🧍 Hypothèses sur les tâches, routines, comportements, habitudes
**Focus :** actions quotidiennes, usage d'outils, contraintes, adaptations, contournements, processus.

### Étape 3 — Présentation & validation

Présenter les hypothèses structurées par persona avec :
- Format clair et lisible
- Numérotation par catégorie
- Séparation visuelle entre personas
- Message de validation en fin de présentation

### Étape 4 — Livrable final optimisé

Après présentation des hypothèses, demander systématiquement :
« Es-tu satisfait(e) de ces hypothèses ? Si oui, je peux te fournir un **livrable Markdown optimisé** (prêt pour conversion PDF ou usage terrain). »

Si réponse positive → fournir le contenu restructuré en format Markdown propre :
- Page de garde avec titre activité
- Sommaire des personas
- Hypothèses par persona avec mise en forme professionnelle
- Format optimisé pour entretiens terrain
- Prêt pour téléchargement/conversion

## Format de sortie
Structure de présentation (conversation) :

```
# HYPOTHÈSES UX PAR PERSONA - [NOM ACTIVITÉ]

## Règles
**Exhaustivité**
- Couverture totale : générer des hypothèses pour TOUS les personas fournis
- 3 catégories obligatoires : Industrie + Besoins + Comportements pour chaque persona
- Pas d'exception : même si un persona prioritaire est mentionné, tous doivent être traités
- Vérification pré-génération : confirmer le nombre de personas avant de commencer

**Qualité**
- Pertinence > quantité : privilégier des hypothèses uniques et testables
- Éviter la redondance : ne pas multiplier les hypothèses similaires
- Spécificité persona : adapter chaque hypothèse au contexte du persona
- Maximum 15/catégorie : ne pas dépasser pour rester actionnable

**Communication**
- Clarté des attentes : expliquer le format et le processus
- Validation explicite : attendre confirmation avant de générer le livrable final
- Pas de livrable avant validation : ne proposer le Markdown optimisé qu'après review

**Workflow**
- Respect des étapes : Analyse → Génération → Présentation → Validation → Livrable
- Pas de raccourci : toujours présenter pour validation avant le livrable final
- Attendre une confirmation explicite (« c'est validé » / « ok pour le livrable » / « parfait »)

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Connecteurs & datasources requis
- **Aucun.** Cette skill travaille sur le seul contenu que tu lui fournis dans la conversation — pas de source externe à brancher.

## Détails complémentaires
### Critères de qualité des hypothèses

**Critères formels**
- Forme : phrases simples et réalistes (ex. « Les livreurs roulent plus de 100 km par jour »)
- Clarté : formulation directe sans ambiguïté
- Concision : une idée par hypothèse

**Critères de testabilité**
- Vérifiabilité : peuvent être confirmées ou infirmées en entretien terrain
- Testabilité : formulées pour être facilement questionnées en interview
- Observabilité : basées sur des faits ou comportements observables

**Critères de pertinence**
- Spécificité persona : adaptées aux particularités de chaque persona
- Diversité : couvrent les variations internes au persona
- Valeur unique : chaque hypothèse apporte un éclairage distinct
- Non-redondance : éviter les hypothèses similaires ou dérivées

### 👤 [NOM PERSONA 1]

### ⚙️ HYPOTHÈSES SUR L'INDUSTRIE
1. [Hypothèse industrie spécifique au persona 1]
2. [Hypothèse industrie spécifique au persona 1]
3. [...]
[Maximum 15, selon pertinence]

### 💢 HYPOTHÈSES SUR LES BESOINS, ATTENTES, FRUSTRATIONS, FREINS
1. [Hypothèse besoins spécifique au persona 1]
2. [...]
[Maximum 15, selon pertinence]

### 🧍 HYPOTHÈSES SUR LES TÂCHES, ROUTINES, COMPORTEMENTS, HABITUDES
1. [Hypothèse comportements spécifique au persona 1]
2. [...]
[Maximum 15, selon pertinence]

### 👤 [NOM PERSONA 2]

[Même structure complète pour persona 2...]

[Répéter pour CHAQUE persona fourni]
```

**Prochaine étape** (fin de présentation) : « Une fois ces hypothèses reviewées, confirme-le moi et je générerai le document Markdown optimisé pour tes entretiens terrain. »

Principes de présentation :
- Organiser par persona (pas par catégorie transverse)
- Utiliser des sections clairement séparées
- Maximum 15 hypothèses par catégorie
- Prioriser les hypothèses à fort potentiel de découverte
- Maintenir la cohérence avec les spécificités des personas

### Livrables finaux

1. **Hypothèses UX structurées** par persona (format conversation) — 3 catégories par persona, maximum 15 hypothèses/catégorie, tous les personas couverts.
2. **Guide d'utilisation terrain** : comment utiliser ces hypothèses en entretien.
3. **Document Markdown optimisé** (sur demande après validation) : page de garde (nom activité + date), sommaire des personas, hypothèses structurées avec mise en forme professionnelle, format prêt pour entretiens terrain, téléchargeable et convertible en PDF.

### Exemple d'usage

**Input :**
- Activité : plateforme de livraison de repas en Afrique de l'Ouest
- Personas : livreurs à moto, restaurateurs locaux, clients urbains
- Persona prioritaire : livreurs à moto (priorité de présentation uniquement)

**Output :**
1. **Analyse** : compréhension du secteur + spécificités des 3 personas
2. **Génération** :
   - Livreurs à moto (traité en premier car prioritaire) : 3 catégories complètes
   - Restaurateurs locaux : 3 catégories complètes
   - Clients urbains : 3 catégories complètes
3. **Validation** : présentation pour review
4. **Livrable** : document Markdown optimisé pour entretiens terrain
