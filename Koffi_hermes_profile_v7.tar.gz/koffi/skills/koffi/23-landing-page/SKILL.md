---
id: Y0059
name: 23-landing-page
description: "Génère un brief de design détaillé (prompt de spécification prêt à coller dans un outil de génération de maquettes IA type UX Pilot) pour la landing page d'une startup en résidence du programme, à partir de son branding, de son customer discovery et des références du portefeuille. Si la personne demande une page à voir et non un brief, la remise suit le contrôle de sitecraft-ai : fichier HTML autonome et lien publié."
bucket: C
tags: [Design]
version: 2
maj: 2026-09-23
---

# Landing Page Generator : Startups du programme

## ⛔ Avant de remettre : un brief n'est pas une page (23/09/2026)

Cette compétence produit un brief et un prompt de maquette, pas un site. Avant d'envoyer, tu
relis ce qui a été demandé. Si la personne attend une page à voir (« fais-moi la landing »,
« montre-moi le site »), le brief ne suffit pas : la page se construit et se remet en **fichier
HTML autonome et en lien publié**, selon le contrôle en tête de `sitecraft-ai`. Un brief remis à
la place d'une page est un livrable manquant : tu ne remets pas.

## Ce qu'il faut avoir sous la main
**Documents essentiels**
- Ton branding advanced (PPT ou PDF) : mission, valeurs, couleurs, typographie, tagline
- Ton logo en SVG (ou PNG haute résolution si le SVG n'est pas disponible)
- Ta restitution customer discovery (PDF) : pour comprendre ton public cible et ton contexte

**Information clé**
- 🎯 Call-to-action principal : comment veux-tu que les visiteurs te contactent ? (WhatsApp / Email / Formulaire / Lien de téléchargement app)

**Optionnel mais recommandé**
- 📸 Visuels existants : photos de contexte, mockups produit, illustrations
- 💬 Témoignages, si tu as déjà des retours d'utilisateurs beta ou pilotes

💡 Inspire-toi des landing pages du portefeuille : Exemple A · Exemple B · Exemple C · Exemple D · Exemple E


**Ce qu'elle suppose comme accès** : Documents de la startup du programme. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### 🔍 ÉTAPE 1 : ANALYSE

📄 **Documents reçus :**
- Branding advanced : [✅/❌]
- Logo : [✅/❌] [Format]
- Customer discovery : [✅/❌]
- CTA défini : [✅/❌] [Type]
- Visuels additionnels : [✅/❌]

🎯 **Informations extraites :**
- Nom : [...]
- Secteur : [...]
- Cible : [...]
- Pain points : [...]
- Couleurs : Primaire [...], Secondaire [...], Accent [...]
- Typo : [...]
- Valeurs : [...]

❓ **Clarifications :** [Liste ou "Aucune"]

### 📐 ÉTAPE 2 : STRUCTURE PROPOSÉE

**Type landing page :** [Type identifié]
**Sections :**
1. Hero
2. [Section 2]
3. [Section 3]
[...]

**Justification :** [Explication courte basée secteur + insights]
**Référence portefeuille similaire :** [Nom] - [Lien]

### 💡 ÉTAPE 3 : RECOMMANDATIONS

🎨 **Design :**
- [Point 1]
- [Point 2]

📸 **Assets critiques prioritaires :**
- [Asset 1]
- [Asset 2]

⚠️ **Points attention :**
- [Considération technique/contextuelle]

### ✅ ÉTAPE 4 : VALIDATION

"✅ **Validation requise** : Structure et approche proposées OK ? Si oui, je génère immédiatement le prompt de design complet."

### 📄 ÉTAPE 5 : GÉNÉRATION

Après validation, générer le prompt de design complet (template ci-dessus, rédigé en anglais) sous forme de fichier texte téléchargeable nommé `prompt_design_[NOM_STARTUP].txt` si l'environnement le permet, sinon sous forme de bloc de code prêt à copier-coller.

Annoncer :

"📥 **Prompt généré** : `prompt_design_[NOM_STARTUP].txt`
Prompt complet prêt copier-coller dans ton outil de génération de maquettes (rédigé en anglais pour une utilisation optimale).
💡 **Utilisation** :
1. Récupère le fichier (ou copie le bloc ci-dessus)
2. Copie l'intégralité du prompt
3. Colle-le dans ton outil de génération de maquettes IA et lance la génération"

📌 **Note** : Prompt final en anglais pour l'outil de génération de maquettes. Échanges préalables en français.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
<principles>
  <african_context>Photos contexte local, couleurs vibrantes, représentation authentique</african_context>
  <clarity_first>Hiérarchie claire, message immédiat, pas de jargon</clarity_first>
  <benefit_driven>Bénéfices avant features, chiffres et preuves tangibles</benefit_driven>
  <trust_building>Témoignages, logos partenaires, garanties, certifications</trust_building>
  <action_oriented>CTAs multiples et stratégiques, souvent WhatsApp (réduction friction)</action_oriented>
  <mobile_first>Optimisé mobile prioritaire (trafic africain), touch-friendly, chargement rapide</mobile_first>
  <visual_storytelling>Alternance texte/visuels, mockups contextuels, icônes compréhension</visual_storytelling>
  <pain_addressing>Adresser directement pain points + objections du customer discovery</pain_addressing>
</principles>

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** : tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Inputs requis

<inputs>
  <documents>
    <branding>Identité visuelle, valeurs, mission, typo, couleurs (codes exacts)</branding>
    <logo>SVG ou PNG HD avec variantes</logo>
    <customer_discovery>Insights cibles, pain points, contexte marché</customer_discovery>
    <visuels>Photos, mockups, illustrations (optionnel)</visuels>
  </documents>

  <identite>
    <nom>Nom startup</nom>
    <tagline>Tagline exacte</tagline>
    <proposition_valeur>Value proposition</proposition_valeur>
    <mission>Mission</mission>
    <valeurs>3 valeurs principales</valeurs>
  </identite>

  <benefices>
    <benefice_1>Bénéfice clé #1</benefice_1>
    <benefice_2>Bénéfice clé #2</benefice_2>
    <benefice_3>Bénéfice clé #3</benefice_3>
    <benefice_4>Optionnel</benefice_4>
  </benefices>

  <identite_visuelle>
    <couleurs>
      <primaire>Code HEX/RGB exact</primaire>
      <secondaire>Code HEX/RGB exact</secondaire>
      <accent>Code HEX/RGB (opt.)</accent>
      <neutrals>Textes + backgrounds</neutrals>
    </couleurs>
    <typographie>
      <principale>Police titres + weights</principale>
      <secondaire>Police body + weights</secondaire>
      <hierarchie>H1, H2, H3, body sizes</hierarchie>
    </typographie>
    <logo>
      <format>Format fichier</format>
      <variantes>Horizontal, vertical, icône</variantes>
    </logo>
  </identite_visuelle>

  <customer_insights>
    <cible>Description détaillée public</cible>
    <pain_points>Problèmes identifiés</pain_points>
    <contexte_usage>Où/comment solution utilisée</contexte_usage>
    <objections>Freins potentiels</objections>
  </customer_insights>

  <cta>
    <type>WhatsApp / App / Inscription / Contact</type>
    <lien>URL ou numéro</lien>
    <texte>Texte bouton</texte>
  </cta>

  <contexte>
    <secteur>Secteur activité</secteur>
    <geographie>Pays/région</geographie>
    <specificites>Éléments particuliers</specificites>
  </contexte>
</inputs>

### Méthodologie

### 1️⃣ Analyse Documents

**Branding Advanced :**
- Couleurs (codes HEX/RGB exacts)
- Typographies (noms, weights, tailles)
- Tagline, mission, valeurs, personnalité
- Usage logo (variantes, règles)

**Customer Discovery :**
- Public cible (démographie, comportements, besoins)
- Pain points principaux
- Contexte d'usage
- Motivations et freins
- Preuves de validation

**Validation :**
- Bénéfices alignés avec pain points ?
- Ton et style cohérents avec cible/valeurs ?
- Éléments manquants critiques ?

### 2️⃣ Structure Adaptative

**Sections possibles :**
- Hero (obligatoire) : Tagline + sous-titre + CTA + visuel
- Proposition valeur (obligatoire) : Problème résolu
- Bénéfices (obligatoire) : 3-4 bénéfices avec icônes
- Process : 3-4 étapes
- Social proof : Témoignages + logos
- Détails produit : Sections approfondies
- FAQ : 4-6 questions (basées objections)
- CTA final : Appel action + formulaire/redirection

**Logique adaptation par type (référence portefeuille) :**
- Marketplace (Exemple A, Exemple C) : Hero → Proposition → Bénéfices (4) → Process (3) → Témoignages → CTA
- B2B SaaS (Exemple B) : Hero → Services → Confiance → Bénéfices détaillés → Cas usage → CTA
- Consumer (Exemple D) : Hero → Bénéfices → Témoignages → Détails → FAQ → CTA
- Mobilité (Exemple E) : Hero → Process → Avantages éco → Témoignages → Offre → CTA

### 3️⃣ Génération Prompt de Design

Prompt structuré contenant :
- Brief : Contexte, objectif, cible (customer discovery)
- Identité visuelle : Couleurs (codes), typo, logo
- Structure section par section : Layout, contenu, hiérarchie
- Specs techniques : Responsive, animations
- Inspirations : Références portefeuille similaires
- Assets requis : Liste visuels/icônes
- Contenu suggéré : FAQ (objections), témoignages contextuels

### Template Prompt de Design (à coller dans l'outil de génération de maquettes)

Le prompt final est rédigé en anglais (meilleure performance des outils de génération de maquettes IA), même si les échanges avec l'utilisateur·ice se font en français.

```
═══════════════════════════════════════════════════
🎨 PROMPT DESIGN - LANDING PAGE [NOM STARTUP]
═══════════════════════════════════════════════════
📋 BRIEF GÉNÉRAL
────────────────────────────────────────────────────
Startup: [Nom]
Tagline: [Tagline exacte]
Mission: [Mission]
Sector: [Secteur]
Objective: High-fidelity landing page for pilot MVP launch
Target audience: [Description détaillée customer discovery]
Main pain points: [Liste pain points]
Tone: [Professional/Accessible/Inspiring] + anchored in African context
Inspiration: [Références portefeuille pertinentes]
────────────────────────────────────────────────────
🎨 VISUAL IDENTITY
────────────────────────────────────────────────────
COLORS
• Primary: [HEX] - Usage: CTAs, key elements, links
• Secondary: [HEX] - Usage: alternating sections, accents
• Accent: [HEX] - Usage: highlights, badges
• Neutrals:
  - Main text: [HEX]
  - Secondary text: [HEX]
  - Light background: [HEX]
  - Dark background: [HEX]
TYPOGRAPHY
• Primary font: [Name] - Usage: H1, H2, H3 headings
  - H1: [Size]px, [Weight], [Line-height]
  - H2: [Size]px, [Weight], [Line-height]
  - H3: [Size]px, [Weight], [Line-height]
• Secondary font: [Name] - Usage: Body text, subtitles
  - Body: [Size]px, [Weight], [Line-height]
  - Small: [Size]px, [Weight], [Line-height]
LOGO
• Format: [File format]
• Available variants: [List]
• Usage: [Horizontal/vertical] version in header, icon version for favicon
• Protection space: [Specs if available]
────────────────────────────────────────────────────
📐 STRUCTURE & SECTIONS
────────────────────────────────────────────────────
🔷 SECTION 1: HERO
Layout: [Layout description]
Content:
  • H1 Title: "[Exact tagline]"
  • Subtitle: "[Developed value proposition]"
  • Primary CTA: Button "[CTA text]" → [Link type]
  • Hero visual: [Precise visual description]
Visual specs:
  • Background: [Color or gradient with exact codes]
  • Layout: [Exact layout - e.g., text 40% left, visual 60% right]
  • Height: [viewport or px]
  • Animation: [If applicable]
────────────────────────────────────────────────────
🔷 SECTION 2: VALUE PROPOSITION
Layout: [Description]
Content:
  • H2 Title: "[Section title]"
  • Text: "[Explanation of problem solved - aligned with customer discovery pain points]"
  • Visual elements: [Description]
────────────────────────────────────────────────────
🔷 SECTION 3: KEY BENEFITS
Layout: Grid of [3/4] cards with icons
Content:
  • Benefit 1:
    - Icon: [Description or icon type]
    - Title: "[Benefit title]"
    - Description: "[Short explanation]"
  • Benefit 2: [...]
  • Benefit 3: [...]
  • Benefit 4: [...] (if applicable)
Specs:
  • Icons: Style [line/filled/duotone], color [primary/secondary]
  • Cards: Background [color], padding [value], border-radius [value]
────────────────────────────────────────────────────
🔷 SECTION 4: [ADAPT - HOW IT WORKS / SERVICES / PRODUCT DETAILS]
[Complete section details with layout, content, visual specs]
────────────────────────────────────────────────────
🔷 SECTION 5: TESTIMONIALS / SOCIAL PROOF
Layout: [Carousel / Grid / Cards]
Content:
  • [3 suggested testimonials OR contextual placeholders]
  • Partner logos: [If applicable]
────────────────────────────────────────────────────
🔷 SECTION 6: FAQ
Content: [4-6 questions based on customer discovery objections]
  Q1: [Question]
  A1: [Answer]

  Q2: [Question]
  A2: [Answer]

  [...]
Layout: Accordion with click expansion
────────────────────────────────────────────────────
🔷 SECTION 7: FINAL CTA
Layout: Full-width section
Content:
  • H2 Title: "[Final hook phrase]"
  • Subtitle: "[Benefit reinforcement]"
  • CTA: Prominent button "[Text]" → [Link]
  • Background: [Primary color or gradient]
────────────────────────────────────────────────────
📱 TECHNICAL SPECIFICATIONS
────────────────────────────────────────────────────
RESPONSIVE
• Breakpoints:
  - Mobile: < 768px
  - Tablet: 768px - 1024px
  - Desktop: > 1024px
• Priority: Mobile-first
• Key adaptations:
  - Hero: Vertical stack on mobile
  - Benefits grids: 1 col mobile, 2 tablet, 3-4 desktop
  - Typography: Reduce H1 by [X]% on mobile
INTERACTIONS
• Hover states:
  - Buttons: Elevation + color change
  - Cards: Slight elevation (box-shadow)
• Scroll animations: [Progressive fade-in / Slide-in / None]
• Micro-interactions: [Details if applicable]
PERFORMANCE
• Images: WebP format with PNG/JPG fallback, lazy loading
• Optimization: Priority fast loading for African 3G/4G connections
• Compression: Assets optimized for performance
────────────────────────────────────────────────────
🎯 SUGGESTED CONTENT (Based on Customer Discovery)
────────────────────────────────────────────────────
TESTIMONIALS (Contextual placeholders)
1. [Fictional name], [Target profile]
   "[Realistic testimonial addressing identified pain point]"
2. [Fictional name], [Target profile]
   "[Testimonial highlighting key benefit]"
3. [Fictional name], [Target profile]
   "[Testimonial about ease of use or result obtained]"
FAQ (Based on Customer Discovery objections)
[Questions and answers anticipating identified barriers]
────────────────────────────────────────────────────
📎 REQUIRED ASSETS
────────────────────────────────────────────────────
VISUALS
☐ Hero image/illustration: [Precise visual type description]
☐ Product/app mockup: [Usage context to represent]
☐ Section illustrations: [List with descriptions]
☐ Benefit icons: [Icon themes]
☐ African context photos: [Scenes to capture]
☐ Partner logos: [If applicable]
GRAPHIC ELEMENTS
☐ Decorative shapes: [Description if relevant]
☐ Patterns: [Style if applicable]
☐ Badges/Labels: [E.g., "New", "Beta", "Free", etc.]
TEXT CONTENT TO PREPARE
☐ Real testimonials (if available)
☐ Statistics/key figures
☐ Team bio (if team section)
═══════════════════════════════════════════════════
```

### Instructions Spéciales

<instructions>
  <doc_analysis>TOUJOURS analyser en détail les documents fournis (branding + customer discovery) avant de demander infos complémentaires. Extraire maximum d'infos de ces sources.</doc_analysis>

  <adaptability>Si inputs manquants APRÈS analyse documents, demander clarifications ciblées. Ne JAMAIS supposer couleurs, typographies ou éléments marque.</adaptability>

  <contextual_creativity>Pour sections contenu (témoignages, FAQ), générer suggestions réalistes basées sur :
    - Pain points customer discovery
    - Objections potentielles relevées
    - Secteur et profil cible
  Utiliser les références du portefeuille pour ton et style.</contextual_creativity>

  <technical_precision>TOUJOURS fournir :
    - Codes couleurs exacts (HEX/RGB), jamais noms génériques
    - Polices avec weights et tailles précises
    - Dimensions et espacements en px/rem
    - Animations et micro-interactions précises</technical_precision>

  <referencing>Identifier startup(s) du portefeuille existante(s) similaires (secteur, solution, cible) et mentionner comme références avec liens directs.</referencing>

  <customer_centric>Customer discovery = source prioritaire pour :
    - Comprendre cible (langage, besoins, contexte)
    - Structurer bénéfices (alignés pain points)
    - Anticiper objections (FAQ)
    - Définir ton et niveau langage</customer_centric>

  <file_output>Prompt de design final livré, après validation utilisateur, sous forme de fichier texte téléchargeable si l'environnement le permet (sinon, sous forme de bloc de code prêt à copier-coller). Le livrable contient UNIQUEMENT le prompt formaté, prêt copier-coller dans l'outil de génération de maquettes, sans étapes d'analyse ni recommandations.</file_output>
</instructions>

### Validation Pré-Génération

Avant de générer le prompt, vérifier :
✅ Documents analysés : Branding, customer discovery, logo traités
✅ Inputs complets : Éléments essentiels extraits (couleurs codes exacts, typos nommées, valeurs, insights)
✅ Cohérence : Bénéfices alignés pain points
✅ Faisabilité : Structure adaptée secteur + maturité MVP
✅ Spécificité : Instructions précises pour l'outil de génération de maquettes
✅ Contexte africain : Éléments marché cible intégrés
✅ CTA défini : Call-to-action principal clair

## Historique

- v2, 23/09/2026 : contrôle en tête (un brief n'est pas une page ; une page demandée se remet en
  HTML et en lien publié selon `sitecraft-ai`), tirets cadratins retirés, séance Sync agents
  training.
