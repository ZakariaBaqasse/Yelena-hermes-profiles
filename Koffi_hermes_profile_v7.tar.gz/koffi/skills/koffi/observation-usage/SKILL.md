---
id: Y0422
name: observation-usage
description: "Organise et exploite une observation courte d'utilisateurs réels quand on ne peut pas la mener soi-même : écrit le protocole que le commanditaire exécute en une demi-journée, puis transforme ce qui remonte en constats situés et en décisions de conception — sans jamais transformer une observation en statistique ni combler par un usage supposé."
bucket: B
tags: [Design, Produit, Qualité, Nouveau]
version: 1
maj: 2026-08-13
---

# Observer l'usage réel, quand on ne peut pas le faire soi-même

## Ce qu'il faut avoir sous la main
- **La tâche à observer** — pas l'écran, la chose que la personne vient faire.
- **Qui peut être observé**, combien de personnes, et qui mènera l'observation.
- **Où et quand** cela se passe dans la vraie vie : au comptoir, en déplacement, en fin de journée.
- **Ce que tu as déjà** : retours de terrain, tickets, remarques d'équipe, même informelles.

## Process
### Étape 1 — Une tâche, pas une démonstration

L'observation porte sur une tâche que la personne ferait de toute façon aujourd'hui. On ne lui fait pas visiter le produit et on ne lui demande pas son avis sur le design : on la regarde travailler et on note ce qui se passe.

### Étape 2 — Écrire le protocole en une page

Le lieu, le moment, la durée par personne — quinze minutes suffisent —, la phrase exacte d'introduction, et la seule règle que l'observateur doit tenir : **ne pas aider**. C'est la consigne la plus difficile et la plus importante ; un observateur qui montre où appuyer efface précisément ce qu'on était venu voir.

Trois questions, pas plus, posées à la fin et jamais pendant : qu'attendiez-vous à ce moment-là, qu'avez-vous fait quand ça n'a pas marché, à qui en parlez-vous quand ça bloque.

### Étape 3 — Dire quoi noter

Ce qui se note : le geste, l'hésitation, le contournement, le moment où la personne quitte l'écran pour faire autre chose, ce qu'elle dit à voix haute, et le temps réel d'une opération. Ce qui ne se note pas : les opinions sur les couleurs.

Une photo de l'appareil et de son écran vaut trois lignes de compte rendu — et elle donne aussi le modèle, la luminosité et l'état de la connexion, qu'on n'aurait pas pensé à demander.

### Étape 4 — Restituer chaque constat situé

Un constat porte qui, quand, où, et ce qui a été vu. « Deux commerçants sur trois, le 12 août, au comptoir, ont demandé le montant au client une deuxième fois pendant le chargement » est exploitable. « Les utilisateurs trouvent l'application lente » ne l'est pas, et n'a pas été observé — c'est une interprétation.

### Étape 5 — Traduire en décisions, en gardant la trace

Chaque décision de conception nomme le constat qui la porte. Une décision sans constat rattaché est une préférence, et elle doit s'assumer comme telle plutôt que s'abriter derrière l'observation.

### Étape 6 — Dire ce que trois personnes ne prouvent pas

Trois observations montrent l'existence d'un problème ; elles ne mesurent pas sa fréquence. Ce qui appelle un chiffre va aux statistiques d'usage, et le rapport le dit à la place de laisser croire.

## Format de sortie
- **Livrable 1** : le protocole, une page — lieu, durée, phrase d'introduction, consigne de non-assistance, quoi noter, les trois questions de fin.
- **Livrable 2**, après terrain : les constats situés, groupés par moment du parcours, chacun avec sa preuve ; puis les décisions de conception, chacune rattachée à son constat ; puis ce que l'observation ne permet pas de conclure.
- **Longueur** : le protocole tient sur une page ou il ne sera pas suivi.

## Règles
1. **On observe une tâche réelle, jamais une démonstration.**
2. **L'observateur n'aide pas.** C'est la règle qui fait la valeur du reste.
3. **0 statistique tirée d'une observation.** Trois personnes ne font pas un pourcentage, et un pourcentage tiré de trois personnes circule ensuite sans son échantillon.
4. **Un constat porte sa situation** — qui, quand, où — ou ce n'est pas un constat.
5. **On ne comble pas les trous par l'usage supposé.** Ce qui n'a pas été observé n'est pas observé ; le dire coûte une ligne.
6. **Ce qu'on apprend d'une maison ne sert jamais d'exemple pour une autre.** Un usage observé ailleurs ne franchit pas la cloison, même comme ordre de grandeur.
7. **La personne observée sait qu'elle l'est et pourquoi**, et rien de ce qui l'identifie ne circule dans le rapport.

## Cas limites
- **Aucun utilisateur accessible** — observer les personnes de la maison qui parlent aux clients toute la journée, en le déclarant comme une source de seconde main.
- **Produit pas encore en service** — observer la tâche telle qu'elle se fait aujourd'hui, sans le produit. C'est souvent plus instructif.
- **Une seule personne observable** — cela vaut mieux que zéro ; le rapport le dit et n'en tire aucune généralité.
- **Constat qui contredit une décision déjà prise et coûteuse** — l'écrire quand même, avec la preuve, et laisser l'arbitrage à la maison.
- **Observation menée par la personne qui a conçu l'écran** — le signaler dans la portée : on n'observe pas neutralement son propre travail.
