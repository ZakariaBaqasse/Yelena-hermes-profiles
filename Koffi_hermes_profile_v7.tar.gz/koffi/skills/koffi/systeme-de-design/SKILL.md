---
id: Y0417
name: systeme-de-design
description: "Pose les fondations réutilisables d'un produit numérique — valeurs nommées par rôle, composants et leurs états, règles de composition et procédure d'évolution — pour qu'un produit se développe vite et cohérent au lieu que chaque écran soit redessiné à la main, sans jamais fabriquer une valeur de couleur, un espacement, une taille de cible ou un seuil de contraste."
bucket: B
tags: [Design, Produit, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Le système de design — les briques d'un produit numérique cohérent

## Ce qu'il faut avoir sous la main
- **Le produit** — site, application, les deux — et son stade : rien n'existe encore, ou il y a déjà des écrans dessinés à harmoniser.
- **La charte ou l'identité de marque** si elle existe déjà (couleurs, typographies, logo) — sinon dis-le, je pars des rôles à définir.
- **Les écrans ou parcours prioritaires** à couvrir en premier.
- **Le parc d'appareils réel** de tes utilisateurs si tu le connais : type de téléphones, qualité de connexion dominante.
- **La note typographique**, si elle existe déjà comme livrable séparé — je la reprends plutôt que de la refaire.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Nommer les valeurs par leur rôle, jamais par leur apparence

Établis la table des valeurs de base — couleurs, espacements, arrondis, épaisseurs de trait, niveaux d'élévation — et nomme chaque entrée par **ce qu'elle fait**, jamais par ce qu'elle est : fond de page, surface de carte, bordure, texte principal, texte secondaire, action, alerte, succès — pas « bleu clair », pas « gris 400 ». C'est le piège le plus structurant du métier : une valeur nommée par sa teinte devient un mensonge le jour où la marque change de couleur, et personne n'ose la renommer parce qu'elle est utilisée partout dans le produit.

Les valeurs elles-mêmes — code couleur, valeur en pixels ou en unité relative, épaisseur exacte — restent `⟦à renseigner⟧` tant qu'elles ne sont pas décidées par l'équipe design ou mesurées sur la charte existante. Tu livres la table des rôles vide plutôt qu'une table remplie de valeurs plausibles.

### Étape 2 — L'échelle typographique

Reprends l'échelle typographique de la note typographique existante si elle t'a été fournie — tu ne la refais pas, tu la cites et tu l'intègres au système. Si elle n'existe pas encore, signale que ce livrable en dépend et pose la structure attendue (rôles de taille : titre, sous-titre, corps, légende, bouton) avec les valeurs en `⟦à renseigner⟧`.

Vérifie un point souvent oublié : le comportement de la police si elle ne charge pas — la police de secours doit être choisie, sinon le texte disparaît visuellement pendant le chargement sur une connexion lente, ce qui est fréquent sur le terrain visé.

### Étape 3 — Les composants, du plus élémentaire au plus composé

Liste les composants en partant des plus simples — bouton, champ de texte, étiquette, case à cocher — vers les plus composés — carte, formulaire, barre de navigation, tableau. Pour chacun : son usage, ses variantes (tailles, priorités visuelles), et les valeurs de base qu'il consomme depuis la table de l'étape 1 — jamais de valeur propre inventée pour un composant isolé.

Résiste à l'envie de partir large. Un composant n'entre dans le système que s'il répond à un besoin déjà constaté dans les écrans prioritaires donnés au démarrage — pas à un besoin qu'on imagine pouvoir arriver.

### Étape 4 — Chaque état, y compris le cas vide

Pour chaque composant interactif, décris le rendu à l'état **au repos**, **survolé**, **actif**, **désactivé**, **en cours de chargement**, **en erreur**, et pour les composants qui affichent une liste ou des données, le **cas vide**. Un bouton dessiné seulement au repos produit une interface où l'utilisateur ne sait jamais s'il a cliqué, si le système travaille, ou si l'action a échoué — et sur une connexion lente, l'état « en cours » n'est pas un raffinement, c'est ce qui empêche d'appuyer cinq fois de suite.

Le cas vide est le plus oublié et le plus visible en réalité : un écran conçu avec des données de démonstration se présente très mal le premier jour d'usage réel, quand il n'y a encore rien à afficher. Décris ce que voit l'utilisateur — pas un cadre gris muet, mais une explication de pourquoi c'est vide et ce qu'il peut faire.

### Étape 5 — Concevoir depuis la petite largeur, et prévoir le dégradé

Conçois d'abord pour le plus petit écran, pas pour le grand écran de bureau confortable où tu travailles. Sur un parc dominé par des téléphones d'entrée de gamme et une connexion payée à la donnée, un écran conçu large se replie mal une fois réduit.

Prévois explicitement le comportement dégradé : ce que voit quelqu'un dont les images ne chargent pas (une forme ou une couleur de remplacement, jamais un vide muet), dont la police distante ne charge pas (la police de secours de l'étape 2), dont la connexion coupe en cours de chargement (ce qui reste visible, ce qui se recharge, ce qui informe que ça a échoué). Ce n'est pas un cas limite technique — c'est une situation fréquente qu'il faut concevoir, pas subir.

### Étape 6 — Cibles tactiles et information qui ne dépend pas de la seule couleur

Traite la taille et l'espacement des zones cliquables comme une contrainte du système, pas comme un détail d'implémentation. Ce qui se clique confortablement à la souris ne s'atteint pas au pouce, encore moins sur un écran fêlé ou avec les mains occupées. Demande la valeur minimale au référentiel d'accessibilité retenu par l'équipe (par exemple un référentiel du type WCAG, à confirmer selon ce que l'organisation applique) plutôt que de l'inventer — ici aussi, la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas tranchée.

Vérifie ensuite que chaque statut ou information critique n'est jamais porté par la seule couleur : un badge de statut coloré doit porter aussi une forme, un mot ou une icône, sinon il disparaît pour une partie des utilisateurs, à l'impression d'un écran, ou sous forte luminosité — une situation courante en plein soleil.

### Étape 7 — Les règles de composition

Pose la grille, les largeurs de lecture, et le comportement du système aux différentes largeurs d'écran — quels éléments se réempilent, lesquels disparaissent, lesquels se transforment en menu replié. Le point de départ reste la petite largeur définie à l'étape 5 ; les largeurs supérieures sont des enrichissements, jamais le point de départ de la réflexion.

### Étape 8 — Les textes d'interface

Rassemble les libellés de boutons, les messages d'erreur, les textes des cas vides et les confirmations d'action comme partie du système — pas comme un remplissage écrit en dernier. Un message d'erreur qui ne dit pas quoi faire ensuite annule le travail visuel de tout l'écran. Rappelle que le français est probablement la langue écrite du produit, mais que les échanges oraux ou informels de l'équipe et des utilisateurs peuvent se faire dans une langue nationale — un texte d'interface doit rester compris sans détour, sans jargon transposé du français administratif.

### Étape 9 — Procédure d'ajout d'un composant, et gouvernance

Termine par la règle qui empêche le système de gonfler ou de mourir : qui peut proposer un composant nouveau, sur quelle preuve de besoin réel (un écran prioritaire qui en a besoin, pas une envie), et qui l'approuve avant qu'il entre au catalogue. Un système de quarante composants dont six servent coûte plus qu'il ne rapporte ; la procédure d'ajout est ce qui garde le système utile dans le temps, pas un supplément administratif.

## Format de sortie
- **Livrable** : le système de design — table des valeurs nommées par rôle (couleurs, espacements, arrondis, épaisseurs, élévations, valeurs en `⟦à renseigner⟧`), échelle typographique reprise de la note existante, liste des composants avec usage et variantes, rendu de **chaque état** pour chaque composant interactif (y compris chargement, erreur, cas vide), règles de composition et comportement aux différentes largeurs, textes d'interface types, procédure d'ajout d'un composant et personne qui l'approuve.
- **Structure** : Markdown clair — answer-first (la table des rôles et la liste des composants d'abord, le détail des états et la procédure ensuite) ; tableaux pour les valeurs et les états, listes pour le reste.
- **Longueur** : proportionnée au périmètre couvert au démarrage. Un système qui couvre les écrans prioritaires annoncés, pas un catalogue exhaustif imaginé à l'avance.
- **Règle 0 invention** : aucune valeur de couleur, aucune mesure d'espacement ou de taille de cible, aucun seuil de contraste n'est produit de mémoire. Chaque valeur vient de la charte fournie, d'une mesure faite avec un outil, du référentiel nommé, ou reste `⟦à renseigner⟧`.

## Règles
1. **Le nom porte le rôle, jamais l'apparence.** Une couleur, un espacement ou une épaisseur se nomme par ce qu'il fait dans l'interface, pas par sa teinte ou sa valeur brute. Tu le rappelles chaque fois qu'une entrée risque d'être nommée par son apparence.
2. **0 valeur chiffrée inventée.** Couleur, espacement, arrondi, taille de cible tactile, seuil de contraste : aucune valeur n'est produite sans être fournie, mesurée, ou tirée d'un référentiel nommé. `⟦à renseigner⟧` sinon — y compris quand la valeur paraît standard ou universelle dans le métier.
3. **Chaque composant interactif a tous ses états décrits**, y compris chargement, erreur et cas vide. Un composant livré avec seulement son état au repos est un livrable incomplet, pas un raccourci acceptable.
4. **On conçoit depuis la petite largeur et la connexion faible.** Le comportement dégradé — images absentes, police de secours, connexion coupée — est décrit explicitement, pas laissé à l'improvisation de l'implémentation.
5. **La couleur n'est jamais le seul porteur d'une information critique.** Un statut s'accompagne d'une forme, d'un mot ou d'une icône.
6. **Le système grossit par besoin constaté, pas par anticipation.** Un composant n'entre au catalogue que s'il répond à un écran prioritaire réel ; la procédure d'ajout et son approbateur sont toujours précisés.
7. **Les textes d'interface font partie du système.** Ils ne sont ni écrits en dernier ni laissés à l'improvisation ; les messages d'erreur disent quoi faire ensuite.
8. **Le contexte local n'est pas un décor.** Le parc d'appareils réel, le coût de la donnée, la lecture en plein soleil et la cohabitation du français écrit avec les langues nationales à l'oral changent les décisions de composition — un système pensé pour un contexte tout-numérique et grand écran ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; publier le système, l'imposer aux équipes de développement ou remplacer un système existant est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un produit ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les valeurs manquantes `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune charte de marque fournie** — tu produis la table des rôles vide de valeurs, tu marques le livrable comme fondation à valider avec l'équipe de marque, et tu ne proposes jamais de teinte ou de valeur à sa place.
- **Note typographique absente** — tu signales la dépendance, tu poses la structure attendue de l'échelle avec les valeurs en `⟦à renseigner⟧`, et tu n'inventes pas de tailles.
- **Écrans déjà dessinés à harmoniser** — tu extrais les composants et valeurs déjà en usage plutôt que d'en inventer de nouveaux, et tu signales les incohérences trouvées (même valeur nommée différemment, même rôle rendu par deux valeurs).
- **Référentiel d'accessibilité non précisé** — tu demandes lequel l'équipe retient, tu laisses la valeur de taille de cible ou de contraste en `⟦à renseigner⟧`, tu ne choisis jamais de valeur à sa place.
- **Demande hors périmètre** (un composant unique isolé, une refonte de marque complète) — tu le dis en une phrase, tu traites ce qui relève du système, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (publication du système, diffusion aux équipes externes) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions de la charte, deux échelles typographiques) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
