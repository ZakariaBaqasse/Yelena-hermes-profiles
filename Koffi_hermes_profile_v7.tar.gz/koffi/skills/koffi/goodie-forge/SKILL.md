---
id: Y0159
name: goodie-forge
description: "Crée des visuels de goodies brandés print-ready en cohérence stricte avec la charte de l'entreprise, et valide le branding avant toute génération. Contrôle avant remise OBLIGATOIRE : liste proposée depuis le catalogue complet des objets courants (badges, tours de cou, bracelets, casquettes, carnets, sacs en toile, tee-shirts, sweats, mugs, gourdes, autocollants, stylos), trois typologies (professionnelle, amusante, moderne), logo dimensionné sur sa zone de protection et jamais sur la place disponible, rendu qui n'est pas plat."
bucket: D
tags: [Design]
version: 2
maj: 2026-09-23
---

# GoodieForge

## ⛔ Contrôle avant remise, obligatoire (22/09 puis 23/09/2026)

Les consignes du 22/09 (objets plus variés, trois typologies, logo à sa taille) vivaient dans
`production-visuelle-livrable` et ne se sont pas appliquées : les objets restent ce qui sort le
moins bien. Elles sont ici, dans la compétence chargée pour les goodies. Avant d'envoyer, tu
vérifies que :

1. **la liste proposée part du catalogue complet** plus bas (section « Catalogue goodies »), et
   pas des trois objets qui viennent en tête : tu proposes ceux qui servent l'usage (équipe,
   stand, cadeau client, vente), le client choisit ;
2. **les trois typologies sont là**, professionnelle, amusante et moderne, et elles diffèrent
   par le registre, pas par la couleur de fond (tableau dans `production-visuelle-livrable`) ;
3. **le logo est dimensionné sur sa zone de protection**, jamais grossi pour remplir l'objet. Un
   logo qui déborde ou écrase l'objet : tu ne remets pas ;
4. **le rendu n'est pas plat** : matière, ombre, perspective, le design épouse l'objet
   (référence du poste en étape 3) ;
5. **aucune dimension ni technique de marquage inventée** : elles viennent du fabricant retenu,
   sinon elles sont marquées `⟦à renseigner⟧`.

Un point en échec : tu corriges avant d'envoyer.

## Ce qu'il faut avoir sous la main
1. **Nom + secteur** de la startup
2. **Tagline officielle** (mot pour mot, telle qu'elle doit apparaître)
3. **URL du site** officiel
4. **Logo** (PNG/SVG/PDF) + charte graphique si dispo
5. **Inspiration** (photo, lien, moodboard : optionnel)
6. **Goodies souhaités** : ☐ T-shirt ☐ Mug ☐ Tote bag ☐ Sticker ☐ Hoodie ☐ Notebook ☐ Casquette ☐ Stylo ☐ Autre
7. **Usage prévu** : ☐ Équipe interne ☐ Événement/Conférence ☐ Cadeau client ☐ Vente/Merch

Je détecte le branding, je te le fais **valider**, puis je produis les mockups. Rien n'est généré avant ta validation.

> Lancé à l'invocation (pas de génération planifiée en tâche de fond).

### Startup avec / sans identité graphique

- **Avec identité** : récupérer les vrais assets, faire valider le branding récupéré, ne RIEN inventer.
- **Sans identité** : proposer une direction créative (palette, typo, style) et la faire valider AVANT toute génération.


**Ce qu'elle suppose comme accès** : Registre du portefeuille, Base de connaissances / guidelines visuelles, Stockage documentaire, Outil de design / brand kit, Génération d'images. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Collecter** le branding (séquence de détection).
2. **Valider** avec l'utilisateur (récap obligatoire), attendre confirmation.
3. **Planifier** la liste des goodies + specs.
   🚨 **La liste se PROPOSE au client, et c'est lui qui choisit lesquels générer** (09/09/2026).
   Elle se tire du catalogue complet ci-dessous, et chaque objet retenu se propose dans les
   trois typologies (professionnelle, amusante, moderne).
   Jamais la planche entière de ma propre initiative.
   ⛔ **Le niveau attendu, « rien de plat » : `memory/reference/mockups-goodies.md`**, à ouvrir
   avant de composer. Studio sur fond uni ou objet dans une scène réelle, les deux conviennent.
   Ce qui fait le niveau : ombre portée cohérente, légère perspective, le design qui COUVRE
   l'objet et épouse sa matière, le motif de la marque décliné dessus, deux ou trois objets en
   profondeur. Le logo plaqué à plat au centre d'un objet sans matière est ce qui est refusé.
   La matière se cherche d'abord au catalogue stock de Magnific et chez Pexels.
4. **Brief visuel** par goodie (style, placement, couleurs, message, format) avant de générer.
5. **Générer le mockup** `[connecteur à brancher : génération d'images]`, visuel réaliste en contexte. Communiquer OBLIGATOIREMENT : *« Ce mockup est une illustration d'ambiance ; le logo y est approximatif, limite des outils de génération d'image. »* ❌ Ne jamais le présenter comme le rendu final conforme à la charte.
6. **Organiser** dans le stockage (structure ci-dessous).
7. **Récapituler** (tableau final).

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ❌ Ne jamais redessiner/modifier/réinterpréter le logo.
- Logo absent → le demander avant toute génération.
- ⚠️ Un outil de génération d'image ne peut pas reproduire le logo à l'identique, le logo dans un mockup IA sera toujours approximatif (limite des modèles de diffusion, pas un bug).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** : tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Détection du branding : séquence stricte

1. Chercher dans le **stockage documentaire** : logo, charte, palette, typographies. `[connecteur à brancher : stockage documentaire]`
2. Vérifier un **brand kit d'outil de design** (couleurs HEX, typos, logo) + un **template de merch/goodie** existant → l'utiliser comme base plutôt que partir de zéro. `[connecteur à brancher : outil de design / brand kit]`
3. Chercher dans la **base de connaissances** : guidelines visuelles, palette, charte.
4. Chercher sur le **site officiel** : logo, couleurs dominantes, typos.
5. Rien trouvé → **demander explicitement** les éléments manquants.

❌ **JAMAIS inventer** des éléments de branding si la startup a une identité existante.

### Validation branding : obligatoire avant génération

Présenter un récap à valider :
```
✅ VALIDATION BRANDING, [Startup]
🎨 Principale : [hex] · Accent : [hex] · Secondaire : [hex]
🔤 Titres : [Police] · Corps : [Police]
💬 Tagline : "[tagline]"
🖼️ Logo : [✅ fourni | ❌ non fourni]
👉 Corrects avant que je génère les goodies ?
```
❌ Ne jamais générer sans validation explicite sur ce récap.

### Catalogue goodies & spécifications

Les cotes ci-dessous sont des repères de départ : la zone de marquage réelle et la technique
(broderie, sérigraphie, gravure, impression) se confirment auprès du fabricant retenu avant
tout fichier final. Pour un objet sans cote ici, la zone est `⟦à renseigner⟧` par le fabricant.

Les objets d'entreprise les plus courants, à couvrir tous (demandé le 23/09/2026) :

- **Badge** : porte-nom d'événement ou d'équipe, recto seul ou recto verso ; nom lisible à
  distance de conversation, logo en retrait. Zone : `⟦à renseigner⟧`.
- **Tour de cou** : bande tissée ou imprimée, motif répété sur la longueur ; le logo se répète,
  il ne s'étire pas. Zone : `⟦à renseigner⟧`.
- **Bracelet** : tissu, silicone ou papier d'événement ; surface étroite, donc symbole seul ou
  mot court. Zone : `⟦à renseigner⟧`.
- **Gourde ou bouteille** : surface courbe, le visuel se contrôle sur l'objet en volume, pas à
  plat. Zone : `⟦à renseigner⟧`.
- **Stylo** : surface minuscule, symbole seul ou nom en une ligne. Zone : `⟦à renseigner⟧`.
- **Autocollant, carnet, sac en toile, casquette, tee-shirt, sweat, mug** : repères ci-dessous.

- **T-shirt** : recto (30×40cm) et/ou verso, fond blanc ou brand, visuel centré poitrine ou poche gauche.
- **Mug** : wrap-around (20×9cm) ou face (9×9cm), full-color ou monotone.
- **Tote bag** : 38×42cm, grand format, fort impact.
- **Sticker** : rond (5/7/10cm), carré, die-cut ; fond transparent possible.
- **Hoodie** : poitrine (25×25cm) et/ou dos (35×45cm), couleur brand.
- **Notebook** : couverture A5 (14,8×21cm), pleine couverture ou logo centré.
- **Casquette** : broderie frontale (6×5cm max), logo simplifié < 5 couleurs.

### Style de prompt par usage

- **Événement** → dynamique, couleurs vives, slogan court percutant.
- **Équipe interne** → sobre, logo centré, cohérence brand.
- **Cadeau client** → premium, minimaliste, tagline mémorable.
- **Vente/Merch** → visuel fort, identitaire, streetwear/lifestyle selon le secteur.

### Organisation du stockage

```
Goodies_[Startup]/
├── T-shirt/ (Recto/ Verso/)
├── Mug/  ├── Tote_Bag/  ├── Stickers/
├── Hoodie/  ├── Notebook/  └── Autres/
```
Nommage : `[Startup] - [Goodie] - [Version] - [AAAA-MM-JJ]`.

### Résumé final obligatoire

Tableau : Goodie | Format | Fichier | Emplacement | Statut (Généré / À revoir / Validé).

## Historique

- v2, 23/09/2026 : contrôle avant remise obligatoire en tête (catalogue complet, trois
  typologies, logo sur sa zone de protection, rendu qui n'est pas plat, aucune cote inventée),
  objets courants ajoutés au catalogue (badge, tour de cou, bracelet, gourde, stylo), tirets
  cadratins retirés, séance Sync agents training.
