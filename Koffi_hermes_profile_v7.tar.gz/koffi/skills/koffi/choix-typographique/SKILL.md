---
id: Y0414
name: choix-typographique
description: "Recommande une police à une entreprise puis l'échelle typographique complète qui en découle : usages réels du texte, couverture des caractères testée sur un échantillon, état de la licence lu dans son fichier, nombre de familles limité, table de rôles nommés avec repli — sans jamais citer de valeur de corps, d'interligne ou de licence de mémoire."
bucket: B
tags: [Design, Marque, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Choisir une police — et l'échelle qui va avec

## Ce qu'il faut avoir sous la main
- **Où ce texte va vivre** : écran seul, document imprimé, enseigne, broderie, sous-titres vidéo, document administratif — liste tout ce qui s'applique.
- **Les langues et signes à couvrir** : le français avec ses accents, et toute langue nationale écrite avec des caractères latins étendus.
- **Un échantillon de texte réel** : quelques titres, un paragraphe courant, des noms propres — de préférence ceux qui posent déjà problème.
- **Ce que tu as déjà** : nom de la ou des polices envisagées, fichier de licence s'il existe, charte graphique existante.
- **La contrainte d'installation** : la police doit-elle tourner sur les postes de toute l'équipe, chez un imprimeur, ou seulement se charger sur un site.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier où le texte va vivre

Liste tous les supports annoncés et classe-les selon ce qu'ils exigent réellement : un écran tolère des graisses fines et des détails serrés, une impression d'entrée de gamme les efface, une enseigne se lit à distance et en mouvement, une broderie interdit les fins traits et les empattements trop fins, un sous-titre vidéo doit rester lisible en compression forte. Si les supports annoncés ont des exigences contradictoires — une police pensée pour l'écran et imposée telle quelle sur une enseigne —, tu le signales avant de recommander quoi que ce soit : c'est souvent le signe qu'il faut deux familles, ou une seule mais pas dans la graisse envisagée.

### Étape 2 — Poser les contraintes dures avant toute préférence

Trois contraintes ne se négocient pas et se posent avant le goût : les langues et caractères à couvrir, les graisses réellement nécessaires (une pour le corps, une pour les titres, éventuellement une pour l'emphase — pas plus que ce que l'usage exige), et le mode de diffusion — installée sur des postes, embarquée dans un document, chargée par un site, gravée chez un prestataire. Une police qui coche tout sauf la diffusion prévue n'est pas un candidat valable, même si elle plaît.

### Étape 3 — Le test de couverture des caractères, avant toute recommandation

C'est le piège le plus coûteux de la région, et il ne se voit pas à l'écran de celui qui choisit. Beaucoup de polices gratuites, y compris très diffusées, couvrent mal le français hors des mots courants — des majuscules accentuées absentes, des signes manquants — et couvrent souvent moins bien encore les caractères latins étendus utilisés pour écrire les langues nationales. Le défaut reste invisible tant qu'on compose des minuscules ordinaires ; il éclate au premier titre tout en capitales ou au premier mot en langue nationale, qui s'affiche avec un caractère de substitution ou un signe manquant.

Compose donc l'échantillon fourni par l'entreprise — pas un texte de démonstration générique — dans chaque police candidate, en capitales et en bas de casse, et vérifie chaque signe un par un. Une police qui échoue ce test sort de la liste, quelle que soit sa qualité par ailleurs. Un test réalisé après le choix n'a validé qu'une préférence, pas une police.

### Étape 4 — L'épreuve en conditions réelles de lecture

Une police se juge dans les conditions où elle va réellement être lue, pas sur une maquette propre en plein écran. Simule : petit écran d'entrée de gamme, luminosité forte comme en plein soleil, impression sur papier ordinaire chez un prestataire aux moyens limités, photocopie, capture d'écran renvoyée sur une messagerie et recompressée. Une graisse fine qui paraît élégante en maquette peut disparaître à l'impression ou devenir illisible en plein jour — c'est précisément le type d'échec qui ne se voit qu'à ce stade, jamais avant.

### Étape 5 — La licence, lue et jamais récitée de mémoire

Tu n'énonces jamais ce qu'une licence autorise de tête, même pour une famille de licence que tu crois connaître — les permissions varient d'une fonte à l'autre à l'intérieur d'une même famille de licence. Le seul texte qui fait foi est le fichier de licence livré avec la police. Tant qu'il n'a pas été lu, chaque usage sensible reste marqué `⟦à vérifier dans le fichier de licence⟧` : incorporation dans un logo, cession du fichier à un prestataire ou un imprimeur, broderie, redistribution à toute l'équipe. L'usage qui pose problème n'est presque jamais l'affichage sur un site — c'est l'un de ceux-là.

### Étape 6 — Trancher le nombre de familles

Deux familles suffisent presque toujours, souvent une seule bien déclinée en graisses. Chaque famille supplémentaire est un coût permanent : à installer sur chaque poste, à transmettre à chaque prestataire, à substituer quand elle manque quelque part dans la chaîne. Une identité qui repose sur trois familles ou plus se dégrade dès le premier document produit par quelqu'un d'autre que celui qui l'a choisie. Si l'entreprise pousse vers trois familles ou davantage, tu le dis explicitement et tu demandes ce que chaque famille supplémentaire apporte que les deux premières ne couvrent pas.

### Étape 7 — Construire l'échelle nommée par rôle, jamais par valeur brute

Une échelle en tailles brutes n'est pas transmissible : personne ne sait quelle taille appliquer à quel texte. Nomme chaque rôle — titre principal, titre de section, chapô, corps, légende, mention — et donne à chacun son corps, sa graisse, son interligne et son interlettrage. Tu ne poses jamais une taille sans le rôle qu'elle sert. Quand aucun référentiel de marque ou aucune mesure n'existe encore pour fixer ces valeurs, tu laisses `⟦à renseigner⟧` plutôt que de proposer un chiffre qui paraît raisonnable : un corps de texte minimal, un interlignage, une taille de titre sont des décisions d'équipe ou des mesures d'outil, jamais des souvenirs de métier.

### Étape 8 — Le repli et la procédure de transmission

Une police qui ne s'installe pas chez un prestataire, qui ne se charge pas sur un site en coupure réseau, ou que l'imprimeur n'a pas au catalogue, doit avoir un remplaçant déjà désigné — pas improvisé le jour où le problème survient. Un document qui perd sa police ne perd pas seulement son style : les sauts de ligne, la pagination et les gabarits bougent avec elle. Documente aussi la procédure concrète de transmission — quel fichier envoyer, sous quelle forme, à qui, en gardant à l'esprit que WhatsApp reste souvent le canal réel de circulation des fichiers et des aperçus entre l'entreprise et ses prestataires.

## Format de sortie
- **Livrable** : la note de recommandation typographique — famille(s) retenue(s) avec la raison rapportée aux usages réels, résultat du test de couverture des caractères sur l'échantillon fourni, état de la licence avec sa source (le fichier lu, ou `⟦à vérifier dans le fichier de licence⟧` sinon), graisses effectivement disponibles, police de repli désignée. Puis la table de l'échelle : une ligne par rôle de texte (titre principal, titre de section, chapô, corps, légende, mention), avec corps, graisse, interligne, interlettrage — `⟦à renseigner⟧` pour toute valeur non fournie ni mesurée. Puis la procédure d'installation et de transmission à un prestataire.
- **Structure** : Markdown clair, answer-first — la recommandation d'abord, la table ensuite, la procédure en dernier. Tableaux pour l'échelle et pour le résultat du test de couverture.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune valeur de corps, d'interligne, d'interlettrage, de licence ou de résolution n'est produite de mémoire. Si une information manque, elle est demandée ou marquée `⟦à renseigner⟧` / `⟦à vérifier dans le fichier de licence⟧`.

## Règles
1. **Le test de couverture des caractères précède la recommandation, jamais l'inverse.** Une police qui échoue sur l'échantillon réel de l'entreprise — capitales accentuées, signes des langues nationales — sort de la liste, quelle que soit sa réputation.
2. **Aucune licence n'est citée de mémoire.** Seul le fichier de licence livré avec la police fait foi. Tant qu'il n'est pas lu, l'usage sensible reste `⟦à vérifier dans le fichier de licence⟧`.
3. **Deux familles au maximum, sauf justification explicite.** Chaque famille supplémentaire est un coût permanent à installer, transmettre et suppléer ; elle se justifie par un usage que les familles existantes ne couvrent pas, pas par la préférence.
4. **Aucune taille n'est posée sans le rôle qu'elle sert.** L'échelle se nomme par rôle de texte, jamais par valeur brute isolée.
5. **Aucune valeur chiffrée n'est produite de mémoire** — corps de texte, interligne, interlettrage, résolution d'impression, poids de fichier, valeur de couleur : elles viennent d'un référentiel nommé, d'une mesure faite avec un outil, ou de l'équipe. Sinon, `⟦à renseigner⟧`.
6. **Le choix se valide en conditions réelles**, pas sur une maquette propre : petit écran, forte luminosité, impression d'entrée de gamme, photocopie, capture recompressée. Une police jugée seulement en maquette n'a pas été jugée.
7. **Un repli est toujours désigné.** Aucune recommandation ne se rend sans une police de remplacement identifiée pour les cas où la principale ne s'installe pas, ne se charge pas ou n'existe pas chez le prestataire.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; acheter une licence, installer une police sur des postes ou l'envoyer à un prestataire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une marque ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun échantillon de texte fourni** — tu le signales et tu proposes de construire l'échantillon à partir des noms propres, titres et langues mentionnés par l'entreprise, en marquant le test de couverture comme provisoire tant qu'il n'a pas tourné sur un texte réel.
- **Fichier de licence absent ou introuvable** — tu ne recommandes pas l'usage sensible concerné (logo, broderie, cession à un prestataire, redistribution) et tu marques `⟦à vérifier dans le fichier de licence⟧` plutôt que de supposer une permission.
- **Une pièce annoncée mais absente** (« voici la charte », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Prestataire ou imprimeur qui n'a pas la police au catalogue** — tu traites ça comme un scénario de repli à documenter, pas comme un détail secondaire.
- **Tutelle publique ou cahier des charges imposant une police officielle** — tu le signales, tu composes l'échelle autour de cette contrainte, et tu ne proposes pas une alternative comme si le choix restait ouvert.
- **Langue nationale mal ou pas couverte par la police candidate** — tu le dis explicitement dans le résultat du test, même si le reste de la couverture est bon, et tu ne classes pas la police comme validée pour cet usage.
- **Demande hors périmètre** (identité de marque complète, palette de couleurs, logo) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (achat de licence, envoi du fichier à un tiers, installation sur des postes) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux fichiers de licence différents pour la même police, chartes existantes qui se contredisent) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
