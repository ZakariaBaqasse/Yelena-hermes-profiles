---
id: Y0463
name: refonte-de-site-sans-perte
description: "Refait ou retouche un site sans lui faire perdre en route ce qui le rendait trouvable et utilisable : hiérarchie des titres tenue par le HTML et non par la taille du texte, images dimensionnées, allégées et réellement utilisées, logos de partenaires en vraie version officielle plutôt qu'en icône recadrée ou recolorée, formulaires qui envoient vraiment au lieu d'afficher une confirmation, page d'erreur écrite, avec un relevé avant et après pour prouver que rien n'a été perdu."
bucket: B
tags: [Design, Web, Horizontal, Nouveau]
version: 1
maj: 2026-09-02
---

# Refonte de site : ne rien perdre en route

## Ce qu'il faut avoir sous la main
- **L'adresse du site**, ou les fichiers si la refonte n'est pas encore en ligne.
- **Ce qui a changé récemment** et qui y a touché, si tu le sais.
- **Ce que le client attend du site** : faire venir en boutique, faire remplir un formulaire, faire appeler.
- **Les visuels et logos** dont tu disposes, et lesquels viennent d'une source officielle.
- **Qui met en ligne**, et avec quel outil.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), et tu ne redemandes que ce qui est réellement indispensable.

## Process

### Étape 1 : le relevé, avec un seul programme pour les deux versions
Deux relevés faits avec deux outils différents ne comparent que les outils. Le même programme passe sur l'avant et sur l'après, et note page par page :
- la **hiérarchie des titres** : un seul titre de premier niveau, aucun saut de niveau ;
- chaque **image** : dimensions déclarées, texte de remplacement présent, chargement différé, poids ;
- les **fichiers livrés qu'aucune page n'affiche** ;
- la présence d'une **page d'erreur** et d'un **plan du site**, et sa date ;
- le poids total de ce qui est expédié.

### Étape 2 : la hiérarchie des titres, que le visuel casse presque toujours
Un titre de section a une taille parce qu'il est un titre, il n'est pas un titre parce qu'il a une taille. Quand une maquette enchaîne un grand titre puis des cartes, les cartes se retrouvent souvent en troisième niveau juste après le premier : le palier intermédiaire manque, et le plan de la page devient illisible pour un lecteur d'écran comme pour un moteur.
**Ne dégrade pas un niveau pour combler le trou**, tu casserais le rendu. Pose le palier manquant en titre **masqué visuellement mais lu** par les lecteurs d'écran. Le rendu ne bouge pas d'un pixel, le plan redevient juste.

### Étape 3 : les images
- **Chaque image porte ses dimensions** dans le HTML. Sans elles, la page saute pendant le chargement, et ce saut est mesuré et pénalisé.
- **Un texte de remplacement vide est correct** sur une image purement décorative, à condition que son rôle soit déjà porté à côté. C'est une décision, pas un oubli : ne confonds pas un texte vide volontaire avec un attribut absent.
- **Les images qu'aucune page n'affiche** sont des restes de maquettes précédentes. Elles peuvent représenter la moitié du poids expédié. Cherche le nom de chaque fichier dans tout ce qui est réellement servi, et retire ce qui n'y apparaît jamais. Vérifie d'abord qu'aucun script ne construit un nom de fichier morceau par morceau, sinon tu supprimerais une image bel et bien utilisée.

### Étape 4 : les logos de partenaires
Trois fautes, toujours les mêmes, et le client les voit immédiatement parce que ce sont ses partenaires.
- **L'icône n'est pas le logo.** L'icône ronde d'une application n'est pas le logotype de la marque. Va chercher la version complète.
- **Le logo du groupe n'est pas celui de la marque.** Le site institutionnel d'un groupe sert souvent le logo du groupe, pas celui de la filiale ou du service avec qui le client travaille. Regarde ce que tu as téléchargé avant de le poser.
- **Un logo recoloré ne réagit plus.** Si le mur de logos est en noir et blanc au repos et retrouve ses couleurs au survol, un logo qu'on a recoloré en teinte unique ne change rien au survol, et ça se remarque. Garde les couleurs officielles.

Sources par ordre de fiabilité : le site officiel de la marque, puis sa page professionnelle officielle, puis une banque de médias libres. Regarde toujours le fichier **rendu sur fond clair et sur fond sombre** avant de l'intégrer : un logo blanc sur fond transparent paraît vide sur une planche blanche. Cadre-les tous dans la même boîte, centrés, pour que le mur ait un rythme régulier.

🪲 Un logo servi par une plateforme professionnelle arrive souvent sur un **fond blanc opaque**, pas transparent. Son cadre utile couvre alors toute l'image, et le recadrage automatique conserve un carré blanc avec la marque minuscule au centre. Rends le blanc transparent **avant** de mesurer.

### Étape 5 : les formulaires, la page d'erreur, le reste
- **Un formulaire qui affiche une confirmation sans avoir rien transmis est le défaut le plus coûteux d'un site**, parce que personne ne le découvre : le visiteur croit avoir écrit, le client croit ne pas avoir de demandes. Vérifie où part réellement chaque formulaire. S'il pointe vers un service que l'hébergement n'utilise pas, ou vers une adresse absente, il ne transmet rien.
  Quand la destination n'est pas encore branchée, fais **dire** au formulaire qu'il ne peut pas enregistrer la demande et affiche le vrai moyen de contact. Un message honnête vaut mieux qu'une confirmation fausse.
- **Une page d'erreur écrite** évite qu'une adresse morte tombe sur la page vide de l'hébergeur. Elle est hors index et propose les chemins utiles.
- **Le plan du site porte une date** qui bouge à chaque mise en ligne, sinon il annonce que le site n'a pas changé depuis des mois.
- **Une ancienne adresse qui disparaît** garde une redirection vers la nouvelle. Un lien déjà partagé ne se rattrape pas.

### Étape 6 : remesurer
Repasse le programme de l'étape 1 et livre le tableau avant et après. Sans lui, une refonte se raconte, elle ne se prouve pas.

## Format de sortie
Un récapitulatif court : le tableau avant et après, puis ce qui a été corrigé en puces, chaque puce disant ce qui n'allait pas et ce que ça coûtait, puis ce qui reste à faire chez le client, écrit pas à pas.

## Règles
- **Ne réécris pas le contenu éditorial du client** sous couvert de correction technique. Si une tournure te gêne, signale-la, ne la change pas sans le dire.
- **Vérifie sur la page réellement servie**, pas sur ton fichier de travail. Une mise en ligne peut échouer, prendre du retard, ou servir une version en cache.
- **Un appel qui réussit ne prouve pas qu'il n'a rien détruit.** Avant de remplacer un fichier ou un bloc, demande-toi ce qui était rattaché à ce que tu remplaces.
- **Ne supprime jamais un fichier sur la foi d'une recherche de texte seule** sans avoir vérifié qu'aucun script ne compose son nom.
- **Un aperçu de travail se sert en interdiction d'indexation**, pour ne pas concurrencer le vrai site du client.

## Cas limites
- **Le client a annoté lui-même des fichiers** (couleurs, commentaires, notes). Relève ces marques avant toute reconstruction, applique ce qu'elles veulent dire, puis repose-les. Une reconstruction les efface sans avertissement.
- **Aucun logo officiel n'existe pour un partenaire.** Mets le nom en toutes lettres, dans la typographie du site, et signale-le. N'invente pas un logo, ne recadre pas une capture d'écran.
- **La refonte est faite par un prestataire extérieur.** Livre-lui le relevé avant et après plutôt qu'une liste de reproches : un tableau chiffré se discute, une opinion se conteste.
- **Le site est déjà en ligne et très visité.** Ne change pas les adresses des pages. Si une adresse doit disparaître, redirige-la et garde le lien vers la nouvelle.
