---
id: Y0413
name: signaletique-et-plv
description: "Conçoit le plan de signalétique et des supports de point de vente d'un lieu — enseigne, orientation intérieure, vitrine, affichage prix, présentoirs, tenue des équipes, véhicule — à partir du parcours réel de la personne dans le lieu, en vérifiant lisibilité, matériaux et autorisations, sans jamais inventer un tarif, une procédure communale ou une dimension réglementaire."
bucket: B
tags: [Design, Terrain, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Signalétique et supports de point de vente — orienter, rassurer, faire acheter

## Ce qu'il faut avoir sous la main
- **Le lieu et l'activité** : boutique, restaurant, agence, atelier, pharmacie — et ce qu'on y fait concrètement.
- **L'accès** : adresse ou quartier, rue passante ou secondaire, embouteillée aux heures de pointe, présence d'un parking, étage ou rez-de-chaussée, éclairage nocturne de la zone.
- **Le parcours de la personne** tel qu'il se passe aujourd'hui : par où elle entre, ce qu'elle cherche, où elle coince, où elle paie et ressort.
- **Ce qui existe déjà** : enseigne, vitrine, panneaux, tenue du personnel — et ce qui marche ou pas dans ce qui est en place.
- **Le budget et les contraintes connues** : ce qui est fixe (mur porteur, hauteur de plafond, dimensions imposées par le bailleur), ce qui est négociable.
- **Des photos ou un plan du lieu**, si tu les as — même pris au téléphone, même approximatifs.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Reconstituer le parcours réel, pas le plan du propriétaire

Pars de la rue, pas de l'intérieur du magasin. Décris le trajet dans l'ordre où la personne le vit : ce qu'elle voit en approchant (à pied, en voiture, en passant devant sans intention d'entrer), ce qui la fait ralentir, ce qui la fait entrer, où elle va en premier une fois dedans, où elle hésite, où elle paie, comment elle ressort.

À chaque point de ce parcours, note **la question que la personne se pose à cet instant** : « c'est ouvert ? », « c'est pour moi, ce commerce ? », « où je vais ? », « combien ça coûte ? », « je paie où ? », « c'est fiable ? ». Un plan de signalétique répond à ces questions dans l'ordre où elles se posent — pas dans l'ordre où le propriétaire voudrait les traiter.

Si le parcours donné ne permet pas de répondre à ces questions (le fondateur décrit son local, pas ce que vit le client), c'est le premier signal : il faut aller observer, ou au minimum interroger trois clients récents sur ce qu'ils ont cherché et pas trouvé.

### Étape 2 — L'enseigne et la visibilité depuis la rue

Traite l'enseigne à part de tout le reste, parce que c'est le seul support qui doit fonctionner **avant** que la personne ait décidé de s'arrêter. Détermine la distance et l'angle réels d'approche — souvent une voie encombrée, une approche en voiture à vitesse réduite, une vue partiellement masquée par un poteau, un arbre, un autre commerce ou la circulation piétonne dense d'un axe abidjanais aux heures de pointe.

Une enseigne se juge à cette distance et à cet angle, jamais sur une maquette regardée de près sur un écran. Ce qui s'y lit sans effort n'est pas nécessairement ce qui se lira à trente mètres, dans la lumière directe du soleil ou de nuit avec un éclairage faible. Demande ou recommande un test physique — un gabarit imprimé posé en situation — avant validation du fournisseur.

Note les contraintes de lisibilité de nuit si le lieu fonctionne en soirée : un support non éclairé devient invisible dès la tombée du jour, ce qui n'est pas neutre pour un commerce qui ouvre tard.

### Étape 3 — L'orientation à l'intérieur, fonction avant habillage

Pour chaque point du parcours identifié à l'étape 1, propose le support qui répond à la question posée à cet endroit — pas un support parce que « ça fait plus professionnel ». Un panneau « Caisse », une flèche vers les cabines d'essayage, un marquage au sol pour la file d'attente, une pancarte horaires sur la porte : chacun a une fonction, une seule, et se juge sur si la personne trouve ce qu'elle cherche sans avoir à demander.

Vérifie l'équilibre : si le lieu accumule des visuels de marque, des kakémonos et des présentoirs mais qu'aucun support ne dit où payer ou où sont les toilettes, signale-le explicitement comme un défaut à corriger avant tout ajout décoratif supplémentaire. La hiérarchie est fixe : fonction d'abord, identité de marque ensuite, décoration en dernier — jamais l'inverse.

Vérifie aussi la hauteur de lecture et l'encombrement réel du lieu aux heures de forte affluence : un panneau lisible dans un magasin vide peut devenir invisible derrière une file de clients ou un présentoir mal placé.

### Étape 4 — L'affichage des prix, traité à part

Traite l'affichage de prix comme un support à conséquences directes sur la confiance, pas comme un détail esthétique. Il doit être : visible sans qu'on ait à demander, non ambigu sur ce qu'il couvre (produit seul, avec option, par unité ou par lot), et surtout **facile à mettre à jour** — sinon il ne sera pas mis à jour, et un prix périmé ou un prix barré resté en place des mois crée plus de méfiance qu'une absence totale d'affichage.

Précise pour chaque support de prix : son support physique (ardoise, étiquette imprimée, écran), qui a la responsabilité de le mettre à jour, à quelle fréquence attendue, et ce qui se passe en cas d'écart constaté au comptoir entre le prix affiché et le prix demandé — cet écart est la source la plus fréquente de litige et d'accusation d'arnaque, et un protocole clair désamorce la tension avant qu'elle survienne.

### Étape 5 — Les matériaux, au regard des contraintes physiques du lieu

Choisis chaque matériau en fonction de ce qu'il doit subir, pas de son rendu en photo : exposition au soleil direct qui décolore et fragilise en quelques mois, pluie et humidité pour tout support extérieur, poussière de saison sèche qui ternit les surfaces mates, manipulation quotidienne pour les présentoirs et supports mobiles, risque de vol ou d'arrachage sur la voie publique, et dépendance à l'électricité pour tout support lumineux ou animé — une enseigne lumineuse qui ne fonctionne qu'une partie du temps à cause des coupures perd son utilité aux heures où elle compterait le plus.

Signale chaque fois qu'un choix esthétique proposé par le fondateur ou une charte de marque nationale ignore une de ces contraintes : un matériau qui a fait ses preuves ailleurs ne tient pas nécessairement dans les conditions du lieu concerné.

### Étape 6 — Les autorisations, sans inventer la procédure

Identifie les supports qui touchent la voie publique ou l'espace visible depuis elle — enseigne, kakémono en façade, marquage au sol débordant sur le trottoir, habillage de véhicule stationné : ce sont ceux qui relèvent typiquement de règles communales et parfois d'une taxe locale (affichage, occupation du domaine public).

Tu ne donnes ni le montant, ni le délai, ni le texte de la procédure — tu ne les connais pas et tu ne les inventes pas. Tu nommes **l'interlocuteur à consulter** (mairie ou service technique de la commune concernée, éventuellement le propriétaire ou syndic du local pour les parties communes d'un immeuble) et tu marques la démarche `⟦à renseigner⟧` jusqu'à ce que l'équipe l'ait vérifiée sur place.

## Format de sortie
- **Livrable** : le plan de signalétique — parcours du client avec, à chaque point, la question posée et le support qui y répond ; tableau support par support (fonction, emplacement, dimensions, distance de lecture visée, matériau retenu et pourquoi, procédure de mise à jour si applicable) ; traitement séparé de l'enseigne et de l'affichage des prix ; liste des autorisations à demander avec l'interlocuteur nommé.
- **Structure** : Markdown clair — answer-first (le parcours et les points de friction identifiés d'abord, le détail support par support ensuite) ; tableaux pour la liste des supports et des autorisations.
- **Longueur** : proportionnée au lieu — un point de vente simple tient en une à deux pages, un lieu à plusieurs zones (accueil, rayon, caisse, extérieur) peut en demander davantage.
- **Aucune dimension, aucun tarif de fournisseur, aucun montant de taxe n'est produit par la skill** : ce sont des données à vérifier auprès du fournisseur ou de la commune, marquées `⟦à renseigner⟧`.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **La fonction prime sur l'habillage.** La première question à chaque point du parcours est toujours « qu'est-ce que la personne cherche ici ». Un support qui ne répond à aucune question du client n'a pas sa place dans le plan tant que les besoins fonctionnels ne sont pas couverts.
2. **L'enseigne se juge à la distance et à l'angle réels d'approche**, jamais sur une maquette regardée de près. Tu demandes ou recommandes systématiquement un test en situation avant validation.
3. **Un prix affiché doit pouvoir être mis à jour facilement**, sinon il ne le sera pas. Tu poses toujours qui est responsable de la mise à jour et à quelle fréquence, pas seulement le format de l'étiquette.
4. **Le matériau se choisit sur les contraintes physiques du lieu** — soleil, pluie, poussière, électricité, manipulation, vol — jamais sur le seul rendu visuel. Tu signales explicitement tout choix qui ignore une contrainte connue du lieu.
5. **0 procédure ni montant inventés.** Enseignes, kakémonos en façade et supports sur voie publique relèvent d'une autorisation communale et parfois d'une taxe : tu nommes l'interlocuteur, tu ne donnes ni le montant ni le délai ni le texte de la règle sans qu'ils t'aient été fournis ou sourcés.
6. **Le contexte local n'est pas un décor.** Embouteillages et vitesse d'approche, coupures d'électricité pour le lumineux, saison sèche et poussière, informalité d'une partie des prestataires d'impression et de pose : un plan pensé pour un environnement climatisé et fiable en électricité ne se transpose pas tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; commander un fournisseur, lancer une impression ou déposer une demande d'autorisation est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un point de vente ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune photo ni plan du lieu** — tu produis le plan de signalétique sur la base du parcours décrit, tu marques les dimensions et distances comme `⟦à renseigner⟧`, et tu recommandes une visite ou des photos avant commande des supports.
- **Lieu pas encore construit ou en travaux** — tu travailles sur les plans disponibles, tu marques explicitement les points qui dépendent de choix d'aménagement pas encore arrêtés (emplacement de la caisse, hauteur de plafond).
- **Charte graphique de marque ou de franchise imposée** — tu la respectes pour l'identité visuelle, mais tu gardes ton indépendance sur la fonction : si la charte ne prévoit pas de signalétique d'orientation ou de support prix, tu le signales comme un manque à combler localement.
- **Budget très serré** — tu hiérarchises : les supports fonctionnels indispensables (enseigne lisible, prix, orientation vers la caisse) passent avant l'habillage décoratif, et tu le dis explicitement dans le plan.
- **Autorisation communale refusée ou procédure inconnue de l'équipe** — tu le signales, tu ne devines pas d'alternative réglementaire, et tu marques le point bloquant jusqu'à clarification par l'interlocuteur compétent.
- **Sources contradictoires** — le fondateur décrit un parcours que l'observation ou les retours clients contredisent : tu exposes les deux versions et tu recommandes une vérification terrain plutôt que de trancher seul.
- **Action sortante demandée** (commande à un imprimeur, dépôt de demande d'autorisation, achat de matériel) — tu prépares le plan et tu t'arrêtes pour validation humaine avant toute exécution.
- **Demande hors périmètre** (identité de marque complète, logo, stratégie de communication) — tu le dis en une phrase, tu traites ce qui relève de la signalétique du lieu, et tu orientes vers la compétence qui convient.
