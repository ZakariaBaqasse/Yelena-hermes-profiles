---
id: Y0682
name: bannieres-publicitaires-multiformats
description: "Produit le jeu complet de bannières d'une campagne payante à partir d'un brief et d'un visuel maître : déclinaison dans chaque format de plateforme aux dimensions vérifiées à la source, contrôle de ce qui casse au changement de proportion, planche de contrôle et message de livraison, sans jamais inventer une dimension ou un poids de fichier."
bucket: B
tags: [Design, Publicité, Nouveau]
version: 1
maj: 2026-09-21
---

# Les bannières publicitaires, dans tous les formats où la campagne va tourner

## Ce qu'il faut avoir sous la main
- **La charte graphique** du client (ou confirme qu'elle est déjà chargée dans la compétence `charte-du-client`).
- **Le brief de campagne** : le message principal, l'offre s'il y en a une, l'appel à l'action, la date de fin de campagne.
- **La cible** : qui doit voir ça, et sur quelle(s) plateforme(s) la campagne tourne réellement (pas la liste théorique de tout ce qui existe : les formats à produire).
- **Le visuel maître** s'il existe déjà (photo, illustration, logo isolé), ou les éléments à partir desquels je le compose.
- **Le nom de la campagne** pour le nommage des fichiers.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal. Il ne constitue pas une condition de démarrage.

## Process
### Étape 1 : Lire la charte et le brief avant de dessiner

Tu vas chercher dans `charte-du-client` : les couleurs, la typographie, la zone de protection du logo, sa taille minimale. Tu lis le brief de campagne : le message, l'offre, l'appel à l'action, l'échéance, la cible.

Ce que tu cherches : est-ce que le message tient en trois éléments, un titre, une ligne d'offre, un bouton ? Si le brief empile quatre idées (le produit, le prix, l'événement, le témoignage client), c'est le premier signal : il faut trancher avec le client ce qui reste. Tout ne tient pas sur l'image. Tu le dis avant de composer. Une découverte à l'étape 4, quand le texte ne rentre plus, arrive trop tard.

Si la charte n'est pas chargée ou incomplète (la taille minimale de logo et la zone de protection restent à définir), tu le signales : tu composeras avec les éléments fournis, mais la vérification du logo à l'étape 3 sera marquée `[à confirmer]`.

### Étape 2 : Composer le visuel maître

Le visuel maître porte la hiérarchie complète : le message en premier (le plus gros, le plus contrasté), l'offre en second, l'appel à l'action visible et cliquable en apparence, le logo lisible à sa taille réelle dans sa zone de protection.

Si le brief laisse deux pistes plausibles (deux accroches, deux traitements photo), tu proposes un choix A/B sur le visuel maître seul, avant de partir en déclinaison. Décliner deux pistes dans dix formats chacune, c'est vingt fichiers à revoir au lieu de deux : le tri se fait ici, à cette étape.

Tu ne composes le visuel maître qu'une fois : c'est la référence dont chaque format dérive.

### Étape 3 : Recomposer, jamais redimensionner

Pour chaque format demandé, tu ne prends pas le visuel maître et tu ne l'étires pas dans une nouvelle proportion. Tu recomposes : le sujet de la photo se recadre pour rester entier et centré dans l'intérêt du nouveau cadre, le texte se repositionne pour ne pas sortir, le logo garde sa taille relative et sa zone de protection.

Sur chaque format, tu vérifies quatre choses, dans cet ordre :
1. **Le texte reste-t-il dans le cadre ?** Un titre qui touchait le bord en carré peut déborder en bandeau étroit.
2. **Le logo est-il toujours lisible à la taille réelle du format ?** Si sa taille descend sous le minimum fixé par la charte, tu **retires le logo** plutôt que de le rendre illisible, et tu le signales dans le message de livraison, ce n'est pas une option silencieuse.
3. **Le sujet de la photo est-il coupé de façon absurde** (un visage tronqué, un produit dont la moitié sort du cadre) ? Si oui, tu recadres autrement ou tu changes de traitement pour ce format.
4. **Le texte tombe-t-il dans une zone masquée par l'interface de la plateforme** (le nom de compte et les icônes en haut d'une story, la barre de réponse et les boutons en bas, la zone où WhatsApp place l'heure et les réactions sur un statut) ? Si oui, tu déplaces le texte dans la zone sûre.

Un format sur lequel une de ces quatre vérifications échoue et que tu livres quand même est une bannière cassée livrée sciemment. Tu la retraites avant de la mettre dans le jeu final.

### Étape 4 : Vérifier dimension et poids à la source

Avant de fixer les dimensions d'un format, tu consultes la page officielle de spécifications de la plateforme concernée (Meta pour Facebook/Instagram, la page créateurs de TikTok, les specs Google Ads pour l'affichage display, la documentation WhatsApp Business pour le statut). Tu notes la dimension exacte, le format de fichier accepté et le poids maximal, et tu gardes le lien de la source pour le message de livraison.

Les dimensions publicitaires changent régulièrement (une plateforme ajoute un format, en retire un autre, révise ses ratios). Une dimension récitée de mémoire, même juste il y a six mois, est un risque : au mieux la bannière est recadrée automatiquement par la plateforme et perd sa composition, au pire elle est refusée à la mise en ligne. Si tu ne peux pas vérifier une dimension au moment de produire (connecteur web indisponible), tu le dis explicitement, tu marques le format `[dimension à confirmer avant livraison]`, et tu ne le comptes pas comme livré.

### Étape 5 : Exporter au format et au poids attendus

Tu exportes chaque fichier en respectant le format demandé par la plateforme (PNG pour la transparence ou la netteté du texte, JPG pour la photo pure quand le poids compte) et tu vérifies que le poids reste sous le maximum trouvé à l'étape 4. Un fichier trop lourd n'est pas un détail : la plateforme le recompresse à son tour, souvent plus mal que ton propre export, et le résultat en ligne est différent de ce qui a été validé.

Tu nommes chaque fichier `campagne_plateforme_format` (par exemple `promo-rentree_instagram_story` ou `promo-rentree_googleads_gratteciel`), de façon que quiconque ouvre le dossier retrouve sans ambiguïté où chaque fichier va.

### Étape 6 : Construire la planche de contrôle

Tu assembles une image unique qui montre tous les formats produits côte à côte, à l'échelle relative de leur proportion réelle (pas tous à la même taille visuelle, sinon la planche ment sur les proportions), avec les dimensions écrites sous chacun.

La personne qui valide regarde la planche en premier. Le dossier de fichiers vient ensuite. Elle doit pouvoir repérer d'un coup d'œil le format qui décroche (texte qui touche le bord, logo trop petit, cadrage étrange) sans ouvrir dix fichiers l'un après l'autre.

### Étape 7 : Le message de livraison

Trois lignes, pas plus : le lien du dossier contenant tous les fichiers et la planche, l'application utilisée pour la composition, la date de fin de campagne (reprise du brief) pour que quelqu'un sache quand retirer les visuels des plateformes.

Si un format a été retiré du jeu (logo illisible retiré, dimension non vérifiée), tu l'ajoutes en une ligne supplémentaire du message : ce n'est jamais silencieux.

## Format de sortie
- **Livrable** : le visuel maître validé (avec choix A/B si deux pistes) ; le jeu de bannières, un fichier par plateforme et par format nommé `campagne_plateforme_format`, au format et poids vérifiés à la source ; la planche de contrôle en une image, tous les formats côte à côte avec leurs dimensions écrites ; le message de livraison en trois lignes.
- **Structure** : livrable visuel avant tout, le texte qui l'accompagne (sources des dimensions, formats retirés, hypothèses) reste court et se place à côté des fichiers. Un rapport séparé à lire n'est pas nécessaire.
- **Chaque dimension et chaque poids maximal cités portent leur source** : le lien vers la page officielle de spécifications de la plateforme, daté du jour de production. Une dimension sans lien de source est marquée `[dimension à confirmer]`.
- **Règle 0 invention** : aucune dimension, aucun poids maximal, aucun format de fichier accepté n'est produit de mémoire ou par extrapolation. Si la source n'est pas consultable, le format concerné est marqué `[à confirmer]` et n'entre pas dans le jeu livré comme final.

## Règles
1. **On recompose, on n'étire jamais.** Chaque format part du visuel maître et se reconstruit dans sa proportion propre : recadrage du sujet, repositionnement du texte, zone de protection du logo respectée. Un simple redimensionnement du fichier n'est jamais un livrable.
2. **Trois éléments maximum sur l'image : titre, offre, appel à l'action.** Tout ce qui ne rentre pas dans ces trois éléments va dans la légende du post ou la page de destination.
3. **Le logo respecte sa taille minimale ou disparaît.** Sous le seuil fixé par la charte, tu retires le logo plutôt que de le rendre illisible, et tu le signales.
4. **Le texte évite les zones masquées par l'interface de chaque plateforme.** Nom de compte et icônes en haut d'une story, boutons et barre de réponse en bas, zone d'horodatage sur un statut WhatsApp : le texte important se place ailleurs.
5. **Dimension et poids se vérifient à la source au moment de produire.** Aucune valeur récitée de mémoire, même récente. La source est citée dans le message de livraison.
6. **Aucun jeu de bannières ne part sans planche de contrôle.** La planche montre tous les formats produits, à l'échelle relative de leurs proportions, avec les dimensions écrites.
7. **Le contexte local n'est pas un décor.** WhatsApp Statut est un canal publicitaire courant en Côte d'Ivoire et pèse dans le choix des formats à produire ; les téléphones d'entrée de gamme et la connexion coûteuse rendent le poids de fichier plus critique qu'ailleurs ; une lecture en une seconde compte davantage quand le défilement se fait sur un petit écran et une connexion lente.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un jeu de fichiers de travail ; publier une campagne, la mettre en ligne ou engager un budget média est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une campagne ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Charte incomplète ou absente**, tu produis avec les éléments fournis, tu marques `[hypothèse : …]` pour les choix non tranchés par la charte, et tu signales que la vérification du logo (taille minimale, zone de protection) reste `[à confirmer]`.
- **Brief incomplet** (l'appel à l'action et la date de fin manquent), tu produis avec ce que tu as ; l'appel à l'action manquant devient un `[hypothèse : …]` visible sur le visuel maître avant d'être décliné partout ; l'absence de date de fin est signalée dans le message de livraison. Une date de fin inventée n'a pas sa place dans le livrable.
- **Visuel maître absent, seuls des éléments bruts sont fournis**, tu composes le visuel maître à partir des éléments donnés (charte, photo, texte du brief) et tu le signales clairement comme la première pièce à valider avant toute déclinaison.
- **Aucune plateforme précisée, brief générique « réseaux sociaux »**, tu ne déclines pas tous les formats théoriquement possibles : tu demandes la liste des plateformes réellement utilisées pour cette campagne, ou tu produis pour les formats les plus probables au vu du brief en le signalant comme hypothèse à confirmer.
- **Dimension ou poids introuvable à la source** (page de spécifications inaccessible), tu marques le format `[dimension à confirmer avant livraison]`, tu ne l'intègres pas au jeu livré comme final, et tu le dis explicitement dans le message de livraison.
- **Le texte ne rentre pas dans un format donné même après recomposition**, tu le dis : ce format ne porte pas ce message tel quel, et tu proposes soit une accroche raccourcie pour ce format spécifique, soit son retrait du jeu, plutôt que de forcer un texte compressé illisible.
- **Demande de dupliquer une bannière existante pour une nouvelle campagne**, tu vérifies que le message, l'offre et l'échéance ont bien changé avant de simplement réutiliser l'ancien visuel maître ; une bannière avec une date de fin de campagne périmée n'est jamais relivrée telle quelle.
- **Action sortante demandée** (publication directe, envoi au community manager pour mise en ligne immédiate, paiement d'espace publicitaire), tu prépares le jeu de fichiers et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (la charte dit une couleur, le brief en mentionne une autre pour cette campagne), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
