---
id: Y0034
name: 06-naming-generator
description: "Génère noms startup + domaines."
bucket: B
tags: [Design]
version: 1
maj: 2026-08-10
---

# Naming Generator

## Ce qu'il faut avoir sous la main
1. **Concept startup** (1-2 lignes décrivant l'activité) — ex. « Plateforme de paiement mobile pour commerçants informels via QR code »
2. **Comparables** (3-6 entreprises dont le nom illustre bien votre secteur)


**Ce qu'elle suppose comme accès** : Outil de génération de noms IA (type Namelix), Vérification disponibilité domaine (.com / .africa), Vérification disponibilité handle Instagram. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### Étape 1 — Mots-clés originaux évocateurs directs

[Dès réception des inputs → produire directement le livrable ci-dessous]

Sources créatives OBLIGATOIRES (lien direct uniquement) :
- Verbes d'action métier : actions principales effectuées (payer, livrer, acheter, vendre, envoyer)
- Objets concrets secteur : outils/produits manipulés (argent, téléphone, colis, boutique, carte)
- Résultats immédiats : bénéfices tangibles (rapide, facile, sûr, instantané)
- Acteurs métier : utilisateurs/parties prenantes (commerçant, client, livreur, vendeur)
- Lieux d'activité : espaces physiques/digitaux (marché, app, plateforme, shop)

❌ **Exclure absolument** :
- Concepts abstraits (innovation, digital, tech, future)
- Métaphores éloignées (pont, vague, étoile SAUF si lien direct évident)
- Termes génériques (solution, service, plateforme)

Format de sortie :
```
🔍 ANALYSE COMPARABLES
[Comparable 1] : [Business + MOTS-CLÉS DIRECTS identifiés dans leur nom]
[Comparable 2] : [Business + MOTS-CLÉS DIRECTS identifiés dans leur nom]
[Comparable 3] : [Business + MOTS-CLÉS DIRECTS identifiés dans leur nom]

INSIGHTS : [Mots-clés DIRECTS du secteur utilisés par les concurrents]

📋 MOTS-CLÉS PARLANTS DIRECTS (35)

🇫🇷 FRANÇAIS (8) :
[VERBE/OBJET/ACTEUR métier direct] - [lien évident avec activité]

🎯 BAMBARA - PRIORITAIRE (15 ≤10 lett.) :
[terme métier concret] ([trad]) - [usage direct]

🌍 WOLOF/SWAHILI/LINGALA (7 ≤10 lett.) :
[mot] - [langue] ([trad]) - [lien direct]

🌐 ANGLAIS TECH (5) :
[ACTION/OBJET métier spécifique] - [évocation immédiate]

✅ VALIDATION : Chaque mot doit faire penser INSTANTANÉMENT à l'activité (test 1 seconde)
```

### Étape 2 — Scoring + handoff

[Après production de l'étape 1 → produire directement le scoring]

**2A — Scoring automatique**
```
🎯 SCORING TOP 15 (critère prioritaire : évocation DIRECTE)

 | Mot-clé | /30 | Évoc.DIRECTE | Émot.Cible | Différenc. | Créativité | Entreprise | Internat. |
|---------|-----|--------------|------------|------------|------------|---------|-----------|
| [mot]   | [X] | [X/5]        | [X/5]      | [X/5]      | [X/5]      | [X/5]   | [X/5]     |

❌ Éliminer tout mot à évocation indirecte ou nécessitant explication
```

**2B — Handoff humain**
```
⏸️ SÉLECTION REQUISE

Choisissez les 10 mots-clés les plus PARLANTS et DIRECTS parmi le Top 15 ci-dessus.

➡️ Répondez : "CONTINUER avec : [mot1], [mot2], [mot3]..."
```

### Étape 3 — Explosion créative directe

[Dès réception des 10 mots → produire directement le tableau créatif]

```
🎨 EXPLOSION CRÉATIVE (maintien évocation directe)

| Mot | Synonymes CONCRETS | Trad Bambara | Verbe action EN | Nouchi street | Objet/Acteur métier | Fusion PARLANTE |
|-----|-------------------|--------------|-----------------|---------------|---------------------|-----------------|
| [X] | [concret métier]  | [prioritaire]| [action directe]| [X]           | [élément tangible]  | [lien évident]  |

✅ 60 éléments de fusion DIRECTS créés (priorité bambara + évocation immédiate)
```

### Étape 4 — Génération hybride ([connecteur à brancher : outil de génération de noms IA type Namelix] + IA créative)

[Après explosion créative → produire directement les 25 noms]

Consignes créativité renforcées :
- Portmanteaux PARLANTS (ex : PayPal = Pay + Pal — lien direct paiement)
- Néologismes ÉVIDENTS (ex : Snapchat = Snap + Chat — photo instantanée)
- Contractions métier CLAIRES (ex : LinkedIn = Linked + In — réseau professionnel)
- Phonétique ÉVOCATRICE du service
- Intégrer racines bambara + maintenir évocation directe
- Test obligatoire : « Un enfant de 10 ans comprend l'activité en entendant le nom ? »

Format de sortie :
```
🚀 GÉNÉRATION HYBRIDE (25 NOMS PARLANTS DIRECTS)

[connecteur à brancher : outil de génération de noms IA type Namelix] (15)
1. [Nom] (X syll.) - Brand: X% [connecteur à brancher : scoring de marque via l'outil de naming] - .com: ✅/❌ [connecteur à brancher : vérification disponibilité domaine] - Évocation DIRECTE: [Comment ça définit CLAIREMENT l'activité] - Étymologie: [X+Y]
...

IA CRÉATIVE (10 - priorité bambara + évocation directe)
16. [Nom] (X syll.) - Technique: [portmanteau/néologisme] - Évocation DIRECTE: [Lien IMMÉDIAT métier] - Racine: [bambara si applicable] - Test clarté: [OUI/NON]
...
```

Handoff humain
```
⏸️ SÉLECTION FINALE

Choisissez les 4 noms les plus PARLANTS (compréhension immédiate de l'activité) parmi les 25 propositions.

➡️ Répondez : "FINALISER avec : [Nom1], [Nom2], [Nom3], [Nom4]"
```

### Étape 5 — Analyse détaillée des 4 finalistes

[Dès réception des 4 noms → produire directement les analyses détaillées]

Format de sortie :
```
🔍 ANALYSE DÉTAILLÉE TOP 4

═══════════════════════════════════════
[NOM 1]
═══════════════════════════════════════

📖 Étymologie : [Origine + fusion créative + racine bambara si applicable]

🎯 Évocation DIRECTE business : [Le nom fait comprendre l'activité SANS EXPLICATION - test 1 seconde]

💫 Impact cible : [Résonance émotionnelle utilisateurs finaux]

🎨 Créativité : [Originalité /10]

🌍 Ancrage culturel : [Bambara/Autre - pertinence locale]

🌐 Disponibilité :
- .com [✅/❌] [connecteur à brancher : vérification disponibilité domaine .com]
- .africa [✅/❌] [connecteur à brancher : vérification disponibilité domaine .africa]
- @Instagram [✅/❌] [connecteur à brancher : vérification disponibilité handle Instagram]

⚡ Test clarté RENFORCÉ : "Un enfant de 10 ans comprend l'activité : OUI/NON"

✅ Lien métier : [DIRECT/INDIRECT - justifier si indirect]

⚠️ Risques : [Ambiguïtés potentielles]

[Répéter pour NOM 2, NOM 3, NOM 4]
```

### Étape 6 — Message de vote équipe

[Après analyses → produire directement le message de vote]

Format de sortie :
```
📧 MESSAGE VOTE ÉQUIPE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Objet : Vote nom [STARTUP] - 4 finalistes à évocation directe
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Bonjour l'équipe,

CONTEXTE STARTUP :
[Description activité en 2-3 lignes]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROPOSITIONS FINALES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏆 [NOM 1]
→ Lien DIRECT avec activité : [explication immédiate]
→ Force émotionnelle : [impact utilisateurs]
→ Ancrage culturel : [bambara/autre + pertinence]

🏆 [NOM 2]
→ Lien DIRECT avec activité : [explication immédiate]
→ Force émotionnelle : [impact utilisateurs]
→ Ancrage culturel : [bambara/autre + pertinence]

🏆 [NOM 3]
→ Lien DIRECT avec activité : [explication immédiate]
→ Force émotionnelle : [impact utilisateurs]
→ Ancrage culturel : [bambara/autre + pertinence]

🏆 [NOM 4]
→ Lien DIRECT avec activité : [explication immédiate]
→ Force émotionnelle : [impact utilisateurs]
→ Ancrage culturel : [bambara/autre + pertinence]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CRITÈRES DE VOTE (/5 CHACUN)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Évocation DIRECTE de l'activité (critère PRIORITAIRE - compréhension immédiate)
✅ Mémorabilité
✅ Prononciation facile
✅ Résonance cible
✅ Potentiel levée fonds internationale

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VOTRE RÉPONSE ATTENDUE :

"Je vote pour [NOM] car :
1. [Activité CLAIRE sans explication]
2. [Impact cible]
3. [1 autre raison forte]"

Deadline : [DATE dans 48-72h]

Merci pour vos retours ! 🚀
```

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Instructions internes

### Référence de style — portfolio de référence

Portfolio de référence (jamais réutilisé comme mot-clé ou proposition) : [exemples anonymisés du secteur].

Marqueurs de style : 2-3 syllabes | mix local/international | sonorités modernes | prononciation facile | évocation DIRECTE et IMMÉDIATE du secteur.

⚠️ **Exclusion absolue** : jamais réutiliser ces noms comme mots-clés ou propositions.

### Grille de scoring (pertinence)

**6 critères (/5 chacun) :**
- Évocation DIRECTE de l'activité (40%) — lien IMMÉDIAT et ÉVIDENT avec le business (pas de concepts abstraits ou éloignés)
- Résonance émotionnelle cible (20%) — impact utilisateurs finaux
- Différenciation concurrents (15%)
- Créativité & mémorabilité (15%)
- Esthétique de l'entreprise (5%)
- Fonctionnement international (5%)

**Seuil de sélection : ≥22/30**

**Priorité absolue :**
- Le mot doit faire comprendre l'activité INSTANTANÉMENT (test 1 seconde)
- Interdiction des mots abstraits, conceptuels ou métaphoriques éloignés
- Obligation de mots parlants, concrets, liés au cœur de métier

### Contraintes

**✅ Obligatoire :**
- 6 étapes séquentielles | max 4 syllabes
- **Préférence bambara** : langue prioritaire pour l'ancrage culturel ivoirien
- Langues secondaires : wolof, swahili, lingala
- [connecteur à brancher : outil de génération de noms IA type Namelix] à l'étape 4
- **Créativité maximale** : portmanteaux, néologismes, fusions audacieuses
- **Évocation DIRECTE** : mots parlants qui désignent directement l'action, l'objet ou le résultat du service

**❌ Interdit absolument :**
- Noms du portfolio de référence comme mots-clés
- Langues à traduction incertaine
- Mots abstraits ou conceptuels éloignés de l'activité
- Métaphores complexes nécessitant explication
- Termes génériques sans lien direct au métier
- Mots ne faisant PAS penser directement à l'activité

**✅ Privilégier :**
- Verbes d'action du métier (ex : payer, livrer, envoyer, acheter)
- Objets concrets du secteur (ex : argent, colis, carte, boutique)
- Résultats immédiats (ex : rapide, sûr, facile)
- Acteurs du métier (ex : commerçant, livreur, client)

### Règles d'exécution

- **Exécution directe** : dès réception des inputs utilisateur, produire IMMÉDIATEMENT les livrables de l'étape sans phrase d'introduction ou d'annonce.
- **Interdiction phrases d'attente** : ne JAMAIS écrire « Je vais maintenant... », « Voici ce qui vous attend... », « Laissez-moi analyser... », etc.
- **Progression séquentielle stricte** : ne jamais passer à l'étape suivante sans validation humaine aux handoffs (étapes 2B et 4B).
- **Maintien évocation directe** : à chaque étape, éliminer impitoyablement tout mot/nom ne permettant pas de comprendre l'activité instantanément.
- **Priorité bambara** : dans toutes les phases créatives, privilégier systématiquement les racines bambara quand pertinent.
- **Format de sortie strict** : utiliser exactement les templates fournis pour chaque étape (blocs avec emojis + tableaux structurés).
- **Scoring rigoureux** : appliquer le seuil 22/30 sans compromis, éliminer tout candidat sous ce seuil.
- **Test clarté systématique** : à partir de l'étape 4, appliquer le test « enfant de 10 ans » sur chaque nom généré.
