---
name: referentiel-local
description: >
  Les corpus de référence du poste, constitués à partir de données ivoiriennes réelles et
  vérifiées, et non de souvenirs ou d'exemples importés. À charger avant toute maquette d'écran et tout visuel de goodie,
  et chaque fois qu'une recommandation gagnerait à s'appuyer sur ce qui se pratique
  réellement en Côte d'Ivoire plutôt que sur une norme générale.
version: 1
maj: 2026-09-06
---

# Référentiel local — design

Ces fichiers vivent dans le poste. Ils ont été établis à partir de collectes datées, dont
la méthode et les limites sont écrites en tête de chaque document.

### `memory/reference/ecrans-applis-ci.md`

Les applications ivoiriennes telles qu'elles se montrent — 38 captures réelles de cinq applications, plus les images dans ecrans-applis-ci/.

**Quand le lire** : avant de dessiner un écran, une fiche de store ou une maquette pour un client ivoirien.

### `memory/reference/ecrans-applis-us.md`

Les standards américains — 24 captures de Duolingo, Cash App, Revolut et Notion, avec ce qui
se transpose et ce qui ne se transpose pas. Images dans `ecrans-applis-us/`.

**Quand le lire** : pour élargir le champ des compositions possibles, jamais pour choisir.
**En cas de divergence avec le fichier ivoirien, pour un client ivoirien, c'est l'ivoirien
qui l'emporte.**

### `memory/reference/logos-marques-ci.md`

Quinze logos de marques et d'institutions ivoiriennes, les deux générations qui s'y
opposent, le défaut de recadrage circulaire qui touche quatre d'entre eux, et cinq questions
de contrôle. Images dans `logos-marques-ci/`.

**Quand le lire** : avant de dessiner un logo, un monogramme ou un avatar de réseau social.

### `memory/reference/design-systems-Yelema.md`

Les 14 systèmes de design de l'espace Figma Yelema, relevés en direct : la marque, le
fichier, sa dernière modification et son adresse. Le squelette invariant, ce que chaque
section contient, et les trois défauts de nommage de la bibliothèque maison.

⛔ Ces systèmes portent des marques CLIENTES. Ils ne sortent pas de la maison sans l'accord
du client concerné, et ils demandent un compte Figma invité.

**Quand le lire** : avant de produire une charte ou un composant pour une startup du
portefeuille, et avant de proposer une convention de nommage.

### `memory/reference/design-systems-publics.md`

Trois design systems publics (Material 3, Carbon, Polaris), ouvrables sans compte et sans
marque cliente dedans.

**Quand le lire** : quand il faut MONTRER à quelqu'un ce qu'est un design system, et quand
il faut adosser un choix de conception à une référence établie plutôt qu'à un avis. On y lit
la méthode, jamais les valeurs : recopier les couleurs de Google dans un livrable client se
voit.

### `memory/reference/catalogue-goodies.md`

Zones de marquage, techniques et contraintes de fabrication de 25 objets.

**Quand le lire** : avant de générer un visuel de goodie ou de promettre un objet à un client.

## Comment m'en servir

**Je les lis avant de recommander, pas après.** Un conseil aligné sur une norme générale se
repère immédiatement chez un client ivoirien, et il coûte la crédibilité de tout le reste.

**Je cite le chiffre et sa date.** « Sur 4 136 offres relevées en août 2026 » vaut mieux que
« généralement ». Le chiffre daté se vérifie ; le « généralement » ne se vérifie pas.

**Je ne dépasse pas ce que le corpus couvre.** Chaque document porte une section sur ce
qu'il ne dit pas. Quand la question tombe dans cet angle mort, je le dis et je cherche
ailleurs plutôt que d'extrapoler.

**Ils vieillissent.** Chaque document indique la commande qui le rafraîchit. Un chiffre de
plus de trois mois s'annonce comme tel.
