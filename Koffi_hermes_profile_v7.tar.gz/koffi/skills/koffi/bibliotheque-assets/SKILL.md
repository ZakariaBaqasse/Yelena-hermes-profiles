---
id: Y0412
name: bibliotheque-assets
description: "Organise les ressources visuelles de l'entreprise — logos, photos, illustrations, icônes, vidéos, modèles — en distinguant strictement le fichier source modifiable de l'export diffusable, avec arborescence par contenu, convention de nommage, matrice des droits d'accès, registre des droits d'usage et règle d'archivage, puis range l'existant en signalant les sources introuvables — sans jamais improviser un seuil, une durée d'archivage ou une condition de licence."
bucket: B
tags: [Design, Organisation, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# La bibliothèque visuelle — retrouver le bon fichier en trente secondes

## Ce qu'il faut avoir sous la main
- **Où vivent les visuels aujourd'hui** : Drive partagé, disque d'un poste, clé USB, historique WhatsApp, ordinateur d'un graphiste parti — même en vrac, même incomplet.
- **Les types de ressources concernés** : logos, photos, illustrations, icônes, vidéos, modèles/gabarits — et s'il y a plusieurs marques ou filiales à distinguer.
- **Qui doit pouvoir lire, qui doit pouvoir modifier, qui doit pouvoir supprimer** — même en première approximation.
- **Les ressources sensibles** connues : photos achetées sous licence, images fournies par un partenaire, portraits pris avec autorisation.
- **Les outils réellement utilisés au quotidien** pour envoyer un visuel à un tiers — imprimeur, agence, partenaire — WhatsApp compris.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier l'existant avant de ranger

Recense où vivent réellement les visuels aujourd'hui — pas où ils devraient être. Un Drive partagé, le poste d'une personne, une clé USB, l'historique WhatsApp d'un graphiste, le disque d'un collaborateur parti : chacun est une source potentielle, et chacune peut contenir la seule copie existante de quelque chose.

Pour chaque fichier trouvé, distingue **source** (fichier modifiable — extension `.ai`, `.psd`, `.indd`, `.eps`, projet vidéo natif) et **export** (fichier fini — `.png`, `.jpg`, `.pdf`, `.mp4`). Un export sans source retrouvable est un signal d'alerte à noter dès maintenant, pas à corriger en silence : le jour où ce visuel doit être agrandi, imprimé en grand format ou décliné, il faudra le reconstruire à l'œil.

Le piège du métier ici : ranger par **date de création ou par projet** (« campagne ramadan 2023 », « dossier presse janvier ») plutôt que par contenu. Un rangement chronologique ne retrouve que ce dont on se souvient déjà — jamais ce qu'on découvre par besoin, quand on cherche « le logo », peu importe quand il a été produit.

### Étape 2 — Construire l'arborescence par rôle, pas par service

L'arborescence racine se découpe par **type de contenu** — Logos, Photographies, Illustrations, Icônes, Vidéos, Modèles/Gabarits — et, s'il y a plusieurs marques ou filiales, par marque en premier niveau. Elle ne se découpe **jamais par service ni par département** : un logo appartient à la marque, pas au service marketing qui l'a utilisé la dernière fois. Une arborescence par service oblige chaque service à reconstituer sa propre collection, fait perdre la source unique de vérité, et garantit que deux personnes travailleront un jour sur deux versions différentes du même logo sans le savoir.

Chaque dossier de contenu se subdivise ensuite en **Sources** et **Exports** — la séparation vient à l'étape suivante, mais elle se décide ici, dans la structure elle-même.

### Étape 3 — La convention de nommage : contenu, variante, format, version

Une convention fixe et non négociable : `[Marque]_[Contenu]_[Variante]_[Format]_[Version]`. Exemples réels : `Yelema_Logo_FondBlanc_RVB_v2.png`, `Yelema_Logo_FondTransparent_CMJN_v2.pdf`, `Yelema_Icone-Paiement_Couleur_SVG_v1.svg`.

Le piège du métier, nommément : nommer les fichiers par leur **histoire** plutôt que par leur **contenu** — « logo final v3 vrai définitif », « logo OK utiliser celui-ci », « logo bon pour impression (2) ». Ce type de nom ne dit ni de quel logo il s'agit, ni sur quel fond il s'utilise, ni dans quel format — il ne dit que l'anxiété de la personne qui l'a enregistré. Une convention de nommage porte l'information utile dans le nom lui-même, sans qu'il faille ouvrir le fichier pour savoir ce qu'il contient.

La version se numérote de façon croissante et documentée — un changelog minimal (qui a changé quoi, et pourquoi) accompagne chaque incrément — jamais par accumulation d'adjectifs superlatifs.

### Étape 4 — Séparer strictement sources et exports, protéger les sources

Deux dossiers distincts et non imbriqués. **Sources** : fichiers modifiables, accès en écriture réservé à l'équipe design. **Exports** : fichiers finis, prêts à diffuser, déclinés dans les formats que les usages réels exigent — RVB pour écran et messagerie, CMJN pour l'impression chez un imprimeur local qui travaille en offset, formats compressés et légers pensés pour une connexion coûteuse et un téléphone d'entrée de gamme.

Quelqu'un qui a besoin d'un logo pour un devis, une présentation ou une affiche ouvre **Exports** et prend un fichier utilisable — il n'ouvre jamais un fichier source qu'il risque d'écraser par une mauvaise manipulation d'enregistrement. C'est le deuxième piège du métier, et le plus coûteux : mélanger sources et exports fait qu'un jour, quelqu'un enregistre par-dessus le fichier de travail du logo, et personne ne s'en aperçoit avant d'en avoir besoin.

WhatsApp reste, dans les faits, un canal de travail courant pour envoyer un visuel à un imprimeur ou un partenaire. Le fichier envoyé doit toujours provenir du dossier **Exports** — jamais d'une capture d'écran ou d'une compression WhatsApp d'un envoi précédent, qui dégrade la qualité et qui, par facilité, finit par devenir la seule version qui circule dans l'entreprise.

### Étape 5 — La matrice des droits d'accès

Un tableau rôle × dossier × droit : qui peut **lire**, qui peut **ajouter**, qui peut **modifier une source**, qui peut **supprimer**. Par défaut raisonnable : lecture ouverte à toute l'entreprise sur Exports, écriture restreinte à l'équipe design/communication sur Sources, suppression réservée à un rôle nommé — un responsable de bibliothèque identifié, pas « l'équipe » en général.

Le piège du métier : une bibliothèque partagée en écriture à tout le monde perd des fichiers sans que personne ne sache qui a supprimé quoi — et la perte se découvre le jour où on en a besoin, souvent en urgence, la veille d'un salon ou d'une impression. La matrice n'est pas une déclaration d'intention, c'est le paramétrage réel des droits sur l'outil de stockage utilisé.

### Étape 6 — Le registre des droits d'usage pour les ressources sensibles

Pour chaque ressource dont l'usage est encadré — photo achetée sous licence, image fournie par un partenaire, portrait pris avec l'autorisation d'une personne — un registre porte : l'origine, la date d'obtention, ce que l'entreprise a le droit d'en faire (usage web ou impression, durée, mention obligatoire, usage commercial ou non), et la preuve de l'autorisation quand elle existe.

Chaque champ reste `⟦à renseigner⟧` tant que l'entreprise ne fournit pas la condition réelle — cette compétence ne déduit ni ne suppose jamais une licence à partir de l'apparence d'un fichier. Le piège du métier, spécifique aux visuels : une photo de collaborateur ou de client réutilisée dans une publicité sans trace d'accord écrit est un risque invisible en interne, qui ne se révèle qu'au moment d'un litige — trop tard pour être corrigé.

### Étape 7 — La règle d'archivage

Ce qui reste en **accès courant** (la dernière version en vigueur de chaque contenu, éventuellement une génération précédente) et ce qui part en **archive** (versions antérieures, campagnes closes, anciens logos avant refonte). La règle s'écrit comme un critère vérifiable — nombre de versions conservées en courant, ancienneté qui déclenche l'archivage — et la valeur exacte reste `⟦à renseigner⟧`, à trancher par l'équipe.

Le piège du métier : une bibliothèque qui garde tout en accès courant, par prudence ou par flemme de trancher, redevient aussi inutilisable qu'un dossier en vrac — retrouver la bonne version demande à nouveau de tout ouvrir. Archiver n'est pas supprimer : la règle déplace, elle n'efface pas sans validation humaine.

### Étape 8 — Ranger l'existant et produire l'état des lieux

Applique l'arborescence et la convention aux fichiers recensés à l'étape 1. Pour chaque déplacement : ancien emplacement, nouveau nom, dossier de destination. Liste séparément, sans les masquer dans le rangement général, les fichiers dont **la source est introuvable** — seul un export basse résolution existe. Ce sont des points de risque réels à signaler explicitement à l'entreprise, pas des cas à ranger comme si de rien n'était : une source manquante aujourd'hui est une reconstruction forcée demain.

## Format de sortie
- **Livrable** : le plan de bibliothèque — arborescence commentée (rôle de chaque dossier), convention de nommage illustrée d'exemples réels, séparation sources/exports, matrice des droits d'accès, registre des droits d'usage pour les ressources sensibles, règle d'archivage, puis le journal du rangement effectué et la liste des fichiers dont la source est introuvable.
- **Structure** : Markdown clair, arborescence en bloc de code, tableaux pour la matrice des droits et le registre des droits d'usage.
- **Longueur** : proportionnée au volume réel de ressources à organiser, sans remplissage.
- **Les seuils** (nombre de versions conservées en courant, ancienneté déclenchant l'archivage, conditions précises d'une licence) sont un **input** de l'équipe, marqués `⟦à renseigner⟧` tant qu'ils ne sont pas donnés — la skill livre la structure et la question à trancher, pas la valeur.
- **Règle 0 invention** : aucune donnée de licence, de droit d'usage ou de seuil inventée. Une information manquante est demandée ou marquée `[à confirmer]`.

## Règles
1. **Toute ressource a une source, ou est signalée comme n'en ayant pas.** Jamais un export présenté comme une source, ni l'inverse.
2. **La convention de nommage porte contenu, variante, format, version, dans cet ordre**, sans exception, sans surnom ni superlatif (« final », « définitif », « bon »).
3. **Les fichiers sources ne sont jamais accessibles en écriture** à qui n'en a pas la responsabilité désignée.
4. **Aucune condition de licence ou d'autorisation n'est supposée.** Une ressource sensible sans condition connue reste `⟦à renseigner⟧`, jamais présumée libre de droits.
5. **L'archivage déplace, il ne supprime pas** — l'effacement définitif d'un fichier est une action validée par un humain, jamais décidée en autonomie.
6. **Le contexte local n'est pas un décor.** Le canal WhatsApp comme voie d'envoi courante, le besoin de CMJN pour un imprimeur local, le coût de la donnée et les téléphones d'entrée de gamme dictent les formats d'export à prévoir — une bibliothèque pensée pour un usage 100 % web ne sert pas telle quelle une entreprise qui imprime et qui envoie par messagerie.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déplacer, écraser ou supprimer un fichier réel, modifier des droits d'accès sur l'outil de stockage, ou envoyer une ressource à un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fichier trouvé sans source retrouvable** — tu le ranges dans Exports en l'état, tu le signales dans la liste dédiée, tu ne le fais jamais passer pour une source.
- **Origine incertaine d'une image** (trouvée en ligne, sans trace d'achat ni d'autorisation) — tu la marques `⟦à renseigner⟧` dans le registre des droits d'usage et tu alertes explicitement sur le risque, tu ne présumes jamais qu'elle est libre de droits.
- **Plusieurs marques ou filiales** — tu ouvres un niveau racine par marque avant le découpage par type de contenu, et tu ne mutualises jamais deux bibliothèques de marques distinctes dans un seul arbre sans ce niveau.
- **Ancien collaborateur parti avec le seul poste contenant des sources** — tu le signales comme un risque de perte avéré, tu ne fais pas comme si le fichier restant en export suffisait.
- **Demande de suppression définitive** — tu prépares la liste de ce qui serait supprimé et tu t'arrêtes pour validation humaine ; tu ne supprimes jamais en autonomie.
- **Connecteur ou dossier partagé inaccessible** — tu le signales et tu travailles avec ce que l'utilisateur a fourni directement.
- **Ressource sensible sans aucune trace d'autorisation** — tu le dis en une phrase claire, sans minimiser, et tu marques le champ correspondant `⟦à renseigner⟧` jusqu'à preuve du contraire.
- **Demande hors périmètre** (charte graphique, identité de marque elle-même) — tu le dis en une phrase et tu orientes vers la compétence qui convient.
