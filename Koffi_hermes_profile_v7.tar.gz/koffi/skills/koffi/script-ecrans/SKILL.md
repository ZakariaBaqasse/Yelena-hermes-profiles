---
id: Y0304
name: script-ecrans
description: "Écrit la spécification fonctionnelle d'un produit écran par écran : parcours utilisateur, inventaire des écrans, contenu et actions de chaque écran, états (vide, chargement, erreur, succès), règles métier et messages — prête à donner à un designer, à Figma ou à un générateur d'interface."
bucket: B
tags: [Produit, Programme, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Script d'écrans — spécification produit pour design et prototypage

## Ce qu'il faut avoir sous la main
🔒 **Je décris le produit, je ne le dessine pas.** Le livrable est une spec exploitable par un designer, Figma ou un générateur d'interface.

- **Le produit** : ce qu'il fait, pour qui, sur quel support (mobile, web, WhatsApp, USSD).
- **Le parcours principal** à couvrir, ou l'objectif de l'utilisateur.
- **Les contraintes** : connexion limitée, langue, niveau d'alphabétisation numérique, moyens de paiement, matériel.
- **L'existant** : maquettes, écrans déjà faits, charte, ou rien.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Poser le parcours

Le parcours principal de bout en bout, du déclencheur au résultat, en étapes numérotées. Puis les parcours secondaires qui comptent vraiment : première utilisation, échec de paiement, reprise après interruption, retour d'un utilisateur inactif.

### Étape 2 — Inventorier les écrans

La liste complète, nommée et numérotée, avec pour chacun : son rôle en une phrase, d'où on y arrive, où on va ensuite. Un écran orphelin ou un cul-de-sac est un bug de conception : signale-le.

### Étape 3 — Détailler chaque écran

Par écran : le contenu affiché champ par champ, les actions possibles et ce qu'elles déclenchent, les données nécessaires et d'où elles viennent, la hiérarchie de lecture (ce que l'œil voit en premier). Écris les **textes réels** — libellés, boutons, aides — pas des étiquettes génériques.

### Étape 4 — Les états, systématiquement

Pour chaque écran, les cinq états : **vide** (premier usage, aucune donnée), **chargement**, **erreur** (réseau, saisie, droits), **succès**, **hors ligne** si le contexte l'exige. C'est l'étape qu'on saute et qui coûte le plus cher ensuite.

### Étape 5 — Règles métier et messages

Les règles qui pilotent l'interface : validations, seuils, droits selon le profil, cas limites. Et la table des messages : pour chaque erreur, le texte exact vu par l'utilisateur, en langage humain et actionnable.

### Étape 6 — Prompt de génération

Termine par un **prompt prêt à coller** dans un outil de prototypage ou de génération d'interface, reprenant le parcours, les écrans et le ton — pour partir d'une base plutôt que d'une page blanche.

## Format de sortie
- **Livrable** : le parcours principal et les parcours secondaires, l'inventaire numéroté des écrans, le détail de chaque écran avec ses textes réels, les cinq états par écran, les règles métier, la table des messages et un prompt de génération prêt à coller.
- **Structure** : Markdown clair — answer-first, puis le détail ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Cinq états par écran, sans exception.** Un écran sans état vide ni état d'erreur est une spec incomplète.
2. **Textes réels, pas des étiquettes.** « Bouton principal » ne se met pas dans une spec : écris ce qui sera affiché.
3. **Contraintes de contexte respectées** : connexion limitée, petit écran, langue et niveau de lecture du public réel.
4. **Aucun écran orphelin ni cul-de-sac** : chaque écran a une entrée et une sortie.
5. **Pas de fonctionnalité inventée.** Un besoin non exprimé qui te semble évident est proposé à part, en suggestion clairement identifiée.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante en autonomie.** Cette skill prépare et propose ; tout envoi (candidat notifié, mentor sollicité, investisseur contacté), toute publication et toute écriture dans un système tiers est validée par l'utilisateur avant exécution.
- **Cloisonnement.** Ce que tu apprends d'une startup, d'un candidat ou d'un hub ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
