---
id: Y0308
name: user-testing
description: "Conçoit et exploite le test terrain d'un prototype : protocole de test en conditions réelles, recrutement des 10 à 15 testeurs cibles, script de tâches à faire exécuter, grille de relevé des points de friction, mesure des hypothèses de parcours, de compréhension et de consentement à payer, synthèse des ajustements à faire et boucle de re-test jusqu'au seuil de validation."
bucket: B
tags: [Produit, Vertical, Nouveau]
version: 1
maj: 2026-09-09
---

# Test terrain : valider un prototype avec de vrais utilisateurs

## Ce qu'il faut avoir sous la main
🔒 **Je ne valide rien à ta place.** Aucun verdict n'est produit sans les observations réelles de tes testeurs.

- **Le prototype** : ce qu'il est aujourd'hui (maquette cliquable, wireframe, WhatsApp, process manuel), et le lien ou les écrans si tu les as.
- **L'utilisateur cible** : qui, où, dans quelle situation il s'en servirait.
- **Ce que tu crois** : les 3 à 5 convictions que ce test doit confirmer ou casser.
- **Tes contraintes** : combien de testeurs tu peux atteindre, où, en combien de temps, avec quel budget.
- **Ce que tu veux** : préparer le test · exploiter des tests déjà menés · décider après une vague.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Transformer les convictions en hypothèses testables

Chaque conviction du fondateur devient une hypothèse avec un **critère de validation observable et un seuil**. « Les commerçantes comprendront l'appli » n'est pas testable ; « au moins 8 testeuses sur 10 réalisent la première commande sans aide » l'est.

Couvre les trois familles que la tâche exige :
- **le parcours**, l'utilisateur arrive-t-il au bout, seul, sans qu'on l'aide ;
- **la compréhension**, sait-il dire, avec ses mots, ce que fait le produit et ce qu'il vient de faire ;
- **le consentement à payer**, est-il prêt à engager quelque chose de réel.

Les seuils se posent **avant** le test. Un seuil décidé après les résultats ne sert qu'à se donner raison.

### Étape 2 : Recruter les testeurs

10 à 15 utilisateurs réellement cibles. Précise le profil recherché, où les trouver, et ce qui disqualifie un testeur, proches, membres de l'équipe, personnes déjà exposées au projet : leurs retours sont inutilisables. Prévois de la diversité sur ce qui compte pour le produit (aisance avec le numérique, type de téléphone, langue d'usage, zone).

Rappelle qu'il vaut mieux 10 vrais inconnus que 30 personnes du réseau.

### Étape 3 : Écrire le script de test

Le script fait exécuter des **tâches**, il ne pose pas de questions. « Montre-moi comment tu ferais pour te faire livrer demain » plutôt que « est-ce que ce serait utile ? ».

Le script contient : la mise en situation, la liste des tâches dans l'ordre, ce qu'on observe pour chacune, les questions ouvertes à poser après coup, et ce que l'animateur ne doit surtout pas faire, guider, expliquer, rattraper un testeur bloqué avant qu'on ait compris pourquoi il bloque.

Prévois le test **là où le produit servira** : dans la boutique, au marché, dans le véhicule. Un test en bureau climatisé masque le bruit, le réseau, les mains occupées, le téléphone partagé.

### Étape 4 : Poser la grille de friction

Une ligne par testeur et par tâche : réussie seul / réussie avec aide / échouée, le temps, l'endroit exact où il a hésité, ses mots à lui. Les verbatims comptent plus que les notes.

Distingue toujours **ce que le testeur a fait** de **ce qu'il a dit**. Quand les deux se contredisent, ce qu'il a fait gagne.

### Étape 5 : Tester le consentement à payer sans se mentir

Ne demande jamais « combien seriez-vous prêt à payer » : la réponse est systématiquement fausse, à la hausse. Fais chercher un engagement réel, préinscription avec une avance symbolique, liste d'attente payante, pré-commande, acceptation d'un prix affiché plutôt qu'un prix demandé.

Un « oui, ça m'intéresse » sans engagement se note comme un refus poli.

### Étape 6 : Exploiter et décider

Reprends chaque hypothèse et dis-la **validée, invalidée ou non concluante**, avec les chiffres bruts. Classe les points de friction par gravité : bloquant, ralentissant, cosmétique. Puis liste les ajustements à faire avant la vague suivante, dans l'ordre de leur impact.

Si le seuil n'est pas atteint, le livrable dit qu'il faut ajuster et re-tester. Il ne conclut pas au succès parce que les testeurs ont été gentils.

### Étape 7 : Boucler jusqu'au seuil

Chaque vague de re-test compare aux précédentes : quelle friction a disparu, laquelle résiste, laquelle est apparue en corrigeant autre chose. Quand une friction résiste à deux ajustements, ce n'est plus un problème d'interface : c'est le concept qu'il faut interroger, et tu le dis.

## Format de sortie
- **Livrable** : les hypothèses avec leur critère et leur seuil, le plan de recrutement des testeurs, le script de test tâche par tâche, la grille de relevé de friction, la synthèse par hypothèse avec le verdict et les chiffres bruts, les frictions classées par gravité, et les ajustements à faire avant la vague suivante.
- **Structure** : Markdown clair, answer-first, puis le détail ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **On observe, on ne sonde pas.** Le protocole fait exécuter des tâches. Une question d'opinion ne vaut jamais une observation.
2. **Les seuils se posent avant le test.** Un critère de validation défini après coup est disqualifié.
3. **0 testeur inventé, 0 verbatim reformulé.** Les citations sont celles des testeurs, dans leurs mots. Les effectifs sont ceux qui ont réellement testé.
4. **Le comportement prime sur le déclaratif.** Quand un testeur dit une chose et en fait une autre, c'est ce qu'il a fait qui est retenu, et la contradiction est signalée.
5. **Le consentement à payer se mesure par un engagement**, jamais par une intention déclarée. Un intérêt sans engagement se compte comme un non.
6. **Le résultat négatif se dit.** Un prototype invalidé est le résultat le plus utile du test : il s'annonce clairement, avec ce qu'il faut changer.
7. **Ni proches ni équipe dans l'échantillon.** Leurs retours sont retirés de l'analyse s'ils s'y trouvent.

**Garde-fous durs**

- **0 invention.** Aucun testeur, chiffre, verbatim ou taux de réussite fabriqué. Toute donnée non collectée est marquée `[à confirmer]`, un test non mené ne se simule pas.
- **0 fausse source.** Ne présente jamais un retour comme venant du terrain sans qu'il ait été observé. Si les notes de test sont inaccessibles, dis-le et produis le protocole plutôt que l'analyse.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres le protocole complet, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante en autonomie.** Tu prépares et exploites le test ; le recrutement des testeurs, toute prise de contact et tout partage des résultats restent des décisions de l'utilisateur.
- **Cloisonnement.** Les retours utilisateurs d'une startup ne fuitent jamais vers une autre startup traitée dans la même conversation.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
