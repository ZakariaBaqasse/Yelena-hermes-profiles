---
id: Y0411
name: modele-de-presentation
description: "Construit le jeu de gabarits réutilisables de l'entreprise — présentation, document, tableur — avec pages types couvrant les usages réels, styles nommés, couleurs et polices de la charte déjà posées, zones modifiables balisées, notice d'une page et procédure de mise à jour : pour que le prochain document soit correct sans repasser par le design."
bucket: B
tags: [Design, Livrables, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Le modèle maison — pour que tout le monde produise à la charte sans le designer

## Ce qu'il faut avoir sous la main
- **La charte graphique** existante : couleurs (codes exacts si tu les as), polices, logo et ses déclinaisons. Si elle n'existe pas encore ou qu'elle est incomplète, dis-le — je ne l'invente pas.
- **Le ou les supports** à modéliser : présentation, document Word, tableur, ou plusieurs.
- **Trois à cinq documents réels** déjà produits dans l'entreprise — même imparfaits, même anciens. C'est ce qui me dit la taille réelle des tableaux, la longueur réelle des textes, les pages qui reviennent tout le temps.
- **Les outils réellement utilisés** : PowerPoint, Google Slides, Word, Google Docs, Canva, Excel, Google Sheets.
- **Le canal de diffusion principal** : impression chez un imprimeur, envoi par mail, partage par WhatsApp, projection en réunion, dépôt sur un portail administratif.
- **Qui produira les documents ensuite** : l'équipe design seule, ou tout le monde.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 — Inventaire des usages réels, pas des usages imaginés

Regarde les documents fournis et liste les types de pages qui reviennent réellement : couverture, sommaire, page de texte, page à deux colonnes, page de tableau, page de graphique, page de citation, page de contact. N'ajoute pas de page type que personne n'utilise — un modèle trop riche est aussi abandonné qu'un modèle trop pauvre, parce que personne ne sait laquelle choisir.

Note les **volumes réels** : combien de lignes fait un tableau typique, combien de mots fait un paragraphe typique, combien de puces une diapositive porte en moyenne. C'est la donnée qui détermine si une page type survivra au premier usage réel — le piège n°5 se loge exactement là : une page de tableau dimensionnée pour six lignes d'exemple, alors que les tableaux de l'entreprise en comptent quarante, ne sert jamais.

### Étape 2 — Vérifier ce que la charte pose vraiment, et ce qu'elle ne pose pas

Reprends les couleurs, la ou les polices, le logo et ses déclinaisons fournis. Tout ce qui manque reste `⟦à renseigner⟧` — tu ne choisis pas une couleur ou une police à la place de l'entreprise, même une couleur « neutre et raisonnable ». Une charte inventée par la skill n'est pas une charte, c'est un habillage de plus à défaire.

Vérifie la disponibilité réelle des polices choisies : une police qui n'est pas installée chez tous les postes de l'entreprise, ni chez les partenaires à qui le document est envoyé, s'affiche autrement dès qu'elle quitte la machine qui l'a produite — le document perd sa mise en forme au moment précis où il compte, en pièce jointe WhatsApp ou par mail à un client. Retiens une police standard largement disponible, ou prévois l'intégration des polices dans le fichier, en signalant le compromis : un fichier plus lourd, plus lent à charger sur une connexion contrainte.

### Étape 3 — Construire les styles nommés, jamais le formatage manuel

Pour chaque niveau de texte, définis un style avec un nom explicite — titre de section, sous-titre, corps de texte, légende, citation — et applique-le partout dans le modèle. N'utilise jamais une mise en forme manuelle (gras ponctuel, taille changée à la main) là où un style nommé doit porter l'information.

C'est le piège n°3 : un titre mis en gras à la main plutôt que via un style « Titre 1 » empêche toute mise à jour globale de la charte. Six mois plus tard, changer une couleur de titre suppose de rouvrir chaque document un par un — personne ne le fait, et la charte dérive silencieusement, document après document.

### Étape 4 — Construire les pages types, robustes avant d'être élégantes

Pour chaque page type retenue à l'étape 1, construis-la en testant mentalement ce qui se passe quand le contenu déborde : une ligne de tableau de plus, un paragraphe de plus, un titre plus long que prévu. Une page qui casse ou exige de déplacer des blocs à la main dès qu'on dépasse l'exemple initial sera abandonnée à la première urgence — c'est le piège n°1, et c'est le plus fréquent.

Applique les couleurs et polices posées à l'étape 2 sur chaque page type — pas seulement sur la couverture, qui est souvent la seule page vraiment soignée dans les modèles ratés.

### Étape 5 — Baliser ce qui se modifie et ce qui reste fixe

Sur chaque page type, distingue explicitement les zones **verrouillées** — logo, marges, couleurs de fond, position des éléments de marque — et les zones **à remplir** — texte, image, données du tableau. Si l'outil le permet (modèle protégé, zones de texte réservées), verrouille réellement ; sinon, indique-le visuellement et dans la notice.

### Étape 6 — Écrire la notice d'une page

La notice répond à trois questions, pas plus : quelle page type utiliser pour quel besoin, ce qu'il ne faut jamais modifier, comment ajouter du contenu (une diapositive, une section) sans casser le style. C'est le piège n°2 — un jeu de pages types sans mode d'emploi produit des documents incohérents, parce que chacun improvise sa propre logique d'usage. La notice n'est pas un supplément, elle fait partie du livrable au même titre que les pages.

### Étape 7 — Poser la procédure de mise à jour de la charte

Décris ce qui se passe le jour où la charte change — nouveau logo, nouvelle couleur, nouvelle police. Qui est responsable de la propagation, quels fichiers sont à reprendre en premier (les styles nommés, précisément, puisqu'ils centralisent le changement), et comment on vérifie que les documents déjà en circulation ne sont pas à refaire un par un.

## Format de sortie
- **Livrable** : le jeu de modèles par support demandé — pages types couvrant les usages réels, styles nommés et documentés, couleurs et polices de la charte appliquées, zones modifiables et zones verrouillées clairement marquées — plus la **notice d'une page** et la **procédure de mise à jour** de la charte.
- **Structure** : answer-first — la notice et la liste des pages types livrées d'abord, le détail de construction (styles, volumes retenus, hypothèses) ensuite.
- **Longueur** : proportionnée au nombre de supports et de pages types demandés, sans remplissage ; la notice, elle, tient toujours en une page — c'est une contrainte du livrable, pas une option.
- **Zones modifiables vs verrouillées** : signalées explicitement sur chaque page type, pas seulement décrites dans le texte.
- **Règle 0 invention** : aucune couleur, police ou élément de logo choisi à la place de l'entreprise. Ce qui manque reste `⟦à renseigner⟧`.

## Règles
1. **Robustesse avant élégance.** Chaque page type est vérifiée contre un débordement de contenu — une ligne de tableau de plus, un paragraphe de plus — avant d'être jugée terminée. Une page qui casse à la première surcharge n'est pas livrable.
2. **Notice obligatoire, une page, jamais optionnelle.** Un jeu de pages types sans notice est un livrable incomplet, même s'il est visuellement parfait.
3. **Styles nommés uniquement.** Aucun formatage manuel dans le modèle livré ; chaque niveau de texte passe par un style identifiable, pour que la mise à jour de la charte reste globale.
4. **Polices vérifiées disponibles, ou intégrées.** Une police qui ne s'affiche pas correctement chez le destinataire fait perdre la mise en forme au moment de l'envoi — vérifie la disponibilité réelle, pas la disponibilité sur ton propre poste.
5. **Pages dimensionnées sur des volumes réels.** Les pages de tableau, de texte ou de graphique se construisent sur les documents réels fournis par l'entreprise, jamais sur un exemple générique inventé pour l'occasion.
6. **Zéro invention de charte.** Couleur, police, logo : ce que l'entreprise n'a pas fourni reste `⟦à renseigner⟧`. Tu ne combles jamais un manque de charte par un choix « raisonnable ».
7. **Le canal de diffusion réel conditionne le modèle.** Un document destiné à être imprimé chez un prestataire local, envoyé par WhatsApp en PDF, ou projeté en réunion n'a pas les mêmes contraintes de poids de fichier ni de rendu — tu le demandes et tu le prends en compte, tu ne conçois pas pour un seul usage implicite.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser le modèle à toute l'entreprise, l'envoyer à un imprimeur ou remplacer les fichiers existants est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Pas de charte graphique existante** — tu construis une base minimale (styles, structure de pages) et tu le dis explicitement : ce n'est pas une création d'identité visuelle, c'est hors périmètre de cette compétence. Tu orientes vers la skill dédiée à l'identité de marque.
- **Outils différents selon les équipes** (certains sur PowerPoint, d'autres sur Google Slides) — tu dupliques et adaptes le modèle par outil plutôt que de promettre une compatibilité parfaite qui n'existe pas.
- **Aucun exemple de document réel fourni** — tu construis sur des volumes types marqués `[hypothèse : …]` et tu demandes au moins un exemple réel avant de considérer les pages de tableau comme validées.
- **Modèle existant mais dérivé** — avant de reconstruire, tu diagnostiques la dérive (formatage manuel accumulé, police non disponible, styles non nommés) et tu le dis : reconstruire sans comprendre pourquoi l'ancien a dérivé reproduit le même échec.
- **Document destiné à l'impression chez un prestataire local** — tu vérifies que le modèle exporte correctement (couleurs, polices, marges) dans le format attendu par l'imprimeur, pas seulement à l'écran.
- **Demande de créer le logo ou l'identité visuelle elle-même** — hors périmètre de cette compétence ; tu le dis en une phrase et tu orientes vers la skill branding.
- **Polices intégrées alourdissant le fichier** — tu signales le compromis poids contre fidélité d'affichage et tu laisses le choix à l'équipe, tu ne trancres pas seul.
- **Action sortante demandée** (diffusion du modèle, envoi à un prestataire, remplacement des fichiers en circulation) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
