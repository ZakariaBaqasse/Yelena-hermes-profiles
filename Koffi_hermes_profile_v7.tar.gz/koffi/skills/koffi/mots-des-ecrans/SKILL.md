---
id: Y0420
name: mots-des-ecrans
description: "Écrit les textes que l'utilisateur lit vraiment dans une interface — messages d'erreur, états vides, confirmations, libellés de boutons, écrans d'attente — de sorte que chacun dise ce qui s'est passé, pourquoi, et quoi faire ensuite ; produit la table des messages exploitable par les développeurs, sans jamais inventer un motif de refus ni promettre un délai."
bucket: B
tags: [Design, Produit, Qualité, Nouveau]
version: 1
maj: 2026-08-13
---

# Les mots des écrans

## Ce qu'il faut avoir sous la main
- **Le parcours ou l'écran** concerné, et ce que la personne essaie d'y faire.
- **La liste des cas** que le produit sait rencontrer : refus, échec technique, délai, doublon, droit manquant, première visite. Même approximative.
- **Ce qui est affiché aujourd'hui**, si quelque chose l'est — capture ou copie du texte suffit.
- **Ce que l'utilisateur peut faire** dans chaque cas : réessayer, attendre, appeler quelqu'un, changer un réglage. C'est le seul point sans lequel je ne peux pas écrire.
- **Le ton de la maison** et le tutoiement ou vouvoiement retenu.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Écris la table avec les cas connus, et marque les motifs que personne ne t'a donnés plutôt que de les deviner.

## Process
### Étape 1 — Lister les moments, pas les écrans

Un message appartient à un moment du parcours, pas à une page. Inventorie les moments où le produit doit parler : première ouverture, liste vide, chargement, succès, refus, échec technique, perte de connexion, saisie invalide, droit manquant, action irréversible, fin de parcours. Un produit qui encaisse de l'argent en a toujours plus qu'on ne croit.

### Étape 2 — Pour chaque moment, séparer la cause de l'action

Deux colonnes avant d'écrire une phrase. À gauche, ce qui s'est réellement passé, dans les mots du système. À droite, ce que la personne peut faire, concrètement, avec ce qu'elle a sous la main. Si la colonne de droite est vide, le message ne s'écrit pas encore : il faut d'abord décider ce qu'on propose, et c'est une décision produit, pas une décision de rédaction.

### Étape 3 — Écrire, dans cet ordre : le fait, la raison, l'action

Le fait d'abord, parce que c'est ce qu'on cherche en lisant. La raison ensuite, seulement si elle est connue et utile. L'action en dernier, formulée à l'impératif et réalisable sans quitter l'écran quand c'est possible.

Quatre interdits, qui reviennent tous :
- **Pas de « Oups ».** Un ton badin sur un paiement refusé insulte celui qui attend son argent.
- **Pas de code technique seul.** Un identifiant d'erreur peut accompagner un message, jamais le remplacer.
- **Pas de délai promis** que personne ne garantit : « sous 24 heures » est un engagement, pas une formulation.
- **Pas de faux nous.** « Nous rencontrons un problème » quand c'est la connexion de la personne qui a lâché est faux, et ça envoie appeler le support pour rien.

### Étape 4 — Traiter l'état vide comme un écran de plein droit

Une liste vide est le premier écran que voit tout nouvel utilisateur : c'est le moment le plus favorable du produit et il est presque toujours gaspillé. Il dit ce qui apparaîtra ici, pourquoi c'est vide maintenant, et l'action qui le remplit.

### Étape 5 — Vérifier la longueur contre la place réelle

Chaque message est écrit pour la largeur où il s'affichera, et se relit sur la plus petite. Un texte juste qui se coupe en deux lignes dans un bandeau prévu pour une seule est un texte à réécrire, pas un problème de développeur.

### Étape 6 — Rendre la table, et la rendre applicable

Un identifiant par message, le texte exact, le titre s'il y en a un, le libellé du bouton, et le comportement attendu. C'est ce que le développeur colle ; s'il doit interpréter, la table n'est pas finie.

## Format de sortie
- **Livrable** : une table des messages — identifiant, moment, titre, texte, libellé d'action, comportement — suivie des cas repérés dont le motif ou l'action n'a pas été fourni, listés nommément.
- **Structure** : un bloc par parcours ; les messages transverses regroupés à part pour éviter les doublons.
- **Longueur** : proportionnée au nombre de moments, jamais gonflée. Vingt messages justes valent mieux que soixante variantes.

## Règles
1. **Trois questions ou rien.** Ce qui s'est passé, pourquoi, quoi faire. Un message qui n'a pas d'action possible le dit explicitement plutôt que de laisser la personne chercher.
2. **0 motif inventé.** Un refus a une cause technique réelle ; si personne ne t'a dit laquelle, tu écris un message qui n'affirme aucune cause, plutôt qu'un message qui en invente une plausible.
3. **0 délai promis.** Aucune durée, aucun « rapidement », aucun « sous peu » sans engagement écrit fourni par la maison.
4. **La personne n'est jamais fautive.** On dit ce qui manque, pas ce qu'elle a mal fait.
5. **Le même événement porte le même mot partout.** Une table des messages sert aussi à ça : un refus ne s'appelle pas « rejeté » dans un écran et « annulé » dans un autre.
6. **Le vocabulaire vient du métier de la personne**, pas du modèle de données. Ce que le système nomme « transaction » se dit peut-être « encaissement » chez elle — et c'est à elle qu'on demande, pas à soi.
7. **Rien ne se traduit à l'aveugle.** Une autre langue se rédige, pas se transpose ; et le contrôle de couverture des caractères de la police se refait sur les textes réels.

## Cas limites
- **Cause inconnue du système lui-même** — le message dit ce qui est certain (l'opération n'a pas abouti) et l'action, sans inventer de raison.
- **Action irréversible** — le message nomme la conséquence exacte avant de demander confirmation, et le bouton porte le verbe de l'action, jamais « OK ».
- **Perte de connexion** — distinguer ce qui est perdu de ce qui est conservé ; c'est la seule information que la personne cherche.
- **Message affiché à un tiers** (un client du commerçant, par exemple) — vérifier ce qu'il révèle du commerçant avant de l'écrire.
- **Contrainte de place très courte** (bandeau, notification) — écrire le fait seul, et porter la raison et l'action dans l'écran qui suit.
- **La maison n'a pas de ton défini** — proposer deux registres sur trois messages réels et faire trancher, plutôt que d'imposer.
