---
id: Y0053
name: 13-prototype
description: "Benchmark d'apps mobiles comparables + prompt UX Pilot prêt à coller."
bucket: B
tags: [Design]
version: 1
maj: 2026-08-10
---

# Prototype — Benchmark d'apps comparables

## Ce qu'il faut avoir sous la main
1. **Nom de ta startup**
2. **One-liner** — une phrase sur ce que fait ton app (*ex. "Application de gestion de budget personnel avec IA"*)
3. **Cible utilisateur** (*ex. "Jeunes actifs 25-35 ans", "PME en Afrique", "Parents d'enfants 0-3 ans"*)
4. **4 à 6 comparables** que tu identifies déjà (*ex. "Vendease, Njacart, Yolafresh, Nile, Frubana"*)

## Process
### 1. Analyse des inputs
- Identifier le secteur d'activité principal
- Extraire les fonctionnalités clés du one-liner
- Identifier la zone géographique cible (si mentionnée)
- Déterminer le segment d'utilisateurs
- Lister les mots-clés de recherche prioritaires

### 2. Recherche des applications comparables [connecteur à brancher : recherche web — Google Play Store + Apple App Store]

Sources consultées, par priorité :
- Google Play Store (recherche directe par mots-clés) — priorité haute
- Apple App Store (recherche directe par mots-clés) — priorité haute
- Articles de comparaison d'apps — priorité moyenne
- Listes d'applications par catégorie — priorité moyenne

Critères de sélection :
- Fonctionnalités similaires au one-liner fourni
- Même cible utilisateur ou segment proche
- Application active (mise à jour récente)
- Disponible sur au moins un des deux stores
- Diversité des approches

Cible : 8 à 10 applications pertinentes.

### 3. Extraction des informations par application

Pour chaque application identifiée :
- Nom de l'application
- Description courte (max 150 caractères)
- Liens Play Store et App Store (cliquables)
- Note utilisateurs (X/5)
- Nombre de téléchargements
- Points forts / différenciateurs
- Patterns UX observables (réutilisés à l'étape 6)

### 4. Tableau comparatif

Colonnes : N° · Nom de l'Application · Description · Play Store · App Store · Note · Téléchargements · Points Forts.

### 5. Analyse synthétique

- Tendances du marché (fonctionnalités communes)
- Modèles économiques
- Différenciateurs clés
- Opportunités identifiées
- Notes moyennes du secteur
- Patterns UX/UI récurrents (réutilisés à l'étape 6)

### 6. Génération du prompt UX Pilot

Objectif : synthétiser les meilleures pratiques UX/UI identifiées dans le benchmarking pour permettre à UX Pilot de générer une interface optimale pour la startup.

Le prompt généré doit couvrir :
- **Contexte de la startup** — nom, one-liner, cible utilisateur
- **Insights du benchmarking** — fonctionnalités clés des concurrents, patterns UX/UI récurrents, éléments différenciateurs qui fonctionnent, modèles de navigation dominants, styles visuels préférés par la cible
- **Opportunités de différenciation** — gaps identifiés, fonctionnalités manquantes ou mal exécutées, axes d'innovation UX possibles
- **Best practices à intégrer** — patterns UX éprouvés, onboarding efficace, navigation intuitive, features de rétention observées
- **Contraintes et préférences de la cible** — niveau de technicité de l'audience, préférences esthétiques probables, contextes d'usage principaux
- **Objectifs UX prioritaires** — objectif primaire de l'interface, parcours utilisateur critique, métriques de succès UX

Structure du prompt final, en 5 sections dans cet ordre : CONTEXTE → INSIGHTS BENCHMARK → OPPORTUNITÉS → RECOMMANDATIONS UX → BRIEF CRÉATION.

> ⚠️ **Anomalie de source (non corrigée en silence)** : le prompt d'origine (version 22, 25/05/2026) s'arrête avant de fournir un exemple rempli de ce bloc des 5 sections — seule la liste des éléments à couvrir (ci-dessus) est spécifiée, jamais un gabarit rédigé. Au rejeu, produire les 5 sections à partir de cette liste plutôt qu'improviser une structure différente.

## Format de sortie
```markdown
---
# 🔍 BENCHMARKING APPLICATIONS MOBILES

## Règles
1. **Collecter les 4 inputs en un seul message** avant de lancer la recherche (nom, one-liner, cible, comparables) ; si le one-liner est trop vague, demander des précisions sur les fonctionnalités principales plutôt que deviner.
2. **Rechercher activement** sur Google Play Store ET Apple App Store via [connecteur à brancher : recherche web] — ne jamais lister une application sans l'avoir vérifiée.
3. **Cibler 8 à 10 applications actives et pertinentes** ; si moins de 8 sont réellement identifiées, le dire explicitement et livrer ce qui est disponible plutôt que compléter par invention.
4. **Vérifier chaque lien** Play Store / App Store avant de le livrer (valide et cliquable) ; si une app n'existe que sur un store, l'indiquer clairement (« — » dans l'autre colonne) ; si une information est inaccessible, écrire « N/A », jamais une valeur inventée.
5. **Livrer les trois blocs dans l'ordre** : tableau comparatif → analyse synthétique des tendances → prompt optimisé pour UX Pilot prêt à copier-coller.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- Aucune application comparable trouvée → élargir les critères de recherche.
- Moins de 8 applications identifiées → l'indiquer explicitement et livrer celles disponibles, sans compléter par invention.
- Application disponible sur un seul store → l'indiquer clairement (« — » dans la colonne du store absent).
- Information inaccessible → écrire « N/A ».
- One-liner trop vague → demander des précisions sur les fonctionnalités principales avant de lancer la recherche.

## Connecteurs & datasources requis
- **Recherche web / navigation** [connecteur à brancher : Google Play Store + Apple App Store — recherche d'applications comparables, vérification des liens/notes/téléchargements, sources secondaires (articles de comparaison, listes par catégorie)] — seul connecteur identifié dans le prompt source ; aucun couplage Sheet/Notion/Drive.

## Détails complémentaires
### 📋 INFORMATIONS STARTUP

**Nom :** [Nom de la startup]  
**Description :** [One-liner]  
**Cible :** [Cible utilisateur]  
---

### 📊 TABLEAU COMPARATIF DES APPLICATIONS SIMILAIRES

| N° | Nom de l'Application | Description | Play Store | App Store | Note | Téléchargements | Points Forts |
|----|---------------------|-------------|------------|-----------|------|-----------------|--------------|
| 1  | [Nom App 1] | [Description courte] | [📱 Play Store](URL) | [🍎 App Store](URL) | 4.5/5 | 1M+ | [Points forts] |
| 2  | [Nom App 2] | [Description courte] | [📱 Play Store](URL) | — | 4.2/5 | 500K+ | [Points forts] |
| 3  | [Nom App 3] | [Description courte] | — | [🍎 App Store](URL) | 4.7/5 | N/A | [Points forts] |
| 4  | [Nom App 4] | [Description courte] | [📱 Play Store](URL) | [🍎 App Store](URL) | 4.3/5 | 100K+ | [Points forts] |
| 5  | [Nom App 5] | [Description courte] | [📱 Play Store](URL) | [🍎 App Store](URL) | 4.6/5 | 2M+ | [Points forts] |
| 6  | [Nom App 6] | [Description courte] | [📱 Play Store](URL) | — | 4.1/5 | 50K+ | [Points forts] |
| 7  | [Nom App 7] | [Description courte] | [📱 Play Store](URL) | [🍎 App Store](URL) | 4.4/5 | 300K+ | [Points forts] |
| 8  | [Nom App 8] | [Description courte] | — | [🍎 App Store](URL) | 4.8/5 | N/A | [Points forts] |
*Légende : 📱 = Google Play Store | 🍎 = Apple App Store | — = Non disponible*
---

### 📈 ANALYSE SYNTHÉTIQUE

### 🎯 Tendances Observées
- **[Tendance 1]** : [Description]
- **[Tendance 2]** : [Description]
- **[Tendance 3]** : [Description]
### 💰 Modèles Économiques
- [X applications] utilisent un modèle freemium
- [Y applications] sont entièrement gratuites avec publicités
- [Z applications] proposent des abonnements premium
### 🎨 Patterns UX/UI Récurrents
- **Navigation** : [Pattern dominant - ex: bottom tab bar, hamburger menu, etc.]
- **Onboarding** : [Approche commune - ex: tutoriel interactif, skip option, etc.]
- **Fonctionnalités principales** : [Où et comment elles sont accessibles]
- **Visualisation de données** : [Graphiques, tableaux, cards, etc.]
- **Style visuel** : [Minimaliste, coloré, material design, etc.]
### 🌟 Différenciateurs Clés
- **[Différenciateur 1]** : [Explication]
- **[Différenciateur 2]** : [Explication]
- **[Différenciateur 3]** : [Explication]
### 💡 Opportunités Identifiées
- **[Opportunité 1]** : [Gap UX/fonctionnel non couvert]
- **[Opportunité 2]** : [Gap UX/fonctionnel non couvert]
- **[Opportunité 3]** : [Gap UX/fonctionnel non couvert]
### ⭐ Niveau de Satisfaction Marché
- Note moyenne du secteur : **X.X/5**
- [Analyse du niveau de satisfaction général]
---

### 🎯 RECOMMANDATIONS

**Points d'attention pour [Nom Startup] :**
1. **[Recommandation 1]** : [Action suggérée]
2. **[Recommandation 2]** : [Action suggérée]
3. **[Recommandation 3]** : [Action suggérée]
---

### 🎨 PROMPT OPTIMISÉ POUR UX PILOT

**📋 Copiez-collez ce prompt dans UX Pilot pour générer l'interface de votre application**
[5 sections CONTEXTE / INSIGHTS BENCHMARK / OPPORTUNITÉS / RECOMMANDATIONS UX / BRIEF CRÉATION — voir "Génération du prompt UX Pilot" ci-dessus]
```
