---
id: Y0415
name: bibliotheque-icones
description: "Recommande la famille d'icônes qu'une entreprise doit adopter et pose les règles qui la maintiennent cohérente dans le temps : inventaire des concepts à représenter, vérification de couverture concept par concept, lecture de la licence à la source, choix de format, règles d'usage et interdiction du mélange de familles — sans jamais fixer de taille, de couleur ou de seuil de couverture de mémoire."
bucket: B
tags: [Design, Marque, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Choisir une famille d'icônes — et s'y tenir

## Ce qu'il faut avoir sous la main
- **La liste des concepts à représenter**, écran par écran ou support par support — y compris ceux propres à ton métier (mobile money, enseigne, marché, etc.). Pas une liste d'icônes déjà trouvées : une liste de *sens* à porter.
- **La ou les familles candidates**, si tu en as déjà une en tête, avec le fichier ou le lien vers la source officielle (fichiers, licence).
- **Le public visé** et son habitude réelle des interfaces à pictogrammes — application, messagerie, les deux.
- **Les supports concernés** : écran seul, impression, enseigne, broderie ou gravure.
- **Ce qui existe déjà** dans ta charte : typographie, couleurs, éventuelles icônes déjà en usage.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Inventorier les concepts, pas les icônes

Liste tous les concepts à représenter, écran par écran ou support par support. Sépare deux catégories : les concepts génériques (rechercher, fermer, envoyer) qu'à peu près toute famille couvre, et les concepts propres au métier de l'entreprise (mobile money, enseigne de kiosque, produit local) que la plupart des familles généralistes ignorent.

C'est cette seconde catégorie qui casse presque toujours — et elle se découvre au moment où l'écran doit être livré, pas avant, si personne ne l'a listée dès le départ. Fais-la lister explicitement par l'entreprise plutôt que de la deviner.

### Étape 2 — Vérifier la couverture, concept par concept

Prends la famille candidate et coche, un par un, chaque concept de la liste établie à l'étape 1. Ne te fie jamais à une impression générale (« cette famille a l'air complète ») : une famille peut compter un grand nombre d'icônes et rater précisément les trois dont l'entreprise a besoin.

Pour chaque concept non couvert, note-le explicitement — il ne se résout pas à cette étape, il devient un point à trancher à l'étape 6.

### Étape 3 — Comparer sur les critères qui décident

Si plusieurs familles sont en lice, compare-les sur ce qui décide réellement, jamais sur le goût :
- **style de trait et épaisseur** — cohérent avec le poids visuel du reste de la marque ;
- **grille de construction** — la logique géométrique qui rend une icône reconnaissable comme appartenant à la même famille que ses voisines ;
- **variantes pleines et ajourées** — utiles pour distinguer un état actif d'un état inactif, si le besoin existe ;
- **nombre de concepts couverts**, mesuré sur la liste de l'étape 1, pas sur le catalogue général de la famille ;
- **format de fichier fourni** et **licence**, traités en détail aux étapes suivantes.

### Étape 4 — Lire la licence à la source

Ouvre le fichier de licence livré avec la famille — jamais la page de présentation ou le résumé qu'en fait un site tiers. Distingue explicitement l'usage d'un fichier isolé (affichage courant sur écran) de l'incorporation dans un produit, un logo ou une enseigne : c'est cette seconde catégorie qui pose problème, rarement la première. Certaines licences imposent une mention, d'autres interdisent la modification du tracé, d'autres distinguent usage commercial et usage éditorial.

Si le fichier de licence n'est pas disponible, dis-le explicitement plutôt que de reconduire ce qui est écrit sur une page marketing.

### Étape 5 — Vérifier le format contre le support réel

Une icône vectorielle reste nette à toute taille et prend la couleur qu'on lui donne ; une icône matricielle se dégrade à l'agrandissement et ne se recolore pas. Sur un support imprimé en grande taille, l'écart est visible immédiatement — exige le format vectoriel dès qu'une icône doit changer de taille ou de couleur selon le contexte.

Si une icône doit être brodée ou gravée, elle n'obéit pas aux mêmes contraintes de finesse qu'une icône d'écran : le trait fin disparaît à l'exécution. Signale ce support à part et prévois qu'une adaptation — pas un simple export — sera nécessaire.

### Étape 6 — Traiter les concepts non couverts

Pour chaque concept resté sans icône à l'étape 2, pose une des trois issues, jamais une quatrième :
- **dessiner sur la grille de la famille retenue** — en respectant son style de trait et sa logique de construction, pour qu'elle reste indiscernable des icônes d'origine ;
- **contourner par le libellé** — remplacer l'icône manquante par un mot ou une combinaison texte + icône générique proche ;
- **changer de famille** — si les concepts manquants sont trop nombreux ou trop centraux au métier pour être compensés.

Ce que tu interdis explicitement : emprunter une icône à une autre famille pour combler le trou. C'est le geste qui semble anodin sur le moment et qui installe le mélange, discrètement, un ajout après l'autre.

### Étape 7 — Poser les règles d'usage et rendre la recommandation

Formalise les règles qui maintiennent la cohérence dans le temps — tailles autorisées, couleurs autorisées, alignement avec le texte — en les traçant vers la charte existante ou en les laissant `⟦à renseigner⟧` si aucune valeur n'a été fournie. Ajoute l'obligation de libellé et l'interdiction de mélange comme règles non négociables, avec la procédure de recours de l'étape 6 en cas de concept manquant futur.

Rends la recommandation finale : la famille retenue, sa raison, l'état de la couverture, l'état de la licence, le format des fichiers.

## Format de sortie
- **Livrable** : la note de recommandation — famille retenue avec la raison, couverture vérifiée concept par concept sur la liste réellement fournie, concepts non couverts et solution prévue pour chacun, état de la licence avec sa source lue, format des fichiers. Puis les règles d'usage : tailles autorisées, couleurs autorisées, alignement avec le texte, obligation de libellé, interdiction de mélange, procédure d'ajout d'une icône manquante. Enfin la liste des icônes retenues, avec pour chacune le concept qu'elle représente et le libellé qui l'accompagne.
- **Structure** : Markdown clair — answer-first (la famille retenue et sa raison d'abord), tableau de couverture concept par concept, liste des règles.
- **Longueur** : proportionnée au nombre de concepts et de supports, sans remplissage.
- **Les valeurs de taille, de couleur et de seuil de couverture sont un input**, pas une production : la note livre la structure de la règle et la question à trancher ; la **valeur** vient de la charte existante ou de l'équipe et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Une icône ne porte jamais seule une action importante.** Elle est toujours accompagnée d'un libellé. La lecture d'un pictogramme est culturelle et apprise — l'écart est réel entre un public urbain habitué aux applications et un public qui utilise surtout la messagerie et le mobile money. Une interface qui n'affiche que des pictogrammes se teste avant d'être livrée, auprès de quelqu'un du public visé, pas par auto-conviction de l'équipe.
2. **Le mélange de familles est interdit, sans exception de circonstance.** Le symptôme apparaît tard, quand une icône manquante est prise ailleurs « juste pour cette fois ». La procédure de recours de l'étape 6 s'applique systématiquement à sa place.
3. **La licence se lit à la source.** Jamais sur une page de présentation ou un résumé tiers — dans le fichier de licence livré avec la famille. L'usage isolé et l'incorporation dans un logo ou une enseigne sont examinés séparément.
4. **Le format vectoriel est requis dès qu'une icône doit changer de taille ou de couleur.** Le format matriciel n'est acceptable que pour un usage figé, à taille et couleur fixes, jamais pour un système destiné à évoluer.
5. **La couleur seule ne porte jamais la distinction entre deux icônes.** Une différence purement chromatique devient indistincte pour une partie des lecteurs et disparaît à l'impression en noir et blanc. La forme doit porter le sens.
6. **0 chiffre inventé.** Aucune taille, aucune valeur de couleur, aucun seuil de couverture minimal n'est produit sans être fourni ou sourcé (charte, fichier de licence, mesure faite avec un outil) : `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; acheter une licence, publier un fichier ou modifier un dépôt de design est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Liste de concepts non fournie** — tu ne devines pas la liste, tu la demandes explicitement : c'est la pièce sans laquelle la vérification de couverture n'a pas de sens. Tu peux, en attendant, poser la méthode et les critères de comparaison des familles.
- **Famille déjà imposée par une tutelle publique ou un groupe** — tu ne rediscutes pas le choix, tu appliques le process de vérification de couverture et de règles d'usage à la famille imposée, et tu signales explicitement les concepts qu'elle ne couvre pas.
- **Fichier de licence introuvable** — tu le dis explicitement, tu ne reconduis jamais ce qui est écrit sur une page de présentation comme s'il s'agissait de la licence elle-même.
- **Icônes déjà en usage, mélangées, découvertes en cours de mission** — tu le signales comme un fait constaté, tu proposes la remise à plat (famille unique + traitement des manques) plutôt qu'un rattrapage partiel.
- **Support de broderie, gravure ou enseigne** — tu le traites à part explicitement : le trait fin qui fonctionne à l'écran ne survit pas à l'exécution, et une adaptation dédiée est nécessaire, pas un simple export.
- **Public non testé sur la lisibilité des pictogrammes** — tu recommandes le test avant livraison et tu marques la recommandation comme provisoire sur ce point tant qu'il n'a pas eu lieu.
- **Demande hors périmètre** (création de la charte graphique complète, choix de la typographie) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (achat de licence, publication d'un kit d'icônes) — tu prépares la recommandation et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (page de présentation vs fichier de licence réel) — tu exposes l'écart et tu demandes l'arbitrage plutôt que de trancher seul.
