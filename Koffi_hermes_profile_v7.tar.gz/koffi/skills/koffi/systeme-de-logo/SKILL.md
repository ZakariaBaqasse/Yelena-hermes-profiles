---
id: Y0419
name: systeme-de-logo
description: "Décline un logo existant en un jeu complet de versions utilisables — horizontale, compacte, symbole seul, monochrome, inversée — et fixe pour chacune son terrain d'emploi : fonds autorisés, taille minimale par technique de reproduction, zone de dégagement, cohabitation avec d'autres marques. Produit le tableau de fichiers livrés et la liste des usages interdits — sans jamais inventer une taille minimale, une valeur colorimétrique ou un poids de fichier."
bucket: B
tags: [Design, Marque, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le logo et ses déclinaisons — le faire tenir partout

## Ce qu'il faut avoir sous la main
- **Le fichier source du logo**, si possible vectoriel — sinon dis-moi ce que tu as (image, PDF, capture, rien du tout).
- **Où ce logo apparaît déjà aujourd'hui** : site, papier en-tête, enseigne, véhicule, tenue du personnel, réseaux sociaux, documents administratifs.
- **Où il devra apparaître demain** que tu connais déjà : nouveau support, nouvel imprimeur, nouveau partenaire.
- **Les marques avec lesquelles il cohabite** s'il y en a : tutelle publique, bailleur, partenaire — et si tu as leurs règles de logo.
- **Ce qui existe déjà en version alternative** (mono, inversé, symbole seul) même fait à la main en urgence — ça compte comme matière de départ.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Avant de proposer une forme : le répertoire de gestes

⛔ **`memory/reference/repertoire-gestes-logo.md` s'ouvre AVANT de dessiner une piste** — neuf
familles de gestes relevées sur trois planches de logos professionnels reçues le 09/09/2026,
et les quatre défauts qu'elles corrigent chez moi. Ce qui en découle, et qui ne se néglige pas :

- **Deux pistes se prennent dans deux familles différentes**, et je nomme la famille de chacune.
  Deux découpes, deux plis ou deux volumes, ce sont deux variantes, pas deux directions — le
  client croit alors choisir alors qu'il n'a qu'une proposition.
- **Le premier essai part de l'initiale du nom**, pas d'une forme abstraite ni d'une image du
  métier.
- **Un seul geste par logo**, deux couleurs au plus, le symbole tient dans un carré.
- **Chaque piste s'éprouve en avatar carré et en une seule couleur** avant d'être montrée.

## Process
### Étape 1 — Inventorier les usages réels avant de dessiner quoi que ce soit

Liste tout ce sur quoi le logo apparaît ou apparaîtra : écran, papier, tissu, métal, bois, mur peint, véhicule, tampon. Pour chaque support, note la technique de reproduction qui s'y applique — impression numérique, sérigraphie, broderie, gravure, peinture d'enseigne — parce que c'est elle, et non le support en lui-même, qui fixe ce que le logo peut ou ne peut pas porter comme détail.

Le piège classique ici est de construire le jeu de versions à partir de ce qu'on imagine plutôt que de ce qui existe déjà chez l'entreprise. Un logo brodé sur une casquette avec un dégradé fin, une signature manuscrite ou un texte trop petit ne se répare pas après coup : la broderie ne rend pas ce que le fichier promet. Fais cet inventaire avant de produire une seule version — c'est lui qui dicte le nombre de versions nécessaires, pas une liste standard.

### Étape 2 — Construire le jeu de versions

À partir de l'inventaire, produis les versions qui répondent à une contrainte réellement identifiée :
- **Version horizontale** — pour les bandeaux larges et étroits en hauteur.
- **Version compacte ou empilée** — pour les formats carrés, les vignettes, les documents étroits.
- **Symbole seul** — pour les avatars, les très petites tailles, les usages où le nom complet ne rentre pas.
- **Version monochrome** — pour l'impression noir et blanc, la gravure, le tampon, la photocopie.
- **Version inversée (fond sombre)** — pour les supports foncés, les vidéos, les fonds photo.

Un jeu est incomplet tant qu'une contrainte réelle de l'étape 1 n'a pas sa réponse dans ce jeu — pas tant qu'il ne coche pas une liste standard. Si l'entreprise n'a par exemple aucun usage sur fond sombre identifié, tu le dis plutôt que de produire une version inversée par réflexe ; à l'inverse, un usage réel sans version dédiée est un manque que tu signales explicitement.

### Étape 3 — Fixer les fonds autorisés et interdits

Pour chaque version, dis sur quels fonds elle peut être posée et sur lesquels elle ne le peut pas — couleur unie claire, couleur unie sombre, photo, motif, papier non blanc, tissu coloré. Un logo validé une fois sur fond blanc en réunion finit toujours, dans la vraie vie, sur une photo Facebook, un tissu de pagne, une enseigne peinte ou un document photocopié dans un cybercafé : les versions monochrome et inversée ne sont pas une option esthétique, elles sont ce qui évite qu'un collaborateur ou un imprimeur bricole un détourage à la main, avec le halo blanc que ça laisse presque toujours.

Note aussi ce qui se passe en diffusion réelle et pas seulement en impression : un logo transmis par WhatsApp est recompressé, parfois plusieurs fois avant d'atteindre son usage final. Signale-le comme un fond à part entière — celui de la compression — et recommande de repartir du fichier source à chaque nouvelle diffusion plutôt que de renvoyer une capture déjà dégradée.

### Étape 4 — Fixer les tailles minimales, technique par technique

Le seuil sous lequel le logo devient illisible n'est pas le même à l'écran, à l'impression, en broderie, en gravure ou sur une enseigne peinte au pinceau : chaque technique a sa propre finesse de restitution, et un seuil pensé pour un écran haute définition n'a aucune valeur pour un tampon en caoutchouc ou une enseigne réalisée avec les moyens d'un atelier local.

Tu ne calcules ni ne devines ces seuils : tu les demandes à qui va reproduire le logo — imprimeur, brodeur, graveur, peintre d'enseigne — ou tu les fais mesurer par un essai physique. Tant qu'ils ne sont pas connus, tu marques `⟦à mesurer⟧` face à chaque technique, dans le tableau, plutôt que d'inscrire une valeur qui a l'air raisonnable. Un seuil inventé qui se révèle faux se découvre en général au moment où l'imprimeur remet un tirage illisible — le refaire coûte plus cher que d'avoir attendu la réponse.

Pense aussi au terrain de lecture, pas seulement à la technique : un logo sur une enseigne extérieure se lit en plein soleil, souvent de loin et en mouvement ; un logo sur un avatar se lit sur un écran d'entrée de gamme, parfois abîmé. Ce sont des raisons de resserrer les tailles minimales, pas des chiffres à produire toi-même.

### Étape 5 — Fixer la zone de dégagement

Pour chaque version, définis l'espace minimal à laisser autour du logo avant tout autre élément — texte, bord de page, autre logo. Exprime cette zone en unité tirée du logo lui-même (par exemple la hauteur du symbole), jamais en valeur absolue fixe : une unité relative se transpose à toute taille, un chiffre absolu ne survit pas au redimensionnement.

C'est cette zone qui empêche le logo d'être collé à un bord de carte de visite, écrasé contre un texte ou noyé dans un alignement de logos partenaires — le cas suivant.

### Étape 6 — Traiter la cohabitation avec d'autres marques

Dès qu'une entreprise travaille avec une tutelle publique, un bailleur ou un partenaire, son logo apparaît dans un alignement de logos qui obéit à des règles d'ordre, de taille relative et d'espacement — et ces règles ne sont pas les siennes, elles appartiennent à l'autre marque.

Identifie chaque cohabitation connue et cherche si les règles de l'autre marque existent et sont accessibles. Si elles ne sont pas fournies, marque `⟦règles à obtenir auprès de [partenaire]⟧` et ne fixe rien à sa place — inventer un ordre ou une taille relative pour une marque qui n'est pas la tienne est un des cas où l'invention coûte le plus cher, parce qu'elle engage une image qui ne t'appartient pas.

### Étape 7 — Produire et nommer les fichiers

Sépare toujours le **fichier source modifiable** (vectoriel de préférence) de l'**export diffusable** prêt à l'emploi. Le fichier vectoriel est ce qui permet toute reprise ultérieure — nouvelle couleur, nouvelle taille, nouveau support ; sa perte oblige à redessiner le logo depuis rien. Cherche où se trouve cette source, et si elle n'existe pas ou est introuvable, dis-le franchement plutôt que de composer avec un export matriciel comme s'il pouvait tout faire : un logo diffusé uniquement en image matricielle se dégrade à l'agrandissement, se découpe mal sur un fond et arrive chez l'imprimeur sans rien d'exploitable.

Nomme chaque fichier de façon à ce que personne n'ait à deviner lequel prendre : la version (horizontale, symbole, mono, inversée), le fond auquel il est destiné, et le format. Le format d'export lui-même (matriciel, vectoriel, quelle famille précise) est choisi selon l'usage désigné à l'étape 1 — pas selon une habitude ; tu peux nommer les familles de formats et dire à quoi chacune sert, sans en inventer les caractéristiques techniques précises (résolution, poids, profil colorimétrique), qui restent `⟦à renseigner⟧` ou relèvent d'un outil de vérification.

### Étape 8 — Lister les usages interdits

Le jeu de versions n'a de valeur que si le document dit aussi ce qui est interdit — pas seulement ce qui est permis. Liste explicitement : les déformations (étirement, écrasement), les recolorations libres, la recomposition du nom dans une autre police, le détourage manuel sur un fond non prévu, l'ajout d'effets (ombre, contour, dégradé) non fournis dans le jeu, l'utilisation d'une version en dessous de sa taille minimale.

Chaque silence sur un usage non couvert devient, dans les faits, une liberté prise par quelqu'un qui a besoin d'une solution dans l'urgence. Nommer l'interdit avant que la situation se présente coûte moins cher que de la corriger après.

## Format de sortie
- **Livrable** : le jeu de versions — pour chacune, sa fonction, le terrain d'emploi, les fonds autorisés et interdits, sa taille minimale par technique de reproduction (`⟦à mesurer⟧` si non connue), sa zone de dégagement en unité relative au logo. Le tableau des fichiers livrés, séparant sources modifiables et exports diffusables, avec le nom exact et l'usage de chaque fichier. La liste des usages interdits. Le traitement de la cohabitation avec d'autres marques, avec `⟦règles à obtenir⟧` quand elles manquent.
- **Structure** : Markdown clair — tableaux pour le jeu de versions et le tableau de fichiers, listes pour les fonds, les tailles et les interdits.
- **Longueur** : proportionnée au nombre de supports réellement identifiés à l'étape 1 — pas une liste standard reproduite par habitude.
- **Les tailles minimales, les valeurs colorimétriques précises et les poids de fichiers sont un input**, jamais une production : la skill livre la structure du tableau et la technique concernée, la **valeur** vient d'une mesure ou de l'équipe et reste `⟦à mesurer⟧` ou `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée, colorimétrique ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Un seul fichier livré n'est jamais un livrable complet.** Faute de version adaptée à un usage réel, quelqu'un improvise, et l'improvisation devient variante qui circule. Le jeu se juge complet contre l'inventaire des usages, pas contre une liste standard.
2. **0 seuil inventé.** Aucune taille minimale, aucune valeur colorimétrique, aucun poids de fichier n'est produit sans mesure ou source : `⟦à mesurer⟧` ou `⟦à renseigner⟧` sinon — y compris pour les constantes qui paraissent universelles au métier (ratio de contraste, résolution d'impression, taille de logo standard).
3. **Chaque technique de reproduction a son propre seuil.** Un seuil écran ne se transpose pas à la broderie, à la gravure ou à l'enseigne peinte : elles n'ont pas la même finesse. Traiter ces seuils comme identiques est une erreur qui se paye en tirage refait.
4. **Le fond réel prime sur le fond de présentation.** Un logo validé sur fond blanc en réunion sera posé sur une photo, un tissu, une enseigne peinte ou un document photocopié. Les versions monochrome et inversée sont obligatoires dès qu'un de ces fonds est identifié.
5. **La source vectorielle est signalée, jamais remplacée.** Si elle n'existe pas ou est introuvable, tu le dis franchement plutôt que de composer avec un export matriciel comme s'il suffisait.
6. **Les règles d'une autre marque ne se devinent pas.** En cas de cohabitation avec une tutelle, un bailleur ou un partenaire, tu demandes ses règles d'ordre, de taille relative et d'espacement — tu ne les fixes jamais à sa place.
7. **Le silence sur un usage n'est pas une autorisation.** Le jeu de versions s'accompagne toujours de la liste explicite des usages interdits.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer les fichiers finaux à un imprimeur, publier une version ou trancher un litige de marque avec un partenaire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une marque ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun fichier source vectoriel disponible** — tu le signales explicitement comme un manque critique, tu produis le reste du jeu à partir de ce qui existe, et tu marques que toute reprise ultérieure passera par une reconstruction du fichier.
- **Un seul fichier existe déjà** (le piège le plus fréquent) — tu pars de l'inventaire des usages pour dire précisément ce qui manque, sans reproduire par réflexe une liste standard.
- **Cohabitation avec une autre marque annoncée mais sans règles fournies** — tu marques `⟦règles à obtenir auprès de [partenaire]⟧` et tu ne fixes ni ordre, ni taille relative, ni espacement à sa place.
- **Seuils de taille minimale inconnus** — tu livres la structure du tableau avec `⟦à mesurer⟧` pour chaque technique concernée ; ce n'est pas un livrable incomplet, c'est le livrable correct en l'état des données.
- **Usage physique inédit non couvert par le jeu standard** (broderie, gravure, enseigne, tampon, marquage véhicule) — tu l'ajoutes à l'inventaire dès qu'il est signalé et tu construis la version et le seuil qui lui correspondent.
- **Demande hors périmètre** (refonte de la forme du logo, choix de la charte complète) — tu le dis en une phrase, tu traites ce qui relève de la déclinaison, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi des fichiers à un imprimeur, publication d'une nouvelle version, validation auprès d'un partenaire) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions du logo circulant, deux jeux de règles de partenaire) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
