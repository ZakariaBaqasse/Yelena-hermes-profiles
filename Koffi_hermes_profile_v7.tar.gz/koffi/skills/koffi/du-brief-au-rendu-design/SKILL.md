---
id: Y0679
name: du-brief-au-rendu-design
description: "Le déroulé d'un travail de design tel que l'équipe l'attend : lire la charte reçue et la restituer en une page AVANT de produire, décliner un flyer en trois niveaux (basique, intermédiaire, sophistiqué) aux formats carré et story, éprouver la charte sur des sujets variés, décliner la marque sur des objets, rendre un benchmark stratégique en Google Slides visuel puis en PDF, maquetter les écrans sur Figma, UXPilot ou Stitch et jamais en PDF, tenir des références et comparer le parcours réel d'un concurrent captures à l'appui, créer un logo et une charte de zéro pour une entreprise qui n'existe pas encore, et nommer l'outil utilisé à chaque livrable. Règles posées à la réunion d'entraînement du 21 septembre 2026, à charger dès qu'un brief visuel arrive."
bucket: A
tags: [Design, Processus, Nouveau]
version: 2
maj: 2026-09-23
---

# Du brief au rendu, le déroulé d'un travail de design

## Process
### Étape 1 : la charte lue et restituée
Tu lis la charte reçue (ou le logo et les couleurs) et tu la restitues **en une page, dans un Google Slides** : palette avec codes exacts, typographies de titre et de corps, règles du logo (zone de protection, tailles minimales, fonds autorisés, ce qui est interdit), et deux exemples d'application. Cette page est validée par un choix A/B avant tout autre livrable. Quand la charte est absente, tu le dis et tu proposes de la créer (étape 8) au lieu d'appliquer une palette supposée.

### Étape 2 : le flyer en trois niveaux
Pour un flyer, tu rends **trois niveaux** : **basique** (texte, logo, motif), **intermédiaire** (avec une image), **sophistiqué** (composition, image travaillée, hiérarchie forte). Chaque niveau sort en **carré et en story**, et chaque fichier en **JPEG, PNG et PDF**. La charte est respectée aux trois niveaux ; ce qui change est le degré de travail, jamais les couleurs ni le logo. La personne choisit le niveau qui lui ressemble, et ce choix guide les livrables suivants.

### Étape 3 : éprouver la charte sur des sujets variés
Une charte tient quand elle survit à trois sujets différents (une promotion, un produit, un rappel de sécurité). Tu rends trois flyers rapides, même charte, sujets distincts, en carré (JPEG, PNG et PDF), pour vérifier que la qualité ne dépend pas du premier exemple. Ce qui se casse à cette étape (une couleur illisible sur une photo, un logo trop petit) se corrige dans la restitution de charte, pour que la correction serve à tous les livrables suivants.

### Étape 4 : la marque sur des objets
Quand l'entreprise prépare un événement ou un dotation, tu déclines la marque sur des objets (sac, casquette, t-shirt, sous-verre, badge) et tu montres les maquettes dans un **Google Slides**, une page par objet, avec les contraintes d'impression signalées (compétence `preparation-fichiers-impression` pour les fichiers finaux).

### Étape 5 : le benchmark stratégique en Slides
Un benchmark (positionnement, présence sur les réseaux, campagnes, ton, canaux) face aux concurrents sort en **Google Slides très visuel** : une idée par page, des icônes sobres, des chiffres lisibles, des captures réelles des concurrents, **puis le PDF** exporté. Jamais un long PDF de texte. Chaque concurrent cité a été regardé ; une capture a une date. ⛔ Avant d'envoyer, les contrôles 1 et 2 de `production-visuelle-livrable` : chaque affirmation porte sa source sur la page, et les polices se vérifient page par page sur le PDF exporté des Slides, pas sur le fichier local. Un seul en échec : tu ne remets pas.

### Étape 6 : les écrans sur Figma, UXPilot ou Stitch
Un écran d'accueil, un parcours, une page de commande, une landing : tu maquettes sur **Figma, UXPilot ou Stitch**, avec un rendu moderne, et tu rends le **lien** qui s'ouvre sans demande d'accès. **Jamais en PDF** : un écran en PDF ne se clique pas, ne se retouche pas, ne se transmet pas à un développeur. Tu dis lequel des trois outils tu as utilisé. Une planche PNG peut s'ajouter pour l'impression, elle ne remplace pas le lien. Une maquette d'application porte le **parcours complet**, jamais un à trois écrans isolés : le contrôle est dans `ecrans-stitch-vers-page-cliquable`. Un **site** se remet en HTML et en lien publié : le contrôle est dans `sitecraft-ai`.

### Étape 7 : les références et le parcours réel
Tu tiens une liste de références (applications et sites bien faits, dans le secteur et hors secteur) et, quand on te demande de comparer, tu fais les **captures du parcours réel** d'un concurrent (ouverture de compte, commande, inscription), écran par écran, et tu les mets face au parcours de l'entreprise dans un Google Slides, avec ce que tu proposes de garder et ce que tu proposes de changer. Une comparaison sans capture est une opinion.

### Étape 8 : créer de zéro pour une entreprise qui n'existe pas
Quand l'entreprise est en création et n'a ni logo ni charte, tu crées **trois pistes** de logo et de charte dans un Google Slides, sans copier une marque existante, chacune avec sa palette, sa typographie et deux applications (une carte, un écran). La personne choisit une piste, et cette piste devient la charte restituée de l'étape 1.

### Étape 9 : le point d'étape en cinq lignes
« Résume-moi ce que tu as fait » se répond en cinq lignes au plus, une par livrable, avec le lien et l'application utilisée pour chacun.

## Format de sortie
- **Charte restituée** : Google Slides, une page, validée par A/B.
- **Flyer** : trois niveaux, chacun en carré et en story, en JPEG, PNG et PDF.
- **Flyers d'épreuve** : trois sujets, en carré, en JPEG, PNG et PDF.
- **Carrousel** : lien, PDF et un PNG par planche.
- **Objets** : Google Slides, une page par objet.
- **Benchmark** : Google Slides visuel, puis PDF.
- **Écrans** : lien Figma, UXPilot ou Stitch, parcours complet, outil nommé, jamais PDF.
- **Site** : HTML et lien publié.
- **Références et parcours** : Google Slides avec captures datées.
- **Création de zéro** : trois pistes dans un Google Slides.
- **Chaque livrable** nomme l'application utilisée.
- **Règle 0 invention** : aucune capture fabriquée, aucun chiffre de benchmark sans source, aucune couleur reconstituée à l'œil.

## Règles
1. **Lire avant de produire.** La charte se restitue et se valide avant le premier flyer.
2. **Trois niveaux à chaque flyer.** La personne choisit le degré de travail sur pièces.
3. **Un flyer sort en carré et en story**, en JPEG, PNG et PDF, jamais en A4 pour un réseau.
4. **Le stratégique sort en Slides puis en PDF.**
5. **Un écran ne sort jamais en PDF.** Figma, UXPilot ou Stitch, lien partagé, outil nommé.
6. **Une comparaison porte des captures réelles et datées.**
7. **De zéro se fait en trois pistes**, sans copier une marque existante.
8. **L'application utilisée est nommée à chaque livrable.**

**Garde-fous durs**

- **0 invention.** Aucune capture, aucun chiffre, aucune part de marché, aucun code couleur fabriqués. Ce qui manque est marqué `[à confirmer]`.
- **0 fausse source.** Une capture vient d'une page réelle, ouverte, datée. Un concurrent cité a été regardé.
- **Produis, ne bloque pas.** Sans charte, tu proposes d'en créer une ; sans image, tu rends le niveau basique et tu demandes l'image.
- 🔒 **Aucune action sortante en autonomie.** Poster un visuel, publier une page, envoyer un fichier à un imprimeur restent des actions validées.
- **Cloisonnement.** Une charte, une piste de logo, une maquette produites pour une entreprise ne servent jamais une autre.

## Cas limites
- **La personne envoie un logo fait par un proche, sans charte** : tu le prends tel quel, tu restitues ce que tu en déduis (couleurs relevées sur le fichier, marquées à confirmer) et tu proposes de fixer les règles manquantes.
- **La charte reçue est en anglais ou trop longue** : tu la restitues en une page en français, en gardant les codes exacts.
- **La personne demande « juste un flyer »** : tu rends les trois niveaux quand même, en carré et en story ; elle en prend un.
- **L'entreprise n'a pas d'application** mais demande des écrans : tu maquettes ce qui a du sens (une page de commande, une page de prise de rendez-vous) sur Figma, UXPilot ou Stitch, et tu le dis.
- **Aucun des trois outils de maquette n'est disponible** : tu le dis en une ligne, tu rends une planche PNG en signalant que ce n'est pas un prototype, et tu signales à qui brancher l'outil.
- **Le benchmark demande des chiffres non publics** : tu rends ce qui est observable (présence, ton, fréquence, formats) et tu marques `[non public]` le reste.
- **La personne veut copier un concurrent** : tu rends les références et le parcours réel, et tu proposes ce qui s'en inspire sans le reproduire.

## Historique

- v2, 23/09/2026 : flyer en JPEG, PNG et PDF (au lieu de PNG seul), carrousel en lien, PDF et PNG, parcours d'écrans complet, site en HTML et lien publié, contrôle des sources et des polices avant l'envoi d'un benchmark, séance Sync agents training.
