---
id: Y0047
name: 09-7-images-persona
description: "Visuel persona pour deck + métadonnées."
bucket: A
tags: [Design]
version: 1
maj: 2026-08-10
---

# Générateur Complet de Persona Service Blueprint

## Ce qu'il faut avoir sous la main
1. **Produit/Service** *(description précise du service/produit)* ;
2. **Pays/Secteur** *(zone géographique et secteur d'activité)* ;
3. **Personas existants** *(liste des personas déjà identifiés avec leurs rôles)*.

## Process
1. **ANALYSER** les personas fournis et les enrichir (âge, profil, environnement).
2. **IDENTIFIER** les personas manquants dans la chaîne de valeur complète.
3. **CLASSER** tous les personas en Front/Back.
4. **GÉNÉRER ET AFFICHER** automatiquement une image professionnelle pour chaque persona.

### Processus d'amélioration

**Pour personas existants :**
1. Conserver le nom et rôle de base.
2. Enrichir avec âge approximatif et personnalité.
3. Préciser l'environnement de travail.
4. Améliorer la description du rôle.
5. **GÉNÉRER AUTOMATIQUEMENT** l'image correspondante avec le style photographique réaliste.

**Pour personas manquants :**
1. Identifier les gaps dans la chaîne de valeur.
2. Créer des personas complémentaires pertinents.
3. Suivre le même format d'enrichissement.
4. **GÉNÉRER AUTOMATIQUEMENT** les images correspondantes avec le style photographique réaliste.

## Format de sortie
### **PERSONAS FRONT**

## Règles
**FRONT :** Contact direct client OU production d'éléments visibles.
**BACK :** Support/opérations/maintenance sans contact direct client.

### Contraintes

- Traiter TOUS les personas existants fournis en input (les améliorer, ne pas les ignorer).
- Ajouter maximum 5-8 personas manquants selon le contexte.
- **OBLIGATION ABSOLUE :** générer et afficher automatiquement UNE image par persona.
- Descriptions enrichies : 15-25 mots par section.
- Style visuel cohérent : photographique authentique, film grain, éclairage naturel.
- Éviter : peau plastique, cartoon, art digital, symétrie parfaite.
- Respecter l'ordre d'affichage : H2 → Image → Description.
- Ne jamais demander confirmation pour générer les images — exécution automatique.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Capacité de génération d'image

**Fonction :** génère une image réaliste et professionnelle adaptée au contexte.

**Paramètres :** `nom_persona`, `role`, `age_approx`, `style_vestimentaire`, `environnement_travail`.

### Exécution obligatoire

**DIRECTIVE IMPÉRATIVE :** Pour CHAQUE persona créé ou amélioré, tu DOIS immédiatement :
1. Générer une image à partir des paramètres extraits.
2. Afficher l'image générée directement dans la réponse.
3. Ne jamais attendre de demande pour générer les images.

**Paramètres obligatoires pour chaque image :**
- `nom_persona` : [Nom exact du persona]
- `role` : [Rôle professionnel précis]
- `age_approx` : [Âge numérique - ex : 28, 35, 45]
- `style_vestimentaire` : [Tenue professionnelle adaptée au contexte]
- `environnement_travail` : [Environnement spécifique au rôle]

### [Nom du Persona]

[GÉNÉRER IMMÉDIATEMENT L'IMAGE DU PERSONA ET L'AFFICHER ICI]

- **Rôle :** [Description enrichie du rôle - 1-2 phrases]
- **Profil :** [Âge, personnalité, style vestimentaire]
- **Environnement :** [Lieu de travail, contexte professionnel]

### [Nom du Persona]

[GÉNÉRER IMMÉDIATEMENT L'IMAGE DU PERSONA ET L'AFFICHER ICI]

- **Rôle :** [Description enrichie du rôle - 1-2 phrases]
- **Profil :** [Âge, personnalité, style vestimentaire]
- **Environnement :** [Lieu de travail, contexte professionnel]

### **PERSONAS BACK**

### [Nom du Persona]

[GÉNÉRER IMMÉDIATEMENT L'IMAGE DU PERSONA ET L'AFFICHER ICI]

- **Rôle :** [Description enrichie du rôle - 1-2 phrases]
- **Profil :** [Âge, personnalité, style vestimentaire]
- **Environnement :** [Lieu de travail, contexte professionnel]

### [Nom du Persona]

[GÉNÉRER IMMÉDIATEMENT L'IMAGE DU PERSONA ET L'AFFICHER ICI]

- **Rôle :** [Description enrichie du rôle - 1-2 phrases]
- **Profil :** [Âge, personnalité, style vestimentaire]
- **Environnement :** [Lieu de travail, contexte professionnel]

### Style de génération d'image — obligatoire

**EXÉCUTION AUTOMATIQUE OBLIGATOIRE :** dès qu'un persona est défini, génère immédiatement l'image avec ces paramètres visuels obligatoires :

- **Style photographique :** photorealistic, candid 35mm photograph. Cinematic, sharp focus, f/2.8, soft natural light, detailed textures, Kodak Portra 400 film grain, 8k resolution, award-winning photography. --no plastic skin, cartoon, digital art, perfect symmetry.
- **Contexte :** professionnel, adapté au rôle et à la zone géographique fournie.
- **Qualité :** haute résolution, présentation professionnelle.
- **Affichage :** image directement intégrée dans la réponse sans attendre.

### Structure d'affichage

**FORMAT D'AFFICHAGE OBLIGATOIRE :**
1. Nom du persona en titre H2 (`## Nom du Persona`).
2. Image générée automatiquement juste en dessous.
3. Description structurée : Rôle, Profil, Environnement.
4. Séparateur (`---`) entre chaque persona.
