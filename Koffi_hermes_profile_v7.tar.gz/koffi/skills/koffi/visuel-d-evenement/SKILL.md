---
id: Y0472
name: visuel-d-evenement
description: "Produit le visuel d'un événement au format exact attendu par la plateforme qui l'héberge, avec les logos des partenaires alignés proprement et l'information essentielle lisible jusqu'à la taille de vignette : le format cible se fixe avant le dessin, les logos viennent des fichiers officiels, et toutes les déclinaisons sortent d'une source unique, jamais fabriquées format par format."
bucket: B
tags: [Design, Événementiel, Nouveau]
version: 1
maj: 2026-09-07
---

# Le visuel d'événement au format exact de la plateforme qui l'accueille

## Ce qu'il faut avoir sous la main
- **Les formats et canaux visés** : affiche imprimée, statut WhatsApp, publication Facebook ou Instagram, bannière LinkedIn, écran d'accueil de plateforme d'inscription. Précise si un format est imposé par un tiers (organisateur de salon, plateforme de billetterie).
- **Le contenu obligatoire** : titre de l'événement, date complète (jour, date, heure, fuseau si le public dépasse la Côte d'Ivoire), lieu, organisateur, éventuel appel à l'action (inscription, lien, numéro).
- **Les logos partenaires** : les fichiers officiels si tu les as, ou le nom exact de chaque partenaire et la personne à qui les demander si tu ne les as pas encore.
- **La charte graphique existante**, si elle existe : couleurs, police, ton visuel des visuels précédents.
- **Les autorisations d'usage déjà obtenues** pour chaque logo partenaire, ou l'état de la demande.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en listant explicitement les logos ou autorisations manquants. Un intake complet est l'idéal, pas une condition de démarrage. Ce qui bloque la publication n'est jamais la production : c'est l'absence de fichier officiel ou d'autorisation, et ça se signale, ça ne s'invente pas.

## Process
### Étape 1 : Fixer le format cible et sa zone de sécurité avant tout dessin

Liste chaque plateforme visée et sa dimension exacte, son ratio, et sa zone de sécurité (la zone que la plateforme ne recadre jamais, où le titre et la date doivent impérativement tenir). Si la dimension exacte n'est pas connue, elle est `⟦à renseigner⟧`, tu ne la devines pas à partir d'un souvenir de plateforme.

Le piège classique : dessiner un visuel unique « qui a l'air bien », puis l'adapter format par format. Chaque plateforme recadre selon son propre rapport, et le recadrage tombe presque toujours sur le titre ou sur la date, parce que ce sont les éléments posés en haut ou en bord de composition. La zone de sécurité se pose avant le premier élément graphique, pas après.

### Étape 2 : Sourcer les logos depuis leurs fichiers officiels et vérifier l'autorisation d'usage

Pour chaque logo partenaire, exige le fichier officiel fourni par le partenaire lui-même (vectoriel si possible, ou au minimum une version haute définition à fond transparent). Un logo trouvé par recherche d'images est refusé systématiquement : basse définition, fond blanc mal incrusté, version périmée, ou parfois le logo d'une entreprise homonyme. Aucun de ces cas ne se rattrape en retouche, il se rattrape en redemandant le bon fichier.

Vérifie aussi que l'usage du logo est autorisé, et que la charte du partenaire ne l'interdit pas dans certaines déclinaisons (couleur modifiée, proportions changées, fond non prévu). Un logo posé sans autorisation, même bien intégré graphiquement, est un problème qui n'a rien à voir avec le design.

### Étape 3 : Construire la hiérarchie d'information, séparée du texte de publication

Détermine ce qui doit être lu en premier (titre), en second (date complète : jour de la semaine, date, heure, fuseau si le public dépasse le pays), puis lieu, organisateur, appel à l'action. La date incomplète est une source récurrente de questions, surtout quand l'événement est relayé au-delà de la Côte d'Ivoire par des partenaires ou une diaspora : une heure sans fuseau se lit différemment selon qui la lit.

Ce qui est écrit dans le visuel doit aussi exister dans le texte qui accompagne la publication (post, message WhatsApp, description). Un texte uniquement incrusté dans l'image est illisible pour une partie des lecteurs (malvoyance, lecteur d'écran, connexion qui bloque le chargement de l'image) et invisible pour la recherche. Le visuel porte l'essentiel visuellement, le texte de publication le répète intégralement.

### Étape 4 : Aligner les logos sur leur masse visuelle, pas sur leur boîte

Un logo large et bas et un logo carré, alignés sur la même hauteur de cadre, ne paraissent jamais de la même taille à l'œil : le logo carré semble plus imposant. L'alignement correct se fait sur la masse visuelle perçue, pas sur les dimensions du fichier. Le contrôle se fait à l'œil, sur le rendu final, pas en comparant des valeurs de hauteur ou de largeur dans l'outil de conception.

Si plusieurs partenaires sont présents, vérifie que l'ordre respecte les usages convenus avec l'organisateur (souvent : organisateur en premier, puis ordre d'engagement ou ordre alphabétique) : un ordre de logos mal traité est un motif fréquent de tension entre partenaires.

### Étape 5 : Décliner depuis une source unique, pas format par format

Construis toutes les déclinaisons à partir d'un seul fichier source où texte, logos et fond sont modifiables indépendamment. Une correction (une faute dans le titre, une date qui change) se reporte alors sur tous les formats en une seule modification. Des déclinaisons faites une par une, à la main, dérivent inévitablement : une correction n'est reportée que sur une partie des formats, et l'écart ne se voit souvent qu'une fois publié, quand il est trop tard.

### Étape 6 : Contrôler la lisibilité à la taille réelle d'affichage

Le visuel sera vu en vignette dans un fil, sur un téléphone d'entrée de gamme, avec une image parfois compressée par la plateforme ou par WhatsApp. Le contrôle de lisibilité se fait à cette taille réduite, jamais à cent pour cent sur un grand écran de conception. Si le titre ou la date deviennent illisibles une fois réduits, ce n'est pas un détail de finition, c'est un défaut du livrable qui se corrige avant diffusion.

### Étape 7 : Produire la fiche technique et arrêter la liste des manques

Documente pour chaque format : dimensions exactes, zone de sécurité, polices et tailles utilisées, codes couleur, et la provenance de chaque logo (fichier reçu de qui, à quelle date). Dresse la liste des logos dont le fichier officiel ou l'autorisation d'usage manque encore. Cette liste est la condition de publication : tant qu'elle n'est pas vide, le visuel ne se publie pas, même si tout le reste est prêt. Tu le dis explicitement à chaque livraison où la liste n'est pas vide.

## Format de sortie
- **Livrable** : le visuel au format demandé, plus ses déclinaisons pour chaque canal cité, générées depuis la même source. La fiche technique (dimensions par format, zone de sécurité, polices et tailles, codes couleur, provenance de chaque logo). La planche de contrôle montrant le rendu en vignette, à la taille réelle d'affichage sur chaque canal. La liste des logos ou autorisations manquants.
- **Structure** : Markdown pour la fiche technique et la liste des manques ; le ou les fichiers visuels sont livrés séparément (aperçu décrit en Markdown si le format d'échange ne permet pas de joindre l'image directement).
- **Longueur** : proportionnée au nombre de formats demandés. Une fiche technique reste concise : un tableau par information, pas de prose.
- **Toute dimension, taille de police ou code couleur non fournie et non déjà présente dans une charte transmise est `⟦à renseigner⟧`**, jamais devinée par cohérence esthétique supposée.
- **Règle 0 invention** : aucun logo, aucune couleur de charte partenaire, aucune dimension de plateforme inventée. Une donnée manquante est demandée ou marquée `[à confirmer]`.

## Règles
1. **Le format se fixe avant le dessin.** Aucun élément graphique n'est posé tant que la dimension exacte et la zone de sécurité du format cible n'ont pas été établies ou marquées `⟦à renseigner⟧`.
2. **Un logo vient de son fichier officiel, jamais d'une recherche d'images.** Basse définition, fond mal détouré, version périmée, entreprise homonyme : aucun de ces cas ne se corrige en retouche, il se corrige en redemandant le bon fichier au partenaire.
3. **L'alignement des logos se juge à l'œil sur la masse visuelle**, jamais sur les valeurs de largeur ou de hauteur du cadre. Un logo large et bas et un logo carré alignés sur la même boîte ne sont presque jamais visuellement équilibrés.
4. **La lisibilité se contrôle à la taille réelle d'affichage**, réduite, sur l'appareil et la plateforme visés, jamais à cent pour cent sur un grand écran de conception.
5. **La date est toujours complète** : jour de la semaine, date, heure, fuseau dès que le public dépasse le pays d'origine de l'événement.
6. **Aucun logo partenaire sans autorisation d'usage constatée**, et aucune déclinaison qui contredit la charte du partenaire (couleur modifiée, proportions changées, fond non prévu) sans validation explicite de ce partenaire.
7. **Toutes les déclinaisons sortent d'une source unique.** Une correction se reporte sur tous les formats en une seule modification ; des déclinaisons faites indépendamment les unes des autres dérivent et ne se rattrapent qu'en repartant de la source.
8. **Le texte du visuel se répète intégralement dans le texte de publication.** Rien d'essentiel ne reste uniquement incrusté dans l'image.
9. **Le visuel ne se publie pas tant que la liste des logos ou autorisations manquants n'est pas vide.** Cette liste est rendue à chaque livraison, même partielle.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un logo ou une charte comme « officiel » sans l'avoir reçu du partenaire ou de l'organisateur. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contenu disponible tu livres le visuel et sa fiche technique, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer ; seule la publication reste conditionnée à la liste des manques vidée.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un visuel et sa fiche technique ; publier sur un réseau, envoyer à l'imprimeur, ou diffuser à des partenaires est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un événement (logos, contacts, chartes de partenaires) ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Logo manquant** : tu produis le visuel en réservant l'emplacement visuellement cohérent, tu le marques `[logo à recevoir : nom du partenaire]`, et il figure dans la liste des manques qui bloque la publication.
- **Format non standard demandé par une plateforme peu courante** : tu demandes la dimension exacte plutôt que d'estimer par analogie avec un format voisin ; un format mal deviné se recadre mal.
- **Partenaire refuse ou tarde à autoriser l'usage de son logo** : tu le retires du visuel plutôt que de le laisser en attente indéfinie, et tu le signales à l'organisateur.
- **Charte graphique transmise contredit une demande de l'organisateur** (couleur imposée par un partenaire, différente de celle voulue par l'organisateur) : tu exposes le conflit et demandes l'arbitrage plutôt que de trancher seul.
- **Événement multi-pays avec fuseaux différents** : tu affiches l'heure dans le fuseau du lieu de l'événement et tu le précises explicitement dans le texte de publication, plutôt que de multiplier les heures sur le visuel.
- **Visuel destiné à l'impression et à la diffusion numérique simultanément** : tu produis les deux déclinaisons séparément (résolution et mode colorimétrique différents), et tu signales le délai que demande un passage chez un imprimeur local si le calendrier de l'événement est serré.
- **Texte en plusieurs langues** : tu demandes laquelle domine visuellement et si des versions séparées par langue sont attendues, plutôt que de superposer les langues sur un même visuel au risque de tout rendre illisible.
- **Modification demandée après une diffusion déjà lancée sur certains canaux** : tu prépares la version corrigée et tu t'arrêtes avant toute republication, la republication étant une action sortante qui appartient à l'organisateur.
- **Demande hors périmètre** (rédaction du texte de publication complet, stratégie de diffusion, choix des créneaux de publication) : tu le dis en une phrase, tu traites ce qui relève du visuel, et tu orientes vers la compétence qui convient.
