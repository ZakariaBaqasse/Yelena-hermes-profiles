---
id: Y0168
name: higgsfield-video-generator
description: "Génère des images hyperréalistes et des vidéos brandées avec voix off pour les réseaux sociaux (TikTok, Instagram Reels, LinkedIn, Facebook) d'une marque du portefeuille : script validé → image → vidéo → voix off → assemblage Canva, logo officiel et représentation du marché cible obligatoires."
bucket: C
tags: [Design]
version: 1
maj: 2026-08-10
---

# Video_Image_Generator

## Ce qu'il faut avoir sous la main
1. **Pour quelle marque/startup** souhaites-tu créer du contenu ? (obligatoire)
2. **Workflow souhaité** : un contenu à la fois, ou en batch (Bulk Create pour 3+ designs) ? (obligatoire)
3. **Réseaux ciblés** : ☐ TikTok ☐ Instagram Reels ☐ LinkedIn ☐ Facebook (obligatoire — multi-choix).

### Checklist démarrage

- ☐ Marque identifiée
- ☐ Workflow validé (batch ou un par un)
- ☐ Réseaux ciblés validés
- ☐ Branding récupéré (registre des marques + mémoire de la marque)
- ☐ **Logo officiel URL confirmée** (checkpoint obligatoire)
- ☐ Couleurs HEX + typographies récupérées
- ☐ Templates Canva identifiés et présentés
- ☐ Calendrier éditorial lu (fourni par l'utilisateur ou via `[skill à brancher : 02-contentstrategist]`)
- ☐ Type d'image détecté automatiquement
- ☐ Format réseau confirmé (voir section Formats)
- ☐ CSV préparé dans Google Drive (si batch)


**Ce qu'elle suppose comme accès** : Registre des marques, Dossier d'assets branding, Mémoire de la marque, Document de référence créative, Base de comparables/inspiration, Dossier de travail Bulk Create, Drive de la marque, Génération d'image. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Dès que la marque est identifiée, récupère **immédiatement et en priorité** les assets branding :

1. `[datasource à brancher : registre des marques — pour la marque concernée, contient Brand Memory (couleurs HEX officielles, typo, tagline), Logo Folder, sub-hub de contenu]`.
2. `[datasource à brancher : dossier d'assets branding (Drive ou équivalent) — logo officiel, URL directe ou lien de dossier]` : logo officiel, couleurs HEX, typographies, tagline.

⛔ **CHECKPOINT LOGO OBLIGATOIRE** : avant de passer à l'étape suivante, confirme que tu as bien récupéré l'URL du logo officiel. Si introuvable dans le registre des marques, cherche dans `[connecteur à brancher : Google Drive]`, `[connecteur à brancher : Notion]`, puis sur le site web de la marque via `[connecteur à brancher : recherche web]`. Ne continue JAMAIS sans avoir le logo en main.

Récupère ensuite les informations complémentaires : `[datasource à brancher : mémoire de la marque — profil, contacts, historique, financement]`, `[datasource à brancher : document de référence créative de la marque — guidelines ton/style visuel]`, et `[connecteur à brancher : Notion]`, `[connecteur à brancher : Google Drive]` ou `[connecteur à brancher : recherche web]` pour tout contexte supplémentaire (produits, CTA, site web, numéro WhatsApp).

### Étape 2 — Calendrier éditorial

Demande à l'utilisateur s'il dispose d'un calendrier éditorial. Si oui, demande-lui de le partager dans le chat ou en fichier — inspire-toi en priorité de ce calendrier pour générer les scénarios. Si l'utilisateur n'en a **pas** : sollicite `[skill à brancher : 02-contentstrategist]` pour générer des scénarios adaptés à la marque, consulte `[datasource à brancher : base de comparables/inspiration (Airtable ou équivalent) — exemples de contenu performant par secteur]` et utilise `[connecteur à brancher : recherche web]` pour identifier les concurrents et leurs stratégies de contenu performantes.

### Étape 3A — Génération one-by-one

Si workflow one-by-one validé à l'onboarding, respecte ce workflow dans l'ordre exact :

1. **Script d'abord — validation obligatoire** : génère le script complet et présente-le à l'utilisateur. Le script inclut : dialogue ou voiceover exact, description de la scène et de l'environnement, CTA final avec les coordonnées réelles de la marque (site web ou WhatsApp). Indique systématiquement le **nombre de mots** et la **durée estimée à parole lente** (≈ 2 mots/seconde). Si la durée dépasse 9 secondes (plus de 18 mots), propose automatiquement une **version courte ≤ 20 mots** adaptée à la contrainte vidéo, tout en conservant le script long pour la voix off. **STOP — attends l'approbation explicite (script long + version courte) avant de passer à l'étape suivante.** Ne lance aucune génération sans un « ok » ou « valide » clair.
2. **Image avec logo intégré** : génère une image hyperréaliste via `[connecteur à brancher : génération d'image]`. Avant de lancer la génération, vérifie que tu as bien l'URL du logo récupérée à l'Étape 1. **Workflow logo en deux niveaux :** (1) **Injection directe** : utilise l'URL du logo officiel comme image de référence dans le prompt si le connecteur accepte une référence d'image / un asset de marque — inclure dans le prompt : *"branded content featuring the official [nom de la marque] logo prominently displayed"* avec l'URL logo en référence. (2) **Fallback Canva** : si le connecteur ne supporte pas l'injection directe du logo, inclure une enseigne dans la scène (*"a sign on the wall with the text [NOM MARQUE] in bold letters"*) puis superposer le logo officiel via `[connecteur à brancher : Canva]` (`update_fill` ou asset URL). Personnages fidèles au marché cible de la marque (voir Configuration), contexte authentique et immersif. Inclure systématiquement : *"clean background with negative space at the top and bottom for logo and text overlay"*. Aucun texte superflu sur l'image en dehors du logo. **Utilise les couleurs HEX officielles** de la marque pour orienter la palette visuelle du prompt. **Proportions réalistes obligatoires** : tous les objets (téléphones, terminaux POS, produits, enseignes) doivent respecter leur taille réelle par rapport aux mains et au corps humain. Un terminal POS tient dans une main. Un téléphone fait ~15cm. Ne JAMAIS générer d'objets disproportionnés.
3. **Vidéo** : ⚠️ **Contrainte technique du connecteur vidéo branché** — vérifie sa durée maximale par clip avant de lancer (ce workflow est calibré sur un plafond typique de **9 secondes** ; adapte-le si le connecteur branché a un plafond différent). Utiliser exclusivement la **version courte du script (≤ 20 mots)** validée à l'étape 1. Ne jamais lancer la vidéo avec un script trop long. Anime **l'image déjà générée** via `[connecteur à brancher : génération vidéo]` — ne regénère pas une nouvelle image. Format : 9:16. Le prompt décrit le personnage comme *"murmuring / lips barely moving, speaking slowly and clearly"* suivi de la phrase exacte du script court. **Workflow multi-clips (recommandé pour vidéos 15-30s)** : pour du contenu RS complet, générer 2-3 clips séparés (chacun au plafond du connecteur) : clip 1 = accroche/hook, clip 2 = démo produit ou bénéfice client, clip 3 = CTA + logo. Assembler en post-prod (outil de montage vidéo au choix de l'utilisateur) pour obtenir une vidéo 15-30s avec transitions.
4. **Voix off** : génère la voix off du **script complet** (sans limite de durée) via `[connecteur à brancher : synthèse vocale / voix off]`, en français clair et naturel. ⚠️ **Distinction voix off / vidéo :** la voix off couvre le script long intégral ; la vidéo couvre uniquement la version courte (limite du connecteur, voir ci-dessus). Précise toujours que la **combinaison finale se fait dans un outil de montage** (au choix de l'utilisateur).
5. **Design Canva** : via `[connecteur à brancher : Canva]`, commence par consulter Canva Magic Studio pour récupérer les branding guidelines officiels via `get_brand_guidelines`. Recherche ensuite le template de marque (`list_brand_templates`). Si un template existe, utilise-le comme base (`create_design_from_brand_template`). Sinon, crée un design vierge. Dans tous les cas : injecte image/vidéo + logo officiel via `update_fill` ou asset overlay + textes du script + CTA visible. Respecte les formats exacts (voir section Formats). ⚠️ **Ne jamais partager les liens canva.com directement.** **Workflow d'affichage obligatoire :** (1) `start_editing_transaction`, (2) `get_design_thumbnail` pour récupérer un fichier téléchargeable, (3) `cancel_editing_transaction` immédiatement après. Présenter les designs sous forme de fichiers numérotés.

### Étape 3B — Bulk Create (3+ designs)

Si workflow batch validé à l'onboarding, appliquer ce processus :

⚠️ **Validation avant batch (obligatoire) :** Générer un **« Slide 0 » de référence charte** (couleurs hex + typographie + zone logo) — l'utilisateur doit valider ce slide avant tout lancement. Puis générer **2-3 visuels test** → présenter → valider le style → lancer le batch complet. ❌ Ne jamais démarrer un batch sans validation du Slide 0 et du style.

1. **Préparer le template Canva :** Ouvrir le template, clic droit sur chaque zone variable → « Connecter les données », nommer : `titre`, `sous_titre`, `contenu_1`, `tagline`, `cta`, sauvegarder.
2. **Préparer le CSV :** créer le fichier source via `[connecteur à brancher : Google Sheets]` dans `[datasource à brancher : dossier de travail Bulk Create (Drive ou équivalent) — où créer les CSV sources par marque]`. Partager le lien pour téléchargement en `.csv`. ❌ Ne jamais afficher le CSV brut dans le chat.
3. **Lancer :** dans Canva, Apps → Bulk Create → Upload CSV → vérifier mapping → Générer → déplacer tous les designs dans le dossier client.

### Étape 4 — Organisation des fichiers

Après chaque création, organise les fichiers dans `[datasource à brancher : Drive de la marque — arborescence "vidéos générées par IA / [Nom de la marque] / images" ou "/ vidéos"]`. Si le dossier de la marque n'existe pas encore, crée-le. Maintiens cette arborescence pour toutes les marques du portefeuille.

## Format de sortie
- **Livrable** : Génère des images hyperréalistes et des vidéos brandées avec voix off pour les réseaux sociaux (TikTok, Instagram Reels, LinkedIn, Facebook) d'une mar.
- **Structure** : Markdown clair — titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] » — jamais présentée comme réelle.

## Règles
- Les personnages sont **fidèles au marché cible de la marque** (voir Configuration). JAMAIS de style « stock photo générique » déconnecté du marché réel.
- Le français doit être **simple, limpide et accessible** au grand public (secteur informel, quand pertinent pour le marché cible).
- 🚫 **IMPÉRATIF NON NÉGOCIABLE — Logo officiel obligatoire** : chaque image et chaque vidéo DOIT afficher le logo officiel de la marque. Ne jamais livrer un visuel sans logo. Si le logo officiel n'a pas été récupéré, **STOPPE et récupère-le avant de continuer**. Aucune exception. Workflow obligatoire : enseigne dans le prompt de génération d'image + overlay logo officiel dans Canva via `update_fill` ou asset URL.
- Chaque vidéo doit se terminer par un **CTA visible** : site web ou contact WhatsApp de la marque.
- Toujours mettre en avant la proposition de valeur principale de la marque.

### Règles obligatoires — Génération & coûts

- Utilise **exclusivement** les presets/modèles validés du connecteur branché pour les images et pour les vidéos — ne bascule pas d'un modèle à un autre sans raison.
- **N'utilise JAMAIS** un mode de génération premium/coûteux (ex. un « Marketing Studio » ou équivalent) sans autorisation explicite de l'utilisateur.
- Si une génération semble coûteuse en tokens/crédits, **stoppe et demande confirmation** avant de lancer.
- Privilégie toujours l'option de génération la moins coûteuse.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Détection du type d'image — automatique, sans question

Ne pas demander le type d'image. Détecter selon le post :

- **Post éducatif / data** → illustration + icônes (pas de photo)
- **Post coulisses / équipe** → photos réelles uniquement (si dispo dans le dossier d'assets de la marque)
- **Post témoignage** → logo ou photo du client cité
- **Post produit / feature** → illustration tech ou screenshot
- **Post produit sur un marché où les prix locaux sont pertinents** → générer systématiquement une variante avec overlay du prix en devise locale
- **Cover carrousel** → stock photo avec une représentation fidèle au marché cible de la marque (voir Configuration), contexte pro, souriant

Si une librairie photos existe dans le dossier d'assets de la marque → l'utiliser en priorité. Sinon → stock photos par défaut du marché cible (mots-clés par défaut : voir Configuration).

### Formats par réseau social

- **TikTok — Vidéo verticale :** 1080×1920px (9:16)
- **Instagram — Reels / Story :** 1080×1920px (9:16)
- **Instagram — Carré :** 1080×1080px (1:1)
- **LinkedIn — Post carré / Carrousel :** 1080×1080px
- **LinkedIn — Portrait :** 1200×1500px
- **LinkedIn — Bannière lien :** 1200×627px
- **Facebook — Post lien :** 1200×630px

### Checklist QA pré-livraison (obligatoire avant tout envoi)

- ☐ Proportions objets réalistes (téléphone, POS, produits à l'échelle)
- ☐ Personnages fidèles au marché cible de la marque (pas générique)
- ☐ Logo officiel affiché
- ☐ Couleurs conformes au brand kit
- ☐ Sous-titres dynamiques si vidéo avec voix off (85% des vidéos RS vues sans son)
- ☐ End card avec CTA (logo + tagline + lien/QR + couleurs brand)
- ☐ Format correct pour le réseau cible (voir section Formats)

### Configuration (déployée pour l'entreprise)

> **Première instance — l'entreprise et son portefeuille.** Marques suivies : le programme.
>
> **Marché cible par défaut = Côte d'Ivoire / Abidjan.** Représentation obligatoire sur toute image ou vidéo avec personnages : apparence ouest-africaine / ivoirienne — peau foncée à medium-foncée, coiffures naturelles africaines (tresses, locs, TWA, dégradé). Décors : Abidjan urbain (Plateau, Cocody, Marcory, marchés), boutiques locales avec produits reconnaissables, environnements ivoiriens authentiques. JAMAIS de style « stock photo africain générique ». Dans tous les prompts de génération image/vidéo, inclure : *"Ivorian man/woman"* ou *"West African"* (jamais juste *"African"*), contexte géographique précis (*"in Abidjan"*, *"in an Ivorian market"*), vêtements réalistes locaux. Mots-clés stock photo par défaut : Fintech → *"African fintech Ivory Coast"*, *"Abidjan mobile payment"* — Immobilier → *"Ivory Coast real estate"* — B2B → *"Abidjan entrepreneur"*, *"West Africa business meeting"*.
>
> Pour un autre déploiement (autre client Yelema, autre marché), remplace la liste de marques et les défauts marché / mots-clés stock photo par ceux du client — le reste du workflow (branding, script, génération image/vidéo, voix off, assemblage Canva, checklists QA) est inchangé.
