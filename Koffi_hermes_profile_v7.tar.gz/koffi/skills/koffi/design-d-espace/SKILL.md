---
id: Y0735
name: design-d-espace
description: "Habille un espace aux couleurs d'une marque : stand de salon, accueil et murs d'un bureau, salle de réunion ou d'événement, signalétique et panneaux. Part des cotes réelles du lieu et du règlement de l'organisateur, propose trois directions, rend les plans à plat de chaque surface, une mise en situation en perspective et la nomenclature des supports, puis les fichiers de fabrication. Contrôle avant remise obligatoire. Sans jamais inventer une cote, un matériau, un tarif ou une règle d'organisateur."
bucket: B
tags: [Design, Espace, Événement, Nouveau]
version: 1
maj: 2026-09-23
---

# Le design d'espace : brander un stand, un bureau, une salle

Un designer ne s'arrête pas à l'écran et au papier : il peut habiller un stand, l'accueil d'un
bureau, une salle, et poser la signalétique qui va avec. Cas d'usage ouvert le 23/09/2026.

Le plan d'orientation d'un lieu (où est la caisse, où sont les salles) relève de
`signaletique-et-plv` ; les supports d'un événement (kakémono, fond de scène, badges) de
`kit-evenement` ; les fichiers d'impression de `preparation-fichiers-impression`. Cette
compétence fait le reste : l'habillage de l'espace lui-même.

## Ce qu'il faut avoir sous la main
- **Le lieu et ses cotes** : pour un stand, le plan et le cahier des charges de l'organisateur
  (surface, hauteurs, cloisons fournies, règles d'accrochage) ; pour un bureau ou une salle, des
  photos de chaque mur et les mesures prises sur place.
- **L'objectif** : attirer depuis l'allée, accueillir, faire patienter, affirmer une culture
  d'équipe, orienter.
- **La charte** : logo en vectoriel, couleurs, typographies, motifs.
- **Le fabricant ou le poseur**, s'il est déjà choisi, et ses contraintes de fichiers.
- **Le budget**, même approximatif, pour savoir s'il s'agit d'adhésifs, de toiles tendues ou de
  mobilier.

> Tu n'attends pas d'avoir tout. Sans cotes, tu produis la direction et la mise en situation
> en marquant les surfaces `⟦à renseigner⟧`, et le livrable se dit provisoire.

## ⛔ Contrôle avant remise, obligatoire

Avant d'envoyer, tu vérifies que :

1. **chaque surface dessinée correspond à une cote reçue**, ou porte la mention « provisoire,
   cote à confirmer » ;
2. **le nom et la promesse se lisent à la distance réelle** : depuis l'allée pour un stand,
   depuis l'entrée pour un accueil. Tu réduis le plan à l'échelle de cette distance et tu
   regardes ce qui reste lisible ;
3. **le logo vient du fichier vectoriel**, posé en dernier. Un générateur d'image ne touche
   jamais une image qui porte la marque (règle des générateurs de
   `production-visuelle-livrable`) ;
4. **la remise porte les trois pièces** : la mise en situation en perspective, les plans à plat
   de chaque surface, la nomenclature des supports ;
5. **rien n'est inventé** : ni cote, ni matériau présenté comme validé, ni tarif, ni règle de
   l'organisateur ou du bailleur. Ce qui manque est `⟦à renseigner⟧` avec l'interlocuteur
   nommé.

Un point en échec : tu ne remets pas.

## Process
### Étape 1 : le lieu réel
Tu relèves chaque surface disponible, mur par mur ou face par face, avec sa cote, ses
obstacles (prise, porte, fenêtre, pilier, extincteur) et ce qui ne se touche pas. Pour un
stand, le cahier des charges de l'organisateur prime : hauteur autorisée, cloisons fournies,
ce qui peut se fixer et comment.

### Étape 2 : le parcours et les distances
Tu écris ce que la personne voit dans l'ordre où elle le voit. Pour un stand : de loin dans
l'allée (le nom et une promesse, rien d'autre), à trois pas (l'offre), au comptoir (le contact,
le code à scanner). Pour un bureau : l'entrée, l'accueil, la circulation, les salles. Chaque
distance a son niveau de texte, et le bas des surfaces est souvent masqué par le mobilier et
les visiteurs.

### Étape 3 : trois directions
Trois partis pris nommés chacun en une phrase, pas trois variantes de couleur. Au moins une
direction travaille le volume ou la matière (une surface qui avance, un éclairage, un motif qui
court d'un mur à l'autre), au moins une est une rupture assumée. Le client choisit en A/B/C.

### Étape 4 : les plans à plat
Chaque surface se dessine à l'échelle, sur sa cote, en vue de face : visuel, texte, logo, zone
à laisser libre. Le fond perdu et les marges de sécurité viennent du fabricant.

### Étape 5 : la mise en situation
Une vue en perspective montre l'espace habillé. Elle part d'une photo réelle du lieu quand il y
en a une ; sinon d'une scène vierge, sans personne et sans marque, sur laquelle tu poses
ensuite les visuels et le logo réels. Elle se présente comme une vue d'intention, pas comme un
plan de fabrication.

### Étape 6 : la nomenclature
Un tableau, un support par ligne : surface, cote, support proposé (adhésif, toile, panneau,
lettrage), quantité, fichier correspondant, ce qui reste à confirmer et auprès de qui.

### Étape 7 : les fichiers de fabrication
Après validation seulement, par le protocole de `preparation-fichiers-impression`, contrôlés
sur le rendu et non sur les propriétés du fichier.

## Format de sortie
- **Direction** : Google Slides puis PDF, une direction par page, avec sa mise en situation.
- **Plans à plat** : une page par surface, cotes écrites.
- **Nomenclature** : Google Sheet.
- **Fichiers de fabrication** : après validation, un fichier par surface, nommé
  `<slug>_<surface>_v<N>.pdf`.
- La remise nomme l'outil utilisé et liste ce qui reste à confirmer.

## Règles
1. **La cote reçue prime** : sans elle, aucun fichier de fabrication ne part.
2. **La distance décide du texte.** Ce qui ne se lit pas à la distance réelle n'a rien à faire
   sur la surface.
3. **Le logo se pose en dernier depuis le vectoriel.**
4. **Trois directions, dont une qui ose.**
5. **Rien d'inventé** : cotes, matériaux, prix et règlements viennent de l'organisateur, du
   bailleur ou du fabricant.

**Garde-fous durs**
- 🔒 **Aucune commande, aucun bon à tirer, aucune dépense en autonomie** : tu prépares, la
  personne valide.
- **Cloisonnement** : un plan, une photo de lieu ou une direction produits pour une entreprise
  ne servent jamais une autre.

## Cas limites
- **Aucune cote, aucune photo** : direction et mise en situation seulement, livrable dit
  provisoire, liste des mesures à prendre sur place.
- **Stand clé en main imposé par l'organisateur** : tu travailles dans ses surfaces
  personnalisables et tu le dis.
- **Bureau en location** : ce qui se colle et s'enlève sans trace passe avant ce qui se visse ;
  l'accord du bailleur est à obtenir, tu nommes l'interlocuteur.
- **Façade ou vitrine visible de la rue** : l'autorisation relève de la commune, voir
  `signaletique-et-plv`.
- **Demande d'orientation pure** (panneaux de salles, fléchage) : `signaletique-et-plv`.

## Historique

- v1, 23/09/2026 : création, nouveau cas d'usage du designer (stand, bureau, salle,
  signalétique, panneaux), séance Sync agents training.
