---
id: Y0097
name: client-testimonial
description: "Génère une image de témoignage client (testimonial card LinkedIn/Instagram) brandée pour une startup, en priorisant un vrai verbatim (auto-sourcé dans les canaux existants ou fourni) sur une quote générée — avec garde-fous stricts consentement, authenticité, logo client jamais halluciné."
bucket: C
tags: [Content Creation]
version: 1
maj: 2026-08-10
---

# Client_Testimonial

## Ce qu'il faut avoir sous la main
1. **Startup émettrice** + site web (nom obligatoire, clé du brand kit).
2. **Le client qui témoigne** : logo si tu l'as (sinon nom + site, j'irai le chercher) + nom/rôle/entreprise pour l'attribution.
3. **La quote** : fournie, à générer, ou laisse-moi **aller pêcher un vrai témoignage** dans les canaux existants — c'est mon mode préféré (zéro fabrication).
4. **Combien de témoignages ?** (1, ou 3+ pour un lot en batch).

Optionnel : photo du client, template de référence, dossier de destination, format (LinkedIn carré 1080×1080 par défaut).


**Ce qu'elle suppose comme accès** : Registre central des startups, Community Inbox, WA / suivi NPS, Support FAQ, Content Calendar / Community Inbox, Registre/mémoire des témoignages déjà produits, Recherche web, Apify (ou équivalent scraping). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Startup + site web** — nom (obligatoire, clé brand kit) + site internet (recommandé).
2. **Logo du CLIENT** (entreprise/personne qui témoigne — distinct du logo startup). Si tu ne l'as pas mais connais le **nom + le site du client** → va chercher le logo officiel via `[connecteur à brancher : recherche web — trouver le logo officiel du client (og:image, page presse / media kit, logo haute-déf)]` et **fais-le valider**. Préférer PNG/SVG transparent ; si seulement basse résolution / .webp → demande un fichier propre. Ne jamais halluciner un logo.
3. **La quote** : fournie, à générer, OU **auto-sourcée** depuis nos canaux (voir Étape 3 — à proposer en priorité).
4. **Attribution** : nom + rôle + entreprise du client.
5. **Photo du client** (optionnel).
6. **Template de référence** (optionnel) — propose : lien public ou upload à émuler ; sinon brand kit.
7. **Combien de témoignages ?** — propose le **mode batch** (3+ → Bulk Create). Pour chaque item : logo client + quote/source + attribution.
8. **Dossier de destination** — demande le lien (sous-dossier `Testimonials/`) ; sinon propose d'en créer un. Jamais à la racine.
9. **Format** : LinkedIn 1080×1080 (défaut) · portrait 1200×1500 · story 1080×1920.

### Étape 2 — Branding startup (checkpoint obligatoire)

Résous le brand kit via le Registry (Brand Memory) : HEX officiels, typo, logo startup, tagline. Sans HEX + logo startup → demande. **Jamais de couleur inventée.**

### Étape 3 — Origine de la quote (3 modes — proposer A en priorité)

**Mode A — Verbatim réel auto-sourcé (préféré : vraie voix client, zéro fabrication)** Propose d'aller pêcher de vrais témoignages déjà existants :

- **Sources internes** : `[datasource à brancher : Community Inbox — commentaires/DM positifs loggés par la réponse d'engagement]`, retours **NPS** (`[datasource à brancher : WA / suivi NPS de la startup]`), `[datasource à brancher : Support FAQ de la startup]` — résolues via le Registry.
- **Sources externes** : `[connecteur à brancher : Apify (ou équivalent scraping) — avis Google, commentaires sous les posts LinkedIn/IG de la startup]` ; `[connecteur à brancher : recherche web]` en repli léger. Présente les **3-5 meilleurs verbatims réels** : texte + auteur + source + date → l'utilisateur choisit. **Conserve la source** (traçabilité). Filtre : pertinent, élogieux mais crédible, exploitable.

**Mode B — Quote fournie** : utilisée telle quelle.

**Mode C — Quote générée** (si rien de réel dispo) : 1 message, voix client 1re personne, **≤ 30 mots**, bénéfice concret, crédible. **JAMAIS de chiffre, fait, nom ou résultat non fourni.** 3 options → validation. Signaler clairement à l'utilisateur que la quote est *générée* (à valider/faire confirmer par le client).

### Étape 5 — Composition de la carte témoignage

Layout standard : guillemets / icône quote · **la quote** en gros (lisible < 3 s) · **attribution** (photo si dispo + nom + rôle + entreprise) · **logo CLIENT** en overlay, mis en avant (il témoigne) · **accents = brand kit STARTUP** (HEX, typo) + logo startup en signature discrète (émetteur). 2 logos hiérarchisés. Photos/scènes générées : personnages ouest-africains/ivoiriens réalistes, proportions réalistes. **Variantes** : propose **2-3 variantes de layout** (quote-forward / photo-forward / chiffre-forward) → l'utilisateur choisit. Une quote validée peut être **déclinée en plusieurs formats** (LinkedIn carré + Story + portrait).

### Étape 6 — Auto-révision (avant délégation)

☐ Quote ≤ 30 mots et validée ☐ Sens non altéré (si verbatim réel) ☐ Source tracée (si réel) ☐ Consentement vérifié/flaggé ☐ Aucun chiffre/fait/nom inventé ☐ Attribution complète ☐ Logo client présent (overlay) ☐ Logo startup + HEX officiels ☐ Lisible < 3 s ☐ Template respecté si fourni. En batch : vérifier chaque item.

### Étape 7 — Délégation à la génération visuelle

Délègue la création du visuel via `[connecteur à brancher : mécanisme d'invocation d'une skill Yelema par une autre — délégation vers la skill de génération visuelle de marque (Canva), selon l'implémentation retenue côté plateforme]`. Brief : **⚠️ sans template fourni** : avant de générer, informe l'utilisateur qu'un design généré automatiquement (Canva AI ou équivalent) produit un layout générique (style "SaaS américain", non calibré pour un positionnement premium ou un marché africain). Propose : (A) attendre un template maison comme base de départ, ou (B) procéder en connaissance de cause. **Ne jamais livrer silencieusement un résultat de qualité insuffisante sans avoir obtenu ce choix.**

```
BRIEF TESTIMONIAL — skill Génération Visuelle de Marque
Startup (émetteur) : [nom] | brand_kit_id : [id] | site : [url]
Format(s) : [1080x1080 / 1200x1500 / 1080x1920]  | Variantes : 2-3 layouts
Quantité : [1 ou N -> Bulk Create]  | Dossier destination : [lien] (Testimonials/)
Template fourni : [lien/upload ou "aucun -> brand kit"]

PAR TÉMOIGNAGE :
QUOTE (validée) : "[texte exact]"   | Source : [interne/externe/générée]  | Consentement : [statut]
ATTRIBUTION : [Nom], [Rôle], [Entreprise]
LOGO CLIENT (overlay OBLIGATOIRE) : [URL/asset]  ← jamais IA, mis en avant
PHOTO CLIENT (si dispo) : [URL]
BRANDING : HEX startup via Brand Kit, logo startup en signature discrète
LAYOUT : guillemets + quote en gros + attribution + logo client mis en avant + accents brand startup

Workflow attendu de la skill de génération visuelle (Canva) :
PATH A — template/brand template dispo : create_design_from_brand_template -> start_editing_transaction -> replace_text -> commit_editing_transaction -> export_design
PATH B — sinon : generate_design(design_type:"instagram_post", brand_kit_id:[id], length:"short", query:[desc layout]) -> create_design_from_candidate -> resize_design OBLIGATOIRE au format demandé (⚠️ instagram_post natif = 1080×1350 — toujours resizer si format demandé ≠ 1080×1350, ex: LinkedIn 1080×1080)
BATCH (3+) : CSV (quote, nom, role, entreprise, logo_client_url par ligne) -> Bulk Create.
⚠️ Un POST = instagram_post (1 page). NE PAS utiliser presentation.
⚠️ LOGO CLIENT INACCESSIBLE (URL privée, Drive non public, lien expiré) → STOP IMMÉDIAT : ne pas lancer la génération. Retourner le message : "Logo client non accessible — fournir une URL publique directe ou uploader le fichier."
Logos via overlay. Ranger dans le dossier. Retourner liens éditables + images exportées.
```

### Étape 8 — Échec de la génération visuelle

Si la skill de génération visuelle (Canva) est indisponible → concept en Markdown (quote + attribution + layout + emplacement 2 logos), prêt à recréer. Pas plus d'1 retry.

### Étape 9 — Caption (optionnelle)

Caption LinkedIn courte : accroche (≤ 140 car.) + 2-3 lignes contexte + 1 CTA doux + 3-5 hashtags PascalCase. Aucun lien dans le corps.

### Étape 10 — Mémoire

Enregistre dans `[datasource à brancher : registre/mémoire des témoignages déjà produits]` : [startup] | [client] | [quote courte] | [source] | [consentement] | [date] | [format]. Une entrée par témoignage. Sert aussi à éviter de réutiliser deux fois le même verbatim/client.

### Étape 11 — Livraison

1. Lien(s) éditable(s) + image(s) exportée(s), rangés dans `Testimonials/`.
2. Quote(s) validée(s) + attribution(s) + **source**.
3. **Flags par visuel** : « Logo client à vérifier : [O/N] » + « Consentement : [statut] » (⛔ si à publier sans consentement).
4. **Tableau récap** (toujours) : | # | Client | Quote (courte) | Source | Consentement | Format | Lien | + 📁 dossier de destination.
5. Handoff `[connecteur à brancher : mécanisme d'invocation d'une skill Yelema par une autre — délégation vers la skill de QA pre-publish / contrôle de marque]` pour vérifier lisibilité de la quote, netteté du logo, exactitude de l'attribution.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- Un témoignage cite une **vraie personne** (nom + logo). Avant production, confirme le **statut de consentement** : ☑ Obtenu / ⏳ À demander / ❌ Non. Si ce n'est pas « Obtenu » → le visuel peut être drafté mais **flaggé «** ⛔ **EN ATTENTE CONSENTEMENT — NE PAS PUBLIER »**.
- **Authenticité** : tu peux **condenser / nettoyer** une vraie quote (≤ 30 mots) mais **JAMAIS en changer le sens** ni ajouter un élément non dit. Montre toujours **« original → version carte »** pour validation.
- Trace dans `[datasource à brancher : Content Calendar / Community Inbox de la startup]` : verbatim original, source, statut consentement.

### Contraintes absolues

- **Privilégier un verbatim RÉEL** (auto-sourcé) à une quote générée.
- **Consentement** : jamais publier le témoignage d'une vraie personne sans statut consentement OK ; sinon flag ⛔.
- **Authenticité** : ne jamais altérer le sens d'une vraie quote ni inventer quote/chiffre/nom/rôle.
- **Logo client = obligatoire** (fourni ou récupéré depuis le site + validé) ; jamais halluciné, jamais généré par IA — overlay uniquement. **Si logo inaccessible (URL Drive privée, lien non public, résolution insuffisante) → STOP : bloquer la génération et demander immédiatement une URL directe accessible publiquement ou un upload. Ne jamais livrer un visuel sans le logo client intégré, même partiellement.**
- **2 logos** : client (témoin, mis en avant) + startup (émetteur, signature).
- NEVER couleur inventée — HEX du Registry. Toujours ranger dans le dossier. Utiliser le nom de marque officiel exact de l'émetteur (ex. « l'entreprise », jamais un nom étendu ou approximatif).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### 🗂️ Résolution des ressources — Registry

Pour résoudre les ressources d'une startup, interroge `[datasource à brancher : registre central des startups — base qui répertorie, pour chaque startup, les liens vers sa Brand Memory, son dossier logos, sa Community Inbox, ses retours NPS, sa Support FAQ, son Content Calendar, son sous-espace de travail]` :

1. Filtre sur le nom de la startup parmi celles du portefeuille du fonds.
2. Extrait : **Brand Memory** (HEX, typo, tagline) · **dossier logos startup** · **Community Inbox** · **retours NPS** · **Support FAQ** · **KPI Snapshot** · **Content Calendar** · **sous-espace dédié**.
