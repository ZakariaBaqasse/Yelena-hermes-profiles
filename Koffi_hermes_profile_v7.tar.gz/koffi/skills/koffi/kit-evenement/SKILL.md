---
id: Y0683
name: kit-evenement
description: "Produit le kit visuel complet d'un événement d'entreprise : invitation numérique et imprimable, kakemono, fond de scène, badges nominatifs, programme, signalétique et visuel de remerciement, dans l'ordre où chaque pièce part réellement, sans jamais inventer une information de l'événement qui manque à la fiche."
bucket: B
tags: [Design, Événementiel, Nouveau]
version: 1
maj: 2026-09-21
---

# Le kit visuel d'un événement, de l'invitation au badge

## Ce qu'il faut avoir sous la main
- **La fiche de l'événement** : nom, date, heure, lieu (adresse complète), public visé, format (petit-déjeuner, conférence, lancement, cocktail…).
- **Le message principal** : ce que l'invité doit comprendre en une phrase.
- **Les partenaires ou intervenants à faire apparaître**, avec leurs logos si tu les as, et l'ordre dans lequel ils doivent apparaître.
- **La charte graphique** de l'entreprise (logo, couleurs, typographies) ou un lien vers elle.
- **Le canal d'envoi de l'invitation** (WhatsApp, e-mail, les deux) et si une version imprimée est aussi nécessaire.
- **Les pièces du kit dont tu as réellement besoin** : si tu ne précises rien, je pars sur le kit complet (invitation, kakemono, fond de scène, badges, programme, signalétique légère, visuel de remerciement).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en marquant ce qui manque `à confirmer` : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Fixer le ton avec l'invitation

L'invitation est la première pièce produite, dans les deux versions dont l'événement a besoin : la version numérique aux dimensions du canal d'envoi (une image WhatsApp se lit différemment d'un e-mail HTML), et si demandé, la version imprimable en A5 ou A6.

Ce qui trahit un problème à ce stade : une invitation où le message principal (fourni par la fiche) n'apparaît pas dans les trois premières secondes de lecture, ou une invitation qui liste tout ce que l'événement contient. Une bonne invitation donne une seule raison d'y aller. Sur WhatsApp en particulier, l'image s'ouvre en miniature avant d'être agrandie : le nom de l'événement et la date doivent être lisibles dès la miniature. Le plein écran ne doit pas être nécessaire pour les lire.

Une fois l'invitation validée par l'organisateur, sa palette, sa typographie et son ton deviennent le fil conducteur de toutes les pièces suivantes. Si l'invitation change après coup, tout le reste du kit est repris : ne jamais produire le kakemono sur une version de l'invitation qui n'est plus celle envoyée.

### Étape 2 : Le kakemono ou roll-up, pensé pour dix mètres

Piège à désamorcer : commencer par le kakemono parce qu'il est la pièce la plus impressionnante à concevoir, alors qu'il est la dernière à être vue par le public et n'a aucune urgence de production comparable à l'invitation.

Un roll-up (85 × 200 cm, format standard le plus courant en Côte d'Ivoire ; confirmer le format exact avec l'imprimeur si l'entreprise en a un attitré) se lit à trois distances différentes, et le texte se hiérarchise en conséquence : le titre se lit à dix mètres (gros, court, peu de mots), le sous-titre à trois mètres (une phrase), et tout texte plus fin que ça ne sera lu par personne debout devant. Le tiers inférieur du roll-up est structurellement caché une bonne partie du temps, par le pied du support, par le mobilier ou par le public qui se tient devant : cette zone n'accueille que des éléments secondaires. La date, l'adresse et les logos partenaires dont on veut garantir la visibilité restent ailleurs sur le support.

Fichier livré en PDF avec fond perdu et traits de coupe (voir compétence `preparation-fichiers-impression` pour les cotes exactes, la résolution et le profil couleur).

### Étape 3 : Le fond de scène ou photocall, pensé pour la photo

Piège à désamorcer : un fond de scène conçu comme une affiche, avec le message ou le logo unique centré, à l'endroit exact où les personnes viendront se placer pour la photo. Le résultat : le logo disparaît derrière les têtes sur chaque photo prise, et l'entreprise a payé un fond de scène invisible sur ses propres réseaux.

Le centre du fond de scène reste dégagé. Deux approches courantes : le logo se répète en motif régulier sur toute la surface (pattern), garantissant qu'il apparaît quel que soit l'endroit où la photo est cadrée ; ou il se concentre en bande haute, au-dessus de la hauteur moyenne d'une tête humaine debout. Les cotes du fond de scène dépendent du mur ou de la structure du lieu : elles sont marquées `à confirmer` tant que le lieu ne les a pas données, jamais estimées à l'œil.

### Étape 4 : Les logos partenaires, une règle stricte

Piège à désamorcer, transversal à toutes les pièces qui portent des logos (invitation, kakemono, fond de scène, programme) : des logos de tailles visuellement différentes, ou un ordre que l'organisateur n'a pas validé. Le designer ne détient pas seul la décision sur cet ordre. En Afrique francophone comme ailleurs, l'ordre et la taille relative des logos partenaires sont une question de protocole. Le goût personnel n'y a pas sa place : un partenaire placé plus petit ou plus bas qu'un autre sans raison donnée peut être lu comme un signal, jusqu'à froisser une relation.

Règle appliquée systématiquement : tous les logos partenaires s'alignent sur une **même hauteur d'ancre** (le bloc visuel de chaque logo occupe la même hauteur, indépendamment de sa forme d'origine), dans l'**ordre exact fourni par l'organisateur** dans la fiche événement. Si aucun ordre n'est donné, la question est posée avant production plutôt que tranchée seul.

### Étape 5 : Les badges, lisibles en marchant

Piège à désamorcer : un badge où le nom de l'entreprise ou la fonction prend toute la place et où le prénom, la seule information qui sert vraiment à l'accueil et au réseautage, est écrit petit.

Sur un badge, le **prénom se lit de face à deux mètres** : il occupe la plus grande partie du badge, en gras, en haut. Le nom de famille peut suivre en dessous, un cran plus petit. Le nom de l'entreprise ou de la fonction vient en dernier, plus petit encore : c'est une information secondaire à l'accueil, elle ne domine jamais.

Livrable : une planche PDF prête à découper (plusieurs badges par page, avec traits de coupe) et un gabarit nominatif réutilisable pour que l'organisateur puisse générer la liste complète des invités sans redemander une conception par nom.

### Étape 6 : Le programme et la signalétique légère

Le programme tient sur une page recto ou recto-verso : l'heure, l'intitulé de chaque moment, le nom de l'intervenant s'il y en a un. Ce qui trahit un problème : un programme qui détaille plus que ce que l'invité a besoin de savoir en amont (un déroulé minute par minute pour l'équipe interne n'est pas un document à remettre au public).

La signalétique légère (fléchage, noms de salles, panneau d'accueil) est livrée en un fichier distinct par panneau, parce que chaque panneau est imprimé et positionné séparément par des personnes différentes le jour J, souvent dans l'urgence avant l'arrivée des premiers invités : un fichier unique qui regroupe tout oblige quelqu'un à découper ou recadrer sur place, ce qui est le moment où les erreurs et les retards apparaissent.

### Étape 7 : Le visuel de remerciement, produit à l'avance

Le visuel de remerciement (posté après l'événement, sur les réseaux) est préparé en amont, dans la charte du kit, avec l'espace réservé pour une photo qui n'existe pas encore. Il part en deux formats : carré (post) et story (vertical plein écran). Le texte de remerciement générique est fourni ; l'organisateur y insère la photo choisie après l'événement.

### Étape 8 : La planche de présentation et la livraison

Avant l'envoi final, une **planche de présentation** rassemble toutes les pièces du kit visuellement ensemble, pour que l'organisateur voie la cohérence d'ensemble avant validation.

Chaque pièce imprimée (kakemono, fond de scène, badges, signalétique, invitation A5 ou A6) est nommée avec ses cotes en centimètres dans le nom du fichier (ex. `kakemono-nomdelentreprise_85x200cm_v1.pdf`), pour qu'un imprimeur ne puisse pas se tromper de format en ouvrant le dossier. Chaque pièce numérique (invitation écran, remerciement) est livrée dans le format d'écran attendu par son canal.

## Format de sortie
- **Livrable** : l'invitation validée en premier (numérique + imprimable si demandée), puis le kit complet : kakemono/roll-up, fond de scène, badges (planche + gabarit nominatif), programme d'une page, signalétique (un fichier par panneau), visuel de remerciement (carré + story). Une planche de présentation qui montre l'ensemble. Un message de livraison qui récapitule ce qui part chez l'imprimeur, quand, et ce qui reste à confirmer.
- **Structure** : chaque pièce imprimée respecte les règles de la compétence `preparation-fichiers-impression` (fond perdu, traits de coupe, résolution, profil couleur, cotes réelles). Chaque pièce numérique respecte les dimensions natives de son canal de diffusion.
- **Nommage** : `<pièce>-<événement>_<format ou cotes>_v<N>` pour chaque fichier, afin qu'un imprimeur ou un organisateur identifie la pièce et son format sans ouvrir le fichier.
- **Longueur** : le kit complet correspond aux pièces demandées, ni plus ni moins ; le message de livraison tient en quelques lignes.
- **Règle 0 invention** : aucune information de l'événement (date, heure, adresse, nom de partenaire, cote de lieu) n'est produite sans avoir été fournie. Ce qui manque est marqué `à confirmer` et la pièce concernée ne part pas tant que la mention est active.

## Règles
1. **L'ordre de production suit l'ordre d'envoi.** L'invitation d'abord, toujours, parce qu'elle part la première. Le reste du kit ne commence qu'une fois l'invitation validée par l'organisateur.
2. **Le centre d'un photocall reste libre.** Le message ou le logo se répète en motif ou se place en bande haute ; jamais centré à l'endroit où les invités se placeront pour la photo.
3. **Un kakemono se hiérarchise par distance de lecture**. L'ordre d'importance sur un écran de conception ne s'applique pas ici : titre à dix mètres, sous-titre à trois mètres, rien d'indispensable dans le tiers inférieur.
4. **Les logos partenaires suivent l'ordre fourni**, jamais un ordre choisi par le designer, et s'alignent sur une même hauteur d'ancre.
5. **Le prénom domine le badge.** Il se lit de face à deux mètres ; l'entreprise ou la fonction vient après, plus petit.
6. **Chaque panneau de signalétique est un fichier séparé**, jamais un fichier unique à découper sur place.
7. **0 invention.** Aucune date, heure, adresse, nom de partenaire ou cote de lieu n'est produite sans être fournie par la fiche événement. `à confirmer` sinon, et la pièce ne part pas tant que la mention est active.
8. **L'imprimé et l'écran se séparent toujours.** Chaque pièce imprimée applique les règles de `preparation-fichiers-impression` (fond perdu, résolution, profil couleur, cotes) ; chaque pièce numérique applique les dimensions de son canal.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des fichiers de travail ; l'envoi de l'invitation aux invités, la commande chez l'imprimeur ou la publication du remerciement sont des actions validées par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un événement ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fiche événement incomplète**, tu produis avec ce que tu as, en marquant `à confirmer` chaque information manquante et en la signalant dans le message de livraison ; tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Logos partenaires fournis sans ordre précisé**, tu poses la question avant de produire les pièces qui les portent, plutôt que de choisir un ordre seul.
- **Cotes du lieu (fond de scène, kakemono) non données**, tu produis le visuel dans une proportion standard marquée `à confirmer`, et tu signales qu'il devra être redimensionné une fois les cotes réelles connues.
- **Invitation modifiée après validation**, tu reprends toutes les pièces déjà produites qui en dérivent avant de les livrer, tu ne laisses jamais coexister un kit sur deux versions de charte différentes.
- **Kit partiel demandé** (juste l'invitation, ou juste les badges), tu produis uniquement les pièces demandées, sans imposer le kit complet.
- **Événement déjà passé** (demande de bilan visuel ou de remerciement seul), tu produis le visuel de remerciement isolément, sans reconstituer les pièces qui ne servent plus.
- **Demande hors périmètre** (identité de marque complète, logo de l'entreprise à créer), tu le dis en une phrase et tu orientes vers la compétence de branding correspondante.
- **Action sortante demandée** (envoi de l'invitation, commande d'impression, publication), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions de la fiche événement, deux ordres de partenaires différents), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
