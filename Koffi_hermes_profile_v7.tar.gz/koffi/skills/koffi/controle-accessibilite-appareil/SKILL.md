---
id: Y0421
name: controle-accessibilite-appareil
description: "Écrit un protocole de contrôle d'accessibilité exécutable en vingt minutes par quelqu'un qui tient un vrai téléphone — zones touchables, texte agrandi, lecteur d'écran, plein soleil, rotation — puis exploite les résultats rapportés ; distingue strictement ce qui se calcule sur fichier de ce qui ne se prouve que sur appareil."
bucket: B
tags: [Design, Produit, Qualité, Nouveau]
version: 1
maj: 2026-08-13
---

# Contrôler l'accessibilité sur un appareil réel

## Ce qu'il faut avoir sous la main
- **L'écran ou le parcours** à contrôler, et comment y accéder.
- **Qui exécutera le test** et sur quel appareil — le modèle exact compte, pas la marque seule.
- **Le référentiel retenu** par la maison, s'il en existe un. Sinon, dis-le : je le signale et j'en propose un.
- **Ce qui a déjà été mesuré**, s'il y a lieu.

## Process
### Étape 1 — Séparer les deux colonnes avant d'écrire quoi que ce soit

Liste ce que tu as réellement mesuré toi-même, avec la méthode et la date. Puis liste ce qui reste indémontrable sans appareil. La deuxième colonne devient le protocole ; la première n'y entre pas, on ne fait pas refaire à la main ce qu'un calcul a tranché.

### Étape 2 — Écrire le protocole pour quelqu'un qui n'est pas du métier

Une manipulation par ligne, en langage ordinaire, avec le résultat attendu écrit **avant** le test pour qu'il n'y ait rien à interpréter. Le testeur doit pouvoir répondre par oui, non, ou une photo.

Les contrôles qui reviennent, et ce qu'ils cherchent :
- **Le pouce** : atteindre chaque cible d'une seule main, y compris en haut de l'écran, sans changer de prise.
- **Le texte agrandi** : pousser la taille de texte du système au maximum et rouvrir l'écran. On cherche du texte coupé, des boutons qui se chevauchent, un bouton principal sorti de l'écran.
- **Le lecteur d'écran** : parcourir l'écran à l'aveugle et écouter. On cherche les éléments annoncés sans nom, l'ordre de lecture incohérent, et les images porteuses d'information qui ne disent rien.
- **Le plein soleil** : sortir, viser le même écran. On cherche ce qui disparaît — et une couleur qui portait seule une information disparaît toujours la première.
- **La rotation et le clavier ouvert** : ce qui reste atteignable quand la moitié de la hauteur est mangée.
- **Le mode sombre**, s'il existe : les mêmes contrôles, parce que les couleurs y changent d'associations.

### Étape 3 — Demander la preuve, pas l'avis

Chaque écart revient avec une photo ou une capture. « C'est petit » n'est pas exploitable ; une photo l'est, et elle permet de mesurer après coup.

### Étape 4 — Exploiter le retour et trancher

Chaque écart rapporté reçoit un verdict : défaut du dessin, défaut de la construction, ou comportement attendu mal compris. Un écart qui vient de l'appareil du testeur et non du produit se note comme tel, il ne devient pas une correction.

### Étape 5 — Ce qui ne peut pas être testé se déclare

Un appareil unique ne dit rien du parc. Le rapport nomme le modèle testé, la version du système, et écrit noir sur blanc ce que ce test ne couvre pas.

## Format de sortie
- **Livrable 1** : la fiche de test — une manipulation par ligne, le résultat attendu, une case pour le constat, une pour la photo. Tient sur une page.
- **Livrable 2**, après retour : le rapport des écarts, chacun avec sa preuve, son verdict et sa correction ; suivi de ce que le test n'a pas couvert.
- **Longueur** : la fiche ne dépasse jamais ce qui s'exécute en vingt minutes, sinon elle n'est pas exécutée.

## Règles
1. **Un seuil ne se cite pas de mémoire.** Ni ratio de contraste, ni taille de cible, ni dimension minimale : ils dépendent du référentiel retenu et de sa version. Ou tu as la source sous les yeux et tu la cites, ou tu n'as pas le chiffre.
2. **Le référentiel se choisit, il ne se suppose pas.** Si la maison n'en a pas, tu le dis et tu proposes celui de la plateforme visée, en le nommant.
3. **Une spécification n'est pas un test.** Ne jamais écrire qu'un comportement est conforme parce qu'il est déclaré dans un document.
4. **Un seul appareil n'est pas le parc.** Le modèle testé est toujours nommé, et la portée du résultat avec lui.
5. **La preuve prime sur l'impression**, du testeur comme de toi.
6. **Le protocole se refait après correction**, sur les mêmes lignes, sinon on ne sait pas ce qui a bougé.

## Cas limites
- **Personne pour tenir l'appareil** — tu livres quand même la fiche, et tu dis clairement que les lignes concernées restent non vérifiées, sans les compter comme réussies.
- **Testeur qui connaît le produit par cœur** — il ne verra pas ce que voit un nouveau ; le noter dans la portée du test.
- **Écran derrière une authentification ou un paiement réel** — prévoir le jeu d'essai avant, plutôt que découvrir le blocage pendant les vingt minutes.
- **Résultat contredisant une mesure calculée** — la mesure calculée n'est pas fausse pour autant : chercher l'écart entre le fichier et ce qui est réellement construit.
- **Maison sans aucune politique d'accessibilité** — le signaler comme une décision à prendre, pas comme un manquement.
