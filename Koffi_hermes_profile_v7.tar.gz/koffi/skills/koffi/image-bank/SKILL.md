---
id: Y0171
name: image-bank
description: "Banque d'images IA pour startups africaines : génère des images brutes (photos contextuelles, illustrations, visuels de fond) cohérentes avec l'identité de la startup et son secteur. Ne crée pas les supports finaux."
bucket: D
tags: [Marketing & Growth]
version: 1
maj: 2026-08-10
---

# Image_Bank

## Ce qu'il faut avoir sous la main
1. **Nom / organisation**, **secteur** et **pays**
2. **Supports ciblés** : ☐ Réseaux sociaux ☐ Site web ☐ Print/Marketing ☐ Pancartes/Affichage ☐ Bannières événementielles
3. **Volume** : combien d'images ?
4. **Sujets & contextes** : scènes/personnes/environnements souhaités (ex. commerçants, marchés, bureaux…) — sinon je propose selon ton secteur

Je détecte le branding automatiquement, je te présente un brief à **valider**, puis je génère. Rien n'est généré avant ta validation.

> Lancé à l'invocation (pas de génération planifiée en tâche de fond).

> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un brief ou un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant clairement tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.


**Ce qu'elle suppose comme accès** : Registre du portefeuille + mémoire de branding, Stockage documentaire branding, Outil de design / brand kit, Génération d'images, Stockage documentaire. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Analyser** le branding (mémoire + fallback skill Branding) ; **rechercher** les visuels officiels du produit (hardware, screenshots). Absents → demander un upload. **JAMAIS improviser un produit/interface inexistant.**
2. **Planifier** la liste des images selon les supports.
3. **Brief visuel** par image (style, ton, sujet, couleurs, format). Pour une scène d'usage produit : vérifier comment le produit s'utilise et **décrire précisément son positionnement** (« placed upright on its stand », « mounted on the wall »…), ne jamais laisser le modèle décider seul.
4. **Valider** : présenter le récap (liste des images, palette, style) et attendre la confirmation explicite.
5. **Vérifier un template de marque existant** avant la génération IA : si un template au bon format existe, le proposer AVANT de générer. La génération IA est un recours. `[connecteur à brancher : outil de design / brand kit]`
6. **Générer** `[connecteur à brancher : génération d'images]` en intégrant le branding.
7. **Organiser** dans le stockage + **récapituler** (tableau final).

❌ Ne jamais générer sans brief visuel défini ET validation explicite. ❌ Ne jamais laisser les fichiers non organisés.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Ancrage géographique précis** : toujours pays + ville + quartier (ex. « Cocody, Abidjan, Côte d'Ivoire ») + codes vestimentaires/architecturaux locaux. Éviter « African city » générique. Adapter teintes de peau/traits/vêtements au réel local ; jamais de visages neutres non situés.
- **Environnement contextualisé** : cadre cohérent avec la ville/pays, sans enseigne lisible ni logo inventé.
- **Zéro texte lisible** : pas de badges, enseignes, noms d'institutions, texte sur vêtements ou surimpression.
- **Écrans jamais inventés** : screenshots officiels fournis → les utiliser comme référence via file ID ; sinon écran flouté ou hors champ. Renommer tout fichier de référence sans espaces/accents.
- **Aucune institution fictive** (logo/enseigne/nom).
- **Lumière & tonalité** : lumière naturelle, tons chauds ; intégrer la couleur primaire HEX du branding.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Détection du branding — explorer, ne pas demander

1. Charger automatiquement couleurs HEX, typos, logo, tagline via la skill de mémoire de branding (Memory Startup Branding). `[datasource à brancher : mémoire de branding]`
2. Compléter dans les sources : `[datasource à brancher : stockage documentaire « Branding des startups »]` + base de connaissances branding.
3. Assets incomplets → recours à la skill Branding pour une recherche approfondie.
4. Assets trouvés → les intégrer automatiquement dans les prompts.
5. Aucun asset → tons professionnels neutres par défaut + le mentionner.

### Catégories d'images & formats

- **Réseaux sociaux** : posts carrés 1080×1080, stories 1080×1920, bannières LinkedIn 1584×396, couvertures FB 820×312.
- **Site web** : hero 1920×1080, thumbnails 800×450, icônes 512×512.
- **Print/Marketing** : flyers A4, brochures tri-fold, cartes de visite 85×55mm.
- **Pancartes/Affichage** : roll-up 800×2000, kakémono, bâches.

Types par usage : personnes & contexte métier · environnement & lieu · produit/feature · équipe/coulisses (photos réelles depuis le stockage, sinon stock africain pro) · data/éducative (infographie, pas de photo) · événementielle · institutionnelle.

### Mots-clés par secteur

- **Fintech** : "African mobile payment", "West Africa fintech", "financial inclusion".
- **Agritech** : "African farmer technology", "smallholder farmer".
- **E-commerce** : "African marketplace", "African entrepreneur".
- **Santé** : "African healthcare professional", "community health".
- **Général B2B** : "African business meeting", "African startup team".

### Organisation du stockage

```
Banque_Images_[Startup]/
├── Reseaux_Sociaux/ (Posts/ Stories/ Bannieres/)
├── Site_Web/ (Hero/ Thumbnails/ Icones/)
├── Print_Marketing/ (Flyers/ Brochures/)
└── Affichage/ (Roll-up/ Evenementiel/)
```
Nommage : `[Startup] — [Support] — [Sujet] — [AAAA-MM-JJ]`.

### Résumé final obligatoire

Tableau : Format | Support | Nom du fichier | Emplacement | Statut (Généré / À revoir / Validé).
