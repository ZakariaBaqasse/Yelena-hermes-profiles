---
id: Y0188
name: linkedin-carousel-generator
description: "Crée des carrousels LinkedIn B2B complets et prêts à publier (texte, visuel, légende), calibrés sur le branding de l'entreprise et optimisés pour la portée organique. Remise OBLIGATOIRE en trois formes : le lien, le PDF et un PNG par planche, jamais le lien seul. Si Canva n'est pas branché, les planches se composent en HTML et se publient par la chaîne de la maison."
bucket: C
tags: [Content Creation]
version: 2
maj: 2026-09-23
---

# LinkedIn Carousel Generator

## ⛔ Contrôle avant remise, obligatoire (23/09/2026)

Un carrousel remis seulement en lien a dû être redemandé : il doit pouvoir être publié tel
quel. Avant d'envoyer, tu vérifies que le message de remise porte les trois formes :

1. **le lien** : la page publiée, ou le lien Canva éditable si Canva a servi ;
2. **le PDF** : une planche par page, dans l'ordre ;
3. **un PNG par planche**, numérotés dans l'ordre (`<slug>_v<N>_planche-01.png`, `-02`…),
   joints ou déposés dans un dossier partagé dont le lien est dans le message.

Une des trois manque : tu ne remets pas. Tu vérifies aussi, planche par planche sur le rendu,
que les polices sont les bonnes et que chaque chiffre porte sa source (contrôles 1 et 2 de
`production-visuelle-livrable`).

## Ce qu'il faut avoir sous la main
- **Startup** concernée (obligatoire).
- **Sujet du carousel** : spécifique et actionnable (ex. « Les 7 erreurs de pricing des SaaS africains »). Si tu n'as pas de sujet, dis-le : je propose un calendrier éditorial à exploiter ou 5 idées adaptées à la startup.
- **Site web de la startup** (recommandé), **concurrents/comparables** (optionnel), **template(s) Canva** de référence (optionnel, lien ou upload), **assets** (logos, images de fond) si tu en as, **dossier Canva de destination** pour ranger le fichier final.


**Ce qu'elle suppose comme accès** : Base de branding des startups, Journal des carousels déjà générés, Registre des Brand Template IDs et Brand Kit IDs Canva, Dossier partagé d'assets visuels, Canva. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
À réception d'une demande, vérifie les deux conditions suivantes avant toute génération :

**Condition A, Sujet valide :** le sujet doit être spécifique, actionnable et circonscrit. Exemples valides : « Les 7 erreurs de pricing des SaaS africains », « Comment intégrer Mobile Money en 3 étapes ». Exemples invalides : « fintech », « croissance », « IA ». Si vague, demande : « Peux-tu préciser ? Quel problème concret veux-tu résoudre pour ton audience, et quel résultat obtiendront-ils en lisant ce carousel ? ». **Si aucun sujet n'est fourni** → ne pas bloquer, proposer :
- **Option 1 : Calendrier éditorial :** l'utilisateur peut partager son calendrier éditorial (fichier, lien, ou contenu collé) → en extraire les carousels prévus ou les sujets identifiés, les lister avec leur date prévue si disponible, et demander lesquels produire en priorité.
- **Option 2 : Génération d'idées :** proposer 5 idées de carousel adaptées à la startup (en t'appuyant sur son site web et ses concurrents si fournis, sinon sur la base de branding, voir Étape 2), puis demander laquelle retenir.

**Condition B, Startup identifiée :** un nom de startup doit être fourni explicitement. Si absent, demande-le avant de continuer. Une fois le nom confirmé, collecte aussi : **site web** (recommandé), **concurrents ou comparables** (1-2, optionnel), **template(s) Canva** (lien public ou upload, optionnel, pour émuler le style ; si plusieurs templates fournis, chaque carousel sera associé au template le plus adapté à son contenu, en variant les templates autant que possible pour éviter les répétitions visuelles), **assets supplémentaires** (logos, images de fond, illustrations, téléversables à tout moment ; si un template nécessite un asset spécifique, récupère-le via `[datasource à brancher : dossier partagé, images et visuels de référence par startup, à insérer dans les templates Canva]`), **dossier Canva de destination** (demander si non fourni).

Si les deux conditions A et B sont remplies, passe à l'Étape 2.

### Étape 2 : Chargement du branding

Recherche la startup dans `[datasource à brancher : base de branding des startups (data room, une entrée par startup), champs nom, couleur principale (hex), couleur secondaire (hex), police de titre, police de corps, ton, audience cible, URL du logo]`. Note l'URL du logo exacte, elle sera passée directement au connecteur Canva pour insertion dans le design.

Si toutes les données sont trouvées (y compris l'URL du logo) → passe à l'Étape 3. Si des champs sont manquants (notamment URL logo, ton ou audience cible) → liste les champs manquants et demande-les à l'utilisateur. **Ne jamais passer à la génération du visuel (Étape 8) sans disposer de l'URL du logo** (les couleurs HEX et polices ne sont pas requises en texte, le Brand Kit Canva de la startup les gère automatiquement une fois branché). Si aucune entrée de branding trouvée → informe : « Aucune donnée de branding trouvée pour [startup]. » puis demande les champs essentiels : nom, URL logo, ton, audience cible.

### Étape 3 : Vérification de l'historique

Consulte `[datasource à brancher : journal des carousels déjà générés par startup, sujet, formule de hook, date, langue]`. Si un carousel sur le même sujet ou avec la même formule de hook existe déjà pour cette startup, signale-le et propose un angle différent ou un sujet complémentaire. Si aucun historique, continue sans interruption.

### Étape 4 : Langue et complexité

**Langue :** génère dans la langue de l'audience cible. Par défaut : français pour les marchés africains francophones (Sénégal, Côte d'Ivoire, Cameroun, Mali, Burkina Faso, Guinée, RDC, etc.). Pour une audience mixte, français avec termes techniques en anglais entre parenthèses.

**Complexité :** si le sujet est technique (ex. « intégration API USSD », « tokenisation des actifs »), ajoute une slide de définition en 1 phrase simple entre le hook et la slide problème. Si grand public, hook direct sans prérequis.

### Étape 5 : Sélection du hook

Choisis la formule selon le type de contenu : Liste numérotée (guide/outils), Avant/Après (parcours fondateur), Affirmation Data (donnée de marché), Affirmation Audacieuse (remise en question), Hook Problème (problème reconnaissable), Curiosity Gap (contre-intuitif), Shortcut Upgrade (raccourci).

**Règles du hook :** 6 à 10 mots maximum. Doit créer un manque informationnel que l'audience veut combler. Ne jamais répondre à la question sur la slide 1. Privilégier les chiffres impairs (3, 5, 7, 9). Ne jamais utiliser : « Dans le monde actuel... », « À l'ère du numérique... », « Aujourd'hui plus que jamais... ».

### Étape 6 : Génération des slides

**Structure, nombre de slides :** valeur par défaut 8 slides. Utilise 10 slides uniquement si le sujet nécessite plus de 6 points distincts et non réductibles. N'utilise jamais moins de 7 slides ni plus de 15 en l'absence de template. **Priorité template :** si un ou plusieurs templates Canva ont été fournis par l'utilisateur, le nombre de slides du template assigné s'impose comme contrainte absolue pour ce carousel. Si plusieurs templates sont disponibles : analyse chacun (structure, nombre de slides, format de texte) et associe chaque carousel au template le plus adapté à son contenu et sa formule de hook, en **variant les templates autant que possible** sur l'ensemble des carousels générés dans la session.

**Slide 1, Hook :** titre 6-10 mots (formule choisie), sous-titre optionnel max 12 mots, aucun corps, aucun numéro.

**Slide 2, Problème :** titre max 8 mots nommant le problème spécifique, corps 1-2 phrases max 25 mots, reconnaissable sans explication additionnelle, indicateur « 2 / [total] ».

**Slides 3 à N-1, Contenu :** titre max 8 mots, corps max 25 mots, 1 idée par slide (test : compréhensible sans lire aucune autre slide), indicateur « X / [total] » en bas à droite.

**Contrainte de variété :** inclure obligatoirement au moins 1 slide avec statistique ou donnée chiffrée, 1 slide avec comparaison (Avant/Après ou Option A vs B), 1 slide avec exemple concret, citation ou cas réel.

**Slide finale, CTA :** rappel de valeur en 1 phrase + 1 action unique. CTA doux par défaut (question spécifique ou invitation à sauvegarder). CTA fort (lien, DM, téléchargement) uniquement si demandé explicitement. Pas de numéro sur cette slide.

### Étape 7 : Auto-révision avant génération du visuel

Avant de créer le design, vérifie chaque point : slide 1 crée un manque informationnel · chaque slide contenu = exactement 1 idée · aucune slide ne dépend d'une autre · slide CTA = 1 seule action · aucun titre > 8 mots · aucun corps > 25 mots · variété présente (stat, comparaison, exemple) · indicateur de progression sur toutes les slides intermédiaires · si template(s) fourni(s) : nombre de slides conforme au template assigné à ce carousel · si template(s) fourni(s) : longueur de texte respecte les contraintes visuelles du template · si plusieurs templates disponibles : ce carousel utilise bien un template différent du précédent (varier autant que possible). Si une vérification échoue : corriger avant de continuer.

### Étape 8 : Génération du visuel

Produis directement le design (pas de délégation à un autre agent) via `[connecteur à brancher : Canva, actions create_design_from_brand_template, start_editing_transaction, replace_text, commit_editing_transaction, export_design, generate_design, create_design_from_candidate, resize_design]`. Résous le `brand_template_id` et le `brand_kit_id` de la startup via `[datasource à brancher : registre des Brand Template IDs (carousel LinkedIn 1080×1350px) et Brand Kit IDs Canva, un par startup du portefeuille]`.

**PATH A, Brand Template disponible (préféré) :**
1. récupère le `brand_template_id` de la startup dans le registre ;
2. `create_design_from_brand_template(brand_template_id)` : 1 seul appel, branding 100% respecté (polices, logo, couleurs) ;
3. `start_editing_transaction` → `replace_text` sur chaque slide avec les textes validés à l'Étape 7 ;
4. `commit_editing_transaction` ;
5. `export_design` en PDF, puis en PNG (une image par planche), et le lien éditable.

**PATH B, Aucun Brand Template (fallback) :** ⚠️ `instagram_post` ne génère qu'1 seule page, ne jamais l'utiliser pour un carousel multi-slides. Workflow obligatoire en 3 étapes :
1. `generate_design(design_type: "presentation", brand_kit_id: [id], length: "short", query: [contenu de toutes les slides détaillé])` : `presentation` est le seul type qui génère nativement plusieurs pages en 1 fichier ;
2. `create_design_from_candidate(job_id: [id retourné], candidate_id: [candidat avec le plus de thumbnails = celui qui a le plus de slides])` : choisir impérativement le candidat avec le maximum de thumbnails ;
3. `resize_design(design_id: [id retourné], design_type: { type: "custom", width: 1080, height: 1350 })` : redimensionne toutes les pages au format portrait LinkedIn.

Résultat : 1 fichier éditable, [N] pages, 1080×1350px. Ne jamais passer les couleurs HEX ou les polices en texte, le Brand Kit s'en charge automatiquement.

### Étape 9 : Gestion des échecs Canva

Si le connecteur Canva est indisponible ou retourne une erreur, ne pas retenter plus d'une fois, et ne jamais remettre du Markdown à copier-coller : ce n'est pas un carrousel. Tu composes les planches en HTML, une page par planche, tu rends le PDF et un PNG par planche au navigateur, et tu publies la page par la chaîne de `publication-frames` (`integrations/frames/autonomiser.py` puis `integrations/frames/publier.py … --accord`), vérifiée sur l'adresse servie. Tu dis dans la remise que Canva n'a pas servi et avec quoi tu as fait.

### Étape 10 : Caption LinkedIn

**ACCROCHE** (2 premières lignes, max 140 caractères) : visible avant « voir plus », miroir du hook reformulé pour le texte, ne jamais répondre à la question dans l'accroche.

**CORPS** (700 à 1 300 caractères) : 1-2 phrases par paragraphe, saut de ligne entre chaque, utiliser • ou ► pour les listes, jamais de lien dans le corps.

**CTA TEXTE** (1 ligne après saut de ligne) : si fort → « [Action], lien en premier commentaire ». Si doux → question ou invitation à sauvegarder.

**HASHTAGS** (3 à 5, après saut de ligne) : PascalCase uniquement, 2 tags larges + 2 tags niche africain tech.

### Étape 11 : Enregistrement en mémoire

Après livraison, enregistre dans `[datasource à brancher : journal des carousels déjà générés par startup]` : startup | sujet | formule hook | date | N slides | langue.

### Étape 12 : Livraison finale

1. Les trois formes du contrôle avant remise : le lien (Canva éditable, ou page publiée si Canva est indisponible), le PDF, et un PNG par planche.
2. Caption LinkedIn complète.
3. Rappel : « Colle le lien en premier commentaire après publication. Réponds aux commentaires dans les 90 premières minutes. »
4. Créneau optimal : mardi à jeudi, 8h-10h heure locale de l'audience.
5. **Tableau récapitulatif** (toujours inclure en clôture, même pour un seul carousel) :

| # | Sujet | Template utilisé | Slides | Lien | PDF | PNG |
|---|---|---|---|---|---|---|
| 1 | [sujet] | [nom template ou « sans template »] | [N] | [lien] | [fichier] | [N fichiers] |
| … | … | … | … | … | … | … |

📁 **Dossier Canva de destination :** [lien du dossier]

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
1. **Jamais sans branding validé** : pas de génération de visuel (Étape 8) sans URL de logo confirmée dans la base de branding (Étape 2) ; jamais de couleurs HEX ou de polices passées en texte au connecteur, le Brand Kit s'en charge.
2. **Historique systématique** : toujours vérifier le journal des carousels avant de proposer un sujet (Étape 3) et l'enregistrer après livraison (Étape 11) ; jamais deux carousels sur le même sujet/formule pour la même startup sans le signaler.
3. **Structure stricte** : titres ≤ 8 mots, corps ≤ 25 mots, 7 à 15 slides (ou nombre imposé par le template fourni), 1 seul CTA par slide, variété obligatoire (stat + comparaison + exemple), jamais les accroches interdites (« Dans le monde actuel... », « À l'ère du numérique... », « Aujourd'hui plus que jamais... »).
4. **Auto-révision avant génération** : la checklist de l'Étape 7 doit être intégralement validée avant tout appel au connecteur Canva ; en cas d'échec du connecteur, une seule tentative de relance, puis planches composées en HTML (Étape 9), jamais de Markdown.
6. **Remise en trois formes** : lien, PDF et un PNG par planche. Le lien seul n'est pas une remise.
5. **Caption disciplinée** : jamais de lien dans le corps du texte, 3 à 5 hashtags PascalCase (2 larges + 2 niche africain tech), langue calée sur l'audience cible (français par défaut pour l'Afrique francophone).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** : tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Historique

- v2, 23/09/2026 : contrôle avant remise obligatoire en tête (lien, PDF et un PNG par planche),
  export PNG ajouté, repli Markdown remplacé par des planches HTML publiées, tirets cadratins
  retirés, séance Sync agents training.
