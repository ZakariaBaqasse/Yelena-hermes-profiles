---
id: Y0503
name: avant-de-produire-pour-une-marque
description: "Le protocole que je déroule SEULE avant de fabriquer le moindre contenu pour une marque : fouiller son site, ouvrir ses comptes, relever ses normes, scraper ses comparables. À charger dès qu'une demande de production arrive pour une maison dont je n'ai pas encore ce relevé."
bucket: A
tags: [Marketing & Growth, Production]
version: 1
maj: 2026-08-24
---

# Avant de produire pour une marque

## Pourquoi cette compétence existe

Consigne du client, 24/08/2026, mot pour mot : « *on ne doit pas être obligé de te redire à
chaque fois de partir scrapper les comparables, voir les normes pour les vidéos ou images de
pubs du modèle de l'entreprise ou de partir fouiller sur son site pour prendre son logo, les
contacts, mails, infos ou encore comprendre en profondeur* ».

Elle est arrivée après deux échecs payés, tous les deux du même genre : j'avais fabriqué en
partant de ce que la marque **dit d'elle-même** au lieu de partir de ce qu'elle **fait
réellement**. Une fois trois films en 16/9 pour une maison dont les 254 vidéos sont verticales.
Une fois dix-huit plans avec un téléphone générique pour un revendeur d'iPhone.

**La règle : ce protocole se déroule sans qu'on me le demande, et il se termine AVANT le premier
plan.** Un relevé fait après la livraison ne sert qu'à comprendre pourquoi le client m'a reprise.

## Les quatre passes, dans cet ordre

### Passe 1 — Le site de la marque, fouillé, pas survolé

L'accueil ne suffit jamais : les fichiers utiles vivent dans les sous-pages.

- **Logo** en meilleure définition disponible, et les **couleurs mesurées sur le fichier**, pas
  lues sur une capture d'écran. Tant que la charte n'est pas transmise, tout livrable écrit que
  la couleur est *relevée, non fournie*.
- **Contacts** : téléphone, e-mail, adresse, points de vente. ⚠️ **Compter les chiffres d'un
  numéro** : un numéro à l'ancien format ne se met sur aucun visuel.
- **Catalogue réel** avec les prix affichés et leur date de relevé — un prix en promotion se
  périme en jours.
- **Signature**, promesses chiffrées, mentions légales, et ce qui relève d'une **allégation à
  faire valider** (santé, environnement, financier, classement).
- **Sous-pages produit** : c'est là que sont les emballages officiels et les visuels propres.
  Une gamme sans page produit n'a pas de fichier officiel, donc pas de publicité possible.

### Passe 2 — Leurs propres comptes, ouverts et comptés

**Un compte déclaré et non ouvert n'est pas une information, c'est un trou.** On l'ouvre, on
extrait tout ce qui est extractible, et on compte :

- **Format** : dimensions réelles de chaque publication, et la proportion. « Ils font du
  vertical » ne suffit pas — c'est *combien sur combien*.
- **Durée** : minimum, maximum, **médiane** (jamais la moyenne, une seule vidéo longue la tord).
- **Nature** : vidéo ou diaporama d'images ? Deux canaux qui ont l'air identiques peuvent être
  l'un un canal vidéo, l'autre un mur d'affiches.
- **Registre** : leurs sous-titres officiels donnent les phrases exactes. On écrit dans **leur**
  langue parlée, pas en français de brochure.
- **Ce qui marche chez eux** : classement par vues **rapportées aux abonnés**, jamais en vues
  brutes. Le sujet de leur meilleure vidéo est le sujet de la campagne.
- **Mots-dièse par fréquence réelle**, pas ceux qu'on imagine.
- **Affichent-ils leurs prix ?** Beaucoup le font, et ça change tout le brief.

### Passe 3 — Les comparables, scrapés, pas devinés

Deux ou trois maisons du même métier, plus **une référence internationale** du secteur.

Pour chacune : les mêmes mesures que la passe 2, **plus leurs promesses chiffrées**. C'est là
qu'on découvre qu'un concurrent annonce mieux sur l'axe même de la campagne — et ça, le client
doit l'apprendre avant de payer une diffusion, pas après.

⚠️ **Toujours écrire la taille de l'échantillon.** « Médiane 51 s sur les 40 publications les
plus récentes d'un canal qui en compte 670 » n'est pas « médiane 51 s ». Un relevé partiel
présenté comme complet est un chiffre faux.

### Passe 4 — Ce qu'on copie, et ce qu'on ne copie pas

Le mot du client est « tu copies ». Ce qui se copie honnêtement, c'est une **mécanique** :
un format, une durée, une structure de plan, un genre qui marche, une manière d'incarner une
promesse. Ce qui ne se copie pas : un plan, une musique, une accroche, une identité visuelle —
et **rien d'une autre maison dont je suis l'Experte**, pas même comme ordre de grandeur.

🚨 **Et le comparable n'a pas toujours raison.** Si les chiffres montrent que la marque du client
fait mieux que ses comparables sur la mesure qui compte, copier serait une régression, et je le
dis au lieu d'obéir. C'est arrivé dès le premier usage de ce protocole.

## Ce que le protocole produit

Un fichier de relevé dans `connaissances/<marque>-la-maison.md` — ma mémoire de travail, pas un
livrable — qui porte **sa date** et **la taille de chaque échantillon**, et qui devient la source
de vérité de toute production pour cette maison. Plus, dans ma mémoire, les cinq lignes qui ne
doivent pas exiger de rouvrir le fichier : format, durée médiane, registre, sujet qui marche,
réserves qui bloquent une diffusion.

## Réserves qui remontent au client, toujours dans le fil

Mandat manquant, charte non fournie, allégation non validée, mention réglementaire absente,
numéro à vérifier, compte introuvable. Ça se dit en français dans la conversation, jamais dans
un fichier déposé à côté.

## Coût

La passe 3 est facturée à l'extraction. Le client a autorisé le réflexe le 24/08/2026 ; le coût
se dit après, avec le résultat, jamais en demande d'autorisation préalable pour la même chose
deux fois.
