---
id: Y0410
name: lisibilite-et-accessibilite
description: "Contrôle qu'un document, un visuel ou une page reste lisible et utilisable dans les conditions réelles de son destinataire — petit écran, connexion lente, plein soleil, impression en noir et blanc, lecture à voix haute — et produit un rapport point par point avec verdict et correction, sans jamais inventer un seuil de contraste ou une taille minimale."
bucket: B
tags: [Design, Qualité, Horizontal, Nouveau]
version: 1
maj: 2026-08-13
---

# Rester lisible — petit écran, mauvaise connexion, impression en noir et blanc

## Ce qu'il faut avoir sous la main
- **Le fichier ou le lien** à contrôler — document, visuel, page, template.
- **Le canal de diffusion réel** : écran (lequel, sur quel appareil en majorité chez tes destinataires), impression (couleur ou noir et blanc), envoi via WhatsApp ou e-mail, affichage physique.
- **La distance de lecture prévue** si c'est un support physique — affiche, kakémono, panneau — ou la taille d'écran dominante si c'est numérique.
- **Le référentiel d'accessibilité déjà retenu par l'entreprise**, s'il existe (norme interne, WCAG, charte graphique avec ses règles de contraste). S'il n'existe pas, dis-le — je le signale comme un manquant, je n'en invente pas.
- **Toute contrainte connue** : forfait data limité chez les destinataires, lecteurs concernés par une déficience visuelle, usage prévu par une synthèse vocale.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Se placer dans les conditions du destinataire, pas dans celles de l'auteur

Avant de mesurer quoi que ce soit, fixe le scénario réel de réception : quel appareil, quelle luminosité ambiante, quelle distance, quelle vitesse de connexion, en couleur ou en noir et blanc. C'est le piège le plus fréquent du métier — valider sur un grand écran calibré, en intérieur, avec une connexion rapide, ne dit rien de ce que voit un client sur un téléphone bas de gamme, en plein soleil devant un maquis ou un point de vente, avec un forfait qui se compte en mégaoctets.

**Ces conditions se relèvent, elles ne se supposent pas.** L'ordre est strict et il n'a pas d'exception : tu demandes d'abord, tu supposes seulement ensuite. La question tient en une ligne — « quels téléphones ont vos utilisateurs, comment paient-ils leur connexion, où lisent-ils ce support » — et elle ne bloque rien : tu produis pendant que la réponse arrive.

Si la réponse n'arrive pas, pose l'hypothèse la plus exigeante — écran petit, connexion lente, impression en noir et blanc — et marque-la `[hypothèse : …]` **partout où elle sert d'argument**. Un contrôle qui réussit dans le pire cas réussit partout ; l'inverse n'est pas vrai.

🚨 **Une condition supposée ne se présente jamais comme un fait de terrain.** C'est la faute que cette étape existe pour empêcher, et elle est passée quand même : écrire « vos utilisateurs paient leur connexion au volume » quand personne ne l'a dit, c'est fabriquer du contexte local — la forme d'invention la plus difficile à repérer, parce qu'elle a l'air d'une connaissance du terrain et que personne ne va la vérifier. La phrase juste porte sa réserve dans la phrase elle-même : « en supposant une connexion payée au volume, ce qui reste à confirmer », jamais « comme la connexion est payée au volume ». Et le marqueur porte sur **l'affirmation**, pas seulement sur le chiffre.

### Étape 2 — Mesurer le contraste par association de couleurs utilisée

Relève chaque association texte/fond et élément graphique/fond effectivement présente dans le document — pas une association théorique. Pour chacune, applique le référentiel de contraste retenu par l'entreprise, s'il t'a été donné. S'il n'existe pas, tu le dis explicitement : **« aucun référentiel de contraste n'a été fourni, ce point ne peut pas être tranché, seulement décrit »** — tu ne fixes pas de seuil à sa place.

Le contraste se mesure, il ne s'apprécie pas à l'œil. Une couleur de marque posée sur une autre couleur de marque est le cas le plus fréquent d'échec silencieux : les deux couleurs sont choisies pour l'identité visuelle, jamais testées ensemble pour la lecture.

### Étape 3 — Tester le rendu en noir et blanc et l'information portée par la couleur seule

Simule le document en niveaux de gris. Repère toute information qui disparaît ou devient ambiguë : un statut en rouge/vert, une légende qui ne distingue ses catégories que par la teinte, un bouton dont l'état actif ne se voit qu'à la couleur. C'est un cas concret et fréquent : un document conçu à l'écran et imprimé chez un prestataire local en noir et blanc, ou photocopié dans un bureau, perd cette information sans que personne ne l'ait vu venir.

Pour chaque cas repéré, la correction n'est pas de changer la couleur — c'est d'ajouter un **second marqueur indépendant de la couleur** : un mot, un symbole, un motif, une position. Une information qui ne tient que sur une teinte n'est pas accessible, même si cette teinte est parfaitement contrastée.

### Étape 4 — Repérer le texte incrusté dans une image

Cherche tout texte qui existe uniquement comme pixels dans un visuel plutôt que comme texte réel — titre stylisé intégré à une affiche numérique, citation incrustée dans une image partagée sur les réseaux, tableau capturé en image plutôt que composé en texte. Ce texte-là ne peut être ni sélectionné, ni copié, ni traduit, ni retrouvé par une recherche, ni lu par une synthèse vocale — un blocage réel pour un lecteur malvoyant ou pour quelqu'un qui reçoit le document dans une langue qu'il lit mal et compte sur un outil de traduction.

Distingue le cas où c'est un choix assumé — une affiche destinée à l'impression, où le texte fait partie de la composition graphique — du cas où c'est un oubli sur un support qui devait rester du texte exploitable. Le premier cas n'est pas une erreur ; le second l'est.

### Étape 5 — Tester le petit écran et le comportement sans images

Vérifie ce que devient le contenu sur la taille d'écran la plus contraignante attendue chez les destinataires : titres tronqués, boutons trop petits pour un doigt, tableaux qui obligent à défiler dans les deux sens. Vérifie ensuite ce qui reste lisible si les images ne se chargent pas — cas courant avec une connexion instable ou un forfait limité : le message principal doit survivre en texte seul, pas disparaître avec l'image qui le portait.

Contrôle au même moment les textes de remplacement des images : une image sans texte alternatif est une image absente pour une synthèse vocale ou pour quelqu'un qui navigue en mode texte, même si elle se charge très bien à l'écran.

### Étape 6 — Vérifier la hiérarchie de titres et le poids du fichier

Contrôle que la hiérarchie de titres est cohérente et continue — elle sert de repère à qui navigue par lecteur d'écran ou par sommaire automatique, pas seulement de mise en forme visuelle. Un titre de niveau 3 qui suit directement un titre de niveau 1, sans niveau 2 entre les deux, casse ce repère même si l'effet visuel semble correct.

Vérifie ensuite le poids du fichier au regard de son mode de transport réel. Un document de plusieurs dizaines de mégaoctets envoyé par WhatsApp ou par e-mail avec une connexion lente ne sera simplement pas ouvert par une partie des destinataires — le poids fait partie de la lisibilité au sens propre : ce qui ne s'ouvre pas ne se lit pas. Le seuil de poids acceptable est aussi une décision de l'entreprise selon ses canaux ; s'il n'a pas été donné, tu le signales et tu laisses le champ en `⟦à renseigner⟧`, sans en fixer un toi-même.

### Étape 7 — Le rapport de contrôle et le verdict par point

Chaque point contrôlé porte trois éléments : le constat, le verdict (conforme / non conforme / non tranchable faute de référentiel), et la correction proposée. Pas de verdict global unique qui écraserait les nuances — un document peut être irréprochable sur le contraste et défaillant sur le texte incrusté dans l'image.

Termine par une hiérarchisation : quels points bloquent la compréhension du message pour une partie réelle et significative des destinataires, et lesquels sont des améliorations secondaires. Un problème qui touche le canal le plus utilisé par les destinataires réels passe avant un problème visible seulement dans un scénario marginal.

## Format de sortie
- **Livrable** : le rapport de contrôle — scénario de réception retenu, mesures de contraste par association de couleurs (ou signalement de l'absence de référentiel), rendu en noir et blanc et informations portées par la couleur seule avec leur second marqueur proposé, textes incrustés à sortir de l'image, rendu petit écran et comportement sans images, hiérarchie de titres, poids du fichier au regard de son canal de transport. Chaque point : constat, verdict, correction.
- **Structure** : Markdown, tableau point par point recommandé quand le nombre de points le justifie ; answer-first — les points bloquants en tête, les points secondaires ensuite.
- **Longueur** : proportionnée au support contrôlé. Une affiche appelle un rapport court ; un document long ou un site appelle un rapport plus développé, sans remplissage.
- **Les seuils sont un input**, pas une production : contraste minimal, taille minimale, poids maximal de fichier viennent du référentiel de l'entreprise ou restent `⟦à renseigner⟧`.
- **Règle 0 invention** : aucun seuil, aucune norme, aucun chiffre d'accessibilité inventé. Une norme non fournie est signalée comme absente, jamais remplacée par une valeur plausible.

## Règles
1. **Le contraste se mesure, il ne s'apprécie pas à l'œil.** Tu appliques le référentiel fourni ; à défaut, tu décris l'association de couleurs et tu signales l'absence de norme — tu ne tranches jamais au jugement visuel.
2. **Aucune information ne tient sur la couleur seule.** Chaque fois qu'une couleur porte un sens (statut, catégorie, alerte), tu exiges ou proposes un second marqueur indépendant de la couleur.
3. **Le texte qui peut être du texte doit être du texte.** Un texte incrusté dans une image sur un support qui devait rester exploitable est une non-conformité, pas un détail esthétique — sauf s'il s'agit d'un visuel assumé pour impression ou diffusion visuelle seule.
4. **Le contrôle se fait dans les conditions du destinataire, jamais dans celles de l'auteur.** Le scénario de réception le plus dégradé et le plus fréquent prime sur le confort de l'écran de production.
5. **Le poids du fichier fait partie de la lisibilité.** Un document qui ne s'ouvre pas sur le canal de diffusion réel n'est pas lu, quelle que soit la qualité de son contenu.
6. **0 seuil inventé.** Ratio de contraste, taille minimale de police, poids de fichier acceptable : ces valeurs viennent du référentiel de l'entreprise et restent `⟦à renseigner⟧` tant qu'elles ne sont pas données.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; republier, réenvoyer ou réimprimer un support corrigé est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun référentiel d'accessibilité fourni** — tu produis le rapport complet, tu décris chaque association ou taille sans la trancher, et tu marques clairement que ce point reste `⟦à renseigner⟧`. Tu ne fixes jamais un seuil à la place de l'entreprise.
- **Une pièce annoncée mais absente** (« voici le visuel », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais examiné.
- **Canal de diffusion inconnu** — tu retiens le scénario le plus contraignant (petit écran, connexion lente, noir et blanc) comme hypothèse par défaut, et tu le marques comme telle.
- **Support imprimé uniquement, jamais lu à l'écran** — tu adaptes le contrôle : contraste et taille à la distance de lecture prévue prennent le pas sur le poids de fichier et le comportement sans images, qui ne s'appliquent pas.
- **Texte incrusté volontaire** (affiche, visuel de communication assumé comme image) — tu ne le signales pas comme une erreur, tu notes seulement que ce texte restera hors de portée d'une synthèse vocale ou d'une traduction automatique, pour information.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme mesuré sans l'avoir réellement examiné.
- **Demande hors périmètre** (refonte graphique, choix de charte) — tu le dis en une phrase, tu traites ce qui relève du contrôle de lisibilité, et tu renvoies vers la compétence ou l'équipe compétente pour le reste.
- **Action sortante demandée** (republication, renvoi du fichier corrigé, impression) — tu prépares le rapport et les corrections proposées, et tu t'arrêtes pour validation humaine avant toute diffusion.
- **Sources ou référentiels contradictoires** (deux chartes internes donnant des règles différentes) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
