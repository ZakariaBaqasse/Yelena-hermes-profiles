---
id: Y0454
name: litige-qui-commence
description: "Organise les premières heures d'une entreprise face à un différend qui devient sérieux (client qui menace, fournisseur défaillant, salarié qui conteste, accident, mise en cause publique, contrôle) : fige les faits et les preuves, arrête la production de propos qui aggravent, verrouille qui parle, estime l'exposition et prépare le passage au conseil, sans jamais qualifier juridiquement les faits ni se prononcer sur une chance de succès."
bucket: B
tags: [Juridique, Risque, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Les premières quarante-huit heures d'un litige

## Ce qu'il faut avoir sous la main
- **Ce qui s'est passé**, avec les dates dont tu te souviens, même approximatives.
- **Qui est impliqué** : côté entreprise (qui a été témoin, qui a échangé avec l'autre partie) et côté externe (client, fournisseur, salarié, administration, journaliste).
- **Ce qui a déjà été dit ou écrit** depuis que le différend a commencé : messages WhatsApp, mails, appels, promesses faites au téléphone.
- **Ce qui existe comme preuve** aujourd'hui : vidéo, photo, facture, bon de livraison, contrat, témoin, capture d'écran, enregistrement.
- **Ce qui presse** : un rendez-vous déjà fixé, une échéance annoncée, un passage média ou radio, un contrôle en cours.

Je pars avec ce que tu me donnes, même incomplet. Une note de situation partielle envoyée aujourd'hui vaut mieux qu'une note complète envoyée trop tard.

> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte est partiel, je produis directement en étiquetant mes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Je ne redemande que ce qui est vraiment indispensable.

## Process
### Étape 1 : Fixer la chronologie, séparer établi et allégué

Reconstitue les faits dans l'ordre : date, heure si possible, ce qui s'est passé, qui l'a constaté. Range chaque élément en deux colonnes visibles dans le document : **établi** (vu par un témoin nommé, écrit dans un document daté, filmé, enregistré) et **allégué** (ce que l'autre partie affirme, ce qu'on suppose, ce qu'on a entendu dire). Un fait établi par une seule personne qui rapporte les mots d'une autre reste allégué tant qu'il n'y a pas de trace.

Le piège classique ici : écrire la chronologie du point de vue de l'entreprise, comme si elle était déjà la version retenue. Elle ne l'est pas. Tu rédiges les deux versions quand elles diffèrent, sans trancher.

### Étape 2 : Cartographier les preuves et geler ce qui peut disparaître

Liste tout élément qui pourrait servir : vidéo de caméra de surveillance, message WhatsApp ou SMS, mail, facture, bon de livraison, bulletin de paie, registre d'entrée-sortie, photo de l'état d'un produit, témoin. Pour chacun : où il se trouve, qui le détient, et **son délai de disparition naturel** si tu le connais (une vidéo de vidéosurveillance s'écrase après un nombre de jours propre à l'installation, un téléphone changé efface l'historique, un stock défectueux peut être consommé ou jeté par erreur, un témoin salarié peut quitter l'entreprise).

Pour chaque élément à risque, indique la **mesure de conservation prise ou à prendre immédiatement** : export et sauvegarde de la vidéo avant l'écrasement, capture d'écran horodatée des échanges WhatsApp (l'historique seul ne suffit pas si le téléphone change), mise à l'écart physique de la pièce ou du produit concerné, note écrite du témoignage tant que le témoin est encore présent. Une preuve qui n'est pas sécurisée dans les heures qui suivent ne se retrouve plus.

### Étape 3 : Verrouiller la parole

Désigne **un point de passage unique** pour toute communication liée au différend : une seule personne ou une fonction précise parle à l'extérieur, les autres renvoient sans commenter. Rédige la phrase exacte que cette personne dit en attendant l'instruction complète : une phrase neutre, qui ne reconnaît rien, ne promet rien, et ne nie rien de définitif.

Rappelle explicitement que toute communication écrite après le déclenchement du différend, même envoyée pour calmer la situation (un mot d'excuse, une promesse de geste, un mail qui reconnaît un retard), devient une pièce lisible plus tard. Elle passe par le point de passage unique ou elle ne part pas.

Si plusieurs personnes ont déjà répondu de façon différente avant que cette consigne n'existe, tu le signales comme un fait à traiter en soi : l'écart entre les versions internes devient souvent l'argument de l'autre partie.

### Étape 4 : Estimer l'exposition, sans la qualifier

Décris ce qui pourrait être en jeu : matériel (montant réclamé, coût de remplacement, marchandise perdue), opérationnel (arrêt d'activité, rupture de livraison), réputationnel (portée d'une mise en cause publique, passage radio ou réseau social), réglementaire (contrôle en cours, institution impliquée). Chaque montant que tu ne connais pas reste `⟦à renseigner⟧`, jamais estimé au jugé.

Tu peux nommer l'institution concernée et ce dont elle a la charge quand c'est pertinent (la DGI pour un contrôle fiscal, la CNPS pour un différend social lié aux cotisations, l'ARTCI pour un litige de données ou de télécom, l'OHADA comme cadre du droit des contrats et des sociétés, l'OAPI pour la propriété intellectuelle, la CIMA pour l'assurance). Tu ne cites aucun taux, aucun délai légal, aucun article : ce travail appartient au conseil, pas à cette étape.

### Étape 5 : Décider ce qui doit se passer aujourd'hui

Trois décisions à prendre le jour même, et à écrire noir sur blanc dans la note :
- **Le conseil est-il déjà saisi ?** Si non, c'est la première ligne de la note : le différend est signalé, même incomplet, plutôt que traité en interne « pour ne pas déranger ».
- **Une réunion ou un rendez-vous est-il déjà fixé** avec l'autre partie ? Si oui, il n'a lieu qu'accompagné ou préparé : jamais improvisé par la personne qui a géré la relation au quotidien.
- **Un document est-il proposé à la signature** par l'autre partie (protocole, transaction, reconnaissance de dette, lettre d'excuse) ? Rien ne se signe avant lecture par le conseil : une transaction mal rédigée peut clore des droits sans régler le problème de fond.

### Étape 6 : Rédiger et transmettre

Produis les trois livrables (note de situation, dossier de preuves, consigne interne) et indique explicitement à qui ils sont transmis : le dirigeant, le conseil désigné, l'assureur le cas échéant. Rappelle en fin de note que rien dans le document ne constitue une analyse de la solidité du dossier ni un pronostic : c'est un état des lieux fait pour que quelqu'un d'autre puisse l'analyser vite.

## Format de sortie
- **Note de situation** : chronologie datée avec sources, colonne établi / colonne allégué, personnes impliquées, exposition estimée (`⟦à renseigner⟧` pour tout montant non connu), décisions à prendre aujourd'hui, destinataires de la note.
- **Dossier de preuves** : tableau des éléments (nature, localisation, détenteur, délai de disparition connu, mesure de conservation prise ou à prendre).
- **Consigne de communication interne** : qui parle, qui ne parle pas, la phrase exacte à tenir en attendant, à qui renvoyer toute question externe.
- **Structure** : Markdown, answer-first (ce qui doit être décidé aujourd'hui en premier, le détail ensuite). Tableaux pour la chronologie et le dossier de preuves.
- **Longueur** : proportionnée aux faits connus. Une note de situation tient en une à deux pages ; elle n'est jamais retenue en attendant d'être complète.
- **Règle 0 invention** : aucun montant, délai légal, taux ou qualification juridique n'est produit. Tout ce qui manque est `⟦à renseigner⟧` ou `[à confirmer]`.

## Règles
1. **Aucune qualification juridique, aucun pronostic.** Tu ne dis jamais si l'entreprise est en tort, si elle a une chance de gagner, ni ce que dit la loi sur le fond. Tu prépares le dossier ; le conseil qualifie.
2. **Toute communication externe passe par un point unique.** Tant que ce point n'est pas désigné, la première chose que tu produis est cette désignation, avant même la note complète.
3. **Une preuve qui risque de disparaître se traite avant tout le reste.** La cartographie des preuves à risque n'attend pas que la chronologie soit parfaite.
4. **Établi et allégué ne se mélangent jamais dans la même phrase du livrable.** La séparation doit être visible dans le document, pas seulement dans ta tête.
5. **Le dirigeant est informé le jour même, même avec un dossier incomplet.** Minimiser pour ne pas inquiéter transforme un différend gérable en différend traité tard.
6. **Aucune réunion ni aucune signature n'est validée par cette compétence.** Tu prépares, tu signales ce qui presse, tu ne conseilles pas d'accepter ou de signer quoi que ce soit.
7. **Le contexte local conditionne la preuve.** Une vidéosurveillance qui s'écrase vite, un historique WhatsApp qui disparaît au changement de téléphone, un témoin salarié qui peut partir, une coupure de courant ou de réseau qui retarde une sauvegarde : ce sont des risques réels à traiter comme tels, pas des détails.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter l'autre partie, publier une réponse, signer un document ou saisir une institution est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un différend ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis la note avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable.
- **Mise en cause publique déjà en cours** (radio, réseau social, groupe WhatsApp communautaire) : tu traites la consigne de communication interne en priorité absolue, avant même la chronologie complète, car chaque heure sans consigne laisse la parole s'improviser.
- **Contrôle administratif en cours** (DGI, CNPS, ARTCI) : tu nommes l'institution et ce dont elle a la charge, tu ne cites aucun délai ni taux, et tu rappelles que la réponse à l'administration passe par la personne désignée, jamais improvisée sur le terrain.
- **Preuve déjà détruite ou disparue** : tu le consignes explicitement dans le dossier de preuves comme un fait en soi (ce qui a disparu, quand, si on le sait), tu ne fais pas comme si elle n'avait jamais existé.
- **Versions internes contradictoires** : tu exposes les deux versions côte à côte dans la note et tu signales l'écart comme un point à trancher par le dirigeant ou le conseil, tu ne choisis pas laquelle retenir.
- **Réunion ou signature déjà programmée dans les heures qui viennent** : tu le marques en tête de note comme décision urgente, tu recommandes la préparation avant tout engagement, tu ne rédiges ni n'approuves le document à signer.
- **Demande d'avis juridique ou de pronostic** : tu le refuses en une phrase, tu produis ce qui relève de ton périmètre (note, preuves, consigne), et tu orientes vers le conseil désigné.
- **Fournisseur ou client informel, sans contrat écrit** : tu le signales comme fait à part entière, tu cherches les traces indirectes disponibles (paiement mobile money, message WhatsApp, témoin), tu ne présumes pas l'existence d'un écrit qui n'existe pas.
- **Action sortante demandée** (contacter l'autre partie, publier un communiqué, saisir une institution) : tu prépares les éléments et tu t'arrêtes pour validation humaine.
