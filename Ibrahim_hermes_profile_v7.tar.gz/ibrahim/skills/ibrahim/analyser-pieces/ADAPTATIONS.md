# Adaptations locales

⚠ **Ce fichier PRIME sur le `SKILL.md`** partout où les deux se contredisent. Le texte amont
n'est pas modifié : une mise à jour depuis la source le remplacerait et emporterait la
correction.

## Le pack est écrit pour un cabinet d'avocats français, nous sommes en Côte d'Ivoire

La **méthode** du pack est bonne et transposable : séparer les faits des allégations,
conserver les contradictions, exiger une source, bloquer une sortie qui attend encore une
décision humaine. C'est ce qu'on en garde.

Ce qui ne se transpose pas :

1. ⛔ **Le droit applicable n'est ni français ni européen.** C'est le droit ivoirien, et le
   droit **OHADA** qui prime sur le droit interne contraire. Les sources utilisables sont
   dans `rechercher-droit/references/sources-officielles-ci.md`.
2. ⚠ **Le vocabulaire de procédure ne correspond pas.** Les noms de juridictions, de
   recours et de délais du texte amont sont français : ne jamais les reprendre tels quels
   dans un livrable. Dans le doute, nommer l'acte sans nommer la juridiction.
3. ⚠ **« Avocat » n'est pas notre rôle.** Ce poste est un expert juridique d'entreprise, pas
   un auxiliaire de justice. Les passages sur la déontologie de l'avocat, le secret
   professionnel de l'avocat et les règles du barreau ne s'appliquent pas à nous. Ce qui
   s'applique reste entier : la confidentialité due au client, et le
   `cloisonnement-client` du socle.

## Ce qui reste inchangé et prime sur tout

Les socles de la maison continuent de commander : `socle-anti-hallucination` (un marquage se
mérite, il vient après la recherche), `socle-livrables-tous-formats` (un livrable sort par
paire), `cloisonnement-client`, et l'interdiction des tirets cadratins.
