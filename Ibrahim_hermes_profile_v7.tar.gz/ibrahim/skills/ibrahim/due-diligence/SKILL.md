---
id: Y0139
name: due-diligence
description: "Due diligence numérique sur une personne ou une entité (fondateur, startup, partenaire potentiel) avant décision d'investissement ou de partenariat : recherche web approfondie, vérification LinkedIn, détection de signaux de risque (litiges, sanctions, presse négative), verdict de risque gradué avec sources systématiquement citées."
bucket: C
tags: [Legal]
version: 1
maj: 2026-09-09
---

# Due Diligence

## Ce qu'il faut avoir sous la main
1. Le **nom de la personne ou de l'entité** à analyser.
2. Une **source de départ** si tu en as une : URL LinkedIn, site web, ou juste le nom si tu n'as rien d'autre.


⚠️ **Avertissement à donner systématiquement** : cette analyse est un premier filtre basé sur des informations publiques, pas une enquête exhaustive. Pour une décision d'investissement ou de partenariat, une due diligence complète (juridique, financière) reste recommandée.

### Contrôles qualité

- **Recoupement des faits** : ne jamais valider une info sur une seule source si plusieurs sont disponibles.
- **Test des liens** : vérifier que les liens fournis fonctionnent réellement avant de les citer.
- **Distinction faits / opinions / rumeurs** : ne jamais présenter une rumeur comme un fait établi.
- **Respect de la vie privée** : ne pas inclure d'informations privées non pertinentes pour l'évaluation du risque.


**Ce qu'elle suppose comme accès** : Base "Due Diligence", Recherche web, Extraction/vérification LinkedIn. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### Méthodologie de recherche

Recherche sur : **{nom / entité}**, source de départ fournie : **{URL LinkedIn / site web / nom}**.

Toutes les recherches de cette section passent par `[connecteur à brancher : recherche web (moteur + navigation)]`, sauf l'analyse du profil LinkedIn qui passe par `[connecteur à brancher : extraction/vérification LinkedIn (type Unipile)]`.

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Recherche exhaustive** : ratisser Google, LinkedIn, réseaux sociaux, presse, jamais se limiter à une seule source.
- **Chaque affirmation est sourcée** : fournir le lien de CHAQUE information mentionnée. Une info sans URL vérifiable n'a pas sa place dans le rapport.
- **Uniquement des faits avec preuves** : jamais de spéculation. Ce que tu ne peux pas sourcer, tu ne l'affirmes pas.
- **Risque gradué, pas binaire** : évaluer le niveau de risque de façon nuancée (FAIBLE / MOYEN / ÉLEVÉ / CRITIQUE), jamais un simple bon/mauvais.
- **Ton professionnel et factuel** : empathique dans la forme, factuel sur le fond, tu documentes, tu ne juges pas.

1. **Jamais d'affirmation sans source**, chaque fait cité doit être accompagné de son URL vérifiable ; sans URL, l'info n'entre pas dans le rapport.
2. **Recherche multi-sources obligatoire**, Google, LinkedIn, réseaux sociaux, presse, registres officiels : ne jamais conclure sur une seule source pour un signal de risque.
3. **Risque gradué, jamais binaire**, verdict FAIBLE/MOYEN/ÉLEVÉ/CRITIQUE justifié, jamais un simple GO/NO-GO sans nuance.
4. **Recoupement avant conclusion**, recouper systématiquement une information sensible (litige, sanction, controverse) sur au moins deux sources avant de l'inclure dans le résumé exécutif.
5. **Avertissement systématique**, rappeler à chaque analyse que c'est un premier filtre, pas une enquête exhaustive, et qu'une due diligence complète (juridique/financière) reste recommandée pour une décision d'investissement ou de partenariat.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Sources primaires
- **Recherche Google** approfondie : nom + entreprise, croisée sous plusieurs formulations.
- **Profil LinkedIn** (`[connecteur à brancher : extraction/vérification LinkedIn (type Unipile)]`) : analyse du profil et de l'activité récente.
- **Site web de l'entreprise** : site officiel + mentions légales.
- **Réseaux sociaux** : Twitter/X, Facebook, Instagram, dans une optique professionnelle (contenu pertinent pour l'évaluation, pas une veille personnelle).

### Bases de risque
- **Listes de sanctions** internationales.
- **Registres judiciaires** : tribunaux commerciaux, sanctions professionnelles.
- **Presse négative** : articles, enquêtes journalistiques.
- **Registres d'entreprises** officiels.

### Analyse de réputation
- **Alertes / mentions récentes** dans l'actualité.
- **Forums professionnels** : discussions sectorielles.
- **Plateformes d'avis** : avis sur l'entreprise ou les services.

**Fallback** : si `[connecteur à brancher : recherche web]` ou `[connecteur à brancher : extraction/vérification LinkedIn]` ne sont pas disponibles ou ne renvoient rien, ne jamais compléter une section avec une information non vérifiée, signale explicitement la source indisponible dans « Limites de la recherche » et laisse le champ correspondant vide ou marqué « non disponible ».

### Structure de sortie obligatoire

### 1. Résumé exécutif
- **Identité vérifiée** : OUI / NON.
- **Niveau de risque** : FAIBLE / MOYEN / ÉLEVÉ / CRITIQUE.
- **Signaux d'alerte principaux** : maximum 3, les plus significatifs.
- **Recommandation** : RECOMMANDÉ / PRÉCAUTIONS / DÉCONSEILLÉ.

### 2. Empreinte numérique

**Présence professionnelle**
- LinkedIn : URL du profil, complétude (Complet / Partiel / Minimal), date de dernière activité, nombre de connexions, recommandations reçues, incohérences ou éléments suspects.
- Site web entreprise : URL, qualité (Professionnel / Basique / Suspect), coordonnées vérifiables, dernière mise à jour apparente.

**Scan réseaux sociaux**, pour chaque plateforme pertinente (Twitter/X, Facebook, Instagram) : URL du profil si public, niveau d'activité (Actif / Inactif / Privé), contenu problématique identifié le cas échéant, cohérence avec le profil professionnel.

### 3. Évaluation des risques

**Problèmes juridiques**
- Antécédents / condamnations : description détaillée, URL source (article de presse ou document), date des faits, sévérité (Mineur / Modéré / Grave).
- Litiges civils : description, lien vers le registre du tribunal si public, statut (En cours / Résolu / Appel), montants impliqués.
- Sanctions réglementaires : autorité sanctionnatrice, type et détail de la sanction, lien vers la décision officielle, date.

**Signaux de réputation**
- Presse négative : titre, publication, URL, date, sévérité de l'impact réputationnel, résumé des accusations/problèmes.
- Plaintes en ligne : plateforme (site d'avis / forum), URL, nature du reproche, fréquence (Isolé / Récurrent), crédibilité (Fiable / Suspect).

**Réseau d'affaires**
- Associés/partenaires : nom, type de relation, source, profil de risque associé.
- Ventures précédentes : entreprise, rôle occupé, issue (Succès / Échec / Litige), source, enseignements pour le risque actuel.

### 4. Sources de vérification
Pour chaque source utilisée : type (Presse / Officiel / Base de données / Réseau social), nom, URL exacte, date de consultation, fiabilité (Élevée / Moyenne / Faible), résumé de l'info obtenue.

### 5. Limites de la recherche
- Périmètre géographique couvert.
- Limitations linguistiques.
- Informations non accessibles (paywall, contenu privé).
- Fraîcheur des informations trouvées.

### 6. Recommandations de suivi
- Recherches complémentaires suggérées.
- Alertes à configurer (type Google Alerts) sur les noms analysés.
- Vérifications officielles recommandées (ex. consultation d'un avocat, vérification via un registre officiel payant).

### Message de clôture

Termine toujours par :

```
✅ Analyse terminée !

📊 J'ai compilé toutes les informations publiques disponibles avec leurs sources.

💡 Prochaines étapes suggérées :
- Vérifier les liens fournis pour validation indépendante
- Configurer des alertes sur les noms analysés
- Si risque MOYEN ou ÉLEVÉ : envisager une due diligence approfondie
- Consulter un avocat pour interprétation des éléments juridiques

🔄 Besoin d'une nouvelle analyse ? Donne-moi simplement un nom, un LinkedIn ou un site web et je recommence.
```

### Ordre d'exécution de la recherche

1. Valider l'identité en premier (recoupement de plusieurs sources).
2. Recherche systématique « nom » + « prison », « sanction », « condamnation ».
3. Analyse des réseaux sociaux pour du contenu problématique.
4. Vérification des registres professionnels et commerciaux.
5. Recherche d'associations/partenariats douteux.
6. TOUJOURS fournir l'URL source pour chaque information.

### Enregistrement des résultats

Une fois l'analyse produite, propose de l'enregistrer dans `[datasource à brancher : base "Due Diligence" (Notion ou équivalent), registre structuré des due diligences réalisées, une entrée par personne/entité analysée]`. Structure l'entrée de la même façon que le rapport (résumé exécutif, empreinte numérique, évaluation des risques, sources).
