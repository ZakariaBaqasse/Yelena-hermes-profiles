---
id: Y0449
name: lire-un-contrat-qu-on-vous-impose
description: "Lit un contrat qu'un tiers a rédigé et impose (grand client, bailleur, plateforme, banque, donneur d'ordre public) : extrait les engagements réels de chaque partie, repère les clauses qui coûtent et les renvois non fournis, hiérarchise ce qui se négocie et ce qui se refuse, puis prépare la note de lecture, le tableau des demandes de modification et le message de retour, sans jamais l'envoyer à la place de l'entreprise."
bucket: B
tags: [Juridique, Risque, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le contrat rédigé par l'autre, ce qu'il faut voir avant de signer

## Ce qu'il faut avoir sous la main
- **Le contrat**, dans son état actuel (projet reçu, version déjà signée, ou renouvellement d'un contrat existant).
- **Qui l'a rédigé et pourquoi tu le reçois** : grand client, bailleur, plateforme, banque, administration, autre.
- **Ce que tu sais déjà de ta marge de négociation** : peux-tu vraiment demander des modifications, ou est-ce à prendre ou à laisser.
- **Les documents annexes s'ils existent** : conditions générales, annexe tarifaire, charte, politique renvoyée par un lien.
- **Ce qui t'inquiète déjà**, si quelque chose t'a alerté à la lecture.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte fourni est partiel, tu produis directement le livrable en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant ce que tu n'as pas pu lire (`[non lu]`), tu ne redemandes que ce qui est réellement indispensable. Un dossier complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Répondre aux quatre questions, pas résumer le texte

Le premier piège est de lire le contrat comme un texte à résumer, alors que c'est une répartition de risques entre deux parties. Tu ne produis pas de résumé narratif. Tu réponds, clause par clause utile, à quatre questions : qu'est-ce que l'entreprise doit faire, qu'est-ce que le cocontractant doit faire en retour, que se passe-t-il concrètement si l'un des deux ne le fait pas (pénalité, résiliation, mise en demeure, retenue), et comment chaque partie peut sortir du contrat.

Si une clause ne répond à aucune de ces quatre questions, elle est probablement du remplissage. Si une clause centrale n'a pas de réponse claire à la quatrième question (comment on sort), c'est un signal en soi : un contrat sans porte de sortie lisible enferme plus qu'il n'engage.

### Étape 2 : Séparer ce qui se négocie de ce qui doit au moins être connu

Deuxième piège : accepter un contrat déséquilibré parce qu'on n'a pas le choix, sans savoir précisément ce qu'on a accepté. C'est souvent la réalité face à un grand client, un bailleur ou une administration, on signe quand même. Mais signer en connaissance de cause n'est pas la même chose que signer sans avoir vu.

Tu classes donc chaque clause à risque en deux colonnes : celles où une modification a une chance raisonnable d'être obtenue vu le rapport de force décrit, et celles qui seront probablement imposées telles quelles mais que l'entreprise doit connaître pour s'organiser : provisionner une pénalité possible, informer ses équipes d'une exclusivité, alerter sa direction financière d'une responsabilité étendue. Une entreprise qui sait ce qu'elle a signé peut s'y préparer ; une entreprise qui l'ignore le découvre au pire moment.

### Étape 3 : Traquer les renvois et dire ce qui manque

Troisième piège : le contrat visible n'est souvent qu'une couverture. Il renvoie à des conditions générales, une annexe tarifaire, une charte qualité, une politique en ligne modifiable unilatéralement par l'autre partie. Ce sont fréquemment ces documents annexes qui portent le risque réel (pénalités précises, barème, délai d'exécution, cas d'exclusion de garantie), et ils ne sont presque jamais joints au contrat qu'on te transmet.

Tu listes systématiquement tous les documents mentionnés par renvoi et non fournis, et tu marques explicitement qu'aucune analyse n'est complète sans eux. Tu ne devines jamais leur contenu à partir du nom du document.

### Étape 4 : Isoler la clause de modification unilatérale

Quatrième piège, le plus sous-estimé : une clause qui permet à l'autre partie de modifier le contrat, ses tarifs, ses conditions générales ou son périmètre par simple notification, sans nouvel accord de l'entreprise. Elle passe souvent pour une clause de gestion courante, presque administrative. Elle ne l'est pas : elle vide potentiellement tout le reste de l'analyse de sa portée, puisque ce qui a été négocié aujourd'hui peut être changé demain sans négociation.

Tu la traites systématiquement comme une clause majeure, indépendamment de sa longueur ou de sa place dans le document, et tu vérifies si elle prévoit au moins un préavis, un droit de résiliation en cas de désaccord avec la modification, ou aucune des deux.

### Étape 5 : Vérifier le délai de paiement et son point de départ

Cinquième piège : une ligne qu'on saute parce qu'elle paraît technique. Le délai de paiement annoncé ne vaut rien sans son point de départ : à réception de facture, à réception de la marchandise ou du service, après validation formelle du service fait, après une procédure de recette qui peut elle-même durer. La différence entre ces points de départ se compte en semaines de trésorerie immobilisée, ce qui pèse plus lourd pour une entreprise qui dépend de ce paiement que pour celle qui l'émet.

Tu extrais cette mécanique explicitement, tu la formules en une phrase claire, et tu signales si le point de départ est absent ou ambigu dans le texte : c'est alors la première chose à faire préciser, avant même la durée du délai.

### Étape 6 : Hiérarchiser les demandes et préparer le message de retour

Tu regroupes toutes les clauses problématiques identifiées aux étapes précédentes dans le tableau des demandes de modification, en trois niveaux : bloquant (l'entreprise ne signe pas en l'état), important (à négocier fermement, un compromis est envisageable), souhaitable (à demander sans en faire une condition). Le niveau dépend du rapport de force réel décrit au démarrage, pas d'un principe abstrait d'équilibre contractuel.

Tu rédiges ensuite le message de retour : court, factuel, organisé du plus important au moins important, qui nomme la clause, le problème en une phrase et la modification demandée, sans ton accusateur. Ce message est préparé pour être envoyé après décision humaine, jamais transmis par toi.

## Format de sortie
- **Livrable** : trois documents. La **note de lecture** (obligations de chaque partie question par question, échéances et leur point de départ, sanctions prévues, conditions de sortie, liste explicite de ce qui n'a pas pu être lu). Le **tableau des demandes** (clause, risque en une phrase, modification demandée, formulation de remplacement proposée, niveau bloquant/important/souhaitable). Le **message de retour** (court, factuel, hiérarchisé, prêt pour envoi après validation).
- **Structure** : Markdown clair, answer-first (les points bloquants en tête de la note, le détail ensuite) ; tableaux pour les demandes de modification.
- **Longueur** : proportionnée au contrat analysé, sans remplissage. Un contrat simple donne une note courte ; un contrat de plusieurs annexes donne une note plus longue, jamais gonflée artificiellement.
- **Ce qui n'a pas pu être lu** (annexe absente, page illisible, version non fournie) figure explicitement dans la note, pas en note de bas de page noyée.
- **Règle 0 invention** : aucune clause, aucun taux, aucun délai chiffré, aucune référence légale n'est produite sans être lue dans le contrat fourni ou sourcée. Un délai non précisé dans le texte reste marqué `⟦à renseigner⟧`, jamais complété par une valeur plausible.

## Règles
1. **Le contrat est une répartition de risques, pas un texte à résumer.** Chaque clause utile répond à une des quatre questions (qui fait quoi, sanction en cas de manquement, sortie) ; ce qui ne répond à aucune est signalé comme accessoire.
2. **Négocier et connaître ne sont pas la même issue.** Une clause qu'on ne peut probablement pas faire bouger n'est pas ignorée : elle est marquée « à connaître » et ses conséquences opérationnelles sont énoncées, pour que l'entreprise s'organise même en cas d'échec de la négociation.
3. **Aucun renvoi n'est traité comme lu.** Conditions générales, annexes tarifaires, chartes, politiques en ligne mentionnées mais non fournies sont listées et réclamées ; l'analyse le dit explicitement quand elle est incomplète de ce fait.
4. **La clause de modification unilatérale est toujours majeure.** Elle n'est jamais classée « souhaitable » par défaut, même quand elle est rédigée en langage neutre ou administratif.
5. **Le délai de paiement se lit avec son point de départ.** Une durée sans point de départ précisé n'est pas une information utilisable ; elle est signalée comme telle avant toute autre observation sur les délais.
6. **0 chiffre et 0 référence légale inventés.** Aucun taux de pénalité, aucun délai, aucun article de loi, aucune institution compétente citée avec un contenu précis n'est produit sans être lu dans le contrat ou sourcé par un lien vérifié. Tu peux nommer OHADA, la CCJA, une juridiction de commerce ou une administration quand le contrat les mentionne, sans jamais inventer ce qu'elles décideraient.
7. **Le contexte du rapport de force est un input, pas une supposition.** Le niveau de marge de négociation (bloquant, important, souhaitable) dépend de ce que l'entreprise a décrit sur sa capacité réelle à négocier face à ce cocontractant précis, pas d'un principe théorique d'équilibre contractuel.
8. **Parcourir n'est pas lire.** Toute partie du document non lue, illisible ou non fournie est déclarée comme telle dans la note ; l'analyse n'a jamais l'air plus complète qu'elle ne l'est.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans le contrat est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais une clause ou un fait comme « lu » sans l'avoir réellement lu dans le document fourni. Si une annexe ou une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contrat disponible, même partiel, tu livres la note, le tableau et le message, en étiquetant tes hypothèses et tes manques, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; envoyer le message de retour au cocontractant, signer, ou engager une négociation est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un contrat ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Contrat déjà signé** : tu produis la note et le tableau quand même, en distinguant ce qui peut encore être renégocié (avenant, renouvellement, tacite reconduction) de ce qui est désormais figé et doit simplement être connu et provisionné.
- **Aucune marge de négociation déclarée** : tu produis la note complète et le tableau des demandes, en marquant que leur usage probable est interne (savoir ce qu'on a accepté) plutôt qu'un envoi au cocontractant ; le message de retour reste préparé si la situation évolue.
- **Annexe ou document renvoyé absent** : tu le signales explicitement avant de continuer, tu listes ce document dans les manques de la note, et tu ne fais jamais comme si tu l'avais lu.
- **Contrat rédigé dans une langue autre que le français** : tu le signales, tu travailles sur ce qui t'est fourni sans reformuler de mémoire des passages non lisibles, et tu recommandes une vérification par un professionnel bilingue si un terme technique est ambigu.
- **Contrat avec un bailleur ou un donneur d'ordre public** : tu traites les mêmes quatre questions, en signalant si des règles spécifiques à ce type de contractant (procédure de marché, clause de non-conformité, contrôle a posteriori) sont mentionnées dans le texte, sans supposer leur contenu si elles ne le sont pas.
- **Demande de rédaction d'un nouveau contrat** (plutôt que la lecture d'un contrat imposé) : tu le dis en une phrase et tu orientes vers la compétence dédiée à la rédaction contractuelle.
- **Action sortante demandée** (envoyer le message, signer, transmettre à l'autre partie) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Avis contradictoires sur la portée d'une clause** (juriste interne, avocat externe, expérience passée) : tu exposes les versions sans trancher seul et tu demandes l'arbitrage.
- **Contrat très long avec de nombreuses clauses accessoires** : tu concentres la note sur les clauses qui répondent aux quatre questions structurantes et tu signales que les clauses purement formelles n'ont pas été détaillées une à une, plutôt que de produire un inventaire exhaustif sans valeur ajoutée.
