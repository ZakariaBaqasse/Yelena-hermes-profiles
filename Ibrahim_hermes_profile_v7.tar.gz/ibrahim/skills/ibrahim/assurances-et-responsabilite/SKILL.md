---
id: Y0452
name: assurances-et-responsabilite
description: "Cartographie les risques réels d'une entreprise (locaux, stock, transport, véhicules, responsabilité civile, produit, accidents du travail, perte d'exploitation) et les confronte à ce que les polices existantes couvrent réellement : exclusions, franchises, plafonds, conditions de garantie. Produit la carte des risques et couvertures, la fiche de sinistre prête à l'emploi, et la liste des trous classés par gravité, sans jamais recommander un produit d'assurance ni citer un tarif ou un plafond inventé."
bucket: B
tags: [Juridique, Risque, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# Ce qui est assuré, ce qui ne l'est pas, et ce qu'on fait quand ça arrive

## Ce qu'il faut avoir sous la main
- **L'activité** : ce que tu fais, où (locaux, entrepôts, points de vente), ce que tu transportes ou stockes, combien de personnes tu emploies.
- **Les polices existantes** : copie des contrats, ou au moins leurs titres et montants de prime, si tu les as.
- **Ce qui t'inquiète le plus** : incendie, vol, accident de véhicule, client blessé par un produit, accident de travail, autre.
- **Un événement déjà vécu**, même mineur (petit dégât, accident, vol), et comment ça s'est passé avec l'assureur, si applicable.
- **Le pays et la ville** d'exploitation.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les franchises, plafonds et délais non fournis `⟦à renseigner⟧`. Tu ne redemandes que ce qui est réellement indispensable.

## Process
### Étape 1 : Cartographier les risques réels, avant de lire un seul contrat

Liste les risques concrets de l'activité, indépendamment de ce qui est assuré : dommages aux locaux et à leur contenu, perte ou dégradation des marchandises en stock, perte ou dégradation en transport, accident impliquant un véhicule de l'entreprise, dommage causé à un tiers par l'activité ou par un produit vendu, accident touchant un salarié, interruption de l'activité elle-même (perte d'exploitation).

Pour chaque risque, écris la **conséquence réaliste** si l'événement survient : ce que ça coûte, combien de temps ça immobilise, qui est affecté. Un risque sans conséquence chiffrable reste qualitatif, ce n'est pas un défaut : `⟦à renseigner⟧` plutôt qu'un ordre de grandeur inventé.

C'est cette carte, construite sans regarder les polices, qui sert de référence à l'étape 3. Si tu commences par les contrats, tu risques de ne voir que ce qu'ils couvrent et de rater ce qu'ils oublient.

### Étape 2 : Lire chaque police par ses exclusions, pas par son titre

Pour chaque contrat fourni, extrais : ce qui est nommément exclu, la franchise par sinistre `⟦à renseigner⟧`, le plafond d'indemnisation `⟦à renseigner⟧`, et surtout les **conditions de garantie** : équipement à posséder (extincteurs, alarme, gardiennage), usage déclaré du local ou du véhicule, valeur déclarée à la souscription, obligation de déclaration dans un délai `⟦à renseigner⟧`.

Ces conditions sont le point où une police tombe sans que personne s'en aperçoive avant le sinistre : un extincteur absent, un usage professionnel non déclaré sur un contrat de véhicule particulier, un stockage de produits inflammables jamais signalé. Signale chaque condition non vérifiable avec les informations données, marquée `[à confirmer]`.

Si aucun contrat n'est fourni, tu construis la carte de l'étape 3 avec une colonne « couverture » entièrement vide et documentée comme telle : c'est un résultat, pas un blocage.

### Étape 3 : Confronter la carte des risques à la carte des couvertures

Pour chaque risque de l'étape 1, indique s'il est couvert, partiellement couvert (avec la limite précise) ou non couvert du tout. C'est ici qu'apparaissent les trous : un risque réel de l'activité qui n'a aucune police en face.

Classe l'état de conformité pour chaque condition de garantie repérée à l'étape 2 : respectée, non respectée, à vérifier. Une condition non respectée annule la couverture au moment précis où elle servirait, ce n'est pas une nuance administrative.

### Étape 4 : Vérifier la valeur déclarée et l'usage réel, pas ceux d'hier

Deux dérives silencieuses ruinent une couverture qui semblait correcte à la souscription. La valeur assurée du stock ou du local a été fixée un jour donné : si le stock a doublé depuis ou que des travaux ont augmenté la valeur du local, l'indemnité sera réduite en proportion de l'écart, même si la prime a continué d'être payée sans réajustement. Fais vérifier la date de la dernière déclaration de valeur et signale si elle date de plus d'un exercice.

L'usage déclaré du local ou du véhicule peut aussi avoir dérivé sans que personne y pense : un local déclaré « bureau » qui sert désormais d'entrepôt, un véhicule déclaré « usage privé » qui roule chaque jour pour l'entreprise. Note que dans un contexte où une partie des fournisseurs et des clients reste informelle, prouver la valeur réelle du stock (factures manquantes ou informelles) peut compliquer la déclaration de valeur autant que l'indemnisation en cas de sinistre : signale ce point comme un risque en soi, pas comme un détail comptable.

### Étape 5 : Préparer la fiche de sinistre avant qu'elle ne serve

Une déclaration tardive ou incomplète fait tomber une garantie qui aurait pu jouer. La fiche se prépare à froid, pas le jour de l'incendie. Elle contient : les gestes des premières heures (mise en sécurité, préservation des preuves avant tout nettoyage), qui prévenir en interne et à quel moment, le délai de déclaration à l'assureur `⟦à renseigner⟧` (il est dans le contrat, pas dans un usage), les pièces à réunir (photos horodatées, témoignages, rapport de police si pertinent, factures ou preuves de valeur du bien touché).

Note un point pratique local : les photos et vidéos prises au téléphone et partagées immédiatement par WhatsApp aux personnes concernées (dirigeant, courtier, expert) constituent souvent la première preuve exploitable, surtout quand un expert ne peut se déplacer rapidement en raison des distances et des embouteillages, à Abidjan en particulier. Le premier geste utile est de documenter avant de faire intervenir qui que ce soit.

Distingue clairement, dans la fiche, l'accident touchant un salarié : la déclaration à la CNPS (qui a la charge de la prise en charge des accidents du travail et de la maladie professionnelle) suit une logique et un circuit propres, distincts de la déclaration à l'assureur privé de responsabilité civile employeur, si elle existe. Les deux démarches se mènent en parallèle, pas l'une à la place de l'autre.

### Étape 6 : Séparer assurance et continuité d'activité, puis rendre la liste des trous

Une assurance indemnise après le fait accompli, elle ne maintient pas les clients servis ni les salariés payés le temps que l'activité reparte. Si l'entreprise n'a rien prévu pour continuer à livrer, à facturer ou à payer ses charges pendant l'interruption, c'est un trou de résilience distinct d'un trou de couverture, et il se nomme séparément dans le livrable : perte d'exploitation assurée ou non, et plan de continuité existant ou non.

Termine par la **liste des trous**, classée par gravité : ce qui n'est couvert par rien face à un risque à conséquence lourde en tête, ce qui est couvert mais avec une condition de garantie non respectée juste après, ce qui est simplement à vérifier en dernier. Pour chaque trou, tu décris le risque et son absence de couverture, tu ne proposes jamais le produit qui le comblerait : ce choix revient au courtier ou à l'assureur consulté par l'entreprise.

## Format de sortie
- **Livrable 1, carte des risques et couvertures** : tableau risque / conséquence réaliste / police concernée ou absence / franchise `⟦à renseigner⟧` / plafond `⟦à renseigner⟧` / conditions de garantie / état de conformité.
- **Livrable 2, fiche de sinistre** : gestes des premières heures, personnes à prévenir et ordre, délai de déclaration `⟦à renseigner⟧`, pièces à réunir, circuit spécifique si accident de travail (CNPS).
- **Livrable 3, liste des trous** : classée par gravité, un trou par ligne, risque et absence de couverture, sans produit recommandé en face.
- **Structure** : Markdown, answer-first (les trous les plus graves d'abord), tableaux pour la carte et la fiche.
- **Longueur** : proportionnée au nombre de risques et de polices fournis, sans remplissage.
- **Règle 0 invention** : aucune franchise, aucun plafond, aucun délai, aucun taux de prime n'est produit sans être fourni ou lu dans un contrat transmis : `⟦à renseigner⟧` sinon.

## Règles
1. **Le titre d'une police n'est pas sa couverture.** Tu lis systématiquement les exclusions, la franchise, le plafond et les conditions de garantie avant de conclure qu'un risque est couvert.
2. **0 chiffre inventé.** Aucune franchise, aucun plafond, aucune prime, aucun délai de déclaration n'est produit sans être fourni ou lu dans une source réelle : `⟦à renseigner⟧` sinon, y compris pour les ordres de grandeur qualifiés de « courants dans le secteur ».
3. **La valeur assurée se vérifie à date, pas à la souscription.** Tu signales toujours si la dernière mise à jour de la valeur déclarée dépasse un exercice.
4. **La fiche de sinistre se prépare avant l'incident.** Tu ne renvoies jamais sa préparation au jour où l'événement survient.
5. **Assurance et continuité d'activité sont deux sujets distincts.** Tu ne présentes jamais une couverture de perte d'exploitation comme un substitut à un plan de continuité opérationnelle.
6. **Tu ne recommandes aucun produit, aucun assureur, aucun courtier.** Tu décris le risque et le trou, tu orientes vers le professionnel qualifié pour le combler.
7. **Le contexte local n'est pas un décor.** Informalité d'une partie des fournisseurs et clients (preuve de valeur du stock), distances et embouteillages (délai d'intervention d'un expert), circuit CNPS distinct de l'assureur privé pour les accidents de travail : tu les nommes quand ils changent la réponse, pas par principe.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter un assureur, déclarer un sinistre ou souscrire une police est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les franchises, plafonds et délais non fournis `⟦à renseigner⟧`.
- **Aucune police fournie** : tu produis quand même la carte des risques et la fiche de sinistre générique, avec une colonne « couverture » entièrement vide et documentée comme telle, et tu le dis explicitement : sans contrat lu, aucune couverture ne peut être confirmée.
- **Police annoncée mais non transmise** (« voici mes contrats », rien n'est joint) : tu le signales avant de continuer, tu ne fais pas comme si tu l'avais lue.
- **Donnée introuvable dans le contrat** (franchise illisible, clause ambiguë) : tu le dis explicitement, tu marques `[à confirmer]`, tu ne devines pas la clause à sa place.
- **Sinistre déjà survenu** : tu bascules sur la fiche de sinistre en priorité, tu notes ce qui a déjà été fait ou manqué, et tu signales si un délai de déclaration semble dépassé sans te prononcer sur la conséquence juridique exacte.
- **Demande de recommandation de produit ou d'assureur** : tu le refuses, tu expliques pourquoi (hors périmètre et hors responsabilité de la compétence), tu orientes vers un courtier ou un assureur.
- **Demande hors périmètre** (calcul de prime, négociation de contrat, contentieux en cours) : tu le dis en une phrase, tu traites ce qui relève de ton champ, tu orientes vers la compétence ou le professionnel qui convient.
- **Action sortante demandée** (déclarer un sinistre, souscrire, résilier) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions d'un même contrat, avenant non pris en compte) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
