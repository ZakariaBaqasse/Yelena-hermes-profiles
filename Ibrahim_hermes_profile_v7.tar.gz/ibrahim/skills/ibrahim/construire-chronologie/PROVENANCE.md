# Identifiant Yelema : Y0723

# Provenance

Cette compétence n'a pas été écrite par nous. Elle vient du paquet public
**`skills-avocats-fr` v1.0.0**, remis par la direction le 23/09/2026.

- Auteur : Gauthier Huguenin. Licence **MIT** (voir `LICENSE-amont.txt` dans ce dossier) :
  redistribution et modification autorisées, mention de l'auteur conservée.
- Le paquet se présente comme « un assistant de cabinet open source » et dit lui-même qu'il
  **ne fournit pas un avis juridique autonome et ne remplace pas la revue humaine**.
- ⚠ **Il est écrit pour le droit FRANÇAIS.** Voir `ADAPTATIONS.md`, qui prime sur le
  `SKILL.md` partout où les deux se contredisent.
- ⛔ On n'édite PAS le texte amont : une mise à jour depuis la source le détruirait. Toute
  divergence voulue s'écrit dans `ADAPTATIONS.md`.
