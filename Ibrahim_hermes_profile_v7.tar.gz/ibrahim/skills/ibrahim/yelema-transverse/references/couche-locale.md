# Couche locale : Ibrahim · Juridique et conformité

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-IBRAHIM-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Source identifiée, note encore à fabriquer. Le relevé du gouvernement de 2026 existe sur la machine (memory/reference/gouvernement-2026.md chez LOKOLI) et sert de base. Pour un poste juridique, la note utile n'est pas la liste des ministres mais la chaîne qui décide d'un texte : Assemblée nationale et Sénat pour la loi, Président pour l'ordonnance, Secrétariat général du Gouvernement pour la publication au Journal officiel, juridictions pour l'application. POINT DUR À PORTER : le Journal officiel n'est PAS en accès libre en ligne ; le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66). Toute date de publication citée sans avoir ouvert le JO est une date de seconde main, et doit être annoncée comme telle. Écart tranché le 18/09 : décret n°2026-05/2 du 07/01/2026, publié au Journal officiel n°5 (Spécial) du 17/02/2026, il ne reste que DEUX districts autonomes, Abidjan et Yamoussoukro.

### CL-IBRAHIM-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-IBRAHIM-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-IBRAHIM-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-IBRAHIM-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-IBRAHIM-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || FAIT LE 18/09 : les dix actes uniformes sont sur la machine, en PDF et en texte, dans ~/.claude/outils-communs/ohada/ avec une fiche LISEZ-MOI. Ce ne sont pas des textes étrangers : la Côte d'Ivoire est État partie au traité OHADA, ces actes y sont directement applicables et priment sur le droit interne contraire. CEUX QUI TOUCHENT LE MÉTIER JURIDIQUE, dans l'ordre d'usage réel : AUDCG (droit commercial général, adopté le 15/12/2010 à Lomé, 307 articles) pour le statut du commerçant et de l'entreprenant, le RCCM, le bail à usage professionnel, le fonds de commerce, la vente commerciale et la prescription ; AUSCGIE (sociétés commerciales et GIE, 30/01/2014 à Ouagadougou, 920 articles) pour les statuts, la gouvernance, les cessions de parts et la dissolution ; AUS (sûretés, 15/12/2010, 228 articles) pour le cautionnement, le gage, le nantissement, l'hypothèque et la réserve de propriété ; AUPSRVE (procédures simplifiées de recouvrement et voies d'exécution, 2023, Journal officiel OHADA spécial du 15/11/2023, 338 articles) pour l'injonction de payer et les saisies ; AUPCAP (procédures collectives, 10/09/2015 à Grand-Bassam, 258 articles) pour l'entreprise en difficulté ; AUA et AUM (arbitrage et médiation, 23/11/2017 à Conakry, 36 et 17 articles) pour les clauses de règlement des litiges. S'y ajoutent AUDCIF (comptable), AUSCOOP (coopératives) et AUCTMR (transport routier de marchandises).

### CL-IBRAHIM-11 · Les actes uniformes OHADA, article par article utile
- **Pourquoi** : Citer un texte de mémoire est une faute qui se voit
- **Où chercher** : OHADA, textes officiels
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OHADA complète sur disque : les DIX actes uniformes en PDF et en .txt cherchable (AUDCG-2010 307 art., AUSCGIE-2014 920, AUSCOOP-2010 397, AUS-2010 228, AUPSRVE-2023 338, AUPCAP-2015 258, AUDCIF-2017 113, AUA-2017 36, AUM-2017 17, AUCTMR-2003 31), plus l'AUDCIF tel que publié au Journal officiel. Ces actes sont DIRECTEMENT applicables en Côte d'Ivoire et priment sur le droit interne contraire. ⛔ Citer par l'article, jamais de mémoire. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches. || FAIT LE 18/09, c'est la même base que la ligne 06 mais l'exigence est différente : ici il s'agit de CITER, et une citation se prend sur le texte. Les dix actes sont en PDF (la pièce) et en .txt (pour chercher) dans ~/.claude/outils-communs/ohada/. TROIS PIÈGES D'EXTRACTION, écrits dans le LISEZ-MOI, à connaître avant de conclure qu'un texte est muet. (1) AUSCGIE-2014.txt est SANS ACCENTS, c'est une reconnaissance sans diacritiques : chercher societe et non société, sinon on ne trouve rien. (2) AUS-2010.txt numérote en Art.1.- et non Article 1 : une recherche sur Article 42 n'y rend rien alors que l'article existe. (3) AUDCIF-2017.txt est une saisie retapée, propre et complète, mais porteuse de coquilles (nonnes IFRS pour normes IFRS) : pour citer, ouvrir AUDCIF-2017-JO-officiel.pdf, qui est la publication authentique au Journal officiel du 15/02/2017. Les huit autres se cherchent en clair. CE QUI MANQUE : le traité OHADA lui-même, les annexes de l'AUDCIF (plan comptable général et dispositif des comptes consolidés, soit l'essentiel des 1 200 pages du numéro spécial), l'acte SYCEBNL de 2022 sur les entités à but non lucratif, et la jurisprudence de la CCJA qui tranche l'interprétation.

## Langue

### CL-IBRAHIM-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || CORRIGÉ LE 18/09 : le socle affirmait que la compétence parler-ivoirien était déjà liée à ce poste. C'ÉTAIT FAUX — elle l'était chez KOUASSI, d'où le socle a été repris, et elle manquait sur SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis le 18/09, version du catalogue vérifiée neutre. ⚠ LA LEÇON : un socle transverse porte la réponse du poste SOURCE, pas celle du poste cible. Une affirmation du type « déjà chez lui » doit se vérifier poste par poste avant d'être propagée. Ce que sert ce corpus : la règle de registre (le premier contact reste formel ici, on vouvoie, l'urgence fabriquée est mal vue) autant que le lexique.

## Canaux

### CL-IBRAHIM-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : les risques déclarés (piratage de compte vécu par 40 %, escroquerie 48 %) sont la matière des clauses de responsabilité d'un contrat numérique.

## Droit social

### CL-IBRAHIM-12 · Code du travail ivoirien et conventions collectives par branche
- **Pourquoi** : Une clause contraire à la convention de branche est nulle
- **Où chercher** : Journal officiel, conventions collectives
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base droit du travail sur disque : Code du travail loi 2015-532, ordonnance 2021-902 qui le modifie, convention interprofessionnelle de 1977, taux de cotisation CNPS, et JOURS-FERIES.md. ⛔ UNE DIVERGENCE À NE PAS LISSER, écrite dans le LISEZ-MOI : les deux textes ne donnent pas le même seuil de bascule des heures supplémentaires. ⚠ L'extraction texte de l'ordonnance 2021-902 est vide, c'est un document numérisé : on la cite depuis le PDF. ⛔ LES CONVENTIONS COLLECTIVES PAR BRANCHE NE SONT PAS DANS LA BASE : seule l'interprofessionnelle de 1977 y est. La partie « par branche » de cette ligne reste ouverte. || DÉJÀ SUR LA MACHINE depuis le 17/09 : ~/.claude/outils-communs/droit-travail-ci/ porte la loi 2015-532 du 20/07/2015 portant Code du travail, l'ordonnance 2021-902 du 22/12/2021 qui la modifie, et la convention interprofessionnelle du 19/07/1977. TROIS CHOSES À NE PAS RATER POUR RÉDIGER UNE CLAUSE. (1) LE CODE SEUL N'EST PAS À JOUR : l'ordonnance de 2021 modifie les articles 13.3, 16.6, 16.11, 18.11, 18.14, 23.1, 23.13, 25.2 et 73.2, et son extraction texte est dégradée, c'est un scan : pour citer un article modifié, ouvrir le PDF. (2) LA CONVENTION DE 1977 A ÉTÉ CONCLUE SOUS LE CODE DE 1964 et son articulation avec celui de 2015 n'est pas tranchée ; elle ne régit pas tous les établissements, ce qui se vérifie avant d'en tirer une règle opposable. (3) UNE DIVERGENCE À NE PAS LISSER sur les heures supplémentaires : le Code majore de 15 % de la 41e à la 46e heure puis 50 % au-delà, la convention (art. 51) de 15 % jusqu'à la 48e. Les heures 47 et 48 sont donc à 50 % d'un côté et à 15 % de l'autre. Les taux du Code sont des planchers. CE QUI MANQUE, et c'est exactement ce que demande l'intitulé de cette ligne : LES CONVENTIONS COLLECTIVES DE BRANCHE. Seule l'interprofessionnelle est sur la machine. Une clause contraire à une convention de branche est nulle, et nous ne pouvons pas vérifier aujourd'hui ce que dit la branche du client.

## Données

### CL-IBRAHIM-13 · Protection des données personnelles en Côte d'Ivoire
- **Pourquoi** : Traiter des données sans base légale expose le client
- **Où chercher** : ARTCI, textes sur la protection des données
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base données personnelles sur disque : loi n° 2013-450 du 19/06/2013 telle que publiée au Journal officiel du 08/08/2013 (p. 474 à 482), plus une seconde numérisation, la loi 2013-451 cybercriminalité et la loi 2013-546 transactions électroniques. La compétence donnees-personnelles-ci (Y0676) en est le mode d'emploi. ⛔ CES PDF N'ONT PAS DE COUCHE TEXTE : ce sont des numérisations du JO, il faut les LIRE, l'extraction ne rend rien. || FAIT LE 18/09, texte lu article par article. ~/.claude/outils-communs/donnees-personnelles-ci/ porte la loi n°2013-450 du 19/06/2013 (Journal officiel du 08/08/2013, p. 474 à 482), la loi 2013-451 sur la cybercriminalité et la loi 2013-546 sur les transactions électroniques. ⛔ CES FICHIERS SONT DES SCANS SANS COUCHE TEXTE : aucune recherche plein texte n'y fonctionne, on les ouvre et on les lit ; la correspondance article vers page est dans la fiche de la compétence. COMPÉTENCE ÉCRITE LE 18/09 : donnees-personnelles-ci (Y0676), au catalogue et liée à ce poste, écrite plutôt que de modifier rgpd-data-protection qu'une mise à jour écraserait. CE QUE LE RÉGIME IVOIRIEN A DE DIFFÉRENT DU RGPD, et qui change le conseil : (1) il y a une FORMALITÉ PRÉALABLE que le RGPD a supprimée, déclaration de principe (art. 5), autorisation pour six catégories (art. 7) dont le traitement portant sur un NUMÉRO DE TÉLÉPHONE et tout transfert hors du pays ; (2) L'ABSENCE DE RÉPONSE DE L'ARTCI DANS LE DÉLAI D'UN MOIS, PROROGEABLE D'UN MOIS, VAUT REJET et non acceptation (art. 11) ; (3) la PROSPECTION sans consentement préalable est punie d'un an d'emprisonnement et de 1 à 10 millions FCFA (art. 22) ; (4) le transfert hors de Côte d'Ivoire suppose un pays au niveau de protection suffisant ET l'autorisation préalable de l'ARTCI (art. 26). L'autorité de protection EST l'ARTCI (art. 46), il n'existe pas d'autorité distincte. Sanctions : jusqu'à 10 millions FCFA, 100 millions en récidive dans les cinq ans ou 5 % du chiffre d'affaires hors taxes dans la limite de 500 millions (art. 51). CE QUI MANQUE : les décrets d'application et les délibérations de l'ARTCI, qui fixent le détail des procédures, les durées de conservation par finalité et les conditions du transfert transfrontalier.

## Contrats

### CL-IBRAHIM-14 · Les clauses qui tiennent ici, et celles qui ne tiennent pas
- **Pourquoi** : Recopier un contrat européen
- **Où chercher** : Jurisprudence locale, cabinets de la place
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE, et c'est la ligne la plus difficile de l'onglet. Ce qu'elle demande, ce sont des clauses validées ou censurées par des juges d'ici : cela suppose la JURISPRUDENCE DE LA CCJA et des juridictions ivoiriennes, qui n'est pas sur la machine et dont aucune source gratuite exploitable n'a été trouvée le 18/09. Ce qu'on peut faire sans elle, et qui n'est pas rien : vérifier qu'une clause n'est pas contraire à une disposition d'ordre public des actes uniformes, désormais consultables. Ce qu'on ne peut PAS faire : affirmer qu'une clause tient. Tant que cette ligne est à Non, toute note sur la validité d'une clause porte la réserve, et la vérification finale revient à un avocat de la place.

## Procédure

### CL-IBRAHIM-15 · Les juridictions compétentes et les délais de recours
- **Pourquoi** : Conseiller un recours hors délai
- **Où chercher** : Textes de procédure, tribunal de commerce d'Abidjan
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Code de procédure civile, commerciale et administrative (loi n° 72-833 du 21/12/1972, texte consolidé, 179 pages), le Journal officiel n° 11 spécial du 17/07/2019 portant l'ordonnance n° 2019-586, et la loi 2019-988 qui la ratifie. Motif de la base : les actes uniformes OHADA disent le droit, mais on va en justice selon la procédure ivoirienne. Citer l'AUPSRVE sans savoir devant quelle juridiction et sous quel délai, c'est un conseil qui s'arrête au milieu. ℹ africanlii.org répond 403 et le Centre national de documentation juridique n'y est plus joignable. || FAIT LE 18/09 : ~/.claude/outils-communs/procedure-civile-ci/ porte la loi n°72-833 du 21/12/1972 portant Code de procédure civile, commerciale et administrative en texte consolidé (179 pages), le Journal officiel n°11 spécial du 17/07/2019 avec l'ordonnance n°2019-586 du 03/07/2019, et la loi n°2019-988 du 27/11/2019 qui la ratifie. ⛔ LE PIÈGE DE CE CODE, écrit dans le LISEZ-MOI : le corps du code est le texte de 1972, et LES MODIFICATIONS VIVENT À LA FIN, séparément, sous TEXTES MODIFICATIFS, en ARTICLE N NOUVEAU. Un article lu au fil du corps peut avoir été remplacé cent pages plus loin. Le geste est en deux temps, sans exception. L'ordonnance de 2019 remplace DOUZE articles : 20, 76, 126, 130, 158, 172, 207, 208, 213, 214, 219 et 222, relevé fait sur le Journal officiel et non sur un commentaire. Repère de compétence tiré de la loi 93-670 (article 6 nouveau) : premier et dernier ressort jusqu'à 500 000 francs en matière civile et commerciale, premier ressort au-delà, ainsi qu'en matière d'état des personnes et de mise en cause d'une personne publique ; ⚠ ce seuil est de 1993 et se revérifie avant d'être servi. À NE PAS CONFONDRE : le recouvrement et les saisies relèvent de l'AUPSRVE, pas de ce code. CE QUI MANQUE : la loi sur l'organisation judiciaire, donc le ressort exact des tribunaux de commerce, le tarif des actes, et toute modification postérieure à 2019.

## Fiscalité

### CL-IBRAHIM-16 · Ce qui relève du fiscal et ce qui relève du juridique
- **Pourquoi** : Empiéter sur le terrain du comptable sans le dire
- **Où chercher** : Direction générale des impôts
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base fiscale sur disque : Code général des impôts édition 2025 de la DGI (9 762 paragraphes), annexe fiscale à la loi de finances 2025-987 du 19/12/2025 pour le budget 2026 (41 mesures), et deux synthèses DGI. ⚠ Chercher dans cgi-2025-recolle.txt (césures de colonnes recollées), citer depuis cgi-2025.txt. TVA 18 %, taux réduit 9 %. || FAIT LE 18/09 : ~/.claude/outils-communs/fiscalite-ci/ porte le Code général des Impôts, édition 2025 des Publications de la DGI, avec le Livre de Procédures fiscales, le Code des Investissements, le Code pétrolier, le Code minier et les actes communautaires, plus l'annexe fiscale 2026 (loi de finances n°2025-987 du 19/12/2025). LA FRONTIÈRE, pour ce poste : le juridique dit la forme et l'engagement, le fiscal dit ce que l'opération coûte. Trois endroits où elles se touchent et où l'on empiète sans s'en rendre compte. (1) Le choix de la forme sociale, qui est de l'AUSCGIE, a un effet fiscal immédiat : impôt sur les bénéfices à 25 % pour les personnes morales et physiques, 30 % pour les télécommunications et les TIC (art. 51 du CGI), contre le régime des microentreprises à 6 % (art. 71 bis à 71 quater) ou la taxe d'État de l'entreprenant à 5 %, ramenée à 4 % pour le commerce et le négoce (art. 77). (2) Tout contrat qui prévoit un prix appelle la TVA à 18 %, réduite à 9 % sur une liste limitative (art. 359). (3) Les droits d'enregistrement d'un acte sont fiscaux, pas juridiques. ⛔ RÈGLE À NE JAMAIS OUBLIER : le Code est arrêté au 10 janvier 2025, l'annexe fiscale 2026 lui est postérieure. On lit l'article, PUIS on cherche le même sujet dans l'annexe 2026. Renvoyer à MAMADOU dès qu'il s'agit de chiffrer, de déclarer ou de calendrier d'échéances.

## Propriété

### CL-IBRAHIM-17 · Marques, brevets et dessins en zone OAPI
- **Pourquoi** : Déposer au mauvais endroit
- **Où chercher** : OAPI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OAPI sur disque. Le point qui commande tout : en Côte d'Ivoire IL N'EXISTE PAS de droit national des marques et des brevets à côté de l'Accord de Bangui, dont l'article 5 dit que l'Accord et ses Annexes « tiennent lieu de lois relatives aux matières qu'ils visent ». Un dépôt OAPI vaut pour les DIX-SEPT États membres, il n'y a pas de dépôt ivoirien séparé : conseiller « un dépôt national puis un dépôt régional » est une erreur de fait. ⚠ Exception : l'Annexe VII, propriété littéraire et artistique, n'est qu'un cadre minimal, le droit d'auteur reste pour partie national. || FAIT LE 18/09 : ~/.claude/outils-communs/oapi/ porte l'Accord de Bangui instituant l'OAPI, RÉVISÉ LE 14/12/2015 À BAMAKO, avec ses dix annexes (189 pages), et le RÈGLEMENT D'APPLICATION, résolution n°60/29 du 08/12/2020, pris sur oapi.int même (51 pages). LE POINT QUI COMMANDE TOUT LE RESTE, article 5 de l'Accord, cité mot pour mot : dans les États membres, le présent Accord et ses Annexes TIENNENT LIEU DE LOIS relatives aux matières qu'ils visent, et y abrogent ou empêchent l'entrée en vigueur de toutes les dispositions contraires. Autrement dit : IL N'EXISTE PAS DE DROIT NATIONAL IVOIRIEN DES MARQUES ET DES BREVETS à côté de ce texte, et un dépôt à l'OAPI vaut pour les DIX-SEPT États membres à la fois. Conseiller un dépôt national puis un dépôt régional est une erreur de fait. Les droits restent pour autant des DROITS NATIONAUX INDÉPENDANTS, soumis à la législation de chaque État où ils produisent effet (art. 5 al. 1). ⚠ UNE EXCEPTION DANS LE TEXTE MÊME : l'Annexe VII, propriété littéraire et artistique, n'est qu'un CADRE NORMATIF MINIMAL (art. 5 al. 2) ; le droit d'auteur reste donc pour partie national. LES DIX ANNEXES : 1 brevets, 2 modèles d'utilité, 3 marques de produits ou de services, 4 dessins et modèles industriels, 5 noms commerciaux, 6 indications géographiques, 7 propriété littéraire et artistique, 8 concurrence déloyale, 9 schémas de configuration de circuits intégrés, 10 obtentions végétales. Le règlement de 2020 suit le même découpage et porte LA PROCÉDURE : pièces du dépôt, régularisation, délais, taxes, oppositions. DEUX DURÉES VÉRIFIÉES SUR LE TEXTE : le brevet expire au terme de la VINGTIÈME ANNÉE CIVILE à compter de la date de dépôt de la demande, sous réserve des articles 30 et 44 de l'Annexe 1 ; la marque se conserve SANS LIMITATION DE DURÉE par renouvellements successifs TOUS LES DIX ANS, le renouvellement se demandant au cours de la dernière année de la période en cours. ⛔ PIÈGE DE DATE : la révision de 2015 n'est ENTRÉE EN VIGUEUR QUE LE 14 NOVEMBRE 2020 ; un titre déposé avant relève de l'Acte du 24/02/1999, qui n'est pas sur la machine, et chaque annexe porte ses propres dispositions transitoires. CE QUI MANQUE : le barème des taxes de l'OAPI, fixé par décision du Conseil d'administration et révisé indépendamment de l'Accord, à vérifier sur oapi.int avant tout chiffrage ; le parcours pratique en Côte d'Ivoire, structure nationale de liaison et formalités locales ; la jurisprudence des juridictions nationales et de la Commission supérieure de recours. La vérification finale d'une date de dépôt, d'une priorité ou d'une opposition revient à un mandataire agréé auprès de l'OAPI.

## Références

### CL-IBRAHIM-18 · Modèles de contrats réellement utilisés ici
- **Pourquoi** : Livrer un modèle inapplicable
- **Où chercher** : Cabinets locaux, documents de la maison
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE, et c'est une donnée interne, pas une recherche. Ce que demande cette ligne, ce sont les modèles que la maison utilise réellement et ceux que les cabinets de la place font signer : contrat de prestation, contrat de travail, bail professionnel, accord de confidentialité, conditions générales. Rien de tel n'a été trouvé dans l'espace Drive accessible à mon compte le 18/09. Ce que les actes uniformes permettent maintenant, et qui n'est pas un modèle : vérifier qu'un projet de contrat ne heurte pas une disposition d'ordre public. Pour avancer, il faut soit que la maison verse ses modèles, soit qu'on parte du texte et qu'un avocat de la place relise le premier jeu.

## Droit et conventions

### CL-IBRAHIM-19 · Conventions collectives sectorielles de Côte d'Ivoire
- **Pourquoi** : Un avis sur une relation de travail qui ignore la convention de branche est exact en droit général et faux dans le dossier. Le texte pose le socle, la convention pose l'applicable.
- **Où chercher** : Ministère de l'Emploi et de la Protection sociale ; Journal officiel ; organisations patronales de branche
- **Trouvé** : Non
- **Intégré** : Non
- **Commentaire** : Demandé au point de formation du 22/09/2026.
