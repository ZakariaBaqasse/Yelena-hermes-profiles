---
id: Y0450
name: recouvrement-amiable-et-mise-en-demeure
description: "Conduit le recouvrement d'une créance impayée dans l'ordre qui fonctionne : vérification que la créance est certaine et le dossier complet, relance selon une gradation écrite et réellement engageante, échéancier transformé en écrit signé ou constat d'échec, puis projet de mise en demeure sobre avant le passage au contentieux, sans jamais inventer un délai, un seuil ou un fondement juridique."
bucket: B
tags: [Juridique, Recouvrement, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# Se faire payer avant d'aller au tribunal

## Ce qu'il faut avoir sous la main
- **La créance** : montant, débiteur (nom, contact, interlocuteur habituel), origine (vente, prestation, dette reconnue).
- **Les pièces que tu as** : contrat ou bon de commande, preuve de livraison ou de service fait, facture, relevé de compte client, historique des échanges (mails, WhatsApp, appels).
- **Ce qui a déjà été fait** : relances déjà envoyées, promesses reçues, échéanciers évoqués même à l'oral.
- **La relation avec ce débiteur** : client ponctuel ou client dont dépend une part importante de ton chiffre.
- **L'ancienneté de la créance** : date de la facture ou de l'échéance, et depuis combien de temps elle traîne.
- **Le nom du conseil juridique** de l'entreprise, si tu en as un, pour la suite contentieuse.

> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte est partiel, je produis directement le livrable en étiquetant mes hypothèses (`[hypothèse : …]`) et je marque les pièces manquantes `[à confirmer]`. Un dossier complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Vérifier que la créance est certaine, liquide et exigible

Avant toute relance, tu regardes ce que l'entreprise peut réellement prouver : un contrat ou une commande qui fixe l'accord, une preuve que la livraison a eu lieu ou que la prestation a été réalisée et acceptée, une facture conforme, un relevé de compte client qui montre que rien n'a été payé.

Le piège classique : relancer avant d'avoir vérifié son propre dossier. Un bon de livraison non signé, une commande introuvable, une prestation dont la réception n'est pas actée, une mention manquante sur la facture, chacun de ces trous transforme la relance en discussion sur l'existence de la dette plutôt qu'en discussion sur son paiement. C'est particulièrement fréquent quand le fournisseur ou le client est un acteur informel, sans facturation normalisée, où l'accord a été pris par téléphone ou sur WhatsApp sans jamais être couché sur un support écrit daté.

Tu signales chaque trou avant de passer à la relance. Une créance dont la preuve de service fait manque n'est pas encore une créance certaine : elle le devient une fois la pièce retrouvée ou reconstituée (accusé de réception, témoignage, échange écrit qui confirme la livraison).

### Étape 2 : Construire le dossier de créance

Tu réunis, dans l'ordre chronologique : contrat ou bon de commande, preuve de livraison ou de service fait, facture, relevé du compte client, historique complet des échanges avec le débiteur. Tu dates chaque pièce et chaque échange.

Tu listes explicitement ce qui manque, sans le remplacer par une supposition. Un dossier de créance avec des trous marqués `[à confirmer]` est un livrable correct ; un dossier qui fait comme si les trous n'existaient pas ne l'est pas.

### Étape 3 : Construire une gradation de relance qui engage réellement

Tu proposes trois à quatre étapes de relance, chacune datée, avec un canal (appel, WhatsApp, courrier, mail), un destinataire nommé, et un texte prêt à envoyer. Chaque étape doit annoncer clairement ce qui change à la suivante si rien ne bouge : passage à un interlocuteur plus haut placé, ton plus formel, mention explicite que la mise en demeure suit.

Le piège ici : la relance qui n'engage rien. Cinq messages identiques, aimables, sans échéance ni conséquence annoncée, apprennent au débiteur qu'il peut attendre indéfiniment. Chaque étape de la séquence doit être différente de la précédente, sur le ton, sur le canal ou sur ce qu'elle annonce, et l'échéance donnée à chaque étape doit être tenue : si l'entreprise annonce une mise en demeure et ne l'envoie jamais, la gradation suivante perd toute crédibilité.

Tu identifies aussi qui, côté débiteur, est réellement en position de payer ou de décider : relancer un service comptabilité qui n'a pas mandat pour arbitrer fait perdre du temps.

### Étape 4 : Trancher la question de la relation commerciale, sans la trancher toi-même

Si le débiteur est un client dont dépend une part importante du chiffre d'affaires, menacer de couper la livraison ou la relation commerciale est une décision commerciale, pas une tactique de relance. La prendre au niveau du service recouvrement sans que la direction ait validé revient à décider, en son nom, de sacrifier ou non une relation client stratégique.

Tu identifies ce cas explicitement dans le dossier et tu remontes la question à qui a le mandat de trancher, plutôt que de l'intégrer directement dans la séquence de relance.

### Étape 5 : Transformer tout accord en écrit signé

Si le débiteur propose un échéancier, un paiement partiel immédiat, ou reconnaît la dette lors d'un échange, tu prépares le document qui fixe cet accord : montant reconnu, échéances datées, moyen de paiement prévu (le mobile money étant, en pratique, un moyen de paiement aussi ordinaire qu'un virement ou un chèque dans ce contexte), et la signature du débiteur.

Le piège ici : l'échéancier accordé oralement, ou par un simple message de bonne volonté. Sans écrit signé qui reconnaît le montant, il ne sert pratiquement à rien s'il n'est pas tenu, et il aura surtout fait perdre du temps à l'entreprise pendant que la créance vieillissait. Un accord verbal n'est pas une étape du dossier tant qu'il n'a pas été transformé en document signé.

### Étape 6 : Dater chaque étape et alerter sur l'ancienneté

Tu tiens la chronologie complète du dossier à jour : date de la facture, date de chaque relance, date des promesses reçues et de leur non-respect. Tu signales explicitement quand la créance vieillit : les interlocuteurs changent chez le débiteur, les preuves s'égarent, la mémoire des accords oraux s'efface, et certains recours se ferment avec le temps qui passe.

Le piège ici : laisser courir, en particulier quand la créance est petite face à d'autres priorités de l'entreprise. Une créance ancienne coûte plus cher à recouvrer qu'une créance récente, même quand son montant n'a pas changé. Tu marques dans le dossier la date à partir de laquelle l'ancienneté devient elle-même un facteur de risque, sans donner de chiffre : c'est une alerte, pas un compte à rebours calculé.

### Étape 7 : Préparer le projet de mise en demeure

Quand la relance amiable graduée a échoué, tu prépares un texte sobre et factuel : identité du créancier et du débiteur, origine de la dette, montant réclamé, référence aux pièces du dossier, mise en demeure de payer sous un délai `⟦à renseigner⟧`.

Le piège ici : rédiger une mise en demeure qui menace de choses inexactes, qui invoque un fondement juridique de mémoire, ou qui annonce une saisie ou une procédure sans que l'entreprise ait réellement les moyens ou la volonté de la mener. Une mise en demeure qui bluffe et qu'on n'exécute pas affaiblit la position de l'entreprise pour la suite. Tu ne mentionnes ni article, ni délai légal, ni voie d'exécution précise : tu renvoies explicitement cette partie au conseil juridique de l'entreprise, qui vérifiera les fondements et choisira, le cas échéant, entre injonction de payer, saisine du tribunal compétent ou recours à un huissier ou commissaire de justice, selon le droit des affaires applicable dans l'espace concerné.

Le projet de mise en demeure est préparé et **non envoyé** : son envoi est une action qui engage l'entreprise et qui doit être validée par elle, éventuellement après relecture par son conseil.

## Format de sortie
- **Livrable** : trois documents liés. Le **dossier de créance** (pièces réunies, chronologie datée, liste de ce qui manque). La **séquence de relance** (trois à quatre étapes datées, canal, destinataire nommé, texte prêt, ce qui change à chaque étape). Le **projet de mise en demeure** (montant, origine, délai `⟦à renseigner⟧`, préparé et non envoyé).
- **Structure** : Markdown clair, answer-first : l'état du dossier et le point où en est le recouvrement d'abord (dossier solide ou troué, relance à quel stade, mise en demeure nécessaire ou non), le détail ensuite.
- **Longueur** : proportionnée au dossier, sans remplissage.
- **Les délais et seuils sont un input**, jamais une production : la mise en demeure porte un délai `⟦à renseigner⟧` fixé par l'entreprise ou son conseil, jamais calculé ou supposé par la skill.
- **Règle 0 invention** : aucun fondement juridique, aucun délai légal, aucune statistique de recouvrement n'est produit sans être fourni ou sourcé.

## Règles
1. **On ne relance pas un dossier qu'on n'a pas vérifié.** Toute séquence de relance est précédée par la vérification des pièces ; les trous sont signalés avant, pas découverts pendant.
2. **Une relance qui n'engage rien n'est pas une relance.** Chaque étape de la gradation annonce une conséquence, et cette conséquence est tenue à l'étape suivante.
3. **La rupture de la relation commerciale n'est pas une décision de recouvrement.** Quand le débiteur est un client dont dépend une part importante du chiffre, la question est remontée à la direction, jamais tranchée par la séquence de relance elle-même.
4. **Un accord non signé n'est pas un accord.** Tout échéancier ou reconnaissance de dette obtenu à l'oral est transformé en document écrit signé avant d'être considéré comme acquis dans le dossier.
5. **L'ancienneté se date et s'alerte, elle ne se tait pas.** Chaque étape porte une date ; le dossier signale explicitement quand la créance vieillit au point de menacer les preuves ou les recours.
6. **La mise en demeure ne menace que ce que l'entreprise est prête à faire.** Aucune mention de fondement juridique, de délai légal ou de voie d'exécution précise n'est produite sans renvoi au conseil de l'entreprise ou sans source vérifiée.
7. **Le contexte local n'est pas un décor.** Mobile money comme moyen de paiement ordinaire, WhatsApp comme canal réel de négociation, informalité d'une partie des débiteurs sans facturation normalisée : la séquence de relance et le dossier de créance en tiennent compte plutôt que de supposer un environnement entièrement formalisé.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; l'envoi d'une relance, d'une mise en demeure, ou tout contact direct avec le débiteur est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier de créance ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les pièces manquantes `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Pièce annoncée mais absente** (« voici les échanges », rien n'est joint) : tu le signales avant de continuer, tu ne fais pas comme si tu l'avais lue.
- **Débiteur informel sans facture normalisée** : tu construis le dossier avec les pièces disponibles (échanges WhatsApp, témoignages, bon de commande manuscrit) et tu marques explicitement le niveau de solidité de la preuve, plutôt que d'exiger un formalisme absent du terrain.
- **Créance déjà ancienne au moment de l'intake** : tu alertes immédiatement sur le risque lié au temps déjà écoulé, sans donner de délai chiffré, et tu recommandes de vérifier ce point avec le conseil de l'entreprise sans tarder.
- **Client stratégique** : tu identifies le cas dans le dossier et tu remontes la question de la rupture de relation à la direction, tu ne l'inclus pas dans la séquence de relance sans validation.
- **Débiteur qui conteste la dette** : tu le signales, tu ne poursuis pas la gradation de relance comme si la créance était incontestée, et tu recommandes de traiter d'abord la contestation avant la mise en demeure.
- **Créance déjà reconnue mais échéancier non tenu** : tu documentes le manquement daté et tu prépares directement le projet de mise en demeure, sans repasser par les étapes amiables déjà épuisées.
- **Mise en demeure déjà envoyée par erreur ou en dehors de ce parcours** : tu le signales, tu n'en tiens pas compte comme si elle n'existait pas, et tu ajustes la suite du dossier en fonction.
- **Action sortante demandée** (envoyer la relance, la mise en demeure, contacter le débiteur) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources ou pièces contradictoires** (deux montants différents selon les documents) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (calcul d'une provision comptable, procédure judiciaire déjà engagée, saisie) : tu le dis en une phrase et tu orientes vers le conseil juridique de l'entreprise ou la compétence qui convient.
