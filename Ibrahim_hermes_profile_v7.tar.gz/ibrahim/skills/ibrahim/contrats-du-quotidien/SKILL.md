---
id: Y0448
name: contrats-du-quotidien
description: "Prépare et sécurise les contrats ordinaires d'une PME (bail commercial, contrat de prestation, distribution ou dépôt-vente, prêt de matériel, transport, convention de compte fournisseur) : qualifie la situation réelle avant de choisir le type de contrat, vérifie le pouvoir des signataires, confronte l'écrit à la pratique déjà exécutée, traite en premier les clauses qui décident de tout (durée, préavis, prix, responsabilité, propriété, confidentialité, tribunal compétent, langue), puis rend le projet de contrat, sa note d'accompagnement et sa fiche de signature, sans jamais produire de référence légale, de taux ou de seuil inventé."
bucket: B
tags: [Juridique, Contrats, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Les contrats qu'une entreprise signe vraiment, et ce qu'il faut y mettre

## Ce qu'il faut avoir sous la main
- **La situation**, décrite en langage ordinaire, pas encore juridique : qui fait quoi pour qui, contre quoi, depuis quand.
- **Les deux parties** : raison sociale ou nom, forme juridique si connue, qui signerait de chaque côté.
- **Ce qui se fait déjà** : si la relation tourne depuis un moment sans contrat écrit, sur quelle base (accord oral, échanges WhatsApp, factures déjà émises).
- **Ce qui est déjà tranché** : prix, durée, délai, garantie, tout point déjà négocié entre les parties.
- **Les annexes existantes ou à créer** : cahier des charges, grille tarifaire, plan, état des lieux, inventaire.
- **Le pays et la ville**, pour la juridiction compétente et les usages locaux.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte fourni est partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce qui manque et ne peut pas être supposé. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Qualifier la situation réelle, pas la demande formulée
Quelqu'un qui dit « fais-moi un contrat de prestation » décrit parfois, sans le savoir, une relation de subordination, ou un dépôt-vente qu'il appelle « vente ». La qualification juridique dépend de ce qui se passe réellement, pas du nom donné par celui qui demande.

Vérifie en particulier : un « prestataire » qui reçoit des horaires imposés, un poste de travail fourni, une exclusivité de fait et un contrôle continu ressemble à un salarié déguisé, avec le risque de requalification que cela porte devant la CNPS et l'administration fiscale le jour d'un contrôle ou d'un litige. Une marchandise confiée à un distributeur qui n'en devient jamais propriétaire tant qu'elle n'est pas vendue est un dépôt-vente, pas une vente ferme, et l'écrit doit le dire.

Si la qualification proposée ne correspond pas à ce qui est décrit, tu le signales avant de rédiger quoi que ce soit : rédiger le bon papier sur la mauvaise base ne protège personne.

### Étape 2 : Vérifier le pouvoir de celui qui va signer en face
Un contrat signé par quelqu'un qui n'a pas le pouvoir d'engager sa société ne vaut rien le jour où ça tourne mal, même si tout le reste est bien écrit. Le gérant d'une société immatriculée, le représentant d'une association, le porteur d'une procuration écrite, n'ont pas le même pouvoir, et certains actes demandent l'accord d'un organe (assemblée, conseil) que le signataire seul ne peut pas donner.

Demande la pièce qui établit ce pouvoir : extrait du registre du commerce et du crédit mobilier (RCCM) qui identifie le gérant statutaire, statuts qui décrivent les pouvoirs de représentation, ou procuration signée si un mandataire agit à la place du représentant légal. Une contrepartie informelle, sans immatriculation ni structure identifiable, n'est pas exclue du contrat, mais tu le signales : l'exécution forcée en cas de litige y sera plus difficile, et le contrat doit en tenir compte (garanties, paiement d'avance, clause de résiliation plus stricte).

### Étape 3 : Confronter l'écrit à ce qui se fait déjà
Beaucoup de contrats se rédigent après plusieurs mois de relation déjà en cours, parfois sur la seule base d'échanges WhatsApp ou d'un accord verbal donné lors d'un rendez-vous. Demande systématiquement : depuis combien de temps ça tourne, sur quelle base, et qu'est-ce qui a déjà été payé ou livré.

Chaque écart entre la pratique et le projet de contrat est un point de friction en germe : si le prix payé jusqu'ici diffère de celui du projet, si les délais réels ne correspondent pas au préavis prévu, si un mode de paiement (mobile money, chèque, espèces) est utilisé sans avoir été formalisé, tu le relèves explicitement plutôt que de laisser le nouveau texte contredire silencieusement l'ancien usage. Les captures d'échanges WhatsApp ou les reçus mobile money valent comme éléments de contexte, pas comme preuve juridique automatique : tu le dis, tu ne les traites pas comme équivalents à un écrit signé.

### Étape 4 : Traiter en premier les clauses qui décident de tout
Ce sont les clauses qu'on lit en dernier, et qui commandent pourtant l'issue du contrat le jour où ça se tend :
- **Durée et reconduction** : durée ferme, tacite reconduction ou non, et ce qui se passe à l'échéance.
- **Préavis** : délai à respecter pour mettre fin au contrat, et sa forme (lettre, mise en demeure).
- **Révision du prix** : ce qui peut faire varier le prix ou le loyer, et selon quelle logique (indexation, renégociation, silence des parties).
- **Responsabilité et son plafond** : qui répond de quoi, et jusqu'à quel montant ou quelle limite.
- **Propriété de ce qui est produit ou livré** : à qui appartient un rapport, un plan, une marchandise en dépôt, du matériel prêté, et à quel moment le transfert s'opère.
- **Confidentialité** : ce qui ne doit pas circuler, pour combien de temps, avec quelle conséquence en cas de manquement.
- **Tribunal ou arbitrage compétent** : quelle juridiction ou quel mode de règlement des différends les parties choisissent, et pourquoi celui-là a un sens dans leur situation.
- **Langue qui fait foi** : quand un contrat existe en plusieurs langues, laquelle prévaut en cas de désaccord d'interprétation.

Pour chaque type de contrat, ces clauses prennent une couleur particulière : dans un bail commercial, la révision du loyer et le sort des aménagements en fin de bail ; dans un contrat de prestation, la frontière entre obligation de moyens et obligation de résultat ; dans un dépôt-vente, le rythme d'inventaire et le sort des invendus ; dans un prêt de matériel, l'état constaté à l'aller et au retour et qui supporte la casse ; dans un transport, le délai réaliste (embouteillages, saison des pluies, état des routes) et la réserve à formuler à la livraison ; dans une convention de compte fournisseur, le délai de paiement et ce qui se passe en cas de retard.

### Étape 5 : Vérifier que les annexes existent réellement
Un contrat qui renvoie à « l'annexe 1 » pour le cahier des charges, à « la grille tarifaire ci-jointe » ou à « l'état des lieux établi contradictoirement » est vide sur son objet même si ces pièces n'existent pas encore. Liste chaque annexe promise par le corps du contrat et vérifie qu'elle est fournie, en préparation, ou marquée `⟦à renseigner⟧`.

Signale en particulier les annexes qui engagent le prix ou l'objet (grille tarifaire, cahier des charges, plan, inventaire) : sans elles, le contrat peut être signé mais son exécution reste ouverte à interprétation, ce qui est précisément ce qu'on cherche à éviter.

### Étape 6 : Ancrer juridiquement sans jamais citer de mémoire
Nomme les corpus et institutions qui s'appliquent selon le type de contrat, sans jamais reformuler un article, un taux ou un délai légal de mémoire : le droit OHADA et son acte uniforme sur le droit commercial général encadrent notamment le bail commercial et l'immatriculation au RCCM ; la CNPS a la charge de la protection sociale des salariés et du risque de requalification d'une prestation en emploi ; la DGI a la charge de l'enregistrement fiscal de certains actes ; la CIMA encadre l'assurance, pertinente pour un contrat de transport de marchandises.

Chaque fois qu'une clause aurait besoin d'un texte précis (délai légal de préavis d'un bail, plafond légal de responsabilité, formalité d'enregistrement obligatoire), tu marques `⟦référence à vérifier⟧` plutôt que de citer un article ou un taux de mémoire. Tu ne bloques pas la rédaction pour autant : la clause se rédige avec la structure correcte, et le renvoi au texte précis reste en suspens jusqu'à vérification.

### Étape 7 : Assembler les trois livrables
Rédige le projet de contrat avec chaque élément non fourni en `⟦à renseigner⟧`, la note d'accompagnement qui explique en une phrase ce que fait chaque clause sensible et ce qu'elle fait gagner ou risquer, et la fiche de signature qui fixe qui signe, à quel titre, avec quelle pièce de pouvoir, en combien d'exemplaires, avec quelles annexes et quels paraphes.

## Format de sortie
- **Livrable 1, le projet de contrat** : structuré par articles (objet, durée, prix et paiement, obligations de chaque partie, responsabilité, confidentialité, résiliation, litiges, langue, annexes), chaque donnée manquante en `⟦à renseigner⟧`.
- **Livrable 2, la note d'accompagnement** : une liste des clauses sensibles, chacune en une phrase de langage ordinaire (ce qu'elle fait, ce qu'elle fait gagner ou risquer), avec un signal explicite sur celles qui appellent l'avis d'un conseil juridique avant signature.
- **Livrable 3, la fiche de signature** : qui signe, à quel titre (gérant statutaire, mandataire, associé), quelle pièce établit son pouvoir, en combien d'exemplaires, avec quelles annexes jointes, et ce qui doit être paraphé page par page.
- **Structure** : Markdown clair, les trois livrables séparés et titrés, le projet de contrat en premier.
- **Longueur** : proportionnée au type de contrat ; un prêt de matériel entre deux entreprises ne demande pas la même longueur qu'un bail commercial ou une convention de distribution.
- **Règle 0 invention** : aucun chiffre, taux, délai légal ou référence d'article produit de mémoire. `⟦à renseigner⟧` pour les données manquantes, `⟦référence à vérifier⟧` pour toute référence légale précise.

## Règles
1. **Aucune clause n'est copiée d'un modèle non vérifié pour ce contexte.** Toute clause dont la validité locale n'est pas confirmée est signalée, pas simplement recopiée parce qu'elle « se trouve dans tous les modèles ».
2. **Le pouvoir du signataire se vérifie avant la rédaction, pas après la signature.** Sans pièce établissant ce pouvoir, la fiche de signature le marque en attente.
3. **Les clauses qui décident de tout se traitent en premier**, jamais reléguées en fin de document ni traitées comme du texte standard sans discussion.
4. **L'écrit s'aligne sur la pratique réelle, ou l'écart est nommé.** Un contrat qui contredit silencieusement ce que les parties font depuis des mois n'est pas un contrat sécurisant.
5. **Une annexe promise et absente rend le contrat incomplet sur son objet**, et c'est signalé comme tel, pas comme un détail à régler plus tard.
6. **0 référence légale inventée.** Aucun article, taux, plafond ou délai légal n'est cité de mémoire : `⟦référence à vérifier⟧` sinon. Une institution peut être nommée pour dire ce dont elle a la charge, jamais pour lui prêter un chiffre non fourni.
7. **Le contexte local n'est pas un décor.** Moyen de paiement réellement utilisé (mobile money, virement, chèque, espèces), délais réalistes compte tenu des distances et des embouteillages, statut formel ou informel de la contrepartie : tout cela change la clause qu'il faut écrire, pas seulement son style.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un projet de contrat et ses annexes ; l'envoi à la contrepartie, la signature, l'enregistrement auprès d'une administration ou tout engagement de dépense restent des actions validées par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ou d'une relation contractuelle ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune pièce de pouvoir fournie** : tu rédiges quand même le contrat, mais la fiche de signature reste explicitement en attente sur ce point, et tu ne présentes jamais un signataire comme habilité sans preuve.
- **Relation déjà en cours sans écrit** : tu demandes ce qui se fait réellement, tu signales chaque écart entre la pratique et le projet, et tu ne fais jamais comme si le contrat écrit avait toujours existé.
- **Annexe promise mais absente** : tu le signales avant de continuer et tu marques la clause qui y renvoie comme incomplète, plutôt que de faire comme si elle existait.
- **Référence légale précise demandée** : tu nommes le corpus ou l'institution compétente, tu marques `⟦référence à vérifier⟧`, et tu n'inventes jamais un article, un taux ou un délai pour combler le vide.
- **Contrepartie informelle, non immatriculée** : tu le signales, tu adaptes les garanties proposées (paiement d'avance, clause de résiliation plus stricte) et tu ne traites pas cette situation comme équivalente à une société immatriculée.
- **Litige déjà en cours sur un contrat existant** : hors périmètre de cette skill, tu le dis en une phrase et tu orientes vers la compétence contentieux ou vers un conseil, plutôt que de rédiger un nouveau contrat sur un différend déjà ouvert.
- **Demande d'action sortante** (envoi à la contrepartie, signature, enregistrement, paiement) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Versions contradictoires** (l'oral dit une chose, un ancien écrit en dit une autre) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
