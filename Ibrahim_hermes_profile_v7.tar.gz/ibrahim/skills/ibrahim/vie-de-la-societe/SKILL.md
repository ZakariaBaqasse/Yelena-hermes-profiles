---
id: Y0451
name: vie-de-la-societe
description: "Tient la vie juridique de la société en ordre pendant qu'elle tourne : calendrier des assemblées et des dépôts, suivi des mandats de dirigeants, registre des décisions, projet de procès-verbal, et repérage des modifications à déclarer avant qu'une banque, un acheteur ou un marché public ne les découvre en bloquant le dossier, sans jamais produire de délai, de forme ou de seuil légal de mémoire."
bucket: B
tags: [Juridique, Gouvernance, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# Tenir la société en règle, assemblées, registres, formalités

## Ce qu'il faut avoir sous la main
- **La forme sociale et le pays d'immatriculation** (SARL, SA, SAS, autre ; Côte d'Ivoire ou ailleurs).
- **Les statuts**, si tu les as sous la main, ou au moins la date de constitution et le dernier acte déposé au registre du commerce.
- **Les dirigeants en poste** : qui, depuis quand, pour quelle durée de mandat si tu la connais.
- **La dernière assemblée tenue** et si un procès-verbal existe pour elle.
- **L'adresse du siège social** telle qu'enregistrée, et si elle correspond encore à la réalité.
- **Tout événement récent ou prévu** : changement d'associé, augmentation de capital, changement de dirigeant, candidature à un marché, entrée d'investisseur, projet de cession.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 1 : Reconstituer l'état civil de la société

Avant de chercher ce qui manque, fixe ce qui existe : forme sociale, objet, capital, siège, dirigeants, associés, tels qu'ils figurent dans les derniers actes déposés. Compare avec la réalité telle que le dirigeant la décrit. Le premier signal d'alerte n'est jamais dans un document isolé : il est dans l'écart entre ce que dit le registre et ce que fait l'entreprise aujourd'hui (un associé parti mais toujours inscrit, un objet social qui ne couvre plus l'activité réelle, un capital jamais ajusté après une entrée d'argent informelle).

Si les statuts ne sont pas fournis, tu travailles sur ce que le dirigeant sait de mémoire, tu le marques `[hypothèse : selon déclaration du dirigeant, statuts non vérifiés]`, et tu listes ce qu'il faudrait relire dans les statuts pour confirmer chaque point sensible (durée des mandats, quorum, majorité, clauses d'agrément).

### Étape 2 : Suivre les mandats de dirigeants

C'est le piège qui ne se voit jamais avant qu'un tiers vérifie. Un mandat de gérant ou d'administrateur a une durée fixée par les statuts ou par la décision qui l'a nommé ; une fois cette durée dépassée sans renouvellement, les actes signés depuis sont contestables, y compris ceux qui ont marché sans problème pendant des mois.

Pour chaque dirigeant : date de nomination, durée de mandat `⟦à vérifier aux statuts⟧`, date d'échéance qui en découle, et statut (en cours, à renouveler bientôt, expiré). Un mandat expiré n'est jamais traité comme un détail administratif : c'est signalé en tête du calendrier, avec la question de la régularisation posée explicitement, pas résolue à ta place.

### Étape 3 : Vérifier le siège social

Le siège n'est pas une adresse décorative : c'est le point où la loi considère que la société reçoit valablement ses convocations et ses actes. S'il ne correspond plus au local réellement occupé, ou pire, s'il s'agit d'une adresse d'un tiers ou d'un ancien local, l'entreprise peut ne jamais recevoir un courrier qui compte, et l'apprendre trop tard.

Demande explicitement : l'adresse dans le registre est-elle celle du local d'exploitation actuel ? Si non, c'est une modification à déclarer, pas un détail à laisser filer, surtout si l'entreprise a déménagé plusieurs fois entre quartiers ou communes d'Abidjan sans mettre le registre à jour.

### Étape 4 : Reconstituer le registre des décisions et repérer ce qui n'a jamais été formalisé

Demande la liste des décisions importantes prises depuis la dernière assemblée formalisée : changement de dirigeant, répartition, investissement significatif, entrée ou sortie d'associé, même si elles ont été discutées en réunion informelle ou actées sur un groupe WhatsApp entre associés. Une décision discutée et acceptée oralement, ou confirmée par un message, n'a pas la valeur d'une décision consignée dans un procès-verbal signé : elle n'est pas opposable, et dans deux ans, les mêmes personnes s'en souviendront différemment, ou ne seront plus toutes présentes pour en témoigner.

Chaque décision retrouvée sans PV correspondant devient une ligne du registre à régulariser, et un projet de procès-verbal est préparé pour la faire adopter formellement à la prochaine occasion.

### Étape 5 : Vérifier la séparation des patrimoines

Trois questions simples, qui suffisent presque toujours à révéler le problème : le compte bancaire de la société sert-il aussi à des dépenses personnelles du dirigeant ? Un véhicule, un local ou un équipement utilisé par la société appartient-il au dirigeant sans bail ni convention écrite ? Des avances ont-elles été faites entre la société et le dirigeant sans être remboursées ni documentées ?

Une réponse positive à l'une de ces questions n'est pas anodine : c'est un risque juridique et fiscal, et c'est le premier point qu'un acheteur, un investisseur ou un prêteur regarde en revue de dossier. Tu le signales sans l'euphémiser, et tu recommandes la régularisation (convention formalisée, remboursement, séparation des comptes) plutôt que de la traiter comme un détail comptable.

### Étape 6 : Bâtir le calendrier des obligations sociales

Rassemble tout ce qui précède dans un calendrier : chaque obligation récurrente (assemblée générale ordinaire annuelle, dépôt des comptes, renouvellement de mandat, cotisation ou déclaration auprès de la CNPS et de la DGI selon le régime de la société) avec sa périodicité, son échéance en `⟦à renseigner⟧` tant qu'elle n'est pas confirmée par les statuts ou le texte applicable, un responsable nommé, la pièce à produire, et l'état (à jour, à faire, en retard).

Tu ne remplis jamais une échéance de mémoire. Le droit OHADA harmonise les règles des sociétés commerciales dans les pays membres, mais les délais précis, les formes de convocation et les modalités de dépôt se vérifient dans le texte et auprès du conseil local ; tu poses la ligne du calendrier, pas le chiffre.

### Étape 7 : Identifier les modifications à déclarer

Un événement passé ou prévu (changement de siège, d'objet, de capital, de dirigeant, d'associé) déclenche presque toujours une formalité auprès du registre du commerce et du crédit mobilier, via le greffe du tribunal de commerce compétent ou le guichet unique de formalités des entreprises quand le pays en dispose (le CEPICI en Côte d'Ivoire, par exemple, centralise une partie de ces démarches). Tu listes chaque événement signalé par le dirigeant, la formalité qu'il entraîne vraisemblablement, et tu marques `⟦à confirmer auprès du greffe ou du conseil⟧` la pièce exacte et le délai, plutôt que de les inventer.

Une modification non déclarée à temps ne se voit dans l'exploitation ; elle se voit le jour d'un contrôle, d'une cession ou d'une demande de crédit, quand l'extrait de registre ne correspond plus à la réalité qu'on présente.

### Étape 8 : Préparer le dossier que demandera un tiers

Fais la liste des pièces qu'une banque pour un crédit, un acheteur en revue de dossier, un investisseur en due diligence, ou une administration pour un marché public, demandera presque toujours : statuts à jour, derniers PV d'assemblée, extrait de registre récent, attestations de régularité fiscale et sociale, justificatif de mandat en cours des dirigeants signataires. Pour chacune, indique si elle est disponible, à retrouver, ou à régulariser avant de pouvoir la produire.

C'est ce dossier, préparé à l'avance, qui évite au dirigeant de découvrir en pleine négociation qu'un document manque et qu'il faut trois mois pour le reconstituer, pendant que l'acheteur ou la banque perdent patience.

### Étape 9 : Le verdict d'état de conformité

Rends un état synthétique en trois catégories, comme un diagnostic, pas comme une liste plate :
- **En ordre** : ce qui est à jour et n'appelle aucune action.
- **À régulariser sous peu** : ce qui n'est pas encore un problème mais qui le deviendra (mandat qui approche de son terme, décision récente non encore formalisée).
- **Urgent** : ce qui expose déjà l'entreprise (mandat expiré, siège non conforme, patrimoine mélangé, formalité en retard sur un événement déjà survenu).

Classe chaque point urgent avec ce qu'il coûterait de ne pas agir (un acte contestable, une convocation non reçue, un dossier bloqué), sans dramatiser au-delà de ce qui est constaté, et sans minimiser non plus.

## Format de sortie
- **Livrable 1, le calendrier des obligations** : obligation, périodicité, échéance `⟦à renseigner⟧`, responsable nommé, pièce à produire, état (à jour / à faire / en retard).
- **Livrable 2, le registre des décisions** : date, organe (assemblée générale, décision de gérance, décision collective), objet, décision prise, où se trouve l'original du procès-verbal.
- **Livrable 3, le projet de procès-verbal** (si une décision attend d'être formalisée) : ordre du jour, quorum et majorité rappelés en `⟦à vérifier aux statuts⟧`, résolutions rédigées, signatures prévues.
- **Structure** : Markdown clair, answer-first (le verdict d'état de conformité d'abord, le détail ensuite), tableaux pour le calendrier et le registre.
- **Longueur** : proportionnée à la taille de la société et au nombre d'événements à traiter ; pas de remplissage.
- **Règle 0 invention** : aucun délai, aucune forme, aucun quorum, aucun seuil légal n'est produit sans être fourni ou sourcé ; `⟦à renseigner⟧` ou `⟦à vérifier aux statuts⟧` sinon.

## Règles
1. **Aucun délai, aucune forme, aucun quorum légal n'est produit de mémoire.** Ils dépendent de la forme sociale, des statuts et du pays. Tu poses la ligne à vérifier, tu ne remplis jamais la valeur toi-même.
2. **Le mandat expiré est signalé en priorité absolue**, jamais noyé dans une liste ; il rend contestables les actes déjà signés, pas seulement les futurs.
3. **Une décision sans procès-verbal n'est pas une décision formalisée**, même si tout le monde était d'accord, même si elle a été confirmée par écrit sur un canal informel. Tu le rappelles chaque fois qu'un dirigeant présente un accord verbal ou un message comme suffisant.
4. **Le mélange de patrimoines est signalé sans euphémisme.** Ce n'est jamais un détail comptable ; c'est le premier point qu'un tiers en revue de dossier regarde.
5. **« L'entreprise fonctionne » n'est jamais pris pour « l'entreprise est en ordre ».** Les deux sont indépendants, et c'est précisément l'écart entre eux que cette compétence existe pour combler.
6. **Le contexte local n'est pas un décor.** Un siège qui ne correspond plus à un local réellement occupé, une décision actée sur un groupe WhatsApp sans PV, un guichet unique de formalités qui existe dans le pays visé : tu en tiens compte plutôt que de raisonner sur un modèle abstrait de société.
7. **Chaque point du verdict est daté ou daté à défaut de l'être.** Un constat sans date de vérification ne permet pas de savoir s'il est encore valable dans six mois.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déposer un acte au greffe, envoyer une convocation, signer un procès-verbal ou notifier un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une société ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Statuts non fournis** : tu travailles sur la déclaration du dirigeant, tu marques chaque point sensible `[hypothèse : non vérifié aux statuts]`, et tu listes ce qu'il faut relire pour confirmer.
- **Mandat déjà expiré depuis longtemps** : tu le signales en tête du livrable comme urgent, tu ne minimises jamais en le noyant dans le calendrier général, et tu recommandes de faire vérifier par le conseil la validité des actes signés dans l'intervalle.
- **Décision retrouvée seulement dans un échange WhatsApp ou un compte-rendu informel** : tu la traites comme une décision non formalisée, tu prépares le projet de procès-verbal pour la régulariser, tu ne la comptes jamais comme déjà actée.
- **Société présente dans plusieurs pays ou en cours de changement de forme sociale** : tu traites chaque juridiction séparément, tu ne mélanges pas les cadres, et tu marques explicitement quand une règle diffère selon le pays sans savoir laquelle s'applique.
- **Demande hors périmètre** (rédaction d'un contrat commercial, contentieux en cours, structuration fiscale) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence ou le conseil qui convient.
- **Action sortante demandée** (déposer un acte, envoyer une convocation, faire signer un procès-verbal) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (statuts et registre du commerce ne disent pas la même chose, ou deux associés se souviennent différemment d'une décision) : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
- **Aucun document disponible, seulement la mémoire du dirigeant** : tu produis quand même le calendrier et le registre à partir de ce qui est déclaré, tu marques le tout `[à confirmer]`, et tu poses en premier la reconstitution des documents comme action prioritaire.
