# Sources officielles, Côte d'Ivoire et OHADA

⛔ **Ce fichier REMPLACE `sources-officielles.md` pour nos dossiers.** Le fichier amont liste
Légifrance, la Cour de cassation française, EUR-Lex, la CNIL et le CNB : aucun ne fait
autorité sur un dossier ivoirien. S'y référer produirait une note fausse avec des liens qui
s'ouvrent, ce qui est la pire forme d'erreur.

## Ce qu'on a DÉJÀ sur la machine, et qui se lit avant toute recherche en ligne

| Usage | Où |
|---|---|
| Les 10 actes uniformes OHADA, en PDF et en texte cherchable | `~/.claude/outils-communs/ohada/` |
| Droit du travail ivoirien, jours fériés article par article | `~/.claude/outils-communs/droit-travail-ci/` |
| Corpus local du poste (données personnelles, consommation, image, commerce extérieur) | `memory/reference/bases-locales/` |

⛔ **Une réponse se cite par son article**, jamais de mémoire : les `.txt` existent pour être
cherchés. Les dix actes et leur nombre d'articles : AUDCG 2010 (307), AUSCGIE 2014 (920),
AUSCOOP 2010 (397), AUS 2010 (228), AUPSRVE 2023 (338), AUPCAP 2015 (258), AUDCIF 2017 (113),
AUA 2017 (36), AUM 2017 (17), AUCTMR 2003 (31).

⚠ `ohadalegis.com` sert aussi les versions **abrogées de 1997** sous des noms proches :
vérifier l'année avant de citer.

## Hiérarchie de fiabilité, quand deux sources divergent

1. **Fait foi** : Journal officiel, décret, communiqué du Conseil des ministres, site de
   l'institution concernée.
2. **Quasi-foi** : BCEAO, ANStat, DGTCP, ARTCI, BRVM.
3. **Fiable à dater** : AIP, Reuters, AFP, APA.

Blogs, cabinets, agrégateurs et réponses de moteurs ne sont jamais des sources d'autorité,
exactement comme le dit le fichier amont.

## ⛔ Le point dur, à porter dans chaque note

**Le Journal officiel de Côte d'Ivoire n'est PAS en accès libre en ligne.** Le service JO du
Secrétariat général du Gouvernement délivre un code de téléchargement par téléphone
(+225 20 32 59 66). La rubrique Décrets gratuite de `web.sgg.gouv.ci` s'arrête en 2012.

Conséquence directe : **toute date de publication citée sans avoir ouvert le JO est une date
de seconde main, et la note doit le dire.** Ne pas maquiller une source secondaire en source
primaire parce que le lien s'ouvre.

## Les trois périmètres qu'on confond, et qui rendent une phrase fausse deux fois

- **OHADA**, 17 États : droit des affaires.
- **UEMOA**, 8 États : monnaie, relations financières extérieures.
- **CEDEAO**, 15 États.

⛔ Ne sont **pas** communs : le droit du travail, la fiscalité, la publicité, le SMIG, les
jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est une
erreur de périmètre.

## Les cinq régulateurs qui peuvent arrêter un travail

CSP, HACA, ANP, Autorité de protection des données, ARTCI.

## URLs

Comme en amont : conserver l'URL de la page réellement ouverte, jamais un lien reconstruit ou
supposé.
