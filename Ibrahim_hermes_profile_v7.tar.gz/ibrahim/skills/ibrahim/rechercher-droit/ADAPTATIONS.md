# Adaptations locales

⚠ **Ce fichier PRIME sur le `SKILL.md`** partout où les deux se contredisent. Le texte amont
n'est pas modifié : une mise à jour depuis la source le remplacerait et emporterait la
correction.

## ⛔ Le remplacement le plus important de tout le paquet

Le `SKILL.md` dit de lire `references/sources-officielles.md` avant toute recherche. Ce
fichier liste **Légifrance, la Cour de cassation française, EUR-Lex, la CURIA, la CNIL et le
CNB**. Aucun ne fait autorité sur un dossier ivoirien.

👉 **Lire `references/sources-officielles-ci.md` à la place.** Le fichier français est
conservé intact pour ne pas casser la mise à jour amont, il ne sert pas.

Le danger est précis : une note appuyée sur Légifrance serait **fausse tout en portant des
liens qui s'ouvrent**. C'est la forme d'erreur la plus difficile à repérer pour le lecteur.

## Ce que dit la description de la compétence

Elle annonce « droit français ou européen ». Lire : **droit ivoirien et droit OHADA**. La
méthode de recherche décrite dans `references/methode-recherche.md` reste valable, elle est
indépendante de la juridiction.

## Trois règles de la maison qui s'ajoutent

1. **On lit d'abord ce qu'on a sur disque.** Les dix actes uniformes OHADA sont en texte
   cherchable dans `~/.claude/outils-communs/ohada/`. Chercher en ligne avant d'avoir
   cherché en local, c'est risquer de citer une version abrogée.
2. ⛔ **Le Journal officiel ivoirien n'est pas en accès libre.** Une date de publication non
   lue au JO est une date de seconde main, et la note doit le dire.
3. **Une réponse se cite par son article.** Jamais de mémoire, même pour un texte qu'on
   croit connaître.
