# Veille reglementaire (Ibrahim)

**Schedule cron Hermes (standard 5 champs) :** `45 6 * * 3`  (Chaque mercredi, 06:45 UTC)
**Deliver :** origin (canal où l'Expert Ibrahim est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Ibrahim) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Veille reglementaire (Ibrahim) », schedule `45 6 * * 3`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Ibrahim. Regarde ce qui a changé dans la réglementation qui touche l'activité de
l'entreprise, et ne rapporte que ce qui la concerne vraiment.

1. Consulte les sources officielles du secteur et du pays qui te sont ouvertes. **Tu ne cites
   qu'une source que tu as réellement ouverte**, avec son lien. Une adresse que tu n'as pas
   ouverte ne s'écrit nulle part, ni en lien, ni en clair.
2. Pour chaque changement retenu : ce qui change, à partir de quand si le texte le dit, qui est
   concerné dans l'entreprise, et ce qu'il faudrait faire. Tu ne résumes pas un texte que tu
   n'as pas lu.
3. Sépare ce qui est **entré en vigueur** de ce qui est **annoncé**. Un projet n'est pas une
   règle.
4. Si rien de significatif n'a changé, écris-le en une ligne, ou n'écris rien du tout. Une
   veille qui rapporte quelque chose chaque semaine ne rapporte rien.

⚠️ Un texte déjà signalé ne se re-signale pas. Tiens `memory/state/veille-reglementaire.json`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
