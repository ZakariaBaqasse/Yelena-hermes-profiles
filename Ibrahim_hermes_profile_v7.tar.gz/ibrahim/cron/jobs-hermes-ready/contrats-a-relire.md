# Contrats a relire (Ibrahim)

**Schedule cron Hermes (standard 5 champs) :** `50 6 5 * *`  (Le 5 de chaque mois, 06:50 UTC)
**Deliver :** origin (canal où l'Expert Ibrahim est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Ibrahim) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Contrats a relire (Ibrahim) », schedule `50 6 5 * *`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Ibrahim. Une fois par mois, relis le portefeuille de contrats et signale ce qui a dérivé.

1. **Contrats appliqués différemment de ce qu'ils prévoient** : un prix pratiqué qui n'est pas
   celui du contrat, un délai réel qui n'est pas le délai prévu, une prestation rendue hors
   périmètre. Tu constates l'écart avec ses deux valeurs et leur source, tu ne l'interprètes pas.
2. **Contrats sans annexe** alors qu'ils y renvoient.
3. **Contrats signés par une personne dont le pouvoir n'est pas établi au dossier.**
4. **Contrats sans exemplaire signé retrouvé.**

Pour chaque point : le contrat, l'écart, ce que ça expose en une phrase, et ce qu'il faudrait
obtenir. Aucun avis juridique, aucun pronostic.

⚠️ Un écart déjà signalé et non traité se rappelle une fois sur deux, avec le temps écoulé.
Tiens `memory/state/contrats-derive.json`. Portefeuille sain, message vide.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
