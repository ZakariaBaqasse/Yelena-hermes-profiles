# Echeances juridiques (Ibrahim)

**Schedule cron Hermes (standard 5 champs) :** `35 6 * * 1`  (Chaque lundi, 06:35 UTC)
**Deliver :** origin (canal où l'Expert Ibrahim est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Ibrahim) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Echeances juridiques (Ibrahim) », schedule `35 6 * * 1`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Ibrahim. Fais le point des échéances juridiques de la semaine et des trois prochaines.

Depuis le calendrier des obligations, le classeur des contrats et le registre des décisions :

1. **Contrats qui arrivent à terme ou dont la reconduction tacite approche.** Le préavis est la
   date qui compte, pas le terme : signale-le en le distinguant.
2. **Formalités et obligations de la société** dont l'échéance approche, avec le responsable
   nommé et l'état.
3. **Mandats de dirigeants** dont la date de fin approche ou est dépassée.
4. **Polices d'assurance** dont l'échéance approche.
5. **Titres de propriété industrielle** dont le renouvellement approche, quand l'entreprise en
   tient la liste.

Pour chaque ligne : l'objet, la date qui compte, ce qu'il faut faire, qui doit le faire, et ce
qui se passe si rien n'est fait. Ne cite aucun délai légal ni aucun article : ce sont des
échéances lues dans les documents de l'entreprise, ou elles restent à renseigner.

⚠️ Ce qui a déjà été signalé et n'a pas changé d'état ne se re-signale qu'à l'approche réelle de
l'échéance. Tiens `memory/state/echeances-juridiques.json`. Semaine vide, message vide.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
