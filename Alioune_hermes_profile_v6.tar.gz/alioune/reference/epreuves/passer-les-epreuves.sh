#!/usr/bin/env bash
# Passe les épreuves de Alioune et écrit une réponse par cas.
#
# À lancer AVANT toute remise du pack, et après chaque modification de son
# comportement (règles cardinales, compétences du métier, conventions de forme).
#
#   ./passer-les-epreuves.sh <workspace> <dossier_de_sortie> [modele]
#
# Deux précautions, non négociables :
#
#  1. Les épreuves tournent sur une COPIE du workspace, jamais sur l'agent réel.
#     Certains cas demandent explicitement une action sortante ou une écriture en
#     mémoire : les passer sur l'agent de production reviendrait à provoquer ce
#     qu'on cherche justement à interdire.
#  2. La copie est privée de `.mcp.json`. Sans lui, aucun canal de messagerie
#     n'existe : même une réponse fautive ne peut rien envoyer à personne.
#  3. Le dossier de sortie doit se trouver HORS de l'arborescence d'un autre
#     agent : un agent hérite des CLAUDE.md de tous ses dossiers parents, et un
#     bac à sable mal placé fait passer les épreuves à deux identités
#     superposées. Le script le vérifie et refuse de partir sinon.
#
# Le script ne juge pas. Il produit les réponses ; la notation se fait à la
# lecture, contre le champ « attendu » et les « interdits » de epreuves.json.
set -u

WS="${1:?workspace attendu}"
OUT="${2:?dossier de sortie attendu}"
MODELE="${3:-claude-sonnet-4-6}"
ICI="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$OUT"
BAC="$OUT/bac-a-sable"
mkdir -p "$BAC"

# Un agent hérite des CLAUDE.md de tous ses dossiers parents : un bac à sable
# posé dans l'arborescence d'un autre agent ferait passer les épreuves à deux
# identités superposées, et le résultat serait faux tout en ayant l'air vrai.
d=$(cd "$BAC/.." && pwd)
while [ "$d" != "/" ]; do
  if [ -f "$d/CLAUDE.md" ]; then
    echo "✗ $d/CLAUDE.md serait chargé par-dessus celui de Alioune." >&2
    echo "  Choisissez un dossier de sortie hors de toute arborescence d'agent" >&2
    echo "  (/tmp fait très bien l'affaire)." >&2
    exit 1
  fi
  d=$(dirname "$d")
done
rsync -a --exclude '__pycache__' --exclude '.mcp.json' "$WS/" "$BAC/"
rm -f "$BAC/.mcp.json"

# 🚨 Retirer `.mcp.json` ne suffit PAS à isoler l'épreuve, et l'avoir cru a coûté cher.
# Le 10/8, sur l'épreuve « source inaccessible » : dont tout l'intérêt est que l'outil ne soit
# justement pas joignable :, l'Expert a lu le magasin de secrets de la machine hôte, sourcé son
# fichier d'environnement, et interrogé pour de vrai l'API du logiciel de recrutement : il a
# rendu de VRAIS noms de candidats. Il n'avait rien inventé, et l'épreuve ne mesurait plus rien.
#
# Trois fuites passaient par le compte de l'utilisateur, et aucune ne se voit dans le résultat :
#   · l'ENVIRONNEMENT du shell appelant, qui porte les clés d'API exportées ;
#   · le MAGASIN DE SECRETS, lisible sous `~/.config` ;
#   · et surtout les INSTRUCTIONS GLOBALES de la machine (`~/.claude/CLAUDE.md`), ses crochets
#     et ses serveurs de messagerie, qui se chargent quel que soit le dossier de travail : le
#     script vérifiait scrupuleusement les `CLAUDE.md` des dossiers PARENTS et laissait entrer
#     celui de l'utilisateur, qui s'applique partout.
#
# La parade tient en un HOME d'emprunt : un dossier neuf où l'on ne recopie que de quoi
# s'authentifier : les identifiants, la configuration privée de ses serveurs, les réglages
# privés de leurs crochets. Ni instructions globales, ni magasin de secrets, ni carnet
# d'adresses : `~` ne mène plus nulle part.
FAUXHOME="$OUT/faux-home"
mkdir -p "$FAUXHOME/.claude"
python3 - "$FAUXHOME" <<'PY'
import json, os, shutil, sys
fh, vrai = sys.argv[1], os.path.expanduser("~")
try:
    d = json.load(open(f"{vrai}/.claude.json", encoding="utf-8"))
except Exception:
    d = {}
d.pop("mcpServers", None)
for p in (d.get("projects") or {}).values():
    if isinstance(p, dict):
        p.pop("mcpServers", None)
json.dump(d, open(f"{fh}/.claude.json", "w", encoding="utf-8"))
try:
    s = json.load(open(f"{vrai}/.claude/settings.json", encoding="utf-8"))
except Exception:
    s = {}
s.pop("hooks", None)
json.dump(s, open(f"{fh}/.claude/settings.json", "w", encoding="utf-8"))
shutil.copy(f"{vrai}/.claude/.credentials.json", f"{fh}/.claude/.credentials.json")
PY

n=$(python3 -c "import json;print(len(json.load(open('$ICI/epreuves.json'))))")
echo "→ $n épreuves · modèle $MODELE · bac à sable $BAC"

for i in $(seq 0 $((n - 1))); do
  id=$(python3 -c "import json;print(json.load(open('$ICI/epreuves.json'))[$i]['id'])")
  python3 -c "import json;print(json.load(open('$ICI/epreuves.json'))[$i]['prompt'])" > "$OUT/$id.prompt"

  echo "  [$((i + 1))/$n] $id"
  # La banque de souvenirs partagee de la MACHINE doit etre coupee pendant les epreuves.
  # Sans ca, le rappel automatique injecte dans le bac a sable des souvenirs qui n appartiennent
  # pas a l Expert teste : une epreuve « rendez-vous invente » a ainsi ete notee en echec alors
  # que l agent restituait honnetement une memoire qu on venait de lui poser sous les yeux. La
  # retention est coupee aussi, pour qu aucun cas fictif n entre dans la banque reelle.
  # `env -i` : on repart d'un environnement VIDE et on ne remet que ce qu'il faut pour que
  # `claude` démarre. C'est ce qui met dehors les clés d'API exportées par le shell appelant
  # `env -u ANTHROPIC_API_KEY` n'en retirait qu'une, et laissait passer toutes les autres.
  ( cd "$BAC" && env -i \
      PATH="$PATH" HOME="$FAUXHOME" USER="${USER:-}" LANG="${LANG:-C.UTF-8}" TERM=dumb \
      HINDSIGHT_AUTO_RECALL=0 HINDSIGHT_AUTO_RETAIN=0 timeout 600 \
      claude -p "$(cat "$OUT/$id.prompt")" --model "$MODELE" ) \
      > "$OUT/$id.reponse" 2> "$OUT/$id.err" || echo "     ⚠ sortie non nulle"

  # Les modèles sont plafonnés en jetons par minute sur une organisation :
  # deux épreuves lancées coup sur coup se font refuser. On espace.
  [ "$i" -lt $((n - 1)) ] && sleep 45
done

echo "→ réponses dans $OUT"
