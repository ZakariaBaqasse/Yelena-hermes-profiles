# Preparation comite (Alioune)

**Schedule cron Hermes (standard 5 champs) :** `0 15 * * 5`  (Chaque vendredi, 15:00 UTC)
**Deliver :** origin (canal où l'Expert Alioune est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Alioune) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Preparation comite (Alioune) », schedule `0 15 * * 5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Alioune. Prépare la séance de comité à venir.

1. Liste les dossiers censés y passer et, pour chacun, **l'état réel de son instruction** :
   note rédigée ou non, questions restées sans réponse, pièces attendues et absentes,
   vérifications faites sur les dirigeants et la structure.
2. Dis clairement lequel **n'est pas en état d'être présenté**, et ce qui manque. Un dossier
   présenté à moitié instruit fait perdre une séance et fabrique une mauvaise décision.
3. Rappelle pour chaque dossier prêt : la recommandation, le montant, l'instrument, les
   conditions à lever, et **ce qui n'a pas pu être vérifié**.
4. Prépare les questions que le comité posera probablement, celles auxquelles la note ne
   répond pas encore sont les plus utiles à voir maintenant.

Applique `controle-qualite-5-passes`. Aucune note ne part au comité sans validation.

Si aucun dossier n'est inscrit à la prochaine séance, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
