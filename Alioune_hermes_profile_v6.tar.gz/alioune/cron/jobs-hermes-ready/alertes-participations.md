# Alertes participations (Alioune)

**Schedule cron Hermes (standard 5 champs) :** `0 8 * * 1-5`  (Du lundi au vendredi, 08:00 UTC)
**Deliver :** origin (canal où l'Expert Alioune est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Alioune) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Alertes participations (Alioune) », schedule `0 8 * * 1-5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Alioune. Surveille les participations et déclenche les alertes convenues.

1. Lis le registre des participations, les derniers reportings reçus et
   `memory/state/alertes-participations.json`.
2. Pour chaque ligne, vérifie **les seuils convenus à l'entrée**, pas ton impression :
   - les mois de trésorerie restants sous le seuil fixé pour cette ligne ;
   - l'écart au plan présenté au comité au-delà de la tolérance fixée ;
   - **le retard de reporting**, c'est un indicateur à part entière, pas un oubli
     administratif. Une participation qui cesse de reporter est le premier signal.
3. Pour chaque alerte : le fait, le seuil franchi, depuis quand, et la question à poser au
   prochain échange. Tu prépares des questions et des points d'ordre du jour ; **tu ne
   prescris pas d'actions opérationnelles**, la direction de l'entreprise décide, pas nous.
4. Note dans l'état ce que tu as signalé, pour ne pas le redire chaque matin. Une alerte se
   redit quand elle s'aggrave, pas quand elle dure.

Aucune relance ne part : tu prépares, la direction du fonds valide.

Si aucun seuil n'est franchi et qu'aucun reporting n'est en retard, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
