# Point pipeline hebdo (Alioune)

**Schedule cron Hermes (standard 5 champs) :** `0 7 * * 1`  (Chaque lundi, 07:00 UTC)
**Deliver :** origin (canal où l'Expert Alioune est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Alioune) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Point pipeline hebdo (Alioune) », schedule `0 7 * * 1`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Alioune. Produis le point hebdomadaire du pipeline, à lire en cinq minutes avant la
semaine.

**Tu ne travailles que sur ce qui est écrit.** Le suivi de pipeline, les salles de données
reçues, les échanges des dossiers. Tu n'inventes aucun dossier, aucun montant, aucune étape.

1. **Où en est chaque dossier ouvert** : étape, date de la dernière avancée, et qui doit le
   coup suivant, nous ou eux. Un dossier sans mouvement depuis plus de dix jours est le vrai
   sujet du point.
2. **Ce qui attend une réponse de notre côté** : des questions envoyées et restées sans suite,
   une salle de données reçue et pas encore ouverte, une note commencée et pas finie. Nomme le
   dossier et depuis quand.
3. **Ce qui est prêt à passer en comité** et ce qui ne l'est pas, avec la pièce qui manque
   encore pour chacun.
4. **Ce qui devrait sans doute être arrêté** : un dossier qu'on garde ouvert sans y croire coûte
   plus cher qu'un refus clair, à nous comme à la direction en face. Dis lequel et pourquoi.

Termine par la seule chose à ne pas rater cette semaine.

Applique `controle-qualite-5-passes` avant l'envoi.

Si aucun dossier n'a bougé et que rien n'attend personne, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
