---
name: releve-decisions
description: >
  Transforme une réunion (notes, transcript, dictée du dirigeant) en un relevé de décisions
  diffusable : ce qui a été décidé, qui fait quoi pour quand, et ce qui reste en suspens.
  Alimente automatiquement le suivi des engagements. Utiliser quand le dirigeant dit « fais le
  relevé », « compte rendu de la réunion », « qu'est-ce qui a été décidé », ou après toute
  réunion dont on possède des notes ou un enregistrement.
version: 1
maj: 2026-08-10
---

# Relevé de décisions

Le compte rendu narratif ne sert à personne : personne ne le relit, et il ne prouve rien.
Ce qui circule et engage, c'est le relevé de décisions — court, nominatif, daté.

## Structure

```
RELEVÉ DE DÉCISIONS
<Objet de la réunion> — <date> — <lieu>
Présidence : <qui> · Participants : <liste, fonctions>

DÉCISIONS
D1. <décision, formulée à l'indicatif, sans conditionnel>
D2. <…>

ACTIONS
A1. <quoi> — <qui, nommément> — <pour quand>
A2. <…>

EN SUSPENS
S1. <point non tranché> — <ce qui manque pour trancher> — <qui le fournit, pour quand>

PROCHAIN POINT : <date, format>

<visa de contrôle>
```

## Les trois opérations, dans cet ordre

**1. Séparer.** Passer la matière brute en trois piles : ce qui a été *décidé*, ce qui a été
*confié à quelqu'un*, ce qui a été *évoqué sans trancher*. Tout ce qui ne rentre dans aucune
des trois n'entre pas dans le relevé — les échanges, les arguments, les états d'âme, la
qualité de l'ambiance.

**2. Reformuler.** Chaque ligne est réécrite dans la forme du relevé, pas citée. Une décision
prise en dix minutes de discussion s'écrit en une phrase. Si on n'arrive pas à l'écrire en
une phrase, c'est qu'elle n'a pas été prise.

**3. Vérifier auprès du réel.** Les noms, les fonctions, les dates et les intitulés de
contrats ou de dossiers se contrôlent avant diffusion. Une décision correcte attribuée à la
mauvaise direction est un incident.

## Règles de rédaction

- **Indicatif, pas conditionnel.** « La Direction Financière transmet le rapport de trésorerie
  avant le 8 août », pas « il conviendrait que la Direction Financière transmette ».
- **Toujours un nom, jamais une direction seule.** « La Direction Commerciale » ne fait rien ;
  une personne fait quelque chose. Si le nom manque, écrire `⚠ responsable à désigner` — c'est
  précisément le genre de trou qui fait perdre six semaines.
- **Toujours une date.** Sans date, ce n'est pas une action, c'est une intention.
- **Ce qui n'a pas été explicitement décidé va en EN SUSPENS**, jamais en DÉCISIONS. Ne
  jamais « lisser » un désaccord en décision : c'est la faute la plus grave de l'exercice,
  parce qu'elle se découvre trois semaines plus tard, quand plus personne ne peut la corriger.
- **Ce qui a été dit hors sujet, en aparté ou off n'entre pas** dans le relevé — quelle que
  soit sa valeur informative. Ça peut remonter au dirigeant séparément, jamais dans un document
  diffusable.
- Les références à des contrats, rapports ou documents portent leur **lien cliquable**.

## Le cas du désaccord

Trois situations, trois traitements — ne jamais les confondre :

| Situation | Où ça va | Comment ça s'écrit |
|---|---|---|
| Décision prise malgré une opposition exprimée | DÉCISIONS | La décision seule. L'opposition ne figure pas au relevé, elle remonte au dirigeant à part. |
| Aucune décision, désaccord persistant | EN SUSPENS | « Point non tranché : <objet>. Positions divergentes. Arbitrage à rendre par <qui, quand>. » |
| Accord de principe, modalités non réglées | DÉCISIONS + EN SUSPENS | Le principe en décision, les modalités en suspens avec leur échéance. |

## Attribution des propos

Si le transcript n'attribue pas correctement les locuteurs — cas fréquent, surtout en
comité de direction élargi — **ne jamais deviner** : marquer `⚠ locuteur à confirmer` et
demander. Attribuer un engagement à la mauvaise personne est une faute lourde dans une
direction générale : elle crée un grief, et elle décrédibilise tous les relevés suivants.

Même règle pour les chiffres énoncés oralement : un montant entendu une fois dans un
enregistrement se vérifie avant d'être écrit, ou se marque `⚠ à confirmer`.

## Chaînage

1. Chaque ligne `ACTIONS` est poussée dans `memory/state/engagements.json` via
   `suivi-engagements`, avec `origine` = référence du relevé et son lien.
2. Chaque ligne `EN SUSPENS` avec une échéance devient également un engagement — c'est ce
   qui empêche les points non tranchés de disparaître.
3. Le relevé est soumis au dirigeant **avant** toute diffusion. Un relevé diffusé engage la
   direction générale : il ne part jamais de lui-même.
4. Le relevé nourrit la note de cadrage de la réunion suivante sur le même dossier.

## Quand le livrable n'est pas bon

- Une décision est écrite au conditionnel.
- Une action n'a pas de nom, ou pas de date, sans que le trou soit marqué.
- Un désaccord a été transformé en décision.
- Le relevé raconte la réunion au lieu de l'enregistrer.
- Il fait plus d'une page pour une réunion d'une heure.

## Gabarit

Le gabarit de ce livrable — charte graphique de l'entreprise, blocs obligatoires, emplacement
du visa — est dans [`references/gabarit.html`](references/gabarit.html), avec son rendu PDF dans
le dossier `gabarits/` du pack. Il est rempli de **données fictives** : il sert à valider la
forme, jamais à être repris tel quel. Les champs à remplir y sont signalés en orange.
