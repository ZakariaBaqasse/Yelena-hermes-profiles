---
id: Y0002
name: 00-2-deepdive-comparables
description: "Deep-dive comparables + lessons."
bucket: B
tags: [Sourcing]
version: 1
maj: 2026-08-10
---

# 00.2-Deepdive_Comparables

## Ce qu'il faut avoir sous la main
**Bienvenue 👋** — j'enrichis rapidement ta liste de comparables (startups similaires) sur **50 colonnes** : financement, équipe, produit, go-to-market, tech stack, opérations, stratégie/impact — jusqu'à 8-10 startups par session, en moins de 25 minutes.

1. **La liste de comparables à enrichir** (sortie de la skill Best_Comparables [00-1-best-comparables], ou une liste que tu me donnes directement) — max 8-10 startups par lot, sinon je te propose un découpage en plusieurs lots
2. *(optionnel)* Les colonnes à prioriser si tu veux orienter la recherche

### Objectif principal

Livrer un **tableau markdown stable** avec TOUTES les startups comparables enrichies sur **50 colonnes** en **MOINS de 25 minutes**, complétude cible 50-65%. **Limite dure : max 8-10 startups par session.** Au-delà → diviser en plusieurs sessions (nouvelle conversation par lot).


**Ce qu'elle suppose comme accès** : Apify, LinkedIn (accès), Recherche web / browse, Chaînage inter-skills (amont/aval), Google Sheets. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. Récupérer la liste [connecteur à brancher : chaînage inter-skills — récupérer automatiquement l'output de la skill Best_Comparables (00-1-best-comparables) en amont]. Si échec : demander la liste directement à l'utilisateur.
2. **Vérification de la taille du lot** : si la liste > 10 startups → proposer les lots immédiatement (ex. « Lot 1 : startups 1-8, Lot 2 : startups 9-16 »). Traiter UN seul lot par session.
3. **Dédoublonnage** : fusionner les entités identiques. Signaler les fusions.
4. **Contrôle de pertinence** : 10 sec par entité. Doute → « hors-cible — à valider » dans la colonne dédiée.
5. Confirmer le nombre de startups retenues.

### Étape 2 — Enrichissement rapide (20-23 min)

**Allocation de temps stricte :** 60 sec MAX par startup (timeout absolu). 5-8 startups : jusqu'à 90 sec. 9-10 startups (maximum) : 70 sec.

**Phase 1 (25 sec) — Données CORE via [connecteur à brancher : Apify — Crunchbase/Dealroom] :** Total Equity, Total Debt, Series, Last Equity, Last Debt, Date Last Round (obligatoire), Investors, Debt Partner, Country, Operating Region, Founding Year, Category, Secondary Category, Team Size. Colonnes Source + Statut. → 15-17 colonnes.

**Phase 2 (25 sec) — Site officiel :** Homepage (10 sec) : Tagline, Value Proposition, Primary Product. About/Team (8 sec) : Explanation, Objectives, Key Roles. Product/Pricing (7 sec) : Revenue Model, Pricing, Secondary Products, Buyer Persona. Géo : confirmer pays/siège. → 8-12 colonnes.

**Phase 3 (10 sec) — [connecteur à brancher : LinkedIn (accès), via Apify ou Unipile] :** confirmer Team Size, Key Roles, Géo. Divergence géo → « (à vérifier) ». → 1-3 colonnes.

**Principes qualité :** colonnes stratégiques : 6-12 mots min avec chiffres. Autres : 2-8 mots factuels. Formats : montants « $10M », dates « Jan 2024 », équipe « 150 ». Binaires « Yes »/« No » SEULEMENT si vérifiés — colonne > 90% même valeur = suspect → recheck par échantillon. Cellule vide si non trouvé en < 5 sec.

### Étape 3 — Double-check avant sortie (2 min)

Pour chaque startup, vérifier avant de livrer :
- ✓ Au moins 1 appel d'outil (Apify ou web) effectué — 0 appel = STOP, relancer
- ✓ Chaque chiffre financier a une URL source
- ✓ Colonne Statut remplie pour toutes les startups
- ✓ Colonnes binaires : > 90% même valeur → recheck par échantillon
- ✓ Données non confirmées → « n.d. » ou cellule vide, jamais livrées comme fait

### Étape 4 — Génération du tableau markdown stable (1 min)

**⚠️ Format obligatoire : tableau markdown UNIQUEMENT — JAMAIS de rendu interactif propriétaire, JAMAIS React, JAMAIS XML.**

Le tableau markdown est le seul format stable compatible avec la reprise automatique par les skills en aval.

En-têtes dans l'ordre exact (col 1 à 50) : Company | Total Equity Raised | Total Debt Raised | Series | Website | Date Last Round | Last Equity Raised | Last Debt Raised | Unicorn | Investors | Debt Partner | Country (HQ) | Operating Region | Founding Year | Category | Secondary Category | Team Size | Key Roles | Explanation | Primary Product | Secondary Products | Revenue model | Pricing | Buyer persona | User persona | Main target persona | Tagline | Value Proposition | Primary acquisition channels | Secondary acquisition channels | Partners | Web | IOS App | Android App | Hardware | AI & Machine learning | Blockchain | 3rd parties | Connectivity | Customer service | Problème | Ressources | Objectives | Activités | KPIs Court terme | KPIs Long terme | Impact | Success story | Source | Statut

Règles : 1 ligne par startup (TOUTES présentes) — cellule vide si non vérifiée (jamais « N/A », jamais « - ») — colonne Source : URL + date — colonne Statut : « Actif » / « Racheté par X » / « Fermé ».

**Impératifs absolus du tableau markdown :**
- 1 ligne par startup avec 50 colonnes (même si certaines vides)
- TOUTES les startups de la liste présentes dans le tableau
- Ordre des colonnes : 1-50 selon la liste ci-dessus
- Cellules vides : colonne vide — pas « N/A », pas « - »
- Colonne « Source » : URL + date pour chaque chiffre financier (vide si non vérifiable)
- Colonne « Statut » : « Actif » / « Racheté par X (produit maintenu ou arrêté) » / « Fermé »
- JAMAIS de rendu interactif propriétaire, JAMAIS de code React, JAMAIS de XML, JAMAIS d'export CSV

### Étape 5 — Sortie finale (30 sec)

### ✅ Enrichissement terminé

📊 **[X] startups enrichies (50 colonnes)** | ⏱️ **[X] min [X] sec** | 📈 **Complétude moyenne : [XX]%**

#### 👇 Base de données complète (50 colonnes)

[TABLEAU MARKDOWN — 50 colonnes — TOUTES LES STARTUPS]

#### 📥 Export

Le tableau markdown est l'unique format de livraison — **aucun fichier n'est généré par cette skill**. Pour l'exploiter en tableur : copier-coller dans [connecteur à brancher : Google Sheets — écriture automatique du tableau dans un fichier de suivi, en alternative au copier-coller manuel] ou Excel.

#### 📊 Statistiques

- **Complétude par bloc :**
  - Financement (13 col) : [XX]%
  - Équipe (5 col) : [XX]%
  - Produit/Value (9 col) : [XX]%
  - GTM (3 col) : [XX]%
  - Tech Stack (9 col) : [XX]%
  - Opérations (2 col) : [XX]%
  - Stratégie/KPIs (7 col) : [XX]%
- **Top 3 startups mieux documentées :**
  1. [Startup A] : [XX]% complétude
  2. [Startup B] : [XX]% complétude
  3. [Startup C] : [XX]% complétude
- **Colonnes les mieux remplies :**
  - [Colonne X] : [XX]% remplie
  - [Colonne Y] : [XX]% remplie
  - [Colonne Z] : [XX]% remplie

#### ⚠️ Données limitées

[Liste des startups < 40% complétude avec raison : « Early stage », « Stealth mode », « Site minimal »]

**Prochaine étape :** skill Features_Comparables (00-3-features-comparables) pour l'analyse comparative.

### Standard qualité — sourcing / comparables

*(standard commun à la suite Sourcing/Comparables, juin 2026)*

**Outils (à activer par défaut)**
1. [connecteur à brancher : recherche web / Apify — Crunchbase / Dealroom / LinkedIn, vérification et sourcing des données comparables avant d'écrire un chiffre]. Sans outil, tu devines de mémoire (données périmées/fausses) → tu dois pouvoir VÉRIFIER avant d'écrire.
2. [connecteur à brancher : chaînage inter-skills — récupérer automatiquement l'output de la skill amont (00-1-best-comparables) et transmettre le tableau enrichi à l'étape avale (00-3-features-comparables), au lieu de dépendre d'un copier-coller manuel].

**Fiabilité**
3. **Zéro invention.** Jamais un chiffre, un montant, une valo, un nom, un site, un lien ou un score sans source. Non vérifiable → « n.d. » / case vide / « à confirmer ». Une case vide vaut mieux qu'une donnée fausse.
4. **Données reçues d'abord.** Travaille à partir de l'input (output de la skill amont) ; ne remplis une case qu'avec ce que tu peux vérifier, jamais avec ce que le modèle « sait ».
5. **Date + source sur chaque chiffre.** Prends la donnée la plus récente ; signale si > 18 mois.
6. **Pertinence au critère.** Si une entité ne colle pas à la catégorie cible → « hors-cible » au lieu de la traiter comme un pair.
7. **Dédoublonne** (rebrand, filiale, produit vs société = une seule entité).
8. **Géo & identité exactes** (pays/siège réel, homonymes), double-source si possible.
9. **Statut opérationnel** : actif / racheté (le produit survit-il ?) / mort-absorbé — signale-le ; ne traite jamais une boîte morte comme un acteur vivant.
10. **Pas de livrable fantôme.** Ne prétends jamais avoir produit une image, un fichier, un export ou un lien que tu ne peux pas réellement générer. Sors ce que tu sais produire (tableau markdown) et passe le relais à la skill compétente.
11. **Signale tes incertitudes** (faible confiance, donnée contradictoire, case devinée).

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Taille de lot — limite dure** : MAX 8-10 startups par session. Si la liste dépasse 10 → proposer les lots avant de commencer. Ne jamais lancer sur 20+ entités d'un coup.
- **Nouvelle conversation en cas de blocage** : si la recherche reste bloquée sans output → ouvrir une NOUVELLE conversation. Relancer le même échange est inutile.
- **Format stable obligatoire** : sortie = tableau markdown UNIQUEMENT. JAMAIS un rendu interactif propriétaire, JAMAIS du code React, JAMAIS du XML. Seul format compatible avec la reprise automatique par les skills en aval.
- **Vérification avant sortie** : si le résultat revient en quelques secondes sans appel d'outil → STOP. Relancer avec les outils actifs. Aucune donnée de mémoire.
- **Mode silencieux** : pas de messages intermédiaires, enrichir directement.
- **[connecteur à brancher : Apify — priorité pour scraper Crunchbase, Dealroom et LinkedIn]**. Réserver la recherche web pour les sites officiels, homepages et médias non-scrapables.
- **Timeouts ultra-stricts** : 60 sec MAX par startup, passer immédiatement à la suivante.
- **Stratégie breadth-first** : scanner rapidement TOUTES les sources, remplir le maximum de colonnes même partiellement.
- **Cellule vide acceptable** : mieux vaut 50 colonnes à 50% qu'attendre la perfection.
- **Pas d'invention** : cellule vide si donnée introuvable — JAMAIS de N/A, JAMAIS de tiret.
- **Récence des montants** : remplir TOUJOURS la colonne « Date Last Round » pour chaque montant. > 18 mois → suffixer « (à revérifier) ». Source récente presse/site officiel > agrégat Crunchbase.
- **Traçabilité financière** : colonne « Source » obligatoire pour tout chiffre financier (URL + date). Sans URL vérifiable → cellule vide.
- **Statut opérationnel** : colonne « Statut » obligatoire : « Actif » / « Racheté par [X] (produit maintenu) » / « Racheté par [X] (produit arrêté) » / « Fermé ».
- **Contrôle de pertinence** : vérifier en 10 sec que l'entité correspond au critère cible. Sinon : « hors-cible — à valider » dans la colonne dédiée.
- **Dédoublonnage** : fusionner les entités identiques (rebrand / filiale / produit vs société mère). Une ligne par entité réelle.
- **Géo à double source** : site officiel + LinkedIn. Divergence → « (à vérifier) ».
- **Complétude sur cellules vérifiées uniquement** : cible 50-65% sur cellules VÉRIFIÉES. Cellule vide honnête > cellule pleine fausse.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
**Liste de plus de 20 startups :**
```
⚠️ [X] startups à enrichir
Temps estimé : ~[X] min

Options :
1. Session complète → ~[X] min (recommandé)
2. Top 15 startups (funding/traction) → 25 min
3. Batch de 15 → Plusieurs sessions

Votre choix ? (défaut : option 1)
```

**Timeout dépassé (22 min) :** réduire à 40 sec/startup restante, [connecteur à brancher : Apify — Crunchbase] + Homepage uniquement, colonnes CORE prioritaires, terminer avant 25 min.

**Startup avec données très limitées :** remplir les colonnes disponibles (même 20-30%), inclure dans le tableau avec une note, pas de message d'erreur.

---

## Détails complémentaires
### Gestion du temps

Si après 22 min, progression < 75% : passer à 40 sec max/startup restante, sources primaires uniquement ([connecteur à brancher : Apify — Crunchbase] + Homepage), terminer avant 25 min.

### Tâche

Enrichir max 8-10 startups avec **50 colonnes** en < 25 minutes et livrer un **tableau markdown stable**. JAMAIS de rendu interactif propriétaire, JAMAIS d'export CSV.

### Structure des 50 colonnes

- **Bloc 1 — Financement (13 col.)** : 1. Company · 2. Total Equity Raised · 3. Total Debt Raised · 4. Series · 5. Website · 6. Date Last Round · 7. Last Equity Raised · 8. Last Debt Raised · 9. Unicorn · 10. Investors · 11. Debt Partner · 12. Country (HQ) · 13. Operating Region
- **Bloc 2 — Équipe (5 col.)** : 14. Founding Year · 15. Category · 16. Secondary Category · 17. Team Size · 18. Key Roles
- **Bloc 3 — Produit & Value (9 col.)** : 19. Explanation · 20. Primary Product · 21. Secondary Products · 22. Revenue model · 23. Pricing · 24. Buyer persona · 25. User persona · 26. Main target persona · 27. Tagline
- **Bloc 4 — Go-to-Market (3 col.)** : 28. Value Proposition · 29. Primary acquisition channels · 30. Secondary acquisition channels
- **Bloc 5 — Tech Stack (9 col.)** : 31. Partners · 32. Web · 33. IOS App · 34. Android App · 35. Hardware · 36. AI & Machine learning · 37. Blockchain · 38. 3rd parties · 39. Connectivity
- **Bloc 6 — Opérations (2 col.)** : 40. Customer service · 41. Problème
- **Bloc 7 — Stratégie & KPIs (7 col.)** : 42. Ressources · 43. Objectives · 44. Activités · 45. KPIs Court terme · 46. KPIs Long terme · 47. Impact · 48. Success story
- **Bloc 8 — Qualité & Audit (2 col.)** : 49. Source (URL + date de consultation — obligatoire pour tout chiffre financier) · 50. Statut (Actif / Racheté par X produit maintenu ou arrêté / Fermé)
