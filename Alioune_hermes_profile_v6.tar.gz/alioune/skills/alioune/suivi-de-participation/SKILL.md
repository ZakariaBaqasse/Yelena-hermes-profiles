---
id: Y0384
name: suivi-de-participation
description: "Tient la ligne après l'investissement : collecte du reporting périodique, mise à jour de cinq indicateurs stables et de la trésorerie en mois, comparaison au plan présenté au comité, détection mécanique des signaux qui appellent une conversation, préparation des points de suivi et des conseils — sans jamais décider à la place de la direction ni fabriquer un seuil d'alerte."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Suivi de participation — voir venir, sans piloter à la place de la direction

## Ce qu'il faut avoir sous la main
- **La participation** concernée et le tour dont elle sort (montant, date, ticket du fonds).
- **Les cinq indicateurs suivis**, tels qu'ils ont été convenus à l'entrée — s'ils n'ont jamais été fixés, dis-le, je le signale.
- **Le reporting reçu** depuis le dernier point : chiffres, tableau, message WhatsApp de la direction, ce que tu as.
- **Le plan présenté au comité** au moment de l'investissement (trajectoire attendue sur les mêmes indicateurs, si disponible).
- **Les seuils d'alerte** déjà convenus — mois de trésorerie minimum, écart au plan tolérable, délai de retard de reporting acceptable — ou l'absence de seuils, ce qui est aussi une information.
- **La date du dernier point** avec la direction et ce qui en était sorti.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Vérifier la fraîcheur du reporting avant tout calcul

Avant de mettre à jour un seul indicateur, regarde une chose : le reporting est-il arrivé quand il devait arriver, et dans le format convenu. Un retard n'est pas un manquement administratif qu'on relance poliment dans trois semaines — c'est déjà un signal, au même titre qu'un chiffre qui se dégrade. Une direction qui reporte en retard ou de moins en moins souvent est en train de dire quelque chose, même si elle ne le formule pas.

Le retard de reporting se traite comme un **indicateur à part entière**, avec son propre seuil d'alerte fixé à l'entrée (`⟦délai acceptable à renseigner⟧`). S'il n'a jamais été fixé, tu le signales — c'est un trou à combler avant le prochain tour, pas une excuse pour ne rien mesurer.

Si le reporting attendu n'est pas arrivé du tout, tu le dis en premier, avant toute autre section de la fiche, et tu continues avec ce que tu as par ailleurs.

### Étape 2 — Mettre à jour les cinq indicateurs et lire leur tendance, pas leur niveau

Résiste à l'envie d'en suivre quarante. Le suivi tient sur **cinq indicateurs**, choisis à l'entrée et stables dans le temps — s'ils changent à chaque point, la comparaison dans le temps devient impossible et le suivi perd son intérêt. S'ils n'ont jamais été arrêtés formellement, tu le signales explicitement et tu proposes de les fixer avant d'aller plus loin ; tu ne les invente pas à leur place.

Pour chacun : la valeur actuelle, l'historique sur les périodes disponibles, et la **tendance** — en hausse, en baisse, stable — sur au moins trois périodes quand elles existent. Un point isolé ne dit rien ; une tendance sur trois périodes dit ce qu'un point ne dira jamais. Une valeur qui semble bonne mais qui décroît trois fois de suite pèse plus qu'une valeur médiocre mais stable.

### Étape 3 — Calculer la trésorerie en mois et projeter la date de rupture

À partir de la trésorerie disponible et du rythme de consommation observé sur les dernières périodes (le burn), calcule le nombre de mois de trésorerie restants et la date de rupture projetée si rien ne change. Ce calcul se fait sur des données reçues, jamais sur une hypothèse de rythme non communiquée — si le burn n'est pas donné ou n'est pas calculable à partir de ce que tu as, tu le marques `[à confirmer]` plutôt que d'estimer un rythme plausible.

Une trésorerie qui descend sous le seuil convenu (`⟦mois minimum à renseigner⟧`) déclenche l'alerte correspondante, indépendamment de la performance par ailleurs — une participation qui grandit bien et qui manque de cash reste une participation en danger de court terme.

### Étape 4 — Comparer au plan présenté au comité

Reprends la trajectoire attendue sur les mêmes indicateurs, telle qu'elle a été présentée au moment de l'investissement, et mesure l'écart réel/plan sur chacun. L'écart se lit en évolution, pas en absolu isolé : une participation à 20 % sous son plan qui rattrape du terrain chaque période raconte une histoire différente d'une participation à 5 % sous son plan qui s'écarte un peu plus à chaque point.

Si le plan initial n'a jamais été formalisé ou n'est pas disponible, tu le dis — l'écart au plan devient alors non calculable, et la fiche le signale plutôt que de comparer à une trajectoire supposée.

### Étape 5 — Déclencher les alertes mécaniquement, sur les seuils convenus

Une alerte se déclenche parce qu'un seuil fixé à l'avance est franchi — mois de trésorerie, écart au plan, retard de reporting — jamais parce que la situation « donne une mauvaise impression ». L'alerte au ressenti est le piège classique : elle sonne trop tard sur la participation qu'on aime bien et trop tôt sur celle qu'on connaît moins.

Pour chaque alerte déclenchée : l'indicateur concerné, la valeur observée, le seuil qui l'a produite, et depuis quand. Si aucun seuil n'a été convenu pour un indicateur donné, tu ne déclenches rien sur cet indicateur — tu signales l'absence de seuil comme un manque à combler, pas comme une alerte implicite.

### Étape 6 — Préparer le point de suivi, sans franchir la ligne du rôle

À partir des alertes et des tendances, prépare les **questions et points d'ordre du jour** à porter au prochain échange avec la direction ou au prochain conseil — pas des instructions, pas des décisions opérationnelles. « Pourquoi le taux de X a-t-il décroché trois périodes de suite » est une question d'actionnaire ; « recrutez tel profil » ou « arrêtez cette dépense » ne l'est pas, même si la tentation est grande quand le signal est net.

Une note de suivi qui prescrit des actions opérationnelles à la direction sort de son rôle et le dit explicitement si elle s'en approche — le suivi éclaire la décision de l'entreprise, il ne la remplace pas. Signale, si pertinent, ce qui relève d'un point à traiter en tête-à-tête avec le dirigeant plutôt qu'en conseil formel — certains sujets (tension d'équipe, désaccord entre fondateurs, retard de trésorerie personnel) se traitent mieux hors compte rendu écrit.

### Étape 7 — Tenir l'historique des décisions et des engagements

Ajoute à la fiche ce qui a été décidé ou promis au point précédent, de part et d'autre — un engagement de la direction (livrer tel chiffre, corriger tel indicateur d'ici telle échéance) et un engagement du fonds (introduire tel contact, valider tel financement complémentaire). Au point suivant, tu vérifies si l'engagement a été tenu avant d'en prendre un nouveau : un suivi qui accumule des promesses sans jamais vérifier si les précédentes ont été honorées perd toute valeur d'alerte.

## Format de sortie
- **Livrable** : la fiche de suivi de participation — les cinq indicateurs avec historique et tendance, la trésorerie en mois et la date de rupture projetée, l'écart au plan présenté au comité, les alertes déclenchées avec le seuil qui les a produites, les points à porter au prochain échange, l'historique des décisions et engagements pris de part et d'autre, et la liste des données non reçues.
- **Structure** : Markdown clair — answer-first (les alertes déclenchées et le retard éventuel de reporting d'abord, le détail des indicateurs ensuite) ; un tableau pour les cinq indicateurs et leur tendance, un tableau pour les alertes avec seuil et valeur observée.
- **Longueur** : proportionnée à la fréquence du suivi — une fiche tient en une à deux pages ; elle s'allège si peu de données sont arrivées, elle ne s'étoffe pas artificiellement.
- **Les seuils sont un input**, pas une production : la skill livre la structure de l'alerte (indicateur, question à trancher, mécanisme de déclenchement) ; la **valeur** du seuil vient du fonds ou du comité et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun chiffre de trésorerie, de burn, d'écart ou de seuil inventé. Une donnée manquante est marquée `[à confirmer]`, jamais remplacée par une estimation plausible.
- **Toute relance de la direction est préparée, jamais envoyée** sans validation explicite de l'utilisateur.

## Règles
1. **L'absence de reporting est un signal, pas un manquement administratif.** Un retard se mesure et s'alerte comme n'importe quel autre indicateur, avec son propre seuil convenu à l'entrée. Tu ne relances jamais poliment en silence : tu signales le retard dans la fiche dès qu'il dépasse le seuil.
2. **Cinq indicateurs, stables dans le temps, lus en tendance.** Tu ne rajoutes pas d'indicateur au fil des points sans que cela soit une décision explicite du fonds ; tu ne juges jamais un indicateur sur un seul point quand l'historique existe sur plusieurs périodes.
3. **0 chiffre inventé.** Aucune valeur de trésorerie, de burn, de date de rupture, d'écart au plan ou de seuil d'alerte n'est produite sans être fournie ou calculée à partir de données reçues : `⟦à renseigner⟧` ou `[à confirmer]` sinon.
4. **Les alertes se déclenchent mécaniquement sur seuil, jamais au ressenti.** Si un seuil n'existe pas pour un indicateur, tu ne déclenches rien sur cet indicateur — tu signales le manque de seuil, tu ne compenses pas par une appréciation qualitative déguisée en alerte.
5. **Le rôle d'actionnaire n'est pas le rôle de dirigeant.** Tu prépares des questions, des alertes et des points d'ordre du jour ; tu ne rédiges jamais une instruction opérationnelle à la direction. Si une alerte appelle une action évidente, tu la formules en question à poser, pas en décision à exécuter.
6. **Le canal de reporting fait partie du signal.** Une direction qui reportait par tableau structuré et qui bascule sur des messages WhatsApp épars, ou l'inverse, dit quelque chose sur son organisation interne — tu le notes plutôt que de l'ignorer parce que le contenu chiffré est par ailleurs correct.
7. **Un engagement pris ne se referme pas de lui-même.** Tu vérifies au point suivant si l'engagement précédent — du fonds ou de la direction — a été tenu, avant d'en enregistrer un nouveau.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; relancer la direction, convoquer un conseil ou communiquer une alerte à un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une participation ne fuite jamais vers le dossier d'une autre participation traitée dans la même conversation.

## Cas limites
- **Reporting jamais reçu depuis le dernier point** — tu le signales en tête de fiche, avant toute autre section, et tu produis le reste sur la base des données déjà disponibles.
- **Indicateurs jamais fixés à l'entrée** — tu le dis explicitement, tu ne choisis pas cinq indicateurs à la place du fonds, et tu proposes de les arrêter avant le prochain point.
- **Seuils d'alerte jamais convenus** — tu livres la fiche avec la structure d'alerte et les seuils en `⟦à renseigner⟧`, tu ne déclenches aucune alerte sur ces indicateurs, et tu signales le manque comme prioritaire.
- **Plan initial introuvable** — l'écart au plan devient non calculable ; tu le marques et tu continues sur le reste plutôt que de comparer à une trajectoire supposée.
- **Burn ou trésorerie non communiqués ou incohérents** — tu marques le calcul `[à confirmer]`, tu ne projettes pas de date de rupture sur un rythme de consommation deviné.
- **Reporting reçu par un canal informel (WhatsApp, message vocal, tableau non structuré)** — tu l'exploites comme n'importe quelle source reçue, tu notes le canal, tu ne le rejettes pas au motif qu'il n'est pas structuré.
- **Signal net appelant une action opérationnelle évidente** — tu le formules en question à poser à la direction au prochain point, jamais en instruction.
- **Désaccord entre co-investisseurs sur la lecture d'un indicateur** — tu exposes les deux lectures et demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (renégociation de conditions, décision d'investissement complémentaire, valorisation) — tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi de la relance, convocation du conseil, communication d'une alerte) — tu prépares le contenu et tu t'arrêtes pour validation humaine.
