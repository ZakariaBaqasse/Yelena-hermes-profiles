---
id: Y0151
name: exec-summary
description: "Executive summary startup 1 page."
bucket: A
tags: [Fundraising]
version: 1
maj: 2026-08-10
---

# Executive Summary

## Ce qu'il faut avoir sous la main
1. L'**audience cible** (Partners / Comité d'investissement / Client-Prospect / Board-LPs) ;
2. Le **type de document** (analyse de pitch / due diligence / proposition commerciale RFP / portfolio update) ;
3. Les **documents sources disponibles** (données brutes, chiffres, contexte à synthétiser).

## Process
[Liste numérotée des actions]

### PROCHAINES ÉTAPES

[Liste numérotée timeline DD/décision]

### PIPELINE & OPPORTUNITÉS

[Formulations textuelles des deals en cours]

### WORKFLOW DE GÉNÉRATION

### ÉTAPE 1 : Questions initiales à l'utilisateur

Poser systématiquement (déjà couvertes par le bloc **Démarrage** ci-dessus si pas encore fournies) :

1. **Audience cible** ? (Partners / Comité / Client / Board)
2. **Type de document** ? (Pitch analysis / DD / RFP / Portfolio update)
3. **Documents sources disponibles** ? (Confirmer les pièces jointes/données)

### ÉTAPE 2 : Analyse documents

- Lire INTÉGRALEMENT les documents
- Extraire données chiffrées précises
- Identifier structure narrative optimale
- Noter sources pour citations

### ÉTAPE 3 : Rédaction et affichage

**OBLIGATOIRE : Afficher d'abord le contenu COMPLET dans la conversation**

**Checklist avant rédaction :**

- ✅ Structure adaptée à l'audience validée
- ✅ Aucun emoji dans le contenu
- ✅ Aucun séparateur `---` entre sections
- ✅ Aucune référence au logo
- ✅ Ton professionnel strict
- ✅ **Formulations textuelles élégantes pour les données** (pas de tableaux dans exports)
- ✅ Citations sources préparées

**Pendant rédaction :**

- Paragraphes courts (3-4 lignes max)
- Bullets pour listes
- **Formulations textuelles pour données comparatives** (pas de tableaux)
- **Bold** pour highlights
- Citations sources systématiques (mentionner explicitement la source de chaque donnée)

**Format d'affichage dans la conversation :**

Présenter le document complet avec :

- Titre clair indiquant qu'il s'agit du contenu à valider
- Contenu intégral formaté
- Note finale indiquant que les fichiers vont être générés

### ÉTAPE 4 : Génération fichiers

**UNIQUEMENT APRÈS avoir affiché le contenu dans la conversation**

Générer SIMULTANÉMENT :

1. **Fichier Word (.docx)** - Nom : `Executive_Summary_[Projet]_[Date].docx`
2. **Fichier PDF (.pdf)** - Nom : `Executive_Summary_[Projet]_[Date].pdf`

**Génération :** convertir le contenu Markdown validé (sans tableaux) en ces deux fichiers, en respectant strictement le nommage ci-dessus.

**Important pour les exports :**

- PAS de tableaux HTML ou Markdown
- Formulations textuelles élégantes uniquement
- Format sobre et corporate
- Ne doit PAS ressembler à du ChatGPT

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis) — les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
### ❌ CE QUI EST STRICTEMENT INTERDIT

1. **AUCUN emoji** dans le contenu principal (sauf interaction conversationnelle avec l'utilisateur)
2. **AUCUN séparateur** `---` (style ChatGPT à éviter absolument)
3. **AUCUNE référence à un logo** (jamais mentionner de logo dans les documents)
4. **AUCUN ton familier** ou conversationnel dans les documents
5. **AUCUNE formulation marketing** ou "punchy"
6. **AUCUN tableau** dans les fichiers Word/PDF (impossible à quadriller correctement)

### ✅ CE QUI EST OBLIGATOIRE

1. **Afficher d'abord le contenu COMPLET dans la conversation** avant de générer les fichiers
2. **Ton professionnel strict** : langage corporate, factuel, orienté business
3. **Structure hiérarchique claire** : titres `#`, `##`, `###` uniquement
4. **Paragraphes courts** : 3-4 lignes maximum
5. **Bullets pour listes** : structuration visuelle optimale
6. **Formulations textuelles élégantes** pour les données chiffrées (pas de tableaux dans exports)
7. **Format qui ne ressemble PAS à du ChatGPT** : sobre, corporate, professionnel

### PRINCIPE DIRECTEUR

**Un executive summary professionnel doit pouvoir être imprimé, posé sur le bureau d'un décideur et être immédiatement compris, crédible et actionnable. Le format doit être irréprochable, sobre, orienté business et ne JAMAIS ressembler à une conversation ChatGPT.**

Le document ne doit PAS contenir de tableaux (impossible à quadriller correctement), mais des formulations textuelles élégantes qui présentent les données de manière fluide et professionnelle.

**Workflow impératif :**

1. Afficher le contenu COMPLET dans la conversation
2. Attendre validation implicite
3. Générer les fichiers Word + PDF (sans tableaux, formulations textuelles uniquement)

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne peut servir qu'à la startup dont elle provient, et une source consultée pour un dossier ne s'invoque pas dans un autre.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### FORMAT DE DOCUMENT PROFESSIONNEL

### Page de garde minimaliste

```
# [TITRE PRINCIPAL EN MAJUSCULES]

Executive Summary - [Type de document]
Préparé pour : [Destinataire]
Date : [Date]

```

### Structure générale (sans séparateurs ---)

```
# TITRE PRINCIPAL

Metadata du document

### PREMIÈRE SECTION

Contenu de la section...

### Sous-section si nécessaire

Détails...

### DEUXIÈME SECTION

Contenu...

```

**Important** : Utiliser UNIQUEMENT la hiérarchie de titres (#, ##, ###) pour structurer. PAS de lignes `---` entre les sections.

### FORMATAGE DES DONNÉES CHIFFRÉES

### DANS LA CONVERSATION : Tableaux autorisés

Pour l'affichage dans la conversation, tu peux utiliser des tableaux Markdown standard :

```
| Colonne 1 | Colonne 2 | Colonne 3 |
|-----------|-----------|-----------|
| Donnée A  | Donnée B  | Donnée C  |

```

### DANS LES FICHIERS WORD/PDF : Formulations textuelles UNIQUEMENT

**Interdiction stricte des tableaux** dans les exports. Remplacer par des formulations élégantes :

❌ **INTERDIT dans fichiers :**

```
| Métrique | Valeur |
|----------|--------|
| Revenue | 2M€ |

```

✅ **CORRECT dans fichiers :**

```
**Performance financière** : Le chiffre d'affaires s'établit à 2 M€ avec une croissance annuelle de 150%. La marge brute atteint 65% et le point mort est projeté au T3 2026.

```

**Autre exemple élégant :**

```
L'infrastructure du studio affiche des résultats tangibles depuis 2022 : 18 startups lancées dans des secteurs variés (agritech, fintech, healthtech, logistique), 7,5 M€ de financements levés avec 10 startups bénéficiant de 750 k€ chacune en pré-seed, 4 startups en cours de seed pour des montants supérieurs à 1 M€ chacune, une valorisation combinée de portefeuille de 25,3 M€, et une part de marché de 66% sur les financements early-stage en Côte d'Ivoire.

```

**Formulation comparative élégante :**

```
La différenciation entre modèle incubateur et Venture Studio est structurante. Là où l'incubateur intervient sur des projets existants via un accompagnement ponctuel, sans prise d'equity et avec un time-to-seed moyen de 36 mois, le Venture Studio identifie d'abord des problèmes structurants, co-fonde les entreprises de manière opérationnelle, investit du capital et partage le risque, déploie une équipe CxO mutualisée à temps plein, et réduit le time-to-seed à 10,7 mois.

```

**Formulation budgétaire élégante :**

```
Le budget global sur 5 ans s'établit à 7 M€, réparti comme suit : en année 1, 100 k€ pour la licence Playbook du programme, 100 k€ pour la licence Playbook interne, 200 k€ pour la plateforme IA, 800 k€ pour les ressources humaines, bureaux, opérations et événements, et 200 k€ pour le volet legal et structuration, soit un total de 1,4 M€. Pour les années 2 à 5, le budget annuel récurrent est de 1,4 M€ (400 k€ de licences playbooks et IA, 1 M€ pour RH et opérations), portant le budget total sur 5 ans à 7 M€.

```

### STRUCTURES PAR AUDIENCE

### STRUCTURE 1 : Client / Prospect (RFP/Proposition commerciale)

```
# [TITRE PROPOSITION]

Executive Summary - Proposition Technique et Financière
Préparé pour : [Client]
Date : [Date]

### SYNTHÈSE EXÉCUTIVE

[2-3 paragraphes : enjeu client, solution proposée, valeur ajoutée]

### COMPRÉHENSION DU BESOIN

### Contexte stratégique

[Analyse situation client]

### Ambition

[Objectifs identifiés]

### Périmètre

[Scope du projet]

### NOTRE PROPOSITION DE VALEUR

### [Titre différenciateur]

[Description infrastructure/expertise/track record]

[Formulations textuelles élégantes pour les métriques]

### Différenciation

[En quoi la proposition se distingue]

[Formulations comparatives élégantes]

### APPROCHE MÉTHODOLOGIQUE

### [Titre méthodologie]

[Description phases/étapes]

[Liste structurée ou formulation narrative]

### LIVRABLES & INFRASTRUCTURE

[Liste structurée des livrables tangibles]

### TIMELINE DE MISE EN ŒUVRE

[Formulation textuelle ou liste structurée des phases avec durées]

### PROPOSITION FINANCIÈRE

### Budget global

[Formulation textuelle élégante des postes budgétaires]

### Options

[Description options de paiement/accompagnement]

### RETOUR SUR INVESTISSEMENT

[Hypothèses et projections chiffrées formulées en texte]

[Valorisations/exits formulées élégamment]

### IMPACT ATTENDU

[Bénéfices quantifiables et qualitatifs]

### EXPERTISE & RÉFÉRENCES

[Équipe, partenaires, track record]

### PROPRIÉTÉ INTELLECTUELLE & DURABILITÉ

[Droits d'usage, pérennité]

### POURQUOI [ORGANISATION]

[Avantages compétitifs - liste bullets]

### CONTACT

[Informations contact]

[Note finale si pertinent]

```

### STRUCTURE 2 : Partners / Comité d'Investissement

```
# [TITRE STARTUP/PROJET]

Executive Summary - Investment Committee
Préparé pour : [Organisation]
Date : [Date]

### SYNTHÈSE STRATÉGIQUE

[3 paragraphes : problème, solution, opportunité]

### POINTS CLÉS

Liste à puces des éléments critiques :
- **Marché** : [données formulées en texte]
- **Produit** : [value prop]
- **Traction** : [métriques formulées en texte]
- **Équipe** : [profils]
- **Financement** : [besoin/utilisation]

### ANALYSE FINANCIÈRE

[Formulations textuelles élégantes des métriques historiques + projections]

### Hypothèses

[Liste hypothèses clés]

### ANALYSE DE RISQUE

Liste structurée :
- **[Risque 1]** : Description → Mitigation : [Action]
- **[Risque 2]** : Description → Mitigation : [Action]

### RECOMMANDATION

**[GO / NO-GO / CONDITIONAL]**

[Justification en 2-4 paragraphes structurés]

### Conditions (si pertinent)

[Liste conditions]

### CONTACT

[Informations]

```

### STRUCTURE 3 : Portfolio Update / Board

```
# PORTFOLIO UPDATE - [PÉRIODE]

Executive Summary - Portfolio Performance
Préparé pour : [Board/LPs]
Date : [Date]

### SYNTHÈSE DE PÉRIODE

[Vue d'ensemble performance, highlights]

### MÉTRIQUES GLOBALES PORTEFEUILLE

[Formulations textuelles élégantes des indicateurs clés avec évolutions]

### PERFORMANCE PAR STARTUP

[Formulations textuelles par startup : statut, métriques, commentaires]

### ÉVÉNEMENTS MARQUANTS

### Levées de fonds

[Liste]

### Exits

[Liste]

### Pivots/Ajustements

[Liste]

### RISQUES & ALERTES

[Liste structurée avec plans d'action]

### RECOMMANDATIONS BOARD

[Liste numérotée]

### CONTACT

[Informations]

```

### EXEMPLES DE FORMULATIONS ÉLÉGANTES

### ✅ DONNÉES CHIFFRÉES (remplaçant tableaux)

**Performance startup :**

```
La startup affiche une croissance mensuelle de 25% avec un ARR actuel de 450 k€. Le CAC s'établit à 120€ pour une LTV de 1 800€, soit un ratio LTV/CAC de 15. L'équipe compte 12 collaborateurs dont 8 profils tech. La trésorerie actuelle permet une runway de 18 mois.

```

**Budget détaillé :**

```
L'investissement requis pour la phase seed s'élève à 2 M€, décomposé comme suit : 800 k€ consacrés au développement produit et infrastructure technique, 600 k€ pour le déploiement commercial et l'acquisition client, 400 k€ pour le renforcement de l'équipe avec 6 recrutements clés (2 tech, 2 sales, 1 product, 1 ops), et 200 k€ de réserve opérationnelle. Cette structure permet d'atteindre le prochain jalon de 2 M€ d'ARR sous 24 mois.

```

**Comparaison modèles :**

```
Le Venture Studio se distingue fondamentalement de l'incubateur traditionnel sur cinq dimensions critiques. Premièrement, le point d'entrée : le studio identifie des problèmes structurants avant de créer les solutions, là où l'incubateur accompagne des projets déjà constitués. Deuxièmement, le rôle : co-fondation opérationnelle versus mentorat ponctuel. Troisièmement, le risque : le studio investit du capital et prend de l'equity, partageant ainsi le risque entrepreneurial. Quatrièmement, le support : une équipe CxO mutualisée à temps plein versus des formations et du mentorat. Cinquièmement, la temporalité : un time-to-seed de 10,7 mois contre 36 mois en moyenne pour le parcours incubateur classique.

```

### ✅ FORMULATIONS PROFESSIONNELLES

- "Cette proposition présente l'approche méthodologique pour le lancement d'un Venture Studio au Bénin."
- "L'analyse financière démontre une solidité structurelle avec des marges progressives et un chemin clair vers la rentabilité."
- "L'investissement recommandé s'élève à 2 M€ en seed, structuré autour de quatre postes stratégiques."
- "L'équipe fondatrice dispose d'une expertise sectorielle cumulée de 25 années, dont 15 années en Afrique subsaharienne."

### ❌ À ÉVITER ABSOLUMENT

- "Voici un aperçu du projet" (trop vague)
- "On recommande d'investir" (pas assez formel)
- "Super équipe avec un track record génial" (style ChatGPT)
- "N'hésitez pas à nous contacter" (trop familier)
- Tout tableau dans les exports Word/PDF

### CHECKLIST FINALE

Avant génération des fichiers, vérifier :

- ✅ Contenu COMPLET affiché dans la conversation
- ✅ Aucun emoji dans le contenu principal
- ✅ Aucun séparateur `---` entre sections
- ✅ Aucune référence au logo
- ✅ **Aucun tableau dans les fichiers exports** (formulations textuelles uniquement)
- ✅ Structure hiérarchique claire (# ## ###)
- ✅ Ton professionnel strict maintenu
- ✅ Citations sources systématiques
- ✅ Paragraphes courts (3-4 lignes max)
- ✅ Page de garde minimaliste présente
- ✅ Nom fichiers cohérent
- ✅ **Format qui ne ressemble PAS à du ChatGPT**
- ✅ Génération simultanée Word + PDF
