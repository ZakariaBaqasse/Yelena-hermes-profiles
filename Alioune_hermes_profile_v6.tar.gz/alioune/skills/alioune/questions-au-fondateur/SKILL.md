---
id: Y0381
name: questions-au-fondateur
description: "Transforme les manques et les écarts relevés dans un dossier d'investissement en une liste de questions hiérarchisée par gravité — bloquant, conditionnant, précisant — chaque question citant ce qui a déjà été lu et ce qui reste ouvert, calibrée pour un entretien d'une heure ou pour un envoi écrit, sans jamais reposer une question dont la réponse est déjà dans les pièces."
bucket: C
tags: [Investissement, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Questions à la direction — la liste qui sort des trous, hiérarchisée

## Ce qu'il faut avoir sous la main
- **Le dossier ou le mémo** déjà produit, ou les manques déjà repérés — même une liste brute en vrac.
- **Les pièces déjà reçues** : comptes, statuts, contrats, pacte d'associés — pour que je sache ce qui est déjà répondu.
- **Le format visé** : un entretien (et sa durée disponible) ou un envoi écrit (et le délai que tu peux accorder).
- **Le contexte de la relation** : premier contact avec la direction, ou échange déjà avancé où certains sujets ont déjà été abordés.
- **Les sujets que tu sais sensibles** si tu en as déjà identifié — litige, départ d'associé, dépendance à un client, dette non déclarée.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Recenser les manques, pas les sujets

Reprends le dossier, le mémo ou la liste brute donnée en intake, et extrais chaque **manque concret** : une pièce non reçue, un chiffre non expliqué, une incohérence entre deux documents, une affirmation du fondateur non étayée. Un manque se formule en une phrase factuelle — « le contrat avec le client principal n'est pas dans le dossier », pas « la dépendance client m'inquiète ».

Si le dossier ne permet pas de dire ce qui manque précisément, tu le signales : une liste de questions ne peut pas naître d'un dossier qu'on n'a pas encore vraiment lu.

### Étape 2 — Trier par ce que chaque manque peut coûter

Pour chaque manque, pose une seule question de tri : **s'il reste sans réponse, l'opération tombe-t-elle, ses termes changent-ils, ou seule la précision en pâtit ?** C'est le critère qui range en trois blocs :
- **Bloquant** — sans réponse, on ne peut pas avancer : un chiffre qui contredirait la thèse d'investissement, une pièce dont l'absence signale un risque juridique non maîtrisé, un fait qui remettrait en cause la légalité ou la propriété de l'actif.
- **Conditionnant** — la réponse ne stoppe rien mais change le prix, les garanties ou la structure de l'opération.
- **Précisant** — la réponse affine la compréhension sans changer la décision.

C'est ici que se joue le piège classique du métier : envoyer soixante questions à plat noie les deux qui pouvaient arrêter l'opération dans les cinquante-huit autres. Le bloc bloquant se pose **en premier**, seul si nécessaire, même si l'échange doit être court.

### Étape 3 — Vérifier que la question n'a pas déjà sa réponse

Avant de garder une question, relis les pièces déjà reçues et confirme qu'elle n'y est pas répondue, même partiellement. Rien ne décrédibilise plus vite qu'une question dont la réponse figure en page trois du document qu'on vient de recevoir — c'est le signe qu'on n'a pas lu, et la direction s'en souvient pour le reste de la relation.

Chaque question conservée porte donc deux mentions explicites : **ce qu'on a déjà trouvé** dans les pièces (même incomplet ou ambigu), et **ce qui reste précisément ouvert**. Une question qui ne peut pas citer ce qu'on a déjà lu doit être reformulée ou supprimée.

### Étape 4 — Rendre chaque question vérifiable

Élimine les questions fermées, qui appellent un oui ou un non et n'apprennent rien — « avez-vous des litiges en cours ? » se répond en une syllabe et ne prouve rien dans un sens ou dans l'autre. Reformule pour demander une pièce nommée, un chiffre daté, un nom, un accès à vérifier soi-même : « quels sont les litiges en cours à la date d'aujourd'hui, et peux-tu partager les pièces de procédure correspondantes ? »

Précise pour chacune la **forme de réponse attendue** — document, tableau chiffré, nom et coordonnées, accès à un registre — et un **délai proposé**, laissé en `⟦à renseigner⟧` tant que l'équipe ne l'a pas fixé : le délai est une décision de calendrier, pas une donnée que tu inventes.

### Étape 5 — Poser les sujets sensibles en disant pourquoi

Litige en cours, départ récent d'un associé, dette non déclarée au bilan, dépendance à un client ou à un partenaire unique : ces sujets se posent, mais jamais posés à froid, noyés au milieu d'une liste comme s'ils étaient anodins. Ils s'introduisent en disant explicitement pourquoi on les pose — « ce point est posé parce qu'il conditionne directement la valorisation retenue » — ce qui change la nature de l'échange : la direction comprend qu'il ne s'agit pas d'une suspicion gratuite mais d'un point qui doit être clarifié pour que l'opération avance.

Dans le contexte ouest-africain, certains de ces sujets se heurtent à l'informalité courante des structures — un associé sorti sans acte notarié, une dette entre proches non contractualisée, un accord verbal avec un client. La question ne suppose pas la mauvaise foi : elle demande la trace, quelle qu'en soit la forme, et laisse la direction expliquer l'absence de formalisation si c'est le cas.

### Étape 6 — Décliner en version entretien et version écrite

Pour l'**entretien** : regroupe les questions par thème, réordonne pour tenir dans le temps disponible donné en intake, et reformule chaque question fermée-évitée en question ouverte qui invite la direction à raconter plutôt qu'à confirmer. Les questions bloquantes ouvrent l'échange ; les sujets sensibles se placent après un thème neutre, jamais en première minute.

Pour l'**écrit** : conserve les trois blocs de gravité, groupe par thème pour tenir en un seul envoi lisible, et associe à chaque question sa pièce déjà lue, son manque, sa forme de réponse attendue et son délai. Cette version est prête à être relue — elle ne part jamais sans validation humaine.

## Format de sortie
- **Livrable** : la liste de questions en trois blocs de gravité — bloquant, conditionnant, précisant — chaque question portant : ce qui a déjà été lu, ce qui reste ouvert, la forme de réponse attendue, le délai proposé (`⟦à renseigner⟧` si non fixé par l'équipe).
- **Annexes** : la version entretien (questions ouvertes, regroupées par thème, ordonnées pour tenir dans la durée donnée) et la version écrite (prête à relecture avant envoi).
- **Structure** : Markdown clair — le bloc bloquant en tête, tableaux ou listes par thème.
- **Longueur** : proportionnée au nombre de manques réels du dossier, sans remplissage — une liste qui compte davantage de questions précisantes que de questions bloquantes ou conditionnantes doit interroger la qualité du tri, pas être livrée telle quelle sans le signaler.
- **Règle 0 invention** : aucun chiffre, délai ou seuil de gravité fabriqué. Ce qui manque pour trancher un tri est marqué `[à confirmer]` ou `⟦à renseigner⟧`.

## Règles
1. **Le bloquant passe en premier, même seul.** Si le temps d'entretien est court, ce sont les questions bloquantes qui restent — jamais les précisantes.
2. **Toute question cite ce qui a déjà été lu.** Une question qui ne mentionne pas la pièce déjà vue et ce qui y manque n'est pas prête à sortir — elle risque de reposer une question déjà répondue.
3. **Pas de question fermée.** Chaque question demande une pièce, un chiffre daté, un nom ou un accès — jamais un oui ou un non.
4. **Les sujets sensibles se posent avec leur motif.** Ils ne disparaissent jamais de la liste, mais ils ne se posent jamais sans dire pourquoi on les pose.
5. **Le délai de réponse est une décision de l'équipe.** Tu proposes la structure et laisses la valeur en `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
6. **Le contexte local n'est pas un motif d'indulgence ni de suspicion.** L'informalité d'une structure ouest-africaine appelle une question sur la trace disponible, pas une accusation ni un renoncement à demander.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; l'envoi de la liste à la direction, la programmation de l'entretien ou toute communication externe est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun manque identifié dans le dossier** — tu le dis explicitement : une liste de questions ne se fabrique pas pour occuper l'échange. Tu proposes alors les questions de vérification standard du thème plutôt que des questions inventées de toutes pièces.
- **Une pièce annoncée mais absente** (« voici les comptes », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Donnée introuvable dans les pièces reçues** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Toutes les questions semblent bloquantes** — tu réexamines le critère de tri avant de rendre la liste : une liste sans hiérarchie réelle n'a pas rempli son objet.
- **Sujet sensible signalé en intake sans détail** — tu le places dans le bloc adapté avec son motif générique, et tu marques `[à préciser avec l'équipe]` la formulation exacte si le contexte manque pour l'affiner.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (due diligence complète, mémo d'investissement, négociation des termes).
- **Action sortante demandée** (envoi de la liste, prise de rendez-vous, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires entre deux pièces du dossier** — tu exposes les deux versions dans la question elle-même et tu ne tranches pas laquelle est correcte.
