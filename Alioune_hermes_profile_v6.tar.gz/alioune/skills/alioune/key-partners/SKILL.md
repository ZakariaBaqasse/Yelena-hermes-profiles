---
id: Y0182
name: key-partners
description: "Cartographie les partenaires opérationnels stratégiques (logistique, paiements, fournisseurs, financement, stockage...) dont une startup a besoin pour fonctionner et croître dans une zone géographique cible, avec priorisation d'activation (critique/important/optionnel)."
bucket: C
tags: [Business & Strategy]
version: 1
maj: 2026-08-10
---

# Key Partners

## Ce qu'il faut avoir sous la main
- **Nom de la startup**
- **One-liner** (description en une phrase de l'activité)
- **Site internet**
- **2-3 entreprises comparables** (concurrents ou modèles similaires)
- **Pays ou zone régionale à couvrir**

Si un de ces champs manque, demande-lui de le compléter avant de continuer. Dès que j'ai tout, je produis directement la cartographie.

### 🎯 CONTEXTE STRATÉGIQUE

[Analyse courte du modèle d'affaires et des besoins critiques en partenaires pour assurer les opérations]

### 🎯 CONTEXTE STRATÉGIQUE

L'entreprise opère sur un modèle de marketplace B2B agricole similaire à Ninjacart (Inde) et Nile (Égypte). Les besoins critiques incluent : (1) logistique first/last-mile pour collecter et livrer produits frais, (2) solutions de paiement pour agriculteurs sans banque, (3) partenaires pour améliorer la productivité agricole, (4) infrastructures de stockage/cold chain, (5) financement pour producteurs.


**Ce qu'elle suppose comme accès** : Base « Partenaires », Connecteur recherche web, Connecteur LinkedIn/réseau pro (type Unipile). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Analyser le modèle d'affaires** à partir du one-liner, du site web et des comparables → comprendre la chaîne de valeur, les opérations clés, les besoins critiques.
2. **Consulter** `[datasource à brancher : base « Partenaires » — recense les partenaires opérationnels déjà identifiés/actifs par catégorie et par zone géographique]`. Vérifier si des partenaires existants correspondent déjà aux besoins identifiés et les réutiliser en priorité avant de chercher de nouveaux partenaires.
3. **Identifier les catégories de partenaires opérationnels pertinentes** : celles nécessaires au fonctionnement quotidien du business (logistique, paiements, tech, fournisseurs, finance, etc.) — spécifiques au modèle d'affaires, pas génériques (ex. « First-Mile Logistics », « Payment Processors », « Agricultural Input Suppliers », « Cold Chain Partners »).
4. **Pour chaque catégorie, identifier 3-5 partenaires potentiels actifs dans la zone** :
   - `[connecteur à brancher : recherche web — trouver des partenaires potentiels et vérifier leur présence géographique effective]`
   - `[connecteur à brancher : LinkedIn/réseau pro (type Unipile) — identifier des décideurs chez le partenaire, valider son activité récente, trouver un point de contact]`
   - Détails requis par partenaire : nom + brève description, informations opérationnelles spécifiques (réseau, villes, capacités), modèle tarifaire si pertinent, potentiel de scalabilité (Low/Medium/Strong), statut de collaboration possible (Active/Discussion/Prospection), site web, contact identifié.
5. **Structurer la présentation par catégories** avec contexte stratégique. Proposer à l'utilisateur d'enregistrer les nouveaux partenaires identifiés dans `[datasource à brancher : base « Partenaires »]`.

### 📌 PROCHAINES ÉTAPES

1. [Action concrète 1]
2. [Action concrète 2]
3. [Action concrète 3]
```

### 📌 PROCHAINES ÉTAPES

1. **Semaine 1-2 :** Contacter Wave pour intégration API paiements + signature avec 2-3 transporteurs informels zones pilotes
2. **Mois 1 :** Initier discussions AFRIGO pour partenariat logistique
3. **Mois 2-3 :** Préparer dossier partenariat fournisseur d'intrants (volumes prévisionnels, proposition de valeur)

## Format de sortie
```
# KEY PARTNERS - [NOM STARTUP]

**Startup :** [Nom]
**Activité :** [One-liner]
**Zone géographique :** [Zone spécifiée]
**Comparables :** [Liste des comparables]

## Règles
- Tous les partenaires DOIVENT avoir une présence confirmée dans la zone géographique spécifiée. Indiquer précisément les villes/pays couverts.
- Pour chaque partenaire, fournir des détails opérationnels concrets adaptés au type de service (réseau logistique, taux de commission, capacités techniques, etc.).
- Identifier des catégories spécifiques au modèle d'affaires, pas des catégories génériques.
- Évaluer systématiquement le potentiel de scalabilité de chaque partenaire (Low/Medium/Strong) en fonction de sa couverture géographique et de ses capacités.
- Attribuer un statut réaliste basé sur la maturité de la startup et la taille du partenaire : **Active** (déjà utilisable ou très accessible) · **Discussion** (nécessite des négociations commerciales) · **Prospection** (partenaire stratégique mais difficile d'accès).
- Inclure les sites web officiels. Si incertain, indiquer « Site à vérifier » plutôt qu'un lien incorrect.
- La synthèse par priorité doit refléter les besoins opérationnels immédiats de la startup selon sa phase de développement.
- Ne jamais inventer un partenaire, une présence géographique ou un contact — si `[connecteur à brancher : recherche web]` ou `[connecteur à brancher : LinkedIn/réseau pro]` ne sont pas branchés, le signaler explicitement plutôt que de fabriquer un résultat.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### 🤝 PARTENAIRES OPÉRATIONNELS PAR CATÉGORIE

### [CATÉGORIE 1]
*Pourquoi cette catégorie est critique :* [Explication stratégique courte]

#### [Nom Partenaire 1]
**Description :** [Courte description de l'entreprise et son activité]
**Détails opérationnels :**
- 📍 **Réseau/Présence :** [Villes, pays, zones de couverture]
- ⚙ **[Spécificité 1] :** [ex: Fleet: Motorcycles, 2T Trucks]
- ⚙ **[Spécificité 2] :** [ex: Capacités: Storage centers]
- 💰 **Tarification :** [Modèle tarifaire si connu ou estimé]
- 📈 **Potentiel de scalabilité :** [Low / Medium / Strong]
- 🔄 **Statut :** [Active / Discussion / Prospection]
- 🔗 **Site :** [URL]

[Répéter pour 3-5 partenaires par catégorie, puis pour 4-7 catégories selon le business model]

### 📊 SYNTHÈSE PAR PRIORITÉ

### 🔴 Partenaires critiques (à activer immédiatement)
1. [Partenaire X] - [Catégorie] : [Raison de criticité]

### 🟡 Partenaires importants (à moyen terme)
1. [Partenaire Z] - [Catégorie] : [Raison]

### 🟢 Partenaires optionnels (pour scalabilité future)
1. [Partenaire W] - [Catégorie] : [Raison]

### Exemple d'application

**INPUT UTILISATEUR :**
- **Nom :** l'entreprise
- **One-liner :** Plateforme digitale d'approvisionnement agricole connectant producteurs et acheteurs
- **Site :** www.exemple.com
- **Comparables :** Ninjacart, Nile
- **Zone :** Côte d'Ivoire et Afrique de l'Ouest

### 🤝 PARTENAIRES OPÉRATIONNELS PAR CATÉGORIE

### LOGISTIQUE - FIRST MILE
*Pourquoi critique :* La collecte efficace des produits agricoles auprès des producteurs dispersés est le goulot d'étranglement principal des marketplaces agricoles.

#### AFRIGO
**Description :** Entreprise de logistique et livraison spécialisée en Afrique de l'Ouest
**Détails opérationnels :**
- 📍 **Réseau :** Centres de collecte et stockage à Abidjan ; opérations en Côte d'Ivoire et Sénégal
- ⚙ **Flotte :** Motos, vans, camions 2T
- ⚙ **Capacités :** Points de collecte en zones rurales périurbaines
- 💰 **Tarification :** Contrat mensuel + pay-per-collection
- 📈 **Potentiel de scalabilité :** Strong (réseau régional)
- 🔄 **Statut :** Discussion
- 🔗 **Site :** www.afrigo.com

#### Transporteurs informels locaux
**Description :** Réseau de transporteurs individuels et collectifs couvrant les zones rurales
**Détails opérationnels :**
- 📍 **Réseau :** Toutes régions agricoles de Côte d'Ivoire
- ⚙ **Flotte :** Tous types (motos, camionnettes, camions)
- ⚙ **Capacités :** Flexibilité totale, disponibilité immédiate
- 💰 **Tarification :** Pay-per-delivery, négociation spot
- 📈 **Potentiel de scalabilité :** Low (fragmentation)
- 🔄 **Statut :** Active
- 🔗 **Site :** N/A (agrégation via la plateforme de l'entreprise)

[Etc. — 3 autres partenaires first-mile]

### PAIEMENTS & MOBILE MONEY
*Pourquoi critique :* 70% des producteurs agricoles en Afrique de l'Ouest n'ont pas de compte bancaire. Solutions mobile money essentielles pour les transactions.

#### Wave
**Description :** Fintech offrant des solutions de paiement mobile et transferts d'argent en Afrique de l'Ouest
**Détails opérationnels :**
- 📍 **Réseau :** Côte d'Ivoire, Sénégal, Mali, Burkina Faso, Bénin
- ⚙ **Services :** Paiements in-app, transferts, collecte de paiements fournisseurs
- ⚙ **Intégration :** API disponible, documentation complète
- 💰 **Tarification :** 1% par transaction
- 📈 **Potentiel de scalabilité :** Strong (couverture régionale, base utilisateurs large)
- 🔄 **Statut :** Active (intégration API rapide)
- 🔗 **Site :** www.wave.com

[Etc. — les autres catégories (Fournisseurs d'intrants agricoles, Financement & crédit agricole, Stockage & conservation) suivent la même structure]

### 📊 SYNTHÈSE PAR PRIORITÉ

### 🔴 Partenaires critiques (à activer immédiatement)
1. **Wave** - Paiements : Essentiel pour les transactions producteurs dès J1
2. **Transporteurs informels** - First-Mile : Flexibilité pour la phase pilote

### 🟡 Partenaires importants (3-6 mois)
1. **AFRIGO** - First-Mile : Pour professionnaliser la collecte à plus grande échelle

### 🟢 Partenaires pour scalabilité (6-12 mois)
1. **Orange Money** - Paiements : Expansion multi-pays Afrique de l'Ouest

### Ton & Style

- **Professionnel et opérationnel** : focus sur des informations actionnables.
- **Structuré et scannable** : faciliter la prise de décision rapide.
- **Précis sur les détails techniques** : réseau, tarifs, capacités.
- **Pragmatique** : statuts réalistes selon la phase de la startup.
