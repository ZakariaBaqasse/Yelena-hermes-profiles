---
name: suivi-engagements
description: >
  Capte, stocke et suit CHAQUE engagement pris devant le dirigeant ou par le dirigeant
  lui-même (« je vous transmets la note d'ici jeudi », « la
  direction commerciale revient vers nous avant le comité de direction »), depuis les
  vocaux, les comptes rendus de réunion, les courriers ou les messages. Source de vérité :
  `memory/state/engagements.json`. Produit une vue de statut (en retard / à échéance / à
  venir) et propose les relances AVANT la date butoir. Utiliser quand le dirigeant dit « où en
  sont les engagements », « qui me doit quoi », « qu'est-ce qui est en retard », « note que
  X doit faire Y », « relance ».
version: 1
maj: 2026-08-10
---

# Suivi des engagements

Une direction générale ne perd pas le fil de ses dossiers parce qu'elle travaille mal :
elle le perd parce que **personne ne tient le fil de ce qui a été promis, par qui, pour
quand**. C'est la fonction la plus simple et la plus rentable de cet agent — et la seule
qui produit de la valeur tous les jours sans qu'on la demande.

## Principe

Un engagement = **qui** + **quoi** + **pour quand** + **où ça a été dit**. S'il manque le
« pour quand », on le demande. S'il manque le « qui », ce n'est pas un engagement, c'est un
souhait — ne pas l'enregistrer.

Un engagement se distingue de trois choses avec lesquelles on le confond :

| Ce n'est pas… | Exemple | Pourquoi |
|---|---|---|
| une **intention** | « il faudrait qu'on regarde ce dossier » | personne n'est nommé, aucune date |
| une **tâche interne** | « je relis la note ce soir » | ça n'engage personne d'extérieur, ça encombre la liste |
| une **décision** | « le dossier est arbitré en faveur de X » | c'est un fait à consigner, pas une échéance à suivre |

En cas de doute, la question qui tranche : **« si personne ne le fait, quelqu'un devra
s'en expliquer ? »** Si oui, c'est un engagement.

## Source de vérité

`memory/state/engagements.json`. Un tableau d'objets :

```json
{
  "id": "eng-2026-07-30-001",
  "quoi": "Transmettre la note d'arbitrage sur le contrat fournisseur de Yopougon",
  "qui": "Direction des Achats",
  "pour": "dirigeant",
  "echeance": "2026-08-06",
  "echeance_confirmee": true,
  "origine": "réunion de comité de direction du 30/07, CR §4",
  "source_lien": "<lien cliquable vers le CR ou le message d'origine>",
  "sensibilite": "normale",
  "statut": "en_cours",
  "relances": ["2026-08-04"],
  "cloture": null
}
```

- `statut` ∈ `en_cours` | `fait` | `caduc` | `en_retard`.
- `sensibilite` ∈ `normale` | `reservee` — une ligne `reservee` ne figure jamais dans une
  restitution qui pourrait être lue par un tiers.
- **Ne jamais supprimer une ligne.** Un engagement abandonné passe en `caduc` avec sa raison
  dans `cloture`. L'historique est ce qui permet de répondre « nous vous l'avions demandé
  le 30 juillet ».

Écriture : lire le fichier entier, modifier en mémoire, réécrire entier. Jamais d'écriture
partielle — deux passes concurrentes se perdraient mutuellement.

## Capter

À chaque compte rendu, vocal ou message, relever les formulations d'engagement. Les tournures
qui en signalent un, par ordre de fréquence réelle :

- « je vous envoie / je vous transmets / je reviens vers vous »
- « on vous fait un point / une note / un retour »
- « il faut que X fasse », « X va se rapprocher de »
- « d'ici », « avant le », « à la prochaine réunion », « dans la foulée »
- au passif : « la note sera transmise », « le dossier sera instruit » — **noter que le
  passif masque le « qui » : c'est le premier à réclamer.**

Les enregistrer **immédiatement** — ne jamais compter sur la mémoire de la session.

Quand une échéance est floue (« rapidement », « dans la semaine », « avant le comité »),
deux options, jamais une invention :

1. poser **une** question au dirigeant pour la fixer ;
2. inscrire une date déduite avec `echeance_confirmee: false`, et l'afficher partout
   avec la mention `⚠ à confirmer`.

Convertir les repères internes en dates réelles quand c'est possible : « avant le comité
de direction » devient une date si la tenue du comité est connue — et la source est citée.

## Restituer

Format de sortie, trié par urgence, rien d'autre :

```
EN RETARD (n)
• <quoi> — <qui> — échéance <date>, <n> jours de retard — origine : <lien>

À ÉCHÉANCE CETTE SEMAINE (n)
• <quoi> — <qui> — <date>

À VENIR (n)
• <quoi> — <qui> — <date>
```

Pas de commentaire, pas de mise en perspective, pas de félicitations : le dirigeant lit vite.

Deux règles d'affichage :

- **Au-delà de douze lignes**, ne montrer que « en retard » et « cette semaine », et
  terminer par « + n engagements à venir, dites-moi si vous voulez la liste ».
- L'**origine est toujours un lien cliquable**. Un engagement qu'on ne peut pas rattacher à
  sa source ne tient pas trente secondes en cas de contestation.

## Relancer

Deux jours ouvrés avant l'échéance, proposer la relance — **proposer, pas envoyer**.
Le projet de message est sobre, professionnel, sans reproche, et rappelle l'origine :

> Objet : Note d'arbitrage — contrat fournisseur de Yopougon
>
> Monsieur le Directeur,
>
> Dans le prolongement de la réunion du comité de direction du 30 juillet, je me permets
> de revenir vers vous concernant la note d'arbitrage attendue pour le 6 août.
>
> Je reste à votre disposition pour tout élément complémentaire.

Après l'échéance, la relance change de registre — elle **constate** sans accuser : « la note
n'étant pas parvenue à ce jour, je souhaitais m'assurer que la demande vous était bien
parvenue ». Toute relance envoyée s'inscrit dans `relances[]`.

**Trois relances sans réponse = un signal à faire remonter**, pas un simple problème
administratif. Le signaler comme tel au dirigeant, sans commentaire, et laisser l'arbitrage à
sa main.

## Exemple travaillé

Extrait de compte rendu :

> « Le Directeur financier de la filiale indique qu'il transmettra les projections de
> trésorerie révisées rapidement. La Direction des achats se rapprochera de la banque
> partenaire avant le prochain comité de direction. Il faudrait par ailleurs qu'on regarde
> le dossier d'exonération de la zone franche. »

Ce qui entre dans le fichier :

| quoi | qui | échéance | note |
|---|---|---|---|
| Transmettre les projections de trésorerie révisées | Directeur financier de la filiale | ⚠ à confirmer | « rapidement » n'est pas une date : à faire préciser |
| Se rapprocher de la banque partenaire | Direction des achats | date du prochain comité de direction si elle est connue, sinon ⚠ | l'échéance est déduite, la source est citée |

Ce qui **n'entre pas** : « il faudrait qu'on regarde le dossier d'exonération de la zone
franche » — personne n'est nommé, aucune date. C'est une intention. Si le dirigeant veut la
suivre, il la transforme lui-même en engagement.

## Quand le livrable n'est pas bon

Rejeter et refaire si l'un de ces défauts apparaît :

- une échéance inventée pour « faire propre » ;
- un engagement sans origine traçable présenté comme acquis ;
- une liste qui mélange les tâches internes de l'équipe de direction et les engagements de tiers ;
- un tri par date d'enregistrement plutôt que par urgence ;
- un commentaire d'appréciation sur le retard de quelqu'un.

## Garde-fous

- Un engagement pris par un acteur extérieur (client, fournisseur, banquier, actionnaire)
  ne se relance **jamais** sans l'accord du dirigeant.
- Ne jamais inventer une échéance.
- Un engagement dont l'origine n'est pas traçable s'inscrit avec `origine: "à confirmer"` —
  il sera invérifiable en cas de contestation, et c'est au dirigeant de le savoir.
- Les lignes `sensibilite: reservee` ne sortent que dans le canal du dirigeant.

## Chaînage

- **Alimenté par** `releve-decisions` (chaque relevé de réunion verse ses actions ici) et par
  tout message ou vocal reçu.
- **Alimente** `radar-hebdomadaire` (les engagements en retard sont la première section du
  radar) et l'automatisation quotidienne de relance.
- **Croise** `cartographie-acteurs` : si la personne engagée a changé de fonction, l'engagement
  est à réattribuer, pas à relancer à l'aveugle.

## Gabarit

Le gabarit de ce livrable — charte graphique de l'entreprise, blocs obligatoires,
emplacement du visa — est dans [`references/gabarit.html`](references/gabarit.html), avec
son rendu PDF dans le dossier `gabarits/` du pack. Il est rempli de **données fictives** :
il sert à valider la forme, jamais à être repris tel quel. Les champs à remplir y sont
signalés en orange.
