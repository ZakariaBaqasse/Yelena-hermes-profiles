---
id: Y0385
name: reporting-souscripteurs
description: "Rédige la lettre périodique adressée aux souscripteurs d'un véhicule d'investissement : activité de la période, portefeuille ligne par ligne avec sa base de valorisation, mouvements de trésorerie, indicateurs de performance calculés selon une méthode constante, difficultés et perspectives — sans jamais inventer un chiffre, revaloriser une ligne sans événement, ou taire une mauvaise nouvelle que le souscripteur apprendra ailleurs."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Reporting aux souscripteurs — la lettre qu'on peut relire dans trois ans

## Ce qu'il faut avoir sous la main
- **Le véhicule et la période** couverte par la lettre, et les destinataires (l'ensemble des souscripteurs, ou aussi le comité consultatif s'il existe).
- **L'activité de la période** : dossiers vus, instruits, décidés — même en vrac, même sous forme de liste brute.
- **Le portefeuille actuel** ligne par ligne, avec pour chaque ligne le dernier événement connu (tour de financement, cession, dépréciation constatée, ou rien).
- **Les mouvements de trésorerie** de la période : appels de fonds effectués, distributions versées, avec leurs dates.
- **Les indicateurs calculés à la période précédente** et leur méthode, pour que je vérifie la continuité — ou la lettre précédente elle-même si tu l'as.
- **Les difficultés** que tu sais déjà devoir mentionner, même si elles sont inconfortables.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cadrer la période, le véhicule et l'audience

Identifie précisément le véhicule (nom, forme juridique, devise de reporting), la période couverte, et **qui reçoit la lettre** : l'ensemble des souscripteurs, ou aussi un comité consultatif qui a accès à un niveau de détail supérieur. Ce cadrage détermine tout le reste — le niveau de détail de l'étape 3 en particulier ne se règle pas de la même façon selon l'audience.

Si le véhicule reporte en devise différente de celle de certains souscripteurs — le cas fréquent d'un fonds en FCFA avec des souscripteurs de la diaspora en euros ou en dollars — signale-le : les variations de change doivent être distinguées de la performance réelle du portefeuille, sinon un mouvement de parité se lit comme une performance qu'il n'est pas.

### Étape 2 — Raconter l'activité sans trier ce qui rassure

Distingue trois niveaux, sans les fondre : les dossiers **vus** (flux entrant, sourcing), les dossiers **instruits** (analyse engagée, encore en cours), les dossiers **décidés** (investissement réalisé, ou refus motivé). Un souscripteur veut voir le tri qui s'opère, pas seulement le résultat.

Ne présente pas un fort volume de dossiers vus comme un signe de sélectivité s'il n'y a pas de décision derrière — un pipeline qui gonfle sans convertir est une information, pas un argument.

### Étape 3 — Le portefeuille ligne par ligne : la valorisation se rattache à un fait

Pour chaque ligne du portefeuille, indique le statut, et surtout la **base de valorisation retenue** : au coût, ou revalorisée. Une revalorisation ne s'écrit que si elle est adossée à un événement identifiable — un tour de financement à un prix connu, une cession, une dépréciation constatée sur des signaux factuels (arrêt d'activité, défaut de paiement, restructuration). L'événement s'écrit à côté du chiffre, pas en note de bas de page.

**En l'absence d'événement, la ligne reste au coût, et tu l'écris explicitement** — « valorisée au coût, aucun événement sur la période » est une phrase normale, pas un aveu de faiblesse. Le piège classique est de faire glisser une valorisation vers le haut parce que « le dossier avance bien » : sans transaction ou fait constaté, ce glissement est une opinion présentée comme un chiffre, et il sera contesté le jour où un souscripteur demande la base.

Règle le niveau de détail par ligne selon l'audience de l'étape 1 : voir Étape 7.

### Étape 4 — Les mouvements de trésorerie : appels de fonds et distributions

Liste les appels de fonds effectués sur la période (montant, date, motif — nouvel investissement, frais de gestion, suivi de portefeuille) et les distributions versées (montant, date, origine — cession, dividende, remboursement). Ce sont des faits, ils se rapportent sans reformulation.

Si tu évoques un **calendrier de distribution à venir**, formule-le comme une intention conditionnée à des événements (une cession en cours, un remboursement attendu), jamais comme une échéance ferme. Un souscripteur qui a retenu une date qui glisse ensuite retient surtout que le gérant a promis ce qu'il ne maîtrisait pas — même si le retard a une cause légitime. Toute date de distribution évoquée dans la lettre reste `⟦à renseigner⟧` tant qu'elle n'est pas confirmée par un événement déjà survenu ou juridiquement engagé.

### Étape 5 — Les indicateurs de performance : la méthode ne change pas en silence

Rappelle, à chaque lettre, la **définition** de chaque indicateur utilisé (méthode de calcul, dénominateur, ce qui est inclus ou exclu — lignes non réalisées, frais, devise de référence) avant de donner sa valeur. Un indicateur sans sa définition rappelée n'est pas comparable, même s'il porte le même nom que la période précédente.

Si la méthode change — nouvelle façon de valoriser, périmètre modifié, devise de calcul différente — **la lettre l'annonce explicitement et retraite la période précédente selon la nouvelle méthode**, pour que la comparaison reste honnête. Une progression obtenue en changeant simplement de méthode de calcul, sans le dire, est la façon la plus rapide de perdre la confiance d'un souscripteur professionnel qui recalculera de son côté.

Aucune valeur d'indicateur n'est produite par toi si elle ne t'a pas été fournie ou calculée à partir de données que tu as reçues : `⟦à renseigner⟧` sinon.

### Étape 6 — Les difficultés se disent tôt, les perspectives sans promesse

Écris la ou les difficultés de la période **en une phrase factuelle**, tôt dans la lettre — pas noyée en fin de document après trois pages de bonnes nouvelles — suivie de ce qui est engagé pour y répondre. Une ligne qui sous-performe, un dossier qui échoue, un retard de levée : ce sont des faits normaux de l'activité, et les taire ne les rend pas moins vrais, seulement moins bien encadrés.

Pour les perspectives de la période suivante, distingue ce qui est engagé (décision prise, terme signé) de ce qui est visé (objectif, intention). Une perspective formulée comme certaine alors qu'elle est visée retombe dans le piège de l'étape 4.

### Étape 7 — Confidentialité : qui lit quoi

Avant d'assembler la lettre finale, repasse chaque ligne sensible du portefeuille au filtre de l'audience définie à l'étape 1. Les souscripteurs d'un même véhicule sont souvent, dans un écosystème restreint, investis ou en relation avec des concurrents des participations du portefeuille — un chiffre d'affaires précis, une difficulté nommée en détail, ou l'identité d'un repreneur en négociation peuvent être lus par la mauvaise personne.

Ce qui est sensible se traite en agrégé dans la lettre collective (statut, tendance, base de valorisation sans le détail opérationnel) et en détail dans un échange bilatéral avec le souscripteur qui en a besoin — pas dans le document large diffusion. Le comité consultatif, quand il existe, reçoit un niveau de détail supérieur à celui de la lettre générale : c'est précisément sa fonction, et cela doit rester distinct dans le livrable.

## Format de sortie
- **Livrable** : la lettre aux souscripteurs — mot d'introduction, activité de la période (dossiers vus / instruits / décidés), portefeuille ligne par ligne avec base de valorisation et événement associé, mouvements de trésorerie de la période, indicateurs de performance avec leur définition rappelée et toute évolution de méthode signalée, difficultés et actions engagées, perspectives de la période suivante. En annexe : tableau de bord chiffré et réponses préparées aux questions attendues.
- **Structure** : Markdown clair, sections dans l'ordre du Process ; tableau pour le portefeuille ligne par ligne (ligne, statut, base de valorisation, événement, commentaire) et pour les mouvements de trésorerie.
- **Longueur** : proportionnée au portefeuille et à la période — ni un pavé qui dilue les difficultés, ni une synthèse qui les efface.
- **Statut du document** : la lettre produite est un **projet**, marqué comme tel, tant que la direction du fonds ne l'a pas validée. Elle n'est jamais envoyée en l'état par la skill.
- **Règle 0 invention** : aucune valorisation, aucun indicateur, aucune date de distribution n'est produit sans donnée fournie. `⟦à renseigner⟧` sinon.

## Règles
1. **Une mauvaise nouvelle s'écrit tôt et en une phrase factuelle.** Elle ne se dilue pas dans le milieu du document ni ne se tait — un souscripteur qui l'apprend ailleurs cesse de croire tout le reste de la lettre, y compris ce qui était vrai.
2. **La méthode de calcul des indicateurs ne change jamais en silence.** Tout changement est annoncé, et la période précédente est retraitée selon la nouvelle méthode pour rester comparable. Une progression obtenue par un changement de calcul non annoncé est traitée comme une falsification, pas comme une amélioration.
3. **Aucune revalorisation sans événement.** Une ligne ne monte ou ne baisse que si un fait daté le justifie (tour, cession, dépréciation constatée) ; sinon elle reste au coût, et cela s'écrit.
4. **Le niveau de détail par ligne se règle sur l'audience, jamais sur défaut.** Ce qui est sensible pour une participation se traite en échange bilatéral, pas dans la lettre collective.
5. **Aucun calendrier de distribution ferme sans événement déjà survenu ou juridiquement engagé.** Une intention se formule comme conditionnée, jamais comme une échéance.
6. **0 chiffre inventé.** Valorisation, indicateur de performance, montant d'appel de fonds ou de distribution, taux de change : tout vient d'une donnée fournie ou d'un calcul fait à partir d'elle. `⟦à renseigner⟧` sinon — y compris pour un ordre de grandeur « plausible pour ce type de fonds ».
7. **Observé et intention ne se mélangent jamais dans la même phrase** du document : ce qui s'est produit et ce qui est visé restent visuellement distincts.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; l'envoi de la lettre aux souscripteurs, sa diffusion ou sa signature est une action validée par la direction du fonds.
- **Cloisonnement.** Ce que tu apprends d'un véhicule ou d'une participation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun événement de valorisation sur la période** — tu produis la lettre normalement, avec toutes les lignes maintenues au coût explicitement mentionné ; ce n'est pas un défaut du livrable, c'est un résultat de la période.
- **Méthode de calcul incertaine ou non retrouvée** — tu le signales avant de produire l'indicateur, tu ne recalcules pas selon une méthode supposée, et tu proposes de repartir de la dernière lettre validée comme référence.
- **Difficulté significative non mentionnée par l'équipe** mais visible dans les données fournies (ligne en forte baisse, retard d'appel de fonds, dossier abandonné) — tu la signales et tu demandes comment elle doit être formulée, plutôt que de l'omettre ou de la formuler seul sans validation.
- **Destinataires multiples avec niveaux de détail différents** — tu produis les deux versions (lettre générale, dossier comité consultatif) distinctement, jamais une version unique qu'on filtrerait après coup.
- **Devise de reporting différente de celle de souscripteurs** — tu distingues explicitement variation de change et performance réelle, et tu signales le point si la conversion n'est pas fournie.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Action sortante demandée** (envoi de la lettre, publication, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux valorisations différentes pour la même ligne, deux dates d'appel de fonds) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
