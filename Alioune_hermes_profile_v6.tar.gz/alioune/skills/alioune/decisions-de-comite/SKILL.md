---
id: Y0392
name: decisions-de-comite
description: "Transforme une séance de comité d'investissement en deux objets qui survivent à la réunion : le relevé de décisions — ce qui a été décidé, à quel montant, sous quelles conditions suspensives, par quelle formation — et le registre des engagements qui attribue chaque condition à une personne nommée et une échéance, puis produit le rappel des soldes avant la séance suivante — sans jamais transformer une discussion favorable en décision, ni un accord de principe en engagement chiffré."
bucket: C
tags: [Investissement, Gouvernance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Décisions de comité et engagements — ce qui a été décidé, par qui, sous quelles conditions

## Ce qu'il faut avoir sous la main
- **Les notes ou la transcription de la séance** : ordre du jour, dossiers passés, ce qui a été dit sur chacun.
- **La liste des membres présents et absents**, et s'il y a eu des déports — sur quel dossier, pourquoi.
- **Pour chaque dossier passé** : la décision telle qu'elle a été exprimée, le montant et l'instrument envisagés, les conditions ou réserves formulées.
- **Le relevé et le registre de la séance précédente**, si tu en as un — pour que je produise le rappel des engagements en cours.
- **La date de la prochaine séance**, si elle est connue.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si des notes de séance même partielles sont déjà fournies, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Reconstituer qui a décidé

Avant le contenu, la forme : qui était présent, qui était absent, et qui s'est déporté sur quel dossier — avec le motif du déport. Un membre qui a un intérêt dans une société candidate et qui quitte la salle pendant la discussion fait partie de la décision, pas de l'anecdote. Si le motif du déport n'est pas donné, tu le marques `[à confirmer]` plutôt que de l'omettre : un déport sans motif documenté est une faiblesse de gouvernance qui doit être visible, pas absorbée dans le silence.

### Étape 2 — Isoler la décision de la discussion

Pour chaque dossier, tu ne retiens que ce qui engage. Le débat — qui a dit quoi, les hésitations, les arguments échangés — ne figure dans le relevé que lorsqu'il éclaire une condition posée ou un refus motivé ; sinon il reste dans les notes de travail et n'entre pas dans le document final. Un relevé qui raconte la réunion au lieu d'enregistrer la décision ne sera relu par personne au moment où il compte : quand il faut savoir ce qui a été approuvé.

La décision de chaque dossier s'écrit dans un **vocabulaire fermé**, toujours le même : **approuvé**, **approuvé sous conditions**, **ajourné**, **refusé**. Pas de nuance hors de ces quatre mots — une nuance qui a sa place se traduit en condition suspensive (étape 3) ou en motif d'ajournement (étape 5), jamais en adjectif flottant.

### Étape 3 — Décomposer chaque décision favorable en conditions suspensives

C'est le point où une décision favorable se perd le plus souvent. « Approuvé sous réserve de la remise des comptes certifiés et de l'obtention de l'agrément » se retient, dans les mémoires, comme « approuvé » — et un décaissement peut partir avant que la réserve soit levée. Tu décomposes donc chaque phrase de ce type en **lignes séparées**, une par condition, chacune avec son propre état.

Le statut du dossier dans le relevé reste **« approuvé sous conditions »** jusqu'à ce que la dernière condition soit levée et documentée comme telle — jamais « approuvé » tant qu'il en reste une ouverte, même si elle paraît formelle. Une condition réglementaire — agrément d'une autorité sectorielle, avis d'une instance de supervision — se signale spécifiquement : ces conditions-là prennent souvent plus de temps que le reste du dossier, et un comité qui l'oublie découvre le retard au moment du décaissement.

### Étape 4 — Attribuer chaque engagement à une personne nommée

« L'équipe doit vérifier » n'engage personne et ne sera pas fait. Chaque condition suspensive et chaque demande formulée en séance devient une ligne d'engagement portée par **une personne présente dans la salle**, nommée. Si aucun nom ne ressort des notes, tu marques l'engagement **« non attribué »** — ce n'est pas un trou dans le document, c'est une information sur l'état réel de la décision : un engagement sans porteur a une probabilité de non-exécution que le comité doit connaître.

### Étape 5 — Ne pas écrire une décision qui n'a pas été prise

Un comité qui n'arrive pas à trancher n'a pas produit un accord de principe : il a produit un **ajournement**. Tu écris l'ajournement tel quel, avec ce qui doit être apporté ou clarifié pour que le dossier repasse en séance. Écrire « accord de principe » ou « favorable en l'état » là où il n'y a eu qu'une discussion encourageante est une invention de décision, au même titre qu'un chiffre inventé — elle crée une attente que personne n'a validée.

De même, une réserve exprimée par un seul membre sans vote ni consensus du comité se rapporte comme réserve individuelle, attribuée à son auteur — elle n'entre pas dans la décision collective.

### Étape 6 — Construire le registre et le boucler sur le relevé

Chaque ligne du registre des engagements doit pouvoir remonter à un dossier et, si elle en découle, à une condition précise du relevé. Aucun engagement flottant, aucune ligne du relevé qui promette une action sans ligne correspondante dans le registre. Tu vérifies cette correspondance avant de livrer : c'est le contrôle qui évite qu'une condition « oubliée » dans le registre ne réapparaisse jamais.

### Étape 7 — Préparer le rappel avant la séance suivante

Si un relevé et un registre antérieurs sont fournis, tu produis la note de rappel : les engagements **soldés** depuis la dernière fois, les engagements **en retard** avec leur âge (temps écoulé depuis l'échéance, pas une pénalité chiffrée), les conditions suspensives **encore ouvertes** sur des dossiers déjà « approuvés sous conditions », et les dossiers **ajournés** dont le motif d'ajournement est levé et qui doivent donc revenir à l'ordre du jour. Cette note ouvre la séance suivante ; elle n'est pas un rapport d'activité, c'est une liste de ce qui doit être tranché à nouveau.

## Format de sortie
- **Livrable 1 — Relevé de séance** : date, formation présente, absents et déportés avec motif ; pour chaque dossier — nom, décision (vocabulaire fermé), montant, instrument, conditions suspensives listées une par une, réserves exprimées avec leur auteur, prochain jalon ; puis les points transverses décidés en séance (politique d'investissement, seuils de délégation, autres décisions non liées à un dossier unique).
- **Livrable 2 — Registre des engagements** : identifiant, dossier lié, ce qui est attendu, personne porteuse (ou « non attribué »), échéance, état (`ouvert` / `en cours` / `soldé` / `en retard`), date de dernière mise à jour.
- **Livrable 3 — Note de rappel avant la séance suivante** (si historique disponible) : engagements soldés, engagements en retard avec leur âge, conditions suspensives encore ouvertes, ajournements dont le motif est levé.
- **Structure** : Markdown, tableaux pour le registre et pour la liste des conditions suspensives, prose courte pour les motifs de déport et de refus.
- **Longueur** : proportionnée au nombre de dossiers passés en séance, sans remplissage — le relevé ne raconte pas la discussion, il enregistre la décision.
- **Règle 0 invention** : aucune donnée chiffrée, aucun nom, aucune date ni aucune décision inventés. Ce qui manque est marqué `[à confirmer]` ou `⟦à renseigner⟧`, jamais complété par une valeur plausible.

## Règles
1. **Le relevé se tient à ce qui engage.** Le débat n'y figure que lorsqu'il éclaire une condition posée ou un refus motivé. Une transcription de discussion n'est pas un relevé de décisions.
2. **Une décision favorable non conditionnée est rare — cherche les conditions.** Toute réserve exprimée en séance devient une ligne de condition suspensive distincte, avec son propre état. Le statut « approuvé sous conditions » reste tant qu'il en reste une ouverte, quelle que soit son importance apparente.
3. **Un engagement porte un nom.** Une demande sans porteur identifié est marquée « non attribué » — c'est une information sur le dossier, pas un défaut du document.
4. **Un accord de principe n'est pas une décision.** Tu n'écris « approuvé », « approuvé sous conditions » ou « refusé » que si le comité a effectivement tranché. Sinon, c'est un ajournement, écrit avec ce qui doit être apporté pour lever le blocage.
5. **Les déports et les réserves individuelles font partie de la décision.** Qui s'est déporté, sur quel dossier, pourquoi, et qui a exprimé une réserve individuelle sans qu'elle soit reprise par le comité : ces éléments figurent dans le relevé, pas dans une annexe qu'on oublie de lire.
6. **Le contexte local n'est pas un décor.** Une condition suspensive réglementaire (agrément d'une autorité de supervision, avis sectoriel) se signale comme telle, parce qu'elle suit un calendrier propre, hors du contrôle du comité. Un engagement confirmé oralement ou par écrit informel entre deux séances (WhatsApp, e-mail court) compte comme engagement dès qu'il est confirmé par son porteur — tu ne l'ignores pas parce qu'il n'est pas passé en séance formelle, mais tu le marques comme pris hors séance.
7. **0 chiffre et 0 décision inventés.** Aucun montant, aucune échéance, aucun vote, aucune décision n'est produit sans être fourni dans les notes de séance : `⟦à renseigner⟧` ou `[à confirmer]` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais une décision ou une condition comme « actée en séance » sans qu'elle figure dans les notes fournies. Si une source est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres le relevé et le registre, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; diffuser le relevé hors du comité, envoyer une relance à un porteur d'engagement ou notifier un dossier à l'extérieur est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ou d'un comité ne fuite jamais vers un autre dossier ou une autre instance traités dans la même conversation.

## Cas limites
- **Notes de séance incomplètes** — tu produis le relevé avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à reconstituer.
- **Premier comité, aucun historique** — tu produis le relevé et le registre sans note de rappel, en le signalant : le rappel apparaîtra à partir de la deuxième séance disponible.
- **Une pièce annoncée mais absente** (« voici la transcription », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Motif de déport ou de réserve introuvable** — tu le marques `[à confirmer]` explicitement plutôt que de l'omettre ou de le deviner.
- **Source ou connecteur inaccessible** (registre précédent non trouvé, liste des membres manquante) — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné.
- **Dossier déjà en cours d'exécution** (décision antérieure au périmètre fourni) — tu pars du registre existant plutôt que de reconstituer la décision d'origine, et tu le dis.
- **Demande hors périmètre** (analyse du dossier lui-même, recommandation d'investir) — tu le dis en une phrase et tu orientes vers la compétence d'analyse ou de mémo d'investissement qui convient ; cette skill ne juge pas le dossier, elle enregistre ce que le comité en a décidé.
- **Diffusion demandée hors du comité** — tu prépares le document et tu t'arrêtes pour validation humaine : un relevé contient des valorisations, des refus motivés et parfois des appréciations sur des dirigeants.
- **Comité divisé, deux versions des faits circulent** — tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul quelle version fait foi.
