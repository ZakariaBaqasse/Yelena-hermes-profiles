#!/usr/bin/env python3
"""
Search recent news about a person (or their company) via Brave Search API.

Usage:
    python news_search.py --name "Pierre-Thomas Louis de Soultrait" --company "LG Electronics Europe" [--days 90]

Output: JSON array of news items on stdout.
"""
import argparse, datetime, json, os, sys, urllib.parse, urllib.request
from pathlib import Path


def get_brave_key():
    k = os.environ.get("BRAVE_SEARCH_API_KEY")
    if k:
        return k
    try:
        cfg = json.loads((Path.home() / ".openclaw/openclaw.json").read_text())
        # Brave key can live under plugins.entries or tools.entries depending on the version
        for root in ("plugins", "tools"):
            k = (cfg.get(root, {}).get("entries", {}).get("brave", {})
                    .get("config", {}).get("webSearch", {}).get("apiKey"))
            if k:
                return k
        if k:
            return k
    except Exception:
        pass
    raise RuntimeError("BRAVE_SEARCH_API_KEY introuvable (env ou openclaw.json)")


def brave_search(query, key, limit=10, freshness="pm"):
    """freshness: pd (past day), pw (past week), pm (past month), py (past year)"""
    url = "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode({
        "q": query,
        "count": limit,
        "freshness": freshness,
        "country": "FR",
        "search_lang": "fr",
    })
    req = urllib.request.Request(url, headers={
        "X-Subscription-Token": key,
        "Accept": "application/json",
    })
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--company", default="")
    ap.add_argument("--days", type=int, default=90)
    ap.add_argument("--max-results", type=int, default=5)
    args = ap.parse_args()

    key = get_brave_key()
    freshness = "py" if args.days > 90 else ("pm" if args.days > 7 else "pw")

    queries = [f'"{args.name}"']
    if args.company:
        queries.append(f'"{args.name}" {args.company}')
        queries.append(f'{args.company} annonce 2026')

    seen = set()
    results = []
    for q in queries:
        try:
            data = brave_search(q, key, limit=10, freshness=freshness)
            web = data.get("web", {}).get("results", [])
            news = data.get("news", {}).get("results", [])
            for item in news + web:
                url = item.get("url")
                if not url or url in seen:
                    continue
                seen.add(url)
                results.append({
                    "title": item.get("title", "")[:140],
                    "url": url,
                    "source": (item.get("meta_url") or {}).get("hostname", "") or item.get("source", ""),
                    "date": item.get("age") or item.get("page_age", ""),
                    "description": (item.get("description") or "")[:220],
                })
        except Exception as e:
            print(f"# Query '{q}' failed: {e}", file=sys.stderr)

    # Filter by age approximation (Brave returns age like "2 days ago")
    def age_days(item):
        age = (item.get("date") or "").lower()
        if "hour" in age:
            return 0
        if "day" in age:
            try:
                return int(age.split()[0])
            except Exception:
                return 5
        if "week" in age:
            try:
                return int(age.split()[0]) * 7
            except Exception:
                return 30
        if "month" in age:
            try:
                return int(age.split()[0]) * 30
            except Exception:
                return 60
        if "year" in age:
            return 400
        return 999

    fresh = [r for r in results if age_days(r) <= args.days]
    fresh.sort(key=age_days)
    print(json.dumps(fresh[:args.max_results], ensure_ascii=False, indent=2))
    print(f"# {len(results)} total results, {len(fresh)} within {args.days}j, kept top {min(args.max_results, len(fresh))}", file=sys.stderr)


if __name__ == "__main__":
    main()
