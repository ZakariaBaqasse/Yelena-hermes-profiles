#!/usr/bin/env python3
"""
Render a meeting brief to HTML + PDF.

This script composes the final HTML from a simple Python dict and the
templates/brief.html.j2 template. No Jinja dependency required — we use
str.format_map with a pre-processing step for loops.

For production, a Claude Code or LLM pass should fill the fields with
rich content (synergies, sujets, angle relationnel). This script assumes
the caller has already prepared the data dict.

Usage:
    python render_brief.py --data-json brief-data.json --slug pierre-thomas-soultrait
"""
import argparse, datetime, html as html_mod, json, os, re, subprocess, sys, urllib.request
from pathlib import Path

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", str(Path.home() / ".openclaw/workspace")))
HTML2PDF = WORKSPACE / "tools" / "html2pdf.js"
TEMPLATE = Path(__file__).resolve().parent.parent / "templates" / "brief.html.j2"


def esc(s):
    return html_mod.escape(str(s or ""), quote=True)


def download_photo(url, slug):
    if not url:
        return ""
    try:
        dest = Path(f"/tmp/meeting-brief-photo-{slug}.jpg")
        urllib.request.urlretrieve(url, str(dest))
        return str(dest)
    except Exception as e:
        print(f"# photo download failed: {e}", file=sys.stderr)
        return ""


def render_template(tpl: str, data: dict) -> str:
    """Minimal Jinja-like renderer supporting {{var}}, {% for %}, {% if %}."""
    def render_for(match):
        var_name, iterable_name, block = match.group(1), match.group(2), match.group(3)
        items = data.get(iterable_name, []) or []
        out = []
        for it in items:
            sub = block
            if isinstance(it, dict):
                # Replace {{var_name.key}} with escaped value
                for k, v in it.items():
                    sub = sub.replace("{{" + var_name + "." + k + "}}", esc(v))
                # Allow {{var_name}} when item exposes a conventional text-like field
                display = it.get("text", it.get("value", it.get("title", "")))
                sub = sub.replace("{{" + var_name + "}}", esc(display))
            else:
                # Support simple scalar loop items, e.g. topics: ["item 1", "item 2"]
                sub = sub.replace("{{" + var_name + "}}", esc(it))
            # Trailing placeholders → empty
            sub = re.sub(r"\{\{" + re.escape(var_name) + r"\.[a-zA-Z_]+\}\}", "", sub)
            sub = re.sub(r"\{\{" + re.escape(var_name) + r"\}\}", "", sub)
            out.append(sub)
        return "".join(out)

    def render_if(match):
        var_name, block = match.group(1), match.group(2)
        if var_name.startswith("not "):
            val = not data.get(var_name[4:], None)
        else:
            val = bool(data.get(var_name))
        return block if val else ""

    tpl = re.sub(r"\{%\s*for\s+(\w+)\s+in\s+(\w+)\s*%\}(.*?)\{%\s*endfor\s*%\}", render_for, tpl, flags=re.DOTALL)
    tpl = re.sub(r"\{%\s*if\s+([^%]+?)\s*%\}(.*?)\{%\s*endif\s*%\}", render_if, tpl, flags=re.DOTALL)

    # Simple {{var}} substitution (support |safe for raw html)
    def simple_sub(match):
        key = match.group(1).strip()
        safe = False
        if "|safe" in key:
            key = key.replace("|safe", "").strip()
            safe = True
        val = data.get(key, "")
        if safe:
            return str(val or "")
        return esc(val)

    tpl = re.sub(r"\{\{\s*([^}]+?)\s*\}\}", simple_sub, tpl)
    return tpl


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-json", required=True, help="Path to JSON with brief data (see example-data.json)")
    ap.add_argument("--slug", required=True, help="Slug used for output filenames")
    args = ap.parse_args()

    data = json.loads(Path(args.data_json).read_text())

    # Photo: download locally so it embeds in PDF
    photo_url = data.get("photo_url", "")
    if photo_url and photo_url.startswith(("http://", "https://")):
        local = download_photo(photo_url, args.slug)
        if local:
            data["photo_url"] = "file://" + local

    # Initials fallback
    if not data.get("photo_url"):
        name_parts = (data.get("name") or "").split()
        data["initials"] = "".join(p[0].upper() for p in name_parts[:2]) or "?"

    # Generation date
    data["generation_date"] = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")

    # Render template
    tpl = TEMPLATE.read_text()
    html_out = render_template(tpl, data)

    out_html = WORKSPACE / "tools" / f"brief-rdv-{args.slug}-{datetime.date.today().isoformat()}.html"
    out_pdf = WORKSPACE / "tools" / f"brief-rdv-{args.slug}-{datetime.date.today().isoformat()}.pdf"
    out_html.write_text(html_out)
    print(f"HTML : {out_html}", file=sys.stderr)

    # PDF generation
    if HTML2PDF.exists():
        r = subprocess.run(["node", str(HTML2PDF), str(out_html), str(out_pdf)],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(f"# html2pdf.js error: {r.stderr[:400]}", file=sys.stderr)
    else:
        subprocess.run(["wkhtmltopdf", "--enable-local-file-access", str(out_html), str(out_pdf)],
                       capture_output=True, text=True)

    try:
        info = subprocess.run(["pdfinfo", str(out_pdf)], capture_output=True, text=True)
        pages = 0
        for line in info.stdout.splitlines():
            if line.startswith("Pages:"):
                pages = int(line.split()[-1])
        if pages != 1:
            print(f"# WARN: PDF has {pages} pages (expected 1)", file=sys.stderr)
        print(f"PDF  : {out_pdf} ({pages} page{'s' if pages!=1 else ''})")
    except Exception as e:
        print(f"# pdfinfo error: {e}", file=sys.stderr)
        print(f"PDF  : {out_pdf}")


if __name__ == "__main__":
    main()
