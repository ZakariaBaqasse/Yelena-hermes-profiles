#!/usr/bin/env bash
# Meeting brief pipeline — orchestrates scraping + data preparation + rendering.
#
# Usage:
#   ./run_pipeline.sh --name "Pierre-Thomas Louis de Soultrait" \
#                     --linkedin "https://www.linkedin.com/in/..." \
#                     --context "Directeur pays d'un bailleur, RDV sur un financement" \
#                     --meeting-date "2026-04-17"
#
# This pipeline collects raw data (LinkedIn + news) into staging JSON,
# then delegates the creative synthesis (profile summary, synergies, sujets,
# angle relationnel) to a model pass — because these require editorial
# judgment, not templating.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

NAME=""
LINKEDIN=""
CONTEXT=""
MEETING_DATE="$(date +%Y-%m-%d)"
COMPANY=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --name) NAME="$2"; shift 2;;
    --linkedin) LINKEDIN="$2"; shift 2;;
    --context) CONTEXT="$2"; shift 2;;
    --meeting-date) MEETING_DATE="$2"; shift 2;;
    --company) COMPANY="$2"; shift 2;;
    *) echo "Unknown arg: $1"; exit 1;;
  esac
done

if [[ -z "$NAME" ]]; then
  echo "ERROR: --name required" >&2
  exit 1
fi

SLUG=$(echo "$NAME" | iconv -t ASCII//TRANSLIT | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g;s/-\+/-/g;s/^-//;s/-$//')

echo "== meeting-brief pipeline =="
echo "name     : $NAME"
echo "linkedin : $LINKEDIN"
echo "date RDV : $MEETING_DATE"
echo "slug     : $SLUG"
echo

echo ">> 1/3 LinkedIn scrape..."
if [[ -n "$LINKEDIN" ]]; then
  python3 "$SCRIPT_DIR/linkedin_scrape.py" --url "$LINKEDIN" > "$TMPDIR/linkedin.json" 2>> "$TMPDIR/scrape.log" || {
    echo "   LinkedIn scrape failed; continuing with empty data" >&2
    echo '{"profile": {}, "posts": []}' > "$TMPDIR/linkedin.json"
  }
else
  echo '{"profile": {}, "posts": []}' > "$TMPDIR/linkedin.json"
fi
echo "   posts recovered: $(jq '.posts | length' "$TMPDIR/linkedin.json")"

echo ">> 2/3 News search..."
python3 "$SCRIPT_DIR/news_search.py" --name "$NAME" ${COMPANY:+--company "$COMPANY"} > "$TMPDIR/news.json" 2>> "$TMPDIR/scrape.log" || echo '[]' > "$TMPDIR/news.json"
echo "   news items: $(jq 'length' "$TMPDIR/news.json")"

echo ">> 3/3 Ready for editorial pass."
echo
echo "Raw data collected in: $TMPDIR"
echo "  - linkedin.json"
echo "  - news.json"
echo "  - scrape.log"
echo
echo "Next: prepare the final brief-data.json with editorial synthesis"
echo "(profile_summary, synergies[], topics[], relational_angle, tags[]),"
echo "then run:"
echo "  python3 $SCRIPT_DIR/render_brief.py --data-json brief-data.json --slug $SLUG"
echo
# Pretty print raw data for the operator / LLM pass
echo "--- linkedin.json (preview) ---"
jq '{profile: .profile, posts_count: (.posts | length), first_post: .posts[0]}' "$TMPDIR/linkedin.json" 2>/dev/null || cat "$TMPDIR/linkedin.json"
echo
echo "--- news.json ---"
cat "$TMPDIR/news.json"
