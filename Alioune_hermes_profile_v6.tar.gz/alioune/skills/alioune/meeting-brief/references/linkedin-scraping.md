# LinkedIn scraping — Apify harvestapi

## Actors

- `harvestapi~linkedin-profile-posts` — posts récents d'un profil.
- `harvestapi~linkedin-profile` — profil complet (expérience, éducation, skills).
- `harvestapi~linkedin-company` — page entreprise.

## Endpoint

```
POST https://api.apify.com/v2/acts/{actor}/run-sync-get-dataset-items?token=$APIFY_API_TOKEN&timeout=180
```

## Body — profile-posts

```json
{
  "profileUrls": ["https://www.linkedin.com/in/<handle>"],
  "maxPosts": 10,
  "postType": "all"
}
```

Réponse : array de posts avec `text`, `postedAt`, `likesCount`, `commentsCount`, `repostsCount`, `url`.

## Body — profile

```json
{
  "profileUrls": ["https://www.linkedin.com/in/<handle>"]
}
```

Réponse : objet profil avec `fullName`, `headline`, `currentPosition`, `experience[]`, `education[]`, `profilePicture`.

## Limites

- Plan Starter Apify : ~500 posts / mois approximativement. Attention à ne pas vider le crédit sur un profil hyper actif.
- Timeout fréquent sur les gros profils (>1000 posts en DB Apify). Toujours passer `maxPosts` ≤ 15.

## Fallback si Apify indisponible

1. Si le profil est public et a un flag « Open to network », on peut scraper via `BrowserTool` connecté.
2. Sinon : extraction manuelle depuis WebFetch sur l'URL du profil (limité, pas de posts).
3. En dernier recours : demander au cabinet un résumé du profil s'il le connaît.

## Structure de photo

`profilePicture` renvoie une URL Cloudfront / LinkedIn. Ces URLs expirent en ~24h — télécharger l'image et la référencer localement dans le PDF :

```python
import urllib.request
urllib.request.urlretrieve(photo_url, f"/tmp/{slug}.jpg")
```

## Dates LinkedIn

Format `postedAt` = ISO avec timezone. Convertir en « il y a X jours » pour l'affichage si < 60 jours, sinon date absolue.
