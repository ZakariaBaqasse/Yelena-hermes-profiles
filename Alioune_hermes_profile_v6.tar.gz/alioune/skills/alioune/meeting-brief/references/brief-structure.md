# Structure du brief RDV

## Objectif

Un document que Le Dircab peut lire en 90 secondes avant d'entrer en RDV.

## Header

- Photo (ronde, 66×66px) OU initiales sur fond teal #2DBEB6 si pas de photo trouvée.
- Eyebrow teal : « BRIEF RDV — [DATE] »
- Nom complet en gros
- Sous-titre : poste actuel @ société
- 3-4 tags : secteurs, géographies, types d'acteur (ex: « TECH B2B », « EUROPE », « 250+ collaborateurs »)

## Profil (bloc 1)

3-4 lignes maximum. Structure :
1. Formation courte (ex: « MBA MIT Sloan · IAE Paris 1 »)
2. Parcours (2-3 étapes clés)
3. Position actuelle + responsabilités
4. Signal distinctif (prix, board, conseil, angle public)

## Actualités (bloc 2)

3 items, chacun :
- Titre court (≤ 100 car)
- Source + date (ex: « Jeune Afrique · 19 mars 2026 »)
- Lien (raccourci si possible)

Si pas d'actualité < 90j : dire « Pas d'actualité notable récente » plutôt que remplir avec du bruit.

## Posts LinkedIn (bloc 3)

3 posts récents, chacun :
- Sujet en 1 ligne
- Date
- Engagement si significatif (likes/comments > 100)
- Angle : ce que le post révèle du positionnement ou des priorités actuelles

Si la personne ne poste pas : « Profil peu actif sur LinkedIn » + dernier post daté.

## Enjeux de la rencontre (bloc 4)

3 enjeux classés, chacun :
- Titre de l'enjeu (ex : « Financement de la seconde phase du programme X »)
- Ce que la personne vient chercher, et ce qu'elle peut apporter
- Le dossier du cabinet auquel ça se raccroche, et l'état d'avancement connu

Voir `angles-institutionnels.md` pour la logique de sélection.

## Sujets à aborder (bloc 5)

4 sujets, priorisés :
1. Sujet prioritaire (lié à une actualité ou à un dossier en cours)
2. Sujet secondaire d'intérêt mutuel
3. Sujet de découverte / qualification
4. Sujet léger / relationnel

## Angle relationnel (bloc 6)

Un paragraphe de 3-4 lignes :
- Comment ouvrir (accroche personnelle si possible)
- Qui mentionner (connexions en commun, références crédibles)
- Ce qu'il faut éviter (sujets sensibles, dossiers contentieux, positions non arrêtées)
- Ce que le cabinet peut proposer immédiatement (présentation, invitation, intro)

## Règles de longueur

| Bloc | Max |
|---|---|
| Nom | 1 ligne |
| Profil | 4 lignes |
| Actualité × 3 | 2 lignes chacune |
| Post LinkedIn × 3 | 2 lignes chacun |
| Synergie × 3 | 3 lignes chacune |
| Sujet × 4 | 1 ligne chacun |
| Angle relationnel | 4 lignes |

Si ça dépasse : couper dans Actualités ou Posts en premier, jamais dans Synergies ou Sujets.
