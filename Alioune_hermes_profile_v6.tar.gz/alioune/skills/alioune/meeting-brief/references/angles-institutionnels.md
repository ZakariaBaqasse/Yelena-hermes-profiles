# Qualifier les enjeux d'une rencontre institutionnelle

Dans un brief d'entreprise, on cherche des « synergies ». Au cabinet, la question n'est
pas *ce qu'on peut vendre à cette personne*, c'est **ce qu'elle vient chercher, ce
qu'elle peut apporter, et à quel dossier ça se rattache**. Un brief qui rate ça fait
perdre la réunion.

## Les trois questions, toujours dans cet ordre

1. **Que vient-elle chercher ?** Un arbitrage, une signature, une audience, un déblocage
   administratif, un soutien politique, une information — ou simplement exister dans
   l'agenda. C'est presque toujours **une seule** chose ; le reste est l'emballage.
2. **Que peut-elle apporter ?** Un financement, une expertise, un accès, un relais
   d'opinion, un investissement, une caution internationale. N'écrire que ce qui est
   **vérifiable** : un engagement annoncé publiquement, un précédent, un montant déjà
   décaissé ailleurs. Jamais une intention supposée.
3. **À quel dossier ça se rattache ?** Nom du dossier, état d'avancement connu, dernière
   décision publique. **S'il n'y en a aucun**, l'écrire noir sur blanc : « aucun dossier
   connu ne relie cette personne au cabinet à ce jour ». C'est une information utile, pas
   un échec du brief.

## Typologies — ce qu'il faut chercher pour chacune

| Profil | Ce qu'il vient généralement chercher | À vérifier avant |
|---|---|---|
| **Bailleur, institution financière** (Banque mondiale, BAD, FMI, UE, agences bilatérales) | Une contrepartie, une réforme, la levée d'une condition, la visibilité d'un décaissement | L'**état réel** de ses financements au pays — intention, approbation, signature, décaissement. Les confondre est l'erreur classique : voir `veille-financements`. |
| **Corps diplomatique** (ambassadeur, chargé d'affaires) | Une audience, un positionnement, la préparation d'une visite, un dossier bilatéral | Date de prise de fonctions et agrément ; derniers actes bilatéraux ; sujets sensibles connus entre les deux États |
| **Membre du gouvernement, dirigeant d'institution** | Un arbitrage interministériel, un appui budgétaire, une nomination | Sa fonction **courante** (piège n°1), le texte qui la fonde, et sa position déjà exprimée publiquement sur le sujet |
| **Patronat, investisseur, dirigeant d'entreprise** | Une autorisation, un marché, un régime fiscal, le règlement d'un litige | Ce que l'entreprise a déjà obtenu ou demandé ; ses contentieux publics ; son ancrage réel (emplois, sites, historique) |
| **Élu local, autorité régionale** | Un équipement, un arbitrage territorial, une visite | Les engagements déjà pris publiquement sur ce territoire — et ce qui a été livré ou non |
| **Organisation régionale** (UEMOA, CEDEAO, Union africaine) | Un alignement, une candidature, une contribution, un calendrier | Les échéances statutaires en cours et la position déjà tenue par le pays |
| **Média, société civile, chercheur** | Une parole, un accès, une réaction | Ce que la personne a publié récemment sur le pays, son angle habituel, et ce qui a déjà été dit officiellement |

## Ce qui rend un enjeu utile plutôt que décoratif

Le test : **si cette personne écrit au cabinet trois mois après la rencontre, est-ce de
cet enjeu qu'elle parlera ?** Si la réponse est vague, l'enjeu est décoratif — le
supprimer plutôt que de remplir le bloc. Trois blocs justes valent mieux que six mous.

Trois défauts récurrents :

- **L'enjeu générique.** « Coopération économique renforcée » ne veut rien dire et ne se
  raccroche à aucun dossier. Écrire l'objet concret, ou ne rien écrire.
- **L'enjeu supposé.** Affirmer qu'un bailleur « pourrait financer » un programme parce
  que c'est plausible est une invention. Ne s'appuyer que sur du public et du daté.
- **L'enjeu hors mandat ou hors géographie.** Une institution dont le mandat ne couvre pas
  le pays, une entreprise sans présence locale : le dire vaut mieux qu'un angle fabriqué.

## Le point de vigilance — jamais omis

Chaque brief se termine par une ligne de vigilance : **un sujet sur lequel la position
officielle n'est pas arrêtée, un contentieux en cours, une déclaration récente qui
pourrait être opposée**. C'est souvent la ligne la plus utile du document : celle qui
évite un engagement pris en séance sur un dossier non tranché.

Si rien n'est identifié, l'écrire — « aucun point de vigilance identifié sur sources
publiques à la date du brief ». Une absence vérifiée n'est pas un blanc.

## Sources et liens

Tout fait cité dans le bloc enjeux porte sa source **en lien cliquable** et sa date. Un
enjeu sans source est une opinion, et une opinion n'entre pas dans un brief de cabinet.
