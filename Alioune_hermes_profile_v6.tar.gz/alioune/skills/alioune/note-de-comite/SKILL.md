---
id: Y0382
name: note-de-comite
description: "Rédige la note soumise au comité d'investissement dans le format et la doctrine du fonds quand ils sont fournis : recommandation et demande d'approbation en tête, thèse d'investissement et ce qui doit être vrai pour qu'elle se réalise, économie de l'affaire recalculée, risques et atténuations réellement disponibles, cas d'échec explicite, termes et conditions suspensives, liste de ce qui n'a pas pu être vérifié — sans jamais fabriquer un chiffre, un multiple ou une clause juridique non fournie."
bucket: C
tags: [Investissement, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Note de comité — instruire une décision, pas plaider un dossier

## Ce qu'il faut avoir sous la main
- **L'opération** : entreprise, montant demandé, instrument envisagé (equity, dette convertible, quasi-fonds propres…), et le stade du process (pré-comité, comité final, avant décaissement).
- **Le dossier déjà constitué** : mémo d'investissement, résultats de due diligence, états financiers, analyse marché — ce qui existe, même incomplet.
- **Le gabarit et la doctrine du fonds** si le fonds en a un : format de note attendu, tickets habituels, secteurs ou zones exclus, niveaux de délégation.
- **Ce qui est déjà tranché** versus **ce qui reste ouvert** dans le comité — valorisation négociée, clauses déjà discutées, points de blocage identifiés.
- **Les pièces qui manquent encore** ou qu'on attend d'un tiers (audit, avis juridique, référence bancaire).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — La recommandation et sa demande, en première ligne

Avant tout narratif, avant la présentation de l'entreprise : ce qu'on demande d'approuver. Montant, instrument, conditions attachées, en une poignée de lignes que le comité peut lire en dix secondes. Une note qui construit son suspense jusqu'à la conclusion oblige le comité à lire quinze pages avant de savoir ce qu'on lui demande — c'est le premier piège du genre, et il se corrige en écrivant la fin d'abord.

Si la demande change selon un scénario (montant réduit, tranche conditionnelle), les deux versions sont posées ici, pas noyées plus loin.

### Étape 2 — Séparer fait, estimation et opinion

Reprends chaque donnée du dossier — chiffre de vente, taille d'équipe, part de marché, projection — et marque sa nature : **fait vérifié** (audité, constaté, sourcé), **estimation** (calcul ou extrapolation, avec sa méthode), **opinion** (jugement de l'équipe deal ou du fondateur). Ces trois catégories ne se mélangent jamais dans la même phrase du livrable.

Un comité qui ne sait pas si « l'entreprise est leader sur son segment » est un fait établi ou l'opinion du fondateur ne peut pas pondérer correctement le reste de la note — et c'est précisément le rôle de cette étape que de lui donner ce repère.

### Étape 3 — La thèse d'investissement et ce qui doit être vrai

Formule la thèse en une phrase, puis découpe-la en trois ou quatre affirmations **falsifiables** : ce qui doit être vrai pour que l'investissement se réalise comme prévu. Pas « l'équipe est solide » — plutôt « le directeur commercial recruté en `⟦date⟧` peut porter seul l'expansion prévue sur `⟦zone⟧` ».

Chaque affirmation reçoit son statut de vérification : confirmée par la due diligence, partiellement vérifiée, ou non vérifiée à ce stade — reportée à l'étape 9.

### Étape 4 — Marché, concurrence, équipe — établi versus supposé

Traite ces trois blocs avec la même discipline que le dossier de deal : ce qui vient d'une source identifiée (étude sectorielle, entretien, registre) reste sourcé ; ce qui vient d'une déclaration non vérifiée du fondateur est marqué comme telle. Tu ne recopies pas la taille de marché ou la part de concurrence donnée dans le mémo sans vérifier si elle est sourcée — un chiffre repris sans source dans le mémo original reste un chiffre inventé dans la note de comité.

Sur l'équipe, signale spécifiquement les postes clés vacants ou récemment pourvus : c'est un risque d'exécution qu'un tableau de compétences ne fait pas apparaître.

### Étape 5 — L'économie de l'affaire, recalculée et non recopiée

Les chiffres du business plan ne se copient pas dans la note : ils se **recalculent** à partir des inputs disponibles (hypothèses de volume, de prix, de marge fournies par le dossier), et l'écart entre le chiffre du fondateur et le chiffre recalculé est montré, pas gommé. Dans un contexte où la comptabilité de la cible est souvent informelle ou partiellement auditée, ce recalcul est ce qui distingue une note utile d'une note qui répète le mémo.

Chaque agrégat cité (chiffre d'affaires, marge, valorisation, multiple) porte sa source et la méthode de calcul retenue.

### Étape 6 — Risques classés, atténuations réellement disponibles

Liste les risques par ordre de matérialité pour la thèse — pas par ordre alphabétique ni par ordre d'apparition dans le mémo. Pour chacun, distingue l'**atténuation réellement disponible aujourd'hui** (une clause contractuelle, une garantie, un covenant, une tierce partie déjà engagée) d'un **vœu pieux** (« l'équipe va lever davantage », « le marché va se structurer ») qui n'atténue rien tant qu'il n'est pas matérialisé.

Signale les risques propres au contexte : dépendance à un acteur dominant non contrôlable (opérateur télécom, administration, banque de réseau), exposition au cash informel qui fragilise la traçabilité des revenus déclarés, risque de change si le financement ou le compte de la cible n'est pas dans la même devise que le fonds.

### Étape 7 — Le cas d'échec, écrit explicitement

C'est le garde-fou contre la note qui plaide. Écris la phrase qui commence par : *« Cette décision est mauvaise si… »* — et complète-la avec les deux ou trois affirmations de l'étape 3 dont l'invalidation ferait basculer la thèse. Une note dont toutes les sections concluent positivement n'a pas instruit une décision, elle a construit un argumentaire — et c'est cette section qui, relue dans deux ans, protège la crédibilité de celui qui l'a rédigée.

### Étape 8 — Termes, structure, conditions suspensives

Pose les termes proposés (instrument, montant, valorisation ou taux, clauses de gouvernance, droits attachés) dans le vocabulaire et la structure juridique retenus par le fonds — actions de préférence, dette convertible, garanties personnelles ou nantissements selon les usages OHADA quand la structuration a été précisée par l'équipe deal ; tu ne complètes jamais une clause juridique de ton propre chef.

Une recommandation favorable sans condition suspensive n'est pas exploitable pour le comité : liste les pièces, vérifications ou clauses **à lever avant décaissement** — pas comme un vœu, comme une liste que quelqu'un devra cocher.

### Étape 9 — Ce qui n'a pas pu être vérifié, et pourquoi

Liste explicitement les points restés en suspens : document non transmis, accès refusé, délai de due diligence trop court, connecteur ou source inaccessible, tiers qui n'a pas répondu. Pour chacun, dis pourquoi ce n'a pas été vérifié et ce que ça pèse dans la décision — passer ce point sous silence prive le comité de l'information dont il a le plus besoin pour pondérer le reste de la note.

## Format de sortie
- **Livrable** : la note de comité — recommandation et demande d'approbation en tête ; présentation de l'entreprise et de l'opération ; thèse et affirmations à vérifier avec leur statut ; marché, concurrence, équipe ; économie de l'affaire recalculée avec sources ; risques classés et atténuations disponibles ; cas d'échec ; termes et structure ; conditions suspensives ; ce qui n'a pas été vérifié ; annexes citées.
- **Format et vocabulaire repris du gabarit du fonds** quand il est fourni — titres de sections, ordre, niveau de détail attendu par le comité. En son absence, la structure ci-dessus fait référence, signalée comme structure par défaut.
- **Structure** : Markdown clair — answer-first (la recommandation d'abord, son instruction ensuite) ; tableaux pour les risques, les termes, les points non vérifiés.
- **Longueur** : proportionnée à la taille et au stade de l'opération, sans remplissage. Une note pour un comité final est plus dense qu'une note de pré-screening.
- **Règle 0 invention** : aucun chiffre, multiple, taux ou clause juridique inventé. Une donnée manquante reste `⟦à renseigner⟧` ou `[à confirmer]`, jamais remplacée par une valeur plausible.

## Règles
1. **La recommandation se met en tête, jamais en conclusion.** Montant, instrument, conditions : le comité doit savoir en dix secondes ce qu'on lui demande d'approuver.
2. **Fait, estimation et opinion ne se mélangent jamais dans la même phrase.** La séparation est visible dans le document, pas seulement dans ton raisonnement — un comité qui ne distingue pas les trois ne peut pas arbitrer.
3. **Toute note porte son cas d'échec.** Ce qui, si c'était faux, rendrait la décision mauvaise se dit explicitement, même — surtout — quand la recommandation est favorable.
4. **Une recommandation favorable sans condition suspensive n'est pas un livrable complet.** « Oui » n'est pas exploitable ; « oui sous réserve de… » l'est.
5. **Ce qui n'a pas pu être vérifié se dit, avec la raison.** Le silence sur un point non vérifié prive le comité de l'information nécessaire pour pondérer le reste.
6. **Les chiffres du mémo se recalculent, ils ne se recopient pas.** Un chiffre d'affaires, une marge ou un multiple cité sans méthode de calcul visible n'est pas une donnée établie.
7. **Le contexte local structure les risques et les termes, il ne se limite pas à un décor.** Comptabilité informelle, dépendance à un tiers dominant non contrôlable, structuration des garanties dans le cadre OHADA, exposition au change : une note qui les ignore ne protège pas la décision qu'elle instruit.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; l'envoi de la note au comité, la communication d'un terme à la cible ou le déclenchement d'un décaissement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Gabarit du fonds non fourni** — tu utilises la structure par défaut du Format de sortie et tu le signales explicitement, plutôt que d'improviser un format qui ressemblerait à celui du fonds sans l'être.
- **Due diligence absente ou partielle** — tu produis la note, tu marques la recommandation comme **provisoire**, et tu listes en priorité ce qui doit être vérifié avant tout décaissement.
- **Chiffres contradictoires entre business plan, audit et déclaration du fondateur** — tu exposes les trois versions et leur source, tu ne tranches pas seul en faveur de la plus favorable à l'opération.
- **Une pièce annoncée mais absente** (« l'audit est joint », rien n'est transmis) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Point juridique ou fiscal précis demandé** (rédaction d'une clause, montage de garantie) — tu poses la question dans la note comme point à trancher avec un conseil juridique, tu ne rédiges pas la clause toi-même.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient (due diligence, valorisation, structuration juridique).
- **Action sortante demandée** (envoi de la note, communication d'un terme à la cible, déclenchement de virement) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné, en le listant à l'étape 9.
