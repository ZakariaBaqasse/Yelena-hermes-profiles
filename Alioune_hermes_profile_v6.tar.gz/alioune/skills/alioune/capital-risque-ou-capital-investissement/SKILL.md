---
id: Y0391
name: capital-risque-ou-capital-investissement
description: "Établit, avant toute instruction de dossier, dans quel métier le fonds opère — capital-risque ou capital-investissement — parce que presque tout en découle : la façon de fixer le prix, la nature de l'instrument, l'objet de la vérification préalable, la gouvernance recherchée, la sortie visée et le reporting aux souscripteurs. Pose la question à chaque dossier plutôt qu'une seule fois, sans jamais déduire la doctrine d'un fonds de son nom ou de la taille de son ticket."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Capital-risque ou capital-investissement — savoir quel métier on exerce avant d'instruire

## Ce qu'il faut avoir sous la main
- **La thèse écrite du fonds** si elle existe, ou à défaut ta description du mandat : stade des entreprises visées, taille de ticket, secteurs.
- **Le nombre de poches** gérées par le fonds, si plusieurs, et le mandat de chacune.
- **Le dossier à instruire** : nom, stade tel qu'annoncé par l'entreprise, ce qu'elle produit comme résultat aujourd'hui (même « rien encore »).
- **Ce que tu as déjà en main** : mémorandum, états financiers, term sheet en discussion.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Poser la question du métier, sans la déduire

Avant de regarder le dossier, cherche la thèse écrite du fonds. Si elle est transmise, elle tranche. Si elle n'est pas transmise, tu ne devines pas à partir du nom du fonds, de la taille du ticket évoquée ou des dossiers déjà vus dans la conversation — un fonds qui a fait de l'amorçage l'an dernier peut lever une poche de capital-investissement cette année. Le métier exercé se marque `⟦à renseigner⟧` et se demande explicitement : *« Ce ticket s'inscrit-il dans une logique de prise de participation minoritaire sur une entreprise en construction, ou de prise de contrôle sur une entreprise qui produit déjà des résultats mesurables ? »*

C'est la question qui structure tout le reste. Ne l'esquive pas parce que le fondateur du dossier ou le chargé d'affaires semble pressé de passer à l'instruction — l'instruction sans grille n'a pas de valeur.

### Étape 2 — Cartographier les poches, si le fonds en a plusieurs

Un même véhicule peut loger une poche d'amorçage et une poche de croissance, avec des comités et des critères distincts. Établis, pour chaque poche déclarée : son mandat, son stade cible, sa fourchette de ticket, son horizon de détention. Un dossier qui hésite entre deux poches n'est pas encore prêt à être instruit — il faut d'abord trancher de quelle poche il relève, sinon l'instruction sert deux maîtres à la fois.

### Étape 3 — Vérifier le stade réel de l'entreprise face au métier déclaré

Le piège le plus coûteux ne vient pas d'un mauvais choix de métier, mais d'un décalage entre le stade annoncé et le stade réel. Une entreprise qui se présente comme « en forte croissance » pour attirer du capital-investissement peut n'avoir ni comptes audités, ni résultat stabilisé — elle relève alors du capital-risque, quel que soit son âge. Inversement, une entreprise qui se présente comme « jeune et innovante » pour éviter un examen de rentabilité peut déjà produire un excédent brut d'exploitation positif depuis plusieurs exercices — elle relève du capital-investissement, quel que soit son discours.

Confronte le narratif du dossier aux pièces disponibles (comptes, résultat, ancienneté de l'activité) avant d'entériner le métier proposé. Un désaccord entre les deux se signale, il ne se tranche pas seul.

### Étape 4 — Décliner ce que le métier commande

Une fois le métier fixé pour ce dossier, il commande six choses, et aucune ne se décide indépendamment des autres :

- **Le prix** : un multiple de revenus ou de résultat, ou une construction à rebours de la dilution cible et du tour suivant anticipé — les deux logiques ne se mélangent pas dans une même valorisation.
- **L'instrument** : actions ordinaires, actions de préférence, obligations convertibles côté capital-risque ; actions accompagnées de dette d'acquisition ou de dette senior côté capital-investissement. Le droit OHADA des sociétés commerciales encadre différemment ces instruments — une action de préférence n'a pas le même régime qu'une avance en compte courant, et un montage qui fonctionne dans une juridiction de common law ne se transpose pas sans vérification.
- **L'objet de la vérification préalable** : la thèse, l'équipe, la taille du marché adressable côté capital-risque ; la qualité des comptes, les engagements hors bilan, la conformité fiscale et sociale, la capacité de remboursement côté capital-investissement — et dans un contexte où une partie de l'activité peut être restée informelle, la fiabilité même des états financiers transmis devient le premier point à vérifier, avant tout ratio.
- **La gouvernance obtenue** : droit d'information et droits de veto sur des décisions structurantes côté capital-risque ; contrôle effectif du conseil et souvent du poste de direction financière côté capital-investissement.
- **La sortie visée** : tour de financement suivant ou cession industrielle côté capital-risque ; cession stratégique, ouverture de capital ou reprise par la direction en place côté capital-investissement.
- **Le reporting aux souscripteurs** : multiple sur capitaux investis et taux de rendement interne restent les mêmes indicateurs de surface, mais les repères de comparaison — le rythme attendu, la dispersion normale des résultats entre lignes — ne sont pas les mêmes d'un métier à l'autre.

### Étape 5 — Vérifier le vocabulaire avant de le livrer

Le vocabulaire trahit le métier plus vite que n'importe quelle analyse. Parler de préférence de liquidation à un fonds qui rachète des entreprises rentables avec effet de levier, ou parler de covenants bancaires classiques à un fonds d'amorçage qui n'a jamais mis de dette dans une ligne, décrédibilise l'ensemble du livrable — même quand le fond de l'analyse est juste. Avant de livrer, relis les termes employés à l'aune du métier fixé à l'étape 1 : si un terme appartient à l'autre métier, il se corrige ou s'explique.

### Étape 6 — Écrire la réponse dans la mémoire, pas seulement dans le livrable

Le métier ne se redébat pas à chaque dossier suivant du même fonds ou de la même poche, sauf signal contraire. Une fois établi, il s'enregistre dans la mémoire d'entreprise avec sa source (thèse écrite, ou hypothèse posée faute de thèse transmise), pour que les instructions suivantes s'y conforment sans reposer la question de fond — elles ne reposent que la question du stade réel du dossier concerné, qui elle se vérifie à chaque fois.

## Format de sortie
- **Livrable 1 — fiche de cadrage du métier**, produite au démarrage de la relation avec un fonds ou dès qu'une poche nouvelle apparaît : type de capital pratiqué, liste des poches et mandat de chacune, stade et ticket cible par poche, instruments utilisés, horizon de détention, gouvernance recherchée, sorties visées, indicateurs servis aux souscripteurs. Chaque case renseignée ou marquée `⟦à renseigner⟧` accompagnée de la question précise à poser pour la lever.
- **Livrable 2 — entête de qualification**, produite à chaque dossier instruit : de quelle poche il relève, quel métier s'applique et sur quelle base (thèse écrite ou hypothèse posée), et la liste des points d'instruction que ce choix rend obligatoires (ce qu'il faut vérifier, ce qu'il ne faut pas exiger à ce stade).
- **Structure** : Markdown, answer-first (le métier retenu et son motif d'abord, la déclinaison ensuite) ; tableau pour la fiche de cadrage quand plusieurs poches coexistent.
- **Longueur** : la fiche de cadrage tient sur une page ; l'entête de qualification tient en quelques lignes — elle précède l'instruction, elle ne la remplace pas.
- **Règle 0 invention** : aucun multiple, aucun taux, aucun seuil de ticket inventé. Ce qui n'est pas fourni par le fonds ou la cible reste `⟦à renseigner⟧`.

## Règles
1. **Le métier ne se déduit jamais du nom, de la taille du ticket ou de l'historique des dossiers vus.** Il se lit dans une thèse écrite, ou se marque `⟦à renseigner⟧` et se demande.
2. **La question se repose à chaque dossier**, pas une fois pour tout le fonds — un fonds multi-poches, ou une entreprise dont le stade réel diverge de son discours, changent la réponse.
3. **Le stade réel prime sur le stade annoncé.** Une divergence entre le narratif du dossier et les pièces disponibles (comptes, résultat, ancienneté) se signale avant que le métier soit entériné.
4. **Les six conséquences du choix (prix, instrument, vérification, gouvernance, sortie, reporting) se déclinent ensemble**, jamais une seule isolément — instruire le prix sans en tirer l'instrument correspondant produit une incohérence qui se verra en comité.
5. **Le vocabulaire du métier appliqué se vérifie avant livraison.** Un terme de l'autre métier employé par erreur se corrige, il ne se laisse pas passer parce que « l'idée est la même ».
6. **Le contexte OHADA n'est pas un décor** dès qu'il touche à la nature de l'instrument ou aux sûretés : un montage pensé pour une autre juridiction se vérifie avant d'être proposé tel quel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer une term sheet, communiquer un avis à la cible ou engager le fonds sur un montage est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Thèse non transmise** — tu poses le métier en `⟦à renseigner⟧`, tu formules la question exacte à envoyer au fonds, et tu produis quand même l'entête de qualification sur l'hypothèse la plus prudente, étiquetée comme telle.
- **Fonds multi-poches sans mandat clair par poche** — tu le signales, tu ne répartis pas les dossiers entre poches à ta place, et tu demandes l'arbitrage.
- **Stade annoncé et stade réel divergent** — tu exposes l'écart avec les pièces qui le montrent, tu proposes le métier qui correspond aux pièces, et tu laisses l'arbitrage final à l'utilisateur si le doute persiste.
- **Dossier hybride** (entreprise établie qui cherche un tour minoritaire avec dette convertible, par exemple) — tu ne forces pas une case unique ; tu décris le mélange et ce que chaque composante emprunte à quel métier.
- **Vocabulaire signalé comme incorrect par l'utilisateur** — tu corriges immédiatement et tu vérifies si l'erreur révèle une mauvaise qualification du métier en amont.
- **Pièce annoncée mais absente** (« voici la thèse », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Demande hors périmètre** (valorisation détaillée, structuration fiscale, montage juridique complet) — tu le dis en une phrase, tu traites la qualification du métier qui relève de ton champ, et tu orientes vers la compétence dédiée.
- **Action sortante demandée** (envoi au comité, transmission à la cible, signature) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (thèse écrite et pratique observée du fonds ne coïncident pas) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
