---
id: Y0390
name: tri-des-dossiers-entrants
description: "Filtre le flux entrant avant toute instruction : confronte chaque dossier aux critères éliminatoires du mandat, apprécie l'adéquation à la thèse, sépare ce qui est constatable de ce qui reste à vérifier, puis rend une décision motivée en trois issues — instruire, observer avec déclencheur, écarter avec motif — sans jamais fabriquer un chiffre, un stade ou une conformité que le dossier ne donne pas."
bucket: C
tags: [Investissement, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Tri des dossiers entrants — décider en quinze minutes si un dossier mérite qu'on y passe la semaine

## Ce qu'il faut avoir sous la main
- **Le dossier** tel que reçu : courriel, présentation, formulaire, note de recommandation — ce que tu as, même partiel.
- **L'origine** : candidature directe, mise en relation par qui, deal mandaté — et la date de réception.
- **La thèse d'investissement du fonds** : stade visé, fourchette de ticket, secteurs, géographies, exclusions, type de capital pratiqué (minoritaire de croissance ou majoritaire). Si ce document n'existe pas sous cette forme, dis-le — je le marque comme prérequis manquant plutôt que de deviner un mandat.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Identifier le dossier et son origine

Nom de l'entreprise, stade déclaré, secteur, géographie, forme de la candidature (directe, mise en relation, deal mandaté), qui l'a transmis, date de réception. Note l'origine sans lui donner de poids sur la décision : une mise en relation par un investisseur respecté rend un dossier plus agréable à lire, elle ne le rend pas plus conforme au mandat. C'est le moment de le dire, avant que le biais opère.

### Étape 2 — Passer les critères éliminatoires du mandat, un par un

Reprends la thèse d'investissement fournie et vérifie chaque critère séparément, avec un verdict explicite pour chacun :
- géographie visée,
- stade (amorçage, croissance, autre),
- fourchette de ticket,
- secteur — inclus ou explicitement exclu,
- type de capital recherché par l'entreprise (minoritaire de croissance ou majoritaire) contre celui pratiqué par le fonds,
- éligibilité de structure (forme juridique, résidence, actionnariat) si le mandat en pose.

Un seul critère éliminatoire non satisfait suffit à sortir le dossier du mandat, **quelle que soit la qualité perçue par ailleurs**. Un dossier excellent hors mandat reste hors mandat : le dire tôt, avec le critère précis en cause, est le service qu'on rend au fondateur — pas une politesse, une économie de temps pour tout le monde.

Si la thèse n'a pas été fournie, ne fabrique aucun critère : marque cette étape **provisoire**, liste les critères qu'il faudrait connaître, et dis que le tri définitif attend le document.

### Étape 3 — Apprécier l'adéquation à la thèse, pour ce qui reste

Pour les dossiers qui passent l'étape 2, quelques lignes seulement : le stade réel semble-t-il correspondre à ce que le fonds finance à ce moment de la vie d'une entreprise, le marché décrit paraît-il de l'ordre de grandeur pertinent pour le ticket visé, l'équipe déclarée couvre-t-elle les compétences qu'on attendrait. Ce n'est pas une notation — c'est un filtre de plausibilité, pas une instruction anticipée.

### Étape 4 — Séparer ce qui se constate de ce qui reste à vérifier

Une présentation de levée est un document de vente ; à ce stade, tu ne vérifies rien et donc tu ne conclus rien sur la véracité des chiffres. Distingue ce que tu peux **constater sans travail** — existence légale déclarée, cohérence interne du récit, secteur et stade tels qu'énoncés — de ce qui appartient à l'instruction : exactitude du chiffre d'affaires, qualité réelle de l'équipe, solidité de la traction. Toute donnée absente du dossier (stade exact, chiffre d'affaires, structure juridique) se marque `⟦à renseigner⟧` et devient une **question posée au fondateur**, jamais une hypothèse qui tranche à sa place.

### Étape 5 — Trancher : instruire, observer, ou écarter

Trois issues, une seule retenue :
- **Instruire** — dans le mandat, signaux d'adéquation cohérents, aucun doute disqualifiant à ce stade. Tu donnes les trois questions qui décideront de la suite de l'instruction.
- **Observer** — le problème ou l'entreprise n'est pas mauvais, il est **trop tôt**. Tu nommes le déclencheur précis qui justifierait de rouvrir le dossier (un niveau de revenus `⟦à renseigner⟧`, un tour bouclé, un agrément obtenu, une entrée sur un marché donné) et une date de revue. Sans déclencheur nommé, l'observation n'est pas une décision, c'est un cimetière — tu ne la produis jamais sans ce déclencheur.
- **Écarter** — hors mandat constaté à l'étape 2, ou raison disqualifiante claire. Le motif s'écrit en une phrase, précis, sans adoucissement de convenance. La décision d'écarter **définitivement** reste soumise à l'accord de l'équipe : ce que tu produis ici est une recommandation motivée, pas une clôture.

Aucun écart ne se produit sans motif écrit. Un fonds qui n'archive pas ses refus ne peut ni les justifier à ses souscripteurs, ni détecter qu'il refuse systématiquement un type de dossier qu'il prétend rechercher.

### Étape 6 — La réponse au fondateur et la ligne de pipeline

Rédige un projet de réponse adapté à l'issue : pour l'instruction, les prochaines pièces demandées ; pour l'observation, une formulation respectueuse qui nomme le déclencheur et invite à revenir ; pour l'écart, une phrase claire, un motif réel, sans faux espoir ni promesse vague. Puis la ligne de pipeline : entreprise, date, origine, issue, motif, et date de revue si observation.

## Format de sortie
- **Livrable** : la fiche de tri — identification et origine du dossier avec date ; passage des critères éliminatoires un par un avec verdict ; adéquation à la thèse en quelques lignes ; ce que le dossier ne dit pas et qu'il faudrait savoir ; issue recommandée avec motif en une phrase ; déclencheur et date de revue si observation, ou trois questions clés si instruction ; projet de réponse au fondateur ; ligne de pipeline.
- **Structure** : Markdown, answer-first — l'issue et son motif d'abord, le détail du passage des critères ensuite.
- **Longueur** : une fiche tient sur une page. Le tri n'est pas une instruction ; s'il s'étale, c'est le signe qu'on a débordé du périmètre.
- **Les critères du mandat sont un input**, jamais une production : géographie, ticket, secteurs, exclusions, type de capital viennent de la thèse écrite fournie par le fonds, et restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Toute absence se marque `⟦à renseigner⟧` et devient une question, pas une supposition.

## Règles
1. **Les critères éliminatoires passent avant toute appréciation de qualité.** Un dossier hors mandat n'est pas discuté sur son mérite — il sort au premier critère non satisfait, et c'est signalé sans détour.
2. **Écarté n'est pas écarté définitivement.** La plupart des dossiers ne sont pas mauvais, ils arrivent trop tôt. L'observation a toujours un déclencheur nommé et une date de revue — sans les deux, ce n'est pas une observation valide.
3. **Le tri ne juge pas la véracité des chiffres déclarés.** Il juge l'adéquation au mandat et les signaux constatables sans travail. La vérification des chiffres, de l'équipe et de la traction relève de l'instruction, pas du tri.
4. **Aucun écart sans motif écrit.** La traçabilité des refus est ce qui permet au fonds d'expliquer sa sélectivité et de repérer ses propres angles morts de sourcing.
5. **0 invention.** Stade, chiffre d'affaires, structure juridique, taille de marché : toute donnée manquante est `⟦à renseigner⟧` et devient une question au fondateur, jamais une supposition qui décide.
6. **La thèse du fonds est un input, pas une déduction.** Sans document fourni pour la géographie, le ticket, les secteurs, les exclusions et le type de capital, le passage des critères éliminatoires reste **provisoire** et l'étiquette comme tel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit une fiche de tri et un projet de réponse ; l'envoi de la réponse au fondateur, l'archivage définitif du dossier ou toute communication externe est validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Thèse du fonds non fournie** — tu produis la fiche avec les critères éliminatoires marqués `⟦à renseigner⟧`, tu qualifies le tri de **provisoire**, et tu listes précisément ce qu'il faut recevoir pour le finaliser.
- **Dossier incomplet** (un courriel sans deck, un formulaire à moitié rempli) — tu produis avec ce que tu as, en étiquetant les hypothèses et en marquant les manques `[à confirmer]`.
- **Origine prestigieuse** (recommandation d'un investisseur ou d'un partenaire respecté) — aucune dérogation aux critères éliminatoires ; tu le dis explicitement si la tentation de l'indulgence est visible dans le dossier ou la manière dont il a été transmis.
- **Secteur ou stade « à la mode »** — même traitement que tout autre dossier : le mandat prime sur la tendance, la fiche ne mentionne la tendance qu'en note, jamais comme argument de passage.
- **Dossier déjà vu ou en relance** — tu le signales et tu t'appuies sur l'historique de pipeline si disponible plutôt que de retraiter comme un dossier neuf.
- **Structure juridique atypique ou informelle** — fréquent dans la région ; tu ne l'assimiles pas d'office à une inéligibilité sauf exclusion explicite du mandat, tu marques l'éligibilité comme point à vérifier.
- **Demande d'instruction complète à la place d'un tri** — tu le dis en une phrase, tu produis le tri qui relève de ton périmètre, et tu orientes vers la compétence d'instruction dédiée pour la suite.
- **Décision d'écarter contestée ou sensible** — la recommandation est motivée et documentée, mais la clôture définitive reste soumise à l'accord de l'équipe.
- **Sources contradictoires** (le dossier dit une chose, une information externe en dit une autre) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
