---
id: Y0389
name: referentiel-sources-afrique
description: "Tient le catalogue raisonné des sources utilisables pour chiffrer un marché, un secteur ou un financement en Afrique francophone — ce que chaque source couvre, sa méthode, ses angles morts, et surtout les conclusions qu'elle interdit de tirer. Impose le lien daté à côté de chaque chiffre et désamorce le piège classique de la base au deal : un pourcentage annuel faussé par une seule opération."
bucket: C
tags: [Investissement, Marché, Afrique, Nouveau]
version: 1
maj: 2026-08-10
---

# Référentiel des sources africaines — où chercher, et ce que chacune interdit de conclure

## Ce qu'il faut avoir sous la main
- **Ce qu'il faut chiffrer ou sourcer** — le marché, le secteur, le montant de financement, l'article de droit, la statistique macro.
- **Le périmètre exact** : pays ou zone (UEMOA, tel pays précis, Afrique francophone au sens large), secteur, période.
- **Un livrable brouillon existant**, si tu as déjà des chiffres à faire auditer — colle-les, avec leur source si tu l'as.
- **La destination du document** : interne, comité d'investissement, dossier bailleur — ça change le niveau d'exigence sur les sources.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Fixer le périmètre avant de chercher la source

Avant d'ouvrir un seul rapport, écris précisément ce qui doit être mesuré : quel pays ou quelle zone, quel secteur, quelle période, et surtout quel **type** de donnée — équité seule ou équité et dette confondues, avec ou sans seuil de publication minimum, Afrique du Nord incluse ou exclue. Ce périmètre est ce qui rendra deux chiffres comparables ou pas plus tard. Un périmètre flou («le financement tech en Afrique») produit une recherche qui rapporte des chiffres inconciliables.

### Étape 2 — Choisir la source adaptée, pas la première qui répond

Chaque famille de besoin a ses sources naturelles : financement des startups (Partech, Africa: The Big Deal, Briter Bridges, AVCA, Disrupt Africa, StartupList Africa, Launch Base Africa), cadre macro et régional UEMOA (BCEAO, BRVM, Banque mondiale), droit des affaires (OHADA), financement de développement (IFC, Proparco). Si la demande sort de ce périmètre — un secteur non couvert, un pays hors zone francophone — tu le dis et tu proposes la piste la plus proche plutôt que de forcer une source à répondre à une question qu'elle ne couvre pas.

### Étape 3 — Lire la source à la source, jamais l'agrégateur

Un article de presse qui cite « selon un rapport » n'est pas la source : c'est une reformulation, souvent déjà déformée. Trois articles qui reprennent le même communiqué comptent pour **une seule source**. Tu remontes systématiquement à la publication d'origine — le rapport PDF, la base en ligne, le communiqué officiel — et c'est ce lien-là qui accompagne le chiffre dans le livrable, pas l'article qui en parlait.

### Étape 4 — Vérifier ce que la méthode de collecte permet de voir

Pour chaque source mobilisée, établis : sa méthode (déclarative, base au deal, enquête, données administratives), sa périodicité, et ses angles morts. Une base qui se nourrit d'annonces publiques **surestime ce qui communique et manque ce qui se tait** — opérations discrètes, dette bancaire locale, capital familial, financement informel. Une absence dans la base n'est jamais une absence dans le réel : c'est un angle mort à nommer, pas un zéro à écrire.

Cas concret à garder en tête, parce qu'il illustre exactement le risque : sur une base au deal comme *Africa: The Big Deal*, la part de l'Afrique francophone subsaharienne dans le financement africain grimpe à 9 % en 2025 — presque uniquement portée par une levée unique de 137 millions de dollars au Sénégal. Le chiffre honnête à citer dans un dossier n'est pas ce pic annuel, c'est le cumulé pluriannuel : 5,2 % sur 2019-2025 (Partech Africa Tech Venture Capital Report, https://partechpartners.com/africa-reports/2025-africa-tech-venture-capital-report). Sur une base au deal, **une seule opération peut faire basculer un pourcentage annuel entier**. Règle qui en découle directement : si le cumulé pluriannuel est disponible, c'est lui qui entre dans le livrable ; si seule une année est citée, tu écris explicitement ce qui la porte.

### Étape 5 — Vérifier la comparabilité avant d'additionner ou de comparer

Deux rapports qui donnent des totaux différents pour le même marché ne se contredisent pas forcément — ils mesurent souvent des périmètres différents. Équité seule contre équité plus dette, seuil de publication à cent mille dollars contre absence de seuil, zone géographique élargie ou restreinte : avant de comparer deux chiffres ou de les additionner, tu vérifies que leurs définitions coïncident. Si elles ne coïncident pas, l'écart entre les deux rapports s'explique par le périmètre, pas par la réalité — et tu le dis au lieu de trancher pour l'un ou l'autre.

### Étape 6 — Dater chaque chiffre et vérifier sa fraîcheur

Un marché africain — financement, tech, régulation — bouge vite. Un chiffre publié il y a trois ans, présenté sans date dans un livrable actuel, devient faux même s'il était exact au moment de sa publication. Chaque donnée porte sa date de publication et, si pertinent, la date d'observation qu'elle décrit — les deux peuvent différer.

### Étape 7 — Produire la fiche ou le chiffrage, jamais l'estimation déguisée

Si une donnée n'existe dans aucune source accessible, elle reste `⟦à renseigner⟧` avec la piste concrète pour l'obtenir (quelle base interroger, quel contact, quelle méthode bottom-up alternative). Une estimation plausible non sourcée ne remplace jamais un `⟦à renseigner⟧` — même présentée comme « ordre de grandeur ».

## Format de sortie
- **Livrable A — fiche de source** : nom, lien direct, ce qu'elle couvre réellement (géographie, secteur, type de donnée), méthode de collecte, périodicité, angles morts connus, et la liste explicite de ce qu'elle ne permet **pas** de conclure.
- **Livrable B — chiffrage sourcé** : pour chaque donnée citée — valeur, source nommée, lien, date de publication, et une phrase sur ce que le chiffre ne dit pas (périmètre, effet d'un cas isolé, angle mort de la méthode).
- **Structure** : Markdown, answer-first — le chiffre ou la fiche d'abord, la mise en garde méthodologique juste après, pas en fin de document où elle sera ignorée.
- **Longueur** : proportionnée à la demande — une fiche de source tient sur une demi-page, un chiffrage sur plusieurs pages selon le nombre de données mobilisées.
- **Règle 0 invention** : toute donnée non trouvée reste `⟦à renseigner⟧` avec la piste pour l'obtenir. Jamais une estimation présentée comme un ordre de grandeur.

## Règles
1. **Le lien et la date accompagnent systématiquement le chiffre.** Un chiffre sans les deux n'entre pas dans le livrable — il reste en attente ou en `⟦à renseigner⟧`.
2. **Sur une base au deal, le cumulé pluriannuel prime sur l'année isolée.** Si une seule année est citée malgré tout, la donnée qui la porte est nommée explicitement à côté.
3. **Deux chiffres de périmètres différents ne se comparent ni ne s'additionnent** sans que la différence de périmètre soit d'abord vérifiée et signalée.
4. **On remonte toujours à la publication d'origine**, jamais à l'article qui en parle. Trois reprises du même communiqué comptent pour une source.
5. **L'absence dans une base n'est jamais lue comme une absence dans le réel.** L'angle mort de la méthode (déclaratif, informel, discret) est nommé chaque fois qu'il est pertinent.
6. **Un chiffre daté de plus d'un an s'accompagne d'un avertissement de fraîcheur** dans les secteurs qui bougent vite — financement, régulation, tech.
7. **0 chiffre inventé.** Aucune valeur plausible ne comble une donnée introuvable ; elle reste `⟦à renseigner⟧` avec la piste de recherche.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter des clients potentiels, publier une page de test ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Site institutionnel qui refuse la requête automatique** — ce n'est pas une indisponibilité de la source : tu le signales comme un accès à consulter manuellement, tu ne conclus jamais qu'une source est hors service sur la seule foi d'un refus technique.
- **Périmètres incomparables entre deux rapports** — tu exposes les deux définitions côte à côte plutôt que de choisir un total « officiel » à la place de l'utilisateur.
- **Chiffre introuvable dans toutes les sources listées** — tu le marques `⟦à renseigner⟧` avec la piste concrète (base à interroger, contact, méthode bottom-up alternative), tu ne le remplaces jamais par un ordre de grandeur plausible.
- **Une seule opération porte tout un ratio annuel** — tu le signales explicitement et tu proposes le cumulé pluriannuel comme chiffre par défaut du livrable.
- **Sources contradictoires sur la même donnée** — tu exposes les deux versions avec leurs méthodes respectives et tu demandes l'arbitrage plutôt que de trancher seul.
- **Rapport annoncé mais non fourni** (« le rapport Partech dit que… », rien n'est joint ni consulté) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lu.
- **Demande hors périmètre des sources listées** (secteur non couvert, pays hors zone francophone) — tu le dis en une phrase et tu orientes vers la piste la plus proche disponible.
- **Action sortante demandée** (envoi du dossier, publication, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
