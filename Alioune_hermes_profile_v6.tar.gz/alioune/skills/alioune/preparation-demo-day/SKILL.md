---
id: Y0301
name: preparation-demo-day
description: "Prépare un Demo Day ou un roadshow investisseurs : sélection et ordre de passage des startups, coaching des pitchs, liste d'investisseurs à inviter et argumentaire d'invitation, déroulé de l'événement, kit participants et suivi des contacts après l'événement."
bucket: B
tags: [Programme, Investisseurs, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Demo Day — préparation et suivi

## Ce qu'il faut avoir sous la main
🔒 **Je n'invite personne et je ne publie rien.** Je livre les listes et les messages ; l'envoi est ta décision.

- **Le format** : date, durée, présentiel ou hybride, capacité, budget.
- **Les startups** candidates au passage et leur état de préparation.
- **L'audience visée** : investisseurs, corporates, institutionnels, presse — et ce qu'on attend de chacun.
- **Le résultat attendu** : rendez-vous, engagements, visibilité, couverture presse.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Sélectionner et ordonner

Toutes les startups d'une cohorte ne passent pas : une startup non prête abîme l'événement et la startup elle-même. Propose la sélection sur critères, puis l'**ordre de passage** — on ouvre fort, on ferme fort, et on ne met jamais deux startups du même secteur à la suite.

### Étape 2 — Coacher les pitchs

Par startup : le format imposé (durée, slides, message unique), les deux faiblesses de son pitch actuel, et les trois questions difficiles qu'elle prendra. Prévois deux répétitions dont une avec chronomètre.

### Étape 3 — Construire la liste d'invités

Par cible : qui, pourquoi lui, quelle startup pourrait l'intéresser, quel est le chemin d'invitation. Un investisseur invité sans qu'aucune startup n'entre dans sa thèse ne reviendra pas l'année suivante.

### Étape 4 — Déroulé

Minuté, avec le temps de réseautage traité comme une séquence à part entière — c'est là que se prennent les rendez-vous, pas pendant les pitchs. Prévois le retard, la panne technique et le no-show d'un intervenant.

### Étape 5 — Kit et suivi

Kit participant : one-pager par startup, contacts, comment prendre rendez-vous. Puis le plan de suivi à J+2 : qui relance qui, avec quel message, et le tableau de suivi des contacts et rendez-vous obtenus.

## Format de sortie
- **Livrable** : la sélection et l'ordre de passage, les fiches de coaching par startup, la liste d'invités argumentée, le déroulé minuté, le kit participant et le plan de suivi post-événement.
- **Structure** : Markdown clair — answer-first, puis le détail ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Sélection assumée.** Une startup non prête ne passe pas ; dis-le avec le motif plutôt que de laisser passer.
2. **Chaque invité a une raison d'être là**, rattachée à au moins une startup qui passe.
3. **Le réseautage est une séquence du déroulé**, avec sa durée et son animation.
4. **Aucun chiffre de startup dans le kit sans validation de la startup concernée.**
5. **Le suivi est prévu avant l'événement**, pas improvisé après.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante en autonomie.** Cette skill prépare et propose ; tout envoi (candidat notifié, mentor sollicité, investisseur contacté), toute publication et toute écriture dans un système tiers est validée par l'utilisateur avant exécution.
- **Cloisonnement.** Ce que tu apprends d'une startup, d'un candidat ou d'un hub ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
