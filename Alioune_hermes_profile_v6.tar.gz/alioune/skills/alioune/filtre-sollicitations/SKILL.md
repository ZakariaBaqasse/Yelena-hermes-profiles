---
name: filtre-sollicitations
description: >
  Protège le temps et l'attention du dirigeant. Pour toute sollicitation qui remonte (demande
  de rendez-vous, invitation, dossier à signer, note, appel), détermine : est-ce de son niveau ?
  qui peut le traiter à sa place ? que faut-il pour qu'il puisse trancher en deux minutes ?
  Produit une position argumentée — traiter / déléguer / décliner / différer — jamais un
  simple avis. Utiliser quand il dit « est-ce que je dois y aller », « qu'est-ce que je fais
  de ça », « trie », « est-ce que c'est pour moi », ou quand une demande de rendez-vous arrive.
version: 1
maj: 2026-08-10
---

# Filtre des sollicitations

La ressource la plus rare de la direction générale, c'est le temps du dirigeant. Ce skill existe
pour le défendre. Chaque sollicitation acceptée sans examen est une sollicitation refusée
ailleurs — et ce qu'on refuse ainsi, sans le savoir, est souvent ce qui comptait.

## Les quatre issues

Toute demande sort avec **une** de ces quatre positions, jamais « à voir » :

| Position | Quand |
|---|---|
| **Traiter** | Enjeu stratégique pour l'entreprise, arbitrage entre directions, interlocuteur de rang équivalent (actionnaire, banquier, dirigeant d'un partenaire), ou signature engageant la direction générale |
| **Déléguer** | Un directeur, un responsable ou un service est compétent et légitime — **nommer la personne**, jamais « les équipes » |
| **Décliner** | Hors périmètre, sans enjeu, ou déjà traité ailleurs — proposer la formule de réponse |
| **Différer** | Enjeu réel, mais l'information manque ou le moment est mauvais — dire **jusqu'à quand** et **ce qu'on attend** |

« Différer » n'est pas une échappatoire : un différé sans date et sans condition de reprise
est un refus déguisé, et il coûte plus cher qu'un refus assumé.

## Grille d'examen

Pour chaque sollicitation, répondre dans cet ordre :

1. **Qui demande ?** Rang, société, statut **vérifié à date**. Un correspondant dont la
   fonction a changé change toute l'analyse — vérifier via `cartographie-acteurs`.
2. **Que demande-t-il exactement ?** Reformuler en une phrase. Une demande floue se clarifie
   avant de remonter : un rendez-vous « pour échanger » n'est pas une demande, c'est une porte.
3. **Y a-t-il un antécédent ?** Le sujet est-il déjà passé, déjà tranché, déjà refusé ? Un
   refus antérieur qu'on ignore fabrique une incohérence coûteuse en crédibilité.
4. **Quel est le coût de dire oui ?** En temps, mais surtout **en précédent créé** : ce qui
   est accordé une fois devient une norme opposable par le suivant.
5. **Quel est le coût de dire non ?** Commercial, relationnel, financier. Certains « non »
   se paient six mois plus tard.
6. **Qui d'autre est déjà saisi ?** Une même demande adressée en parallèle à trois
   interlocuteurs de la direction générale est une information en soi.

## Le test du niveau

Avant de proposer « traiter », vérifier qu'aucune de ces trois réponses n'est « oui » :

- un directeur de département peut-il répondre **avec la même autorité** ?
- la réponse attendue est-elle purement technique ou procédurale ?
- la demande porte-t-elle sur un dossier dont un responsable a la charge nominative ?

Si oui à l'une d'elles : c'est « déléguer », et le nom de la personne compétente fait partie
de la réponse. Une délégation sans nom retombe toujours sur le bureau du dirigeant.

## Sortie

```
SOLLICITATION : <une phrase>
DEMANDEUR : <nom, fonction vérifiée à date> — <lien vers la source de vérification>
ANTÉCÉDENT : <oui / non — lequel, avec lien>

POSITION : Traiter | Déléguer à <nom, fonction> | Décliner | Différer jusqu'au <date>
POURQUOI : <deux lignes>
SI VOUS DITES OUI : <ce que ça coûte, ce que ça engage, quel précédent ça crée>
SI VOUS DITES NON : <ce que ça coûte>
PROJET DE RÉPONSE : <trois à cinq lignes, prêtes à partir>
```

Quand plusieurs suites sont défendables, les présenter en **options lettrées**, pour qu'il
réponde d'un caractère :

```
A. Recevoir en rendez-vous de 20 minutes la semaine du 12
B. Déléguer au directeur général adjoint, avec compte rendu
C. Répondre par écrit sans rendez-vous
```

## Exemple travaillé

> La CGECI (Confédération Générale des Entreprises de Côte d'Ivoire) demande un rendez-vous
> « pour présenter ses propositions sur la fiscalité du secteur », en rappelant avoir écrit
> deux fois sans réponse.

```
SOLLICITATION : Rendez-vous pour porter des propositions fiscales sectorielles.
DEMANDEUR : Président de la CGECI — fonction vérifiée, mandat en cours.
ANTÉCÉDENT : Deux courriers restés sans réponse. Sujet relevant de la direction financière
et fiscale du groupe.

POSITION : Déléguer au directeur financier, avec réponse écrite de la direction générale.
POURQUOI : La demande est sectorielle et instruite ailleurs ; recevoir au niveau du dirigeant
créerait un précédent que d'autres organisations patronales invoqueraient. Mais deux courriers
sans réponse constituent un risque relationnel réel.
SI VOUS DITES OUI : 20 minutes, et une file d'attente d'organisations équivalentes.
SI VOUS DITES NON sans réponse écrite : un grief facile à documenter, y compris auprès
du conseil d'administration.
PROJET DE RÉPONSE : accusé de réception, orientation nominative vers le directeur financier,
engagement d'un retour sous quinzaine.
```

## Quand le livrable n'est pas bon

- La position est « à voir », « selon », ou deux positions à la fois.
- La délégation ne nomme personne.
- Le différé n'a ni date ni condition de reprise.
- Le coût du « non » n'est pas évalué — c'est le côté qu'on oublie, et c'est celui qui se paie.
- La fonction du demandeur n'a pas été revérifiée.

## Garde-fous

- **Ne jamais décliner seul.** Ce skill propose ; le dirigeant décide. Aucune réponse ne part
  sans son accord explicite.
- Une demande émanant du président du conseil d'administration, d'un actionnaire majoritaire
  ou d'un investisseur stratégique **ne se filtre pas** : elle remonte telle quelle, avec le
  contexte utile et rien de plus.
- Signaler quand une même personne sollicite de façon répétée, ou quand plusieurs
  organisations d'un même secteur sollicitent en même temps : c'est un signal, pas du bruit.
- Ne jamais qualifier un demandeur (« insistant », « peu pertinent »). Décrire les faits,
  laisser le jugement au dirigeant.

## Chaînage

- **Alimente** `suivi-engagements` dès qu'une réponse promet quelque chose.
- **Croise** `cartographie-acteurs` pour la fonction du demandeur, et `veille-ci` pour savoir
  si le sujet est en train de devenir public.
- **Débouche sur** `note-decision` quand la sollicitation cache un vrai arbitrage.
