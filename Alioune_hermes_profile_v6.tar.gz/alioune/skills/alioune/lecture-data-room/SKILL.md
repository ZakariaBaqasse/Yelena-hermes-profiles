---
id: Y0652
name: lecture-data-room
description: "Transforme une salle de données d'entreprise en base de travail exploitable : inventaire pièce par pièce, hiérarchie des sources, détection de ce qui manque et des versions concurrentes, carte des faits reliée à chaque pièce et à sa page — puis répond à toute question posée sur le dossier en citant sa source, ou en disant qu'elle n'existe dans aucune pièce."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Lecture de salle de données — inventorier avant d'analyser

## Ce qu'il faut avoir sous la main
- **Le dossier** : accès à la salle de données, ou pièces envoyées au fil de l'eau — précise si l'envoi est complet ou partiel.
- **Le stade de l'opération** (due diligence préliminaire, avant closing, revue post-signature…) et le **secteur** de l'entreprise — pour bâtir la liste de ce qu'on doit y trouver.
- **Le pays / cadre juridique** de l'entreprise (zone OHADA en général) — pour savoir ce qui compte comme pièce signée ou déposée au greffe chez toi.
- **Les questions précises** déjà posées sur ce dossier, si tu en as — sinon je pars de l'inventaire seul.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Inventorier avant de lire

Avant toute analyse de fond, construis le tableau des pièces : nom du document, **rubrique** (juridique, financier, commercial, RH, technique, fiscal…), **date du document lui-même** — pas la date de réception ou de dépôt dans la salle —, **émetteur**, et **nature** (signée / déposée au greffe, export d'un système, tableur produit en interne, présentation commerciale).

Le piège classique ici : confondre la date à laquelle le fichier arrive avec la date du fait qu'il décrit. Un bilan daté de mars mais reçu en septembre reste un bilan de mars — c'est cette date qui compte pour tout ce qui suit.

### Étape 2 — Dresser la liste de ce qui devrait être là, et pointer l'absence

Sans référentiel de ce qu'on attend à ce stade et dans ce secteur, on lit très bien les pièces fournies sans jamais remarquer celles qui manquent. Construis cette liste de référence à partir du stade de l'opération et du secteur communiqués — avec l'équipe si le référentiel sectoriel n'est pas déjà connu — puis confronte-la à l'inventaire de l'étape 1.

Chaque pièce attendue et absente est **nommée explicitement** dans le livrable — jamais noyée dans une phrase générale du type « le dossier semble incomplet ». En zone OHADA, vérifie particulièrement les pièces qui existent normalement sous forme d'acte : statuts à jour, PV d'assemblées, extrait RCCM, attestations fiscales et sociales — leur absence est un signal fort, pas un détail administratif.

### Étape 3 — Hiérarchiser les sources, neutraliser la présentation commerciale

Établis une hiérarchie explicite, du plus fiable au moins fiable :
1. **Pièce signée ou déposée au greffe / authentique** — statuts, PV d'AG, actes notariés, extrait RCCM, jugement.
2. **Export d'un système** — comptabilité, paie, CRM, ERP — daté et non retraité à la main.
3. **Tableur produit par l'entreprise** — retraité, construit pour l'occasion, non audité.
4. **Présentation commerciale** — pitch deck, mémorandum d'information, note de synthèse rédigée pour convaincre.

Une affirmation ne monte **jamais** au-dessus de la meilleure pièce qui la porte. Si seule la présentation affirme un chiffre ou un fait, ce n'est pas un fait établi — c'est ce que dit la direction, et tu l'écris ainsi dans la carte des faits, pas comme une donnée vérifiée.

### Étape 4 — Résoudre les versions concurrentes

Repère les documents multiples portant le même nom ou le même objet — trois tableurs de trésorerie, deux versions de business plan. Date chacun précisément à partir de son contenu ou de ses métadonnées, pas de l'ordre d'arrivée dans la salle.

Retiens la version la **plus récente**, sauf raison documentée de faire autrement — et jamais la version la plus flatteuse pour le narratif présenté. Liste les versions concurrentes trouvées dans un tableau dédié, avec la date de chacune et laquelle a été retenue pour la suite, et pourquoi.

### Étape 5 — Construire la carte des faits, transversalement

C'est le cœur du travail, et c'est là qu'un résumé document par document échoue. Une affirmation importante — le chiffre d'affaires réel, la détention du capital, l'absence de litige, l'existence d'une garantie — s'établit en **croisant** ce que disent plusieurs pièces entre elles, pas en rapportant ce que dit une seule.

Pour chaque fait retenu dans la carte : l'affirmation, la ou les pièces d'appui, la page ou la ligne précise, et le niveau de preuve issu de la hiérarchie de l'étape 3. Si deux pièces se contredisent, tu le signales explicitement dans la carte — tu ne choisis jamais silencieusement laquelle croire.

### Étape 6 — Répondre aux questions posées, pièce et page à l'appui

Pour chaque question sur le dossier — venant de l'intake ou posée plus tard dans l'échange — tu réponds en citant la pièce et, si possible, la page, le tableau ou la ligne exacte. Si la réponse n'est dans aucune pièce fournie, tu le dis explicitement : « cette information n'apparaît dans aucune pièce de la salle » n'est jamais remplacé par une déduction non sourcée présentée comme un fait.

## Format de sortie
- **Livrable** : l'inventaire de la salle de données — tableau des pièces (nom, rubrique, date, émetteur, nature), liste nommée de ce qui est attendu et absent, carte des faits établis avec pièce d'appui et page, tableau des versions concurrentes datées, et une note de méthode listant ce qui n'a pas pu être établi et pourquoi.
- **Structure** : Markdown, tableaux pour l'inventaire, les absences et les versions ; la carte des faits peut être en liste structurée si elle est plus lisible ainsi.
- **Longueur** : proportionnée à la taille du dossier — un inventaire de dix pièces ne produit pas dix pages.
- **Toute réponse ultérieure sur le dossier cite sa pièce.** Une réponse sans référence de pièce n'est pas un livrable recevable de cette skill.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque ou n'est dans aucune pièce, elle est marquée « absente / à confirmer » — jamais remplacée par une valeur plausible.

## Règles
1. **Jamais de résumé document par document.** Le livrable est une carte des faits transversale, pas une suite de fiches par fichier. Si tu te surprends à écrire « le document X dit… » vingt fois de suite sans jamais croiser, tu recommences.
2. **La présentation commerciale n'établit jamais un fait.** Elle dit ce que la direction affirme. Toute affirmation dont la seule source est une présentation, un pitch ou un mémorandum est marquée comme telle dans la carte des faits — pas comme donnée vérifiée.
3. **La hiérarchie des sources est stricte.** Une affirmation ne dépasse jamais le niveau de preuve de la meilleure pièce qui la porte, même si une pièce de rang inférieur la répète plus clairement.
4. **L'absence se nomme, elle ne se devine pas.** Chaque pièce attendue et manquante figure explicitement dans une liste — une phrase vague sur le caractère incomplet du dossier n'est pas une lecture de salle de données.
5. **Les versions se datent, elles ne se choisissent pas au flair.** Entre plusieurs documents concurrents, la version retenue est la plus récente sauf raison documentée — jamais la plus favorable au narratif de la direction.
6. **Le contexte OHADA structure la hiérarchie des sources.** Statuts, PV d'AG, extrait RCCM, actes notariés sont au sommet parce qu'ils sont opposables ; les accords non écrits ou les pratiques informelles fréquentes dans la région ne montent jamais au rang de pièce signée — ils sont signalés comme un trou de preuve, pas comblés par une déduction.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter l'entreprise, partager le dossier à un tiers ou engager une décision d'investissement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une salle de données ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Dossier partiel dès le départ** — tu inventories ce qui est là, tu marques la liste des attendus non fournis, et tu produis le livrable en l'état plutôt que d'attendre le complément.
- **Pièce annoncée mais absente** (« voici les statuts », rien n'est joint) — tu le signales avant de continuer et tu ne fais jamais comme si tu l'avais lue.
- **Document illisible ou corrompu** — tu le listes dans l'inventaire avec son statut « illisible », tu ne devines pas son contenu à partir du nom du fichier.
- **Pièces contradictoires entre elles** — tu exposes les deux versions dans la carte des faits et tu demandes l'arbitrage plutôt que de trancher seul lequel croire.
- **Aucune pièce de rang supérieur pour un fait important** — tu le dis explicitement : ce fait n'est appuyé que par une présentation ou un tableur interne, donc non établi au sens de la hiérarchie.
- **Demande d'avis juridique ou de valorisation** — tu le dis en une phrase, tu restes sur l'inventaire et la carte des faits, et tu orientes vers la compétence dédiée (analyse juridique, valorisation).
- **Question posée sur un fait absent de toute pièce** — tu réponds que l'information n'est dans aucune pièce fournie, sans la déduire ni l'estimer.
- **Action sortante demandée** (partage du dossier, envoi à un tiers, décision d'engagement) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Plusieurs dossiers traités dans la même conversation** — tu maintiens la carte des faits de chaque dossier strictement séparée, sans réutiliser une pièce ou un fait de l'un pour combler un trou de l'autre.
