# Couche locale : Alioune · Investissement et analyse de dossiers

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-ALIOUNE-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Source identifiée, note encore à fabriquer. Le relevé du gouvernement de 2026 existe sur la machine (memory/reference/gouvernement-2026.md chez LOKOLI) et sert de base. Pour un poste juridique, la note utile n'est pas la liste des ministres mais la chaîne qui décide d'un texte : Assemblée nationale et Sénat pour la loi, Président pour l'ordonnance, Secrétariat général du Gouvernement pour la publication au Journal officiel, juridictions pour l'application. POINT DUR À PORTER : le Journal officiel n'est PAS en accès libre en ligne ; le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66). Toute date de publication citée sans avoir ouvert le JO est une date de seconde main, et doit être annoncée comme telle. Écart tranché le 18/09 : décret n°2026-05/2 du 07/01/2026, publié au Journal officiel n°5 (Spécial) du 17/02/2026, il ne reste que DEUX districts autonomes, Abidjan et Yamoussoukro.

### CL-ALIOUNE-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-ALIOUNE-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-ALIOUNE-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-ALIOUNE-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-ALIOUNE-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Les dix actes uniformes sont sur la machine depuis le 18/09, dans ~/.claude/outils-communs/ohada/. POUR UN MÉTIER D'INVESTISSEMENT, cinq comptent. AUSCGIE (30/01/2014, 920 articles) : formes sociales, capital, gouvernance, cessions, valeurs mobilières, c'est le texte du montage. AUS (sûretés, 15/12/2010, 228 articles) : ce qui garantit une créance ou un financement, cautionnement, gage, nantissement, hypothèque, réserve de propriété. AUDCIF (26/01/2017, 113 articles) : les comptes sur lesquels on valorise, et les dates d'entrée en vigueur, 01/01/2018 pour les comptes personnels et 01/01/2019 pour les comptes consolidés et les états en normes IFRS. AUPCAP (10/09/2015, 258 articles) : ce qui se passe quand la participation va mal, du règlement préventif à la liquidation, c'est le scénario bas d'un dossier. AUA (arbitrage, 23/11/2017, 36 articles) : la clause de règlement des litiges d'un pacte. ⚠ PIÈGE DE RECHERCHE : AUSCGIE-2014.txt est une reconnaissance SANS ACCENTS, chercher societe et non société.

## Langue

### CL-ALIOUNE-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || CORRIGÉ LE 18/09 : le socle affirmait que la compétence parler-ivoirien était déjà liée à ce poste. C'ÉTAIT FAUX — elle l'était chez KOUASSI, d'où le socle a été repris, et elle manquait sur SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis le 18/09, version du catalogue vérifiée neutre. ⚠ LA LEÇON : un socle transverse porte la réponse du poste SOURCE, pas celle du poste cible. Une affirmation du type « déjà chez lui » doit se vérifier poste par poste avant d'être propagée. Ce que sert ce corpus : la règle de registre (le premier contact reste formel ici, on vouvoie, l'urgence fabriquée est mal vue) autant que le lexique.

## Canaux

### CL-ALIOUNE-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : e-commerce à 9,8 % des internautes seulement, contre 75,1 % de ménages connectés. Tout plan d'affaires qui confond connecté et acheteur est à corriger.

## Financement

### CL-ALIOUNE-11 · Les financeurs présents en Côte d'Ivoire et dans la zone
- **Pourquoi** : Orienter un dossier vers un fonds qui n'investit pas ici
- **Où chercher** : Annuaires de fonds, presse économique régionale
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://projectsportal.afdb.org/
- **Pièce, ici** : references/pieces/1a8HaiTV9yYmMiM5MkurVKyLBitqJ7bvr2SR8Ad1da0g.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/12/2026
- **Commentaire** : INTÉGRÉ LE 22/09. Base neuve bases-locales/financement-ci/, qui rassemble ce qui vivait dans quatre postes sans être posé nulle part. ⛔ SA RÈGLE DE LECTURE VAUT PLUS QUE TOUTES LES LISTES : un même montant traverse QUATRE ÉTATS, intention annoncée, approbation par le conseil du bailleur, signature ou ratification, décaissement. Un chiffre sans son état ne veut rien dire, et c'est l'erreur la plus fréquente dans la reprise de presse. Toujours nommer l'état, et le dater. POUR CETTE LIGNE : la note porte les bailleurs publics (quatorze sources suivies avec leurs pièges d'accès, dont tresor.gouv.ci que le préfixe www casse et le FMI qui rend 403 aux robots), les neuf financements documentés du PND avec leur état et leur date, et les investisseurs privés. ⚠ LA LISTE DES FONDS N'EST PAS EXHAUSTIVE ET NE PEUT PAS L'ÊTRE : capital-risque et capital investissement ne figurent dans aucun registre public, ils ne sont pas des intermédiaires de marché donc pas agréés par l'AMF-UMOA. Implantés à Abidjan : COMOÉ CAPITAL (ticket 0 à 500 000 €, 4,4 Md FCFA levés), ADIWALE PARTNERS (capital de croissance 3 à 8 M€, fonds I clôturé à 60 M€), CDC-CI CAPITAL (720 M FCFA dans 8 start-up en mai 2026). Régionaux ayant signé ici : Janngo, E3 Capital, KawiSafi, Cur8, Saviu. ⛔ QUATRE DE CES CINQ LIGNES VIENNENT D'UNE SEULE OPÉRATION, le tour GoCab : c'est le piège de la base construite au deal, ces noms valent un appel, pas une présentation comme acteurs installés. ⛔ ET LES NEUF FINANCEMENTS NE SONT PAS LE PORTEFEUILLE : le PND annoncé pèse 114 838,5 Md FCFA et n'est traçable qu'à 10 à 15 % sur sources publiques. RESTE À FAIRE, écrit dans la note : qualifier les quatre fonds GoCab, AJOUTER LES BANQUES COMMERCIALES ET LEURS LIGNES PME qui sont absentes de l'inventaire et sont probablement le canal le plus utilisé, et vérifier le fonds national de 100 Md FCFA relevé dans la presse et non confirmé, donc hors liste.

### CL-ALIOUNE-12 · Les guichets publics et bailleurs actifs dans la région
- **Pourquoi** : Rater une ligne de financement ouverte
- **Où chercher** : BOAD, BAD, programmes nationaux
- **Trouvé** : Non
- **Intégré** : Non
- **Pièce, ici** : references/pieces/1AZwgqyp0VWh4BFnM6CqWFnBogEPcLImBCL_of5h9POY.md
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON TROUVÉ, mais la carte d'accès est faite le 18/09 et elle évite de perdre du temps. RÉPONDENT : la BOAD, banque de développement de l'UEMOA (boad.org) ; la BCEAO (bceao.int) ; la BRVM (brvm.org) ; l'AMF-UMOA (amf-umoa.org). NE RÉPONDENT PAS : la Banque africaine de développement (afdb.org, 403) ; ⛔ LE CEPICI, guichet unique ivoirien de l'investissement, INATTEIGNABLE depuis cette machine, cepici.gouv.ci renvoie sur cepici.ci qui redirige à son tour, en boucle, essayé sur trois adresses. C'est le point d'entrée de tout investisseur étranger en Côte d'Ivoire et c'est le seul qui ne s'ouvre pas. ⚙ l'équipe A INDIQUÉ LE 18/09 QU'IL A ACCÈS AU CEPICI : le contenu viendra par lui. CE QUE DEMANDE VRAIMENT LA LIGNE, ce ne sont pas les adresses mais LES LIGNES DE FINANCEMENT OUVERTES À UN INSTANT DONNÉ, avec leurs critères d'éligibilité et leurs dates de clôture. Cela se périme vite : c'est une veille, pas une fiche. ⚙ AJOUT DU 18/09 : le livrable 260918_Financeurs-Cote-dIvoire (voir CL-ALIOUNE-11) porte désormais les GUICHETS PUBLICS IVOIRIENS et les BAILLEURS. GUICHETS : le GUDE-PME, guichet unique de développement des PME, holding dont l'État est l'actionnaire unique, créé en janvier 2022, chapeaute CI-PME (accompagnement) et la SGPME (garantie, 1 080 PME et plus de 35 Md FCFA depuis mai 2023) ; le FGPME, fonds de garantie des crédits aux PME, loi 68-346 du 29/07/1968 et décret 2020-18 du 08/01/2020, garantit les crédits bancaires des PME ivoiriennes et fournit les cautions exigées dans les marchés publics ; le programme PACA-CI, prolongé jusqu'en 2026, a octroyé plus d'un milliard FCFA à la SGPME. BAILLEURS, qui financent rarement une PME en direct et passent par une banque ou un fonds : la BAD (12,5 M€ dans Adiwale Fund I, 6,5 M€ dans Saviu II) ; la BIDC (prêt de 10 Md FCFA à Afriland First Bank Côte d'Ivoire le 20/05/2026) ; PROPARCO et l'AFD (premier financement Choose Africa 2 en Côte d'Ivoire, accès au crédit de plusieurs milliers de TPME, axe entrepreneuriat féminin) ; la SFI (entrée au capital de CDCI avec Valoris Group) ; Banque mondiale, Bpifrance, JICA, PNUD et Digital Africa cités comme partenaires de la feuille de route innovation et IA 2026-2028. ⛔ RESTE MANQUANT, ET C'EST POURQUOI LA LIGNE RESTE À NON : les paramètres du FGPME (quotité de garantie, plafonds, durée, coût) ne sont ni sur pme.gouv.ci ni sur le site dédié dont l'adresse relevée ne résout plus ; à demander à CI-PME ou à lire dans le décret 2020-18, qui n'est pas sur disque. Et les lignes de financement OUVERTES à un instant donné restent une veille, pas une fiche.

## Marché

### CL-ALIOUNE-13 · Les tickets et valorisations observés dans la région
- **Pourquoi** : Une valorisation calquée sur un marché américain
- **Où chercher** : Communiqués d'opérations, presse spécialisée
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON TROUVÉ. Aucune base de transactions n'est sur la machine, et il n'en existe pas de gratuite qui couvre proprement l'Afrique francophone. ⚠ LE RISQUE CENTRAL DE CETTE LIGNE est déjà traité par la compétence referentiel-sources-afrique et sa mise en garde vaut d'être reprise telle quelle : SUR UNE BASE AU DEAL, UNE SEULE OPÉRATION SUFFIT À FAIRE BOUGER UN POURCENTAGE ANNUEL. Un multiple de valorisation tiré d'un échantillon de quelques transactions n'est pas un repère de marché, et le servir comme tel est la faute que cette ligne existe pour empêcher. CE QUI EST FAISABLE SANS BASE PAYANTE : constituer un relevé maison à partir des communiqués d'opérations, daté, avec le périmètre de chaque chiffre ; même méthode que les 132 publications de marques ivoiriennes relevées le 06/09. ℹ UN COMPARABLE GRATUIT EXISTE POURTANT, et il est régional : le ratio cours sur bénéfice moyen de la BRVM, 17,90 au 17/09/2026 (voir ligne 14).

### CL-ALIOUNE-14 · La BRVM : ce qui y est coté et comment
- **Pourquoi** : Parler de sortie en bourse sans connaître le marché régional
- **Où chercher** : BRVM
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://bfin.brvm.org/boc/BOC_JOUR/
- **Pièce, ici** : references/pieces/1Cbt59fAweiRWa1ec44XiJuz2BItsVODMpK-o4rCpWjc.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/12/2026
- **Commentaire** : INTÉGRÉ LE 22/09, et à la source du jour. Note neuve bases-locales/financement-ci/BRVM.md, avec deux bulletins officiels gardés comme exemples de lecture. LA SOURCE EST PARFAITE ET GRATUITE : le bulletin officiel de la cote est quotidien, public, à adresse prévisible https://bfin.brvm.org/boc/BOC_JOUR/BOC_AAAAMMJJ.pdf. ⚠ JOURS OUVRÉS SEULEMENT ET AVEC DU RETARD, vérifié le 22/09 à 19 h : le bulletin du jour même rendait 404, celui du samedi aussi, ceux du vendredi 18 et du lundi 21 répondaient. Un script qui veut le dernier bulletin doit REMONTER LES JOURS. ÉTAT AU LUNDI 21/09/2026 : 47 sociétés cotées, 206 lignes obligataires, capitalisation actions 21 003 Md FCFA, BRVM Composite 544,68 soit +57,54 % sur un an, BRVM 30 à 263,82, PER MOYEN DU MARCHÉ 17,28, rendement moyen 6,01 %. Deux compartiments, Prestige 12 sociétés (PER 14,69) et Principal 35 (PER 21,90). ⚠ Le PER moyen est calculé SANS UNILEVER CI, le bulletin le précise, reprendre la note avec le chiffre. SEPT SECTEURS avec des PER très dispersés : consommation de base 10,15, télécoms 14,48, services financiers 17,02, CONSOMMATION DISCRÉTIONNAIRE 40,17. On compare secteur par secteur, jamais au PER global. ⛔ LA VRAIE CONTRAINTE EST LA LIQUIDITÉ : au 18/09, 44 titres échangés dans la séance sur 47 sociétés cotées, pour 4,6 Md FCFA. Une sortie en bourse s'y construit, elle ne s'y improvise pas, et la question n'est pas de savoir si l'on peut coter mais qui achètera le jour où l'on vend. ⚠ Les variations annuelles sont spectaculaires : un comparable pris en haut de cycle n'en est pas un, citer la variation annuelle à côté du niveau. ℹ Compartiment de croissance PME mentionné par des sources secondaires, AUCUNE COTATION n'y apparaît dans le bulletin, donc non affirmé.

## Juridique

### CL-ALIOUNE-15 · Formes de société et pactes d'associés en OHADA
- **Pourquoi** : Proposer un montage inapplicable
- **Où chercher** : OHADA, cabinets de la place
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base OHADA complète sur disque : les DIX actes uniformes en PDF et en .txt cherchable (AUDCG-2010 307 art., AUSCGIE-2014 920, AUSCOOP-2010 397, AUS-2010 228, AUPSRVE-2023 338, AUPCAP-2015 258, AUDCIF-2017 113, AUA-2017 36, AUM-2017 17, AUCTMR-2003 31), plus l'AUDCIF tel que publié au Journal officiel. Ces actes sont DIRECTEMENT applicables en Côte d'Ivoire et priment sur le droit interne contraire. ⛔ Citer par l'article, jamais de mémoire. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches. Pour les formes de société et les pactes d'associés, l'acte à ouvrir est l'AUSCGIE-2014, 920 articles. || FAIT LE 18/09, vérifié sur le texte et non de mémoire. L'acte qui porte cette ligne est l'AUSCGIE, adopté le 30/01/2014 à Ouagadougou, 920 articles, dans ~/.claude/outils-communs/ohada/. TROIS POINTS. (1) LA SOCIÉTÉ PAR ACTIONS SIMPLIFIÉE EXISTE dans l'acte uniforme : la forme qui donne la liberté statutaire qu'attend un investisseur n'a pas besoin d'être importée. (2) LES PACTES D'ASSOCIÉS SONT EXPRESSÉMENT ADMIS, le texte dit que les associés peuvent conclure des CONVENTIONS EXTRASTATUTAIRES en vue notamment d'organiser leurs relations, dans le respect des dispositions impératives de l'acte et des clauses statutaires ; un pacte n'est donc pas un montage toléré, c'est une faculté prévue. (3) ⚠ LE CAPITAL SOCIAL MINIMUM DE LA SARL EST D'UN MILLION DE FRANCS CFA (article 311), MAIS L'ARTICLE AJOUTE « SAUF DISPOSITIONS NATIONALES CONTRAIRES » : plusieurs États ont utilisé cette réserve pour abaisser le seuil, donc VÉRIFIER LE DROIT IVOIRIEN AVANT DE CITER UN MONTANT À UN CLIENT. L'acte uniforme ne tranche pas seul. ⚠ PIÈGE : AUSCGIE-2014.txt est sans accents, chercher societe et non société.

## Analyse

### CL-ALIOUNE-16 · Les secteurs porteurs ici, et sur quelles données le dire
- **Pourquoi** : Affirmer un secteur porteur sans source
- **Où chercher** : INS, études sectorielles publiées
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1db-gNTnugAdHgEcW3QMQwLMvQys3YBvaKvfL9CRgf2Y.md
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/03/2027
- **Commentaire** : ✅ CONTRÔLÉ À L'USAGE LE 21/09, ET LE CONTRÔLE A CORRIGÉ MA PROPRE NOTE. Premier essai non concluant : question sur une unité de transformation de cacao, Alioune n'a utilisé aucun chiffre de la note, mais elle est allée chercher l'ICCO, le Conseil du café-cacao et l'USDA, meilleures sources pour CETTE question. Un test dont on ne peut pas conclure n'est pas un test réussi. Second essai sur la structure des exportations, que la note porte directement : PASSÉ, et elle a fait mieux que la note. Elle a relevé 2024 quand la note s'arrêtait à 2023, vérifié que les deux requêtes tombent au dollar près, et ÉTABLI ce que j'avais laissé ouvert sur le chapitre 89. ⛔ DEUX DÉFAUTS DE MON CÔTÉ, CORRIGÉS : l'année était figée en dur dans le script, donc la note vieillissait en silence ; et le sondage naïf de la dernière année retenait 2025, qui bute sur le plafond de 500 lignes de l'aperçu et rend du mensuel, soit 69 milliards de dollars contre 20,5 en 2024, sans aucun message d'erreur. Le script refuse désormais une année qui touche le plafond. || ⚠ CORRIGÉ LE 21/09 : les pièces étaient deux scripts. Remplacés par la note reperes-macro-ci.md, engendrée par eux, qui porte les agrégats et la structure du commerce extérieur. ⛔ UN CHIFFRE DE CETTE NOTE NE SE CITE PAS SANS VÉRIFIER : le chapitre 89, navires, pèse 5,5 % des exportations et un milliard de dollars alors que le pays ne construit pas de navires. Non élucidé, et écrit comme tel. || INTÉGRÉ LE 21/09, par les intégrations banque-mondiale et un-comtrade. De quoi ADOSSER un avis de secteur à des chiffres datés au lieu d'une impression : PIB courant 99,8 milliards USD en 2025, croissance réelle 6,5 %, PIB par habitant 3 050 USD, inflation 0,13 %, population 32 711 547, urbanisation 54,6 %. Et la structure des échanges déclarés 2023, par partenaire et par chapitre de produit. ⛔ CE QUE ÇA NE DONNE PAS : la rentabilité d'un secteur, ses marges et ses acteurs. Un agrégat macro cadre un dossier, il ne le tranche pas. ⚠ Un agrégat se cite en trois morceaux, la valeur, l'année, la source, et la Banque mondiale rend des années SANS valeur pour les séries non publiées : le script écarte les vides et rend l'année avec le chiffre. || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || FAIT LE 18/09, et le chiffre contredit le récit courant. Séries dans ~/.claude/outils-communs/statistiques-ci/. POIDS DU SECTEUR PRIMAIRE DANS LE PIB : 15,7 % en 2019, 16,9 % en 2020, 16,2 % en 2021, 16,6 % en 2022, 15,2 % EN 2023, dont agriculture d'exportation 7,2 % et agriculture vivrière 5,2 % en 2023. LE PAYS EST LE PREMIER PRODUCTEUR MONDIAL DE CACAO ET SON SECTEUR PRIMAIRE PÈSE MOINS D'UN SIXIÈME DU PIB, EN RECUL DEPUIS 2020. Dire que l'agriculture est le moteur sans ce chiffre, c'est répéter un récit, pas instruire un dossier : l'essentiel de la valeur ajoutée se forme ailleurs. CROISSANCE RÉELLE : 7,2 % en 2023, 6,9 % en 2022, 7,4 % en 2021, 2,0 % en 2020. PIB nominal 2023 47 913,3 milliards FCFA. ⛔ LA SÉRIE S'ARRÊTE À 2023 : pour 2024, 2025 et 2026 il n'existe pas de mesure dans ces bases ; la note de l'annexe fiscale 2026 annonce 6,5 % en 2025 et 6,7 % en 2026, PRÉVISIONS BUDGÉTAIRES DE L'ÉTAT, PAS MESURES. ⚠ CE QUI MANQUE : les études sectorielles elles-mêmes, qui diraient la TAILLE D'UN MARCHÉ et pas seulement le poids d'un secteur.

### CL-ALIOUNE-17 · Les risques propres au contexte : change, politique, logistique
- **Pourquoi** : Un dossier qui ignore le risque local
- **Où chercher** : Notes de risque publiées, presse
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Pour le volet change du risque : règlement n° 09/2010/CM/UEMOA sur disque. ⛔ L'entrée est libre, la sortie est soumise à autorisation préalable du ministre chargé des Finances. ⚠ Les volets politique et logistique de cette ligne ne sont PAS couverts par cette pièce. || FAIT LE 18/09 POUR LE CHANGE, qui est le volet où l'on se trompe le plus, et NON FAIT pour le politique et le logistique. Base montée : ~/.claude/outils-communs/change-uemoa/, avec le RÈGLEMENT N° 09/2010/CM/UEMOA DU 1er OCTOBRE 2010 relatif aux relations financières extérieures, 47 pages, 43 articles, pris sur decfinex.tresor.gouv.ci, site du Trésor ivoirien. CE QUI EST LIBRE, à savoir avant de parler de contrainte de change à un investisseur étranger : les mouvements de capitaux ENTRE ÉTATS MEMBRES de l'UEMOA sont libres et sans restriction aucune ; LES INVESTISSEMENTS ÉTRANGERS DANS UN ÉTAT MEMBRE, ET LA CESSION D'INVESTISSEMENTS ENTRE NON-RÉSIDENTS, SONT LIBRES. ⛔ CE QUI NE L'EST PAS, ET L'ASYMÉTRIE EST LE POINT À RETENIR : tout investissement À L'ÉTRANGER effectué par un RÉSIDENT est subordonné à une AUTORISATION PRÉALABLE DU MINISTRE CHARGÉ DES FINANCES. L'argent entre librement, il ne ressort pas librement. CE QUI SE DÉCLARE MÊME QUAND C'EST LIBRE : les investissements directs font l'objet d'une déclaration statistique à la Direction chargée des Finances Extérieures et à la BCEAO ; tout emprunt à l'étranger de même, et par l'entremise d'un intermédiaire agréé. ⚠ DÉFINITION PIÉGEUSE, À CITER TELLE QUELLE : n'est pas un investissement direct la seule participation N'EXCÉDANT PAS DIX POUR CENT du capital d'une société ; un ticket minoritaire sous ce seuil ne suit pas le même régime. ℹ Le rapatriement est effectif lorsque la banque cède les devises à la BCEAO, pas à la date de l'ordre. ⛔ LE TEXTE DE 2010 EST CELUI QUI EST SUR LA MACHINE : la BCEAO a publié en mai 2023 une note décrivant une révision, mais elle est rédigée EN PROPOSITIONS et son adoption n'est pas établie ; vérifier sur bceao.int avant de citer une règle que la révision changerait. ⏸ RISQUE POLITIQUE ET RISQUE LOGISTIQUE NON SOURCÉS : question posée à l'équipe le 18/09, il pense que la maison utilise déjà quelque chose, à identifier.

## Références

### CL-ALIOUNE-18 · Dossiers d'investissement réels du marché régional
- **Pourquoi** : Travailler sans modèle local
- **Où chercher** : Documents publics d'opérations
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE. Ni documents publics d'opérations rassemblés, ni modèles internes. Ce que demande la ligne, c'est un jeu de notes de comité et de term sheets réellement utilisés ici, pour ne pas calquer un format étranger. ℹ UNE PISTE SÉRIEUSE ET GRATUITE, NON EXPLORÉE : les documents d'information visés par l'AMF-UMOA à l'occasion des appels publics à l'épargne, et les rapports annuels des 47 sociétés cotées, que la BRVM publie. Ce ne sont pas des dossiers de capital-risque, mais ce sont de vrais documents d'opération du marché régional, en français, et à la bonne échelle.
