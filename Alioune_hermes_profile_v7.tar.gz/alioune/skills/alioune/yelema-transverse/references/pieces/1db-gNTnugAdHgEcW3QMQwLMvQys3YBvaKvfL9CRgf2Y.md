# 260921_Reperes macro Cote d Ivoire v2

===== onglet t.0 · Tab 1 · 114 lignes non vides =====

# Les repères macro de la Côte d'Ivoire, et ce qu'ils ne disent pas
Relevé du 2026-09-21.
## À quoi sert cette note
Adosser un avis à des chiffres datés plutôt qu'à une impression. Un dossier qui affirme « le secteur X est porteur » sans un agrégat derrière n'instruit rien, il répète ce qui se dit. Ces repères servent à cadrer : l'ordre de grandeur du pays, sa croissance, où partent ses exportations et en quoi elles consistent.

⛔ Ils ne tranchent pas un dossier sectoriel. Ils ne donnent ni la taille d'un marché, ni une rentabilité, ni des marges, ni les acteurs en présence. Un agrégat macro encadre une analyse, il ne la remplace pas. Les études sectorielles restent à trouver, et c'est écrit comme tel dans la couche locale.
## Les agrégats
Banque mondiale · CIV · relevé le 21/09/2026
indicateur                                                           valeur  année
Population totale                                                  32711547  2025
PIB courant, dollars                                      99 773 555 666,20  2025
Croissance du PIB réel, %                                              6,50  2025
PIB par habitant, dollars                                          3 050,10  2025
Inflation, prix à la consommation, %                                   0,13  2025
Population urbaine, % du total                                        54,55  2025
Individus utilisant Internet, % de la population                      41,43  2024
Abonnements mobiles pour 100 habitants                               183,88  2024
Chômage, % de la population active                                     2,32  2025
Alphabétisation des adultes, %                                           50  2021

Source : Banque mondiale, World Development Indicators, api.worldbank.org

Un agrégat se cite en trois morceaux : la valeur, l'année, la source. Sans l'année, le chiffre est invérifiable et vieillit en silence. La Banque mondiale renvoie des années sans valeur pour les séries non publiées : le relevé ci-dessus écarte les vides et rend l'année réellement mesurée, qui n'est donc pas la même pour toutes les lignes.

⚠ Deux lectures à ne pas confondre. Une mesure est un constat publié ; une prévision est un engagement budgétaire de l'État. L'annexe fiscale annonce 6,5 % pour 2025 et 6,7 % pour 2026 : ce sont des prévisions. Ne jamais les servir comme des mesures.
## Où partent les exportations
CIV · exportations par partenaire · 2024
   part           valeur USD  intitulé
  13.4%        2 751 688 782  Switzerland
  12.2%        2 512 773 257  Netherlands
   8.1%        1 669 188 142  Mali
   4.5%          922 489 018  USA
   4.2%          871 216 711  Germany
   4.1%          846 532 641  France
   4.0%          830 663 722  Viet Nam
   4.0%          824 917 212  Belgium
   3.8%          770 773 217  Burkina Faso
   3.5%          728 950 972  China
   3.5%          716 811 099  Spain
   3.5%          715 291 982  Malaysia
   2.3%          477 159 972  Türkiye
   2.3%          469 411 262  South Africa
   2.1%          439 253 733  United Kingdom
   2.1%          437 413 965  India
   1.7%          355 939 678  Italy
   1.3%          276 062 012  Ghana
   1.3%          273 870 375  Canada
   1.3%          261 399 584  Areas  nes

Total des lignes retenues : 20 548 862 153 USD
⛔ Chiffres DÉCLARÉS à l'ONU : ni l'informel ni la contrebande n'y sont, et un même flux diffère souvent selon qu'on lit le déclarant ou son partenaire.
Source : UN Comtrade, aperçu public, comtradeapi.un.org
⚠ L'aperçu public plafonne le nombre de lignes : cette liste est celle des plus gros partenaires rendus, pas l'intégralité du commerce.

⛔ Le fait que ce tableau impose : trois des dix premiers clients sont des voisins de la sous-région, et le Mali est le troisième débouché du pays. Un raisonnement qui ne regarde que l'Europe et l'Asie passe à côté d'une part majeure, et il passe surtout à côté du fait que ce débouché-là dépend de corridors terrestres et de la stabilité régionale, pas du fret maritime.
## Ce que le pays exporte
CIV · exportations par chapitre de produit · 2024
   part           valeur USD  intitulé
  35.0%        7 183 624 687  18 · Cocoa and cocoa preparations
  15.3%        3 144 142 851  71 · Natural  cultured pearls; precious  semi-precious stones; precious metals  metals clad with precious metal  and articles thereof; imitation jewellery; coin
  15.1%        3 107 433 041  27 · Mineral fuels  mineral oils and products of their distillation; bituminous substances; mineral waxes
  12.0%        2 464 322 363  40 · Rubber and articles thereof
   7.3%        1 505 341 425  08 · Fruit and nuts  edible; peel of citrus fruit or melons
   1.7%          356 973 916  15 · Animal  vegetable or microbial fats and oils and their cleavage products; prepared edible fats; animal or vegetable waxes
   1.4%          294 469 459  52 · Cotton
   1.4%          279 990 402  33 · Essential oils and resinoids; perfumery  cosmetic or toilet preparations
   1.0%          207 735 993  39 · Plastics and articles thereof
   0.8%          169 262 990  21 · Miscellaneous edible preparations
   0.8%          159 414 291  89 · Ships  boats and floating structures
   0.7%          147 943 511  84 · Machinery and mechanical appliances  boilers  nuclear reactors; parts thereof
   0.7%          145 454 094  26 · Ores  slag and ash
   0.7%          143 161 740  09 · Coffee  tea  mate and spices
   0.6%          126 628 457  34 · Soap  organic surface-active agents; washing  lubricating  polishing or scouring preparations; artificial or prepared waxes  candles and similar articles  modelling pastes  dental waxes and dental preparations with a basis of plaster
   0.6%          115 662 801  44 · Wood and articles of wood; wood charcoal
   0.4%           88 528 091  85 · Electrical machinery and equipment and parts thereof; sound recorders and reproducers; television image and sound recorders and reproducers  parts and accessories of such articles
   0.4%           84 094 216  48 · Paper and paperboard; articles of paper pulp  of paper or paperboard
   0.3%           70 250 972  24 · Tobacco and manufactured tobacco substitutes; products  whether or not containing nicotine  intended for inhalation without combustion; other nicotine containing products intended for the intake of nicotine into the human body
   0.3%           69 480 737  16 · Meat  fish  crustaceans  molluscs or other aquatic invertebrates  or insects; preparations thereof

Total des lignes retenues : 20 548 862 153 USD
⛔ Chiffres DÉCLARÉS à l'ONU : ni l'informel ni la contrebande n'y sont, et un même flux diffère souvent selon qu'on lit le déclarant ou son partenaire.
Source : UN Comtrade, aperçu public, comtradeapi.un.org

⚠ Le chapitre 89, navires et structures flottantes, est un piège d'une seule année. Il pesait 1 001 700 362 USD en 2023, soit 5,5 % des exportations déclarées, et retombe à 159 414 291 USD en 2024, soit 0,8 %. La Côte d'Ivoire ne construit pas de navires ; les destinations de 2023 étaient l'Angola, les Pays-Bas, la Norvège, le Portugal, la Belgique et l'Égypte, toutes pétrolières ou maritimes. La cause n'est pas établie et ne se devine pas. Un raisonnement bâti sur 2023 doit isoler ce chapitre, sinon il compte un pic ponctuel comme un secteur d'activité.

Le détail de 2023, gardé pour cette comparaison :

CIV · exportations par chapitre de produit · 2023
   part           valeur USD  intitulé
  31.6%        5 806 918 037  18 · Cocoa and cocoa preparations
  15.8%        2 893 941 097  27 · Mineral fuels  mineral oils and products of their distillation; bituminous substances; mineral waxes
  12.8%        2 353 173 331  71 · Natural  cultured pearls; precious  semi-precious stones; precious metals  metals clad with precious metal  and articles thereof; imitation jewellery; coin
  11.2%        2 054 548 771  40 · Rubber and articles thereof
   8.2%        1 509 686 715  08 · Fruit and nuts  edible; peel of citrus fruit or melons
   5.5%        1 001 700 362  89 · Ships  boats and floating structures
   1.8%          327 672 482  15 · Animal  vegetable or microbial fats and oils and their cleavage products; prepared edible fats; animal or vegetable waxes
   1.6%          287 294 112  33 · Essential oils and resinoids; perfumery  cosmetic or toilet preparations
   1.2%          224 134 624  52 · Cotton
   1.0%          175 909 720  39 · Plastics and articles thereof
   0.9%          159 302 761  26 · Ores  slag and ash
   0.8%          138 736 979  21 · Miscellaneous edible preparations
   0.7%          137 002 910  84 · Machinery and mechanical appliances  boilers  nuclear reactors; parts thereof
   0.7%          127 441 758  34 · Soap  organic surface-active agents; washing  lubricating  polishing or scouring preparations; artificial or prepared waxes  candles and similar articles  modelling pastes  dental waxes and dental preparations with a basis of plaster
   0.6%          106 906 617  44 · Wood and articles of wood; wood charcoal
   0.5%           88 660 469  48 · Paper and paperboard; articles of paper pulp  of paper or paperboard
   0.4%           79 472 403  31 · Fertilizers
   0.4%           71 427 613  64 · Footwear; gaiters and the like; parts of such articles
   0.4%           67 455 428  63 · Textiles  made up articles; sets; worn clothing and worn textile articles; rags
   0.4%           65 389 967  24 · Tobacco and manufactured tobacco substitutes; products  whether or not containing nicotine  intended for inhalation without combustion; other nicotine containing products intended for the intake of nicotine into the human body

Total des lignes retenues : 18 350 163 618 USD
⛔ Chiffres DÉCLARÉS à l'ONU : ni l'informel ni la contrebande n'y sont, et un même flux diffère souvent selon qu'on lit le déclarant ou son partenaire.
Source : UN Comtrade, aperçu public, comtradeapi.un.org
## Limites, et comment rafraîchir
Ces chiffres sont des déclarations douanières agrégées. Ils portent sur les flux déclarés, pas sur les échanges réels : le commerce informel transfrontalier, considérable dans la sous-région, n'y figure pas. Un écart entre ce tableau et ce que dit un professionnel du terrain n'est pas forcément une erreur du tableau.

python3 integrations/banque-mondiale/chiffres.py --pays CIV
python3 integrations/banque-mondiale/chiffres.py --chercher "valeur ajoutée agriculture"
python3 integrations/un-comtrade/echanges.py --partenaires
python3 integrations/un-comtrade/echanges.py --produits

Pour un indicateur qui n'est pas dans la liste ci-dessus, --chercher trouve son code, puis --indicateur <code> le relève. Tout appel passe par ces scripts et par eux seuls.

Sources : Banque mondiale, World Development Indicators, api.worldbank.org · Nations unies, UN Comtrade, comtradeapi.un.org.
