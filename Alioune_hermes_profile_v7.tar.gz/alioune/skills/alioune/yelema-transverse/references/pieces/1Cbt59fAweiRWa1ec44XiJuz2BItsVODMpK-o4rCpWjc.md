# 260922_La BRVM - ce qui y est cote et comment le lire

===== onglet t.0 · Tab 1 · 40 lignes non vides =====

# La BRVM, ce qui y est coté et comment le lire
Écrite le 22/09/2026. La Bourse régionale des valeurs mobilières est le marché financier des huit pays de l'UEMOA, basée à Abidjan. Pour un dossier d'investissement, elle change une chose : une sortie en bourse régionale n'est pas une hypothèse d'école, et elle fournit des comparables locaux qu'on n'a plus besoin d'aller chercher sur un marché américain.
## La source, et elle est parfaite
Le bulletin officiel de la cote est public, quotidien, gratuit, et à adresse prévisible :

https://bfin.brvm.org/boc/BOC_JOUR/BOC_AAAAMMJJ.pdf

⛔ Aucun chiffre de marché ne se cite de mémoire ni de seconde main. On ouvre le bulletin du jour, on lit, on date. Deux copies sont gardées ici comme exemples de lecture : brvm-bulletin-20260918.pdf et brvm-bulletin-20260921.pdf.

⚠ Jours ouvrés seulement, et avec du retard. Vérifié le 22/09/2026 à 19 h : le bulletin du jour même rendait 404, celui du samedi 19 aussi, ceux du vendredi 18 et du lundi 21 répondaient. Un script qui veut « le dernier bulletin » doit remonter les jours jusqu'à trouver, il ne peut pas supposer la date du jour.
## L'état du marché au lundi 21 septembre 2026
|  |  |
| Sociétés cotées | 47 |
| Lignes obligataires | 206 |
| Capitalisation actions et droits | 21 003 Md FCFA |
| BRVM Composite | 544,68 · +57,54 % sur un an |
| BRVM 30 | 263,82 · +58,70 % sur un an |
| PER moyen du marché | 17,28 |
| Taux de rendement moyen | 6,01 % |
| Taux de rentabilité moyen | 4,59 % |
| Volume moyen annuel par séance | 1 973 870 titres |
| Valeur moyenne annuelle par séance | 2 847 Md FCFA |

Deux compartiments portent les 47 sociétés : BRVM-Prestige, 12 sociétés (PER moyen 14,69 au 18/09) et BRVM-Principal, 35 sociétés (PER moyen 21,90 au 18/09). ℹ Un compartiment de croissance destiné aux PME est mentionné par des sources secondaires ; aucune cotation n'y apparaît dans le bulletin, donc on ne l'affirme pas.

Répartition sectorielle et PER par secteur, au 21/09 :

| Secteur | Sociétés | PER moyen (18/09) |
| Services financiers | 16 | 17,02 |
| Consommation de base | 9 | 10,15 |
| Consommation discrétionnaire | 7 | 40,17 |
| Industriels | 6 |  |
| Énergie | 4 |  |
| Télécommunications | 3 | 14,48 |
| Services publics | 2 |  |

⚠ Le PER moyen du marché est calculé sans la valeur Unilever CI, le bulletin le précise en note de bas de tableau. Reprendre la note avec le chiffre.
## Ce que ça change pour un dossier
- Un comparable local existe. Un PER de 17,28 pour le marché, 10,15 en consommation de base et 40,17 en consommation discrétionnaire : la dispersion par secteur est forte, on compare secteur par secteur, jamais au PER global.
- ⛔ La liquidité est mince, et c'est la vraie contrainte. Au 18/09, 44 titres seulement avaient été échangés dans la séance, sur 47 sociétés cotées, pour 4,6 Md FCFA. Une sortie en bourse s'y construit, elle ne s'y improvise pas : la question n'est pas « peut-on coter », c'est « qui achètera le jour où l'on vend ».
- Les variations annuelles sont spectaculaires (Composite +57,5 %, BRVM 30 +58,7 %). Un comparable pris en haut de cycle n'est pas un comparable. Toujours citer la variation annuelle à côté du niveau.
## Ce que cette fiche ne couvre pas
- La liste nominative des 47 sociétés, qui est dans le bulletin, à relever au besoin.
- Les 37 SGI participantes, sociétés de gestion et d'intermédiation, dont la liste est aussi dans le bulletin.
- Les conditions d'admission à la cote, qui relèvent du règlement général de la BRVM et de l'AMF-UMOA. ⟦à récupérer⟧

Chiffres au 21/09/2026. Ils se périment en une séance : rouvrir le bulletin avant toute citation.
