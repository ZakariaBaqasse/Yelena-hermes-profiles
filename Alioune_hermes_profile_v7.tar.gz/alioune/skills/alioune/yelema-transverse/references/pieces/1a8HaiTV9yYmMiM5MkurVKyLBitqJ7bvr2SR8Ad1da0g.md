# 260922_Qui finance quoi en Cote d'Ivoire - bailleurs et investisseurs

===== onglet t.0 · Tab 1 · 55 lignes non vides =====

# Qui finance quoi en Côte d'Ivoire
Constituée le 22/09/2026 en rassemblant ce qui vivait dans quatre postes sans être posé nulle part. Deux mondes qui ne se confondent pas : les bailleurs publics, qui financent l'État et ses projets, et les investisseurs privés, qui prennent des participations dans des entreprises.
## ⛔ La règle de lecture, qui vaut plus que toutes les listes
Un même montant traverse quatre états, et presque personne ne fait la distinction :

| État | Ce que ça veut dire |
| Intention | annoncée en table ronde ou en communiqué. N'engage rien |
| Approbation | le conseil du bailleur a validé. L'argent n'est pas signé |
| Signature ou ratification | l'accord existe juridiquement |
| Décaissement | l'argent est parti |

⛔ Un chiffre sans son état ne veut rien dire, et c'est l'erreur la plus fréquente dans la reprise de presse : une intention annoncée devient « la Banque mondiale a débloqué ». Toujours nommer l'état, et le dater.
## Les bailleurs publics : où regarder
Quatorze sources suivies, avec leurs pièges d'accès déjà relevés :

Banque mondiale (portail projets) · BAD, projectsportal.afdb.org · AFD · Trésor et DGTCP, tresor.gouv.ci ⚠ le préfixe www casse tout · finances.gouv.ci · FMI ⚠ 403 aux robots · BOAD · BADEA · Banque islamique de développement · Union européenne · PNUD · FIDA · Fonds vert pour le climat · CEPICI.

⚠ Rappel de la barrière UEMOA : uemoa.int sert une chaîne TLS incomplète, réparée par integrations/web-public/telecharger.py. Ce n'est pas un site inaccessible.
## Les financements documentés du PND
Neuf financements, avec leur état et leur date. Tous sont à l'état signé, ratifié ou approuvé, aucun n'est un décaissement constaté.

| Bailleur | Montant | État et date |
| Banque mondiale | 875 M USD | 5 accords signés le 08/07/2026 |
| BAD | 200 M€ | approuvé le 13/07/2026 |
| BOAD | 30 Md FCFA | ratifié le 22/07/2026 |
| AFD | 28,3 M€ | ratifié le 22/07/2026 |
| BID | 15,25 M€ | ratifié le 22/07/2026 |
| BADEA | 9,58 Md FCFA | ratifié le 22/07/2026 |
| IDA | 57,27 Md FCFA | ratifié le 22/07/2026 |
| Marché UMOA | 79,03 Md FCFA | levée du 21/07/2026 |
| PASEA | 825 M USD | signé le 10/07/2024 |

⛔ Ces neuf lignes ne sont pas le portefeuille. Le portefeuille du PND annoncé est de 114 838,5 Md FCFA, et il n'est traçable qu'à 10 à 15 % sur sources publiques. Présenter cette liste comme le financement du PND serait faux d'un ordre de grandeur.
### Le Groupe de coordination arabe et les Nations unies
⚠ Source unique, et c'est une page de communication : la biographie officielle de la ministre. Ces chiffres valent pour préparer un entretien, pas pour être cités publiquement, et se recoupent avant tout usage externe.

Groupe de coordination arabe, coopération passée de 600 M USD à près de 3 Md USD en 2025 · Système des Nations unies et PNUD, plus de 600 M USD (350 Md FCFA) de dons mobilisés entre 2021 et 2024, portefeuille actif de 55 Md FCFA · Canada, mémorandum cadre de 2023, plus de 125 Md FCFA sur l'autonomisation des femmes, le climat et la formation professionnelle · BAD, présidence du Conseil des gouverneurs 2019-2020, augmentation de capital de +125 % · BIDC, présidence du Conseil des gouverneurs · BID, gouverneure.
### Le numérique : un projet documenté, pas un paysage
PADCI, Projet d'accélération digitale en Côte d'Ivoire, financé par la Banque mondiale. Son plan de mobilisation des parties prenantes donne le détail :

| Composante | Montant |
| 1. Fondements numériques | 50 M USD, dont 5 pour les fondements juridiques et institutionnels et 45 pour les compétences numériques intermédiaires et avancées |
| 2. Connectivité haut débit résiliente au climat | 45 M USD, dont 30 pour raccorder les établissements publics déjà électrifiés et 15 pour la protection des infrastructures critiques |
| 3. Fourniture de services publics numériques | 45 M USD |
| 4. Gestion du projet |  |

Zone de la première phase : les deux districts autonomes et onze régions prioritaires.

⚠ Un projet documenté n'est pas un paysage de bailleurs. BAD, BID, Union européenne et coopérations bilatérales sur le numérique restent à établir. ⟦à faire⟧
## Les investisseurs privés
⚠ Cette liste n'est pas exhaustive et ne peut pas l'être : les fonds de capital-risque et de capital investissement ne figurent dans aucun registre public. Ils ne sont pas des intermédiaires de marché, donc pas agréés par l'AMF-UMOA. La liste se bâtit opération par opération.

Gérants implantés à Abidjan, à saisir en premier :

- Comoé Capital, fonds d'impact, cinquième fonds africain parrainé par Investisseurs & Partenaires au titre d'I&P Développement 2, dirigé par Issa Sidibé. Ticket 0 à 500 000 €, PME et start-up ivoiriennes, 4,4 Md FCFA levés, la CDC-CI est à son capital.
- Adiwale Partners, capital investissement indépendant fondé en 2016 à Abidjan. Participations minoritaires significatives dans 10 à 12 entreprises, capital de croissance de 3 à 8 M€, Afrique de l'Ouest francophone. Adiwale Fund I clôturé à 60 M€ dont 12,5 M€ de la BAD.
- CDC-CI Capital, filiale à 100 % de la Caisse des dépôts et consignations de Côte d'Ivoire, initiative publique à gestion privée, deux guichets : agro-industrie, fintech, industries culturelles, projets verts. 720 M FCFA dans 8 start-up en mai 2026, au moins 2,6 Md FCFA sur douze mois.

Fonds régionaux ayant signé ici, à qualifier par un appel : Janngo Capital, E3 Capital, KawiSafi Ventures, Cur8 Capital (tous les quatre au tour de GoCab Côte d'Ivoire, 45 M$ dont 15 M$ en fonds propres et 30 M$ en dette) · Saviu Ventures (Saviu II, 6,5 M€ approuvés par la BAD, amorçage et premier tour institutionnel, Afrique de l'Ouest et Centrale francophone).

⛔ Quatre de ces cinq lignes viennent d'une seule opération. C'est le piège de la base construite au deal : ces noms valent un appel, pas une présentation comme acteurs installés.

⚠ Tenue de la liste : aucun nom n'y entre sans source datée, et un ticket annoncé au lancement d'un fonds ne dit pas ce qu'il fait aujourd'hui. Avant d'orienter un dossier, on rappelle le fonds et on fait confirmer sa thèse du moment.
## Ce qui reste à faire
- Qualifier les quatre fonds issus du tour GoCab.
- Ajouter les banques commerciales et leurs lignes PME, absentes de l'inventaire. C'est probablement le canal le plus utilisé et le moins documenté ici.
- Vérifier sur source primaire le projet de fonds national de 100 Md FCFA pour les start-up technologiques, relevé dans la presse et non confirmé, donc hors liste.
- Établir le paysage des bailleurs du numérique au-delà du PADCI.

Pour le marché financier régional et les comparables de valorisation, voir BRVM.md.

À recontrôler le 22/12/2026 : les montants annoncés changent d'état en quelques mois.
