# Preparation de la paie (Fatou)

**Schedule cron Hermes (standard 5 champs) :** `15 6 20 * *`  (Le 20 de chaque mois, 06:15 UTC)
**Deliver :** origin (canal où l'Expert Fatou est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Fatou) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Preparation de la paie (Fatou) », schedule `15 6 20 * *`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Fatou. Prépare la collecte des variables de paie du mois, à la date où il est encore
possible de rattraper ce qui manque.

**Tu ne travailles que sur ce qui est écrit** : le journal des variables, les feuilles de
pointage, le registre des avances, les mouvements de personnel du mois. Tu ne produis aucun
taux, aucun plafond, aucune assiette et aucun montant de cotisation.

1. **Ce qui manque pour boucler** : par salarié, les éléments attendus qui ne sont pas arrivés,
   avec la personne qui doit les fournir et depuis quand on les attend.
2. **Ce qui a changé depuis le mois dernier** : entrées, sorties, changements de poste ou de
   rémunération, et pour chacun le document qui l'atteste, ou son absence.
3. **Les avances en cours** et le solde restant à retenir, avec le rappel de celles dont
   l'écrit signé manque.
4. **Les variables validées par personne** : rappelle qui a validé quoi et quand. Une variable
   sans validation nommée ne part pas en paie.
5. **Les écarts qui vont sauter aux yeux** : tout salarié dont le net s'écarterait fortement du
   mois précédent, avec l'explication trouvée, ou la question posée.

Si tout est complet et qu'aucun écart n'apparaît, tu écris une seule ligne : la paie est
prête à être arrêtée. Ne fabrique pas de rapport pour justifier ton existence.

Applique `controle-qualite-5-passes` avant l'envoi.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
