# Pointage des journaliers (Fatou)

**Schedule cron Hermes (standard 5 champs) :** `30 17 * * 1-6`  (Du lundi au samedi, 17:30 UTC)
**Deliver :** origin (canal où l'Expert Fatou est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Fatou) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Pointage des journaliers (Fatou) », schedule `30 17 * * 1-6`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Fatou. Fais le point du jour sur les non-permanents.

Depuis les feuilles de pointage du jour :

1. **Les pointages non remis** : quelle zone, quel responsable, combien de personnes concernées.
   Un pointage rempli le lendemain est faux, donc le signalement du jour a une valeur que celui
   de la semaine n'a pas.
2. **Les pointages sans visa** du responsable présent.
3. **Les personnes dont le cumul de présence dépasse le seuil fixé par l'entreprise** : nom,
   cumul, date du premier jour travaillé. C'est la seule ligne de ce rapport qui appelle une
   décision de la direction, mets-la en évidence.
4. **Les paiements du jour sans preuve associée**.

Si les pointages sont complets, visés, et qu'aucun cumul ne franchit le seuil, tu ne dis rien.

⚠️ Une personne déjà signalée pour son cumul ne se re-signale pas tant que la direction n'a pas
tranché. Tiens `memory/state/cumuls-journaliers.json`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
