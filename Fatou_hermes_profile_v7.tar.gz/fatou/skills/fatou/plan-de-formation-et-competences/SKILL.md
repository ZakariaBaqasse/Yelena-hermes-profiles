---
id: Y0447
name: plan-de-formation-et-competences
description: "Construit la montée en compétence d'une équipe avec les moyens réels d'une PME : carte des compétences observées, liste des dépendances critiques (la personne unique qui sait faire), plan d'action qui commence par ce qui ne coûte rien (compagnonnage, rotation, procédure écrite, formation fournisseur) avant d'envisager le payant. Nomme les dispositifs de financement de la formation existants et l'organisme qui les gère, sans jamais inventer un taux, un montant ou une condition d'éligibilité."
bucket: B
tags: [RH, Formation, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Faire monter les gens en compétence sans budget de formation

## Ce qu'il faut avoir sous la main
- **L'équipe concernée** : les postes et les personnes, avec leurs tâches principales telles qu'elles se font réellement, pas telles qu'elles sont écrites sur le papier (s'il y a un papier).
- **Les compétences clés du métier** : celles sans lesquelles l'activité s'arrête ou tourne mal.
- **Les incidents récents** qui ont révélé un manque : une erreur, un retard, un client mécontent, une absence qui a bloqué quelque chose. Ce sont eux qui montrent où chercher, pas une intuition générale.
- **Ce qui existe déjà** : tutorat informel, procédures écrites, formations déjà suivies, fournisseur qui a déjà formé quelqu'un sur son matériel.
- **Le budget réel disponible**, même zéro, et si l'entreprise a déjà eu recours à un dispositif de financement de la formation.
- **La ville ou la région**, pour situer l'offre de formation locale accessible.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Cartographier ce que les gens savent faire réellement

Construis la carte à partir de ce qui est **observé**, jamais de ce qui est **déclaré**. Un responsable qui dit « il maîtrise » et un client qui se plaint du même travail ne racontent pas la même chose : c'est le second qui compte. La preuve d'observation peut être un incident, un contrôle qualité, un résultat chiffré fourni par l'entreprise, ou un test simple que tu proposes de faire passer.

Une compétence déclarée sans preuve d'observation reste marquée `[à vérifier]` dans la carte, elle n'entre pas comme un niveau acquis.

L'erreur de débutant ici est de recopier l'organigramme ou les fiches de poste comme s'ils décrivaient le travail réel. Dans une PME, la fiche de poste et le travail du jour se ressemblent rarement.

### Étape 2 : Faire apparaître les dépendances critiques

Pour chaque compétence clé du métier, pose la question : combien de personnes savent la faire, et que se passe-t-il si la seule qui sait est absente une semaine, un mois, ou définitivement. Si la réponse est « une seule personne, et je ne sais pas », c'est une dépendance critique, et elle doit apparaître nommément dans le livrable, avec la conséquence concrète de l'absence (arrêt de production, perte du client, incapacité à facturer, panne non réparable).

C'est le risque le moins visible d'une PME parce qu'il n'apparaît dans aucun tableau tant que la personne est là. Tu le fais exister avant qu'il ne se produise, avec une solution de reprise même minimale (documenter, doubler, faire tourner).

### Étape 3 : Distinguer le vrai besoin de formation d'un problème d'organisation

Avant de conclure qu'il faut former quelqu'un, demande ce qui l'empêche de bien faire aujourd'hui : la tâche a-t-elle été décrite une seule fois clairement, l'outil fonctionne-t-il, la consigne change-t-elle chaque semaine sans être réécrite, la personne a-t-elle les moyens matériels de faire ce qu'on lui demande. Un problème d'organisation qu'on traite comme un problème de compétence coûte une formation qui ne changera rien.

Ce n'est qu'après avoir écarté ces causes que tu classes le manque comme un vrai besoin de compétence à combler.

### Étape 4 : Prioriser ce qui manque ou ce qui est fragile

Croise la carte de l'étape 1 et les dépendances de l'étape 2 : une compétence rare, critique pour l'activité, et détenue par une seule personne, passe avant une compétence secondaire détenue par plusieurs. Priorise aussi ce qui a déjà causé un incident constaté, avant ce qui reste hypothétique.

### Étape 5 : Construire le plan en respectant le gratuit avant le payant

Pour chaque compétence à combler, cherche dans cet ordre, et ne passe au niveau suivant que si le précédent ne suffit pas :
1. **Le compagnonnage interne** : quelqu'un qui sait déjà, à qui on donne du temps et un cadre pour transmettre.
2. **La rotation de postes** : faire tourner les personnes sur les tâches critiques pour que la dépendance à une seule personne se réduise d'elle-même.
3. **La procédure écrite** : mettre sur papier ou en note vocale ce qui n'existe que dans une tête, pour que ça survienne à quelqu'un d'autre.
4. **La formation par le fournisseur** : la plupart des fournisseurs de matériel ou de logiciel forment gratuitement ou à faible coût sur leur propre produit ; c'est souvent oublié alors que c'est déjà payé dans le contrat.
5. **La formation externe payante** : en dernier recours, quand aucune des options précédentes ne couvre le besoin.

Chaque action du plan porte un **porteur nommé**, une **échéance**, et un **critère de réussite observable** (pas « il sera formé », mais « il refait seul telle tâche sans erreur sur telle période »). Une liste d'actions sans ces trois éléments est une liste de souhaits, pas un plan : elle ne se traduit jamais en changement réel.

### Étape 6 : Préparer le retour au poste

Une formation qui n'est suivie d'aucun changement au poste ne sert à rien : la personne revient, reprend ses habitudes, et personne n'a préparé l'environnement à ce qu'elle a appris. Pour chaque action de formation, précise ce qui change concrètement au retour : une tâche qui lui est confiée, un outil qu'elle utilise désormais, une transmission qu'elle assure à son tour.

### Étape 7 : Nommer les dispositifs de financement sans en inventer les conditions

Nomme les dispositifs de financement de la formation professionnelle qui existent dans le pays, et l'organisme qui les gère (en Côte d'Ivoire, le FDFP, Fonds de Développement de la Formation Professionnelle, en a la charge). Tu dis ce dont l'organisme s'occupe en général. Tu ne cites **aucun** taux de contribution, aucun plafond de prise en charge, aucune procédure détaillée : toutes les conditions concrètes sont marquées `⟦à vérifier auprès de l'organisme⟧`, parce qu'elles changent et que seule l'institution fait foi.

## Format de sortie
- **Livrable** : trois documents. La **carte des compétences** (une ligne par personne, une colonne par compétence clé, niveau observé avec preuve, jamais de niveau déclaré non vérifié). La **liste des dépendances critiques** (compétence, personne unique qui la détient, conséquence d'une absence, solution de reprise). Le **plan de montée en compétence** (action, modalité : interne, fournisseur ou externe payant, porteur, échéance, critère de réussite observable, coût `⟦à renseigner⟧`).
- **Structure** : Markdown, tableaux pour les trois livrables, answer-first (les dépendances critiques et les priorités d'abord, le détail du plan ensuite).
- **Longueur** : proportionnée à la taille de l'équipe ; pas de remplissage pour faire nombre.
- **Règle 0 invention** : aucun taux, montant, condition d'éligibilité ou statistique n'est produit sans être fourni ou sourcé. `⟦à renseigner⟧` ou `⟦à vérifier auprès de l'organisme⟧` sinon.

## Règles
1. **Aucune compétence n'entre dans la carte sur une simple déclaration.** Elle doit avoir une preuve d'observation, sinon elle reste `[à vérifier]`.
2. **La dépendance critique est nommée, même si la personne est encore présente et compétente.** Ne jamais attendre l'absence pour la signaler.
3. **On ne conclut à un besoin de formation qu'après avoir écarté un problème d'organisation** (tâche non décrite, outil défaillant, consigne instable, moyens absents).
4. **Le gratuit interne passe toujours avant le payant externe** dans l'ordre de proposition, sauf si le besoin dépasse manifestement ce que l'interne peut couvrir, et cette exception se justifie explicitement.
5. **Chaque action du plan porte un porteur, une échéance et un critère de réussite observable.** Sans ces trois éléments, ce n'est pas une action, c'est un vœu.
6. **Un dispositif de financement se nomme, jamais ses conditions chiffrées.** Le nom de l'organisme et sa mission générale peuvent être donnés ; taux, plafonds, montants et démarches restent `⟦à vérifier auprès de l'organisme⟧`.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; inscrire quelqu'un à une formation, engager une dépense ou contacter un organisme de financement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une équipe ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucune preuve d'observation disponible pour une compétence** : elle reste `[à vérifier]` dans la carte, tu ne lui donnes jamais de niveau par défaut, même « moyen ».
- **Une seule personne existe dans l'entreprise pour une tâche entière** (pas de doublon possible à court terme) : tu marques la dépendance comme critique et tu proposes une solution de reprise minimale (documenter la tâche, prévoir un contact de secours) plutôt que de conclure qu'il n'y a rien à faire.
- **Budget de formation à zéro** : tu produis quand même le plan complet, en donnant la priorité totale aux quatre premiers niveaux du gratuit (compagnonnage, rotation, procédure écrite, fournisseur) avant de mentionner l'option payante comme piste future.
- **Désaccord entre le responsable et la personne sur le niveau réel** : tu exposes les deux versions et la preuve disponible de chaque côté, tu ne trancnhes pas seul, tu proposes un test simple pour lever le doute.
- **Dispositif de financement mentionné par l'entreprise mais conditions inconnues** : tu nommes l'organisme, tu marques toutes les conditions `⟦à vérifier auprès de l'organisme⟧`, tu n'avances aucune probabilité d'éligibilité.
- **Incident non documenté, seulement raconté oralement** : tu l'utilises comme indice pour prioriser, mais tu le marques comme non vérifié plutôt que comme preuve d'observation ferme.
- **Demande hors périmètre** (recrutement, évaluation salariale, rupture de contrat) : tu le dis en une phrase, tu traites ce qui relève de la montée en compétence, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (inscrire quelqu'un à une formation, envoyer un dossier à l'organisme de financement) : tu prépares les éléments nécessaires et tu t'arrêtes pour validation humaine.
- **Sources contradictoires sur l'existence ou le rôle d'un dispositif** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
