---
id: Y0670
name: journaliers-et-saisonniers
description: "Organise le travail des journaliers, saisonniers et manutentionnaires payés à la tâche : pointage quotidien, règle de rémunération écrite, circuit de paiement traçable et suivi cumulé par personne pour repérer le moment où une situation cesse d'être occasionnelle, sans jamais fixer de seuil de requalification ni de barème à la place du droit applicable."
bucket: B
tags: [RH, Terrain, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# Les journaliers et les saisonniers, payer juste et pouvoir le prouver

## Ce qu'il faut avoir sous la main
- **Qui tu emploies ainsi** : journaliers de dépôt ou de chantier, renforts de saison, manutentionnaires à la tâche, avec le nombre approximatif de personnes concernées.
- **La base de rémunération actuelle**, même informelle : au jour, à la tâche, à la quantité, avec le montant si tu l'as déjà (sinon je le marque `⟦à renseigner⟧`).
- **Le mode de paiement réel** : espèces, mobile money, mélange des deux, et si une trace existe déjà (cahier, liste, rien).
- **Depuis quand ces personnes travaillent pour toi**, même approximativement, surtout celles qui reviennent souvent.
- **Le pays et le secteur** (agriculture, BTP, commerce, logistique) : le calendrier de saison et le droit applicable en dépendent.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process

### Étape 1 : Cadrer qui est réellement concerné

Distingue les trois profils, parce que la règle qui s'applique n'est pas la même : le **journalier** (présence au jour, dépôt ou chantier), le **saisonnier** (recruté pour un pic identifié dans le calendrier, récolte, fêtes, campagne commerciale), le **payé à la tâche** (rémunéré à la quantité produite ou manutentionnée, indépendamment du temps passé).

Le piège ici : appeler « journalier » quelqu'un qui vient tous les jours depuis des mois. Le mot ne protège rien, seule la réalité du cumul compte, et c'est l'étape 5 qui la mesure. À ce stade, tu te contentes de nommer correctement chaque profil et son motif de recours (pic de volume, absence de poste permanent budgété, essai avant embauche), parce que le motif éclaire déjà si la situation est censée être courte.

### Étape 2 : Écrire la règle de rémunération, une seule fois

Fais formuler la règle par la personne qui décide, pas par le chef d'équipe qui l'applique de mémoire : base de calcul (jour, tâche, quantité, unité de mesure), montant `⟦à renseigner⟧`, ce qui majore (dimanche, nuit, tâche pénible) et de combien `⟦à renseigner⟧`, ce qui est fourni en nature (repas, transport) et sa valeur si elle compte dans le calcul.

Une fois écrite, cette règle devient la référence unique. Le signal d'alerte : un chef d'équipe qui négocie le montant sur le terrain, ou une équipe payée différemment d'une semaine à l'autre pour la même tâche. Dès que tu le repères, tu le signales, ce n'est pas une variation normale, c'est l'absence de règle qui refait surface.

### Étape 3 : Construire la feuille de pointage du jour même

Le pointage se remplit sur le lieu, le jour même, par une personne nommée, jamais reconstitué de mémoire en fin de semaine. Un pointage reconstitué a posteriori est toujours faux, et il est faux dans le sens de celui qui le remplit, qu'il s'agisse d'arrondir des heures ou d'oublier une absence.

La feuille tient sur une ligne par personne et par jour : nom, tâche ou zone, heures ou quantité produite selon la base retenue à l'étape 2, visa du responsable présent. Le format reste identique d'un jour à l'autre, pour qu'un cumul soit lisible sans retraitement. Sur un chantier ou un dépôt sans accès numérique fiable, le papier reste légitime, à condition d'être rempli sur place et signé, pas rempli en fin de journée dans un bureau.

### Étape 4 : Rendre le paiement traçable

L'espèce n'est pas le problème, l'absence de preuve l'est. Chaque paiement, en espèces ou par mobile money, doit produire une trace : liste émargée avec nom, montant, date et motif, contresignée par deux personnes quand le montant ou le nombre de bénéficiaires le justifie, ou paiement par mobile money nominatif quand le réseau et l'équipement des personnes le permettent (attention, une partie des journaliers n'a pas de téléphone à leur nom ou n'est pas à l'aise avec l'usage, ne force pas le mobile money là où il exclut).

Le signal d'alerte : un paiement en liquide fait sans liste, "sur la confiance", surtout quand le chef d'équipe est aussi celui qui recrute les journaliers, situation où le contrôle croisé n'existe pas. Tu proposes alors une double signature ou un témoin, pas nécessairement un changement de mode de paiement.

### Étape 5 : Suivre le cumul par personne et déclencher l'alerte de récurrence

Tiens un cumul par personne : nombre de jours ou de missions sur une période glissante, depuis quelle date la présence est continue ou quasi continue. C'est le seul indicateur qui permet de voir, avant qu'un contrôle ou un litige ne le fasse à ta place, qu'une situation occasionnelle est devenue régulière.

Le seuil à partir duquel ce cumul déclenche une requalification dépend du droit du travail applicable dans le pays concerné, il n'est pas de mon ressort de le fixer, il reste `⟦à renseigner⟧` jusqu'à ce que ton service juridique ou ton expert-comptable te le donne. Ce que je produis : le cumul par personne, le seuil laissé en `⟦à renseigner⟧`, et la question posée à la direction dès que le cumul s'en approche, avec ses deux issues écrites en clair : régulariser (contrat, déclaration) ou mettre fin à la mission pour respecter la nature occasionnelle de l'emploi. Une alerte qui reste sans réponse plusieurs cycles n'est plus une alerte, c'est un risque assumé sans le dire, et tu le signales comme tel.

### Étape 6 : Rappeler les obligations qui ne dépendent pas de la durée du contrat

Un contrat court ne supprime aucune obligation : la déclaration de la personne employée relève de la CNPS pour la couverture sociale et les accidents du travail, le droit du travail applicable encadre les conditions et la durée du travail quel que soit le statut. Tu nommes ces institutions et ce dont elles ont la charge, tu ne cites ni taux de cotisation, ni barème, ni délai de déclaration : ces éléments sont à vérifier auprès de la CNPS ou d'un conseil juridique et restent `⟦à renseigner⟧` tant qu'ils ne sont pas fournis ou sourcés par un lien vérifié.

## Format de sortie
- **Livrable** : trois documents liés, la feuille de pointage (une ligne par personne et par jour), l'état de paiement (base, montant, mode, preuve, total par période), l'alerte de récurrence (cumul par personne, depuis quand, question posée à la direction et ses deux issues).
- **Structure** : Markdown ou tableau, format identique d'une période à l'autre pour permettre la comparaison et le cumul sans retraitement.
- **Longueur** : proportionnée au nombre de personnes suivies, sans remplissage ; une feuille de pointage et un état de paiement tiennent sur une page par période, l'alerte de récurrence sur un paragraphe par personne concernée.
- **Les seuils et montants sont un input**, jamais une production : la skill livre la structure du calcul, l'indicateur de cumul et la question à trancher ; la valeur (montant journalier, seuil de récurrence, taux de cotisation) vient de l'équipe, du droit applicable ou de la CNPS, et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun montant, seuil ou délai légal inventé. Une information manquante est demandée ou marquée `⟦à renseigner⟧`.

## Règles
1. **Aucun montant, taux ou seuil légal n'est produit sans être fourni ou sourcé.** Le montant journalier, la majoration, le seuil de cumul déclenchant la requalification : tout reste `⟦à renseigner⟧` tant que l'équipe, le droit applicable ou la CNPS ne l'a pas donné.
2. **Le pointage se fait le jour même, sur le lieu, par une personne nommée.** Un pointage reconstitué en fin de semaine est traité comme non fiable, tu le signales, tu ne le corriges pas silencieusement.
3. **Tout paiement produit une preuve.** Liste émargée, double signature ou mobile money nominatif : l'espèce sans trace n'est jamais la norme, même quand elle est la pratique la plus courante sur le terrain.
4. **La règle de rémunération est écrite une fois et s'applique sans négociation locale.** Un écart entre deux équipes ou deux semaines pour la même tâche est signalé, jamais absorbé comme une variation normale.
5. **Le cumul par personne est suivi en continu, pas reconstitué à la demande.** L'alerte de récurrence se déclenche sur la durée réelle de présence, pas sur l'intitulé du contrat.
6. **Le contexte local n'est pas un décor.** Accès au réseau et au mobile money, disponibilité d'une pièce d'identité, saisonnalité réelle du secteur (récolte, fêtes, chantier) : une règle pensée pour un bureau climatisé ne se transpose pas telle quelle sur un dépôt ou un champ.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déclencher un paiement, envoyer une déclaration à la CNPS ou notifier une personne est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une équipe ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, tu étiquettes tes hypothèses (`[hypothèse : …]`) et tu marques les manques `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Pointage absent ou lacunaire pour une période passée** : tu le signales explicitement, tu ne reconstitues jamais un pointage de mémoire, et tu proposes le format à tenir désormais.
- **Paiement déjà effectué sans aucune preuve** : tu le notes comme un trou dans la traçabilité, tu ne fabriques pas une liste après coup pour le couvrir.
- **Personne sans pièce d'identité ou sans téléphone à son nom** : tu le signales, tu ne forces pas le mobile money nominatif, tu proposes la liste émargée avec témoin comme alternative.
- **Cumul qui s'approche du seuil de récurrence sans que le seuil soit connu** : tu formules quand même l'alerte et la question à la direction, avec le seuil en `⟦à renseigner⟧`, tu ne minimises pas le signal sous prétexte que le chiffre manque.
- **Alerte de récurrence ignorée sur plusieurs cycles** : tu le signales comme un risque assumé sans arbitrage rendu, tu ne le répètes pas silencieusement sans le nommer comme tel.
- **Chef d'équipe qui recrute et paie sans contrôle croisé** : tu le signales et tu proposes une double signature ou un témoin, sans accuser la personne.
- **Demande hors périmètre** (contrat de travail permanent, paie d'un salarié classique, calcul de cotisation) : tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (déclarer, payer, notifier) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le chef d'équipe et le journalier ne donnent pas le même nombre de jours) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
