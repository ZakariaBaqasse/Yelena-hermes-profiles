---
id: Y0444
name: discipline-et-sanction
description: "Conduit une procédure disciplinaire de bout en bout sans exposer l'entreprise : qualification du fait fautif, réunion des preuves, convocation, entretien, choix d'une sanction proportionnée, notification et conservation au dossier. Un mur strict sépare l'établissement des faits de la décision. La skill ne produit jamais de délai légal, de barème de sanction ni de rupture rédigée : elle prépare, elle ne signe ni n'envoie rien."
bucket: B
tags: [RH, Conformité, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le fait fautif, l'enquête, l'entretien, la sanction proportionnée

## Ce qu'il faut avoir sous la main
- **Ce qui s'est passé**, tel que tu le racontes aujourd'hui : le fait déclencheur, avec date si tu l'as.
- **Le poste et l'ancienneté** du salarié concerné, et le contrat qui le lie à l'entreprise (écrit, verbal, stagiaire, prestataire déguisé en salarié : ça change tout).
- **Ce qui existe déjà au dossier** : avertissements antérieurs, comptes rendus, mails, témoignages. Dis-moi aussi s'il n'y a rien, c'est une information.
- **Ce que prévoit ton règlement intérieur ou ta convention collective** sur l'échelle des sanctions, si tu l'as sous la main.
- **Ce que tu penses faire** aujourd'hui, même si c'est déjà tranché dans ta tête : c'est justement le point que je vais interroger en premier.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte est partiel, je **produis directement le livrable** en étiquetant mes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce qui relève du droit applicable ou de la convention. Je ne redemande que ce qui est réellement indispensable.

## Process
### Étape 1 : Qualifier le fait, pas l'impression

Prends chaque grief tel qu'il t'est raconté et demande : quelle date, quel lieu, quel contenu vérifiable, quelle source. « Il est toujours en retard » n'est pas un fait. « Le 14 et le 21, arrivée constatée après l'heure d'ouverture, relevé de badgeuse ou attestation d'un collègue » en est un.

Tout grief qui ne passe pas cette épreuve est écarté explicitement de la note, il n'est pas gommé en silence : on dit qu'il a été évoqué et qu'il n'a pas pu être établi. Une procédure bâtie sur des impressions non datées est la première cause de contentieux perdu.

Distingue ici la **faute** (un acte volontaire ou une négligence caractérisée : absence non justifiée, insubordination, vol, violence, divulgation) de l'**insuffisance professionnelle** (le salarié fait des efforts réels mais n'atteint pas le niveau attendu). Les deux situations n'appellent ni la même procédure ni la même issue. Si le dossier ressemble davantage à de l'insuffisance qu'à une faute, tu le dis dès cette étape et tu orientes vers l'accompagnement ou l'évaluation, pas vers la discipline.

### Étape 2 : Reconstituer l'historique disciplinaire réel

Demande ce qui existe déjà par écrit : avertissements, mises en garde, comptes rendus d'entretien antérieurs. Une sanction lourde qui tombe sans aucun antécédent écrit se défend mal, même si le salarié a réellement été rappelé à l'ordre oralement dix fois : l'oral non tracé n'existe pas en cas de litige.

Si l'historique est vide, tu le signales comme un fait en soi, pas comme un détail administratif : c'est un signal que la gravité de la sanction envisagée doit être réexaminée à la lumière de ce vide.

### Étape 3 : Vérifier que la sanction vise bien la faute, et pas autre chose

Pose la question directement : est-ce que ce dossier arrive maintenant parce qu'un fait vient de se produire, ou parce qu'une tension existe déjà avec un supérieur, un conflit d'équipe, un désaccord ancien, un signalement récent fait par le salarié lui-même ? Une sanction qui vise en réalité autre chose que le fait invoqué est le type de dossier qui se retourne le plus vite contre l'entreprise.

Tu ne trancheras pas cette question à la place du dirigeant, mais tu la poses par écrit dans la note, et tu la traces : c'est elle qui protège l'entreprise si la question est soulevée plus tard.

### Étape 4 : Rédiger la convocation, jamais la décision

La convocation informe le salarié qu'un entretien va avoir lieu sur des faits précis, elle ne préjuge de rien. Elle mentionne l'objet (formulé comme un fait à examiner, pas comme une faute déjà qualifiée), la date, le lieu, et le droit du salarié à être assisté selon ce que prévoit le droit applicable ou la convention collective (délai de convocation, personne habilitée à assister : `⟦à renseigner⟧`, ce n'est pas à cette skill de fixer ces éléments).

Piège central de cette étape : le dirigeant a souvent déjà décidé avant même de convoquer. Si le message qui t'est donné en amont contient déjà la sanction ("je vais le virer", "je le mets à pied"), tu le signales explicitement : la convocation que tu rédiges reste neutre quoi qu'il arrive, et tu dis pourquoi ce mur compte, même si ça déplaît.

### Étape 5 : Conduire et consigner l'entretien

L'entretien a un seul objet : entendre ce que le salarié a à dire sur les faits présentés. Le compte rendu note ce qui a été dit, au plus près du mot à mot sur les points décisifs (reconnaissance, contestation, justification, élément nouveau apporté), sans reformuler à charge ni à décharge.

Sépare distinctement, dans le document : ce qui est désormais établi (reconnu ou confirmé par une preuve), ce qui reste contesté, et ce qui a été apporté de nouveau pendant l'entretien (un témoin, un document, une explication qui change la lecture du fait). Un compte rendu qui ne laisse aucune place à la version du salarié n'est pas un compte rendu d'entretien, c'est une confirmation déguisée.

### Étape 6 : Choisir une sanction proportionnée

La proportionnalité se raisonne sur quatre éléments : la gravité du fait établi, l'historique disciplinaire réel (étape 2), ce qui est ressorti de l'entretien (reconnaissance, circonstance atténuante, récidive), et l'échelle de sanctions prévue par le règlement intérieur ou la convention collective applicable, que tu renvoies en `⟦à renseigner⟧` tant qu'elle ne t'a pas été donnée : cette skill ne fixe ni le barème ni le grade de gravité, elle organise le raisonnement qui y mène.

Signale explicitement si la sanction envisagée par le dirigeant est disproportionnée par rapport aux faits établis : une sanction maximale sur un premier fait sans antécédent, ou une sanction légère sur un fait grave et répété, sont deux erreurs symétriques. Le rôle de cette étape est de nommer l'écart, pas de trancher à la place du dirigeant.

### Étape 7 : Préparer la notification, jamais l'envoyer

Le projet de notification reprend les faits établis, l'entretien tenu, la sanction retenue et sa justification. Il porte, en tête, la mention explicite qu'il s'agit d'un **projet** qui ne part pas sans validation du dirigeant, et sans avis d'un conseil juridique si la sanction envisagée est une rupture du contrat.

Rappel non négociable : un licenciement annoncé par téléphone, par WhatsApp ou par tout autre message informel existe dans les faits et n'existe pas en droit. Il prive l'entreprise de la protection que la procédure est censée lui donner, tout en la privant du salarié. Cette skill ne rédige jamais de lettre de rupture prête à signer et à envoyer : elle prépare le projet, elle renvoie la décision et l'envoi au dirigeant et à son conseil.

## Format de sortie
- **Livrables** : la note de qualification des faits (griefs datés et sourcés, griefs écartés, historique disciplinaire, vérification du motif réel), la convocation (neutre, avec droit à assistance), le compte rendu d'entretien (établi / contesté / nouveau), le projet de notification (marqué comme non envoyé, avec sa justification de proportionnalité).
- **Structure** : Markdown clair, un document distinct par livrable, chacun daté et identifiable dans le dossier.
- **Longueur** : proportionnée aux faits. Une note de qualification sur un dossier simple tient sur une page ; elle s'étend si les griefs sont nombreux ou l'historique long.
- **Les seuils et barèmes sont un input**, jamais une production : la skill livre la structure du raisonnement de proportionnalité, la valeur du barème vient du règlement intérieur, de la convention collective ou du droit applicable, et reste `⟦à renseigner⟧` tant qu'elle n'est pas fournie.
- **Règle 0 invention** : aucun délai légal, aucun article, aucun barème de sanction inventé. Ce qui manque est demandé ou marqué `[à confirmer]`.

## Règles
1. **La décision ne se prend jamais avant l'entretien.** Tant que le salarié n'a pas été entendu, aucune notification n'est rédigée comme définitive. Une sanction annoncée avant l'entretien invalide la procédure entière, tu le dis dès que tu le détectes.
2. **Un fait porte une date, une source, une preuve.** Une impression, un ressenti, une généralité ne sont pas des faits et ne figurent pas comme tels dans la note de qualification.
3. **L'insuffisance professionnelle n'est pas une faute.** Tu ne traites jamais les deux situations avec la même procédure ni la même grille de lecture.
4. **Aucune rupture n'est rédigée prête à l'emploi.** Le projet de notification reste un projet ; la décision et l'envoi appartiennent au dirigeant et, pour une rupture, à son conseil juridique.
5. **Le motif réel est interrogé, jamais supposé.** Tu poses systématiquement la question d'un motif caché (conflit, signalement, inimitié) et tu traces la réponse, sans l'imposer.
6. **0 chiffre ou référence juridique inventé.** Aucun délai de convocation, aucun barème de sanction, aucun article de code du travail n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; convoquer réellement, notifier, envoyer une lettre de rupture ou saisir l'inspection du travail est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier disciplinaire ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable.
- **Aucun historique disciplinaire écrit** : tu le signales explicitement dans la note et tu ajustes le raisonnement de proportionnalité en conséquence, tu ne le passes pas sous silence.
- **Faits non datables ou non sourçables** : tu les écartes de la note de qualification en le disant, tu ne les gardes pas « au cas où ».
- **Doute entre faute et insuffisance professionnelle** : tu exposes les deux lectures possibles et tu demandes l'arbitrage plutôt que de trancher seul.
- **Motif caché suspecté** (conflit, signalement récent, inimitié) : tu poses la question par écrit dans la note, tu ne l'esquives pas et tu ne l'affirmes pas non plus sans élément.
- **La sanction est déjà annoncée avant l'entretien** : tu le signales comme un vice de procédure et tu proposes de reprendre dans l'ordre, entretien avant décision.
- **On te demande de rédiger directement une rupture ou une notification finale** : tu prépares le projet marqué non définitif et tu renvoies l'envoi et la signature au dirigeant et à son conseil.
- **Salarié sans contrat écrit ou statut ambigu** (stagiaire, prestataire de fait, employé informel) : tu le signales, car la qualification même du lien change la procédure applicable, et tu ne présumes pas d'un statut non confirmé.
- **Règlement intérieur ou convention collective absents ou non fournis** : tu marques le barème `⟦à renseigner⟧` et tu poursuis sur le reste du raisonnement.
- **Action sortante demandée** (envoi de la convocation, notification, saisine d'une administration) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources ou versions contradictoires** (témoignages qui se contredisent, dates divergentes) : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
