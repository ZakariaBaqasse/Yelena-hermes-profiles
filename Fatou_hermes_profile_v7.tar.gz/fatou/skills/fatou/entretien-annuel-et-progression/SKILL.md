---
id: Y0446
name: entretien-annuel-et-progression
description: "Installe et conduit l'entretien annuel dans une entreprise qui n'en a jamais fait : attentes du poste reformulées en résultats observables, préparation du responsable autant que du salarié, conduite de l'échange, compte rendu qui distingue ce qui est décidé de ce qui est demandé à la direction, et suite concrète pour que le second entretien ne soit pas plus dur que le premier."
bucket: B
tags: [RH, Management, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le premier entretien annuel d'une entreprise qui n'en a jamais fait

## Ce qu'il faut avoir sous la main
- **Le poste et la personne concernée**, et surtout ce qu'elle fait réellement au quotidien (pas seulement son intitulé de poste).
- **Qui conduit l'entretien** : le fondateur, un responsable de service, quelqu'un qui le fait pour la première fois.
- **Ce qui a été dit, promis ou reproché en cours d'année** et jamais mis par écrit, formation évoquée, retard signalé, incident client.
- **Un support existant** s'il y en a un, même un vieux formulaire copié d'ailleurs.
- **La date visée et le mode** : en présentiel, par visio, dans quel délai avant que ce soit trop tard pour être utile.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` tout seuil, montant ou décision qui appartient à l'entreprise. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Choisir ce qu'on évalue, pas qui on juge

Premier piège du métier, et le plus fréquent : évaluer la personne au lieu du travail. « Manque de motivation », « bon esprit », « pas assez impliqué » : ces formules ne se contestent pas, ne s'améliorent pas et ne se prouvent pas. Elles ferment la conversation au lieu de l'ouvrir, et elles ne survivent jamais à un désaccord.

Ta première tâche est de forcer la reformulation. Pars de trois à cinq attentes réelles du poste, celles que la personne fait vraiment, pas un référentiel générique de compétences transverses importé d'ailleurs. Pour chaque attente, écris-la en résultat observable : pas « manque de rigueur dans le suivi des stocks » mais « les ruptures de stock n'ont pas été remontées dans les 24 heures, sur trois épisodes identifiés entre telle et telle période ». Si le responsable ne peut pas citer un fait daté pour appuyer un jugement, le jugement ne rentre pas dans le support : il devient une question à poser en entretien, pas une conclusion à annoncer.

### Étape 2 : Repérer ce qui aurait dû être dit avant

Un grief découvert en fin d'année aurait dû être formulé en mars. L'entretien annuel n'est pas là pour remplacer un management qui s'est tu pendant des mois : c'est le piège de l'entretien qui absorbe tout ce qui n'a jamais été dit.

Pour chaque point que le responsable veut aborder, pose la question : est-ce que ce fait date de plus de quelques mois et n'a jamais été formulé à la personne ? Si oui, signale-le explicitement dans la note de préparation comme une défaillance de suivi en cours d'année, distincte du bilan de la personne. Le responsable doit pouvoir dire « je n'ai pas été assez régulier là-dessus, ça change à partir de maintenant » plutôt que de faire retomber sur l'entretien la charge d'un problème qui traîne depuis longtemps.

### Étape 3 : Préparer le responsable, pas seulement le salarié

L'entretien annuel se prépare des deux côtés, et c'est presque toujours le côté responsable qu'on oublie. La note de préparation contient : les faits précis à citer, avec dates et situations, jamais des impressions ; les questions ouvertes à poser plutôt que les constats à annoncer ; et surtout ce que le responsable **ne peut pas promettre** tant que la direction n'a pas tranché, augmentation, promotion, changement de poste, formation financée.

Le rapport hiérarchique porte souvent, dans ce contexte, une autorité qui inhibe la contradiction : dire non à son responsable ne se fait pas facilement. Ce n'est pas une raison pour parler à sa place, c'est une raison de préparer des questions qui laissent la place au silence et à la réponse différée plutôt que des questions fermées qui n'attendent qu'un oui.

Signale aussi le canal le plus simple pour transmettre le support avant l'entretien, WhatsApp, papier remis en main, peu importe : ce qui compte est que la personne l'ait vraiment reçu et ait eu le temps de le lire, pas seulement qu'un mail soit parti.

### Étape 4 : Conduire l'échange en séparant constat, ressenti et décision

Structure l'entretien en trois temps distincts, pour éviter que tout se mélange dans le même paragraphe : d'abord les faits sur chaque attente (ce qui s'est passé, avec des exemples concrets), puis ce qui a aidé ou gêné dans l'exécution (moyens, charge, relations avec d'autres services), enfin ce qui s'en suit (décision ou demande).

Prévois explicitement un temps de relecture par le salarié avant que le compte rendu soit considéré comme définitif, et la possibilité d'y ajouter un désaccord écrit. Dans beaucoup de contextes, le silence du salarié devant son responsable est pris pour un accord alors qu'il ne l'est pas : la seule façon de le vérifier est de laisser un espace où le silence n'est pas la seule option disponible.

### Étape 5 : Écrire le compte rendu qui distingue décidé et demandé

Deuxième piège majeur : l'entretien qui promet. Une augmentation évoquée à voix haute, une promotion suggérée, une formation annoncée en passant deviennent, dans la tête du salarié, un engagement pris ; et disparaissent, dans celle de l'entreprise, dès que la porte se ferme. C'est la source la plus fréquente de rupture de confiance après un premier entretien annuel.

Le compte rendu tient donc trois colonnes strictement séparées, jamais mélangées dans la même phrase :
- **Décidé** : ce qui est acté immédiatement, par qui, à partir de quand.
- **Demandé, remonté à la direction** : ce qui suppose un arbitrage extérieur à l'entretien, avec un délai de réponse `⟦à renseigner⟧` fixé par l'entreprise, jamais estimé par toi.
- **Désaccord conservé** : la formulation du salarié gardée telle qu'il l'a dite, pas résumée ni adoucie par le responsable.

Rien dans la colonne « décidé » ne doit reposer sur une phrase orale du type « on verra » : si ce n'est pas tranché, ça va dans « demandé ».

### Étape 6 : Verrouiller la suite

Un compte rendu qui ne débouche sur rien enseigne, plus efficacement que n'importe quel discours, que l'exercice est décoratif : le second entretien annuel devient alors plus difficile à mener que le premier, parce que la confiance dans le rituel est déjà abîmée. Fixe donc une date de vérification intermédiaire, pas d'attente jusqu'aux douze prochains mois, et nomme qui doit relancer si la direction n'a pas répondu dans le délai fixé.

Rappelle enfin, dans le compte rendu lui-même, que rémunération, promotion et cotisations liées à la progression de carrière relèvent de décisions de l'entreprise et, le cas échéant, de ses obligations déclaratives auprès de la CNPS : ce document ne les tranche pas, il les fait remonter à qui doit les trancher.

## Format de sortie
- **Livrable 1, le support d'entretien** : trois à cinq attentes du poste formulées en résultats, ce qui s'est passé sur chacune avec des faits datés, ce qui a aidé, ce qui a gêné.
- **Livrable 2, la note de préparation du responsable** : les faits précis à citer, les questions ouvertes à poser, ce qu'il ne peut pas promettre tant que la direction n'a pas décidé.
- **Livrable 3, le compte rendu** : constats partagés, points de désaccord conservés tels quels, décisions prises avec leur date d'effet, demandes remontées à la direction avec un délai de réponse `⟦à renseigner⟧`, espace de signature des deux parties.
- **Structure** : Markdown clair, un document par livrable, tableaux quand c'est plus lisible qu'une liste.
- **Longueur** : proportionnée au poste et à l'ancienneté de la relation de travail, sans remplissage. Un support d'entretien tient sur une à deux pages, pas neuf compétences notées de un à cinq.
- **Règle 0 invention** : aucun montant, taux, seuil ou délai n'est produit par la skill. Tout ce qui relève d'une décision de l'entreprise reste `⟦à renseigner⟧` jusqu'à ce qu'elle soit donnée.

## Règles
1. **On évalue le travail, pas la personne.** Toute formulation qui juge un trait de caractère plutôt qu'un fait observable est reformulée ou retirée avant d'entrer dans le support.
2. **0 promesse déguisée.** Rien dans la colonne « décidé » du compte rendu ne repose sur une intention orale. Ce qui n'est pas tranché par la direction va dans « demandé », jamais présenté comme acquis.
3. **Le grief ancien se nomme comme tel.** Tout point qui date de plus de quelques mois et n'a jamais été formulé est signalé comme défaillance de suivi en cours d'année, pas comme faute annuelle de la personne.
4. **Le silence n'est pas un accord.** Le compte rendu prévoit un temps de relecture réel et la possibilité écrite d'un désaccord ; l'absence d'objection à l'oral ne vaut pas validation.
5. **0 chiffre inventé.** Aucun taux d'augmentation, aucun montant de prime, aucun barème de notation n'est produit sans être fourni par l'entreprise : `⟦à renseigner⟧` sinon.
6. **Sans suite, l'entretien n'a servi à rien.** Toute décision ou demande porte une échéance et un responsable de relance ; un compte rendu sans suite fixée n'est pas un livrable terminé.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; envoyer le compte rendu, l'officialiser, remonter une demande à la direction ou déclencher une évolution de rémunération est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends sur un salarié ou une équipe ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun historique de suivi en cours d'année** : tu produis le support à partir des attentes du poste seules, tu le signales, et tu recommandes d'installer un point intermédiaire avant le prochain entretien plutôt que d'attendre un an de plus.
- **Un fait annoncé mais non détaillé** (« il y a eu un problème avec un client », sans précision) : tu le signales avant de continuer et tu ne fabriques pas la situation à sa place.
- **Promesse orale déjà faite avant l'entretien** : tu la fais apparaître dans le compte rendu comme demande à confirmer par la direction, jamais comme décision actée, même si le salarié la considère déjà comme acquise.
- **Poste sans référentiel écrit** (pas de fiche de poste, tâches jamais formalisées) : tu construis les trois à cinq attentes à partir de ce que la personne fait réellement au quotidien, en le disant explicitement.
- **Désaccord persistant après relecture** : tu conserves les deux versions dans le compte rendu, tu ne tranches pas à la place des parties, et tu recommandes un temps de médiation si l'écart porte sur un fait vérifiable.
- **Demande hors périmètre** (grille salariale sectorielle, barème de progression de carrière, contentieux disciplinaire) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence ou le conseil qui convient.
- **Action sortante demandée** (envoi du compte rendu signé, annonce d'une décision à l'équipe) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** entre le responsable et le salarié sur un même fait : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
