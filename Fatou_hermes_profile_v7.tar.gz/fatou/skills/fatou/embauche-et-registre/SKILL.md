---
id: Y0668
name: embauche-et-registre
description: "Construit une embauche solide du premier jour au dossier complet : qualification réelle du poste, choix du type de contrat qui correspond à cette réalité, composition du dossier du salarié, déclarations et inscriptions auprès des institutions compétentes, tenue du registre de l'employeur et cadrage de la période d'essai, sans jamais citer un délai, un plafond ou un article de loi non fourni."
bucket: B
tags: [RH, Conformité, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Embaucher quelqu'un pour de bon, du premier jour au dossier complet

## Ce qu'il faut avoir sous la main
- **Le poste réel** : ce que la personne va faire au quotidien, ses horaires, son lieu de travail, qui lui donne des consignes.
- **Le lien envisagé** par l'entreprise (contrat à durée indéterminée, déterminée, stage, prestation) et pourquoi ce choix.
- **La date réelle de début** : si la personne travaille déjà depuis un moment sans contrat signé, dis-le sans détour, c'est une situation que je traite normalement.
- **Ce qui existe déjà** comme pièces (pièce d'identité, CV, diplôme, certificat médical, numéro de compte ou de mobile money pour le paiement) et ce qui manque encore.
- **Le secteur d'activité** de l'entreprise, et si une convention collective est déjà identifiée.
- **Le pays et la ville** où se fait l'embauche.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `⟦à renseigner⟧` : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 1 : Qualifier la réalité du poste avant tout papier
Avant de nommer un type de contrat, décris ce que la personne fait réellement : qui fixe ses horaires, qui fournit ses outils de travail, si elle travaille pour cette seule entreprise ou pour plusieurs, si elle peut refuser une tâche ou se faire remplacer librement. Ce sont les indices de la subordination, et c'est elle, pas l'intitulé du document, qui détermine la nature du lien.

Si la personne travaille déjà depuis un moment sans contrat écrit, note la date réelle de début. C'est cette date, et non celle de la signature à venir, qui doit apparaître dans le dossier : régulariser une situation ne consiste pas à faire comme si elle commençait aujourd'hui.

### Étape 2 : Choisir le type de contrat qui correspond, et signaler l'écart s'il y en a un
Confronte ce que l'entreprise souhaite (souvent : un contrat court, un stage, une prestation facturée, pour la souplesse ou le coût) à ce que l'étape 1 a révélé. Trois écarts reviennent souvent et doivent être nommés explicitement quand tu les rencontres :
- un poste permanent occupé sous une succession de contrats à durée déterminée renouvelés,
- un stage qui occupe en réalité un poste de production au même titre que les salariés,
- une prestation facturée par quelqu'un qui vient tous les jours, aux horaires de la maison, sous la même subordination qu'un salarié.

Dans les trois cas, dis clairement que la qualification affichée et la réalité décrite ne se correspondent pas, et que c'est ce risque de requalification, pas la forme du document, que l'entreprise porte. Une saisonnalité réelle de l'activité (récolte, fêtes, pic commercial) peut justifier un contrat à durée déterminée légitime : encore faut-il que la durée corresponde à la saison, pas au confort de renouveler sans fin.

Nomme aussi la convention collective applicable si le secteur est connu, sans jamais deviner son contenu : elle se lit, elle ne se déduit pas du nom de l'entreprise ni de son secteur supposé. Tant qu'elle n'est pas fournie ou identifiée avec certitude, marque-la `⟦à renseigner⟧`.

### Étape 3 : Composer le dossier du salarié, une place unique
Liste les pièces attendues pour ce type de contrat et cette situation : pièce d'identité, CV, diplôme ou attestation, certificat médical d'aptitude, photos, coordonnées de paiement (compte bancaire ou numéro mobile money), contrat signé, avenants éventuels. Pour chacune, indique son statut : obtenue, demandée, manquante, et qui doit la fournir.

Signale explicitement quand des pièces circulent par WhatsApp ou par courriel personnel sans jamais atterrir dans un dossier unique : une photo de carte d'identité prise au téléphone et jamais reclassée n'est pas un dossier, c'est une trace qui disparaîtra le jour où on en aura besoin. Le dossier vit à un seul endroit, identique pour chaque salarié, pas dans la messagerie de la personne qui a recruté.

### Étape 4 : Cartographier les déclarations et inscriptions dues
Pour chaque institution concernée, dis ce dont elle a la charge, sans jamais citer un taux, un plafond ou un délai chiffré :
- la **caisse de sécurité sociale (CNPS)** : immatriculation de l'employeur s'il ne l'est pas déjà, immatriculation du salarié, déclaration de l'embauche, cotisations dues sur le salaire ;
- l'**administration fiscale (DGI)** : obligations liées à la paie et à l'emploi de personnel, à vérifier avec le conseil de l'entreprise ;
- le **service public de l'emploi ou l'inspection du travail** (le nom exact et la procédure locale sont à confirmer auprès de la source officielle) : déclaration d'embauche, tenue du registre de l'employeur, contrôle de conformité du contrat.

Pour chaque ligne : ce qui est exigé, l'échéance en `⟦à renseigner⟧`, et le justificatif à conserver une fois la démarche faite (accusé, récépissé, attestation). N'oublie pas la visite médicale d'embauche si elle est requise : elle suppose un déplacement physique du salarié, à anticiper dans les délais quand l'entreprise et le centre de santé ne sont pas au même endroit, en particulier dans une ville aux distances et embouteillages importants.

### Étape 5 : Cadrer la période d'essai, sans en faire un espace sans règles
La période d'essai n'est pas une zone de non-droit où tout est permis parce que « c'est encore l'essai ». Elle a une durée, une logique de renouvellement éventuel, et des conditions de rupture qui lui sont propres : ce qui la distingue d'un contrat en cours n'est pas l'absence de procédure, mais sa légèreté relative.

Tu dis ce que tu sais de cette logique, et tu renvoies la durée exacte, la possibilité de renouvellement et les modalités de rupture à la convention collective applicable et au conseil de l'entreprise, marquées `⟦à renseigner⟧`. Tu ne complètes jamais ces valeurs par un chiffre qui te semble raisonnable.

### Étape 6 : Tenir le registre de l'employeur et clore le dossier
Le registre de l'employeur est l'endroit où chaque embauche doit apparaître, dans l'ordre, avec les informations qui permettent de la retrouver en cas de contrôle. Vérifie que la fiche produite à cette étape peut alimenter ce registre sans retraitement : mêmes intitulés, mêmes dates, même référence du dossier.

Termine par un état des lieux en trois blocs : ce qui est complet, ce qui est en cours, ce qui est bloqué et pourquoi. Un dossier « complet à 80 % » n'existe pas dans ce livrable : chaque pièce et chaque déclaration a un statut binaire, faite ou pas faite, avec sa date si elle est faite.

## Format de sortie
Trois documents, produits ensemble :

- **Le dossier d'embauche** : tableau des pièces attendues, avec pour chacune son statut (obtenue, demandée, manquante), qui la fournit, et la date d'obtention si elle existe.
- **La fiche de formalités** : tableau par déclaration ou inscription, l'institution concernée, ce qu'elle exige, l'échéance `⟦à renseigner⟧`, et le justificatif à conserver une fois la démarche accomplie.
- **La note de qualification du poste** : les questions posées sur la réalité du poste, les réponses obtenues, le type de contrat qui en découle, et l'écart signalé en une phrase nette quand ce que l'entreprise souhaite ne correspond pas à ce qu'elle décrit.

Structure Markdown, answer-first : la note de qualification et son verdict de type de contrat en tête, le détail des pièces et des formalités ensuite. Longueur proportionnée, sans remplissage : ces trois documents tiennent en général sur une à deux pages chacun.

**Règle 0 invention** : aucune échéance, aucun taux de cotisation, aucun plafond, aucune durée de période d'essai, aucun article de convention ou de code n'est produit sans être fourni ou sourcé. `⟦à renseigner⟧` sinon, à chaque occurrence, pas seulement la première fois.

## Règles
1. **La subordination fait la qualification, pas le titre du document.** Un contrat intitulé « prestation » qui décrit en réalité un lien salarié doit être signalé comme tel, même si l'entreprise préfère l'autre lecture.
2. **0 chiffre inventé.** Aucun délai de déclaration, aucun taux de cotisation, aucune durée de préavis ou de période d'essai n'est produit sans être fourni ou sourcé. Un ordre de grandeur « habituel » non sourcé reste une invention.
3. **La convention collective se lit, elle ne se devine pas.** Tant qu'elle n'a pas été identifiée avec certitude et fournie, son contenu reste `⟦à renseigner⟧`, y compris pour la période d'essai.
4. **Une embauche déjà en cours sans papier n'est pas cachée, elle est régularisée.** La date réelle de début figure dans le dossier, pas une date de convenance qui ferait démarrer l'histoire au jour de la signature.
5. **Le dossier vit à un seul endroit.** Une pièce reçue par WhatsApp, courriel ou messagerie personnelle n'est considérée « obtenue » qu'une fois reclassée dans le dossier unique, pas avant.
6. **Un statut de pièce ou de démarche est binaire.** Fait ou pas fait, avec sa date s'il est fait. Pas de statut intermédiaire flou qui masque un retard.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `⟦à renseigner⟧`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; déposer une déclaration auprès d'une institution, signer un contrat ou verser un premier salaire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier d'embauche ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Salarié déjà au travail depuis plusieurs mois sans contrat** : tu produis le dossier avec la date réelle de début, tu signales le retard en une phrase, sans dramatiser ni minimiser, et tu proposes la marche de régularisation comme un cas normal du process.
- **Type de contrat souhaité par l'entreprise en écart avec la réalité décrite** : tu nommes l'écart explicitement dans la note de qualification, tu ne valides pas le choix de l'entreprise par confort.
- **Convention collective inconnue ou non identifiée** : tu marques chaque valeur qui en dépend `⟦à renseigner⟧`, tu ne devines pas à partir du secteur supposé.
- **Institution ou procédure locale incertaine** (nom exact, guichet, formulaire) : tu le dis explicitement plutôt que d'inventer un intitulé, et tu renvoies à la vérification auprès de la source officielle ou du conseil de l'entreprise.
- **Pièce annoncée mais non jointe** (« voici la pièce d'identité », rien n'est joint) : tu le signales avant de continuer, tu ne fais pas comme si tu l'avais vue.
- **Poste saisonnier réel** : tu le distingues du contrat court renouvelé par commodité, en demandant ce qui justifie la durée annoncée par rapport à la saison décrite.
- **Entreprise elle-même non immatriculée ou informelle** : tu le signales comme un préalable à traiter avant l'embauche elle-même, tu ne construis pas un dossier de salarié sur un employeur qui n'a pas d'existence formelle.
- **Demande hors périmètre** (licenciement, contentieux prud'homal, calcul de paie) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (dépôt de déclaration, envoi de documents à une institution, signature) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions de la convention applicable, deux dates de début rapportées) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
