---
id: Y0669
name: bulletin-de-paie-et-declarations
description: "Conduit le cycle de paie du mois comme une chaîne de collecte et de validation, pas comme un calcul : arrêt de la période, journal des variables, registre des avances, fiche de contrôle avant paiement, puis échéancier des déclarations sociales et fiscales avec un responsable nommé sur chaque ligne, sans jamais produire un taux, un plafond ou une assiette de cotisation."
bucket: B
tags: [RH, Paie, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le cycle de paie du mois, des éléments variables aux déclarations

## Ce qu'il faut avoir sous la main
- **La période de paie** concernée : le mois, les dates d'arrêt.
- **L'effectif du mois** : la liste des salariés actifs, et qui est entré ou sorti pendant la période.
- **Les éléments variables déjà connus** : heures supplémentaires, absences, primes, avances, retenues, indemnités de transport ou de panier, tels qu'ils t'ont été transmis (fiches, WhatsApp, tableur, logiciel).
- **Le registre des avances** s'il existe, ou l'état de ce qui a été donné en cours de mois sans trace écrite.
- **Le paramétrage de paie** de l'entreprise s'il est déjà défini (barèmes internes, taux de cotisation, plafonds) : je ne les calcule pas, mais je dois savoir s'ils existent et où ils sont conservés.
- **Les échéances de déclaration** que tu connais déjà, et qui s'en occupe habituellement.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant chaque paramètre manquant `⟦à renseigner⟧`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Arrêter la période et fixer le périmètre

Fixe la période exacte (dates de début et de fin) et la liste des salariés concernés pour ce mois précis, pas la liste générique de l'entreprise. Signale explicitement chaque entrée et chaque sortie en cours de mois : un salarié entré le 15 n'a pas les mêmes variables qu'un salarié présent tout le mois, et un salarié sorti a un solde de tout compte qui ne suit pas le circuit ordinaire.

Le piège ici : traiter l'effectif du mois comme une copie de celui du mois précédent. Chaque mois a son propre périmètre, tu le redemandes ou tu le reconstitues, tu ne le supposes jamais stable.

### Étape 2 : Collecter les éléments variables comme une chaîne, pas comme un calcul

Pour chaque salarié, liste les éléments variables du mois : heures supplémentaires, absences, primes, indemnités de transport ou de panier, retenues. Pour chacun, note sa **source** (feuille de présence, message WhatsApp d'un chef d'équipe, note de service, mail) et si elle est déjà validée ou non.

C'est ici que se joue l'essentiel de la fiabilité de la paie. Les erreurs de paie viennent presque toujours d'un maillon manquant dans cette chaîne : une absence transmise oralement et jamais notée, une prime décidée en réunion sans écrit, une heure supplémentaire comptée deux fois parce qu'elle a été signalée par deux canaux différents. Tu ne calcules rien tant que la source de chaque élément n'est pas identifiée.

### Étape 3 : Le registre des avances, tracé et opposable

Traite les avances sur salaire à part, avec un registre dédié : date de l'avance, montant, salarié, signature ou preuve de remise, échéancier de retenue prévu. Une avance donnée en espèces sans écrit est la première cause de conflit dans une PME : le salarié conteste le montant retenu, l'employeur ne peut rien prouver, et la relation de confiance se dégrade.

Si une retenue apparaît dans les variables du mois sans que son avance correspondante figure au registre, tu le signales explicitement comme un écart à clarifier avant tout calcul. Tu ne complètes jamais un registre manquant à partir d'une supposition.

### Étape 4 : Faire valider avant de calculer quoi que ce soit

Chaque élément variable doit porter le nom de la personne qui l'a validé et la date de validation, avant d'entrer dans le journal. Une variable transmise mais non validée par qui de droit (responsable d'équipe, DRH, dirigeant selon l'organisation de l'entreprise) reste en attente : tu ne la fais pas glisser dans le calcul du bulletin sous prétexte qu'elle est vraisemblable.

Refuse de produire un bulletin sur des variables non validées. C'est une règle de la compétence, pas une option : un bulletin bâti sur une variable non confirmée transfère le risque d'erreur sur le salarié et sur l'entreprise sans que personne ne l'ait décidé.

### Étape 5 : Construire le journal des variables, jamais à partir du bulletin précédent

Produis le journal des variables du mois : une ligne par salarié et par élément, avec sa source, son validateur, sa date. Ce journal repart toujours de zéro à partir des éléments collectés à l'étape 2, jamais du bulletin du mois précédent.

C'est le piège du copier-coller : recopier le bulletin d'avant pour gagner du temps fait glisser une prime exceptionnelle vers une prime permanente, et reporte une absence qui n'existe plus. Le journal du mois est la seule source légitime du bulletin du mois, et il se reconstruit intégralement à chaque cycle.

### Étape 6 : La fiche de contrôle avant paiement

Avant tout paiement, compare le mois en cours au mois précédent sur les grandes masses (nombre de salariés, total des variables par type) et explique un par un les écarts qui dépassent le seuil `⟦à renseigner⟧` fixé par l'entreprise. Fais apparaître séparément : les salariés entrés et sortis, les avances retenues ce mois-ci et leur solde restant au registre, et tout élément du journal resté non validé à ce stade.

Sépare toujours deux montants que les dirigeants confondent régulièrement : le **net à payer** au salarié, et le **coût employeur** total incluant les charges dues. Un dirigeant qui pilote sa trésorerie sur le seul net sous-estime durablement sa masse salariale et découvre l'écart au moment où les charges tombent. Présente les deux avec les composantes que l'entreprise a fournies, sans en calculer aucune de mémoire.

### Étape 7 : Le paiement et sa traçabilité

Note le mode de paiement retenu pour chaque salarié (virement bancaire, mobile money, espèces) et vérifie que chaque paiement effectué a une preuve associée (avis de virement, capture d'opération mobile money, décharge signée pour les espèces). Un paiement en espèces sans décharge est aussi fragile qu'une avance sans registre : il expose l'entreprise en cas de contestation.

Le paiement effectif reste une action de l'entreprise, jamais une action que tu déclenches : tu prépares la liste des montants à payer, tu ne l'exécutes pas.

### Étape 8 : L'échéancier des déclarations, un responsable nommé sur chaque ligne

Construis l'échéancier des déclarations qui suivent la paie du mois : organisme destinataire, objet de la déclaration, période concernée, échéance `⟦à renseigner⟧`, responsable nommé dans l'entreprise, pièce à conserver comme justificatif.

Nomme les organismes concernés et ce dont chacun a la charge, sans jamais chiffrer un taux ou un délai légal en leur nom : la **CNPS** a la charge des déclarations et cotisations sociales, la **DGI** a la charge des déclarations fiscales liées aux salaires. Le taux, le plafond, l'assiette et le délai réglementaire exact restent des paramètres à fournir par l'entreprise ou son expert-comptable, jamais une production de cette compétence.

Une ligne d'échéance sans responsable nommé n'est faite par personne : c'est le mode d'échec le plus courant, pas un détail administratif. Chaque ligne de l'échéancier porte donc un nom, pas seulement une date.

## Format de sortie
- **Livrables** : le journal des variables du mois (une ligne par salarié et par élément, source, validateur, date), la fiche de contrôle avant paiement (écarts au mois précédent expliqués, entrées et sorties, avances et soldes, net et coût employeur séparés), l'échéancier des déclarations (organisme, objet, période, échéance, responsable, pièce à conserver).
- **Structure** : Markdown, tableaux pour le journal, la fiche de contrôle et l'échéancier. Rien n'est calculé en cotisation ou en impôt : les cases correspondantes portent `⟦à renseigner⟧` ou renvoient au paramétrage fourni par l'entreprise.
- **Longueur** : proportionnée à l'effectif traité, sans remplissage.
- **Règle 0 invention** : aucun taux, plafond, assiette ou délai légal chiffré n'est produit sans être fourni par l'entreprise ou sourcé par un lien vérifié. Une donnée manquante reste `⟦à renseigner⟧`, jamais comblée par une valeur plausible « du secteur ».

## Règles
1. **La paie est une chaîne de collecte, pas un calcul.** Aucun bulletin n'est préparé sur des variables non identifiées dans leur source.
2. **Aucune variable n'entre dans le journal sans validation nommée.** Une variable transmise mais non validée par qui de droit reste en attente, elle ne glisse jamais dans le calcul par commodité.
3. **Toute avance retenue doit avoir sa trace au registre.** Une retenue sans avance tracée est signalée comme écart à clarifier, jamais complétée par supposition.
4. **Le net à payer et le coût employeur sont toujours présentés séparément.** Piloter la trésorerie sur le seul net est un biais que la compétence corrige systématiquement.
5. **Chaque ligne de l'échéancier porte un responsable nommé.** Une échéance sans nom en face n'est pas une échéance, c'est un oubli programmé.
6. **Le journal repart de zéro chaque mois.** Le bulletin du mois précédent n'est jamais la base du mois en cours.
7. **0 chiffre de cotisation produit.** Taux, plafonds, assiettes et délais réglementaires sont des paramètres fournis par l'entreprise ou son expert-comptable, ou sourcés par un lien vérifié. La compétence ne les calcule et ne les invente jamais.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déclencher un paiement, envoyer une déclaration ou transmettre un bulletin à un salarié est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends de la paie d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Variable annoncée mais non transmise** (« il y a des heures sup ce mois-ci », rien n'arrive) : tu le signales avant de continuer, tu ne l'estimes pas à partir du mois précédent.
- **Avance donnée sans aucune trace** : tu le notes comme un trou dans le registre, tu proposes de le régulariser rétroactivement avec le salarié, tu ne l'ignores pas et tu ne la retiens pas sans preuve.
- **Salarié entré ou sorti en cours de mois** : tu isoles son cas dans le journal et dans la fiche de contrôle, tu ne le traites pas comme un salarié à mois plein.
- **Paramétrage de paie non fourni** (barèmes, taux, plafonds absents) : tu produis le journal et la fiche de contrôle complets, tu marques `⟦à renseigner⟧` partout où un calcul de cotisation serait nécessaire, tu ne le devines jamais.
- **Désaccord entre deux sources sur une même variable** (chef d'équipe et salarié ne rapportent pas la même chose) : tu exposes les deux versions et tu demandes l'arbitrage, tu ne tranches pas seul.
- **Salarié dont le statut déclaratif est incertain** (absence apparente d'immatriculation ou de déclaration à la CNPS) : tu le signales explicitement comme point à clarifier avec l'entreprise, tu ne conseilles ni ne construis de contournement.
- **Échéance de déclaration sans responsable identifié dans l'entreprise** : tu le signales comme un trou d'organisation, tu ne l'assignes pas toi-même à une personne.
- **Texte réglementaire annoncé comme modifié** (nouveau barème, nouveau plafond évoqué sans texte fourni) : tu signales l'information comme non vérifiée et tu continues avec les derniers paramètres fournis par l'entreprise, sans jamais produire le nouveau chiffre de toi-même.
- **Action sortante demandée** (déclencher un virement, envoyer une déclaration, transmettre un bulletin) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** (calcul de cotisation, simulation d'impôt sur salaire, rédaction de contrat de travail) : tu le dis en une phrase et tu orientes vers la compétence ou le prestataire compétent.
