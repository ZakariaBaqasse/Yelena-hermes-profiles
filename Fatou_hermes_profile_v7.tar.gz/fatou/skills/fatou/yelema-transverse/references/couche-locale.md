# Couche locale : Fatou · Ressources humaines et paie

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-FATOU-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci/
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Socle commun. Pour elle, les interlocuteurs utiles sont la CNPS, la DGI et l'inspection du travail. ✅ 17/09, balayage de la flotte : LA PIÈCE EXISTE DÉJÀ. memory/reference/gouvernement-2026.md chez LOKOLI donne la composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 » (1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués), relevée le 10/09 sur le portail officiel, avec la réserve : rouvrir la page avant de citer un ministre. À reprendre plutôt qu'à refaire. Et pour savoir quelle source fait foi quand deux divergent, watchlist-sources-ci.md chez BENKAN, YIRIWA et LOKOLI porte une hiérarchie de fiabilité (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, INS, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA). ⚠ Les trois versions diffèrent.

### CL-FATOU-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Socle commun. Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021. MISE À JOUR DU 18/09, ET CE JEU EST ANTÉRIEUR AU CHANGEMENT : le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026 (référence établie sur le recensement mensuel d'Ivoire-Juriste, cohérence vérifiée contre son récapitulatif de janvier). La presse ne l'a relevé que le 18/03. L'écart noté plus haut sur les districts est donc tranché : UN LIVRABLE ÉCRIT DEUX DISTRICTS AUTONOMES, JAMAIS DOUZE NI QUATORZE. L'écart sur les communes, 201 contre 197, reste ouvert. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-FATOU-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://fr.wikipedia.org/wiki/F%C3%AAtes_et_jours_f%C3%A9ri%C3%A9s_en_C%C3%B4te_d'Ivoire
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Socle commun, et CHEZ ELLE C'EST UNE RÈGLE DE PAIE, pas un confort de planning. Le régime ivoirien des fériés est à deux étages : SEULS LE 1ER MAI ET LE 7 AOÛT sont chômés ET payés pour tous, les autres sont chômés non payés sauf accord ou convention ; et si l'un des deux tombe un dimanche, le lundi devient férié chômé. Un logiciel paramétré sur un calendrier français se trompe tous les mois. Base légale : article 24.2 du Code du travail (loi 2015-532) et décret 96-205 du 07/03/1996 modifié par le 2011-371. ✅ La réponse précise existe déjà chez DJÉNÉBA (memory/reference/droit/JOURS-FERIES.md) : c'est l'ARTICLE 64 de la convention de 1977 qui liste les fériés chômés PAYÉS. Le 7 août et le 1er mai sont payés même un dimanche ; les autres (1er janvier, Korité, Tabaski, 1er novembre, Noël, Ascension, Assomption) ne le sont pas s'ils tombent un dimanche. Il faut avoir accompli la dernière journée avant et la première après le férié pour y avoir droit, l'absence autorisée conservant le droit. ARTICLE 65 pour les autres fériés : majoration de 100 % pour les payés à l'heure qui travaillent ce jour-là.

## Zone UEMOA

### CL-FATOU-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Socle commun. uemoa.int répond mais sa chaîne de certificat est incomplète, les scripts tombent et le navigateur passe.

### CL-FATOU-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Socle commun. Aucun chiffre relevé. ATTENTION, MANQUE TRANSVERSE : aucun montant de SMIG n'a été relevé dans les quatre fiches produites le 17/09, et c'est le plancher de tout. Voir CL-FATOU-20. MISE À JOUR DU 18/09 : les chiffres de base sont désormais relevés sur bceao.int, huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. LE SMIG RESTE NON RELEVÉ, c'est un manque transverse distinct et il n'est pas comblé par cette mise à jour.

## Droit des affaires

### CL-FATOU-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/actes-uniformes/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Socle commun, et comme chez Adjoua : peu utile ici. Le droit social ivoirien est NATIONAL. L'OHADA n'entre que par la marge, pour la forme juridique de l'employeur.

## Langue

### CL-FATOU-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.dictionnairedesfrancophones.org/explore/localisation/geonames%3A2287781
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || Réparé le 17/09 : la compétence parler-ivoirien (Y0487) est désormais liée au poste, comme chez cinq autres experts. Utile directement ici, sa compétence de paie cite le message WhatsApp d'un chef d'équipe comme source d'élément variable. EN REVANCHE referentiel-local N'A PAS ÉTÉ LIÉE, et c'est délibéré : la version du catalogue est celle du RECRUTEMENT (titrée « Référentiel local — recrutement »), elle pointe marche-emploi-ci.md et business-cases-par-metier.md, des fichiers qui vivent chez Adjoua et n'existent pas ici. La lier donnerait à Fatou une compétence qui renvoie à des fichiers absents. Il lui faut sa propre version quand ses corpus existeront. ⚠ 17/09 : remis à « Intégré : Non ». Le mode d'emploi est explicite, « une pièce sans lien n'est pas intégrée », et la pièce n'est pas encore déposée dans le dossier Couche Locale du Drive. Elle est disponible dans le poste, ce qui est autre chose.

## Canaux

### CL-FATOU-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : le mobile money touche 50,3 % des individus, plus de 13 millions de comptes, et 85 % des transactions sont des transferts.

## Paie

### CL-FATOU-11 · Le bulletin de paie ivoirien : rubriques et mentions obligatoires
- **Pourquoi** : Un bulletin non conforme est contestable
- **Où chercher** : Code du travail, CNPS
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 18/09/2026
- **Commentaire** : Lu le 18/09 dans le socle ~/.claude/outils-communs/droit-travail-ci/ (édition 2021 du Code, qui intègre la convention interprofessionnelle). CE QUE LE CODE DONNE, ET CE QU'IL NE DONNE PAS. Il ne fixe PAS la liste des rubriques d'un bulletin de paie : cette liste est renvoyée à un texte réglementaire que je n'ai pas téléchargé. LA LIGNE RESTE DONC À NON, volontairement, plutôt que d'inventer des rubriques plausibles. Ce que le Code établit en revanche et qui change la pratique : ARTICLE 32.6, l'acceptation sans protestation ni réserve d'un bulletin de paie NE VAUT PAS renonciation du travailleur au paiement du salaire, des indemnités et des accessoires qui lui sont dus ; elle ne vaut pas non plus compte arrêté et réglé, et elle N'INTERROMPT PAS la prescription des salaires. Autrement dit, un bulletin signé ne protège pas l'employeur. À CHERCHER ENSUITE : l'arrêté ou le décret fixant les mentions obligatoires du bulletin.

### CL-FATOU-12 · Barèmes de cotisations et retenues à la source
- **Pourquoi** : Un net faux se voit au premier virement
- **Où chercher** : CNPS, Direction générale des impôts
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Taux de cotisation CNPS sur disque, plus les retenues fiscales dans bases-locales/fiscalite-ci/. ⚠ La répartition de la vieillesse (7,70 / 6,30) vient de sources secondaires, pas du document CNPS. || FAIT le 18/09, SUR SOURCE PRIMAIRE. Le document de recouvrement de la CNPS a été rapatrié dans le socle : ~/.claude/outils-communs/droit-travail-ci/cnps/cnps-taux-de-cotisation.pdf et .txt. TAUX : prestations familiales 5 % · assurance maternité 0,75 % · accidents du travail et maladies professionnelles 2 à 5 % SELON LE SECTEUR D'ACTIVITÉ · assurance vieillesse 14 %. Les sources secondaires concordantes répartissent la vieillesse en 7,70 % employeur et 6,30 % salarié, ce qui boucle bien à 14 % ; cette répartition n'est pas dans le document CNPS lui-même, je la signale comme telle. Prestations familiales et accidents du travail sont intégralement à la charge de l'employeur. ASSIETTE (art. 23 du Code de prévoyance sociale) : l'ensemble des salaires, Y COMPRIS les avantages en nature et les indemnités diverses, À L'EXCEPTION des indemnités ayant le caractère de remboursement de frais. APPRENTIS : l'assiette est la moitié du SMIG s'il y a contrat d'apprentissage, la valeur du SMIG sinon. QUI PAIE : l'employeur est responsable du versement de TOUT, part patronale ET part salariale, et le salarié ne peut s'opposer à la retenue de sa part sur son salaire. ⚠ RÉSERVE DE DATE : le document porte la mention « Édition 2018 » et il est hébergé dans un répertoire de 2020. Les taux qu'il donne sont identiques à ceux que publient les sources secondaires pour 2026, donc ils paraissent stables, mais un taux de paie se reconfirme sur le site de la CNPS avant chaque exercice. NON RENSEIGNÉ : le barème de l'impôt sur les traitements et salaires (ITS), qui relève de la DGI et non de la CNPS. Les plafonds d'assiette circulent aussi en sources secondaires seulement.

### CL-FATOU-19 · Le solde de tout compte
- **Pourquoi** : C'est le moment où une paie approximative devient un contentieux
- **Où chercher** : Code du travail, convention collective interprofessionnelle
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base droit du travail sur disque : Code du travail loi 2015-532, ordonnance 2021-902 qui le modifie, convention interprofessionnelle de 1977, taux de cotisation CNPS, et JOURS-FERIES.md. ⛔ UNE DIVERGENCE À NE PAS LISSER, écrite dans le LISEZ-MOI : les deux textes ne donnent pas le même seuil de bascule des heures supplémentaires. ⚠ L'extraction texte de l'ordonnance 2021-902 est vide, c'est un document numérisé : on la cite depuis le PDF. || Lu le 18/09 dans le socle ~/.claude/outils-communs/droit-travail-ci/ (édition 2021 du Code, qui intègre la convention interprofessionnelle). LE POINT EST CONTRE-INTUITIF ET IL EST DÉCISIF. ARTICLE 32.6 : N'EST PAS OPPOSABLE AU TRAVAILLEUR la mention « pour solde de tout compte », ou toute mention équivalente, qu'il souscrit pendant l'exécution ou après la résiliation de son contrat et par laquelle il renoncerait à tout ou partie de ses droits. Faire signer un solde de tout compte NE PROTÈGE DONC PAS l'employeur : le travailleur conserve ses droits, le compte n'est pas réputé arrêté et réglé, et la prescription des salaires ne cesse pas de courir. DEVANT L'INSPECTION DU TRAVAIL, c'est encore plus net : dans un procès-verbal de conciliation, aucune mention du type « pour solde de tout compte » ou « toutes causes confondues » ne peut être employée, À PEINE DE NULLITÉ DU PROCÈS-VERBAL. Une clause mettant définitivement fin au litige ne s'y mentionne qu'avec la volonté expressément manifestée des parties. CONSÉQUENCE DE PAIE : un solde de tout compte se calcule juste, il ne se sécurise pas par une signature. RESTE DÛ : la liste des éléments à y porter (indemnité de licenciement, congés non pris, préavis non effectué), à relever article par article.

### CL-FATOU-20 · Le SMIG et les minima de branche
- **Pourquoi** : C'est le plancher de tout, et il manque partout
- **Où chercher** : Texte réglementaire fixant le SMIG, conventions de branche
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ilo.org/setting-adequate-wages-c%C3%B4te-divoire
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. SMIG 75 000 FCFA par mois depuis le 01/01/2023, première hausse depuis 2014 selon l'OIT ; SMAG 39 960 FCFA. ⚠ Le numéro du décret (2022-986 du 21/12/2022) et le SMAG viennent de sources secondaires. L'art. 31.8 du Code renvoie le montant à un décret, négocié tous les trois ans. ⛔ LES MINIMA DE BRANCHE NE SONT PAS COUVERTS : les conventions collectives sectorielles restent dues. || MANQUE TRANSVERSE COMBLÉ le 18/09, après avoir été signalé vide sur cinq fiches. SMIG : 75 000 FCFA PAR MOIS, applicable depuis le 1er JANVIER 2023. L'Organisation internationale du travail, source de rang 2, écrit que c'était la PREMIÈRE HAUSSE DEPUIS 2014, de 60 000 à 75 000 FCFA. Les sources secondaires concordantes l'attribuent au décret n°2022-986 du 21/12/2022 et donnent un SMAG, minimum agricole, de 39 960 FCFA par le même texte : LE NUMÉRO DU DÉCRET ET LE SMAG VIENNENT DE SOURCES SECONDAIRES, pas du texte, à confirmer au Journal officiel. AUCUNE REVALORISATION EN 2026 à ce jour. Des fédérations syndicales demandent 150 000 FCFA, soit le double : c'est une revendication, pas un montant applicable, et elle ne se cite jamais comme un chiffre de paie. CE QUE DIT LE CODE (art. 31.8) : un décret fixe les montants du SMIG et du SMAG après avis de la Commission consultative du travail, et LES PARTENAIRES SOCIAUX LES NÉGOCIENT TOUS LES TROIS ANS au sein de cette commission. Le montant n'est donc jamais dans le Code, toujours dans un décret : le dernier que cite l'édition 2021 du Code est le décret n°2013-791 du 20/11/2013, ce qui confirme que l'édition est antérieure à la revalorisation de 2023. NON RENSEIGNÉ : les minima de branche, qui relèvent des conventions collectives sectorielles (voir la ligne 14).

### CL-FATOU-21 · Les heures supplémentaires : seuils et taux de majoration
- **Pourquoi** : C'est la variable de paie la plus fréquente après l'absence
- **Où chercher** : Code du travail, convention collective
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. ⛔ CE QUE L'INTÉGRATION APPORTE ICI EST UN DÉSACCORD, pas une réponse : les deux textes du dossier NE DONNENT PAS LE MÊME SEUIL de bascule des heures supplémentaires. Le LISEZ-MOI l'écrit noir sur blanc. Un livrable qui donne un seuil unique sans dire lequel des deux textes il suit est faux par omission. || Lu le 18/09 dans le socle ~/.claude/outils-communs/droit-travail-ci/ (édition 2021 du Code, qui intègre la convention interprofessionnelle). FAIT, ET AVEC UNE DIVERGENCE À NE PAS LISSER : les deux textes du socle ne donnent PAS le même seuil de bascule. SELON LE CODE, à défaut de convention ou d'accord d'établissement, les majorations sont fixées par arrêté du ministre chargé du Travail et NE PEUVENT ÊTRE INFÉRIEURES à : 15 % de la 41e à la 46e heure · 50 % au-delà de la 46e · 75 % de nuit · 75 % de jour les dimanches et jours fériés · 100 % de nuit les dimanches et jours fériés. SELON L'ARTICLE 51 DE LA CONVENTION INTERPROFESSIONNELLE : 15 % de la 41e à la 48e heure · 50 % au-delà de la 48e · 75 % de nuit · 75 % de jour les dimanches et fériés · 100 % de nuit les dimanches et fériés. LE SEUIL DIFFÈRE : 46e heure dans le Code, 48e dans la convention. Les heures 47 et 48 sont donc majorées à 50 % d'un côté et à 15 % de l'autre. JE NE TRANCHE PAS. Ce que je peux dire : les taux du Code sont des PLANCHERS, et la convention s'applique là où elle s'applique. Même nature d'écart que celui relevé le 17/09 sur les durées de préavis, et même besoin d'un avis de juriste. ASSIETTE : la convention majore LE SALAIRE RÉEL, déduction faite de l'indemnité d'expatriation. AUTRE RÈGLE, pour les payés à l'heure : les heures récupérées non compensées dans les jours qui suivent sont rémunérées AVEC UNE MAJORATION DE 100 % (art. 65 de la convention).

### CL-FATOU-28 · La CMU : affiliation, immatriculation et cotisation
- **Pourquoi** : Elle passe sur chaque bulletin, et l'employeur est sanctionné s'il la rate
- **Où chercher** : Loi 2014-131, Journal officiel du 10 avril 2014 ; décret des taux, CNAM
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://extranet.who.int/cpcd/health-legislation/loi-ndeg2014-131-instituant-la-couverture-maladie-universelle
- **Pièce, ici** : references/pieces/1voow-RaUR-BSl-KGVuH7I5UEeAxAFc3fCu6MnH946sA.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : AJOUTÉ ET INTÉGRÉ LE 22/09, sujet absent de tous les onglets alors qu'il passe sur CHAQUE bulletin de paie. Loi n° 2014-131 du 24/03/2014, JO du 10/04/2014, texte intégral sur disque. Régime OBLIGATOIRE de couverture maladie, géré par la CNAM ; l'assujetti doit être AFFILIÉ ET DÉCLARÉ pour ouvrir droit aux prestations. ⛔ LE CHIFFRE QUE TOUT LE MONDE CITE N'EST PAS DANS LA LOI. Les « 1 000 FCFA par mois et par personne » ne figurent PAS dans la loi 2014-131, qui renvoie explicitement les TAUX ET ASSIETTES à un DÉCRET que nous n'avons pas. Le montant est largement rapporté par la presse et les cabinets, il n'est pas sourcé chez nous : NE PAS le porter sur un bulletin ni dans une note client sans ouvrir le décret ou interroger la CNAM. ⏸ Décret à rapatrier, c'est le trou principal, avec la ventilation employeur/salarié qui n'est pas davantage dans la loi. SANCTIONS DE L'EMPLOYEUR, chiffrées dans le texte : art. 68, défaut d'affiliation dans les délais = 100 000 à 1 000 000 FCFA et injonction sous un mois ; art. 69, défaut d'immatriculation DES SALARIÉS = 100 000 à 1 000 000 FCFA et injonction sous un mois ; art. 70, PRÉLÈVEMENT SCIEMMENT INDU DE COTISATIONS SALARIALES = 100 000 à 1 000 000 FCFA ; art. 67, fausse déclaration = 1 À 5 ANS d'emprisonnement et 100 000 à 1 000 000 FCFA. ⚠ L'ART. 70 VISE L'EMPLOYEUR QUI PRÉLÈVE TROP, pas seulement celui qui ne prélève pas : une erreur de paramétrage de paie en défaveur du salarié est sanctionnée dès lors qu'elle est sciemment faite. QUATRE POINTS QUI CHANGENT UN TRAITEMENT DE PAIE : (1) le numéro d'immatriculation devient l'IDENTIFIANT UNIQUE du système de sécurité sociale et remplace tout autre ; (2) l'affiliation prend effet À LA DATE D'IMMATRICULATION, pas à l'embauche ni à la demande ; (3) une PÉRIODE DE STAGE PRÉALABLE est obligatoire, un salarié fraîchement immatriculé n'est pas couvert le jour même ; (4) cotisations et prestations sont EXONÉRÉES D'IMPÔTS ET TAXES, ce qui touche l'assiette des autres retenues. PROCÉDURE : recouvrement prescrit par CINQ ANS ; toute contestation doit OBLIGATOIREMENT être portée d'abord devant l'organisme, par lettre recommandée, avant toute juridiction. ⛔ NON VÉRIFIÉ SUR TEXTE : le taux de prise en charge (la presse annonce 70 % pour le régime général de base et l'intégralité pour le régime d'assistance médicale).

## Droit social

### CL-FATOU-13 · Congés, absences, maternité : ce que dit le texte ici
- **Pourquoi** : Appliquer une règle française
- **Où chercher** : Code du travail
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.economie-ivoirienne.ci/sites/default/files/sites/default/files/inline-files/Loi%20n%C2%B0%202015-532%20du%2020%20juillet%202015%20portant%20code%20du%20Travail.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base droit du travail sur disque : Code du travail loi 2015-532, ordonnance 2021-902 qui le modifie, convention interprofessionnelle de 1977, taux de cotisation CNPS, et JOURS-FERIES.md. ⛔ UNE DIVERGENCE À NE PAS LISSER, écrite dans le LISEZ-MOI : les deux textes ne donnent pas le même seuil de bascule des heures supplémentaires. ⚠ L'extraction texte de l'ordonnance 2021-902 est vide, c'est un document numérisé : on la cite depuis le PDF. || Lu le 18/09 dans le socle ~/.claude/outils-communs/droit-travail-ci/ (édition 2021 du Code, qui intègre la convention interprofessionnelle). MATERNITÉ, CONFIRMÉ SUR LE TEXTE : QUATORZE SEMAINES. Pendant cette période, et sans préjudice des prolongations prévues à l'article 23.6 alinéa 1, la salariée a droit à une ALLOCATION DE MATERNITÉ et à une INDEMNITÉ JOURNALIÈRE ÉGALE AU SALAIRE qu'elle percevait au moment de la suspension du contrat, plus le remboursement des soins liés à la grossesse et aux couches dans la limite des tarifs des formations sanitaires publiques, et les allocations prénatales. CES PRESTATIONS SONT À LA CHARGE DE L'INSTITUTION DE PRÉVOYANCE SOCIALE, pas de l'employeur : c'est le point qu'on se trompe le plus souvent à porter en paie. ⚠ VÉRIFICATION FAITE : l'ordonnance 2021-902 du 22/12/2021 modifie les articles 23.1 et 23.13, mais NI 23.11 NI 23.12, qui portent les quatorze semaines et les prestations. Le chiffre tient donc bien après l'ordonnance. Les articles 23.1 et 23.13 modifiés restent à lire avant toute réponse sur le champ d'application et les sanctions. CONGÉS PAYÉS, aménagement : un congé qui ne dépasse pas QUATORZE JOURS CONSÉCUTIFS doit être CONTINU ; au-delà il peut être fractionné avec l'agrément du salarié, et dans ce cas UNE FRACTION DOIT ÊTRE D'AU MOINS QUATORZE JOURS CONSÉCUTIFS (art. 25.7 du Code). MISE EN DISPONIBILITÉ sans salaire, à la demande du travailleur, notamment pour l'allaitement à l'issue du congé de maternité, l'assistance à un enfant diminué, un mandat public, un congé de formation ou élever son enfant : LA PÉRIODE N'ENTRE PAS DANS LE CALCUL DE L'ANCIENNETÉ NI DU CONGÉ (art. 16.8). RESTE DÛ : la durée d'acquisition du congé annuel, à relever article par article.

### CL-FATOU-14 · Conventions collectives par branche
- **Pourquoi** : La branche prime sur l'usage
- **Où chercher** : Conventions collectives publiées
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1CW9Hw4MyQKtE2Bpp-9ONYdonvwfUZfqSs0cdqEpfbXI.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. ⛔ LA QUESTION ÉTAIT MAL POSÉE, ET C'EST LA TROUVAILLE : les conventions sectorielles n'existent PAS branche par branche. L'arrêté n° 1 MTIC, CAB, du 3 janvier 1978 rend la convention interprofessionnelle du 19/07/1977 OBLIGATOIRE pour tous les employeurs et travailleurs de DOUZE branches, y compris les non-signataires (art. 2) : industries et commerces de toute nature, mécanique générale, BÂTIMENT ET TRAVAUX PUBLICS, distribution de produits pétroliers, auxiliaires de transports, transports urbains et interurbains, transports routiers, secteur automobile, transports maritime aérien et lagunaire (sauf Marine marchande), BANQUES ASSURANCES CRÉDITS IMMOBILIER, HÔTELLERIE, électricité gaz eau service sanitaire. Dire « il n'y a pas de convention pour le BTP » est donc faux : il est couvert et l'employeur ne peut pas s'y soustraire. ✅ EN PLUS, deux textes de branche : Mines & Carrières 2023 (GPMCI/FISMECA, 12/05/2023, 81 pages, RÉCUPÉRÉE EN ENTIER, seule grille de branche complète que nous ayons : classification art. 62, catégories art. 69, barème art. 70) et la convention annexe « journaliers » (indemnité de précarité de 3 % du salaire horaire minimum de la catégorie au-delà de 3 mois). ⛔ CE QUI MANQUE : le TEXTE de la convention bancaire signée le 20/08/2025 entre l'APBEF-CI et le SYNABEFA-CI n'est pas publié, seule la presse en rend compte ; il se demande à l'APBEF-CI. D'ici là, pour une banque, on applique 1977 et on DIT qu'un texte plus récent existe sans l'avoir lu. Manquent aussi les grilles de branche autres que les mines : ce qui circule sur les sites d'emploi n'est pas une source conventionnelle. ⚠ OÙ L'ON A REGARDÉ : emploi.gouv.ci (403, y compris par navigateur, et ce n'est PAS un filtrage d'agent, ni code 1010 ni _cf_chl_opt), travail.gouv.ci (domaine inexistant), droit-afrique.com (403 de serveur mal configuré, « unable to read htaccess file »), droitci.info, loidici.biz (d'où vient l'arrêté de 1978), chambredesmines.org (d'où vient la convention minière), cgeci.com et la presse économique. || ⛔ NON INTÉGRÉ AU 20/09, ET C'EST LA RÉPONSE HONNÊTE : seule une adresse est connue, aucune pièce n'est posée dans l'espace du poste et aucune note d'usage n'en a été tirée. « Trouvé » dit qu'on sait où regarder, pas qu'on l'a. Tant que les trois conditions du Mode d'emploi ne sont pas réunies, la colonne Intégré reste Non. || TROUVÉ, et cette pièce sert aussi à ADJOUA. Convention collective interprofessionnelle du 19 juillet 1977, conclue entre l'Association interprofessionnelle des employeurs de Côte d'Ivoire et l'UGTCI, accessible en PDF. Elle porte les classifications, les catégories et des annexes par branche professionnelle. RÉSERVE JURIDIQUE À NE PAS ESCAMOTER : elle a été conclue sous le Code du travail de 1964, son articulation avec celui de 2015 n'est pas évidente et ne se décide pas ici. À faire dire par un juriste avant d'en faire une règle opposable à un client. L'OIT la référence dans NATLEX, qui filtre les scripts en 403 mais s'ouvre au navigateur. ✅ ELLE EST DÉJÀ SUR LE DISQUE DE DJÉNÉBA depuis le 26/08 (memory/reference/droit/, PDF + texte extrait). Ses articles utiles en paie : 34 (préavis), 64 (fériés chômés payés et conditions du droit à l'indemnité), 65 (majoration de 100 % pour les payés à l'heure travaillant un autre férié). ✅ 17/09, fait : les textes sont désormais en BASE COMMUNE, ~/.claude/outils-communs/droit-travail-ci/ (Code, ordonnance 2021-902, convention 1977, JOURS-FERIES.md, LISEZ-MOI qui cite article par article), et liés dans ce poste sous memory/reference/droit/. Un texte de loi n'appartient à aucun poste.

## Administration

### CL-FATOU-15 · Déclarations périodiques et leurs échéances
- **Pourquoi** : Une déclaration en retard coûte une pénalité
- **Où chercher** : CNPS, DGI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE : ⛔ DEUX CALENDRIERS QUI NE COÏNCIDENT PAS, et les confondre est l'erreur la plus fréquente en paie ivoirienne. SOCIAL, CNPS : versement MENSUEL à partir de 20 salariés, TRIMESTRIEL en dessous, dans les 15 premiers jours suivant la période échue ; régularisation annuelle par la DISA au plus tard le 31 MARS, accompagnée de la DASC. Retard : pénalité de 10 % ET non-délivrance de l'attestation de mise à jour, ce qui BLOQUE UN MARCHÉ PUBLIC, c'est par là que le retard coûte le plus cher. FISCAL, DGI, article 126 du Code général des impôts, ET LE MANQUE DU 18/09 EST COMBLÉ : retenues sur salaires versées le 15 du mois suivant au régime du réel, et pour les grandes et moyennes entreprises le 10 pour l'industrie, le pétrole et les mines, le 15 pour le commerce, LE 20 POUR LES PRESTATAIRES DE SERVICES. Petits montants : semestriel si les retenues n'excèdent pas 10 000 F, mais tout se rattrape dès qu'un mois dépasse 5 000 F. Cession ou cessation : versement immédiat. ÉTAT ANNUEL DES SALAIRES (art. 127) : au plus tard le 30 JUIN pour les entreprises certifiées par un commissaire aux comptes, LE 30 MAI pour toutes les autres, et il porte le numéro CNPS du salarié, ce qui relie les deux administrations. Conservation des documents de paie jusqu'à la fin de la TROISIÈME année suivant les retenues (art. 125).

### CL-FATOU-22 · La médecine du travail : quel organisme, quelle périodicité, quel coût
- **Pourquoi** : L'obligation est connue mais inapplicable si on ne sait pas chez qui aller
- **Où chercher** : Services de santé au travail agréés, inspection du travail
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE, la santé au travail : ⛔ L'ARTICLE 43.1 N'IMPOSE AUCUN SEUIL D'EFFECTIF. Tout employeur doit assurer un service de santé au travail, au choix un service médical autonome interne ou l'adhésion à un service médical interentreprises. L'article 43.2 en fixe le contenu : surveillance du milieu de travail pour prévenir accidents et maladies professionnelles, et surveillance de la santé des travailleurs, QUI COMPREND L'EXAMEN MÉDICAL DES CANDIDATS À L'EMBAUCHE ET DES NOUVEAUX EMBAUCHÉS. La visite d'embauche est donc une obligation de texte, pas un usage. EFFET DE PAIE : en cas de maladie, les indemnités peuvent être versées par le service interentreprises auquel adhère l'employeur, sur les fonds provenant de la participation de ses adhérents. L'organisme compétent en accident du travail et maladies professionnelles est l'ONATMP-CI. ⛔ CE QUI RESTE DÛ, ET QUI SE DIT AU CLIENT : la PÉRIODICITÉ des visites périodiques et le COÛT de l'adhésion ne sont pas dans les textes que nous détenons. Ils relèvent de textes réglementaires et des tarifs des services interentreprises. Ne pas avancer de chiffre.

### CL-FATOU-23 · Le registre d'employeur et les affichages obligatoires
- **Pourquoi** : C'est ce que l'inspection regarde en premier lors d'un contrôle
- **Où chercher** : Code du travail, inspection du travail
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE, registre et affichages : ⚠ LE MANQUE DU 18/09 EST COMBLÉ, LA LISTE DES AFFICHAGES EST RELEVÉE. Elle est dispersée dans le Code, et une entreprise qui n'affiche rien est en défaut sur SIX points à la fois : la non-discrimination à l'embauche (art. 4) et la protection contre le harcèlement moral ou sexuel (art. 5), affichées sur les lieux de travail ET à la porte des locaux d'embauche (art. 7) · la durée et l'horaire de travail, affichés et communiqués à l'inspecteur (art. 21.1) · la durée hebdomadaire et l'horaire journalier, qui doivent EN OUTRE figurer au règlement intérieur · LES TAUX MINIMA DE SALAIRES et les conditions de rémunération à la tâche ou aux pièces, au bureau des employeurs ET SUR LES LIEUX DE PAIE (art. 31.6) · le règlement intérieur, à une place convenable et constamment tenu en bon état de lisibilité · les accords de conciliation et sentences arbitrales devenues exécutoires, au lieu du conflit. REGISTRE D'EMPLOYEUR (art. 92.3) : constamment à jour, au lieu de l'exploitation, trois fascicules, tenu SANS DÉPLACEMENT à la disposition de l'inspecteur et conservé CINQ ANS après la dernière mention. ✅ La dispense qui intéresse une PME équipée : les deux premiers fascicules peuvent être remplacés par un FICHIER ÉLECTRONIQUE FIABLE ET À JOUR. ⛔ Reste dû : le modèle réglementaire du registre, non téléchargé.

### CL-FATOU-24 · Les portails de déclaration en ligne
- **Pourquoi** : Un format de fichier refusé à l'échéance coûte une journée
- **Où chercher** : CNPS (e-DISA), DGI (services en ligne)
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE, les portails : e-DISA est développé et mis GRATUITEMENT à disposition de tout employeur disposant d'un outil informatique ; il reprend les éléments de paie de l'année écoulée pour produire la DISA. ⚠ La DISA part sur support électronique, LA DASC SIGNÉE ET CACHETÉE RESTE PAPIER, quel que soit le mode de dépôt de la DISA. La déclaration aux fins d'immatriculation se retire en agence CNPS ou sur cnps.ci. ⛔ ET VOICI CE QUI CHANGERA LE PROCESSUS DE PAIE, TROUVÉ DANS LE CODE GÉNÉRAL DES IMPÔTS : l'article 126-5° prévoit une DÉCLARATION UNIQUE de l'impôt sur les traitements et salaires ET des cotisations sociales, mais précise que les employeurs n'y seront tenus QU'APRÈS L'OPÉRATIONNALISATION DE LA PLATEFORME DÉDIÉE (loi 2023-1000 du 18/12/2023, annexe fiscale, art. 5). Elle n'est donc pas en service à ce jour, et les deux déclarations restent séparées. À surveiller : le jour où elle ouvre, le calendrier de paie ivoirien change.

## Recrutement

### CL-FATOU-16 · Formalités d'embauche : contrat, visite médicale, déclaration
- **Pourquoi** : Embaucher sans les formalités expose l'employeur
- **Où chercher** : Inspection du travail, CNPS
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://servicepublic.gouv.ci/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base droit du travail sur disque : Code du travail loi 2015-532, ordonnance 2021-902 qui le modifie, convention interprofessionnelle de 1977, taux de cotisation CNPS, et JOURS-FERIES.md. ⛔ UNE DIVERGENCE À NE PAS LISSER, écrite dans le LISEZ-MOI : les deux textes ne donnent pas le même seuil de bascule des heures supplémentaires. ⚠ L'extraction texte de l'ordonnance 2021-902 est vide, c'est un document numérisé : on la cite depuis le PDF. || TROUVÉ, et cette case permet d'éviter un piège réel : TROIS OBLIGATIONS, TROIS DÉLAIS DIFFÉRENTS. (1) CNPS : immatriculation dans les 48 HEURES suivant l'embauche du premier travailleur, puis signalement de toute embauche et de tout départ (cnps.ci/employeur). (2) INSPECTION DU TRAVAIL : l'entreprise se déclare et reçoit une attestation ; la déclaration d'une nouvelle embauche se fait dans les 8 JOURS PRÉCÉDANT la prise de service. (3) VISITE MÉDICALE D'EMBAUCHE : obligatoire AVANT la prise de poste, au plus tard avant l'expiration de la période d'essai, sur le fondement des articles 43.1 et 43.2 du Code du travail ; s'y ajoutent les visites périodiques, de reprise après maladie, et celles prévues pour les femmes, les enfants et les contrats de plus de trois mois. Les délais (2) et (3) viennent de sources secondaires, à confirmer sur le texte.

## Références

### CL-FATOU-17 · Modèles de contrats de travail conformes
- **Pourquoi** : Un modèle importé crée des clauses nulles
- **Où chercher** : Documents de la maison, cabinets locaux
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE, le contrat : ⚠ LE MANQUE SIGNALÉ LE 18/09 EST COMBLÉ, ET LA RÉPONSE ÉTAIT DÉJÀ SUR LE DISQUE. La durée maximale de la période d'essai ne demandait pas le décret que je disais manquer : elle est à l'ARTICLE 14 DE LA CONVENTION DE 1977, chiffrée par catégorie. 8 jours pour les ouvriers et employés payés à l'heure, 1 mois pour les payés au mois, 2 mois pour les agents de maîtrise et techniciens, 3 mois pour les ingénieurs et cadres, 6 MOIS POUR LES CADRES SUPÉRIEURS. Renouvelable UNE SEULE FOIS, et au-delà de deux mois le renouvellement se notifie PAR ÉCRIT AVANT LA FIN DE L'ESSAI : 8 jours avant pour un essai de 2 mois, 15 jours pour 3 mois, 1 mois pour 6 mois, faute de quoi l'employeur doit l'accord du salarié ou une indemnité compensatrice du même nombre de jours. FORME : contrat libre en principe, SAUF trois cas où l'écrit est obligatoire, le CDD (art. 14.2), l'apprentissage qui doit en outre être rédigé en langue française (art. 13.1), et dès qu'une période d'essai est prévue ou renouvelée (art. 14.5). ⛔ EN L'ABSENCE D'ÉCRIT LE CONTRAT EST RÉPUTÉ À DURÉE INDÉTERMINÉE et l'engagement définitif dès le jour de l'embauche : une embauche mal formalisée n'est pas une embauche fragile, c'est un CDI. Mentions obligatoires à l'article 2 de la convention. Priorité de réembauche conservée DEUX ANS après une suppression d'emploi. ⚠ Reste vrai : l'ordonnance 2021-902 modifie l'article 13.3, à lire avant d'écrire un modèle d'apprentissage.

## Vie au travail

### CL-FATOU-18 · Usages locaux : horaires, fêtes, absences prévisibles
- **Pourquoi** : Planifier contre le calendrier réel
- **Où chercher** : Calendrier des fêtes légales, retours de missions
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.cnps.ci/wp-content/uploads/2020/08/Recouvrement.pdf
- **Pièce, ici** : references/pieces/13k037Sr0g-JqAKzp7NbWAa05Qr7N2x3frd0uV7Ar7fQ.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09. La matière était lue depuis le 18/09 mais elle n'était posée nulle part : elle l'est maintenant, dans bases-locales/droit-travail-ci/OBLIGATIONS-EMPLOYEUR.md, note neuve qui rassemble ce qui était dispersé entre le Code du travail de 2015, la convention de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Chaque article y est nommé pour qu'on puisse le rouvrir. POUR CETTE LIGNE, les horaires : DURÉE LÉGALE DE 40 HEURES par semaine pour tous les personnels, quels que soient leur sexe et leur mode de rémunération, hors agriculture ; 2 400 HEURES PAR AN dans les établissements agricoles et assimilés. Équivalences pour la surveillance et le service d'incendie : 44 heures valent 40 effectives hors agriculture, 52 valent 48 dans l'agricole. Aménagements possibles : répartition sur 5 jours ouvrables, limitation à 6 h 40 par jour, ou répartition inégale avec un MAXIMUM DE 8 HEURES PAR JOUR. ⚠ DIVERGENCE À NE PAS LISSER sur les heures supplémentaires : le Code bascule à la 46e heure, la convention à la 48e, donc les heures 47 et 48 sont majorées à 50 % d'un côté et 15 % de l'autre. FÉRIÉS : la fiche JOURS-FERIES.md a été RÉÉCRITE SUR LES DEUX DÉCRETS le 22/09 et corrige deux erreurs que nous servions, le 15 novembre qui manquait à la liste et la règle du lendemain qui couvre aussi la Korité, Noël et la Tabaski depuis 2011. Les fêtes mobiles ne sont datées par aucun texte, elles s'annoncent par communiqué quelques jours avant.

### CL-FATOU-25 · Les outils de paie réellement utilisés par les PME ivoiriennes
- **Pourquoi** : Fatou travaille à côté de ce que le client utilise déjà, pas à la place
- **Où chercher** : Relevé auprès des clients et des éditeurs locaux
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : TOUJOURS À NON, et c'est un refus assumé. Aucun relevé sérieux de l'équipement en logiciels de paie des PME ivoiriennes n'existe : les seules sources sont les pages commerciales des éditeurs eux-mêmes, qui annoncent leurs propres parts de marché sans méthode ni échantillon. Même nature que les taux d'ouverture écartés par le corpus de Kouassi. CE QUI SE CONSTATE EN REVANCHE, et qui vaut mieux qu'un classement inventé : le Code prévoit explicitement la dispense des deux premiers fascicules du registre d'employeur pour qui tient un fichier électronique fiable et à jour (art. 92.3), et la CNPS distribue gratuitement e-disa. Deux signaux que l'outil de paie est attendu, pas un relevé de ce qui est utilisé. CETTE LIGNE SE REMPLIRA PAR LES CLIENTS, en notant l'outil de chacun, pas par une recherche.

## Droit et conventions

### CL-FATOU-26 · Conventions collectives sectorielles de Côte d'Ivoire
- **Pourquoi** : La paie se calcule sur la catégorie de la convention du secteur, pas sur une moyenne de marché. Sans elle, un bulletin est bâti sur une grille qui ne s'applique pas.
- **Où chercher** : Ministère de l'Emploi et de la Protection sociale ; organisations patronales de branche ; Journal officiel
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : ⛔ DOUBLON, ET IL EST INSTRUCTIF. Cette ligne a été ajoutée au point de formation du 22/09/2026, le jour même où la question était traitée sous CL-FATOU-14. La réponse est là-bas : les conventions sectorielles n'existent PAS branche par branche, l'arrêté n° 1 MTIC, CAB, du 3 janvier 1978 rend la convention interprofessionnelle de 1977 OBLIGATOIRE pour douze branches dont le commerce, le BTP, la banque-assurance et l'industrie, y compris pour les non-signataires. Les quatre branches demandées ici sont donc déjà couvertes. Seules les mines et carrières ont un texte propre (2023, récupéré) et les banques un texte de 2025 non publié. ⚠ CE QUE LE DOUBLON RÉVÈLE : deux sessions ont ouvert la même question le même jour sans se voir. Avant d'ajouter une ligne, relire l'onglet du poste. || Demandé au point de formation du 22/09/2026.

### CL-FATOU-27 · Base de calcul des congés payés, calendaire et ouvré
- **Pourquoi** : Le taux d'acquisition change avec la base, environ 2,5 jours par mois en calendaire contre 2,2 en ouvré. La paie des congés en dépend directement.
- **Où chercher** : Code du travail ivoirien ; majorations prévues par chaque convention de branche
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET LA RÉPONSE ÉTAIT DÉJÀ SUR DISQUE. ⛔ LE CONGÉ SE COMPTE EN JOURS OUVRABLES, JAMAIS CALENDAIRES : le Code du travail ne connaît pas le jour calendaire pour le congé annuel, et écrire « calendaires » dans un contrat change le résultat de plusieurs jours par an. Loi 2015-532 art. 25.1 : 2,2 JOURS OUVRABLES PAR MOIS de service effectif, soit 26,4 jours pour douze mois. ⚠ « Sauf disposition plus favorable des conventions collectives ou du contrat » : c'est un PLANCHER, une branche peut donner plus, jamais moins. MAJORATIONS D'ANCIENNETÉ (art. 25.2) : +1 jour après 5 ans, +2 après 10, +3 après 15, +5 après 20, +7 après 25, +8 après 30. SITUATION DE FAMILLE (art. 25.2), pour la FEMME salariée ou apprentie seulement, bascule à 21 ans révolus au dernier jour de la période de référence : moins de 21 ans, 2 jours ouvrables par enfant à charge DÈS LE PREMIER ; plus de 21 ans, 2 jours par enfant À COMPTER DU QUATRIÈME. Plus 1 jour pour la médaille d'honneur du travail, et 2 semaines pour le travailleur logé astreint à 24 h de présence continue. NE SE DÉDUISENT PAS du congé acquis (art. 25.3) : accident du travail, maladie professionnelle, formation syndicale, repos de la femme en couches, et la maladie constatée par un médecin agréé DANS LA LIMITE DE SIX MOIS. ⚠ NE PAS CONFONDRE DURÉE ET INDEMNITÉ : l'indemnité vaut le douzième de la rémunération totale de la période de référence. Deux questions, deux articles. ⚠ LES CONGÉS POUR ÉVÉNEMENT FAMILIAL NE SONT PAS DU CONGÉ ANNUEL : la convention de 1977 en accorde jusqu'à 10 jours ouvrables par an, NON DÉDUCTIBLES du congé réglementaire (mariage 4 jours, décès du conjoint 5, décès d'un enfant ou d'un parent 5, frère ou soeur 2). Ils s'ajoutent, ils ne se retranchent pas. || Demandé au point de formation du 22/09/2026.
