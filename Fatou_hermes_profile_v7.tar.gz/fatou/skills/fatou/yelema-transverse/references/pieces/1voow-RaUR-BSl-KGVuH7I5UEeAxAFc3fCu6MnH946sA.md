# 260922_CMU, obligations de l employeur

===== onglet t.0 · Tab 1 · 28 lignes non vides =====

# La CMU : ce que l'employeur doit faire, et ce que la loi ne dit pas
Établi le 22/09/2026 pour FATOU (paie). Source : loi n° 2014-131 du 24 mars 2014, Journal officiel du 10 avril 2014, loi-2014-131-cmu.pdf, texte intégral sur disque.
## Ce que c'est
La couverture maladie universelle est un régime obligatoire de couverture du risque maladie. Elle est gérée par une institution de prévoyance sociale, la Caisse nationale d'assurance maladie. Toute personne assujettie doit être affiliée et déclarée à l'organisme de gestion pour ouvrir droit aux prestations.
## ⛔ Le chiffre que tout le monde cite n'est PAS dans la loi
On lit partout « 1 000 FCFA par mois et par personne ». Ce montant ne figure pas dans la loi n° 2014-131. Le texte dit, sans ambiguïté, que « les taux et assiettes, les modalités et procédures de paiement ou de recouvrement des cotisations sont précisés par décret ».

Nous n'avons pas ce décret sur disque. Donc : le montant de 1 000 FCFA est largement rapporté par la presse et les cabinets, il n'est pas sourcé chez nous. Ne pas le porter sur un bulletin de paie ni dans une note à un client sans avoir ouvert le décret ou interrogé la CNAM. ⏸ Décret à rapatrier.
## Les obligations de l'employeur, et leurs sanctions
Toutes chiffrées dans le texte, articles 64 à 70.

| Manquement | Sanction |
| Ne pas s'affilier à l'organisme de gestion dans les délais réglementaires (art. 68) | amende de 100 000 à 1 000 000 FCFA, avec injonction de s'affilier sous un mois |
| Ne pas immatriculer ses salariés dans les délais réglementaires (art. 69) | amende de 100 000 à 1 000 000 FCFA, avec injonction d'immatriculer sous un mois |
| Prélever sciemment des cotisations salariales indues (art. 70) | amende de 100 000 à 1 000 000 FCFA |
| Fausse déclaration de l'employeur ou de l'assuré à l'organisme ou aux personnes assermentées (art. 67) | 1 à 5 ans d'emprisonnement et amende de 100 000 à 1 000 000 FCFA |

⚠ L'article 70 vise l'employeur qui prélève trop, pas seulement celui qui ne prélève pas. Une erreur de paramétrage de paie en défaveur du salarié est sanctionnée comme telle dès lors qu'elle est sciemment faite.
## Quatre points qui changent un traitement de paie
- Le numéro d'immatriculation devient l'identifiant unique du système de sécurité sociale en Côte d'Ivoire, et remplace tout autre système d'identification des assurés.
- L'affiliation prend effet à la date d'immatriculation, pas à la date d'embauche ni à celle de la demande.
- Une période de stage préalable est obligatoire avant l'ouverture du droit aux prestations. Un salarié fraîchement immatriculé n'est pas couvert le jour même.
- Cotisations et prestations sont exonérées d'impôts et taxes. Cela a un effet direct sur l'assiette des autres retenues.
## Deux règles de procédure
- Prescription : l'action civile en recouvrement des cotisations ou des majorations de retard se prescrit par cinq ans à compter de l'expiration des délais prescrits.
- Réclamation : une contestation d'une décision de l'organisme doit obligatoirement être portée d'abord devant lui, par lettre recommandée ou autre moyen de notification, avant toute juridiction. Les litiges relèvent ensuite des juridictions de droit commun du lieu de résidence de l'assuré ou du siège de l'employeur.
## ⛔ Ce que cette note ne couvre pas
- Le décret des taux et assiettes, donc le montant réellement dû et sa base de calcul. C'est le trou principal.
- Les modalités d'affiliation et d'immatriculation, que la loi renvoie elles aussi à un décret par régime.
- La ventilation employeur / salarié de la cotisation : elle n'est pas dans la loi.
- Le taux de prise en charge : la presse annonce 70 % pour le régime général de base et une prise en charge intégrale pour le régime d'assistance médicale. Non vérifié sur texte.
