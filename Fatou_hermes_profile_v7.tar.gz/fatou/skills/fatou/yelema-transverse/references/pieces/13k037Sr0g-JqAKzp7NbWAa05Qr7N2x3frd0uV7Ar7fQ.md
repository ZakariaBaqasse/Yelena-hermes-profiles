# 260922_Obligations de l'employeur ivoirien - calendriers, contrat, registre, affichages

===== onglet t.0 · Tab 1 · 72 lignes non vides =====

# Ce qu'un employeur ivoirien doit faire, et quand
Écrite le 22/09/2026 en rassemblant ce qui était dispersé entre le Code du travail de 2015, la convention interprofessionnelle de 1977, le document de recouvrement de la CNPS et le Code général des impôts. Tout ce qui suit vient de textes présents sur ce disque, et chaque article est nommé pour qu'on puisse le rouvrir.

⛔ Deux calendriers différents, et ils ne coïncident pas. Les cotisations sociales vont à la CNPS, l'impôt sur les salaires va à la DGI, avec leurs propres dates et leurs propres seuils. Confondre les deux est l'erreur la plus fréquente en paie ivoirienne.
## 1. Le calendrier social, CNPS
Périodicité, selon l'effectif : versement mensuel à partir de 20 salariés, trimestriel en dessous de 20.

Échéance : dans les 15 premiers jours qui suivent le mois ou le trimestre échu, accompagné de l'appel de cotisations.

Régularisation annuelle : la DISA, déclaration individuelle des salaires annuels, obligatoire en vertu de l'article 26 de la loi 99-477 du 02/08/1999 modifiant le Code de prévoyance sociale, au plus tard le 31 mars de l'année suivante, accompagnée de la DASC, déclaration annuelle des salaires et cotisations. La DISA se fournit sur support électronique non protégé en écriture ; la DASC signée et cachetée se dépose sur papier, quel que soit le mode de dépôt de la DISA.

⛔ La sanction du retard vaut d'être connue par cœur : pénalité de 10 % du montant total mensuel des cotisations dues, plus des sanctions administratives, dont la non-délivrance de l'attestation de mise à jour. Une attestation de mise à jour manquante bloque un marché public. C'est par là que le retard coûte le plus cher, pas par la pénalité.

Information continue : l'employeur informe immédiatement la CNPS de toute fermeture temporaire ou définitive, de tout départ par une fiche de cessation d'emploi, et de toute modification de la situation d'un travailleur, mariage, divorce, enfants.

Taux, assiette et affiliation : voir cnps/ et le LISEZ-MOI.md de cette base.
## 2. Le calendrier fiscal, DGI
Code général des impôts, art. 126. Les retenues d'impôt sur les traitements et salaires d'un mois se versent à la recette des Impôts dont dépend l'entreprise :

| Qui | Échéance |
| Contribuables au régime du réel | le 15 du mois suivant |
| Grandes et moyennes entreprises, industrielles, pétrolières et minières | le 10 du mois suivant |
| Grandes et moyennes entreprises, commerciales | le 15 du mois suivant |
| Grandes et moyennes entreprises, prestataires de services | le 20 du mois suivant |

Petits montants : si les retenues mensuelles n'excèdent pas 10 000 francs, le versement peut n'intervenir que dans les quinze premiers jours de juillet et de janvier pour le semestre écoulé ; mais dès qu'un mois dépasse 5 000 francs, tout ce qui a été retenu depuis le début du semestre se verse dans les quinze premiers jours du mois suivant.

Cession, cessation, décès : les retenues se versent immédiatement en cas de cession ou de cessation ; dans les quinze premiers jours du mois suivant en cas de décès de l'employeur.

État annuel des salaires (art. 127) : à déposer à la DGI, pour chaque personne occupée l'année précédente, au plus tard le 30 juin pour les entreprises soumises à certification par un commissaire aux comptes, le 30 mai pour toutes les autres, les particuliers et les associations. Il porte notamment le numéro CNPS du salarié, ce qui relie les deux administrations.

Tenue des documents (art. 125) : la paie doit enregistrer, par bénéficiaire, la date, la nature et le montant du paiement, l'évaluation des avantages en nature, le montant des retenues et la référence du bordereau de versement. Ces documents se conservent jusqu'à la fin de la troisième année suivant celle des retenues. Et une pièce justificative des retenues se délivre à chaque salarié.
## 3. Les portails de déclaration
- e-DISA, programme développé et mis gratuitement à disposition de tout employeur disposant d'un outil informatique. Il reprend les éléments de paie de l'année écoulée pour produire la DISA. Rappel : la DISA part sur support électronique, la DASC reste papier.
- La déclaration aux fins d'immatriculation se retire en agence CNPS ou sur cnps.ci.
- ⚠ La déclaration unique arrive, et elle n'est pas encore là. L'article 126-5° du Code général des impôts prévoit que chaque versement soit accompagné d'une déclaration unique de l'impôt sur les traitements et salaires et des cotisations sociales, mais précise que les employeurs n'y seront tenus qu'après l'opérationnalisation de la plateforme dédiée (loi 2023-1000 du 18/12/2023, annexe fiscale, art. 5). ⟦à surveiller : le jour où elle ouvre, le processus de paie change⟧
## 4. Le contrat de travail
Forme : le contrat se passe librement, dans les formes qui conviennent aux parties (convention de 1977, art. premier). Trois exceptions où l'écrit est obligatoire : le contrat à durée déterminée (Code, art. 14.2) · le contrat d'apprentissage, qui doit en outre être rédigé en langue française et est exempt de droits de timbre et d'enregistrement (art. 13.1) · dès qu'une période d'essai est prévue ou renouvelée (art. 14.5), le contrat est écrit ou constaté par une lettre d'embauche mentionnant la durée de l'essai.

⚠ En l'absence d'écrit, le contrat est réputé à durée indéterminée et l'engagement définitif dès le jour de l'embauche (convention, art. 13). Une embauche mal formalisée n'est pas une embauche fragile, c'est un CDI.

Mentions obligatoires : convention de 1977, art. 2, à relever ligne à ligne avant de bâtir un modèle. Date et lieu d'établissement, identité et domicile de l'employeur, identité complète du travailleur, et la suite.

Période d'essai, convention de 1977 art. 14, stipulée obligatoirement par écrit :

| Catégorie | Durée maximale |
| Ouvriers et employés payés à l'heure | 8 jours |
| Payés au mois | 1 mois |
| Agents de maîtrise, techniciens et assimilés | 2 mois |
| Ingénieurs, cadres et assimilés | 3 mois |
| Cadres supérieurs | 6 mois |

Renouvelable une seule fois. Pendant l'essai, chaque partie rompt sans indemnité ni préavis. Au-delà de deux mois, le renouvellement se notifie par écrit avant la fin de l'essai : 8 jours avant pour un essai de 2 mois, 15 jours pour 3 mois, 1 mois pour 6 mois. À défaut, l'employeur doit l'accord du travailleur ou une indemnité compensatrice du même nombre de jours de salaire.

⚠ Le Code renvoie la durée maximale de l'essai à un décret, non téléchargé. Les durées ci-dessus sont celles de la convention, applicables là où la convention s'applique.

Priorité de réembauche : le travailleur congédié pour suppression d'emploi ou compression la conserve deux ans dans la même catégorie d'emploi.
## 5. La durée du travail
40 heures par semaine pour tous les personnels, quels que soient leur sexe et leur mode de rémunération, dans les entreprises non agricoles. 2 400 heures par an dans les établissements agricoles et assimilés.

Équivalences pour le personnel occupé exclusivement à la surveillance ou au service d'incendie : 44 heures valent 40 heures effectives hors agriculture, 52 valent 48 dans l'agricole.

Aménagements : répartition sur 5 jours ouvrables · limitation à 6 h 40 par jour ouvrable · ou répartition inégale des 40 heures avec un maximum de 8 heures par jour.

⚠ Heures supplémentaires : les deux textes divergent, le Code bascule à la 46e heure et la convention à la 48e. Voir le LISEZ-MOI.md de cette base, section dédiée. Les heures 47 et 48 sont majorées à 50 % d'un côté et 15 % de l'autre.

Jours fériés : voir JOURS-FERIES.md, qui a été réécrit sur les décrets le 22/09/2026.
## 6. La santé au travail
Art. 43.1 : tout employeur doit assurer un service de santé au travail. Ce n'est pas une option et le texte ne pose aucun seuil d'effectif. Deux formes au choix : un service médical autonome interne, ou l'adhésion à un service médical interentreprises.

Art. 43.2, les prestations : la surveillance du milieu de travail, pour prévenir accidents du travail et maladies professionnelles, et la surveillance de la santé des travailleurs, qui comprend un examen médical des candidats à l'embauche et des salariés nouvellement embauchés. La visite d'embauche est donc une obligation de texte.

Effet de paie : en cas de maladie, les indemnités peuvent être versées par le service médical interentreprises auquel adhère l'employeur, sur les fonds provenant de la participation de ses adhérents.

L'organisme compétent en accident du travail et maladies professionnelles est l'ONATMP-CI.

⛔ Non renseigné, et il faut le dire au client : la périodicité des visites périodiques et le coût de l'adhésion à un service interentreprises. Ils relèvent de textes réglementaires et des tarifs des services, qui n'ont pas été téléchargés. ⟦à obtenir⟧
## 7. Le registre d'employeur
Art. 92.3 : tenu constamment à jour, au lieu de l'exploitation, selon un modèle fixé par voie réglementaire. Trois fascicules : le premier porte les renseignements sur les personnes et le contrat de tous les travailleurs occupés ; le deuxième, les indications sur le travail effectué, le salaire et les congés ; le troisième est réservé.

✅ La dispense qui intéresse une PME équipée : l'employeur peut être dispensé de produire les deux premiers fascicules s'il dispose d'un fichier électronique fiable et à jour.

Conservation : tenu sans déplacement à la disposition de l'inspecteur du travail, et conservé pendant les cinq ans suivant la dernière mention portée. Des décrets peuvent exempter certaines entreprises en raison de leur faible importance ou de la nature de leur activité.
## 8. Les affichages obligatoires
Relevés dans le Code, où ils sont dispersés. Une entreprise qui n'affiche rien est en défaut sur cinq points à la fois.

| Ce qui s'affiche | Où | Texte |
| La non-discrimination à l'embauche (art. 4) et la protection contre le harcèlement moral ou sexuel (art. 5), ainsi que leurs textes d'application | sur les lieux de travail et dans les locaux ou à la porte des locaux où se fait l'embauche | art. 7 |
| La durée et l'horaire de travail | sur les lieux de travail, et communiqués à l'inspecteur du travail | art. 21.1 |
| La durée hebdomadaire et l'horaire journalier, qui doivent en outre figurer au règlement intérieur | à un endroit accessible à tous les travailleurs | décret d'application, art. 6 |
| Les taux minima de salaires et les conditions de rémunération du travail à la tâche ou aux pièces | au bureau des employeurs et sur les lieux de paie | art. 31.6 |
| Le règlement intérieur | à une place convenable, aisément accessible, dans les lieux de travail et à la porte des lieux d'embauche, constamment tenu en bon état de lisibilité | règlement intérieur, art. 12 |
| Les accords de conciliation, sentences arbitrales et recommandations devenues exécutoires | au lieu de travail où est né le conflit | titre conflits collectifs |
## Ce que cette fiche ne couvre pas
- Le licenciement et le préavis, qui sont dans le LISEZ-MOI.md de cette base.
- Les taux de cotisation et le SMIG, même endroit.
- Les barèmes de l'impôt sur les salaires : ils vivent dans fiscalite-ci/, avec le Code général des impôts et l'annexe fiscale 2026.
- La périodicité et le coût de la médecine du travail, voir plus haut.
- Le modèle réglementaire du registre d'employeur, non téléchargé.
- Les conventions sectorielles, qui peuvent être plus favorables : voir conventions-sectorielles/.

À recontrôler le 22/03/2027, et à chaque annexe fiscale : les échéances de l'article 126 ont déjà bougé quatre fois depuis 2006.
