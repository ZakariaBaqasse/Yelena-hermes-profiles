---
id: Y0234
name: skills-matrix-l-d
description: "Cartographie les compétences d'une équipe, détecte les gaps, construit des plans de formation/montée en compétence par personne et par équipe."
bucket: C
tags: [Ressources Humaines]
version: 1
maj: 2026-09-09
---

# Skills Matrix & L&D

## Ce qu'il faut avoir sous la main
1. L'**équipe concernée** et les **rôles** visés.
2. Les **objectifs business**, ce vers quoi l'équipe doit monter en compétence.
3. *(optionnel)* le **niveau actuel connu** de chaque personne, si déjà évalué.


**Ce qu'elle suppose comme accès** : Registre central des entités, Génération d'export fichier (.xlsx/.csv), Tableur ou base de connaissance (type Google Sheets/Notion), Chaînage inter-skills (amont). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
- Définis les **compétences clés** pour les rôles visés (techniques/métier + transverses), regroupées par catégorie.
- Échelle de maîtrise claire (ex. 0 = aucune · 1 = notion · 2 = autonome · 3 = avancé · 4 = expert/référent) avec descripteurs.

### Étape 2 : Matrice & gaps

- **Matrice** : lignes = personnes (ou rôles), colonnes = compétences, cellule = niveau actuel vs **niveau cible**. Place des `[…]` pour les niveaux à renseigner, **rien d'inventé**.
- **Gaps** : écart cible − actuel ; repère les **compétences critiques sous-couvertes** (risque de bus factor / dépendance à une personne) et les forces à valoriser.

### Étape 3 : Plan de développement

- Par gap prioritaire : **action de dev** (formation, mentorat, projet stretch, lecture, pair-programming…), **format** (interne/externe, en ligne/présentiel), **échéance**, **mesure de succès**. Privilégie le **70-20-10** (terrain > social > formel) et les options low-cost adaptées à une petite structure au budget limité.
- Plan d'équipe : priorités, séquencement, budget indicatif en placeholders.

### Étape 4 : Livraison

- Matrice (tableau) + liste de gaps priorisés + plan d'actions. Option : **[connecteur à brancher : génération d'export fichier (.xlsx/.csv), si l'environnement de déploiement ne permet pas nativement de produire un fichier téléchargeable, sinon fournir le contenu structuré en clair]**.
- Si demandé : trame à maintenir dans un **[connecteur à brancher : tableur ou base de connaissance (type Google Sheets/Notion), persistance de la matrice/du plan entre deux sessions]** ; lien avec les évaluations de performance en amont (skill `performance-review-builder`, si disponible dans le même déploiement).

## Format de sortie
- **Livrable** : Cartographie les compétences d'une équipe, détecte les gaps, construit des plans de formation/montée en compétence par personne et par équipe.
- **Structure** : Markdown clair, titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ❌ Ne jamais inventer un niveau de compétence, un coût ou un organisme de formation : placeholders + recommandation de vérifier.
- 🎯 Actions concrètes, mesurables, réalistes pour une petite structure (privilégier mentorat/terrain quand le budget manque).
- ⚖️ Évaluation des compétences factuelle et liée au rôle ; non discriminatoire.
- 🌍 FR/EN.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Résolution du périmètre (optionnel : organisations multi-entités)

Si le périmètre concerne une équipe ou une entité précise au sein d'une organisation composée de plusieurs unités (portefeuille de participations, filiales, business units), résous ses ressources via **[datasource à brancher : registre central des entités, répertorie pour chaque équipe/entité les liens vers son référentiel de compétences existant, son organigramme, ses fiches de poste]**, filtré sur le nom exact de l'équipe/entité. Sinon, travaille directement au niveau de l'organisation dans son ensemble.
