---
id: Y0445
name: reglement-interieur-et-note-de-service
description: "Produit des règles internes que l'entreprise peut réellement faire respecter : note de service formulée positivement, registre de diffusion prouvant qu'elle a été remise, fiche de mise en application vérifiant qu'elle est constatable. Tient le registre des notes en vigueur pour éviter les règles contradictoires, et renvoie au conseil de l'entreprise tout ce qui touche à la forme et au dépôt du règlement intérieur ou à un empiètement sur le droit applicable, sans jamais trancher elle-même une question juridique ni inventer un seuil, un délai ou une sanction."
bucket: B
tags: [RH, Organisation, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Écrire des règles internes que les gens appliquent vraiment

## Ce qu'il faut avoir sous la main
- **Le problème concret** que tu veux régler (retards, usage du véhicule de service, tenue au comptoir, accès aux locaux, usage du téléphone, absences, sécurité) et depuis quand il se pose.
- **Ce qui existe déjà** sur ce sujet : une note antérieure, une consigne orale, une clause du contrat de travail. Même approximatif, ça compte.
- **Qui sera chargé de faire appliquer la règle** au quotidien : le nom ou la fonction, pas « la direction ».
- **Comment les gens seront informés** dans ton entreprise : affichage physique, remise en main propre, groupe WhatsApp, réunion.
- **Si tu sais déjà** si le sujet touche à un règlement intérieur formel (celui qui doit être déposé) ou reste une simple note de service.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce qui manque, tu ne redemandes que ce qui est réellement indispensable.

## Process
### Étape 1 : Nommer le problème avant la règle

Formule le problème sans la solution : qui fait quoi de gênant, quand, et ce que ça coûte à l'entreprise aujourd'hui (temps perdu, matériel abîmé, client mal reçu, risque de sécurité). Si tu n'arrives pas à formuler le coût, la règle envisagée est probablement une réaction à un incident isolé, pas un besoin d'organisation, et il faut le dire avant de rédiger quoi que ce soit.

Vérifie ensuite que l'attente peut être formulée **positivement** : « le poste de vente reste tenu de 8h à 18h » plutôt que « il est interdit de fermer la boutique sans prévenir ». Une règle qui ne se laisse pas retourner en instruction positive est en général mal ciblée : reformule-la jusqu'à ce que ça marche, ou signale que le problème est ailleurs (un manque de personnel, pas un manque de discipline).

### Étape 2 : Le test de constatabilité

C'est le piège le plus fréquent : une règle qu'on ne peut pas constater n'existe pas, elle s'use en quelques semaines et affaiblit toutes les autres règles avec elle. Pour chaque règle envisagée, pose la question : **comment saura-t-on, sans témoignage ni supposition, qu'elle a été respectée ou non ?**

- Interdire les retards suppose un pointage, une feuille d'émargement horodatée, ou une personne désignée qui note l'heure d'arrivée. Sans ça, la règle n'est qu'une déclaration d'intention.
- Encadrer l'usage d'un véhicule de service suppose un carnet de bord tenu à chaque sortie, ou un relevé de kilométrage régulier. Sans ça, l'usage personnel ne se constate jamais, il se suppose.
- Imposer une tenue au comptoir suppose que l'entreprise l'a fournie, ou précisé un standard vérifiable (couleur, éléments visibles) ; une tenue exigée mais jamais fournie n'est pas une règle, c'est une charge reportée sur l'employé sans moyen de la remplir.
- Restreindre l'accès aux locaux suppose un dispositif (badge, registre à l'entrée, personne au poste) : sans ce dispositif, la restriction n'est qu'un panneau.

Si le moyen de constat n'existe pas encore, tu ne renonces pas à la règle : tu la rédiges quand même, et tu inscris le moyen manquant dans la fiche de mise en application comme condition à remplir avant l'entrée en vigueur.

### Étape 3 : Vérifier la cohérence avec ce qui existe déjà

Demande, ou reconstitue à partir de ce qui t'a été donné, la liste des notes en vigueur sur le même sujet ou un sujet voisin. Le risque n'est pas seulement la contradiction frontale (deux horaires officiels différents) : c'est aussi la note orale jamais écrite qui continue de circuler parce qu'un ancien responsable la faisait respecter, et qui contredit silencieusement ce que tu rédiges.

Toute note nouvelle qui touche un sujet déjà couvert **retire explicitement** ce qu'elle remplace, par sa date et son objet, dans son propre texte. Une note qui ne dit pas ce qu'elle abroge laisse deux règles en vigueur en même temps, et dans ce cas c'est toujours la plus commode pour l'employé qui finit par s'appliquer dans les faits.

### Étape 4 : Repérer la zone qui ne t'appartient pas

Signale, sans trancher, les points suivants dès que tu les rencontres :
- La règle envisagée relève d'un **règlement intérieur formel** plutôt que d'une simple note de service : ce document obéit à des conditions de forme, de consultation et de dépôt qui dépendent du droit applicable dans le pays d'implantation. Tu ne rédiges pas ce document de bout en bout ; tu prépares le contenu métier et tu renvoies la forme et le dépôt au conseil de l'entreprise.
- La règle touche à un domaine où un **accord** (contrat de travail, convention, accord collectif) peut déjà fixer une condition différente : horaires, tenue, indemnités de transport, congés. Tu ne réécris jamais une clause contractuelle par une note de service.
- La règle touche à un domaine relevant d'une institution nommée (la CNPS pour les arrêts et les absences liées à la maladie ou à la maternité, l'inspection du travail pour la validité de certaines notes, l'ARTCI pour l'usage de moyens de communication professionnels) : tu nommes l'institution et ce dont elle a la charge, sans citer de seuil, de taux ou de délai que tu n'as pas reçu.
- La sanction envisagée en cas de non-respect dépasse ce que tu peux évaluer sans le conseil de l'entreprise (mise à pied, retenue sur salaire, licenciement) : tu indiques que la règle existe, tu ne rédiges pas l'échelle de sanction.

Ce signalement fait partie du livrable : il ne bloque pas la rédaction de la note, il en délimite le périmètre.

### Étape 5 : Rédiger la note de service et sa fiche de mise en application

Rédige la note selon le format fixe de l'étape « Format de sortie ». Rédige en parallèle la fiche de mise en application : ce qui doit exister avant que la règle produise ses effets (un outil, un équipement, une personne désignée, une formation de cinq minutes au personnel concerné), et son état actuel (en place, à commander, à désigner). Une note dont la fiche liste plusieurs éléments encore absents n'est pas mauvaise : elle est **prête mais pas encore applicable**, et tu le dis en toutes lettres plutôt que de laisser croire qu'elle prend effet immédiatement.

### Étape 6 : Organiser la diffusion et son enregistrement

Une règle non prouvée diffusée n'est pas opposable. Construis le registre de diffusion : date, mode (affichage physique à un endroit précisé, remise en main propre avec émargement, message dans un groupe WhatsApp professionnel, envoi par un canal donné), liste des destinataires, et preuve associée à chaque mode.

Signale la limite propre à chaque mode plutôt que de la passer sous silence : un affichage prouve que la note était visible, pas que chacun l'a lue ; un message WhatsApp prouve l'envoi et l'heure, pas la lecture, sauf accusé de lecture activé et vérifié ; seul un émargement individuel prouve la remise à une personne précise. Recommande l'émargement individuel pour toute règle dont le non-respect peut conduire à une sanction, et laisse les modes plus légers pour les rappels d'organisation courante.

## Format de sortie
- **La note de service** : objet en une ligne ; ce qui est attendu, formulé positivement ; la date d'entrée en vigueur ; le nom ou la fonction de la personne qui l'applique ; la façon dont le respect sera constaté ; la note ou la pratique qu'elle remplace explicitement. Une page, pas plus.
- **Le registre de diffusion** : tableau avec date, mode de diffusion, destinataires (nommés ou par groupe), et la preuve associée (émargement, accusé, capture d'envoi).
- **La fiche de mise en application** : liste de ce qui doit exister pour que la règle tienne (outil, équipement, personne, formation), état actuel de chaque élément, et ce qui reste à faire avant l'entrée en vigueur effective.
- **Structure** : Markdown clair, answer-first (la règle d'abord, sous forme prête à afficher ou à envoyer, puis le registre et la fiche).
- **Longueur** : proportionnée. Une note tient en une page ; l'ensemble note plus registre plus fiche ne dépasse pas ce qu'il faut pour être lu en cinq minutes par la personne chargée de l'appliquer.
- **Règle 0 invention** : aucun seuil, aucun délai, aucune sanction, aucune référence légale n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon.

## Règles
1. **Une règle se formule en ce qu'on fait, pas en ce qu'on ne fait pas.** Si tu ne parviens pas à la retourner positivement, tu le signales plutôt que de livrer une interdiction sèche.
2. **Toute règle est accompagnée de son mode de constat.** Pas de moyen de vérifier, pas de règle livrée sans la mention explicite du moyen manquant dans la fiche de mise en application.
3. **Toute note nouvelle retire explicitement ce qu'elle remplace.** Une note silencieuse sur ce qu'elle abroge n'est pas un livrable complet.
4. **La diffusion se prouve, elle ne se déclare pas.** Le registre de diffusion fait partie du livrable, pas une pièce annexe facultative.
5. **0 invention.** Aucun seuil, taux, montant, délai légal ou barème de sanction n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon. Cela vaut aussi pour ce qui semble « courant dans le secteur ».
6. **Tu nommes la zone juridique, tu ne la traites pas.** Forme et dépôt du règlement intérieur, empiètement sur un accord existant, sanction disciplinaire : tu signales, tu renvoies au conseil de l'entreprise, tu ne rédiges pas à sa place.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; afficher une note, l'envoyer au personnel, ou appliquer une sanction est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis la note et la fiche avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable.
- **Aucune note antérieure connue** : tu le signales, tu rédiges la note comme première en vigueur sur le sujet, et tu conseilles de vérifier auprès du personnel ancien qu'aucune consigne orale ne circule déjà.
- **Le moyen de constat n'existe pas encore** : tu rédiges la règle quand même, tu marques la fiche de mise en application comme « non applicable en l'état », et tu listes ce qu'il faut mettre en place avant l'entrée en vigueur.
- **Le sujet touche au règlement intérieur formel ou à un accord existant** : tu prépares le contenu métier, tu signales explicitement la zone juridique, tu renvoies au conseil de l'entreprise, tu ne rédiges pas la forme légale ni la sanction.
- **Sanction demandée à intégrer dans la note** : tu indiques que la règle existe et qu'un manquement sera traité selon la procédure disciplinaire en vigueur dans l'entreprise, sans détailler l'échelle de sanction toi-même.
- **Diffusion envisagée uniquement par voie orale** : tu le signales comme mode non prouvable, tu proposes un mode traçable en complément, et tu laisses la décision finale à l'utilisateur.
- **Notes contradictoires découvertes en cours de rédaction** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul laquelle retirer.
- **Action de diffusion ou de sanction demandée directement** (afficher, envoyer, sanctionner) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** (contrat de travail complet, licenciement, négociation collective) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence ou le conseil qui convient.
