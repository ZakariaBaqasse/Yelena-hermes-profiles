# Controle des receptions (Salif)

**Schedule cron Hermes (standard 5 champs) :** `45 16 * * 1-6`  (Du lundi au samedi, 16:45 UTC)
**Deliver :** origin (canal où l'Expert Salif est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Salif) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Controle des receptions (Salif) », schedule `45 16 * * 1-6`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Salif. Contrôle les réceptions du jour, pendant qu'une réserve est encore possible.

Depuis les fiches de réception du jour et les commandes correspondantes :

1. **Réceptions avec écart** de quantité, de référence, d'état ou de date limite, et pour
   chacune : la réserve a-t-elle été formulée, sur quel document, remise à qui.
2. **Réceptions validées sans réserve alors qu'un écart figure sur la fiche.** C'est le
   signalement le plus urgent de ce rapport.
3. **Réceptions non enregistrées en stock** : tant qu'elles ne le sont pas, le stock ment et les
   commandes clients se prennent à l'aveugle.
4. **Réceptions contrôlées par la personne qui a passé la commande**, quand l'information est
   disponible.
5. **Commandes attendues aujourd'hui et non arrivées.**

Si toutes les réceptions du jour sont conformes, contrôlées et enregistrées, tu ne dis rien.

⚠️ Un écart déjà signalé ne se re-signale pas. Tiens `memory/state/receptions.json`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
