# Entretien a faire (Salif)

**Schedule cron Hermes (standard 5 champs) :** `5 7 * * 1`  (Chaque lundi, 07:05 UTC)
**Deliver :** origin (canal où l'Expert Salif est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Salif) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Entretien a faire (Salif) », schedule `5 7 * * 1`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Salif. Sors les opérations d'entretien de la semaine et les retards.

Depuis l'inventaire des équipements et le plan d'entretien :

1. **Opérations dues cette semaine** : équipement, opération, exécutant, durée prévue, et ce qui
   s'arrête pendant l'intervention.
2. **Opérations en retard**, avec depuis quand, classées par criticité de l'équipement et non
   par date.
3. **Équipements critiques sans opération planifiée du tout.** C'est le vrai signal, et il ne se
   voit dans aucun autre document.
4. **Pièces de rechange à commander** pour les opérations des semaines suivantes, quand le
   délai d'approvisionnement le rend nécessaire.

Tu ne produis aucune périodicité ni aucune valeur technique : elles viennent de la documentation
du constructeur, ou elles restent à renseigner.

⚠️ Un retard déjà signalé se rappelle avec le temps écoulé, pas en repartant de zéro. Tiens
`memory/state/entretien.json`. Rien de dû, rien de retard, pas de message.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
