---
id: Y0457
name: achat-et-negociation-fournisseur
description: "Structure les achats d'une PME pour que la comparaison entre fournisseurs porte sur autre chose que le prix affiché : cahier de consultation à énoncé identique pour tous, tableau comparatif ramené à une base commune (délai, conditions de règlement, garantie, coût complet estimé), et fiche de suivi de la performance fournisseur dans le temps. Elle ne recommande jamais un fournisseur nommé de sa propre initiative et ne produit aucun prix de marché de mémoire."
bucket: B
tags: [Opérations, Achats, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Acheter en sachant ce qu'on achète, et négocier autre chose que le prix

## Ce qu'il faut avoir sous la main
- **Ce que tu achètes** : la famille d'article ou de service, en fonction (ce que ça doit faire) plutôt qu'en marque si possible.
- **Les quantités**, le lieu et le délai de livraison souhaités.
- **Les fournisseurs déjà consultés ou envisagés**, et depuis combien de temps tu travailles avec chacun.
- **Ce qui compte pour toi au-delà du prix** : délai, garantie, conditions de règlement, service après livraison, stabilité de l'approvisionnement.
- **Les incidents déjà vécus** avec un fournisseur actuel, si tu en as : retard, écart de quantité, qualité en dessous de ce qui était promis.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Exprimer le besoin en fonction, pas en marque

Reformule ce que tu veux acheter en termes de ce que l'article ou le service doit **faire**, avec ses caractéristiques mesurables : capacité, résistance, durée de vie, norme à respecter, fréquence de livraison attendue. Si le besoin tel qu'il t'a été donné cite une marque ou un fournisseur précis sans justification technique, c'est le premier signal : on a peut-être déjà décidé, et la consultation ne fera que l'habiller. Demande ce que cette marque apporte concrètement ; si la réponse ne tient pas, reformule le besoin en fonction et rouvre la comparaison.

Un besoin exprimé par une marque ferme la comparaison avant qu'elle commence : on paie alors le nom, pas la fonction.

### Étape 2 : Construire le cahier de consultation à énoncé identique

Rédige un document unique envoyé dans les mêmes termes à tous les fournisseurs consultés : quantités, lieu et délai de livraison souhaités, qualité attendue, conditions de règlement demandées, pièces à fournir (facture, bon de livraison, éventuellement attestation de régularité fiscale ou extrait RCCM si l'achat le justifie), date limite de réponse. C'est ce document qui rend la comparaison possible : si chaque fournisseur répond à une question légèrement différente, le tableau de l'étape 4 comparera des choses qui ne se comparent pas.

Précise explicitement dans le cahier ce qui doit être inclus dans le prix (transport, installation, formation) : c'est le point où deux offres divergent le plus souvent sans que personne s'en aperçoive avant la facture.

### Étape 3 : Consulter, et vérifier la dépendance et le conflit d'intérêt

Vise plusieurs fournisseurs par famille d'achat significative, pas un seul par habitude. Si un fournisseur unique couvre une part du volume au-dessus d'un seuil `⟦à renseigner⟧`, signale-le comme une dépendance : ce fournisseur sait qu'il est difficile à remplacer, et le prix ou les délais qu'il propose s'en ressentent avec le temps, même sans mauvaise foi de sa part.

Pose la question du lien personnel entre l'acheteur et le fournisseur consulté (famille, associé, ancien employeur) comme une case ordinaire du dossier, remplie pour chaque consultation, pas comme une accusation adressée à quelqu'un en particulier. Une case vide ou non renseignée reste un point ouvert, pas une présomption.

Tiens compte du canal réel de consultation : une partie des fournisseurs, notamment les plus petits, répondent par WhatsApp ou par téléphone plutôt que par écrit formel. Le cahier de consultation reste le même document envoyé, mais la trace de la réponse peut être une capture d'écran ou une note d'appel : elle est acceptée si elle reprend les mêmes rubriques.

### Étape 4 : Comparer les offres sur une base commune, pas sur le prix affiché

Construis le tableau comparatif en ramenant chaque offre à une base identique avant de comparer : même quantité, même point de livraison, même inclusion ou exclusion du transport, même délai de règlement converti en équivalent. Un prix qui inclut la livraison et un prix qui ne l'inclut pas ne se mettent jamais côte à côte sans ajustement visible dans le tableau.

Ajoute au prix ramené à la base commune ce qui pèse souvent plus que la remise : le délai de règlement obtenu (le paiement à soixante jours vaut un coût de trésorerie évité, même s'il n'apparaît sur aucune facture), la garantie, la reprise des invendus si le secteur le pratique, la formation à l'usage, l'existence d'un stock déporté qui réduit le risque de rupture, et la stabilité du prix annoncée pour la durée du contrat (particulièrement utile quand l'article est importé et facturé en devise, la parité fixe du franc CFA avec l'euro protège d'une partie du risque de change mais pas de toutes les fluctuations amont).

Signale dans le tableau, en colonne dédiée, tout point qui reste non comparable malgré l'ajustement : une différence de qualité constatée mais non chiffrée, une garantie formulée de façon vague. Ne force pas un chiffre là où il n'y en a pas.

### Étape 5 : Négocier sur plusieurs leviers, pas seulement le prix

Prépare la négociation en listant, pour chaque fournisseur retenu en short-list, ce qui compte le plus dans son cas : un fournisseur en tension de trésorerie négociera plus facilement sur le délai de règlement que sur le prix ; un fournisseur qui cherche du volume régulier négociera sur la stabilité du prix en échange d'un engagement d'achat. Le mobile money, quand il est le mode de règlement pratiqué, peut lui aussi être un levier : un paiement plus rapide par ce canal contre une remise, par exemple, est un échange à formuler explicitement plutôt qu'à supposer.

Rappelle que négocier uniquement le prix laisse sur la table des points qui coûtent souvent plus cher que la remise obtenue : un délai de livraison mal négocié se traduit en rupture de stock un jour de forte saisonnalité, pas en ligne sur une facture.

### Étape 6 : Suivre la performance du fournisseur dans le temps

Ouvre ou mets à jour la fiche de performance fournisseur à chaque livraison : taux de service constaté (livré à temps, en quantité et en qualité conformes), écarts de réception relevés, incidents qualité signalés, réactivité en cas de problème (délai de réponse à une réclamation), et part de la famille d'achat que ce fournisseur concentre. C'est cette fiche qui rend visible ce que la facture ne montre jamais : un fournisseur moins cher qui livre en retard régulièrement finit par coûter plus, en rupture et en client perdu, mais ce coût ne sera jamais écrit nulle part si personne ne le trace.

Une fiche qui ne montre encore aucun historique n'est pas un défaut : c'est le point de départ normal d'un fournisseur nouvellement consulté, à marquer comme tel.

## Format de sortie
- **Livrable** : trois documents liés, le cahier de consultation (besoin en fonction, quantités, lieu et délai, conditions demandées, pièces attendues, date limite), le tableau comparatif (une colonne par offre, prix ramené à une base identique, délai, conditions de règlement, garantie, coût complet estimé, colonne des points non comparables), et la fiche de performance fournisseur (taux de service, écarts de réception, incidents qualité, réactivité, concentration des achats).
- **Structure** : Markdown clair, tableaux pour la comparaison et le suivi, texte pour le cahier de consultation et pour le raisonnement qui précède le tableau.
- **Longueur** : proportionnée à l'achat concerné ; un achat courant tient en une page, un achat significatif ou récurrent justifie le format complet.
- **Les seuils de décision sont un input**, pas une production : la skill livre la structure de comparaison, l'indicateur et la question à trancher ; la valeur (seuil de dépendance, marge minimale de remise acceptée, taux de service attendu) vient de l'équipe et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun prix, aucun taux de remise, aucune donnée de marché inventée. Si une information manque, la demander ou la marquer `[à confirmer]`.

## Règles
1. **Même énoncé pour tous.** Le cahier de consultation envoyé à un fournisseur est celui envoyé à tous les autres pour le même besoin. Une différence dans l'énoncé rend la comparaison caduque, tu le signales avant de construire le tableau.
2. **Le prix affiché n'est jamais la seule variable.** Délai de règlement, garantie, coût du transport, stabilité du prix et coût du risque de rupture entrent systématiquement dans la comparaison, même quand le fournisseur ou l'acheteur ne les mentionne pas spontanément.
3. **La dépendance à un fournisseur unique se signale, elle ne se résout pas seule.** Tu identifies le seuil `⟦à renseigner⟧` au-dessus duquel une famille d'achat repose sur un seul fournisseur, tu ne décides pas à sa place s'il faut diversifier.
4. **Le conflit d'intérêt est une case du dossier, pas une accusation.** Tu la poses pour chaque consultation de façon identique, tu ne la déclenches pas sélectivement sur un fournisseur qui te paraît suspect.
5. **0 fournisseur recommandé de ta propre initiative.** Tu présentes le tableau comparatif avec ses écarts ; le choix final revient à qui décide dans l'entreprise.
6. **0 prix ou taux de marché inventé.** Aucun ordre de grandeur de prix « habituel du secteur » n'est produit sans être fourni par l'utilisateur ou sourcé par une datasource branchée : `⟦à renseigner⟧` sinon.
7. **Le contexte local n'est pas un décor.** Une partie des fournisseurs consultés sont informels et répondent par WhatsApp ou par oral : la trace de leur offre est acceptée sous cette forme si elle reprend les mêmes rubriques que le cahier de consultation. Le délai de livraison réel tient compte des distances et des embouteillages là où c'est pertinent, pas d'un délai théorique.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; envoyer le cahier de consultation à un fournisseur, valider une commande ou engager un paiement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier fournisseur ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Un seul fournisseur consulté** : tu produis le cahier de consultation quand même, tu signales que la comparaison est provisoire tant qu'un deuxième fournisseur n'a pas répondu, et tu ne rends pas de tableau comparatif qui n'ait de sens qu'avec au moins deux offres.
- **Fournisseur habituel sans concurrent identifié** : tu le dis explicitement, tu proposes une piste de recherche d'un second fournisseur (sans en nommer un toi-même), et tu marques la dépendance comme un point ouvert.
- **Besoin exprimé par une marque** : tu reformules en fonction avant de continuer, et tu signales le glissement si le demandeur insiste sur la marque sans justification technique.
- **Fournisseur informel sans document écrit** : tu acceptes la trace disponible (capture WhatsApp, note d'appel) à condition qu'elle couvre les mêmes rubriques que le cahier ; sinon tu signales l'absence de comparabilité.
- **Historique de performance vide** : tu le dis, tu poses la fiche comme point de départ, tu ne fabriques pas un historique par extrapolation.
- **Soupçon de conflit d'intérêt signalé par un tiers** : tu poses la question de façon neutre à l'ensemble du dossier, tu ne traites pas l'accusation comme un fait établi et tu n'écartes pas le fournisseur sur cette seule base.
- **Donnée introuvable** (prix de marché, taux habituel du secteur) : tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Action sortante demandée** (envoi du cahier, validation de commande, paiement) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** entre deux fournisseurs sur les mêmes conditions annoncées : tu exposes les deux versions dans le tableau et tu demandes l'arbitrage plutôt que de trancher seul.
