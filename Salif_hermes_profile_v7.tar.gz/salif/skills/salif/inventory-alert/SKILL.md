---
id: Y0176
name: inventory-alert
description: "Surveille les niveaux de stock d'une startup à partir de ses Google Sheets (Inventaire/Ventes/Fournisseurs/Devis), détecte les alertes (OK/Attention/Critique/Rupture) et les variations de prix fournisseur, calcule les quantités à réapprovisionner, génère un tableau de bord interactif 3 onglets brandé et déclenche alertes équipe + bons de commande fournisseurs, sans jamais inventer un niveau de stock, un prix ou une donnée absente des sources."
bucket: C
tags: [Ops]
version: 1
maj: 2026-09-09
---

# Inventory Alert

## Ce qu'il faut avoir sous la main
- Le **nom de la startup**
- Si tu l'as sous la main, le **lien vers le Google Sheet Inventaire** (sinon je le cherche moi-même dans les sources connectées)

Je lis d'abord tout ce qui est déjà disponible (seuils, sheets, emails, branding) et je ne te demande, en un seul message groupé, que ce qu'il manque vraiment. Dès que j'ai de quoi produire, je génère directement le tableau de bord.

## Process
### Étape 1 : Croiser les sources
Inventaire, ventes, fournisseurs, devis. Un stock lu sans les ventes ne dit rien de l'urgence : c'est la vitesse d'écoulement qui fait l'alerte.

### Étape 2 : Calculer les niveaux d'alerte
Pour chaque produit : jours de couverture restants au rythme observé, puis classement en normal, attention, critique ou rupture. Les seuils utilisés sont affichés.

### Étape 3 : Détecter les variations de prix fournisseur
Écarts entre les derniers devis et les prix de référence, en valeur et en pourcentage. Une hausse silencieuse ronge la marge sans qu'on la voie.

### Étape 4 : Calculer les réapprovisionnements
Quantités à commander en tenant compte du délai fournisseur et du minimum de commande. Une quantité proposée sans délai fournisseur est signalée comme provisoire.

### Étape 5 : Préparer les envois
Tableau de bord, alertes équipe et bons de commande, présentés pour validation, jamais envoyés directement au fournisseur.

## Format de sortie
**Étape 1, Validation.** Résumé par statut + sheets croisés + variations prix détectées. Demande : **« Voici les [X] produits analysés ([N] sheets croisés). Procéder ? (Oui/Non) »**

**Étape 2, Branding.** (1) Cherche d'abord dans `[datasource à brancher : dossier Drive « Projet IA, [Client] »]` et `[datasource à brancher : base « Clients »]`. Si la page branding ne contient que des images (pas de hex) : scraper automatiquement le site du client via `[connecteur à brancher : recherche web]` (limité à la zone visible de l'écran) sans demander l'URL. (2) Si la recherche web retourne vide : naviguer directement sur le site sans confirmation. (3) Si aucun branding trouvable après ces étapes : **« Branding introuvable pour [Client]. A, Logo (PNG/SVG) ou URL du site | B, Style par défaut du programme (#1A1A2E / #E94560). »**

**Étape 3, Tableau de bord interactif 3 onglets.** Composant avec navigation par onglets en haut. Appliquer les couleurs de la startup sur tous les onglets.

**Onglet 1, **📦** Stock actuel :**

**Onglet 2, **📈** Historique & Tendances :**

**Onglet 3, ** 🏭 **Performance Fournisseurs :** A) Tableau par fournisseur : Fournisseur, Email, Nb commandes passées, Taux de conformité livraison (Qté reçue/Qté commandée × 100, badge 🟢 >95% / 🟡 80-95% / 🔴 <80%), Délai moyen réel (jours), Délai prévu (jours), Ponctualité (badge 🟢/🟡/🔴), Dernière variation de prix, Date dernière commande. Tri par défaut : Taux de conformité ↑ (les moins fiables en premier). B) Mini alerte si fournisseur <80% : 🔴 *[Fournisseur], taux de conformité faible sur les [N] dernières commandes. Envisager un fournisseur alternatif.*

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Configuration par startup

Vérifie d'abord si des préférences existent déjà dans `[connecteur à brancher : mémoire de session, préférences de configuration déjà enregistrées pour ce client (seuils, emails, branding)]`. Si oui, affiche-les et demande confirmation. Sinon, procède à la configuration manuelle. Recherche le contexte via `[datasource à brancher : base « Clients » du portefeuille du fonds]`, `[datasource à brancher : dossier Drive « Projet IA, [Client] »]` et `[connecteur à brancher : recherche web]` si nécessaire.

Avant de poser des questions, consulte le Google Sheet Inventaire (`[datasource à brancher : dossier Drive « Projet IA, [Startup] »]`) si accessible. Lis automatiquement les types de produits, seuils, emails et fournisseurs déjà présents, **ne pose pas ce qui peut être lu depuis le Sheet**. Pour les informations trouvées, affiche-les et demande confirmation. Pose uniquement les questions manquantes, regroupées en un seul message :

- **Type de produits** gérés en stock *(uniquement si non trouvé dans le Sheet Inventaire)*
- **Seuil d'alerte** et **seuil critique** *(uniquement si non trouvés dans le Sheet, défaut : 20 et 10)*
- **Source des données** : Google Sheets dans le dossier « Projet IA, [Startup] », saisie manuelle ou upload
- **Emails, 3 canaux en une seule fois :** 🚨 Alertes équipe, 📊 Rapport équipe, 🏭 Fournisseurs (cherche dans les datasources Notion/Drive d'abord)
- **Slack (optionnel) :** *« Souhaitez-vous les alertes aussi sur Slack ? (Oui/Non) »* Si Oui : *« Configurez `[connecteur à brancher : Slack]`, puis donnez : channel alertes (ex : #inventaire-alertes) + channel rapport (ex : #inventaire-rapport) »*
- **Calendrier** : lundi 8h par défaut, modifiable via `[connecteur à brancher : planification récurrente]`
- **Branding (obligatoire avant de générer le tableau de bord) :** 1. Cherche d'abord le logo et les couleurs dans `[datasource à brancher : dossier Drive « Projet IA, [Client] »]` et `[datasource à brancher : base « Clients »]`. 2. Si la page branding ne contient que des images (aucun code hex en texte) : NE PAS demander l'URL, utiliser automatiquement `[connecteur à brancher : recherche web]` sur le site du client (URL récupérée depuis la mémoire ou la base). Lors de toute navigation sur le site pour extraction de couleurs, se limiter à la zone visible de l'écran (viewport). 3. Si la recherche web retourne un résultat vide sur une requête branding : basculer **automatiquement** vers une navigation directe sur le site, sans attendre confirmation. 4. Si aucun branding trouvable : utiliser la charte du client par défaut (#1A1A2E / #E94560). Appliquer dans le tableau de bord : couleur primaire (header, boutons actifs), couleur secondaire (accents, badges), logo en haut à gauche. **Ne jamais générer le tableau de bord sans avoir résolu le branding.**

### Source des données : Multi-sheets

Liste TOUS les Google Sheets dans `[datasource à brancher : dossier Drive « Projet IA, [Startup] »]`. Identifie leur rôle :

- 📦 **Inventaire/Stock**, source principale. Colonnes **requises** : `produit`, `sku`, `categorie`, `stock_actuel`, `seuil_alerte`, `seuil_critique`, `fournisseur`, `email_fournisseur`, `delai_reappro_jours`, `prix_unitaire`, `devise`, `date_derniere_maj`. Colonnes recommandées : `consommation_hebdo`. Colonnes pertes/défauts : `stock_defaillant` (qte inutilisable, déduite du stock vendable), `motif_defaillance` (casse / péremption / vol / retour_défaut / autre).
- 💰 **Ventes/Commandes/Sorties**, Colonnes **requises** : `date`, `produit` ou `sku`, `quantite_sortie`, `type_mouvement` (valeurs attendues : `vente` | `perte` | `casse` | `vol` | `retour_fournisseur` | `ajustement`). Utilisé pour : consommation moyenne, calcul jours avant rupture, et suivi des pertes distinctement des ventes.
- 🏭 **Fournisseurs/Catalogue**, Colonnes **requises** : `fournisseur`, `email`, `produit` ou `sku`, `prix_catalogue`, `delai_livraison_jours`. Optionnelles : `conditions_paiement`, `contact_nom`.
- 📋 **Devis/Projets/Déploiements**, Colonnes **requises** : `produit` ou `sku`, `quantite_engagee`, `statut` (Actif/Clôturé). Ne lire que statut = Actif pour déduire les engagements.
- 📅 **Historique** (*créé par l'agent*) : `date_snapshot`, `produit`, `sku`, `stock_actuel`, `stock_defaillant`, `pertes_periode`, `statut`, `prix_unitaire`, `valeur_stock`.
- 🔬 **Performance_Fournisseurs** (*créé par l'agent*) : `fournisseur`, `date_commande`, `qte_commandee`, `qte_recue`, `ecart`, `delai_reel_jours`, `prix_unitaire_commande`, `taux_conformite`.

Cross-référencement via clé SKU/produit (insensible à la casse). Dégrader gracieusement si un sheet est absent, ne jamais bloquer, mais **toujours signaler** les données manquantes. **Fallback stock actuel :** Si le sheet Inventaire ne contient pas de colonne `stock_actuel` fiable (absente, vide ou non mise à jour), recalculer depuis le dossier Drive : *Stock actuel = Stock initial + Σ(Bons de commande reçus) − Σ(Ventes/Sorties)*, en cherchant ces données dans les sheets Bons de commande et Ventes/Sorties du dossier « Projet IA, [Startup] ». Indiquer clairement que le stock est **calculé par reconstitution** (non lu directement) et afficher le détail du calcul par produit. **Si aucune source de reconstitution n'est disponible** : afficher « ⚠️ Stock indéterminable, données insuffisantes » et demander à l'utilisateur de fournir la donnée manquante.

### Vérification variation de prix

Lors de chaque analyse, compare le `prix_unitaire` actuel dans le Sheet Inventaire avec le dernier prix enregistré dans le sheet **Historique** pour ce produit. Si delta > 5% : afficher badge 📈 **Prix +X%** (rouge si hausse) ou 📉 **Prix -X%** (vert si baisse) dans le tableau du dashboard. Si delta > 15% : déclencher une alerte dédiée dans le rapport équipe : **« ⚠️ Variation de prix significative détectée : [Produit] +X% vs dernière commande ([Fournisseur]). »**

### Niveaux d'alerte stock

1. ✅ **OK** (stock > seuil alerte) : aucune action, vert.
2. **⚠️ Attention** (entre seuils) : dashboard + rapport.
3. 🔴 **Critique** (stock ≤ seuil critique, >0) : alerte immédiate + bon de commande.
4. ⛔ **Rupture** (stock = 0) : alerte urgente + bon de commande prioritaire.

### Propositions de réapprovisionnement

**Priorité 1, Délai d'écoulement historique :** Si le sheet Ventes contient ≥ 2 lots antérieurs de quantité similaire (±30% de la quantité actuelle) : calculer le délai moyen réel d'écoulement (*jours entre entrée en stock et rupture/épuisement*) et utiliser ce délai pour estimer la fréquence et la quantité à commander. Afficher : *« Délai d'écoulement moyen (lots similaires) : [N] jours, basé sur [X] lots historiques. »* **Priorité 2, Consommation hebdomadaire :** Si historique insuffisant (< 2 lots) : *Qté = consommation hebdo × délai fournisseur (semaines) + seuil alerte*. **Priorité 3, Fallback :** Si aucune donnée de vente disponible : *Qté = (Seuil alerte × 2) − Stock actuel*. Dans tous les cas : si devis en cours, ajouter les quantités engagées. Afficher la logique utilisée et demander confirmation.

### Les 3 canaux de communication

**Type 1, ** 🚨 **Alertes immédiates :** `[connecteur à brancher : envoi email]` + `[connecteur à brancher : Slack]` si configuré. Format Slack : 🚨 **[Startup]*, [X] critique(s)/[Y] rupture(s), [Produit] : [N] unités / Fournisseur : [F] / Qté suggérée : [Q]*. Objet email : 🚨 *[Startup], Alerte stock [X]+[Y], [Date]*.

**Type 2, ** 📊 **Rapport hebdomadaire :** email brandé + Slack résumé avec lien vers le tableau de bord. Structure : logo → 6 KPIs → lien dashboard → tableau → bons commande → alertes prix. Objet : 📦 *[Startup], Rapport inventaire | Semaine du [date]*.

**Type 3, ** 📤 **Bons de commande fournisseurs :** 1 email par fournisseur regroupant tous ses produits. Objet : 📋 *[Startup], Bon commande [N] réf., [Date]*.

Pour chaque canal : aperçu + confirmation avant envoi.

### Adaptation par secteur : Templates

Dès la startup identifiée, appliquer le template :

📱 **Entreprise A, Électronique reconditionnée :** colonnes `etat_produit` (Neuf/Grade A/B/C), `marque`, `modele`, `capacite_stockage`, `couleur`. Cross-sheets : Stock ↔ Ventes ↔ Catalogue. Règle : Grade A Critique = priorité absolue.

🥦 **Entreprise B, Produits frais :** colonnes `date_limite_consommation`, `temperature_stockage`, `unite_mesure`, `origine_producteur`. Cross-sheets : Stock ↔ Commandes clients ↔ Producteurs. Règle : alerte *Risque perte* si la **Date Limite de Consommation** est inférieure à 3 jours ET que le stock est supérieur à 0. Ne jamais abréger : toujours écrire **Date Limite de Consommation** en toutes lettres.

**🏗️ Entreprise C, Matériaux :** colonnes `unite_mesure` (m²/m³/tonne/sac), `emplacement`, `poids_unitaire`. Cross-sheets : Stock ↔ Devis en cours ↔ Fournisseurs. Règle : déduire les devis actifs du stock disponible.

⚡ **Entreprise D, Mobilité électrique :** colonnes `type_equipement`, `numero_serie`, `etat`, `cycles_restants`. Cross-sheets : Équipements ↔ Parc actif ↔ Maintenance. Règle : stock dispo = total − déployés − maintenance. Alerte si cycles_restants < seuil.

💳 **Entreprise E / Entreprise F, Équipements FinTech :** colonnes `type_equipement`, `operateur`, `statut_logistique` (En stock/Déployé/SAV). Cross-sheets : Équipements ↔ Déploiements ↔ SAV. Règle : seul « En stock » compte.

💻 **Entreprise G / Entreprise H / Entreprise I, FinTech digital :** colonnes `type`, `assigne_a`, `date_acquisition`, `garantie_expire_le`. Règle : alerte si garantie < 30 jours.

### Sauvegarde historique

Après chaque analyse validée, sauvegarder un snapshot dans le sheet **Historique** via `[connecteur à brancher : Google Sheets, écriture]`. Colonnes à écrire : `date_snapshot`, `produit`, `sku`, `categorie`, `stock_actuel`, `statut`, `prix_unitaire`, `valeur_stock`. Si le sheet Historique n'existe pas encore dans le dossier Drive, affiche : **« ⚠️ Sheet Historique non trouvé dans Projet IA - [Startup]. Souhaitez-vous que je crée le premier snapshot dans un nouveau sheet ? (Oui/Non) »**

### Suivi performance fournisseurs

Après chaque confirmation de réception (colonnes `qte_commandee` et `qte_recue` renseignées), mettre à jour le sheet **Performance_Fournisseurs** via `[connecteur à brancher : Google Sheets, écriture]` : `fournisseur`, `date_commande`, `qte_commandee`, `qte_recue`, `ecart`, `delai_reel_jours`, `prix_unitaire_commande`. Recalculer automatiquement le `taux_conformite` = moyenne des (qte_recue/qte_commandee) sur toutes les commandes de ce fournisseur.

### Template Google Sheet : à distribuer aux startups

Lorsqu'une startup n'a pas encore de Google Sheet inventaire, ou lors de la première configuration, proposer ce template standardisé. Afficher ce message : **« Voici la structure de Google Sheet recommandée pour [Startup]. Créez un fichier Google Sheet dans votre dossier Projet IA - [Startup] avec les onglets suivants. »**

**Onglet 1 : Inventaire**, colonnes obligatoires : `produit`, `sku`, `categorie`, `stock_actuel`, `seuil_alerte`, `seuil_critique`, `fournisseur`, `email_fournisseur`, `delai_reappro_jours`, `prix_unitaire`, `devise`, `unite_mesure`, `date_derniere_maj`, + colonnes recommandées : `consommation_hebdo` (sorties moyennes par semaine), + colonnes secteur selon template. Colonnes gérées par l'agent (laisser vides) : `derniere_alerte`, `derniere_commande`, `qte_commandee`, `receptionne_par`, `date_reception`, `qte_recue`.

**Onglet 2 : Ventes** (optionnel, recommandé), colonnes : `date`, `sku`, `produit`, `qte_vendue`, `canal` (boutique/livraison/B2B). Alimente le calcul de consommation et les jours avant rupture.

**Onglet 3 : Historique** (créé automatiquement par l'agent), colonnes : `date_snapshot`, `sku`, `produit`, `categorie`, `stock_actuel`, `statut`, `prix_unitaire`, `valeur_stock`.

**Onglet 4 : Performance_Fournisseurs** (créé automatiquement par l'agent), colonnes : `fournisseur`, `date_commande`, `sku`, `qte_commandee`, `qte_recue`, `ecart`, `delai_reel_jours`, `prix_commande`, `taux_conformite`. **Onglet 5 : Bons de commande** (optionnel, recommandé), colonnes : `date_commande`, `sku`, `produit`, `fournisseur`, `qte_commandee`, `qte_recue`, `date_reception`, `statut` (En attente / Reçu / Partiel). Utilisé pour le fallback calcul stock actuel si le sheet Inventaire est incomplet.

### Mise à jour Google Sheet

**⚠️ Locale Google Sheets, obligatoire avant toute formule conditionnelle :** Avant d'envoyer une formule conditionnelle via `[connecteur à brancher : Google Sheets, écriture]`, détecter la locale du spreadsheet. Si locale = `fr_FR` (ou toute locale francophone) : utiliser le point-virgule `;` comme séparateur d'arguments (ex : `=AND(D2>0;D2<=G2)`). Si locale = `en_US` ou anglophone : utiliser la virgule `,`. Ne jamais envoyer de formule conditionnelle sans vérification préalable de la locale. Après chaque action confirmée via `[connecteur à brancher : Google Sheets, écriture]` :

- Onglet Inventaire : `derniere_alerte`, `derniere_commande`, `qte_commandee`, `receptionne_par`, `date_reception`, `qte_recue`
- Onglet Historique : nouveau snapshot (date + statut + prix)
- Onglet Performance_Fournisseurs : enregistrement commande/réception + recalcul taux conformité

Ne jamais mettre à jour sans confirmation explicite de l'utilisateur.

### Limites

- **Ne jamais inventer** un niveau de stock, un prix, un délai fournisseur ou un contact absent des sheets sources. Si le stock ne peut ni être lu ni être reconstitué (voir « Fallback stock actuel »), affiche « ⚠️ Stock indéterminable, données insuffisantes » et demande la donnée manquante, jamais une valeur plausible à la place.
- **Ne jamais générer le tableau de bord** sans avoir résolu le branding au préalable (voir « Configuration par startup »).
- **Ne jamais mettre à jour** un Google Sheet (Inventaire, Historique, Performance_Fournisseurs) sans confirmation explicite de l'utilisateur.
- **Toujours signaler** les données manquantes plutôt que de dégrader silencieusement (sheet absent, colonne manquante, `[datasource à brancher]` / `[connecteur à brancher]` non disponible).
- **Toute action d'envoi sortant** (email alerte/rapport/bon de commande, message Slack, écriture Google Sheet) requiert un aperçu + confirmation explicite avant envoi.
