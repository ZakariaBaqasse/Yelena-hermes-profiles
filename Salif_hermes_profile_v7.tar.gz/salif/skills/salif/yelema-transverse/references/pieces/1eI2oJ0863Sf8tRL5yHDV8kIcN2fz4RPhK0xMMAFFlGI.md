# 260918_Couche-locale-Salif

===== onglet t.0 · Tab 1 · 56 lignes non vides =====

# Couche locale de Salif : ce qui existe, ce qui se trouve, ce qui manque
Treizième fiche de la série. Salif est l'expert Achats, stock et logistique : il tient le stock, contrôle les réceptions, organise les tournées, achète en connaissance de cause, entretient ce qui produit et écrit les procédures que les équipes appliquent.

Il porte 59 compétences, toutes en lien vers le catalogue, et aucun memory/reference/, comme Nadia et Alioune.


## À lire avant tout
### Une compétence ivoirienne qui existe, et deux taux à corriger dedans
douane-import-ci (Y0546) est une bonne surprise : c'est l'une des rares compétences du parc écrites pour la Côte d'Ivoire. Elle estime les droits et taxes, propose un classement tarifaire, liste les pièces, nomme le Guichet unique du commerce extérieur, le TRIE, les ports d'Abidjan et de San Pédro, et elle rappelle partout que le classement définitif appartient à la douane. La méthode est saine.

Deux de ses chiffres ne tiennent pas devant les textes rapatriés le 18/09.

| Ce que dit la compétence | Ce que dit la source | Source |
| Prélèvement communautaire CEDEAO à 1 % | 0,5 % | Circulaire n° 2258 du 31/07/2023, Direction générale des douanes |
| Prélèvement communautaire de solidarité UEMOA à 0,8 % | 1 % dans la colonne P.C.S. de chaque ligne tarifaire | Tarif extérieur commun de l'UEMOA, 17/01/2017 |
| Redevance statistique | absente de la compétence, alors qu'elle est due sur toutes les importations à 1 % | Circulaire n° 2258 et colonne R.S. du TEC |
| TVA à 18 % | exact | Code général des Impôts, article 359 |

Le premier écart est une erreur simple. Le second est plus intéressant : les deux sources divergent réellement, et l'une des deux est peut-être périmée. Personne ici ne peut trancher, et personne ne devrait le faire seul : cela se fait dire par la douane ou par un commissionnaire agréé. Ce qui est sûr, c'est qu'une estimation servie au client avec 0,8 % là où le tarif écrit 1 % est fausse d'un côté ou de l'autre.

La compétence dit aussi d'aller chercher le TEC sur le Drive ou sur le web. Il est désormais sur disque, en entier.
### La compétence qui cartographie la zone ne connaît pas son métier
references-uemoa (Y0393) est solide sur la méthode : elle interdit de citer un taux, un plafond ou un délai de mémoire, elle oblige à fixer le pays avant de nommer une institution, et elle sépare proprement les trois périmètres qui se superposent, UEMOA à huit États, CEDEAO à quinze, OHADA à dix-sept.

Son tableau couvre neuf domaines : monnaie, droit des affaires, travail, protection sociale, fiscalité, assurance, propriété industrielle, télécoms, paiements. Relevé le 18/09 : il ne contient ni douane, ni tarif extérieur commun, ni transport, ni ports, ni marchés publics. Les trois domaines qui font le métier de Salif sont exactement ceux qui manquent. Elle porte par ailleurs zéro lien.
### Un compte de compétences faux, encore
Son CLAUDE.md annonce 51 compétences installées. Il y en a 59. Même défaut que sur les autres postes : le compte se recopie et ne se recompte pas.


## Ce qui est désormais sur disque
Trois bases communes créées le 18/09, dans ~/.claude/outils-communs/. Elles ne sont pas à Salif : Ibrahim, Mamadou et Alioune en ont l'usage aussi.
### commerce-exterieur-ci/
La procédure de dédouanement maritime de la Direction générale des douanes, le guide pratique de la CCI France Côte d'Ivoire, le tarif extérieur commun de l'UEMOA en entier, et le rapport annuel 2024 de l'UEMOA.

Ce que la base rend possible, et que rien ne rendait possible avant : citer la chaîne du dédouanement étape par étape, avec le guichet de chacune. Compte contribuable et code importateur avant la commande. Domiciliation de la facture pro forma et fiche de déclaration à l'importation dès 500 000 FCFA de valeur FOB. Bordereau de suivi des cargaisons et résultat final de classification et de valeur à l'embarquement, le RFCV étant obligatoire pour lever la déclaration. Édition de la déclaration en détail par un commissionnaire agréé, seul habilité. Paiement au comptant, ou à crédit d'enlèvement sous caution bancaire moyennant 2 % d'intérêt. Enfin l'orientation par SYDAM World vers un circuit vert automatique ou vers un contrôle physique, avec ce point à retenir : le circuit vert est contrôlé a posteriori par la Direction des enquêtes douanières, donc un vert n'est pas un quitus.
### marches-publics-ci/
L'ordonnance n° 2019-679 du 24 juillet 2019 portant Code des marchés publics, qui abroge le décret de 2009.

Et un piège qui valait d'être trouvé avant de répondre à un client : les seuils ne sont pas dans le Code. L'article 5.1 les renvoie à un décret pris en Conseil des ministres, et précise qu'ils peuvent différer selon la nature juridique de l'autorité contractante, l'importance du budget ou le type de marché. Citer un montant en s'appuyant sur le Code est donc une faute de raisonnement, pas seulement un risque d'erreur.
### logistique-ci/
Les statistiques du Port autonome de San Pédro, série 2021 à 2025 et suivi mensuel jusqu'à mai 2026, publiées par le port lui-même.

Elles disent trois choses utiles à une planification. San Pédro est un port d'export, 3,67 millions de tonnes contre 1,75 à l'import en 2025 : un importateur y est minoritaire. Le transit vers l'hinterland a triplé depuis 2021 pendant que le transbordement reculait d'un tiers. Et la composition change : le cacao passe de 1,14 million de tonnes en 2021 à 733 000 en 2025, quand le caoutchouc monte de 327 000 à 802 000.


## Les onze lignes de métier
Sept lignes de socle sont reprises telles quelles du socle commun déjà établi, plus la ligne des repères institutionnels et celle des canaux. Restent les onze qui font le métier.
### Ce qui est trouvé
CL-SALIF-06, les actes uniformes OHADA qui touchent son métier. Les dix actes sont sur disque depuis le 17/09. Trois le concernent directement, avec leurs articles :

- L'acte sur le transport de marchandises par route s'applique dès que la prise en charge ou la livraison est dans un État membre, quelles que soient la nationalité et le domicile des parties, article 1er. Il exclut le déménagement, le funéraire et les marchandises dangereuses. La lettre de voiture fait foi jusqu'à preuve du contraire, articles 4 et 5, et son absence n'annule pas le contrat. L'indemnité pour avarie ou perte est plafonnée à 5 000 FCFA par kilogramme de poids brut, article 18, sauf déclaration de valeur. L'action se prescrit par un an, trois en cas de dol, article 25.
- L'acte sur le droit commercial général régit la vente entre commerçants, articles 234 et 235, et exclut l'achat à usage personnel. La prescription y est de deux ans, article 301.
- L'acte sur les sûretés sert dès qu'un achat se garantit.

CL-SALIF-11, le dédouanement. Couvert par la base, procédure et documents compris.

CL-SALIF-12, les régimes UEMOA et le tarif extérieur commun. Les cinq catégories sont établies sur le texte : biens sociaux essentiels à 0 %, première nécessité et biens d'équipement à 5 %, intrants et produits intermédiaires à 10 %, consommation finale à 20 %, biens spécifiques pour le développement économique à 35 %. La cinquième bande est l'apport de la CEDEAO, l'UEMOA n'en avait que quatre.

Avec une réserve qui compte autant que le contenu : l'édition sur disque est celle de 2017 et porte 5 899 lignes tarifaires. La Côte d'Ivoire applique depuis le 8 août 2023 le TEC CEDEAO fondé sur le Système harmonisé 2022, qui en porte 6 381. Le fichier sert l'architecture, pas le taux d'une ligne. Pour un taux, le tarif en ligne des douanes, qui publie aussi le tableau de concordance entre les deux nomenclatures.

Les régimes suspensifs et économiques sont documentés eux aussi, perfectionnement actif et passif, admission temporaire, entrepôt douanier, transit. C'est de la trésorerie, pas du formalisme : un achat qui ressort du territoire ne devrait pas payer comme un achat consommé sur place.

CL-SALIF-13, les ports. San Pédro est servi par sa propre source, 2021 à 2025.
### Ce qui manque, et pourquoi
CL-SALIF-13, la moitié Abidjan. Le port publie une série qui s'arrête à 2021, et une page de chiffres clés annonçant 22,55 millions de tonnes sans année. Ce qui est établi sur sa source, pour 2021 : 28 313 869 tonnes de trafic global net, 787 314 EVP, 1 778 escales commerciales, 34 postes à quai sur 6 kilomètres. Deux chiffres de presse circulent pour 2025 et ils ne concordent pas, l'un annonçant plus de 40 millions de tonnes, l'autre 46,6 millions contre 40,1 en 2024. Le second lit peut-être comme 2025 ce que le premier lit comme 2024. Aucun des deux ne sera servi comme un fait tant que le port n'a pas publié.

CL-SALIF-14, les corridors. Le rapport annuel 2024 de l'UEMOA confirme sur source primaire la persistance des pratiques anormales sur les corridors routiers, la justification des postes de contrôle par les questions sécuritaires, et la transformation en cours de l'Observatoire des pratiques anormales en Observatoire régional des transports, qui couvrira aussi les volumes, les délais et les coûts. Il ne donne aucun chiffre. Ceux qui circulent dans la presse, 27 000 FCFA de perceptions illicites par voyage, 23,9 postes de contrôle sur Abidjan-Bamako, 11 minutes de contrôle par 100 km sur Abidjan-Ouagadougou, ne sont datés nulle part dans nos relevés et certains remontent à plus de dix ans. Il faut le rapport OPA de l'exercice concerné.

CL-SALIF-15, les fournisseurs de la place par famille d'achat. Rien de sourcé. Il existe des annuaires, celui de la Chambre de commerce et d'industrie de Côte d'Ivoire et l'annuaire IDU qui se présente comme le répertoire des entreprises immatriculées au CEPICI. Aucun n'a été ouvert ni évalué. C'est une ligne qui se construit à la main, comme celle des financeurs d'Alioune, et qui vieillit vite.

CL-SALIF-16, les contraintes de stockage locales. Rien. La saisonnalité est dans le socle du calendrier, mais ce que réclame la ligne, chaîne du froid, humidité, effet de la saison des pluies sur un plan de stock, ne se lit dans aucun texte : cela vient de retours terrain et de prestataires logistiques.

CL-SALIF-17, les règles d'achat public et les seuils. Le Code est là, les seuils non. Un relevé de presse cite 100 millions FCFA pour les travaux, 70 pour les fournitures et services, 50 pour un cabinet, 20 pour un consultant individuel, et un décret n° 2021-869 du 15 décembre 2021 comme texte porteur. Source secondaire, non datée pour le premier chiffre, non lue pour le décret : rien de tout cela ne sera servi. Il faut le décret.

CL-SALIF-18, les grilles de coût de transport et d'entreposage. Rien, et c'est normal : cela se relève sur des devis réels, pas dans une publication. Les seuls repères de coût trouvés sont indirects, les surestaries au-delà de cinq jours de stockage au port mentionnées par le guide de la CCI, et le droit unique de sortie à l'export dont les taux sont fixés par le Conseil des ministres avant chaque campagne, ce qui veut dire qu'un taux cité hors campagne est périmé.

CL-SALIF-10, les canaux. Socle commun, et il reste à Non : l'accès à internet est documenté par le rapport de l'ARTCI, la part par plateforme ne l'est pas.


## Ce qui est proposé
- Corriger douane-import-ci sur le prélèvement CEDEAO, ajouter la redevance statistique, et porter la divergence sur le prélèvement de solidarité comme une réserve explicite plutôt que comme un taux. Le pointer vers les fichiers sur disque au lieu du web.
- Compléter references-uemoa de quatre lignes : douane et tarif extérieur commun, transport routier interétatique, ports, marchés publics, avec l'institution compétente et le fichier local quand il existe.
- Récupérer le décret des seuils des marchés publics. C'est le manque qui expose le plus : un achat public hors procédure s'annule après la livraison.
- Récupérer un rapport OPA daté pour les corridors, et les statistiques d'Abidjan quand le port publie.
- Construire la liste des fournisseurs par famille d'achat, si elle est voulue, en sachant que c'est un travail de plusieurs jours et une veille ensuite.

