# 260921_Saisons de Cote d Ivoire, releve 7 villes

===== onglet t.0 · Tab 1 · 124 lignes non vides =====

# Les saisons en Côte d'Ivoire, relevées ville par ville
Relevé du 2026-09-21. Moyennes mensuelles sur 08/2016 à 08/2026, soit 10 ans d'observations.
## À quoi sert cette note
Le pays n'a pas un calendrier des pluies, il en a deux. Le sud littoral connaît deux saisons des pluies séparées par une petite saison sèche ; le nord n'en a qu'une, courte et violente. Une date qui convient à Abidjan peut tomber au pire moment à Korhogo, et l'écart se compte en centaines de millimètres.

Cette note sert à fixer une date : séminaire, tournage, chantier, campagne terrain, livraison, inventaire, comptage physique. Elle ne sert pas à prévoir le temps qu'il fera.
## Le tableau de décision, en une ligne par ville
| Ville | Saison des pluies | Mois les plus secs | Cumul annuel |
| Abidjan | avril, mai, juin, septembre, octobre, novembre | aucun | 1902 mm |
| San-Pédro | mai, juin, septembre | janvier | 1514 mm |
| Bouaké | mai, juin, juillet, août, septembre, octobre | janvier, février, décembre | 1371 mm |
| Yamoussoukro | mars, avril, mai, juin, juillet, août, septembre, octobre | janvier, décembre | 1350 mm |
| Man | mai, juin, juillet, août, septembre, octobre | janvier, février, décembre | 1723 mm |
| Korhogo | juillet, août, septembre | janvier, février, novembre, décembre | 1036 mm |
| Odienné | juin, juillet, août, septembre | janvier, février, mars, novembre, décembre | 1370 mm |

⚠ « Mois les plus secs : aucun » pour Abidjan n'est pas une anomalie : le seuil de mois sec n'y est jamais atteint, il pleut toute l'année, plus ou moins.
## Le détail mensuel, ville par ville
### Abidjan · littoral, régime à deux saisons des pluies
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier              80              21     30.6  intermédiaire
février             101              20     30.9  intermédiaire
mars                128              24     30.6  intermédiaire
avril               160              25     30.4  PLUIES
mai                 250              28     29.5  PLUIES
juin                322              29     27.8  PLUIES
juillet             125              27     27.2  intermédiaire
août                 96              26     27.0  intermédiaire
septembre           162              28     27.5  PLUIES
octobre             228              31     28.3  PLUIES
novembre            153              29     29.2  PLUIES
décembre             97              23     30.0  intermédiaire
### San-Pédro · littoral ouest, le plus arrosé
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier              51              16     30.1  sec
février              60              14     30.3  intermédiaire
mars                 71              13     30.2  intermédiaire
avril                80              17     30.3  intermédiaire
mai                 208              26     29.2  PLUIES
juin                343              28     27.6  PLUIES
juillet             140              25     26.9  intermédiaire
août                116              24     26.5  intermédiaire
septembre           159              25     26.8  PLUIES
octobre             120              26     27.8  intermédiaire
novembre            102              22     28.7  intermédiaire
décembre             63              18     29.6  intermédiaire
### Bouaké · centre
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier               3               1     34.1  sec
février              27               4     34.9  sec
mars                101              14     33.5  intermédiaire
avril                96              15     32.6  intermédiaire
mai                 140              19     31.4  PLUIES
juin                171              23     29.4  PLUIES
juillet             151              25     28.2  PLUIES
août                227              27     28.1  PLUIES
septembre           223              27     28.7  PLUIES
octobre             165              21     30.0  PLUIES
novembre             56              10     31.6  intermédiaire
décembre             11               3     33.0  sec
### Yamoussoukro · centre
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier              12               3     34.1  sec
février              43               7     34.8  intermédiaire
mars                 97              15     33.5  PLUIES
avril               110              16     32.9  PLUIES
mai                 145              21     31.9  PLUIES
juin                185              24     29.8  PLUIES
juillet             129              22     29.0  PLUIES
août                183              23     28.8  PLUIES
septembre           202              25     29.1  PLUIES
octobre             164              23     29.9  PLUIES
novembre             63              13     30.9  intermédiaire
décembre             17               4     32.5  sec
### Man · ouest montagneux
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier               9               2     33.3  sec
février              41               7     33.8  sec
mars                118              17     32.1  intermédiaire
avril               107              17     31.5  intermédiaire
mai                 151              21     30.3  PLUIES
juin                220              27     28.7  PLUIES
juillet             233              29     27.5  PLUIES
août                306              32     27.4  PLUIES
septembre           286              28     27.9  PLUIES
octobre             179              24     28.7  PLUIES
novembre             59              12     29.8  intermédiaire
décembre             16               4     31.6  sec
### Korhogo · nord, régime à une seule saison des pluies
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier               0               0     34.2  sec
février               4               2     35.8  sec
mars                 44               6     35.8  intermédiaire
avril                47               9     35.3  intermédiaire
mai                  93              13     33.3  intermédiaire
juin                112              17     31.1  intermédiaire
juillet             180              23     29.0  PLUIES
août                267              29     28.5  PLUIES
septembre           186              23     28.7  PLUIES
octobre              84              13     30.6  intermédiaire
novembre             16               3     33.0  sec
décembre              4               1     33.5  sec
### Odienné · nord-ouest
mois         pluie (mm)    jours ≥ 1 mm   t° max  régime
janvier               0               0     33.9  sec
février               5               1     35.5  sec
mars                 29               5     35.6  sec
avril                55               9     34.9  intermédiaire
mai                 103              16     33.1  intermédiaire
juin                164              21     30.9  PLUIES
juillet             263              27     29.1  PLUIES
août                344              30     28.7  PLUIES
septembre           253              26     29.5  PLUIES
octobre             131              15     31.3  intermédiaire
novembre             17               4     33.2  sec
décembre              6               1     33.5  sec
## Comment lire ces chiffres, et ce qu'ils ne disent pas
Le cumul en millimètres est la mesure solide. Le compte de jours à 1 mm ou plus se lit comme un ordre de grandeur et rien de plus : la source est une réanalyse sur maille d'environ 25 km, qui étale les pluies faibles et gonfle donc le NOMBRE de jours sans fausser le cumul. À la question « combien de jours de pluie en janvier », on répond par le cumul, pas par la colonne des jours.

Ce sont des moyennes sur dix ans, pas une prévision. Elles disent le risque d'une période, jamais le temps d'une date. Pour les quelques jours à venir, c'est une autre commande, plus bas.

Ce ne sont pas les normales officielles. La SODEXAM est le service météorologique national et fait foi en Côte d'Ivoire ; son site n'accepte pas nos connexions au 20/09/2026. Si une décision engage de l'argent ou un contrat sur ces valeurs, on cite le relevé avec sa source et on fait confirmer par la SODEXAM. On ne présente jamais ces chiffres comme des normales nationales.
## Rafraîchir, ou traiter une ville absente
python3 integrations/open-meteo/meteo.py --saisons --ville Korhogo
python3 integrations/open-meteo/meteo.py --previsions --ville Abidjan   # les 7 jours qui viennent

Les sept villes ci-dessus sont connues de l'outil. Pour une autre localité, ajouter ses coordonnées au dictionnaire VILLES de integrations/open-meteo/meteo.py : l'API est gratuite, sans clé et sans quota nominal, mais tout appel passe par ce script et par lui seul.

Source : Open-Meteo, réanalyse ERA5, archive-api.open-meteo.com.

