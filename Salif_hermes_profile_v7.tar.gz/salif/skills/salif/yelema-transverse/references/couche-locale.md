# Couche locale : Salif · Achats, stock et logistique

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-SALIF-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.gouv.ci
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Pièce déjà sur cette machine, aucune recherche à mener : ~/agents/lokoli/memory/reference/gouvernement-2026.md, composition du gouvernement Mambé du 23/01/2026, relevée le 10/09. Un lien symbolique suffit. La hiérarchie de fiabilité des sources ivoiriennes est dans watchlist-sources-ci.md (rang 1 = Journal officiel, SGG, presidence.ci ; une biographie n'établit jamais un statut, seul l'acte le fait).

### CL-SALIF-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-SALIF-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-SALIF-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-SALIF-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-SALIF-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.com/actes-uniformes.html
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || SUR DISQUE DEPUIS LE 17/09 : ~/.claude/outils-communs/ohada/, les dix actes uniformes en PDF et en texte, avec LISEZ-MOI. TROIS ACTES TOUCHENT CE MÉTIER, avec leurs articles vérifiés le 18/09 : 1) AUCTMR, TRANSPORT DE MARCHANDISES PAR ROUTE. Art. 1er : s'applique dès que la prise en charge OU la livraison est dans un État membre, quels que soient le domicile et la nationalité des parties ; exclut déménagement, funéraire et marchandises dangereuses. Art. 4 et 5 : la lettre de voiture fait foi jusqu'à preuve du contraire, et son absence, son irrégularité ou sa perte N'AFFECTE NI L'EXISTENCE NI LA VALIDITÉ du contrat. ⚠ ART. 18, L'INDEMNITÉ POUR AVARIE OU PERTE EST PLAFONNÉE À 5 000 FCFA PAR KILOGRAMME DE POIDS BRUT, sauf déclaration de valeur ou d'intérêt spécial portée à la lettre de voiture : c'est le chiffre qui décide s'il faut déclarer la valeur, et il se calcule AVANT l'expédition. Art. 25 : l'action se prescrit par UN AN, trois ans en cas de dol. 2) AUDCG, VENTE COMMERCIALE (Livre 8). Art. 234 : régit la vente de marchandises entre commerçants, y compris la fourniture destinée à la fabrication, dès lors qu'un contractant a son siège dans un État partie. Art. 235 : NE RÉGIT PAS l'achat à usage personnel, familial ou domestique, ni les contrats où la main-d'œuvre est prépondérante. Art. 301 : prescription de DEUX ANS, à ne pas confondre avec l'an du transport. 3) AUS, SÛRETÉS, dès qu'un achat se garantit. ⚠ AUSCGIE-2014.txt EST SANS ACCENTS (chercher 'societe'), AUS-2010.txt numérote 'Art.1.-' et non 'Article 1' : détails dans le LISEZ-MOI.

## Langue

### CL-SALIF-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || CORRIGÉ LE 18/09 : le socle affirmait que la compétence parler-ivoirien était déjà liée à ce poste. C'ÉTAIT FAUX — elle l'était chez KOUASSI, d'où le socle a été repris, et elle manquait sur SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis le 18/09, version du catalogue vérifiée neutre. ⚠ LA LEÇON : un socle transverse porte la réponse du poste SOURCE, pas celle du poste cible. Une affirmation du type « déjà chez lui » doit se vérifier poste par poste avant d'être propagée. Ce que sert ce corpus : la règle de registre (le premier contact reste formel ici, on vouvoie, l'urgence fabriquée est mal vue) autant que le lexique.

## Canaux

### CL-SALIF-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : 91,6 % des connexions par mobile, et l'e-commerce à 9,8 % des internautes — la commande en ligne reste marginale dans la chaîne d'achat ici.

## Import

### CL-SALIF-11 · Le dédouanement en Côte d'Ivoire : documents, délais, coûts
- **Pourquoi** : Un délai de livraison promis sans compter la douane
- **Où chercher** : Direction générale des douanes, guichet unique du commerce extérieur
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.douanes.ci/sites/default/files/procedure_import_export_2.pdf
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Procédure de dédouanement maritime de la Direction générale des douanes (15 pages, du compte contribuable à l'enlèvement) et guide CCI France Côte d'Ivoire (36 pages : documents, frais, paiements, régimes suspensifs). ⛔ UN TAUX SE LIT SUR LE TARIF EN LIGNE DES DOUANES, JAMAIS DE MÉMOIRE : ces fichiers donnent l'architecture et la procédure, pas le taux du jour. || SUR DISQUE DEPUIS LE 18/09 : ~/.claude/outils-communs/commerce-exterieur-ci/, avec LISEZ-MOI. Deux pièces : la PROCÉDURE DE DÉDOUANEMENT À L'IMPORTATION ET À L'EXPORTATION PAR VOIE MARITIME de la Direction générale des douanes (15 p.), et le GUIDE PRATIQUE DES PROCÉDURES DE DÉDOUANEMENT de la CCI France Côte d'Ivoire (36 p.). LA CHAÎNE, DANS L'ORDRE, chaque étape ayant son guichet et bloquant la suivante : (1) AVANT LA COMMANDE, compte contribuable permanent ou occasionnel, code importateur annuel ou occasionnel délivré par le ministère du Commerce, enregistrement des deux auprès de la direction informatique de la Douane, compte GUCE ; (2) À LA COMMANDE, domiciliation de la facture pro forma en banque puis levée de la fiche de déclaration à l'importation, EXIGÉE DÈS 500 000 FCFA DE VALEUR FOB ; (3) À L'EMBARQUEMENT, bordereau de suivi des cargaisons puis résultat final de classification et de valeur — ⚠ LE RFCV EST OBLIGATOIRE POUR LEVER LA DÉCLARATION, et c'est sur SA valeur que la déclaration s'établit ; (4) SEUL UN COMMISSIONNAIRE EN DOUANE AGRÉÉ peut éditer la déclaration en détail ; (5) PAIEMENT au comptant, ou à crédit d'enlèvement garanti par caution bancaire moyennant 2 % d'intérêt (obligations cautionnées à partir de 5 millions FCFA) ; (6) CONTRÔLE par SYDAM World, circuit vert automatique ou contrôle physique (scanner, jaune, rouge en visite à quai ou à domicile). ⚠ LE CIRCUIT VERT EST CONTRÔLÉ A POSTERIORI par la Direction des enquêtes douanières : UN VERT N'EST PAS UN QUITUS. DOCUMENTS communs aux deux sens : déclaration en douane unique, facture commerciale, connaissement ou LTA, contrat ou bon de commande, assurance, certificat d'origine, certificat sanitaire ou phytosanitaire, liste de colisage, domiciliation bancaire. À l'import s'ajoutent le permis d'importation (produits alimentaires, pharmaceutiques, chimiques, dérivés animaux), le certificat de conformité et le certificat d'inspection. ⛔ CE QUI MANQUE : les DÉLAIS réels de passage portuaire ne sont chiffrés dans aucune des deux sources. Le guide parle de surestaries au-delà de cinq jours de stockage et cite un dédouanement en trois jours comme un cas remarquable : cela donne l'ordre de grandeur, pas une norme. Le Code des douanes lui-même n'est pas rapatrié.

### CL-SALIF-12 · Les régimes UEMOA et le tarif extérieur commun
- **Pourquoi** : Facturer un droit qui ne s'applique pas
- **Où chercher** : Commission de l'UEMOA, douanes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.douanes.ci/node/42571
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Tarif extérieur commun de l'UEMOA du 17/01/2017 sur disque, 424 pages, toutes les lignes tarifaires avec D.D., R.S. et P.C.S., plus le rapport annuel UEMOA 2024. ⚠ LE LISEZ-MOI SIGNALE QUE CE TEC N'EST PAS CELUI QUI S'APPLIQUE AUJOURD'HUI : le lire comme l'architecture, vérifier le taux en vigueur avant de chiffrer. || SUR DISQUE DEPUIS LE 18/09 : le TARIF EXTÉRIEUR COMMUN DE L'UEMOA du 17/01/2017 EN ENTIER (424 p., toutes les lignes avec leurs colonnes D.D., R.S. et P.C.S.) dans ~/.claude/outils-communs/commerce-exterieur-ci/, plus le rapport annuel 2024 de l'UEMOA. LES CINQ CATÉGORIES, sur le texte. Critère principal : le degré de transformation ; critère secondaire : la production communautaire. Catégorie 0, biens sociaux essentiels, 0 %. Catégorie I, première nécessité, matières premières de base, biens d'équipement, intrants spécifiques, 5 %. Catégorie II, intrants et produits intermédiaires, 10 %. Catégorie III, biens de consommation finale, 20 %. Catégorie IV, biens spécifiques pour le développement économique, 35 %. LA CINQUIÈME BANDE EST L'APPORT DE LA CEDEAO, l'UEMOA n'en avait que quatre. ⛔ L'ÉDITION SUR DISQUE EST PÉRIMÉE POUR LES TAUX : elle porte 5 899 lignes tarifaires, alors que la Côte d'Ivoire applique DEPUIS LE 8 AOÛT 2023 le TEC CEDEAO fondé sur le Système harmonisé 2022, qui en porte 6 381 (circulaire n° 2258 du 31/07/2023 du Directeur général des douanes). Le fichier sert l'architecture et les définitions ; POUR UN TAUX, le tarif en ligne de douanes.ci, qui publie aussi la nomenclature SH 2022 et le tableau de concordance. LES PRÉLÈVEMENTS QUI ACCOMPAGNENT LE DROIT : redevance statistique 1 %, prélèvement communautaire CEDEAO 0,5 % (circulaire n° 2258), PRÉLÈVEMENT COMMUNAUTAIRE DE SOLIDARITÉ UEMOA 0,8 % (TRANCHÉ PAR l'équipe LE 18/09 — ⚠ la colonne P.C.S. du TEC de 2017 écrit encore 1 %, elle est périmée sur ce point), prélèvement Union africaine 0,2 % (source secondaire, à confirmer), TVA 18 % sur base hors taxe (CGI art. 359, vérifié sur le texte). ⛔ LA REDEVANCE STATISTIQUE NE SE CONFOND PAS AVEC LE PRÉLÈVEMENT CEDEAO : deux lignes, deux chèques. RÉGIMES qui font gagner de la trésorerie, documentés dans le guide CCI : perfectionnement actif, perfectionnement passif, admission temporaire, entrepôt douanier, transit. Un achat qui ressort du territoire ne devrait pas payer comme un achat consommé sur place. À L'EXPORT, le droit unique de sortie : prix CAF de référence et taux FIXÉS PAR LE CONSEIL DES MINISTRES AVANT CHAQUE CAMPAGNE, donc un taux cité hors campagne est périmé. Relevés sans millésime : café 5 %, cacao fève 14,6 %, cajou par campagne, karité 10 F/kg, cola 10,2 F/kg. ✅ CORRIGÉ LE 18/09 dans la compétence douane-import-ci (Y0546), qui donnait le prélèvement CEDEAO à 1 % et omettait la redevance statistique ; elle pointe désormais la base locale.

## Logistique

### CL-SALIF-13 · Le port d'Abidjan et le port de San-Pédro : capacités et délais
- **Pourquoi** : Planifier sans connaître le goulot réel
- **Où chercher** : Autorités portuaires
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://sanpedro-portci.com/trafics-portuaires/
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Statistiques du Port autonome de San Pédro 2021 à 2025 et trafic mensuel janvier-mai 2026, source du port. Total 7 768 858 t en 2025, +5 % sur 2024. ⛔ TROIS LECTURES QUI CHANGENT UNE PLANIFICATION : c'est un port d'EXPORT (3 667 172 t export contre 1 747 680 t import en 2025), un importateur y est minoritaire ; le transit explose (610 619 t en 2021 à 1 835 979 t en 2025) et le transbordement recule (839 212 à 518 027 t). ⚠ Le port d'Abidjan n'est PAS couvert par cette base. || SUR DISQUE DEPUIS LE 18/09 : ~/.claude/outils-communs/logistique-ci/, statistiques du PORT AUTONOME DE SAN PÉDRO publiées par le port, série 2021-2025 par famille de marchandises plus le suivi mensuel janvier-mai 2026. SAN PÉDRO 2025 : 7 768 858 t au total, +5 % sur 2024. TROIS LECTURES QUI CHANGENT UNE PLANIFICATION : (a) C'EST UN PORT D'EXPORT, 3 667 172 t contre 1 747 680 t à l'import — un importateur y est minoritaire, avec ce que cela suppose de fréquence de lignes ; (b) LE TRANSIT A TRIPLÉ depuis 2021 (610 619 t → 1 835 979 t) pendant que le TRANSBORDEMENT RECULAIT D'UN TIERS (839 212 t → 518 027 t) : le port sert de plus en plus l'hinterland ; (c) LA COMPOSITION CHANGE, café-cacao de 1 141 635 t en 2021 à 732 665 t en 2025, caoutchouc de 326 636 t à 802 162 t, minerais premier poste d'export en 2025 avec 1 548 637 t (-17 %). ⛔ ABIDJAN : LA SOURCE DU PORT S'ARRÊTE EN 2021 et sa page 'chiffres clés' annonce 22,55 millions de tonnes SANS ANNÉE. Établi sur la source du port pour 2021 : trafic global net 28 313 869 t (brut 30 045 960 t), national net 24 908 065 t, transit net 2 935 724 t, transbordement net 470 080 t, 787 314 EVP, 1 778 escales commerciales. Infrastructure annoncée sans millésime : 34 postes à quai sur 6 km, plan d'eau de plus de 1 000 ha, domaine terrestre brut 800 ha, 140 000 m² de magasins et hangars, 105 000 m² de terre-pleins ; terminal à conteneurs 37 ha, 7 portiques de quai, 2 grues mobiles, 20 portiques de parc. ⛔ DEUX CHIFFRES DE PRESSE POUR 2025 NE CONCORDENT PAS : l'un annonce 'plus de 40 millions de tonnes consolidées en 2025', l'autre '46,6 millions en 2025 contre 40,1 en 2024' avec 1,69 million d'EVP. Le second lit peut-être comme 2025 ce que le premier lit comme 2024. NE SERVIR NI L'UN NI L'AUTRE comme un fait tant que le port n'a pas publié.

### CL-SALIF-14 · Les corridors vers le Mali, le Burkina et le Niger
- **Pourquoi** : Ignorer les temps de corridor et les postes de contrôle
- **Où chercher** : Organisations de transport, chambres consulaires
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/sites/default/files/bibliotheque/rapport-annuel-2024-sur-le-fonctionnement-et-levolution-de-lunion.pdf
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/09/2027
- **Commentaire** : INTÉGRÉ LE 21/09, par l'intégration un-comtrade. Note d'usage neuve : memory/reference/bases-locales/logistique-ci/notes/corridors-et-partenaires.md. ⛔ LE FAIT QUI RENVERSE LA LIGNE : le MALI est le TROISIÈME débouché du pays en 2023 avec 8,7 % des exportations déclarées, devant la Chine, les États-Unis et la France ; le Burkina Faso est sixième à 4,3 %. Ensemble les deux corridors sahéliens pèsent 13 %, plus que les Pays-Bas qui sont premiers à 11,5 %. Traiter ces corridors comme un appoint est une erreur d'ordre de grandeur. ⚠ Les deux premiers rangs, Pays-Bas et Suisse, sont l'effet du cacao et de son négoce, pas de la consommation de ces pays. ⛔ CE QUE LA SOURCE NE DIT PAS : ni délais, ni coûts, ni état des routes, ni points de passage, et elle laisse dehors l'informel, important sur ces corridors précisément. Comtrade porte le DÉCLARÉ. Les temps de trajet réels restent dus, ils se demandent aux organisations de transport. || NON TROUVÉ POUR LES CHIFFRES, et je préfère le dire. CE QUI EST CONFIRMÉ SUR SOURCE PRIMAIRE (rapport annuel 2024 de l'UEMOA, sur disque dans commerce-exterieur-ci/) : l'Observatoire des pratiques anormales constate LA PERSISTANCE DES PRATIQUES ANORMALES sur les corridors routiers de l'espace UEMOA ; les États justifient le nombre important de postes de contrôle par les questions sécuritaires ; les Comités nationaux de facilitation des transports mènent des actions de sensibilisation ; LA TRANSFORMATION DE L'OPA EN OBSERVATOIRE RÉGIONAL DES TRANSPORTS EST EN COURS, pour couvrir aussi les volumes, les délais et les coûts. ⛔ LE RAPPORT ANNUEL NE DONNE AUCUN CHIFFRE DE CORRIDOR. Ceux qui circulent dans la presse — environ 27 000 FCFA de perceptions illicites par voyage, 23,9 postes de contrôle sur Abidjan-Bamako, 4 100 FCFA par 100 km sur Ouagadougou-Bamako, 11 minutes de contrôle par 100 km sur Abidjan-Ouagadougou — NE SONT DATÉS NULLE PART dans nos relevés et certains remontent à plus de dix ans. NE PAS LES SERVIR. ⏸ IL FAUT LE RAPPORT OPA DE L'EXERCICE CONCERNÉ. ✅ uemoa.int est redevenu atteignable depuis cette machine le 18/09 (chaîne TLS incomplète côté serveur, corrigée dans integrations/web-public/telecharger.py) : la bibliothèque de l'UEMOA est ouverte, le rapport OPA est à y chercher.

## Achats

### CL-SALIF-15 · Les fournisseurs de la place par famille d'achat
- **Pourquoi** : Acheter à l'étranger ce qui se trouve ici
- **Où chercher** : Annuaires professionnels, chambres consulaires
- **Trouvé** : Non
- **Intégré** : Non
- **Source primaire** : https://www.cci.ci/annuaire-des-entreprises/
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON TROUVÉ. Il existe des annuaires — celui de la Chambre de commerce et d'industrie de Côte d'Ivoire, et l'annuaire IDU (annuaireidu.ci) qui se présente comme le répertoire des entreprises immatriculées au CEPICI — mais AUCUN N'A ÉTÉ OUVERT NI ÉVALUÉ le 18/09, et un annuaire qui existe n'est pas une liste de fournisseurs par famille d'achat. CETTE LIGNE SE CONSTRUIT À LA MAIN, comme celle des financeurs d'Alioune : à partir de devis reçus, de références clients et des chambres consulaires. C'est un travail de plusieurs jours, puis une veille — un annuaire de fournisseurs vieillit vite.

## Stock

### CL-SALIF-16 · Les contraintes de stockage locales : chaîne du froid, humidité, saison
- **Pourquoi** : Un plan de stock qui ignore la saison des pluies
- **Où chercher** : Retours terrain, prestataires logistiques
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1jd_OGrfQl9jId-N-YAjuigeL-Om3W4xxc4wjVZGirjY.md
- **Mis à jour** : 21/09/2026
- **À revérifier le** : 21/09/2027
- **Commentaire** : ⚠ CORRIGÉ LE 21/09 : la pièce était le script open-meteo. Un chemin qui finit par .py ne se lit pas, il se lance, et l'expert ne le lance pas, il va chercher ailleurs sans le dire. Remplacé par la note saisons-ci.md, engendrée par l'outil, qui porte le détail mensuel des sept villes. Défaut constaté à l'usage sur Djénéba, même pièce. || INTÉGRÉ LE 21/09, par l'intégration open-meteo, pour le volet saisonnalité de la ligne. Humidité et pluies relevées sur dix ans, par ville : Abidjan 1 902 mm par an sans aucun mois sec, donc une contrainte d'humidité PERMANENTE sur le littoral ; Korhogo 1 036 mm concentrés sur juillet à septembre, avec quatre mois secs de novembre à février. Un plan de stockage unique pour les deux zones est faux. ⛔ NON COUVERT par cette pièce : la chaîne du froid, les capacités d'entrepôt et les prestataires, qui se demandent au terrain. La ligne reste partiellement ouverte et c'est écrit ici plutôt que masqué par un Oui. || NON TROUVÉ, et ce n'est pas faute d'avoir cherché au bon endroit : CE QUE DEMANDE LA LIGNE NE SE LIT DANS AUCUN TEXTE. La saisonnalité générale est couverte par le socle du calendrier (CL-SALIF-03), mais la chaîne du froid, l'humidité, et l'effet de la saison des pluies sur un plan de stock viennent de RETOURS TERRAIN et de PRESTATAIRES LOGISTIQUES, pas d'une publication. ⏸ À constituer en interrogeant les prestataires, ou à laisser vide plutôt que de servir des généralités climatiques déguisées en contraintes d'entreposage.

## Marchés publics

### CL-SALIF-17 · Les règles d'achat public et les seuils
- **Pourquoi** : Un achat public hors procédure est annulable
- **Où chercher** : Direction des marchés publics
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://budget.gouv.ci/doc/loi/Code-Marches-Publics-Ordonnance-n-2019-679-du-24-juillet-2019.pdf
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Ordonnance n° 2019-679 du 24/07/2019 portant Code des marchés publics, 44 pages, telle que publiée au Journal officiel. ⛔ LIRE LE FICHIER -flux.txt : l'extraction -layout entrelace les quatre colonnes du JO et est inutilisable. ⛔ ET LE PIÈGE DE LA LIGNE : LES SEUILS NE SONT PAS DANS LE CODE. L'art. 5.1 les renvoie à un décret en Conseil des ministres, et ils peuvent différer selon l'autorité contractante, le budget ou le type de marché. Annoncer un seuil tiré du Code est faux. || SUR DISQUE DEPUIS LE 18/09 : ~/.claude/outils-communs/marches-publics-ci/, l'ORDONNANCE N° 2019-679 DU 24 JUILLET 2019 portant Code des marchés publics (44 p., Journal officiel), qui abroge et remplace le décret n° 2009-259 du 6 août 2009. ⛔ LES SEUILS NE SONT PAS DANS LE CODE, et c'est le piège de la ligne. L'article 5.1 dit que les seuils de référence sont FIXÉS PAR DÉCRET PRIS EN CONSEIL DES MINISTRES, et qu'ils PEUVENT DIFFÉRER selon la nature juridique de l'autorité contractante, l'importance du budget alloué ou le type de marché. L'article 6 renvoie de même les procédures simplifiées applicables en dessous des seuils. CITER UN MONTANT EN S'APPUYANT SUR LE CODE EST UNE FAUTE DE RAISONNEMENT, pas seulement un risque d'erreur : le Code renvoie ailleurs. ⚠ TROIS SEUILS À NE PAS CONFONDRE, tous définis dans le Code : le SEUIL DE RÉFÉRENCE, à partir duquel les procédures s'imposent ; le SEUIL COMMUNAUTAIRE DE PUBLICATION, déterminé par la Commission de l'UEMOA ; les seuils de VALIDATION et d'APPROBATION, qui décident qui signe. Un même marché peut être au-dessus de l'un et en dessous de l'autre. ⏸ RESTE DÛ, ET C'EST LE MANQUE QUI EXPOSE LE PLUS : le décret des seuils. Un relevé de presse cite 100 M FCFA pour les travaux, 70 M pour fournitures et services, 50 M pour un cabinet, 20 M pour un consultant individuel, sauf communes sans statut particulier, et un décret n° 2021-869 du 15/12/2021 comme texte porteur. ⚠ SOURCE SECONDAIRE, NON DATÉE pour le premier chiffre, DÉCRET NON LU : RIEN DE CELA NE SERA SERVI. Manquent aussi les décrets d'application, la jurisprudence de l'ANRMP, et la procédure du quitus de non-redevance exigé pour soumissionner. ⚠ TECHNIQUE : l'extraction -layout du Journal officiel ENTRELACE LES QUATRE COLONNES et est illisible ; c'est le fichier -flux.txt qu'on lit et qu'on cite.

## Références

### CL-SALIF-18 · Grilles de coût de transport et d'entreposage observées
- **Pourquoi** : Chiffrer une logistique sans repère
- **Où chercher** : Devis réels de prestataires
- **Trouvé** : Non
- **Intégré** : Non
- **Pièce, ici** : references/pieces/1eI2oJ0863Sf8tRL5yHDV8kIcN2fz4RPhK0xMMAFFlGI.md
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON TROUVÉ, et c'est attendu : une grille de coût de transport ou d'entreposage SE RELÈVE SUR DES DEVIS RÉELS, elle ne se publie pas. Les seuls repères de coût rencontrés le 18/09 sont indirects : les SURESTARIES au-delà de cinq jours de stockage au port, mentionnées par le guide de la CCI France Côte d'Ivoire sans barème ; et le DROIT UNIQUE DE SORTIE à l'export, dont les prix CAF de référence et les taux sont fixés par le Conseil des ministres AVANT CHAQUE CAMPAGNE. ⏸ À constituer à partir des devis que la maison reçoit, en datant chaque ligne : un tarif de transport sans date ne vaut rien.
