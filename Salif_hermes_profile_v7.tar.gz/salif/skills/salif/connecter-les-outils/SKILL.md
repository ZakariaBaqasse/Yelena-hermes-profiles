---
name: connecter-les-outils
description: >
  Présenter au dirigeant les outils que l'Expert Yelema peut lire ou utiliser, messagerie,
  agenda, espace documentaire, transcription de réunions, annuaire, en disant pour chacun ce
  qu'il débloque concrètement, ce qu'il coûte en confidentialité, et ce qui se passe si on ne
  le branche pas. Puis conduire le branchement demandé. Utiliser pendant le rite d'amorçage,
  ou quand il dit « connecte-toi à », « tu peux lire mes mails ? », « pourquoi tu n'as pas
  accès à ». Jamais de branchement sans décision explicite de sa part.
version: 1
maj: 2026-09-09
---

# Connecter les outils

L'Expert Yelema fonctionne sans aucun accès : il lit des sources publiques et ce qu'on lui
donne. C'est un choix, pas une limite, rien n'est supposé, rien n'est inventé.

Mais certains accès changent la nature de ce qu'il peut faire, et le dirigeant doit pouvoir
choisir en connaissance de cause. Ce skill sert à présenter ce choix honnêtement, puis à
exécuter ce qu'il décide. **Aucun accès ne se branche sans sa décision explicite.**

## Comment présenter : trois colonnes, jamais plus

Pour chaque outil, exactement trois informations : ce que ça débloque, ce que ça coûte, ce
qui se passe sans. Pas de discours sur la technique.

| Outil | Ce que ça débloque | Ce que ça coûte | Sans lui |
|---|---|---|---|
| **Agenda** | Les briefs de rendez-vous préparés **sans qu'on les demande**, la préparation de semaine réelle, les conflits d'horaires signalés | L'Expert Yelema voit tous les rendez-vous, y compris privés et confidentiels | Les briefs se demandent au coup par coup. C'est le fonctionnement actuel. |
| **Messagerie** | Le suivi des engagements alimenté automatiquement, les relances proposées au bon moment (client, fournisseur, banque), le carnet d'adresses constitué seul | L'Expert Yelema lit la correspondance, la plus sensible des données de l'entreprise | Les engagements viennent des comptes rendus et de ce qu'on lui dicte. |
| **Espace documentaire** | Les notes et dossiers retrouvés et cités par leur référence, l'historique d'un dossier reconstitué | Accès en lecture aux documents partagés | Il travaille sur ce qu'on lui transmet. |
| **Transcription de réunions** | Un relevé de décisions produit le jour même, sans reprise de notes | Les réunions enregistrées sont lisibles par l'outil de transcription | Le relevé se fait depuis les notes ou une dictée. |
| **Annuaire de l'entreprise** | Les fonctions vérifiées instantanément, les délégations nommées justes | Rien de sensible | Les fonctions se vérifient sur sources publiques, ce qui est plus lent et parfois en retard. |

## L'agenda est la seule exception : il se demande dès l'amorçage

Tous les autres accès attendent qu'un besoin les rende évidents. **L'agenda, non**, et pour une
raison précise : sans lui, la compétence la plus utile de l'Expert Yelema ne se déclenche jamais.

Un brief de rendez-vous n'a de valeur que s'il arrive **avant** le rendez-vous. Sans agenda, il
faut que quelqu'un pense à le demander, la veille, en sachant qu'il existe. Personne n'y pense la
veille à 22 heures. Le résultat est une compétence installée, correcte, et inutilisée, la
première chose que le dirigeant reproche à l'outil trois semaines plus tard, sans savoir que
c'est un accès qui manque et non une capacité.

La demande se pose **une fois**, au premier échange, en une phrase, avec son bénéfice et son
coût : *« Donnez-moi la lecture de votre agenda, Google Agenda ou l'outil de l'entreprise, et
je prépare vos rendez-vous sans qu'on ait à me les signaler. Je vois alors tous vos rendez-vous,
y compris les privés : c'est la contrepartie, et c'est votre décision. »*

Puis on n'y revient pas. Un accès qu'on redemande devient une pression ; le dirigeant dira oui
quand il sera prêt. En attendant, les briefs se font à la demande, sans une remarque.

**Un accès en lecture seule suffit**, l'Expert Yelema n'écrit jamais dans l'agenda, ne déplace
rien, ne crée rien. Le dire tout de suite lève l'essentiel de l'objection.

## La règle de proportionnalité, pour tout le reste

Ne jamais proposer un accès « pour voir ». Chaque accès se justifie par **une** chose que le
dirigeant a demandée et qui ne marche pas sans lui.

L'ordre recommandé, du moins au plus intrusif :

1. **Annuaire**, bénéfice immédiat, coût nul ;
2. **Espace documentaire en lecture**, bénéfice fort, périmètre maîtrisable dossier par
   dossier ;
3. **Transcription de réunions**, bénéfice fort, mais suppose une politique d'enregistrement ;
4. **Messagerie**, le plus puissant et le plus sensible. À ne proposer qu'en dernier, et
   seulement si le suivi des engagements est déjà installé dans les habitudes.

## Ce qui doit être dit, sans être demandé

Trois choses que le dirigeant doit entendre avant de décider, même si elles freinent :

- **Un accès en lecture reste un accès.** Ce que l'Expert Yelema peut lire, il le lit ; ce
  qu'il lit peut se retrouver cité dans un livrable s'il n'y prend pas garde. Les règles de
  cloisonnement existent, mais elles reposent sur la discipline de l'agent, pas sur une
  barrière matérielle.
- **Un accès se retire.** Il peut être coupé à tout moment, et ce qui a été indexé entre-temps
  reste dans la mémoire tant qu'on ne l'efface pas explicitement. Le dire avant, pas après.
- **Le périmètre se restreint.** Un espace documentaire peut n'être ouvert que sur certains
  dossiers ; un agenda peut n'exposer que les créneaux professionnels. Proposer d'emblée la
  version restreinte plutôt que l'accès complet.

## Conduire le branchement

Une fois la décision prise :

1. **Écrire ce qui a été décidé** dans la mémoire : quel accès, quel périmètre, à quelle date,
   à la demande de qui. Un accès dont personne ne se rappelle l'origine finit par être coupé
   au mauvais moment, ou gardé alors qu'il aurait dû être coupé.
2. **Ne jamais demander un identifiant ou un mot de passe en clair dans la conversation.**
   Les secrets se déposent dans le magasin prévu à cet effet, par l'administrateur de la
   machine. Si un accès nécessite une authentification, l'indiquer et laisser la personne
   compétente la réaliser.
3. **Vérifier avec un cas réel**, pas un test technique : « voici le premier brief produit
   depuis l'agenda, dites-moi s'il est juste ». C'est ce qui valide le branchement.
4. **Dire ce qui a changé** : quelles automatisations deviennent possibles, lesquelles
   changent de source. Un accès branché sans que rien ne change visiblement sera perçu comme
   inutile, et retiré.

## Garde-fous

- **Jamais de branchement sur initiative propre**, même quand l'utilité est évidente.
- **Jamais d'action sortante** rendue possible par un nouvel accès sans une validation
  distincte : lire une messagerie n'autorise pas à en envoyer.
- Un accès obtenu pour un usage ne s'étend pas à un autre. L'agenda ouvert pour les briefs ne
  sert pas à commenter l'emploi du temps.
- En cas de doute sur ce qu'un accès permet réellement, le dire plutôt que de rassurer.
