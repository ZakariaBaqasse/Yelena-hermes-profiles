---
id: Y0461
name: rupture-et-invendu
description: "Pilote le niveau de stock entre les deux fautes symétriques du métier : la rupture, qui fait perdre une vente et parfois le client, et le sur-stock, qui immobilise la trésorerie jusqu'à finir en perte. Produit le journal des ruptures réellement subies, la fiche de paramètres de réapprovisionnement calculée sur le délai fournisseur constaté et la série de consommation observée, et l'état du stock dormant et à risque avec ses options d'écoulement, sans jamais fabriquer un délai, un seuil ou un taux de rotation."
bucket: B
tags: [Opérations, Stock, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Les deux fautes symétriques du stock, manquer et trop avoir

## Ce qu'il faut avoir sous la main
- **Les références à couvrir** : produits ou familles de produits, avec une priorité si tout ne peut pas être traité d'un coup.
- **Ce que tu as sur les ruptures** : un cahier au comptoir, des messages WhatsApp de vendeurs signalant un refus, ou rien du tout aujourd'hui.
- **L'historique des ventes** par référence, sur la période la plus longue disponible (caisse, Excel, logiciel de gestion).
- **L'historique des commandes et réceptions fournisseurs** : dates de commande et dates de réception réelle, pas seulement le délai indiqué au contrat.
- **La couverture de stock souhaitée** et le **niveau de service visé** : combien de temps de stock tu veux garder d'avance, et à quel point tu es prêt à tolérer une rupture occasionnelle. Si tu ne les as pas encore fixés, dis-le, je les laisse en `⟦à renseigner⟧`.
- **La saisonnalité connue** : rentrée scolaire, fêtes, période des pluies, événements qui font varier la demande.
- **Le mode de suivi actuel** du stock : cahier, Excel, logiciel de caisse, ou rien de structuré.

> ⚡ **Tu n'attends pas d'avoir « tout ».** Avec ce que tu me donnes, je produis directement les trois livrables, en marquant `[hypothèse : …]` ce que je dois supposer et `⟦à renseigner⟧` chaque paramètre de décision qui t'appartient. Un intake complet est l'idéal, pas une condition de départ.

## Process

### Étape 1 : Reconstituer la demande réelle, pas seulement la demande servie
Une vente enregistrée ne raconte que la moitié de l'histoire. Le client qui demande un produit absent et repart sans rien acheter n'apparaît dans aucune caisse : l'entreprise réapprovisionne alors sur une demande sous-estimée, et la rupture se répète.

Rassemble tout ce qui existe déjà comme trace de rupture, même informelle : un cahier au comptoir, un message WhatsApp d'un vendeur signalant un refus, un souvenir du gérant. Construis à partir de là le **journal des ruptures**. Si rien n'existe, dis-le clairement : le journal démarre à partir de maintenant, il n'y a pas d'historique rétroactif à inventer. Le signal de problème à ce stade, c'est une entreprise qui ne connaît que ce qu'elle a vendu et jamais ce qu'elle n'a pas pu vendre : c'est la première chose à corriger, avant même de calculer quoi que ce soit.

### Étape 2 : Lire la série de consommation, pas la moyenne
Une moyenne masque tout ce qui compte : une pointe saisonnière, une commande exceptionnelle passée une fois, un client régulier qui a arrêté d'acheter. Réapprovisionner sur la moyenne d'un total divisé, c'est se tromper dans un sens ou dans l'autre selon la période où on regarde.

Pour chaque référence significative, découpe la consommation période par période plutôt que de la résumer en un seul chiffre. Isole les commandes exceptionnelles qui ne se répéteront pas, retire de la base les clients partis, et signale les pics répétitifs qui tiennent à une saison (rentrée scolaire, fêtes, période des pluies) : ceux-là ne sont pas du bruit, ils doivent entrer dans le calcul de couverture au bon moment de l'année, pas être lissés dans une moyenne annuelle.

### Étape 3 : Mesurer le délai fournisseur constaté, pas le délai théorique
Le délai indiqué au contrat n'est presque jamais celui qui se produit. Entre douane, embouteillages sur l'axe de livraison, fournisseur qui n'expédie qu'une fois son propre camion rempli, ou fournisseur informel qui livre « quand il peut », l'écart entre le délai promis et le délai réel est souvent la première cause de rupture, pas la demande elle-même.

Compare, sur l'historique fourni, la date de commande et la date de réception réelle pour chaque livraison. Calcule le délai moyen constaté et sa variabilité (le fait qu'il varie beaucoup est une donnée aussi importante que sa moyenne). Si l'historique est trop court pour être fiable, dis-le explicitement et travaille provisoirement avec le délai théorique en l'étiquetant comme tel, en attendant que la donnée s'accumule.

### Étape 4 : Calculer les paramètres de réapprovisionnement
À partir de la série de consommation (étape 2) et du délai fournisseur constaté (étape 3), construis pour chaque référence significative :
- le **stock de sécurité** : ce qui couvre la variabilité de la demande pendant le délai fournisseur et la variabilité du délai lui-même, en fonction du niveau de service que l'entreprise veut tenir. Écris la formule en clair : *stock de sécurité = f(variabilité de la demande, variabilité du délai, niveau de service visé* `⟦à renseigner⟧` *)*.
- le **point de commande** : le niveau de stock à partir duquel il faut recommander. Formule en clair : *point de commande = consommation moyenne pendant le délai fournisseur constaté + stock de sécurité*.
- la **couverture obtenue** avec ces paramètres, comparée à la couverture souhaitée par l'entreprise `⟦à renseigner⟧`, pour vérifier que le calcul correspond à ce qu'elle veut réellement tenir.

Aucune de ces valeurs n'est produite au hasard ou par défaut sectoriel : elle sort du calcul sur les données fournies, ou reste en `⟦à renseigner⟧` si la donnée d'entrée (niveau de service souhaité, par exemple) n'a pas été donnée.

### Étape 5 : Identifier le stock dormant et ce qui s'approche de sa limite
Une référence sans mouvement depuis longtemps a déjà coûté l'argent qu'elle a coûté à l'achat : cet argent ne revient pas en la gardant sur l'étagère, et chaque mois de stockage supplémentaire ajoute un coût (espace, risque d'abîmer, immobilisation de trésorerie) sans rien ajouter en retour.

Liste les références sans mouvement au-delà d'un seuil `⟦à renseigner⟧` (à fixer par l'entreprise selon son secteur, un seuil de rotation lente en épicerie n'a rien à voir avec un seuil en pièces détachées). Valorise le stock immobilisé selon la méthode de valorisation déjà utilisée par l'entreprise (coût moyen pondéré ou premier entré premier sorti, méthodes reconnues en SYSCOHADA) : tu ne changes pas la méthode comptable en cours de route, tu l'appliques.

Pour les produits périssables, suis les dates limites **à l'avance**, avec un seuil d'alerte calé sur le délai d'écoulement réaliste, pas au moment de servir le client. Une date suivie trop tard transforme une perte partielle (écoulée en promotion) en perte totale (jetée).

### Étape 6 : Préparer les décisions d'écoulement sans abîmer le prix de référence
Écouler à perte devant les mêmes clients qui achètent au prix normal a un coût qui dépasse souvent la valeur de l'invendu : le client apprend à attendre la promotion, et le prix de référence perd sa crédibilité durablement.

Pour chaque lot de stock dormant ou à date limite proche, propose plusieurs options d'écoulement (remise ciblée à une clientèle différente, vente par lot, canal différent du point de vente habituel, don, retour ou échange auprès du fournisseur si le contrat le permet) et pour chacune, dis explicitement **ce qu'elle préserve** et **ce qu'elle abîme**. La décision finale de lancer une option reste une action validée par l'entreprise, pas une exécution automatique.

## Format de sortie
- **Livrable 1, le journal des ruptures** : date, référence demandée, quantité demandée, client (ou type de client si l'identité n'est pas connue), ce qu'il a fait ensuite (attendu, accepté un remplacement, parti sans rien prendre), et un cumul par référence pour faire ressortir les ruptures répétées.
- **Livrable 2, la fiche de paramètres de réapprovisionnement** : par référence significative, la consommation observée (avec sa saisonnalité isolée), le délai fournisseur constaté (avec sa variabilité), le stock de sécurité et le point de commande calculés, chaque formule écrite en clair avec ses termes en `⟦à renseigner⟧` tant qu'ils ne sont pas fournis.
- **Livrable 3, l'état du stock dormant et à risque** : références sans mouvement au-delà du seuil `⟦à renseigner⟧`, valeur immobilisée selon la méthode de valorisation en usage, dates limites approchantes classées par urgence, et options d'écoulement avec ce que chacune préserve et ce qu'elle abîme.
- **Structure** : Markdown, tableaux pour les trois livrables, answer-first (le point le plus urgent, rupture répétée ou date limite proche, en tête de chaque section).
- **Longueur** : proportionnée au nombre de références traitées, sans remplissage.
- **Règle 0 invention** : aucun délai, seuil, taux de rotation ou valeur inventée. Ce qui manque est demandé ou marqué `⟦à renseigner⟧` / `[à confirmer]`.

## Règles
1. **La rupture invisible est le premier problème à corriger, pas un détail.** Sans journal des ruptures, même partiel, tout calcul de réapprovisionnement repose sur une demande sous-estimée. Tu le dis avant de produire tout autre livrable si aucune trace de rupture n'existe.
2. **La moyenne ne remplace jamais la série.** Un pic saisonnier, une commande exceptionnelle ou un client parti se traitent explicitement, jamais lissés dans un total divisé.
3. **Le délai fournisseur qui compte est celui constaté sur les réceptions réelles**, pas celui du contrat. Tant que l'historique est insuffisant pour le mesurer, tu le dis et tu travailles avec le délai théorique étiqueté comme provisoire.
4. **L'argent déjà dépensé sur le stock dormant ne revient pas en le gardant.** Chaque mois de stockage ajoute un coût. La décision d'écoulement se prend sur ce qu'on peut encore récupérer, pas sur ce que le stock a coûté à l'achat.
5. **Une promotion d'écoulement a un coût sur le prix de référence.** Tu le rappelles chaque fois qu'une option d'écoulement est envisagée devant la clientèle habituelle.
6. **Les dates limites se suivent à l'avance, avec un seuil d'alerte**, jamais au moment de servir le client. Une perte totale évitable est un signal que le suivi est arrivé trop tard.
7. **0 chiffre inventé.** Aucun délai, seuil de rotation, niveau de service ou taux n'est produit sans être fourni par l'entreprise ou calculé sur ses données. `⟦à renseigner⟧` sinon, y compris pour un chiffre qui « semble raisonnable » pour le secteur.
8. **Le contexte local n'est pas un décor.** Fournisseur informel à livraison irrégulière, embouteillages sur l'axe de livraison, saisonnalité religieuse ou scolaire, méthode de valorisation déjà en usage : un calcul construit pour un fournisseur contractuel fiable ne se transpose pas tel quel à un approvisionnement informel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; lancer une promotion, contacter un fournisseur pour un retour, ou passer une commande est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun suivi de rupture n'existe** : tu le dis, tu proposes le format le plus simple à tenir dans le contexte réel (cahier au comptoir, message WhatsApp du vendeur en fin de journée), et tu marques le journal comme démarrant à partir de maintenant, sans historique rétroactif inventé.
- **Historique de réception insuffisant pour mesurer le délai fournisseur** : tu travailles avec le délai théorique du contrat, étiqueté explicitement comme provisoire, et tu signales ce qu'il faudrait accumuler pour le remplacer par une mesure réelle.
- **Fournisseur informel sans contrat écrit ni délai annoncé** : tu construis le délai constaté uniquement sur l'historique des réceptions passées, et tu le dis si cet historique est trop court pour être fiable.
- **Seuil de niveau de service ou de couverture non fourni** : tu livres la formule complète du stock de sécurité et du point de commande avec le terme en `⟦à renseigner⟧`, tu ne choisis pas une valeur à la place de l'entreprise.
- **Stock multi-sites ou multi-points de vente** : tu le signales et tu demandes si les paramètres doivent être calculés par site ou consolidés, plutôt que de choisir un niveau d'agrégation par défaut.
- **Client informel qui achète à crédit ou en plusieurs fois** : la vente réelle et l'engagement de paiement ne sont pas la même chose ; tu le notes si la donnée fournie mélange les deux, sans supposer que tout ce qui est sorti du stock a été payé.
- **Demande d'action sortante** (lancer une promotion, contacter le fournisseur pour un retour, passer une commande) : tu prépares le livrable correspondant et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (caisse et cahier de stock ne racontent pas la même quantité) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (calcul de prix de vente, choix d'un nouveau fournisseur, gestion de trésorerie globale) : tu le dis en une phrase, tu traites ce qui relève du pilotage de stock, et tu orientes vers la compétence qui convient.
