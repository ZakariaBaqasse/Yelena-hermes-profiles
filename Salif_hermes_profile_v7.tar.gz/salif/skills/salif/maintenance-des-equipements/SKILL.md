---
id: Y0459
name: maintenance-des-equipements
description: "Met en place l'entretien préventif des équipements dont dépend l'activité (véhicules, groupes électrogènes, chambres froides et congélateurs, machines de production, informatique, installations électriques) : inventaire classé par criticité, plan d'entretien construit à partir des préconisations constructeur et de l'usage réel, carnet d'intervention, et fiche de panne prête à être lue au moment où ça casse, sans jamais fabriquer une périodicité ou une valeur technique de mémoire."
bucket: B
tags: [Opérations, Maintenance, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Les machines, les véhicules et le froid, avant qu'ils lâchent

## Ce qu'il faut avoir sous la main
- **La liste des équipements** qui font tourner l'activité : véhicules, groupe électrogène, chambre froide ou congélateur, machines de production, matériel informatique, installations électriques. Pense à ceux qu'on oublie autant qu'à ceux qu'on voit tous les jours.
- **Pour chacun** (même de façon incomplète) : son âge, son état, s'il existe une documentation constructeur ou un contrat d'entretien, qui s'en occupe aujourd'hui.
- **Les conditions réelles d'usage** : poussière, chaleur, coupures de courant, état des routes parcourues, charge par rapport à la capacité nominale.
- **L'historique** : un carnet existe-t-il déjà, ou l'entretien se fait au feeling. Ce qui s'est déjà cassé, et ce que ça a coûté.
- **Les prestataires actuels** : qui répare quoi, avec quel contact.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `⟦à renseigner⟧` tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process

### Étape 1 : Faire l'inventaire et trancher la criticité avant tout le reste
Liste tous les équipements dont dépend l'activité, en veillant particulièrement à ceux qu'on oublie parce qu'ils sont discrets : chambre froide, groupe électrogène, installation électrique, à côté de ceux qu'on voit tous les jours comme le véhicule de service. Pour chacun, la question qui tranche la criticité : si cet équipement tombe demain, qu'est-ce qui s'arrête, et combien de temps l'activité tient sans lui. Classe en critique, important, secondaire selon cet impact réel, jamais selon la valeur d'achat ou la visibilité de l'équipement.

Piège du métier : la voiture de service passe souvent avant le congélateur, alors qu'une coupure de froid non anticipée détruit un stock en quelques heures et de façon irréversible, surtout par forte chaleur.

### Étape 2 : Interroger l'usage réel avant de reprendre la périodicité du constructeur
Le manuel donne une périodicité pensée pour des conditions nominales. Pose systématiquement : niveau de poussière, température ambiante, régularité et qualité de l'alimentation électrique, charge réelle par rapport à la charge nominale, état des routes parcourues, fréquence des démarrages et arrêts. Chaque facteur aggravant resserre la périodicité, mais ce n'est pas la skill qui décide du nouveau chiffre : elle pose la question, marque `⟦à renseigner⟧`, et l'ajustement final revient au responsable technique ou au prestataire qualifié, sur une base sourcée.

Erreur du débutant : appliquer le tableau du constructeur tel quel, alors qu'un groupe électrogène qui compense des coupures de courant fréquentes démarre et s'arrête bien plus souvent que ce que le manuel avait imaginé.

### Étape 3 : Construire le plan d'entretien à partir d'une source identifiée
Pour chaque équipement critique ou important, liste les opérations d'entretien préventif recommandées, avec la source exacte de la périodicité : manuel constructeur, prestataire agréé, ou usage réel documenté. Jamais « estimation » ni « moyenne du secteur ». Si aucune source n'est disponible, le champ périodicité reste `⟦à renseigner⟧` et devient une action à mener (contacter le constructeur, le distributeur local, le prestataire agréé). Précise qui exécute l'opération (équipe interne, prestataire externe, contrat en place), la durée d'immobilisation prévisible, et le coût estimé si connu.

### Étape 4 : Organiser le carnet d'intervention comme mémoire de l'atelier
Sans historique, on ne voit pas la panne qui revient, ni le prestataire qui refait deux fois la même réparation, ni le moment où le coût cumulé de réparation dépasse la valeur de remplacement. Le carnet consigne, par équipement : date, panne ou opération réalisée, diagnostic, pièce changée, prestataire, coût, durée d'arrêt.

Adapte au terrain : un carnet tenu par un message WhatsApp horodaté avec photo de la facture vaut souvent plus qu'un cahier papier qui reste au garage. Piège : le carnet existe, mais seulement dans la tête du chef d'atelier ; il part avec lui le jour où il quitte l'entreprise.

### Étape 5 : Anticiper les pièces à délai d'approvisionnement long
Distingue les pièces disponibles chez un fournisseur local, à délai court, des pièces qui viennent de l'étranger et transitent par l'import, à délai souvent long et parfois imprévisible. Pour ces dernières, pose la question d'un stock minimal de sécurité : quelle quantité, financée comment, périmée quand pour les pièces qui s'altèrent. Le seuil de stock est une décision de l'équipe, marquée `⟦à renseigner⟧`, jamais un chiffre produit par la skill.

Erreur fréquente : commander la pièce le jour où l'équipement tombe en panne, alors que l'arrêt aurait pu être évité en connaissant le délai à l'avance et en ayant anticipé.

### Étape 6 : Préparer la fiche de panne pour qu'elle soit lisible dans l'urgence
Pour chaque équipement critique, la fiche répond avant que la panne arrive : qui prévenir et dans quel ordre, quelle mesure conservatoire immédiate prendre (couper le courant, transférer la marchandise congelée vers un point froid de secours, immobiliser un véhicule en sécurité), quel prestataire appeler et avec quel contact, quel effet sur les clients et quel message leur envoyer, déjà rédigé.

Une fiche écrite après la panne ne sert à rien : c'est son principe même, elle doit exister avant. Pour une chambre froide, la question du temps de tenue au froid sans électricité et de la solution de repli (glace, groupe de secours, chambre froide voisine) doit avoir une réponse écrite d'avance, pas improvisée pendant que le stock fond.

## Format de sortie
- **Livrable** : trois documents. L'**inventaire des équipements** (équipement, rôle, criticité, âge, état, documentation disponible, contrat d'entretien éventuel). Le **plan d'entretien** (opération, périodicité `⟦à renseigner⟧` avec sa source, exécutant, durée, coût estimé, date prévue, date faite). La **fiche de panne**, une par équipement critique (qui prévenir, mesure conservatoire immédiate, prestataire et contact, effet sur les clients, message préparé).
- **Structure** : Markdown, tableaux pour l'inventaire et le plan d'entretien, fiche courte et actionnable pour chaque équipement critique, lisible par quelqu'un qui n'a pas rédigé le document.
- **Longueur** : proportionnée au nombre d'équipements traités, sans remplissage.
- **Les périodicités et les seuils sont un input**, pas une production : la skill livre la structure, l'opération et la question à trancher ; la valeur vient du constructeur, du prestataire ou de l'équipe, et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune périodicité, aucun coût, aucun seuil de stock inventé. Donnée manquante marquée « à confirmer / `⟦à renseigner⟧` ».

## Règles
1. **La périodicité n'est jamais produite de mémoire.** Elle vient de la documentation constructeur, d'un prestataire agréé, ou d'un usage réel documenté et sourcé. Sinon : `⟦à renseigner⟧`.
2. **Le curatif seul n'est jamais présenté comme une politique de maintenance suffisante.** Si l'entreprise n'a que du curatif, tu le dis explicitement comme un manque, pas comme un choix acceptable.
3. **La criticité se juge sur l'impact réel sur l'activité**, jamais sur la valeur d'achat ni sur la visibilité de l'équipement.
4. **L'usage réel prime sur la préconisation nominale.** Chaque facteur aggravant (poussière, chaleur, coupures de courant, surcharge, état des routes) est nommé avant de reprendre un chiffre du constructeur tel quel.
5. **Aucun stock de pièce, aucun seuil de criticité, aucun coût estimé n'est inventé.** Donnée fournie, ou `⟦à renseigner⟧`.
6. **La fiche de panne est écrite pour être lue pendant l'urgence, pas pour documenter après coup.** Elle reste lisible sans expertise technique par la personne de garde ce jour-là.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter un prestataire, commander une pièce ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune documentation constructeur disponible**, tu produis le plan avec la périodicité en `⟦à renseigner⟧`, et tu inscris comme action « contacter le constructeur ou le distributeur local » plutôt que d'inventer un rythme plausible.
- **Aucun historique de pannes (carnet inexistant)**, tu le signales explicitement comme un manque, tu proposes le format de carnet à mettre en place (y compris un format simple par message horodaté), et tu ne fabriques pas d'historique rétroactif.
- **Prestataire unique et informel, sans contrat écrit**, tu le notes tel quel dans l'inventaire, tu ne présumes pas d'un niveau de service qui n'a pas été formalisé.
- **Pièce introuvable localement ou délai d'import inconnu**, tu marques le délai `⟦à renseigner⟧` et tu poses la question du stock minimal comme décision à prendre, sans avancer un délai plausible.
- **Panne réelle survenant pendant la construction du plan**, tu le signales, tu bascules sur la fiche de panne de l'équipement concerné en priorité, et tu reprends le reste du plan ensuite.
- **Demande hors périmètre** (achat d'équipement neuf, financement, choix d'un nouveau prestataire sur critère de prix), tu le dis en une phrase, tu traites ce qui relève de la maintenance, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (commande de pièce, appel à un prestataire, paiement), tu prépares le contenu et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le manuel dit une chose, le prestataire local en dit une autre), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
