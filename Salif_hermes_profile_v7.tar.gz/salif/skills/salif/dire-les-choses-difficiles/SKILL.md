---
id: Y0479
name: dire-les-choses-difficiles
description: "Rédige le message qu'on n'a pas envie d'écrire : un refus, un retard, une erreur venue de la maison, ou une position à tenir devant quelqu'un qui insiste. Livre le message prêt à envoyer, sa version pour un autre canal, la liste de ce qu'il n'engage pas, et la phrase de tenue si la position risque d'être contestée, sans jamais promettre une réparation à la place de la maison ni inventer une date, un motif ou un montant."
bucket: A
tags: [Socle, Relation, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Annoncer un refus, un retard ou une erreur, sans se justifier ni promettre

## Ce qu'il faut avoir sous la main
- **La situation** : refus, retard, erreur de la maison, ou position à tenir face à quelqu'un qui insiste (plusieurs à la fois, si c'est le cas).
- **Le destinataire** : qui il est, quelle relation tu as avec lui (client, fournisseur, administration, livreur, collègue), et le canal que tu utilises d'habitude avec lui.
- **Le fait** : ce qui s'est passé ou ce qui va se passer, dans l'ordre, avec ce que le destinataire sait déjà et ce qu'il ignore.
- **Ce que la maison peut réellement proposer**, si une réparation ou une compensation est envisageable, cette décision vient de toi, pas de moi.
- **Le canal visé** pour l'envoi final : écrit long, message court, ou passage à l'oral.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Identifier la situation exacte, sans les mélanger
Une situation est un refus, un retard, une erreur de la maison, ou une position à tenir face à l'insistance. Si le contexte en mélange deux (un retard qui vient d'une erreur, par exemple), tu ne fabriques pas un message hybride flou : tu traites chaque brique séparément à l'intérieur du même message, dans l'ordre où le destinataire en a besoin.

Ce qui trahit un début de dérapage ici : vouloir « adoucir » en fusionnant le refus avec une explication qui ressemble à une excuse pour autre chose. Chaque brique reste nette.

### Étape 2 : Poser la nouvelle en premier
La première phrase du message porte l'information, pas le contexte, pas la politesse d'ouverture, pas l'annonce qu'on va annoncer quelque chose. Un refus se lit dans la première ligne. Un retard se lit dans la première ligne, avec la nouvelle date. Une erreur se lit dans la première ligne, nommée sans détour.

Le piège classique : enterrer la nouvelle au milieu d'un paragraphe d'explication. Le destinataire lit jusqu'au bout en cherchant la réponse, et retient l'embarras plutôt que le fait.

### Étape 3 : Couper la justification, retirer l'ambiguïté
Une fois la nouvelle posée, tu gardes uniquement les raisons qui servent au lecteur (ce qu'il doit comprendre pour agir), tu retires celles qui servent seulement à faire pardonner. Une explication qui dépasse deux ou trois lignes se lit comme de la gêne, et une gêne s'exploite : un refus long se négocie, un refus court se respecte.

Tu passes ensuite chaque formule au crible de l'ambiguïté : « on verra », « ce n'est pas exclu », « je reviens vers vous », « pour le moment » sont lues comme des oui déguisés. Si le non est définitif, il se dit en non. Si une porte reste ouverte, tu dis précisément laquelle et à quelle condition, tu ne la laisses pas flotter.

### Étape 4 : Régler la responsabilité, sans coupable et sans promesse à la place de la maison
Sur une erreur, tu distingues ce qui est réellement de la maison et ce qui ne l'est pas. On ne s'excuse pas de ce dont on n'est pas responsable, cela affaiblit inutilement le message. On reconnaît sans détour ce dont on l'est, ne pas le faire coûte beaucoup plus cher que l'erreur elle même.

Tu ne désignes jamais un collègue, un fournisseur ou un outil comme coupable dans le message : le destinataire ne retient que le désordre interne que ça révèle, jamais la nuance qu'on voulait donner.

Tu ne promets pas la réparation dans le même mouvement que tu annonces l'erreur, sauf si celui qui écrit t'a donné une décision déjà prise. Réparer engage la maison, pas la personne qui rédige. La formule correcte est : on reconnaît, on dit qu'on revient avec ce qui est proposé, et un délai réaliste pour revenir est donné, à condition d'être tenu.

### Étape 5 : Sur un retard, régler le moment de l'annonce
Un retard s'annonce le jour où il est connu, pas le jour où il arrive : c'est presque toujours plus tôt qu'on ne le pense au moment d'écrire. Le message donne la nouvelle date, jamais un vague décalage (« un peu plus tard », « bientôt »). Une cause externe réelle (embouteillage, coupure réseau, indisponibilité d'un service mobile money, saisonnalité d'un fournisseur) peut être mentionnée en une phrase brève, comme un fait, jamais développée comme une justification qui s'étire.

### Étape 6 : Sur une position à tenir, préparer la phrase qui ne bouge pas
Quand le sujet est de nature à être recontesté (un refus qu'on insiste à faire revenir, une décision qu'on cherche à négocier), tu prépares en plus la **phrase de tenue** : ce qui se répond une seule fois si l'on insiste, avec éventuellement ce qu'on peut faire à la place, puis on s'arrête. Répéter la même phrase de plus en plus fort ne tient pas une position, ça la fait céder par usure. Le silence qui suit la phrase de tenue fait partie de la réponse, pas un manque de réponse.

### Étape 7 : Régler le registre sur la personne et sur le canal
Le tutoiement, l'emoji, la formule d'ouverture, la longueur et le degré de formalité ne se choisissent jamais par habitude : ils dépendent de qui reçoit et par où. Une administration (DGI, CNPS, une banque) reçoit un registre neutre et complet, même sur un canal court. Un livreur ou un fournisseur avec qui la relation est orale et de proximité reçoit un message plus direct, mais tout aussi net sur le fond. Un doute sur le registre se résout toujours vers le plus neutre, jamais vers le plus familier.

Si le canal habituel de la relation est une messagerie (WhatsApp, SMS) plutôt qu'un écrit long, tu produis une **version courte** distincte : les mêmes trois éléments (nouvelle, raison réduite, ce qui suit) mais tenus en quelques lignes, sans réduire simplement l'écrit long, en le réécrivant pour le format.

### Étape 8 : Assembler le livrable
Tu réunis : le message prêt à envoyer dans le canal principal, sa version pour l'autre canal si le contexte l'exige, la liste de ce que le message n'engage pas (écrite à part, pour que celui qui l'envoie sache exactement ce qu'il promet), et la phrase de tenue si la position risque d'être recontestée.

## Format de sortie
- **Livrable** : le message prêt à envoyer (canal principal indiqué par l'utilisateur), sa version pour un autre canal si le sujet doit passer à l'oral ou par une messagerie courte, la liste de ce que le message n'engage pas, et la phrase de tenue quand la situation le justifie.
- **Structure** : Markdown clair, le message d'abord tel qu'il sera envoyé, puis la liste des engagements et non-engagements, puis la phrase de tenue si présente.
- **Longueur** : un message de refus, de retard ou d'erreur tient rarement plus de quelques lignes. La brièveté est un signe de solidité, pas un manque de soin.
- **Réparations et délais annoncés** : une valeur (montant, date, geste commercial) n'apparaît dans le message que si elle a été donnée par l'utilisateur comme décidée. Sinon elle reste `⟦à renseigner⟧` et le message le signale plutôt que de l'inventer.
- **Règle 0 invention** : aucun motif, aucune date, aucun montant, aucune référence à un tiers n'est fabriqué. Ce qui manque est demandé ou marqué `[à confirmer]`.

## Règles
1. **La nouvelle est la première phrase.** Jamais enterrée dans un paragraphe de contexte ou de politesse.
2. **La justification est courte.** Deux ou trois lignes maximum, uniquement ce qui sert au lecteur à comprendre ou à agir, jamais ce qui sert à faire pardonner.
3. **Aucune formule ambiguë ne remplace un non clair.** « On verra », « ce n'est pas exclu », « je reviens vers vous » sont bannis quand la réponse est en réalité définitive.
4. **On ne s'excuse pas de ce dont on n'est pas responsable, on reconnaît sans détour ce dont on l'est.** Les deux sens de cette règle comptent également.
5. **Aucune réparation n'est promise dans le message sans avoir été donnée comme décidée par l'utilisateur.** Réparer engage la maison, pas la rédaction du message.
6. **Aucun coupable n'est désigné dans le message**, ni collègue, ni fournisseur, ni outil, ni tiers.
7. **Un retard s'annonce dès qu'il est connu**, avec une nouvelle date précise, jamais un vague décalage.
8. **Une position se tient une fois.** La phrase de tenue se dit, éventuellement suivie de ce qu'on peut faire à la place, puis on s'arrête.
9. **Le registre se règle sur la personne et sur le canal, jamais sur l'habitude.** Une messagerie courte n'est pas un écrit long raccourci, c'est un format à part entière. En cas de doute, le registre le plus neutre l'emporte.
10. **Le contexte local n'est pas un décor.** WhatsApp est un canal de travail ordinaire, un fournisseur ou un client peut être informel, une administration (DGI, CNPS, une institution locale) impose un registre neutre quel que soit le canal, et un remboursement peut se faire en mobile money, mais la décision de le proposer ne vient jamais de la rédaction du message.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un message de travail ; l'envoyer, le publier ou le diffuser est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une situation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Destinataire est une autorité ou une administration** (DGI, CNPS, une banque, un partenaire institutionnel) : le registre reste neutre et complet quel que soit le canal, et tu ne réduis pas la forme sous prétexte de brièveté.
- **Le destinataire insiste après un premier refus** : tu fournis la phrase de tenue, pas une nouvelle justification développée. Si l'insistance dépasse ce cadre, tu le signales à l'utilisateur plutôt que d'improviser une escalade.
- **La cause du retard ou de l'erreur est externe et réelle** (embouteillage, coupure réseau, indisponibilité d'un service de paiement, retard d'un fournisseur) : elle se mentionne en une phrase brève, comme un fait, jamais comme une justification qui s'étire ni comme la désignation d'un coupable.
- **Aucun canal écrit n'est possible, tout passe à l'oral** (appel téléphonique) : tu produis un script oral court, avec les mêmes trois éléments (nouvelle, raison réduite, suite), pensé pour être dit et non lu.
- **Le message part vers plusieurs destinataires à la fois** (groupe WhatsApp, liste de diffusion) : le contenu reste identique pour tous, tu ne fabriques pas une version par personne dans un envoi groupé.
- **Une compensation ou une date est demandée mais pas encore décidée** : tu marques `⟦à renseigner⟧` et tu le signales, tu n'inventes ni montant ni date pour combler.
- **Demande hors périmètre** (rédaction d'un document juridique formel, mise en demeure, contrat) : tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi immédiat, publication, partage) : tu prépares le message et tu t'arrêtes pour validation humaine.
