---
name: automatisations
description: >
  Régler, créer, décaler ou couper les automatisations de Yelema, les tâches qui partent
  seules à heure fixe (revue de presse, relances, radar, veilles). Le dirigeant les demande en
  français, jamais en jargon technique : « décale ma revue de presse à 6 h 30 », « je ne veux
  plus le point du vendredi », « préviens-moi chaque lundi de ce qui arrive à échéance ».
  Utiliser pendant le rite d'amorçage et chaque fois qu'il parle du rythme, des horaires, ou
  de quelque chose qu'il veut recevoir régulièrement.
version: 1
maj: 2026-09-09
---

# Automatisations

Huit automatisations tournent dès l'installation. Elles sont réglées sur une journée
d'entreprise standard, pas sur celle du dirigeant. Les caler sur son rythme réel est le
premier réglage qui se voit, et le moins coûteux.

**Vocabulaire.** On dit « automatisation », jamais « cron » ni « tâche planifiée ». Le
dirigeant n'a pas à connaître le mot ; il a à savoir **ce qui part, quand, et comment
l'arrêter**.

**Jamais une commande, jamais un chemin de fichier.** À l'épreuve, un Expert à qui l'on
demandait « comment je l'arrête ? » a répondu par un script à taper dans un terminal, qu'il
avait au passage inventé. Le client n'a pas de terminal et n'a pas à en avoir un : pour lui,
arrêter une automatisation, c'est te le dire. Tu réponds « dis-le moi et je la coupe », et
c'est tout. Le nom d'un script, un chemin de dossier, un mot comme « planificateur » ou
« tâche système » n'ont rien à faire dans une phrase adressée au client, et un nom de
commande que tu n'as pas lu quelque part est une invention comme une autre.

## Les huit livrées

| Quand | Ce qui part |
|---|---|
| Tous les jours, tôt | La revue de presse et des réseaux du jour |
| Chaque matin de semaine | Les factures et engagements en retard et à échéance sous 48 heures, avec les relances rédigées |
| Lundi matin | Le radar hebdomadaire des dossiers |
| Mardi matin | La veille concurrentielle du secteur |
| Jeudi matin | Les appels d'offres et financements ouverts qui concernent l'activité |
| Vendredi après-midi | La préparation de la semaine suivante |
| Chaque fin de journée de semaine | Les décisions, contrats et actes signés dans la journée |
| Le 1ᵉʳ de chaque mois, tôt | La révision de la mémoire : tout fait et toute fiche non revérifiés depuis 90 jours sont repris sur source primaire et redatés. Ne remonte que ce qui a bougé |

## Les trois règles qui les gouvernent

1. **Le silence est la règle.** Une automatisation qui n'a rien à dire se tait. Elle n'envoie
   pas « rien à signaler ». Un automatisme qui écrit tous les jours pour ne rien dire perd sa
   crédibilité en une semaine, et on cesse de le lire, y compris le jour où il compte.
2. **Rien ne part à l'extérieur.** Les relances, les réponses et les relevés sont *rédigés*,
   jamais envoyés. Une automatisation qui écrirait à un client, un fournisseur ou une banque
   engagerait l'entreprise sans décision humaine.
3. **Jamais deux fois la même chose.** Les veilles tiennent la mémoire de ce qu'elles ont déjà
   signalé et ne remontent un sujet connu que s'il a réellement évolué, auquel cas c'est
   **l'évolution** qu'on écrit, pas l'annonce de départ.

## Ce que le dirigeant peut demander, et ce que ça implique

| Il dit | Ce qu'on fait |
|---|---|
| « Décale ma revue de presse à 6 h 30 » | On change l'heure et on confirme la nouvelle. Effet immédiat, à partir du lendemain. |
| « Je ne veux plus le point du vendredi » | On coupe. On ne supprime pas : elle peut être rallumée telle quelle. |
| « Le lundi c'est trop tôt » | On décale, en vérifiant qu'elle ne tombe pas sur la même minute qu'une autre. |
| « Préviens-moi quand X bouge » | Nouvelle automatisation, mais d'abord : à quelle fréquence, sur quelles sources, et qu'est-ce qui déclenche l'envoi ? |
| « Envoie-moi ça toutes les heures » | On dit non, et pourquoi : au-delà d'un rythme quotidien, on ne surveille plus, on notifie, et on cesse d'être lu. |
| « Mets ça aussi dans le groupe X » | On demande confirmation explicite. Une automatisation ne change jamais de destinataire seule. |

## Créer une automatisation : les quatre questions

Avant de créer quoi que ce soit, quatre réponses. Sans elles, on fabrique du bruit :

1. **Qu'est-ce qui part exactement ?** Un livrable nommé, pas « un point sur ». Si on ne peut
   pas décrire la sortie en une phrase, l'automatisation n'est pas mûre.
2. **À quelle fréquence, et pourquoi celle-là ?** La fréquence se déduit du rythme du sujet :
   les factures changent tous les jours, les appels d'offres toutes les semaines, la
   cartographie des concurrents tous les trimestres.
3. **Qu'est-ce qui justifie un envoi ?** Le critère qui distingue « il s'est passé quelque
   chose » de « rien de neuf ». Sans ce critère, l'automatisation enverra toujours.
4. **Comment on évite la répétition ?** Ce qui a déjà été signalé est mémorisé et ne repart pas.

Puis proposer le réglage en options lettrées, pour qu'il tranche d'un caractère :

```
A. Tous les jours, en fin de journée
B. Deux fois par semaine, mardi et jeudi
C. Une fois par semaine, le lundi matin
```

## Deux précautions de réglage

- **Ne jamais placer deux automatisations à la même minute.** Elles se gênent. Décaler de
  quelques minutes suffit, et c'est invisible pour le lecteur.
- **Vérifier l'heure locale.** Les horaires sont exprimés en temps universel et l'heure
  d'Abidjan lui est identique : ce qui est réglé à 6 h part bien à 6 h. Sur une machine
  installée ailleurs, ce serait à recontrôler.
- **L'horaire se lit dans la ligne `schedule:` du fichier de l'automatisation, jamais dans
  l'affichage du planificateur de la machine.** Cet affichage est traduit dans le fuseau du
  serveur, souvent l'Europe, et une automatisation réglée à 6 h y apparaît à 8 h. Annoncer
  cet horaire\-là à l'entreprise, c'est lui donner une heure fausse de deux heures, avec
  l'étiquette « UTC » par-dessus. La faute a été commise : les huit automatisations ont été
  annoncées en heure de Paris présentée comme temps universel. Elle s'ajoute d'un délai de
  déclenchement aléatoire, qui décale encore l'affichage de quelques minutes sans rien changer
  au réglage. **On annonce toujours l'heure d'Abidjan**, et on le dit, « 6 h, heure d'Abidjan »
  - pour que la question ne se repose pas.

## Après chaque changement

Confirmer en une ligne : ce qui a changé, à partir de quand, et comment revenir en arrière.
Le dirigeant doit toujours savoir ce qui va partir sans qu'il le demande, un agent qui écrit
à des heures qu'on ne maîtrise pas devient une nuisance, quelle que soit la qualité du
contenu.

## Garde-fous

🚨 **Rien de la mécanique interne ne sort vers le client.** Pas un chemin de fichier, pas un nom
de script, pas une ligne de commande, pas un dossier de journaux. À l'épreuve, un Expert à qui
l'on demandait « comment je l'arrête ? » a répondu par trois commandes à taper dans un terminal
- qu'il avait inventées, en recopiant les conventions d'une autre installation qu'il croyait
connaître. Le client n'a pas de terminal. Pour lui, arrêter une automatisation, c'est **te le
dire**, et ta réponse tient en une phrase : « dis-le moi et je la coupe ; le réglage est
conservé si tu veux la reprendre ». Si tu t'apprêtes à écrire un nom de fichier ou une commande
dans un message adressé au client, tu es en train de commettre cette faute.


- Ne jamais créer une automatisation « pour montrer ce qu'on sait faire ».
- Ne jamais en créer une qui produirait une action sortante.
- Une automatisation qui échoue plusieurs fois de suite se signale au dirigeant, en une
  ligne, avec ce qui a été tenté, elle ne se répare pas en silence.
- Toute automatisation nouvelle est **annoncée** avant son premier envoi : personne ne
  découvre un message automatique sans avoir été prévenu qu'il existait.
