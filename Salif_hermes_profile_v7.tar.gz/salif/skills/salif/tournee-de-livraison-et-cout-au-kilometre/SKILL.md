---
id: Y0458
name: tournee-de-livraison-et-cout-au-kilometre
description: "Organise la distribution physique quotidienne des commandes : regroupement en tournées, ordre des points de livraison selon les contraintes réelles du terrain, feuille de route et bordereau de livraison, cadrage des encaissements faits par le livreur, et calcul du coût réel d'une tournée et d'une livraison, sans jamais inventer un paramètre de coût, un plafond d'encaisse ou un seuil de rentabilité."
bucket: B
tags: [Opérations, Logistique, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# La tournée de livraison, son organisation et ce qu'elle coûte vraiment

## Ce qu'il faut avoir sous la main
- **La liste des commandes du jour** : client, adresse ou zone, contenu, montant à encaisser s'il y en a, et mode de paiement attendu (cash, mobile money, déjà payé).
- **Le ou les véhicules disponibles** : type (moto, tricycle, utilitaire, camion), capacité, et le nombre de tournées possibles dans la journée.
- **Ce que tu sais des horaires réels des clients** : quand chaque point ouvre, ferme, ou reçoit effectivement la marchandise, même si c'est approximatif.
- **Les paramètres de coût que tu veux utiliser** : carburant, salaire ou prime du livreur, amortissement du véhicule, entretien, péages, coût de la data si le suivi est numérique. Ce que tu n'as pas, laisse-le, je le marque `⟦à renseigner⟧`.
- **Le plafond d'encaisse** que le livreur ne doit jamais dépasser sans repasser au dépôt, si tu en as déjà un.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les paramètres manquants `⟦à renseigner⟧`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Regrouper les commandes en tournées

Tu pars de la liste de commandes et tu la découpes en tournées cohérentes : par zone géographique, par capacité du véhicule disponible, par type de marchandise (le frais ne voyage pas avec le non alimentaire sans précaution), et par urgence déclarée par le client.

Le piège de départ : regrouper par ordre d'arrivée des commandes plutôt que par logique de terrain. Une commande arrivée en dernier mais située sur le trajet d'une tournée déjà pleine doit y entrer ; une commande arrivée en premier mais isolée géographiquement ne doit pas forcer une tournée à faire un détour qui casse tout le reste.

Si le nombre de commandes dépasse la capacité totale des véhicules disponibles, tu le dis explicitement et tu proposes un ordre de priorité (client à horaires stricts, produit périssable, montant encaissé important) plutôt que de fabriquer une tournée intenable sur le papier.

### Étape 2 : Ordonner les points selon les contraintes réelles, pas la distance

C'est le cœur de l'étape, et c'est là que la plupart des feuilles de route se trompent. **La distance n'explique pas le temps.** En zone urbaine dense, l'heure de départ, le sens de circulation, la proximité d'un marché ou d'une gare routière, une pluie annoncée, un chantier connu, pèsent souvent plus que les kilomètres à parcourir.

Tu construis l'ordre des points à partir de **temps observés** si l'entreprise en a (temps réel constaté sur un trajet similaire un autre jour), pas à partir d'une distance mesurée sur une carte. Si aucun temps observé n'existe encore, tu le dis, tu proposes un ordre raisonné à partir des informations données (horaires clients, sens de circulation connu, zones à embouteillages signalées), et tu marques l'ordre comme `[hypothèse : à confirmer sur le terrain]`.

Tu croises systématiquement avec les **horaires réels des clients** : une boutique qui ferme en début d'après-midi, un marché qui n'ouvre que le matin, un service achats qui ne réceptionne que certains jours de la semaine. Un point mal placé dans l'ordre revient au dépôt avec la marchandise, et c'est un coût de tournée entier reperdu sur un seul client.

### Étape 3 : Préparer les documents qui accompagnent la marchandise

Deux documents, pas un de plus, pas un de moins :

- **La feuille de route** : ordre des points avec heure visée et raison de cet ordre, contact et horaires réels de chaque point, contenu exact à livrer à chacun, montant à encaisser et mode attendu, et rappel explicite du plafond d'encaisse.
- **Le bordereau de livraison**, un par point : références et quantités livrées, état constaté à la remise, nom et signature du réceptionnaire, réserves éventuelles notées au moment de la livraison (pas après), montant réellement encaissé et son mode.

Le piège ici : livrer sans bordereau signé parce que "le client est connu" ou "on n'a pas le temps". Sans preuve de réception datée et signée, une contestation ultérieure du client est ingagnable, et c'est exactement la pièce que la gestion des impayés ou du recouvrement viendra réclamer plus tard. Tu rappelles ce lien chaque fois qu'un contournement du bordereau est envisagé.

### Étape 4 : Encadrer les encaissements faits par le livreur

Le livreur qui encaisse du cash ou reçoit un paiement en mobile money sans cadre est la pratique la plus courante et la plus risqueuse de la distribution. Tu poses quatre règles non négociables dans la feuille de route :

1. Tout encaissement se fait **contre reçu** remis au client, même sommaire.
2. Un **plafond d'encaisse maximal en tournée** est fixé `⟦à renseigner⟧` : au-delà, le livreur repasse au dépôt ou dépose avant de continuer.
3. Un **dépôt quotidien** est prévu en fin de tournée, avec heure et lieu précisés.
4. Un **rapprochement livraison par livraison** est fait entre ce qui était attendu (feuille de route) et ce qui a été effectivement encaissé (bordereaux), jamais un rapprochement global en fin de journée qui masque les écarts point par point.

Si le paiement attendu est en mobile money, tu précises le compte ou le numéro de réception à utiliser, jamais un compte personnel du livreur : c'est un point de contrôle, pas un détail.

### Étape 5 : Calculer le coût réel de la tournée et de la livraison

Tu additionnes les paramètres fournis par l'entreprise (carburant, salaire ou prime du livreur, amortissement du véhicule, entretien, péages, coût de suivi éventuel) pour obtenir un **coût total de la tournée**. Tu divises ensuite par le nombre de livraisons effectuées pour obtenir un **coût moyen par livraison**, et tu le rapproches, point par point, du montant facturé ou de la marge attendue sur chaque client livré.

Le piège structurel : ne jamais faire ce calcul, livrer sans compter, et découvrir des mois plus tard, dans la marge globale de l'entreprise, qu'une partie des livraisons coûte plus cher qu'elle ne rapporte, sans savoir lesquelles. Tu produis systématiquement la liste des points dont le coût dépasse un seuil `⟦à renseigner⟧` fixé par l'entreprise, même si cette liste est courte ou vide.

Chaque paramètre de coût qui manque reste marqué `⟦à renseigner⟧` : tu ne le remplaces jamais par un ordre de grandeur "habituel" du secteur, même plausible.

### Étape 6 : Compter ce qui revient, pas seulement ce qui part

Une tournée n'est pas terminée à la dernière livraison réussie. Tu demandes et consignes systématiquement : les points non livrés et pourquoi (client fermé, marchandise refusée, adresse introuvable), les invendus ou refus rapportés au dépôt, et les trajets faits à vide (retour sans marchandise et sans encaissement).

Ce sont des coûts réels que la tournée a supportés sans generer de revenu en face, et qui doivent apparaître dans le calcul de l'étape 5, pas être traités comme un simple aléa sans impact chiffré.

## Format de sortie
- **Livrable** : trois pièces distinctes : la feuille de route (une par véhicule/tournée), le bordereau de livraison type (un modèle, dupliqué pour chaque point), et le calcul du coût de tournée avec sa ventilation par livraison et par point.
- **Structure** : Markdown, avec tableaux pour la feuille de route (ordre, point, heure visée, contact, contenu, encaissement attendu) et pour le calcul de coût (poste de coût, montant, part dans le total).
- **Longueur** : proportionnée au nombre de commandes du jour, sans remplissage. Une tournée de dix points tient sur une page.
- **Les paramètres de coût et les seuils sont des inputs**, jamais une production : la compétence livre la structure du calcul (coût total, coût moyen par livraison, seuil d'alerte par point), la valeur vient de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun paramètre de coût, plafond d'encaisse ou horaire client n'est inventé. Ce qui manque est demandé ou marqué `⟦à renseigner⟧`.

## Règles
1. **La distance ne fait pas le temps.** L'ordre des points se construit sur des temps observés ou, à défaut, sur un raisonnement explicite tenant compte de la circulation, des horaires clients et de la météo, jamais sur la seule mesure kilométrique.
2. **Tout encaissement se fait contre reçu**, avec un plafond d'encaisse `⟦à renseigner⟧` et un dépôt quotidien. Cette règle est rappelée dès qu'un encaissement en tournée est mentionné sans cadre.
3. **Aucune livraison sans bordereau signé.** Le bordereau est la preuve de réception ; son absence rend toute contestation ultérieure ingagnable pour l'entreprise.
4. **Les horaires réels des clients priment sur les horaires supposés.** Un point mal placé dans l'ordre revient au dépôt, et ce retour a un coût qui doit être compté.
5. **Le coût de la tournée se calcule systématiquement**, même quand le résultat est inconfortable. Une tournée jamais chiffrée cache des clients livrés à perte.
6. **Les retours à vide et les invendus rapportés comptent** dans le coût de la tournée, ils ne sont pas un aléa hors calcul.
7. **0 chiffre inventé.** Aucun coût, plafond, horaire ou seuil n'est produit sans être fourni ou marqué `⟦à renseigner⟧`. Un ordre de grandeur "habituel" du secteur non sourcé reste un chiffre inventé.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme "sourcé" sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette compétence produit des documents de travail ; envoyer la feuille de route au livreur, notifier un client d'un retard ou déclencher un paiement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une tournée ou d'un client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** (paramètres de coût ou horaires clients manquants) : tu produis la feuille de route et le calcul avec ce que tu as, en étiquetant les hypothèses (`[hypothèse : …]`) et en marquant les manques `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer.
- **Aucun temps observé disponible** : tu construis un ordre raisonné à partir des informations données, tu le marques explicitement `[hypothèse : à confirmer sur le terrain]`, et tu recommandes de chronométrer la tournée suivante pour disposer de temps réels.
- **Plafond d'encaisse non fixé** : tu le marques `⟦à renseigner⟧` dans la feuille de route et tu signales le risque tel quel, tu ne fixes pas de plafond à la place de l'entreprise.
- **Commandes dépassant la capacité des véhicules disponibles** : tu le dis explicitement et tu proposes un ordre de priorité argumenté, tu ne fabriques pas une tournée intenable pour faire tenir toutes les commandes sur le papier.
- **Client sans horaires connus** : tu le marques `[à confirmer]` dans la feuille de route et tu places le point avec une marge de sécurité plutôt que de lui attribuer un horaire supposé.
- **Paiement attendu en mobile money sans compte de réception précisé** : tu le signales avant de continuer, tu ne proposes jamais d'utiliser un compte personnel du livreur.
- **Retour ou refus signalé après coup, sans bordereau** : tu le notes comme un trou de preuve, tu ne le reconstitues pas comme si le bordereau avait existé.
- **Demande hors périmètre** (optimisation d'itinéraire algorithmique fine, gestion de flotte à grande échelle, entrepôt) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi de la feuille de route, notification client, déclenchement de paiement) : tu prépares le document et tu t'arrêtes pour validation humaine.
