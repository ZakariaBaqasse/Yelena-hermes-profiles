---
id: Y0467
name: partage-et-acces
description: "Choisit le périmètre de partage adapté à l'usage réel (personne nommée, organisation, lien, public) et le droit le plus faible qui suffit (lecture, commentaire, modification), applique le partage, puis vérifie l'ouverture du point de vue du destinataire, pas du sien, avant l'envoi : fiche d'accès, preuve de test, ligne prête à coller et liste des liens internes vérifiés un par un."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Ouvrir un document au bon périmètre du premier coup, et le prouver

## Ce qu'il faut avoir sous la main
- **Le document** : sa nature, et si son contenu est sensible (chiffres internes, données personnelles, dossier en négociation, ou rien de tout ça).
- **Le ou les destinataires** : nom, interne à l'organisation ou externe, et si tu le sais, avec quel type de compte (professionnel, personnel, aucun compte connu).
- **Ce que le destinataire doit pouvoir faire** : lire seulement, commenter, ou modifier.
- **La durée** : accès permanent, ou lié à un événement précis (réunion, appel d'offres, mission) après quoi il devrait se refermer.
- **L'outil de partage utilisé** par ton organisation, si tu le connais.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le contexte est partiel, je **produis directement le livrable** en étiquetant mes hypothèses (`[hypothèse : …]`) je ne redemande que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Identifier l'usage réel, pas l'usage supposé

Avant de choisir un périmètre, tu établis trois faits : qui va ouvrir ce document, avec quel type de compte, et pour quoi faire exactement. « Le partager avec l'équipe » ne dit rien si l'équipe compte un prestataire externe sans adresse professionnelle, ou un imprimeur qui ne dispose que d'une adresse personnelle. C'est précisément ce cas, le destinataire hors de l'organisation, qui casse le plus souvent, et c'est celui que tu identifies en premier.

Si le destinataire n'a pas de compte dans le domaine de l'organisation, tu le marques dès cette étape : le périmètre « toute l'organisation » ne le touchera jamais, quel que soit ce que tu coches ensuite.

### Étape 2 : Choisir le périmètre le plus étroit qui suffit

Quatre périmètres existent, du plus fermé au plus ouvert :
- **Personne nommée** : seule l'adresse indiquée peut ouvrir. Le plus sûr, le seul qui fonctionne à coup sûr pour un destinataire externe sans compte professionnel.
- **Toute l'organisation** : quiconque a un compte dans le domaine peut ouvrir. Adapté au travail interne, invisible pour un prestataire ou un partenaire externe.
- **Toute personne disposant du lien** : quiconque reçoit le lien, par quelque canal que ce soit, y compris transféré, peut ouvrir. Pratique, mais le lien voyage : un transfert sur un groupe WhatsApp de travail ou une boîte mail partagée expose le document à plus de monde que prévu.
- **Publication ouverte** : indexable, trouvable sans même avoir reçu de lien. Réservé aux contenus destinés à être vus par n'importe qui.

Le choix par défaut est le plus étroit qui couvre l'usage réel identifié à l'étape 1. Si le contenu est sensible (chiffre confidentiel, donnée personnelle, dossier en cours de négociation), tu ne montes jamais au périmètre large pour gagner du temps : le périmètre nominatif est nommé et justifié, ou le partage est refusé et remonté à l'utilisateur. Sur une donnée personnelle, en Côte d'Ivoire, c'est l'ARTCI qui a la charge de la protection des données à caractère personnel : tu ne cites aucun taux ni délai de sa réglementation, mais tu signales que le sujet relève de son périmètre dès que le document en contient.

### Étape 3 : Choisir le droit le plus faible qui permette l'usage

Trois droits existent : lecture, commentaire, modification. Tu choisis le plus faible qui suffit à ce que le destinataire doit faire. Le piège classique : ouvrir en modification par défaut « pour ne pas bloquer », sur un document de référence partagé à plusieurs personnes. Résultat fréquent : le document se fait écraser, souvent sans que personne sache par qui, et sans historique clair de qui a changé quoi.

Si l'usage réel est de recueillir des avis sans modifier le contenu final, le commentaire suffit. La modification n'est accordée que si le destinataire doit réellement produire à l'intérieur du document.

### Étape 4 : Traiter le dossier, le fichier, et les liens imbriqués

Tu distingues explicitement ce qui est partagé : le dossier entier, ou seulement le fichier. Les deux ne se propagent pas dans le même sens selon les outils, et un fichier déplacé après son partage peut perdre les accès qui lui avaient été donnés. Tu le vérifies après tout déplacement du document, pas seulement au moment du partage initial.

Si le document contient lui-même des liens (une présentation qui pointe vers un tableur, un document qui renvoie vers un dossier), chaque lien cité à l'intérieur est ouvert au **même périmètre** que le contenant. Un lecteur qui bute au milieu d'une présentation parce que le tableur en pièce jointe n'est pas ouvert au même niveau ne revient pas voir la suite.

### Étape 5 : Vérifier du point de vue du destinataire, jamais du sien

C'est l'étape qui manque le plus souvent, et c'est elle qui évite la plainte en pleine réunion. Le propriétaire d'un document l'ouvre toujours, quel que soit le périmètre réellement configuré, parce que ses droits de propriétaire priment sur le partage. Tester depuis son propre compte ne prouve rien.

Le test correct : navigation privée sans être connecté à aucun compte, ou connexion avec un compte externe de test, ou à défaut un contrôle explicite de la liste des accès affichée par l'outil de partage. Si le destinataire va probablement ouvrir le lien depuis un téléphone d'entrée de gamme via WhatsApp, tu tiens compte du fait que le navigateur intégré de l'application peut se comporter différemment d'un navigateur classique, et qu'une connexion lente rendra pénible l'ouverture d'un fichier lourd envoyé en lien public plutôt qu'en pièce jointe allégée. Tu notes le résultat du test, pas seulement l'intention de le faire.

Si le test échoue, tu corriges le périmètre ou le droit avant de produire la ligne d'envoi, jamais après.

### Étape 6 : Produire la fiche, la preuve, la ligne, et poser la date de revue

Tu rassembles le tout dans le format de sortie. Si l'accès est lié à un événement (réunion, mission, appel d'offres) plutôt que permanent, tu poses une **date de revue** explicite : un partage ouvert pour une réunion qui reste ouvert des mois est le mode d'échec silencieux le plus fréquent, personne ne pense à le refermer une fois l'usage passé.

## Format de sortie
- **Fiche d'accès** : le document, le périmètre choisi (personne nommée / organisation / lien / public), le droit accordé (lecture / commentaire / modification), pour qui, pourquoi, et la date de revue si l'accès est temporaire.
- **Preuve de test** : la méthode utilisée pour vérifier l'ouverture du point de vue du destinataire (navigation privée, compte externe, contrôle de la liste des accès) et le résultat obtenu, succès ou échec constaté.
- **Ligne prête à coller** dans le message d'envoi : le lien, et une phrase claire sur ce que le destinataire peut y faire (lire, commenter, modifier).
- **Liste des liens internes** au document, chacun avec son périmètre vérifié individuellement, si le document en contient.
- **Structure** : Markdown, answer-first (le périmètre retenu et son motif d'abord), tableau pour la fiche d'accès si plusieurs destinataires.
- **Longueur** : proportionnée, une fiche tient sur une portion de page pour un document simple, plus si plusieurs liens internes sont à vérifier.
- **Règle 0 invention** : aucune durée, aucun périmètre par défaut, aucune règle de confidentialité inventée. Ce qui n'est pas précisé par l'utilisateur reste `⟦à renseigner⟧`.

## Règles
1. **Le test se fait avec les droits du destinataire, jamais avec les tiens.** Un propriétaire qui teste depuis son propre compte ne prouve rien : tu le rappelles chaque fois qu'un partage est déclaré « vérifié » sans précision de la méthode.
2. **Le périmètre le plus étroit qui suffit, le droit le plus faible qui suffit.** Tu ne montes jamais au périmètre ou au droit supérieur par confort ou par gain de temps.
3. **Le contenu sensible ne suit pas la règle de vitesse.** Donnée personnelle, chiffre confidentiel, dossier en négociation : le périmètre large est refusé ou explicitement justifié, jamais choisi par défaut.
4. **Dossier et fichier ne se traitent pas comme une seule chose.** Tu précises systématiquement ce qui est réellement partagé, et tu revérifies après tout déplacement du document.
5. **Chaque lien interne au document est vérifié individuellement.** Un contenant ouvert ne garantit rien sur ce qu'il contient.
6. **Un accès temporaire porte une date de revue posée dès sa création.** Sans date, l'accès est traité comme permanent et signalé comme tel.
7. **0 donnée inventée.** Aucun périmètre par défaut, aucune durée, aucune règle de confidentialité n'est produite sans être fournie par l'utilisateur : `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit une fiche d'accès et une recommandation ; modifier réellement les droits d'un document, envoyer le lien, ou révoquer un accès existant est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un document ou d'un destinataire ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Destinataire externe sans compte professionnel connu** tu le signales explicitement, tu recommandes le périmètre nominatif avec l'adresse personnelle fournie, et tu écartes le périmètre « organisation » qui ne le touchera jamais.
- **Impossible de tester réellement l'ouverture** (pas de compte de test disponible, outil non accessible depuis la conversation) tu le dis clairement, tu fournis la méthode de test à exécuter par l'utilisateur lui-même, et tu ne présentes jamais un partage comme vérifié sans preuve.
- **Le document contient des liens vers des ressources externes à l'organisation** (site public, dépôt tiers) tu le signales à part : leur périmètre n'est pas de ton ressort, seul celui des documents internes l'est.
- **Contenu sensible mais usage urgent invoqué** tu ne cèdes pas sur le périmètre nominatif ; tu proposes le chemin le plus rapide qui reste sûr (partage nominatif immédiat plutôt que lien public) et tu signales l'arbitrage à l'utilisateur si un délai réel est en jeu.
- **Accès déjà existants inconnus ou hérités** (le document a été partagé avant, par quelqu'un d'autre) tu le signales avant de modifier quoi que ce soit : un partage écrasé sans le savoir peut couper l'accès à une personne qui en avait légitimement besoin.
- **Demande hors périmètre** (gestion des mots de passe, sécurité du compte, configuration générale de l'outil documentaire) tu le dis en une phrase, tu traites ce qui relève du partage du document, et tu orientes vers le support ou l'administrateur de l'outil.
- **Action sortante demandée** (envoyer effectivement le lien, modifier réellement les droits) tu prépares la fiche et la ligne prête à coller, et tu t'arrêtes pour validation humaine avant toute action réelle.
- **Sources contradictoires sur le statut du destinataire** (interne selon une personne, externe selon une autre) tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
