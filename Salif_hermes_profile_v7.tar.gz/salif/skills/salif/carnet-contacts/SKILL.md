---
name: carnet-contacts
description: >
  Constituer et tenir le carnet d'adresses de l'entreprise : qui écrit à la direction, à
  quelle organisation, sur quel dossier, quand remonte le dernier échange, et par quel canal
  le joindre. Se remplit à partir de ce qui passe (courriers, comptes rendus, échanges),
  jamais par collecte automatique sans décision. Utiliser quand elle dit « qui est cette
  personne », « comment je le joins », « avec qui j'échange le plus », « fais-moi la liste des
  interlocuteurs sur ce dossier », ou pour préparer une liste d'invitations.
version: 1
maj: 2026-09-09
---

# Carnet de contacts

Une direction perd un temps considérable à retrouver une adresse, un rang hiérarchique ou le
fil d'un échange ancien. Ce carnet règle ça, et, accessoirement, il révèle une information
que personne ne regarde jamais : **avec qui l'entreprise échange réellement**, par opposition
à ceux dont on parle.

## Où ça vit

`memory/reference/contacts/<slug>.md`, une fiche par personne. La fiche de contact et la
fiche d'acteur (`cartographie-acteurs`) sont **le même fichier** : l'une décrit la fonction
et son fondement, l'autre ajoute le canal et l'historique d'échange. Ne pas créer deux
systèmes qui divergeront.

```markdown
# <Nom>

- **Fonction** : <fonction>, vérifiée le <date>, <lien vers l'acte ou la source>
- **Organisation** : <entreprise, filiale, service>
- **Rang hiérarchique** : <si pertinent, l'ordre de citation dans une diffusion en dépend>
- **Canaux** : <adresse professionnelle> · <secrétariat> · <téléphone si fourni par lui>
- **Dossiers** : <dossiers de l'entreprise où il apparaît>
- **Fréquence** : <n échanges recensés sur <période>>
- **Dernier échange** : <date>, <objet>, <lien vers la trace>
- **À savoir** : <une ligne, factuelle, une sensibilité connue, un antécédent utile>
```

## Comment il se remplit

**Par ce qui passe, jamais par une aspiration.** À chaque courrier, compte rendu, relevé de
décisions ou échange transmis à l'Expert IA :

1. relever les personnes citées avec leur fonction ;
2. créer la fiche si elle n'existe pas, l'enrichir sinon ;
3. incrémenter la fréquence et mettre à jour le dernier échange, avec son lien.

Si la messagerie est branchée (`connecter-les-outils`), le remplissage devient automatique
sur les correspondants **récurrents**, et seulement eux : une personne croisée une fois
n'entre pas au carnet. Le seuil par défaut est de **trois échanges**, ajustable.

## La règle des adresses

- Une adresse **professionnelle publiée** (site institutionnel, en-tête de courrier, carte de
  visite remise) s'enregistre sans autre formalité.
- Une adresse **personnelle**, un numéro privé, ou tout contact obtenu autrement que par la
  personne elle-même **ne s'enregistre pas** sans l'accord explicite de la direction.
- **Jamais de collecte hors du périmètre de l'entreprise.** On enregistre ceux avec qui
  l'entreprise échange, pas des listes constituées ailleurs.
- Le carnet ne sort **jamais** du canal de la direction, ne s'exporte pas, ne se partage pas.
  Une liste d'interlocuteurs d'une direction générale est en soi une information sensible.

## Ce que le carnet permet, au-delà de retrouver une adresse

- **Préparer une liste d'invitations** ou une diffusion : qui, à quel rang, dans quel ordre.
- **Vérifier une délégation** : quand `filtre-sollicitations` propose de déléguer, le carnet
  donne le nom exact et la fonction à jour.
- **Repérer les silences** : un correspondant habituellement fréquent, une banque, un
  fournisseur, un client, dont le dernier échange remonte à trois mois est un signal, un
  dossier s'est arrêté, ou il est traité ailleurs.
- **Repérer les insistances** : la même personne sur cinq sujets différents en un mois est
  une information utile pour la direction.

Ces deux derniers points sont la vraie valeur du carnet, et personne ne les cherche
spontanément. Les signaler une fois par mois, dans le radar, en une ligne.

## Tenue

- Une fiche dont la fonction n'a pas été vérifiée depuis **90 jours** est marquée à revérifier.
  Une fonction périmée dans un carnet produit une adresse qui part au mauvais destinataire.
- Les doublons se détectent sur le nom **et** l'organisation : deux homonymes existent, et une
  même personne change d'entreprise. En cas d'ambiguïté, ne jamais fusionner d'office
  signaler et demander.
- Une personne qui quitte ses fonctions n'est pas supprimée : sa fiche est datée et close, et
  la nouvelle fiche renvoie vers l'ancienne. Les gens reviennent, et l'historique sert.

## Garde-fous

- **Aucun envoi.** Le carnet sert à préparer, jamais à écrire de lui-même.
- **Aucune donnée sensible** au-delà du strictement professionnel : pas de vie privée, pas
  d'appréciation personnelle, pas d'information de santé ou de famille. La ligne « à savoir »
  reste factuelle et opposable.
- En cas de doute sur l'origine d'un contact, ne pas l'enregistrer et le dire.
