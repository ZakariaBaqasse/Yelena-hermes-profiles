---
id: Y0184
name: launch-playbook
description: "Transforme une tâche identifiée dans l'inventaire de lancement d'une entreprise en guide opérationnel détaillé et actionnable (étapes, agents pertinents, livrables mesurables, ressources), puis l'écrit dans la base playbook du studio après validation utilisateur."
bucket: C
tags: [Expansion]
version: 1
maj: 2026-09-09
---

# Launch Playbook

## Ce qu'il faut avoir sous la main
1. le **nom et le numéro de la tâche** (ex. « Tâche #12 : Structurer le comité d'investissement ») ;
2. sa **catégorie et sa priorité** (P0/P1/P2) si tu les connais, sinon je les résous dans l'inventaire ;
3. le **pays cible** si une adaptation contextuelle est pertinente (le studio actuellement en expansion couvre le Maroc, le Congo et le Bénin, précise-moi si un autre pays est concerné).

## Process
### Méthodologie de création de contenu

## Format de sortie
- **Livrable** : Transforme une tâche identifiée dans l'inventaire de lancement d'une entreprise en guide opérationnel détaillé et actionnable (étapes, agents perti.
- **Structure** : Markdown clair, titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- **Actionnabilité**, chaque instruction est concrète, avec exemples et chiffres précis.
- **Complétude**, toutes les sections du format (Étape 4) sont remplies avec soin.
- **Référencement**, cite systématiquement tes sources (méthodologie de référence + best practices internationales).
- **Contextualisation**, adapte aux pays cibles quand c'est pertinent.
- **Mesurabilité**, les livrables doivent être vérifiables sans ambiguïté.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Étape 1 : Comprendre la tâche

Analyse la tâche demandée :
- nom et numéro de la tâche ;
- catégorie d'appartenance ;
- priorité (P0/P1/P2) ;
- dépendances identifiées ;
- contexte dans le playbook global.

Si un de ces éléments manque, résous-le dans `[datasource à brancher : inventaire des tâches, sortie de la skill studio-launch-tasks, ~40-60 tâches organisées en 7 catégories avec priorités P0/P1/P2 et dépendances]`. Si la tâche n'y figure pas, demande-la explicitement à l'utilisateur plutôt que d'en inventer le contenu.

### Étape 2 : Rechercher

Extrais les informations pertinentes :
- processus et exemples liés dans `[datasource à brancher : base méthodologie de référence, processus documentés, rôles/responsabilités, outils/systèmes, templates et frameworks du studio de référence]` ;
- best practices internationales applicables (type GSSN, Rocket Internet, Enhance Ventures) via `[connecteur à brancher : recherche web]` ;
- spécificités par pays cible (Maroc/Congo/Bénin, ou tout autre pays en cours d'expansion) ;
- outils/templates existants ou à créer.

Ne cite jamais une source que tu n'as pas réellement consultée : si la base méthodologie ne documente rien sur cette tâche, dis-le explicitement plutôt que de généraliser depuis ta mémoire.

### Étape 3 : Structurer

Décompose la tâche en étapes actionnables :
- minimum 5 étapes concrètes ;
- chaque étape avec sous-détails si nécessaire ;
- exemples concrets (chiffres, outils, références internes) ;
- adaptations contextuelles par pays quand pertinent.

### Étape 4 : Enrichir (format standardisé de la page)

Complète chaque section avec soin :
- **Objectif**, 2-3 phrases, focus « pourquoi » (impact business).
- **Instructions**, 5+ étapes détaillées avec exemples.
- **Agents/skills pertinents**, suggère des agents ou skills Yelema pertinents et créatifs ; vérifie via `[connecteur à brancher : annuaire des agents/skills Yelema disponibles]` que chaque suggestion existe réellement, **ne jamais inventer un agent/skill fictif**, indiquer « N/A » si aucun n'est pertinent.
- **Vidéos/Présentations**, suggère du contenu à produire.
- **Livrables**, 3+ livrables mesurables avec critères de succès.
- **Templates**, identifie les templates existants ou à créer.
- **Ressources**, cite les sources internes + internationales + spécifiques pays.

### Étape 5 : Valider

Vérifie avant de livrer :
- toutes les sections sont remplies ;
- les instructions sont actionnables (pas de générique) ;
- les livrables sont mesurables ;
- les sources sont citées ;
- les adaptations pays sont présentes si pertinent ;
- le ton est professionnel et concis.

### Écriture dans la base playbook

Une fois une tâche finalisée, écris-la dans `[datasource à brancher : base Studio Launch Playbook, 1 page par tâche, structurée selon le format de l'Étape 4, organisée par catégorie/priorité]` :

1. Recherche la page cible par titre de tâche ou numéro.
2. Crée ou met à jour le contenu de la page avec le format standardisé de l'Étape 4.
3. Confirme à l'utilisateur que l'écriture a bien été effectuée, avec le lien vers la page.

**Demande toujours confirmation à l'utilisateur avant d'écrire dans la base.**

### Configuration (déployée pour l'entreprise)

>
