---
id: Y0466
name: document-vivant-et-lien-stable
description: "Fait vivre un document déjà partagé sans jamais casser son lien : modifie en place le fichier existant plutôt que d'en créer un nouveau, resynchronise le PDF avec la version modifiable, tient le journal court des révisions à l'intérieur du document, tranche laquelle des deux versions fait foi quand un document modifiable coexiste avec ce qui l'a produit, et retrouve le lien dans la mémoire de l'entreprise quand on le redemande, sans jamais inventer une date ou un contenu de révision non fourni."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Un lien déjà envoyé ne change plus

## Ce qu'il faut avoir sous la main
- **Le document concerné et son lien actuel** (ou son emplacement dans l'outil de partage utilisé).
- **Ce qui doit changer**, aussi précisément que possible.
- **À qui ce lien a déjà été envoyé**, et par quel canal si tu le sais (WhatsApp, e-mail, imprimé, autre).
- **S'il existe un PDF associé** à ce document, et où il est rangé.
- **Si ce document a été produit par une chaîne de fabrication** (un modèle, un gabarit, un autre outil) avant d'être repris et modifié directement, par toi ou par le client.
- **Si un envoi officiel figé** (dossier administratif, appel d'offres) est nécessaire à côté, en plus de la mise à jour.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si tu me donnes déjà le document et ce qui doit changer, je modifie en place, je resynchronise le PDF s'il existe, et je te dis ce qu'il manque pour compléter la fiche mémoire plutôt que de m'arrêter pour le demander en amont.

## Process
### Étape 1 : Retrouver le document vivant, pas en créer un nouveau
Ce qu'on cherche : le fichier précis qui porte déjà le lien en circulation, celui que les destinataires ont dans leur historique de conversation ou dans leur boîte mail. Avant toute modification, on identifie ce fichier exact et son lien exact, plutôt que de partir d'un brouillon récupéré ailleurs ou d'un export du modèle qui l'a produit.

Ce qui trahit un problème : on te donne un contenu à corriger sans le lien, ou deux liens circulent pour « le même » document, ou personne ne sait dire lequel des deux fichiers a réellement été envoyé au client. Dans ce cas, on s'arrête et on fait retrouver le lien exact avant de toucher à quoi que ce soit : modifier le mauvais fichier ne corrige rien, ça ajoute une troisième version au problème.

Le piège du débutant, à nommer explicitement ici : il régénère le document depuis le modèle ou l'outil qui l'a produit, obtient un fichier propre et à jour, et croit avoir réglé le problème. Le nouveau fichier porte un nouveau lien. L'ancien reste ouvert dans tous les téléphones où il a été partagé, personne n'est prévenu qu'il ne faut plus s'y fier, et la correction n'a atteint personne.

### Étape 2 : Trancher qui fait foi, avant de toucher à quoi que ce soit
Ce qu'on cherche : ce document a-t-il été produit par une chaîne de fabrication (un gabarit, un autre outil, une autre skill) puis repris et modifié directement par quelqu'un côté client ou en interne, ou la chaîne de fabrication reste-t-elle la source de référence ? Dès qu'un document modifié directement diverge visiblement du gabarit qui l'a produit (ajouts, corrections, formulations propres à celui qui l'a repris), c'est ce document modifié qui fait foi à partir de cet instant. La chaîne de fabrication devient un historique, pas une source à remettre à jour en écrasant ce travail.

Ce qui trahit un problème : personne n'a annoncé la bascule au moment où elle s'est produite. On régénère depuis la chaîne de fabrication en croyant « rafraîchir » le document, et ça efface silencieusement des heures de travail écrites à la main dedans. Le signal à chercher est toujours le même : un document qui a visiblement été retravaillé après sa production initiale doit déclencher la question avant toute régénération, jamais après.

Ce qu'on fait une fois la bascule identifiée : on l'écrit explicitement dans la fiche du document et dans son journal de révision, une ligne du type : à partir de cette date, ce document fait foi, la chaîne de fabrication n'est plus la source.

### Étape 3 : Modifier en place, jamais dupliquer
Ce qu'on fait : on ouvre le fichier existant à son emplacement actuel, lien inchangé, et on modifie son contenu directement. Pas de copie « pour essayer », pas d'export « propre » qui remplace tout, pas de déplacement vers un autre dossier qui changerait le lien de partage.

Le seul cas où une copie est légitime : tester une mise en forme risquée avant de l'appliquer au document vivant. Dans ce cas, le titre de la copie dit explicitement qu'elle est une copie de travail (par exemple « brouillon, à supprimer »), et elle est supprimée dès que le test est tranché. Elle ne traîne jamais à côté de l'original.

Ce qui trahit un problème : un dossier partagé qui contient deux ou trois fichiers au nom presque identique, sans qu'on sache lequel est le bon. C'est le signe d'une copie de travail oubliée. On assainit avant de continuer : un seul fichier vivant par document, et on signale explicitement si on en supprime d'autres.

### Étape 4 : Écrire le journal de révision, en une ligne
Ce qu'on fait : à la fin du document, ou dans un encart dédié en tête ou en pied de page selon le format, on ajoute une ligne à chaque modification : la date du jour, et ce qui a changé, en une phrase courte et factuelle. Pas un historique de versions avec comparatif détaillé, une ligne lisible par quelqu'un qui rouvre le document sans contexte.

Ce que ça résout : quelqu'un qui a reçu le lien il y a trois semaines et le rouvre aujourd'hui pour vérifier un point doit pouvoir voir en quelques secondes si le document a changé depuis, et quoi. Sans ce journal, il n'a aucun moyen de le savoir, et il continue de citer une information périmée en toute confiance, parfois devant un tiers.

Ce qui trahit un problème : un document modifié plusieurs fois sans qu'aucune ligne n'ait été ajoutée. Le journal se construit au fil des modifications, pas reconstitué de mémoire après coup : si les dates exactes de modifications précédentes ne sont pas connues, elles sont marquées `⟦à renseigner⟧` plutôt qu'inventées.

### Étape 5 : Resynchroniser le PDF, avec sa date d'export
Ce qu'on fait : si un PDF a été exporté depuis ce document et circule (joint à un e-mail, envoyé par WhatsApp, imprimé), on le régénère depuis la version modifiable à jour et on le range au même endroit, sous le même lien de partage si l'outil le permet, avec sa date d'export visible dans le nom du fichier ou en première page.

Ce qui trahit un problème : le document modifiable a changé plusieurs fois depuis le dernier export du PDF, et personne n'a remarqué que les deux racontent désormais des choses différentes. C'est fréquent quand le PDF a été produit une fois « pour l'envoi » puis oublié, pendant que le document modifiable continue de vivre. Le réflexe à avoir : beaucoup de destinataires ouvrent uniquement le PDF, sur un téléphone d'entrée de gamme, sans jamais aller dans l'outil d'édition. Toute modification qui a une incidence sur cette lecture appelle une resynchronisation, pas seulement une mise à jour du fichier modifiable.

Distinction à garder claire : le PDF resynchronisé remplace le PDF précédent au même usage courant. L'export daté pour un envoi officiel (étape 7) est un objet différent, volontairement figé, qui ne remplace rien.

### Étape 6 : Tenir la fiche du document dans la mémoire de l'entreprise
Ce qu'on fait : on crée ou on met à jour une fiche courte, rangée là où l'équipe range ses documents de référence, avec l'intitulé du document, son lien, ce qu'il contient en une phrase, la liste ou l'estimation de qui l'a reçu et par quel canal, et laquelle des versions (document modifiable ou export figé) fait foi.

Pourquoi ce n'est pas cosmétique : sans cette fiche, un lien envoyé il y a plusieurs semaines se retrouve à la fouille, cherché dans un fil qui a défilé ou une boîte mail encombrée, souvent au moment précis où on en a besoin en urgence, devant un client ou un partenaire. La fiche est ce qui permet de redonner le lien en quelques secondes quand on le redemande.

Ce qui trahit un problème : la fiche existe mais son lien renvoie vers un fichier qui n'existe plus ou vers une version périmée. On vérifie systématiquement, à chaque modification en place, que le lien de la fiche pointe toujours vers le bon fichier : rien n'a dû changer puisqu'on a modifié en place et non recréé, mais on vérifie plutôt que de le supposer.

### Étape 7 : L'export daté pour un envoi officiel, quand il est demandé
Ce qu'on fait : quand une version figée et non modifiable est nécessaire (dossier administratif, appel d'offres, envoi à une institution comme la DGI ou la CNPS, archive contractuelle), on produit un export portant sa date en clair, et on le range à côté du document vivant, jamais à sa place. Le document vivant continue d'évoluer normalement après.

Ce qui trahit un problème : quelqu'un traite cet export figé comme s'il devait rester identique au document vivant, et s'étonne ensuite que les deux divergent. On le dit explicitement au moment de produire l'export : cette version est figée à cette date, toute évolution ultérieure du document vivant ne s'y reflète pas, un nouvel export sera nécessaire si une version à jour est redemandée.

## Format de sortie
- **Livrable** : le document mis à jour en place, lien inchangé, avec son journal de révision en fin de document (date, ce qui a changé, en une ligne) ; le PDF resynchronisé portant sa date d'export ; la fiche du document dans la mémoire de l'entreprise (intitulé, lien, contenu, destinataires connus, version qui fait foi) ; et, si demandé, l'export daté pour envoi officiel, produit à côté du document vivant.
- **Structure** : la modification se fait directement dans le fichier existant, jamais dans un nouveau document produit à part. Le journal de révision reste une ligne par modification, factuelle et datée, pas un compte-rendu détaillé.
- **Longueur** : proportionnée à la modification demandée, sans remplissage.
- **Règle 0 invention** : aucune date ou contenu de révision antérieure n'est reconstitué de mémoire. Ce qui n'est pas connu reste `⟦à renseigner⟧`.

## Règles
1. **Un document déjà partagé se modifie en place, jamais en le recréant.** Le lien ne change pas.
2. **Une correction n'est réputée faite que si elle atteint le fichier que les destinataires ont déjà ouvert ou rouvriront**, pas un nouveau fichier qu'on croit leur avoir substitué en l'annonçant seulement par message.
3. **Le PDF suit le document modifiable à chaque changement de fond.** Un PDF non resynchronisé après une modification qui compte pour la lecture est un PDF fautif, pas un détail.
4. **Une copie de travail se nomme comme telle et se supprime dès que son usage est terminé.** Elle ne survit jamais à côté de l'original sans étiquette.
5. **Quand un document a été repris et modifié directement après avoir été produit par une chaîne de fabrication, c'est ce document qui fait foi à partir de cet instant**, et la bascule se dit explicitement au moment où elle se produit, pas après avoir écrasé le travail fait dessus.
6. **Un lien se range dans la fiche mémoire au moment où le document est créé ou modifié**, avec intitulé, contenu et destinataires connus. Il ne se reconstitue jamais après coup à la fouille.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; renvoyer un lien à un tiers, publier un export ou supprimer un fichier définitivement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un document traité dans une conversation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Le lien est introuvable ou perdu**, tu le signales, tu proposes de reconstituer la fiche à partir de ce qui est connu, et tu marques `⟦à renseigner⟧` ce qui manque plutôt que de deviner un emplacement.
- **Le document a déjà circulé mais aucune fiche n'a jamais été créée**, tu la crées maintenant, avec ce qui est connu, en marquant explicitement ce qui reste incertain.
- **Plusieurs copies circulent déjà sans qu'on sache laquelle est la référence**, tu le signales et tu demandes l'arbitrage plutôt que de trancher seul lequel fait foi.
- **La bascule « qui fait foi » n'a jamais été documentée pour un document déjà modifié directement**, tu le signales avant de régénérer quoi que ce soit depuis la chaîne de fabrication, pour ne pas écraser un travail déjà fait.
- **Un export officiel figé est confondu avec le document vivant**, tu rappelles la distinction et tu ne remplaces jamais l'un par l'autre sans validation explicite.
- **On te demande simplement « renvoie-moi le lien »**, tu vas chercher la fiche ; si elle n'existe pas, tu le dis et tu la crées à cette occasion plutôt que de fouiller au hasard.
- **L'outil de partage ne permet pas de conserver le même lien après modification**, tu le signales comme une limite technique réelle, tu proposes la meilleure alternative disponible (réutiliser l'ancien lien, prévenir explicitement les destinataires du changement), sans jamais présenter la situation comme réglée si elle ne l'est pas.
- **Action sortante demandée** (renvoyer un lien à un tiers, publier un export, supprimer un fichier partagé), tu prépares ce qui est nécessaire et tu t'arrêtes pour validation humaine.
