---
id: Y0464
name: annotations-du-client
description: "Avant de reconstruire, régénérer ou mettre à jour un fichier que le client a ouvert : relève tout ce qu'il y a marqué à la main (couleur, note, ligne ajoutée ou retirée, ordre changé, texte réécrit), lit ce que chaque marque veut dire, l'applique, puis repose les marques sur les bonnes lignes, sans jamais écraser une annotation qu'elle n'a pas d'abord comprise."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Ce que le client a écrit à la main dans le fichier ne se perd jamais

## Ce qu'il faut avoir sous la main
- **Le fichier** à mettre à jour ou reconstruire (lien ou pièce jointe), dans son état actuel, tel qu'il est ouvert en ligne à cet instant.
- **La source ou la règle** qui doit produire la nouvelle version (base, export, autre fichier, calcul à refaire).
- **Ce que tu sais des marques présentes**, si tu le sais : ce que veut dire une couleur, une note, une ligne surlignée dans ce fichier précis. Si tu ne le sais pas, dis-le, je te pose une seule question groupée.
- **Le type de mise à jour** demandé : ajout de lignes, recalcul, tri, changement de source.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le fichier est fourni sans autre précision, tu **produis directement le relevé des annotations** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Relever les annotations avant tout, systématiquement

Avant toute écriture, tu parcours le fichier dans son état actuel et tu listes chaque marque qui n'a pas été posée par le système : couleur de fond sur une ou plusieurs lignes, note dans une cellule, commentaire, ligne ajoutée à la fin qui n'existe pas dans la source, ligne absente qui existe dans la source, ordre différent de celui que la source produirait, colonne masquée, texte dans une cellule qui diffère de ce que la formule ou l'import aurait produit.

Ce relevé se fait **même quand rien ne laisse penser que le fichier a été touché**. Le client dira « mets-le à jour », jamais « attention, j'ai annoté » : la demande ne signale jamais la présence de marques, c'est à toi de les chercher.

### Étape 2 : Lire chaque marque, pas la classer

Une couleur dans un fichier de travail n'est pas une décoration, c'est une instruction. Trois lignes en vert et quatre en rouge veulent dire quelque chose de précis, et c'est ce quelque chose qui est le vrai contenu du message. Pour chaque marque tu formules une lecture : ce qu'elle signifie probablement, en t'appuyant sur ce que la mémoire de l'entreprise dit déjà de cette convention.

Si la convention est connue (déjà donnée dans une conversation précédente, déjà écrite en mémoire), tu l'appliques directement, sans redemander. Si elle est inconnue pour ce fichier ou ce code couleur précis, tu la mets de côté pour l'étape 4, tu ne l'inventes pas.

### Étape 3 : Traiter un retrait comme un critère, jamais comme une liste

Quand des lignes ont été rayées ou supprimées à la main, le réflexe qui perd est de les traiter une par une et de s'arrêter là. Un client qui retire quatre lignes a presque toujours appliqué un critère commun, pas choisi quatre cas isolés au hasard. Ta tâche : identifier ce que ces quatre lignes ont en commun, formuler ce critère en une phrase, le montrer au client pour qu'il puisse le contester ou le confirmer, puis chercher dans le reste du fichier les lignes qui tombent sous le même critère et ne les traiter qu'après confirmation.

Supprimer les quatre lignes rayées et t'arrêter là laisse en place tout ce qui devrait tomber avec elles selon la même logique. Le critère non écrit, c'est le retrait mal compris.

### Étape 4 : Regrouper les cas inconnus en une seule question

Pour chaque marque dont la lecture reste incertaine, tu ne poses pas une question par marque : tu regroupes tout ce qui est inconnu dans une seule question, formulée précisément (« la couleur orange sur les lignes X, Y, Z veut dire quoi dans ce fichier ? »). Dès que la réponse arrive, tu l'écris dans la mémoire de l'entreprise pour ce type de fichier, afin de ne plus avoir à la redemander la prochaine fois.

Tant qu'une marque relevée n'a reçu ni lecture ni action, la reconstruction du fichier reste bloquée sur cette marque, explicitement. Tu ne reconstruis pas « en attendant » en espérant que ça ne posera pas problème.

### Étape 5 : Appliquer, reconstruire, puis reposer les marques sur l'identifiant

Une fois toutes les marques lues ou tranchées, tu appliques la mise à jour demandée (recalcul, ajout, tri, changement de source) sur le contenu. Puis tu reposes chaque marque, non pas sur le rang de la ligne, mais sur l'**identifiant** de la ligne concernée (référence, nom, clé unique). Un tri, un ajout ou une suppression déplace les lignes : une marque reposée par numéro de ligne finit sur la mauvaise ligne, une couleur mal replacée devient une fausse instruction pour la suite.

### Étape 6 : Vérifier que l'état de départ était le bon

L'état qui fait foi est celui du fichier en ligne au moment où tu commences, pas une copie locale, pas la dernière version que tu as produite toi-même précédemment. Entre les deux, le client a pu rouvrir le fichier et ajouter une marque. Si un doute existe sur la fraîcheur du fichier fourni, tu le signales avant de conclure que le relevé est complet.

## Format de sortie
- **Le relevé des annotations** : pour chaque marque, où elle se trouve (feuille, ligne identifiée par sa clé, colonne), ce qu'elle est (couleur et son code, note, ajout, retrait, réordonnancement, texte réécrit), la lecture retenue, et l'action qui en découle.
- **Le fichier mis à jour**, avec les marques reposées sur les identifiants corrects.
- **La liste des marques non comprises**, chacune avec la question précise à poser, et la mention explicite que le fichier n'est **pas reconstruit** tant qu'elles restent ouvertes.
- **Quand un retrait révèle un critère** : le critère écrit en une phrase, et les autres lignes qui y tombent, proposées séparément, jamais appliquées sans confirmation.
- **Structure** : Markdown clair, answer-first (le relevé et l'état de blocage éventuel d'abord, le détail ensuite) ; un tableau par marque quand il y en a plusieurs.
- **Longueur** : proportionnée au nombre de marques trouvées. Un fichier sans annotation donne un relevé court qui dit « rien trouvé », pas un relevé vide sans explication.

## Règles
1. **Le relevé précède toujours l'écriture.** Aucune reconstruction, mise à jour ou régénération ne démarre avant que le relevé des annotations soit produit, y compris quand la demande ne mentionne aucune annotation.
2. **Une couleur, une note ou une ligne ajoutée est une instruction, pas une décoration.** Tu la lis comme telle et tu écris cette lecture, tu ne la contournes jamais en silence.
3. **Un retrait de plusieurs lignes est un critère à formuler, pas une liste à exécuter.** Tu cherches le point commun, tu le montres, tu ne l'appliques au reste du fichier qu'après confirmation.
4. **Une marque inconnue se demande une fois, groupée, puis s'écrit en mémoire.** Tu ne redemandes jamais une convention déjà donnée dans une conversation ou une mémoire précédente.
5. **Une marque se repose sur l'identifiant de la ligne, jamais sur son rang.** Après un tri, un ajout ou un retrait, le rang a bougé ; la clé, elle, n'a pas bougé.
6. **L'état qui fait foi est celui du fichier en ligne à l'instant présent.** Une copie locale ou une version précédemment produite par toi peut être obsolète : en cas de doute, tu le signales.
7. **Tant qu'une marque reste sans lecture ni action, le fichier n'est pas reconstruit.** Une reconstruction partielle qui ignore une marque non résolue n'est pas un livrable acceptable, c'est un livrable qui doit être signalé comme bloqué.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; écraser le fichier, l'envoyer à un tiers ou publier une version est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un fichier ou d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fichier sans aucune marque visible**, tu produis quand même le relevé, tu écris explicitement qu'aucune annotation n'a été trouvée, et tu procèdes à la reconstruction normalement. L'absence de marque ne dispense pas du relevé.
- **Convention de couleur ou de note inconnue et jamais rencontrée**, tu poses une seule question groupée pour tous les cas inconnus du fichier, tu n'avances pas sur ces lignes tant que la réponse n'est pas là, et tu l'écris en mémoire dès qu'elle arrive.
- **Retrait de plusieurs lignes sans critère évident**, tu proposes la lecture la plus probable, tu la marques `[hypothèse : …]`, et tu demandes confirmation avant d'appliquer le critère au reste du fichier.
- **Doute sur la fraîcheur du fichier fourni** (copie locale, ancienne version), tu le signales avant de produire le relevé et tu demandes le fichier tel qu'il est actuellement en ligne.
- **Fichier trop volumineux pour un relevé ligne par ligne**, tu relèves par bloc ou par feuille, tu signales la méthode utilisée, et tu marques les zones non couvertes.
- **Marque ambiguë entre deux lectures possibles** (une couleur qui pourrait vouloir dire deux choses selon la convention connue), tu exposes les deux lectures et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande de reconstruction immédiate, sans attendre le relevé**, tu rappelles en une phrase pourquoi le relevé passe d'abord, tu le produis, et tu ne reconstruis qu'une fois les marques traitées ou explicitement écartées par le client.
- **Action sortante demandée** (écraser le fichier partagé, l'envoyer, le publier), tu prépares le fichier mis à jour et tu t'arrêtes pour validation humaine avant toute diffusion.
- **Sources contradictoires** (le fichier annoté et la source de régénération ne s'accordent pas sur une même ligne), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
