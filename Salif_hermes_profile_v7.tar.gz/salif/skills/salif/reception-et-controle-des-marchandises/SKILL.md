---
id: Y0455
name: reception-et-controle-des-marchandises
description: "Organise l'arrivée des marchandises au dépôt ou au magasin : préparation de la réception à partir de la commande, contrôle contradictoire de la quantité, de la référence, de l'état et des dates, formulation des réserves, enregistrement de l'entrée en stock le jour même, et déclenchement de la contestation fournisseur en cas d'écart. Produit la fiche de réception, le procès-verbal de réserves et le journal des écarts fournisseur, sans jamais fixer à la place de l'entreprise un délai légal de réserve, un seuil de tolérance ou un montant de réclamation."
bucket: B
tags: [Opérations, Terrain, Afrique, Nouveau]
version: 1
maj: 2026-09-09
---

# La réception, le seul moment où une erreur fournisseur se conteste encore

## Ce qu'il faut avoir sous la main
- **La commande de référence** : ce qui a été commandé, en quantité et en référence, au fournisseur concerné.
- **Le contexte de la livraison** : transporteur (propre flotte, prestataire, informel), date et heure prévues, mode de règlement (comptant à la livraison, mobile money, à crédit).
- **Qui reçoit** : le nom de la personne qui va contrôler au quai, et si c'est la même personne qui a passé la commande.
- **Ce qui s'est déjà passé** si la livraison a déjà eu lieu : bon signé ou non, réserves déjà notées, écarts déjà repérés, photos prises.
- **Le contrat ou les conditions générales du fournisseur ou du transporteur**, si tu les as : c'est là que se trouve le délai de formulation des réserves.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Préparer la réception avant que le camion arrive

Le contrôle qui se fait dans l'urgence, devant un transporteur qui veut repartir, est un contrôle qui rate des choses. Avant l'arrivée annoncée : sors le bon de commande, vérifie les quantités et les références attendues, prévois l'espace de déchargement, et désigne la personne qui contrôlera.

Le piège classique à ce stade : personne n'a le bon de commande sous la main au moment du contrôle, et on compare la livraison au bon de livraison du fournisseur, pas à ce qui a réellement été commandé. Le bon de livraison est écrit par celui qui livre : ce n'est pas la référence, c'est ce qu'on va vérifier contre la référence.

### Étape 2 : Le contrôle physique, contradictoire : quantité, référence, état

Trois choses se contrôlent ligne par ligne, jamais globalement : la quantité reçue face à la quantité attendue, la référence exacte du produit (pas seulement le nombre de cartons), et l'état visible (emballage, casse, mouillé, ouvert). Une quantité juste sur une référence fausse est un écart, pas une réception conforme : le compte qui tombe juste endort la vigilance, c'est là qu'il faut la garder.

Le contrôle est dit **contradictoire** quand il se fait en présence du livreur ou de son représentant, pour que le constat ne puisse pas être contesté après coup. Quand l'effectif le permet, la personne qui contrôle n'est pas celle qui a passé la commande : c'est le principe de séparation des tâches, et c'est le rempart le plus simple contre l'erreur comme contre la fraude (survaloriser une quantité reçue pour couvrir un vol, par exemple). Quand l'effectif ne le permet pas, la compétence ne l'exige pas : elle le signale comme un risque assumé, pas comme une faute cachée.

### Étape 3 : Les dates et les lots : ce qui entre sans contrôle sort en réclamation

Pour tout produit à durée de vie limitée, le contrôle de la date et du numéro de lot est aussi important que le contrôle de la quantité. Un produit proche de la fin de vie qui entre au même rang qu'un produit frais va se vendre en dernier par principe de rotation, et va donc expirer sur l'étagère. Un lot faisant l'objet d'un rappel connu ne doit pas entrer du tout.

Le réflexe à corriger : contrôler la date sur un échantillon de cartons plutôt que sur toute la ligne, en se fiant à l'homogénéité supposée du lot livré. Un fournisseur qui mélange des lots de dates différentes dans une même livraison n'est pas une hypothèse d'école, c'est une pratique observée.

### Étape 4 : La signature et les réserves : l'acte qui ferme ou ouvre la contestation

Le bon de transport ou de livraison n'est pas un papier de quai, c'est un document qui engage. Une signature sans réserve, sur une livraison où il manquait des cartons ou où un produit était endommagé, vaut acceptation de la livraison telle qu'elle est : contester après devient beaucoup plus difficile, quelle que soit la réalité de ce qu'il y avait dans les cartons.

Dès qu'un écart est constaté à l'étape 2 ou 3, la réserve se formule avant la signature, par écrit, sur le bon lui-même si possible, avec la nature précise de l'écart (pas « colis abîmé » mais « carton n°4 écrasé sur un angle, produit X visiblement fendu »). Les photos prises au moment du contrôle (le téléphone du contrôleur suffit, y compris un modèle d'entrée de gamme) valent preuve et se transmettent immédiatement, par WhatsApp si c'est le canal de travail de l'équipe, au responsable et au fournisseur.

Le **délai dans lequel la réserve doit être formulée pour rester valable** dépend du contrat conclu avec le fournisseur ou le transporteur, et du droit du transport applicable. L'OHADA a en charge l'harmonisation du droit des affaires dans ses États membres, dont le droit du contrat de transport de marchandises par route fait partie ; le délai précis, lui, se lit dans le contrat ou le texte applicable et n'est jamais produit par cette compétence : il reste `⟦à renseigner⟧` jusqu'à ce que le contrat ou un conseil juridique le confirme.

Le piège à ce stade, sous pression de trafic ou d'un transporteur pressé (embouteillages d'Abidjan, tournée du chauffeur qui continue derrière), c'est de signer « pour aller plus vite, on réglera après ». Il n'y a pas d'« après » qui vaille juridiquement autant qu'une réserve écrite au moment de la livraison.

### Étape 5 : L'entrée en stock, le jour même

Tant que la réception n'est pas enregistrée dans le système de gestion des stocks, le stock informatique annonce une quantité qui n'existe pas encore physiquement de façon fiable : les commandes clients se prennent à l'aveugle, et les réapprovisionnements se déclenchent sur une donnée fausse. L'enregistrement se fait le jour de la réception, pas « dès que possible » : chaque jour de retard est un jour où le système ment.

Quand la connexion est coûteuse ou instable et empêche une saisie immédiate dans un système centralisé, la fiche de réception papier ou sur téléphone fait foi en attendant, et la saisie différée se signale explicitement comme telle, avec la date réelle de réception distincte de la date de saisie.

### Étape 6 : Le journal des écarts et la décision de réclamer

Chaque écart constaté (quantité manquante, référence erronée, dommage, date dépassée) s'ajoute au journal des écarts fournisseur, même s'il paraît trop petit pour valoir une réclamation isolée. Un écart de deux pour cent qui se répète à chaque livraison n'est pas un accident, c'est un comportement : seul le cumul dans le temps le rend visible, une ligne isolée ne le montre jamais.

Pour chaque écart cumulé, la question à trancher est : qu'est-ce qui a été réclamé, à qui, et qu'est-ce qui a été obtenu (avoir, remplacement, rien). Le seuil à partir duquel un écart déclenche automatiquement une réclamation formelle est une décision de l'entreprise, pas un chiffre que cette compétence produit : il reste `⟦à renseigner⟧`.

## Format de sortie
- **Livrable 1, la fiche de réception** : commande de référence, fournisseur, transporteur, date et heure de réception, contrôleur nommé, et pour chaque ligne : référence, quantité attendue, quantité reçue, état, lot, date. Statut global : conforme, conforme avec réserve, non conforme.
- **Livrable 2, le procès-verbal de réserves** (produit uniquement s'il y a écart) : nature précise de l'écart ou du dommage, ligne concernée, photos jointes, formulation exacte de la réserve inscrite, à qui le PV est remis (chauffeur, transporteur, fournisseur) et à quelle date et heure. Mention explicite du délai contractuel de réserve applicable, marqué `⟦à renseigner⟧` s'il n'a pas été fourni.
- **Livrable 3, le journal des écarts fournisseur** : tableau cumulatif par fournisseur et par nature d'écart, avec ce qui a été réclamé et ce qui a été obtenu, mis à jour à chaque réception avec écart.
- **Structure** : Markdown, answer-first (le statut de la réception d'abord : conforme, avec réserve, ou non conforme), tableaux pour les lignes de contrôle et le journal des écarts.
- **Longueur** : proportionnée à la réception traitée. Une fiche de réception simple tient sur une page ; le journal des écarts s'allonge avec l'historique.
- **Règle 0 invention** : aucun délai légal, aucun seuil de tolérance, aucun montant de réclamation n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon.

## Règles
1. **La signature vaut acceptation.** Toute signature d'un bon de transport ou de livraison sans réserve écrite ferme la contestation sur ce qui n'a pas été noté. Tu le rappelles avant chaque réception à risque, pas après.
2. **Quantité, référence et état se contrôlent séparément.** Un compte juste sur une référence fausse, ou une quantité juste sur un produit endommagé, est un écart : jamais une conformité.
3. **Les dates et les lots se contrôlent ligne par ligne**, pas sur un échantillon, pour tout produit à durée de vie limitée ou sous rappel connu.
4. **Celui qui commande ne contrôle pas la réception**, quand l'effectif le permet. Quand il ne le permet pas, tu le signales comme un risque assumé, tu ne fais pas comme si le contrôle était équivalent.
5. **L'entrée en stock se fait le jour même.** Un stock informatique qui ne reflète pas la réception réelle fausse toutes les décisions qui s'appuient sur lui, dès le lendemain.
6. **0 chiffre inventé.** Aucun délai légal de réserve, aucun seuil de tolérance, aucun montant de réclamation n'est produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon, y compris pour un délai qui « se fait généralement » dans le secteur.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter un fournisseur, refuser formellement une livraison ou engager une réclamation est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une réception ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fournisseur ou transporteur informel, sans bon de livraison formel** : tu produis quand même une fiche de réception interne datée et signée par le contrôleur ; elle vaut preuve pour l'entreprise même sans contradiction du transporteur.
- **Le transporteur refuse de laisser inscrire une réserve sur son bon** : tu le notes explicitement dans le PV, tu formalises la réserve sur un document interne daté avec photos, et tu signales que la valeur probante en est réduite.
- **Livraison partielle**, le reste annoncé pour plus tard : tu enregistres en stock uniquement ce qui est physiquement reçu et contrôlé, jamais la quantité commandée totale.
- **Panne système ou connexion indisponible au moment de la réception** : la fiche papier ou téléphone fait foi, la saisie différée est explicitement datée avec l'écart entre date réelle et date de saisie signalé.
- **Désaccord entre le chauffeur et le contrôleur** sur la nature de l'écart : tu exposes les deux versions dans le PV sans trancher à la place des parties, et tu recommandes l'arbitrage entre l'entreprise et le fournisseur.
- **Produit sous température dirigée (chaîne du froid)** : le contrôle d'état inclut la température si un relevé est disponible ; son absence se signale comme un trou de contrôle, pas comme une conformité par défaut.
- **Effectif insuffisant pour séparer commande et réception** : tu produis la fiche quand même, tu signales le risque de contrôle faible en clair, tu ne masques pas la limite.
- **Écart déjà connu et jamais réclamé chez ce fournisseur** : tu le fais remonter du journal des écarts avant de conclure sur le cas du jour, pour que le cumul soit visible au moment de la décision.
- **Action sortante demandée** (contacter le fournisseur, refuser la livraison, engager une réclamation formelle) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (contrat fournisseur et conditions générales du transporteur en désaccord sur le délai de réserve) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
