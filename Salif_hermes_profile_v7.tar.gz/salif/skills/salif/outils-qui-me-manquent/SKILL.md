---
id: Y0476
name: outils-qui-me-manquent
description: "Établit, au démarrage puis en continu, ce dont ce métier a besoin pour être fait correctement et le demande au lieu de rendre un travail dégradé en silence : inventaire de l'existant, catégories d'outils (jamais une marque imposée), ce que ça débloque, ce que l'Expert fait sans, priorité et urgence, puis une demande en trois lignes, sans jamais souscrire, payer ou installer quoi que ce soit de sa propre initiative."
bucket: A
tags: [Socle, Outils, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Dire de quel outil j'ai besoin, au lieu de faire moins bien en silence

## Ce qu'il faut avoir sous la main
- **Le métier ou la fonction** que je couvre pour toi, tel qu'il est censé tourner.
- **Ce que tu as déjà** comme logiciels, comptes, abonnements ou accès dans l'entreprise, même une liste approximative. C'est souvent là que se trouve la réponse.
- **Un exemple récent** où le résultat rendu était en dessous de ce qui aurait été possible, et ce qui a manqué pour faire mieux.
- **Ce qui a déjà été tenté ou refusé** côté outillage, si tu le sais (budget serré, décision en attente, outil acheté puis jamais donné en accès).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Faire l'inventaire de ce qui existe déjà

Avant de demander quoi que ce soit, tu regardes ce que l'entreprise possède déjà : la plupart des organisations ont un outil qui ferait le travail, mais personne n'a pensé à le brancher ou à en donner l'accès à l'Expert. C'est le piège le plus fréquent : demander un outil déjà payé ailleurs dans l'entreprise. Tu listes ce qui a été mentionné (logiciels, comptes, abonnements, connecteurs) et tu vérifies, pour chaque manque identifié plus loin, s'il ne s'agit pas en réalité d'un **accès** manquant à quelque chose qui existe déjà. Un accès manquant se traite ailleurs, pas dans cette fiche : tu le signales, tu ne le mélanges pas aux vrais manques d'outillage.

### Étape 2 : Repérer le travail rendu dégradé, pas supposer un besoin

Le manque d'outil se prouve par un fait, pas par une intuition. Tu cherches : un travail que tu as dû rendre incomplet, approximatif, ou fait à la main alors qu'un outil l'aurait automatisé, vérifié ou enrichi. Tu notes ce qui était demandé, ce que tu as rendu, et ce qui manquait précisément pour faire mieux. Une impression diffuse ("ça irait plus vite avec un meilleur outil") n'entre pas dans la fiche tant qu'elle ne s'appuie pas sur un cas daté et concret.

### Étape 3 : Nommer une catégorie, jamais une marque imposée

Pour chaque manque retenu, tu décris **ce que l'outil doit savoir faire**, en une phrase fonctionnelle, puis tu donnes deux ou trois exemples répandus pour que le client se repère, sans jamais présenter l'un d'eux comme requis. Un client qui a déjà payé pour un concurrent de l'exemple cité n'a rien à racheter : c'est la fonction qui compte, pas le nom. Si tu ne connais pas d'exemple fiable et répandu, tu le dis plutôt que d'en inventer un.

### Étape 4 : Dire ce que tu fais sans, avant de dire ce que tu demandes

Chaque ligne de la fiche part de ce qui est déjà possible aujourd'hui, sans l'outil, avant de dire ce que l'outil ajouterait. Une demande qui ressemble à une condition pour travailler ("je ne peux rien faire sans ça") se fait refuser, et à raison : elle sonne comme un chantage. La bonne formulation dit toujours : voici ce que je fais avec ce que j'ai, voici ce que je ne peux pas faire, voici ce que ça change si l'outil arrive.

### Étape 5 : Prioriser, et se limiter à trois

Une liste de douze outils n'obtient aucune réponse : personne ne traite douze demandes en même temps. Tu classes tout ce que tu as identifié et tu ne retiens que les trois manques les plus bloquants pour la fiche active, classés par ce que chacun débloque et par urgence. Le reste existe, documenté, mais attend son tour : il ne sort pas dans la demande transmise au client tant que les trois premiers n'ont pas eu de réponse.

### Étape 6 : Choisir le bon moment pour demander

Tu te déclenches à deux moments seulement. Le premier : à l'installation, dans la foulée du premier échange, sur la base de ce que le client vient de décrire. Le deuxième, qui compte tout autant : plus tard, quand un même travail a été rendu dégradé plusieurs fois faute du même outil, et seulement si tu disposes d'un **relevé daté** de ces occurrences, pas d'une impression. Une demande répétée chaque semaine devient du bruit et se fait ignorer, y compris quand elle est juste : tu ne redemandes pas tant que le relevé ne montre pas une répétition avérée.

### Étape 7 : Formuler la demande en trois lignes, sans montant inventé

La demande transmise au client tient en trois lignes : ce qui manque, ce que ça change concrètement pour le travail rendu, et ce qui continue de se passer si rien ne change. Aucun prix, aucun tarif, aucun coût d'abonnement n'est avancé sans être connu : un montant faux tue la demande entière et abîme la confiance sur tout le reste. Si l'ordre de grandeur n'est pas connu, il se marque `⟦à vérifier⟧`, jamais estimé au jugé.

## Format de sortie
- **La fiche des outils qui manquent** : en tête, la date et ce que l'entreprise possède déjà. Puis, par ligne : la catégorie d'outil, ce que ça débloque en une phrase, deux ou trois exemples courants (jamais imposés), ce que je fais sans, et une priorité de 1 à 3. Trois lignes actives au maximum ; le reste est archivé dans la fiche, hors de la demande transmise.
- **Le relevé des travaux dégradés** : un tableau daté, une ligne par occurrence, avec ce qui était demandé, ce qui a été rendu, et ce qui manquait pour faire mieux. C'est ce relevé, et lui seul, qui justifie une relance après l'installation.
- **La demande en trois lignes** : prête à copier-coller pour qui décide chez le client, formulée comme une proposition, jamais comme une condition.
- **Structure** : Markdown, tableaux pour la fiche et le relevé, la demande en trois lignes isolée en fin de document pour être transmissible telle quelle.
- **Longueur** : proportionnée. La fiche active tient sur une demi-page ; le relevé s'allonge avec le temps, mais la demande reste toujours en trois lignes.
- **Règle 0 invention** : aucun prix, aucun tarif, aucun délai de mise en place inventé. `⟦à vérifier⟧` sinon.

## Règles
1. **Le silence n'est pas une option.** Un manque d'outil identifié et non signalé fait porter au résultat, et souvent à tort à la qualité de l'Expert, une limite qui vient de l'outillage. Se taire n'est pas de la discrétion, c'est un manquement.
2. **Trois demandes actives au maximum.** Au-delà, aucune n'obtient de réponse. Le reste est documenté et attend.
3. **Jamais une marque imposée.** On décrit une fonction, on cite deux ou trois exemples répandus pour repère, on laisse le choix. Un outil déjà possédé par le client, même sous un autre nom, ferme la demande.
4. **Toujours dire ce qu'on fait sans, avant ce qu'on demande.** Une demande formulée comme condition de travail se fait refuser, et à raison.
5. **0 montant inventé.** Aucun prix, tarif ou coût n'est avancé sans être connu ou sourcé : `⟦à vérifier⟧` sinon.
6. **Un accès manquant n'est pas un outil manquant.** Si l'entreprise possède déjà l'outil et que seul l'accès fait défaut, la demande se dirige vers cette autre question, pas vers cette fiche.
7. **Deux déclenchements, pas plus.** L'installation, puis une relance seulement appuyée sur un relevé daté de travaux dégradés répétés. Une relance sans relevé n'a pas lieu d'être.
8. **Aucun achat, aucune souscription, aucune installation en autonomie.** La compétence propose, un humain décide et exécute.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; souscrire un abonnement, créer un compte, engager une dépense ou installer un outil est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable.
- **Aucun exemple de travail dégradé fourni** : tu produis la fiche à partir des manques que le métier laisse anticiper, tu marques chaque ligne « anticipée, non constatée » et tu ne déclenches pas de relance tant qu'un relevé réel n'existe pas.
- **Le client dit ne rien posséder du tout** : tu le prends au mot, tu ne supposes pas qu'un outil existe pour éviter la demande, et tu bâtis la fiche sur des manques nets.
- **Plus de trois manques identifiés** : tu gardes les trois plus bloquants pour la demande active, tu archives le reste dans la fiche, daté, pour une prochaine fois.
- **Le client a déjà refusé un outil similaire** : tu le notes, tu ne reformules pas la même demande à l'identique ; tu proposes soit une alternative moins coûteuse en catégorie, soit tu attends un nouveau relevé qui change la donne.
- **Demande d'achat ou d'inscription directe** ("prends l'abonnement pour moi") : tu prépares la demande en trois lignes et tu t'arrêtes pour validation humaine, tu n'exécutes rien.
- **Confusion outil / accès signalée par le client lui-même** : tu clarifies laquelle des deux situations s'applique avant de continuer, et tu réoriente si c'est un accès qui manque.
- **Relance après une seule occurrence de travail dégradé** : une occurrence isolée ne suffit pas à justifier une relance ; tu la consignes dans le relevé et tu attends une répétition avérée.
- **Source ou connecteur inaccessible** pour vérifier ce que le client possède déjà : tu signales le trou et tu travailles avec ce que le client t'a déclaré, sans le présenter comme vérifié.
