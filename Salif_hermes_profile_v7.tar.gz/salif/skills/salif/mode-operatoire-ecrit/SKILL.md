---
id: Y0460
name: mode-operatoire-ecrit
description: "Transforme une pratique réelle de l'entreprise en mode opératoire écrit et applicable : observation du travail tel qu'il se fait, rédaction dans le langage et le format de l'exécutant, cas particuliers fréquents, point d'escalade nommé, test avec une personne extérieure à la rédaction, puis mise en registre avec version et date de revue, sans jamais remplacer la procédure réelle par la procédure idéale."
bucket: B
tags: [Opérations, Organisation, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Écrire une procédure que les gens appliquent, y compris quand personne ne regarde

## Ce qu'il faut avoir sous la main
- **La tâche concernée**, précisément : pas « la production », mais l'opération qu'on peut regarder se faire une fois (ouvrir la caisse, préparer une commande, réceptionner une livraison, démarrer une machine).
- **Qui l'exécute aujourd'hui** et depuis combien de temps, en général.
- **Comment ça se fait réellement** en ce moment, même si ce n'est pas ce qui devrait se faire, même si ça varie selon la personne.
- **Ce qui existe déjà à l'écrit** sur cette tâche, s'il y a quelque chose, même une note WhatsApp ou une affiche périmée.
- **Le format de restitution voulu** : feuille à afficher au poste, fiche imprimée et laminée, document interne, ou les deux.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Observer avant d'écrire

Le premier piège du métier : rédiger la procédure idéale, celle que le responsable imagine, sans être allé voir comment la tâche se fait réellement. Une procédure idéale que personne ne suit devient vite un papier qu'on ignore, et l'écart entre l'écrit et le réel devient la nouvelle norme, silencieusement.

Tu pars donc de l'observation : ce qui se fait aujourd'hui, dans l'ordre où ça se fait, avec les raccourcis que les gens prennent et pourquoi ils les prennent (souvent une bonne raison : un outil manque, une étape est redondante, le matériel prévu n'est pas disponible). Tu notes séparément ce qui est **observé** et ce que le responsable **suppose ou souhaite**. Ce n'est qu'à l'étape suivante que tu corriges l'écart, en connaissance de cause, pas en l'ignorant.

### Étape 2 : Découper en étapes actionnables

Chaque étape du mode opératoire porte **un verbe d'action** et **une seule action** : « ouvrir », « vérifier », « signer », « appeler », pas « s'assurer que tout est en ordre ». Une étape qui contient un « et » caché entre deux gestes différents est deux étapes.

Après chaque groupe d'étapes qui peut mal se passer, place un **point de contrôle** : ce que l'exécutant doit voir, entendre ou compter pour savoir que ça s'est bien passé avant de continuer. Un mode opératoire sans point de contrôle transfère toute la vérification à la fin, quand l'erreur est déjà coûteuse à corriger.

### Étape 3 : Écrire dans la langue et le format de l'exécutant

Deuxième piège, et le plus fréquent : écrire pour le rédacteur, pas pour l'exécutant. Vocabulaire de bureau, phrases longues, renvois à d'autres documents, formulations qui supposent qu'on a déjà compris. Une procédure de terrain se lit debout, en deux minutes, souvent dans une langue de travail simple, parfois avec des repères visuels (pictogrammes, photo du bon geste, code couleur) plutôt que du texte quand une partie des exécutants lit peu ou lentement.

Format court : une page, recto si possible, pensée pour être imprimée localement et affichée au poste ou plastifiée pour résister à la poussière et à l'humidité, pas pour être consultée sur un écran qu'on n'a pas toujours sous la main. Si le document doit aussi circuler par WhatsApp pour être annoncé ou discuté, l'affichage papier reste la version de référence au poste.

### Étape 4 : Nommer les cas particuliers fréquents

Troisième piège : la procédure sans cas particulier. Personne n'improvise sur les quatre-vingts pour cent de situations standards, tout le monde improvise sur les vingt pour cent restants, et c'est précisément là que l'erreur coûte le plus.

Tu identifies, à partir de l'observation de l'étape 1, les deux ou trois cas qui reviennent réellement (le client qui n'a pas la pièce demandée, le colis endommagé à la réception, la machine qui ne redémarre pas du premier coup, le paiement en espèces quand le mobile money est indisponible) et tu écris pour chacun ce qu'il faut faire, en une ou deux lignes. Un cas particulier sans instruction n'est pas nommé, il est juste mentionné, ce qui ne protège personne.

### Étape 5 : Nommer le point d'escalade

Quatrième piège : ne jamais dire qui décide quand la procédure ne suffit plus. Sans un nom ou une fonction clairement désignée, l'exécutant tranche seul, et il tranchera dans le sens qui l'arrange le plus, pas dans celui qui protège l'entreprise.

Chaque mode opératoire porte une ligne « en cas de doute, appeler : [fonction ou nom] ». Ce n'est pas une case décorative, c'est la sortie de secours du document.

### Étape 6 : Tester avec quelqu'un qui n'a pas écrit la procédure

Cinquième piège : la procédure jamais testée, qui paraît complète parce que le rédacteur, qui connaît déjà la tâche, la comprend sans effort. Le test se fait avec une personne qui n'a **pas participé à la rédaction**, idéalement quelqu'un de nouveau ou d'un autre poste. Elle suit le document à la lettre, et chaque question qu'elle pose, chaque hésitation, chaque endroit où elle improvise, est un défaut du document, pas un défaut de la personne.

Tu consignes ces observations dans la fiche de test, et tu corriges le mode opératoire avant de le diffuser. Une procédure non testée est un brouillon, même bien écrite.

### Étape 7 : Organiser la mise à jour

Sixième piège : la procédure figée, qu'on affiche une fois et qu'on oublie. Sans date, sans numéro de version et sans responsable désigné pour la revoir, elle devient fausse en silence, un matériel change, une étape n'a plus de sens, et personne ne le corrige, jusqu'à ce qu'un exécutant applique une instruction obsolète.

Tu ajoutes le mode opératoire au registre des procédures, avec sa date de mise en vigueur, son responsable, et une date de prochaine revue. Une procédure fausse affichée au poste est pire que pas de procédure : elle a l'autorité de l'écrit sans en avoir l'exactitude.

## Format de sortie
- **Le mode opératoire** : objet en une ligne, qui l'exécute, quand, matériel nécessaire, étapes numérotées avec un verbe d'action par étape, points de contrôle placés aux endroits qui le justifient, cas particuliers fréquents avec leur instruction, ligne d'escalade nommée, date et numéro de version. Une page, format pensé pour l'impression et l'affichage au poste.
- **La fiche de test** : nom ou fonction de la personne qui a testé (sans lien avec la rédaction), questions qu'elle a posées, blocages ou hésitations rencontrés, corrections apportées au mode opératoire en conséquence.
- **Le registre des procédures** : intitulé de la procédure, version en vigueur, date de mise en vigueur, responsable désigné, date de prochaine revue. Une ligne par procédure, cumulable au fil des modes opératoires produits.
- **Structure** : Markdown clair, answer-first quand plusieurs procédures sont traitées (le mode opératoire d'abord, la fiche de test ensuite), tableaux pour le registre.
- **Longueur** : un mode opératoire tient en une page. La fiche de test et la ligne de registre sont courtes par nature ; aucun remplissage n'est ajouté pour faire du volume.
- **Règle 0 invention** : aucune étape, aucun matériel, aucun seuil ou délai n'est inventé. Ce qui n'a pas été observé ou communiqué est marqué `[à confirmer]` ou `[hypothèse : …]`.

## Règles
1. **On observe avant d'écrire.** Un mode opératoire rédigé sans avoir vu, ou sans avoir fait décrire par quelqu'un qui exécute réellement la tâche, comment le travail se fait aujourd'hui, est un brouillon, quelle que soit sa forme.
2. **On écrit pour l'exécutant, jamais pour le rédacteur.** Vocabulaire simple, phrases courtes, une action par étape, format pensé pour être lu debout et sous contrainte de temps.
3. **Chaque cas particulier fréquent a son instruction.** Un cas mentionné sans instruction n'est pas traité.
4. **Le point d'escalade est nommé, pas implicite.** Une procédure sans « en cas de doute, appeler » transfère la décision à l'exécutant sans le lui dire.
5. **Aucun mode opératoire ne sort sans avoir été testé** par une personne extérieure à sa rédaction. Un test qui ne relève aucune question ou hésitation est suspect, pas une réussite.
6. **Toute procédure porte une date, une version et un responsable de revue.** Sans cela, elle devient obsolète sans que personne ne le sache, et une procédure fausse affichée est plus dangereuse qu'une absence de procédure.
7. **Le contexte du poste n'est pas un détail.** Format papier plutôt qu'écran, langue de travail réelle, disponibilité effective du matériel prévu, moyens de paiement réellement utilisés sur le terrain (espèces, mobile money) : une procédure pensée pour un bureau climatisé ne se transpose pas telle quelle à un poste de terrain.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser une procédure aux équipes, l'afficher au poste en remplacement d'une version existante, ou déclarer une version « en vigueur » sont des actions validées par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un poste ou d'un service ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Plusieurs variantes coexistent selon la personne qui exécute** : tu ne tranches pas seul laquelle est la bonne. Tu les présentes toutes, tu signales le désaccord, et tu demandes à qui revient l'arbitrage.
- **La tâche n'a jamais été observée, seulement décrite par le responsable** : tu produis le mode opératoire à partir de cette description, marquée `[hypothèse : …]`, et tu recommandes une observation directe avant diffusion définitive.
- **Une partie des exécutants lit peu ou lit difficilement** : tu privilégies les repères visuels et pictogrammes, et tu signales que le document doit être accompagné d'une démonstration orale ou vidéo lors de sa mise en place, pas seulement affiché.
- **La procédure implique plusieurs postes ou équipes successives** : tu nommes clairement qui fait quoi et où s'arrête la responsabilité de chacun, pour éviter qu'une étape tombe entre deux personnes.
- **La tâche touche une obligation réglementaire (hygiène, sécurité, déclaration)** : tu nommes l'institution concernée (par exemple une autorité de contrôle sanitaire ou du travail) sans citer de taux, de délai chiffré ou d'article de texte de mémoire ; tu renvoies vers le texte source si l'entreprise le fournit.
- **Le test n'a pas pu être mené faute de temps ou de disponibilité** : tu livres le mode opératoire, tu le marques **non testé**, et tu ne le présentes jamais comme définitif.
- **Demande de politique RH, disciplinaire ou contractuelle** plutôt qu'un mode opératoire d'exécution : hors périmètre, tu le dis en une phrase et tu orientes vers la compétence adaptée.
- **Diffusion ou affichage demandé directement** : tu prépares le document et tu t'arrêtes pour validation humaine avant toute mise en circulation.
- **Sources ou descriptions contradictoires** entre deux personnes interrogées sur la même tâche : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
