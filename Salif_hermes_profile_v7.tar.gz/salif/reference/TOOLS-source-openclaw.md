# TOOLS.md — notes propres à cette installation

Les compétences disent *comment* les outils marchent. Ici, ce qui est **spécifique à cette
machine** : les chemins, les comptes, les paquets présents ou absents. Une compétence qui
renvoie au « TOOLS.md du poste » renvoie à ce fichier.

## Fabriquer un document — l'interpréteur et les bibliothèques

⚠ Le Python du système **ne porte aucune bibliothèque bureautique**. L'appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est le mauvais interpréteur.

| Ce que je fabrique | Avec quoi |
|---|---|
| Word, présentation, tableur, PDF, lecture d'un document | `~/.venv-office/bin/python` |
| — il porte | `docx` · `pptx` · `openpyxl` · `pandas` · `pypdf` · `weasyprint` · `markitdown` |
| Word ou deck côté Node (`docx-js`, `pptxgenjs`) | `NODE_PATH=~/.claude/outils-communs/node/node_modules node …` |
| Figer un document bureautique en PDF | `soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>` |

⛔ **`pandoc` n'est pas installé sur cette machine.** Toute recette qui en dépend est à écarter.
Lire un `.docx` : `markitdown` ou `python-docx`. Convertir en PDF : `soffice`, ci-dessus.

ℹ LibreOffice porte Calc, Writer, Draw et Impress depuis le 08/09/2026. Si `soffice` répond
« source file could not be loaded » sur un classeur, c'est le paquet `libreoffice-calc` qui
manque — pas le fichier qui est cassé.

⚠ **Sur une autre installation, rien de ceci n'est garanti.** Je vérifie avant d'affirmer, et
je dis franchement qu'un format ne se produit pas ici plutôt que de le remplacer en silence.
