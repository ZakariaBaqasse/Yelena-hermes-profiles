# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup: camera names and locations, SSH hosts and aliases, preferred TTS voices, speaker/room names, device nicknames, anything environment-specific.

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

### Python / LibreOffice (pour bp-guardrails et scripts openpyxl)

Pas de `pip`/`venv` système par défaut (apt bloqué, pas de sudo) — mais des toolchains dédiées existent déjà sur l'hôte, hors PATH par défaut :

- `/home/node/tools/py-bp/bin/python3` — Python avec `openpyxl` déjà installé
- `/home/node/tools/py-bp/bin/pip` — pip fonctionnel pour ce même venv
- `/home/node/tools/bin/soffice` — LibreOffice headless (recalcul de classeurs)

Préfixer le PATH avant d'utiliser un skill Python qui manipule des `.xlsx` (ex. `bp-guardrails`) :

```bash
export PATH="/home/node/tools/py-bp/bin:/home/node/tools/bin:$PATH"
```

### Unipile WhatsApp (accès direct, ajouté 25/08)

Envoi WhatsApp via l'API Unipile, compte `2250702219778` (le seul autorisé,
confirmé par l'équipe). Secrets à `secrets/unipile.env` (chmod 600, propres à
cette instance, plus de dépendance au workspace ARIA).

Script : `outils/scripts/unipile_send.sh "message" [chat_id] [fichier]`
- Sans `chat_id` : envoie en self-chat, sûr par défaut.
- `chat_id` d'un groupe/contact client : à documenter ici une fois le canal du nouveau
  déploiement connu (aucun chat_id de client précédent n'est repris dans ce pack).
- `fichier` optionnel : attache un document (ex. xlsx) au message.

Ceci n'est PAS un outil OpenClaw nommé — c'est `exec` + un script bash qui lit le fichier
`secrets/unipile.env` (à fournir séparément, jamais inclus dans un pack) et fait un `curl`
direct vers l'API Unipile.

## Related

- [Agent workspace](/concepts/agent-workspace)

## Fabriquer un document — l'interpréteur et les bibliothèques

⚠ Le Python du système **ne porte aucune bibliothèque bureautique**. L'appeler avec `python3`
échoue, et l'échec ressemble à une compétence manquante alors que c'est le mauvais interpréteur.

| Ce que je fabrique | Avec quoi |
|---|---|
| Word, présentation, tableur, PDF, lecture d'un document | `~/.venv-office/bin/python` |
| — il porte | `docx` · `pptx` · `openpyxl` · `pandas` · `pypdf` · `weasyprint` · `markitdown` |
| Word ou deck côté Node (`docx-js`, `pptxgenjs`) | `NODE_PATH=~/.claude/outils-communs/node/node_modules node …` |
| Figer un document bureautique en PDF | `soffice --headless --norestore --convert-to pdf --outdir <dossier> <fichier>` |

⛔ **`pandoc` n'est pas installé sur cette machine.** Toute recette qui en dépend est à écarter.
Lire un `.docx` : `markitdown` ou `python-docx`. Convertir en PDF : `soffice`, ci-dessus.

ℹ LibreOffice porte bien Calc, Writer, Draw et Impress depuis le 08/09/2026. Si `soffice`
répond « source file could not be loaded » sur un classeur, c'est le paquet `libreoffice-calc`
qui manque — pas le fichier qui est cassé.

