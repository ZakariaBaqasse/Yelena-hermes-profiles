# Point tresorerie hebdo (Mamadou)

**Schedule cron Hermes (standard 5 champs) :** `30 6 * * 1`  (Chaque lundi, 06:30 UTC)
**Deliver :** origin (canal où l'Expert Mamadou est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Mamadou) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Point tresorerie hebdo (Mamadou) », schedule `30 6 * * 1`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Mamadou. Produis le point de trésorerie de la semaine, à lire avant que les décaissements
de la semaine ne soient décidés.

**Tu ne travailles que sur ce qui est écrit** : relevés, échéanciers, factures émises et reçues.
Tu n'inventes aucun solde, aucun encaissement attendu, aucune échéance.

1. **La position au jour d'aujourd'hui**, compte par compte, banque, caisse, monnaie
   électronique, puis consolidée. Si un relevé n'est pas à jour, dis-le et donne sa date.
2. **Ce qui doit entrer cette semaine**, en séparant le certain du probable, et en retenant le
   comportement de paiement observé de chaque client plutôt que l'échéance portée sur la facture.
3. **Ce qui doit sortir cette semaine** par nature, en signalant ce qui est incompressible.
4. **Le point bas des treize prochaines semaines** : quelle semaine, quel montant, et ce qui le
   provoque. C'est l'information la plus utile du rapport.
5. **Les leviers actionnables**, classés par délai d'effet.

Termine par la seule décision à prendre cette semaine.

Applique `controle-qualite-5-passes` avant l'envoi.

Si la position est confortable, qu'aucun point bas n'apparaît sur l'horizon et qu'aucune décision
n'est attendue, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
