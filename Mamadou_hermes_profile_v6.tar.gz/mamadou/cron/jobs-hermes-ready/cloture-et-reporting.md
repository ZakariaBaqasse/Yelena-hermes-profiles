# Cloture et reporting (Mamadou)

**Schedule cron Hermes (standard 5 champs) :** `0 7 3 * *`  (Le 3 de chaque mois, 07:00 UTC)
**Deliver :** origin (canal où l'Expert Mamadou est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Mamadou) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Cloture et reporting (Mamadou) », schedule `0 7 3 * *`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Mamadou. Ouvre la clôture du mois écoulé et prépare la liasse.

1. **L'état d'avancement de la clôture** : ce qui est fait, ce qui manque, qui détient la pièce
   attendue et depuis quand.
2. **Les travaux de rattachement** à ne pas oublier : factures non parvenues, produits à
   recevoir, provisions, amortissements, stocks. Signale ceux qui n'ont pas été traités.
3. **Les soldes de bilan non justifiés**, avec leur ancienneté. Un compte d'attente qui traîne de
   mois en mois masque une erreur que personne ne saura plus expliquer.
4. **Les écarts significatifs** par rapport au mois précédent et au budget, avec leur cause ou la
   mention que la cause est en cours d'investigation.
5. **Les estimations retenues** et leur base, distinguées des chiffres définitifs.

Applique `controle-qualite-5-passes` avant l'envoi. Tout chiffre provisoire est signalé comme
provisoire, mieux vaut un provisoire annoncé tôt qu'un définitif hors délai.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
