---
name: devis-proposal-generator
version: 1.0.0
description: "Génère devis chiffrés et propositions commerciales prêts à envoyer, à partir du besoin client et de la grille tarifaire (prix jamais inventés)."
bucket: A
tags: [Sales]
maj: 2026-09-03
---

# Devis Proposal Generator

## Ce qu'il faut avoir sous la main
- Obligatoires : besoin/contexte client, l'offre ou le catalogue de l'entreprise, le pricing (ou grille tarifaire).
- Optionnelles : nom du client, interlocuteur, deadline, remises applicables, conditions de paiement, devise, brand kit.


**Ce qu'elle suppose comme accès** : Génération de visuel interactif (Frame). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. Reformuler la compréhension du besoin (montre que tu as écouté).
2. Structurer la solution : livrables, périmètre inclus / exclus, hypothèses.
3. Chiffrer à partir de la grille fournie (lignes, quantités, unités, sous-totaux, total, taxes si fournies) — rien d'inventé.
4. Ajouter conditions (validité de l'offre, paiement, délais) et prochaines étapes claires (CTA de signature).
5. Adapter le niveau de détail : devis simple (1 page) vs proposition détaillée (multi-sections).

## Format de sortie

Termine TOUJOURS par un **Frame interactif** présentant le livrable de façon soignée et professionnelle (aux couleurs du brand kit si fourni). Si la visualisation n'est pas disponible, produis un livrable structuré prêt à l'emploi.
Le Frame présente le devis/proposition en document commercial soigné (tableau de prix lisible + total mis en avant).

## Règles

- Zéro invention : tout fait, chiffre, prix, statut ou référence repose sur une source vérifiable fournie ou un connecteur. Une donnée absente est signalée « à confirmer », jamais inventée.
- Validation humaine : tout document destiné à être envoyé est présenté « à valider avant envoi » ; aucun envoi automatique.
- Prix & conditions : jamais inventés. Utilise exclusivement la grille tarifaire fournie ; si un prix manque, marque « à confirmer » et ne devine pas.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

À partir d'un besoin client et de l'offre/pricing de l'entreprise, produire un devis chiffré ou une proposition commerciale complète (contexte, compréhension du besoin, solution, périmètre, prix, conditions, prochaines étapes).
