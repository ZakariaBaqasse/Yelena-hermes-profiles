---
id: Y0112
name: create-doc
description: Rédige et met en forme un document natif Google Docs (note, rapport, mémo, contrat) depuis un contenu ou un brief — équivalent maison d'un générateur de doc type Gamma / Genspark Docs.
bucket: B
tags: [Production & artefacts, Marketing & Contenu]
version: 1
maj: 2026-09-03
---

# create-doc — le document natif éditable

> **Skill maison de l'entreprise.** Notre chaîne markdown → Google Doc
> natif est un savoir-faire interne ; elle ne dépend d'aucun outil tiers.

## Ce qu'il faut avoir sous la main
Bienvenue. Pour ton document, donne-moi :

1. **Type de doc** : note, rapport, mémo de décision, compte-rendu, contrat, one-pager écrit…
2. **Sujet & objectif** : ce qu'il doit dire et à qui il sert.
3. **Contenu** : les éléments à intégrer (points, chiffres, doc source). Chiffre absent = on ne l'invente pas.
4. **Ton & longueur** : registre (institutionnel, direct, pédagogique) et taille visée.
5. **Sortie** : **Google Doc natif éditable** (par défaut) et/ou **PDF**.


**Ce qu'elle suppose comme accès** : Google Drive/Docs, gog. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Plan answer-first** : la conclusion / le message clé d'abord, puis le développement. Un titre par section, une idée par paragraphe.
2. **Rédiger en Markdown** : H1-H3, listes, gras, tableaux, liens — c'est la source qui se convertit proprement.
3. **Convertir en Google Doc NATIF** : `gog docs create "Titre" --file doc.md --parent <folder> --account [datasource à brancher : compte éditeur Google Docs/Drive]` (le markdown devient un vrai Doc : titres/listes/gras/images). ⚠️ `gog drive upload doc.docx` **ne convertit pas** (reste un .docx) — utiliser `docs create --file`.
4. **Itérer en gardant le lien** (si le doc existe) : régénérer le `.docx`/markdown puis **PATCH Drive media** sur le `fileId` existant (upload en conversion) — l'ID/lien/partages sont préservés.
5. **Partager** : avec les bonnes personnes ; jamais de données confidentielles dans un doc partagé au domaine/tiers.
6. **QA** : relire la structure (titres cohérents, pas de trou), vérifier que les chiffres = la source.

## Format de sortie
- **Livrable principal** : **Google Doc natif éditable** (lien partageable) — ou **PDF** si demandé (export Drive : `gog drive download --format pdf`).
- **Versioning** : `<slug>_v<N>` ; révision = nouveau `_v(N+1)`, jamais d'écrasement (sauf PATCH in-place assumé = même lien).
- **Support** : réponse directe (« doc prêt, lien ») puis le lien.
- **Règle 0 invention** : aucune donnée chiffrée/factuelle inventée. Manque → « [à confirmer] » ou demander — jamais présentée comme réelle. Pour un doc administratif/légal, ne pas répéter inutilement le nom complet (1 identification + « l'intéressé·e »/pronoms ensuite).

## Règles
- **Answer-first** : le lecteur doit avoir l'essentiel en 10 secondes.
- **Structure lisible** : hiérarchie de titres réelle, listes courtes, tableaux quand c'est pertinent.
- **Natif, pas figé** : livrer du Google Doc éditable (pas un PDF) si l'utilisateur doit retoucher.
- **Confidentialité** : scrub des chiffres internes avant tout partage large ; un doc qui sort du cercle de décision ne contient aucun financier interne sensible.
- **Ton adapté** à l'audience et à la voix demandée (institutionnel ≠ direct ≠ pédagogique).

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **JSON de retour de `gog docs create` capricieux** → retrouver le doc via `gog drive search "name = '...'"` + filtre `mimeType = document`.
- **Tableaux complexes / mise en forme fine** → passer par un `.docx` (python-docx) puis conversion Drive, plutôt que markdown si le rendu markdown ne suffit pas.
- **Contrat / doc légal** → assembler par blocs (python-docx, XML) pour préserver les tableaux ; ne pas passer par pandoc md→docx qui casse les tables.
- **Doc long** → sommaire + sections ancrées.

## Détails complémentaires
### Positionnement
Notre valeur : un **Google Doc natif éditable, rangé, partagé et versionné**, itérable en gardant le lien, intégré au Drive de l'utilisateur. C'est un service interne à l'entreprise, pas une fonctionnalité tierce.
