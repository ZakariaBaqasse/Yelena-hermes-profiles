# Repérage des lignes sources et contrôle de cohérence

Première étape de toute génération. Un graphique branché sur la mauvaise ligne ne produit aucune erreur Excel : il produit une courbe plausible et fausse. Ce fichier décrit comment éviter cela.

## 1. Repérer par libellé, jamais par numéro de ligne

Parcourir la colonne A de l'onglet source et retenir le numéro de ligne dont le libellé correspond. Les libellés varient d'un BP à l'autre : chercher sur une liste de synonymes, en insensible à la casse et aux accents.

| Rôle | Libellés à reconnaître |
|---|---|
| Ligne de dates | ligne 7 de la grille standard de la chaîne BP ; sinon première ligne dont toutes les cellules de la zone de temps sont des dates |
| Flux d'exploitation | `Operating cash-flow`, `Flux d'exploitation`, `Cash-flow opérationnel` |
| Flux d'investissement | `Investing cash-flow`, `Flux d'investissement`, `Capex` |
| Flux de financement | `Financing cash-flow`, `Flux de financement` |
| Flux hors exploitation | `Non-operating cash-flow` (modèles à deux blocs) |
| Solde de clôture | `Closing balance`, `Solde de clôture`, `Closing balance / Runway` |
| Solde d'ouverture | `Starting balance`, `Opening balance`, `Solde d'ouverture` |
| Revenu total | `Total revenues`, `Gross revenues`, `Net revenue`, `Chiffre d'affaires` |
| Volume | `Total active buyers`, `Total active users`, `Total units sold`, `Total assets in service`, `Total TPV`, `Total orders` |

Deux règles de sélection des blocs de flux :

- **Soit trois blocs** (exploitation, investissement, financement), **soit deux** (exploitation, hors exploitation). Jamais un mélange des deux découpages.
- **Jamais un sous-total avec ses composantes.** Si `Operating cash-flow` est retenu, ses lignes de détail (encaissements, décaissements, variation de BFR) ne le sont pas.

Pour le volume, préférer la ligne qui porte le driver le plus parlant pour le lecteur : le nombre de clients actifs pour un modèle à base récurrente, le nombre de transactions ou d'unités pour un modèle transactionnel, le parc en service pour un modèle à actifs. En cas d'ambiguïté, demander à l'utilisateur plutôt que de choisir.

## 2. Contrôle de cohérence obligatoire, avant de tracer

Sur un classeur **recalculé** (les formules doivent porter des valeurs, donc passer par LibreOffice headless ou lire un classeur déjà ouvert dans Excel), vérifier pour chaque période :

```
somme des blocs empilés  =  solde de clôture(période)  −  solde de clôture(période − 1)
```

`chart_helpers.check_cashflow_block()` le fait et renvoie la liste des périodes en écart. Cette liste doit être vide.

Un écart signifie l'une de ces trois choses, dans l'ordre de probabilité :

1. un bloc de flux a été oublié dans la sélection ;
2. un sous-total et ses composantes sont empilés ensemble ;
3. le tableau de flux lui-même ne s'articule pas, et c'est alors un défaut du modèle, pas du graphique. Dans ce cas, ne pas tracer : signaler l'incohérence à l'utilisateur avec les périodes concernées et le montant de l'écart. Un graphique tracé sur un TFT qui ne boucle pas donne une fausse assurance.

## 3. Ce qu'il faut restituer à l'utilisateur

En fin de génération, afficher la table du câblage réellement retenu :

```
Graphe trésorerie   dates      Cashflow_Monthly!7
                    flux 1     Cashflow_Monthly!22   Operating cash-flow
                    flux 2     Cashflow_Monthly!31   Investing cash-flow
                    flux 3     Cashflow_Monthly!44   Financing cash-flow
                    solde      Cashflow_Monthly!48   Closing balance
                    contrôle   OK sur 36 périodes
```

C'est ce qui permet à l'utilisateur de vérifier en dix secondes que le graphe raconte bien ce qu'il croit.
