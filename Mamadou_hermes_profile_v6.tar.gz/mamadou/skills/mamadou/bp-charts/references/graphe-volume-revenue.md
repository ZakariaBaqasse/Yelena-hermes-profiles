# Graphes volume contre revenu

Deux graphiques de même construction, sur deux mailles : les **mois 1 à 13** (source `P&L_Monthly`, colonnes D à P) et les **trois exercices** (source `P&L_Yearly`, colonnes C à E). Ils répondent à une seule question : la croissance vient-elle du volume ou du prix. Les poser côte à côte sur le dashboard, le mensuel à gauche, l'annuel à droite.

Le treizième mois n'est pas un détail : il donne le premier point de comparaison d'une année sur l'autre et évite de lire une saisonnalité comme une tendance.

## Deux formes, choisies par l'écart d'échelle

```
ratio = max(|montant|) / max(|volume|)
├─ ratio > 20   → barres pour le montant + COURBE pour le volume sur axe secondaire
└─ ratio <= 20  → deux séries de barres groupées sur un axe unique
```

La raison est mécanique : un revenu en millions et un volume en centaines placés sur le même axe écrasent le volume sur la ligne de zéro. Inversement, deux séries d'ordres de grandeur proches se lisent mieux en barres groupées, sans le détour d'un second axe. Le helper applique cette règle sous `variant="auto"` ; si l'utilisateur force une forme que le ratio contredit, le signaler sans corriger.

## Séries et palette

- **Montant** (revenu net, chiffre d'affaires, TPV) : barres Deep Navy `#03045E`.
- **Volume** (clients actifs, unités vendues, transactions, parc en service) : courbe Bright Cyan `#00B4D8` de 2,25 pt sans marqueur, ou barres de la même teinte en forme groupée.

Le libellé de chaque série porte son unité entre parenthèses, `Net revenue (EUR)` et `Active buyers (#)` : c'est le seul endroit où le lecteur peut vérifier qu'il ne compare pas des euros à des unités.

## Axe secondaire, le piège à connaître

Quand la forme retenue est barres plus courbe, l'axe secondaire se déclare sur l'axe de **la courbe** :

```
line.y_axis.axId = 200
line.y_axis.crosses = "max"        # sur l'axe SECONDAIRE
line.y_axis.delete = False
line.x_axis.axId = 20              # axe de categories propre au secondaire
line.x_axis.delete = True          # masque, mais il doit exister
bars += line
```

Poser `crosses = "max"` sur l'axe **primaire**, comme le fait la recette documentée d'openpyxl, produit un graphique dont les deux axes sont étiquetés à l'envers : l'axe de gauche affiche l'échelle du volume alors qu'il porte les barres de montant. Les données restent justes, la lecture est fausse, et rien ne le signale. Vérifié au rendu.

L'axe de catégories masqué rattaché au secondaire n'est pas facultatif : sans lui, Excel affiche un second axe de catégories parasite en haut de la zone de tracé.

## Étiquettes de données

Les captures de référence en portent sur les deux séries, ce qui fonctionne à trois points et devient illisible à douze.

Règle de densité : les deux séries étiquetées jusqu'à 6 périodes, le montant seul de 7 à 13 périodes, aucune au-delà. Position `outEnd` pour les barres, `t` pour la courbe.

Cas particulier fréquent, et il faut le traiter : quand le volume et le montant sont proportionnels (panier moyen constant), la courbe passe exactement au sommet des barres et les deux étiquettes se superposent. Détecter la proportionnalité par une corrélation supérieure à 0,98 et, dans ce cas, rentrer l'étiquette de montant dans la barre (`inEnd`) en blanc. Le helper le fait automatiquement.

Une étiquette doit afficher **la valeur seule**. Les moteurs de rendu affichent `Catégorie ; Série ; Valeur` tant que `showSerName`, `showCatName`, `showLegendKey`, `showBubbleSize` et `showPercent` ne sont pas explicitement mis à `False`. Les mettre tous, systématiquement.

## Axes, titre, légende

Axe des valeurs laissé en automatique sur les deux échelles : contrairement au graphe de trésorerie, il n'y a pas de zéro à faire franchir, et forcer une borne écraserait l'une des deux séries. Format `#,##0`, police 9 pt.

Axe des catégories : format `mmm-yy` en mensuel, libellé d'exercice en annuel, graduations à l'extérieur, étiquettes en position normale (aucune valeur négative ici).

Titre affiché, de la forme `Revenue and volume — months 1 to 13` et `Revenue and volume — Year 1 to Year 3`. Légende en haut à droite, non superposée, comme sur les captures de référence.

Dimensions : largeur bornée à l'intervalle **560 à 760 pt**, hauteur 60 % de la largeur. Les deux graphiques doivent avoir la même taille pour se lire en vis-à-vis. La borne basse de 560 pt n'est pas cosmétique : en dessous, la légende en haut à droite recouvre le titre au rendu.

## Ce qui n'est pas prescrit

Les deux captures fournies par l'utilisateur sont des exemples, pas un gabarit à copier au pixel. Ce qui en est repris est structurel : le couple montant plus volume, l'axe secondaire quand les échelles divergent, les étiquettes de valeur, la légende en haut, le titre à gauche. Ce qui n'en est pas repris : les couleurs propres à chaque deck, qui suivent ici la charte Yelema, et le nombre de points, qui suit l'horizon du modèle.
