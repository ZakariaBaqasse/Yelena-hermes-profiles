# Contrôles avant livraison — graphiques d'un BP

Un graphique faux ne lève aucune erreur. Ces contrôles sont donc la seule barrière.

## A. Avant de tracer

1. **Cohérence du tableau de flux** : pour chaque période, somme des blocs empilés égale variation du solde de clôture. Exécuter `check_cashflow_block()` sur un classeur recalculé. La liste renvoyée doit être vide. Si elle ne l'est pas, ne pas tracer et signaler les périodes en écart.
2. **Aucun sous-total empilé avec ses composantes.** Vérifier que les lignes retenues sont toutes de même niveau dans le tableau de flux.
3. **Découpage homogène** : deux blocs (exploitation, hors exploitation) ou trois (exploitation, investissement, financement), jamais un mélange.
4. **Nombre de périodes lu sur la source**, égal à l'horizon réel du modèle, jamais une constante.

## B. Sur le classeur produit

5. **Toutes les cellules des blocs de données sont des formules**, aucune valeur en dur. Scanner : chaque cellule de la zone doit commencer par `=`.
6. **Les libellés des séries correspondent** à ceux des lignes sources, à l'identique.
7. **Aucun chevauchement de graphiques** : vérifier que l'ancrage de chaque graphique laisse passer la hauteur du précédent.
8. **Axe des valeurs du graphe de trésorerie** symétrique dès qu'une période est négative, et couvrant le point bas du runway. Vérifier que `min` est inférieur ou égal au minimum tracé.
9. **Étiquettes de l'axe des catégories en position basse** sur le graphe de trésorerie.
10. **Étiquettes de données réduites à la valeur** : les cinq indicateurs `showSerName`, `showCatName`, `showLegendKey`, `showBubbleSize`, `showPercent` explicitement à `False`.
11. **Densité d'étiquettes** conforme à la règle : deux séries jusqu'à 6 périodes, montant seul jusqu'à 13, aucune au-delà.
12. **Cellules vides traitées comme zéro** sur les trois graphiques.
13. **Palette conforme** à celle annoncée à l'utilisateur, la même sur les trois graphiques.
14. **Onglet DASHBOARD** en paysage, ajusté à la largeur, quadrillage masqué.

## C. Contrôle visuel, non négociable

15. **Exporter le classeur en PDF et regarder les images.** Un graphique ne se valide pas en lisant du XML : l'attribution des axes, le chevauchement des étiquettes et l'écrasement des barres ne se voient qu'au rendu. Convertir avec LibreOffice headless, rendre les pages en images, les ouvrir.
16. Vérifier sur l'image : chaque axe porte bien l'échelle de la série qu'il gouverne, les étiquettes ne se chevauchent pas, aucune série n'est écrasée sur la ligne de zéro, la légende ne recouvre pas la zone de tracé.

## D. À restituer à l'utilisateur

17. **La table du câblage retenu** : pour chaque graphique, l'onglet et le numéro de ligne de chaque série, avec le libellé trouvé. C'est ce qui rend le résultat auditable en quelques secondes.
18. **Le résultat du contrôle de cohérence**, nombre de périodes vérifiées.
19. **Les avertissements de lisibilité** le cas échéant : ratio solde sur flux supérieur à 5 sur le graphe de trésorerie, forme forcée contre la règle du ratio sur les graphes volume contre revenu.
20. **La forme retenue** pour chaque graphe volume contre revenu, avec le ratio qui l'a déterminée.
