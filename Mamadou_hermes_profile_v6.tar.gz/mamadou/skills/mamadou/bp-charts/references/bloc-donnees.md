# Bloc de données intermédiaire

Chaque graphique lit un bloc posé sur le DASHBOARD, jamais l'onglet de calcul directement. Le bloc coûte trois lignes et fait gagner une reconstruction de graphique à chaque évolution du modèle.

## Structure

`1 + n` lignes × `p` colonnes, où `n` est le nombre de séries et `p` le nombre de périodes, **lu dynamiquement sur l'onglet source**, jamais figé.

| Ligne | Colonne A | Contenu des colonnes B et suivantes | Format |
|---|---|---|---|
| 1 | `Données graphique` (Arial 10 gras, gris `#808080`) | dates ou libellés de période, référence simple vers la source | `mmm-yy` en mensuel, texte en annuel ; Arial 8, centré |
| 2..n+1 | libellé de la série, repris tel quel de l'onglet source | référence simple vers la ligne source | `#,##0`, Arial 9 |

Chaque cellule est **une référence simple**, une seule formule tirée vers la droite, en police verte selon la convention de la chaîne BP. Aucun littéral, aucun calcul dans le bloc : s'il faut une transformation (conversion d'unité, cumul), elle appartient à l'onglet de calcul, pas ici.

Reprendre le libellé de la source à l'identique : c'est lui qui alimente la légende du graphique, et un écart entre la légende et le tableau du BP est une source de doute pour le lecteur.

## Emplacement sur le DASHBOARD

Les graphiques occupent le haut de l'onglet, les blocs de données le bas, séparés par au moins deux lignes vides. Ordre des blocs identique à l'ordre des graphiques. Laisser une ligne vide entre deux blocs.

Ancrage : poser le premier graphique en `B5`. Pour le suivant, déduire la ligne de la hauteur du précédent (`next_anchor()` dans le helper : environ deux lignes par centimètre, plus une marge). Deux graphiques qui se chevauchent sont invisibles à la génération et évidents à l'ouverture.

## Colonne source et colonne du bloc

La grille de la chaîne BP place le mois 1 en colonne D des onglets de calcul. Le bloc de données démarre lui en colonne B. Le décalage est donc constant et il est porté par la formule de génération, pas par une saisie :

```
bloc colonne B  →  source colonne D
bloc colonne C  →  source colonne E
...
```

Pour le graphe mensuel volume contre revenu, l'horizon est mois 1 à 13, soit les colonnes D à P de la source et B à N du bloc. Pour le graphe annuel, la source est `P&L_Yearly` colonnes C à E, et le bloc colonnes B à D.

## Pourquoi ce bloc n'est pas décoratif

Trois raisons, dans l'ordre d'importance :

1. **Re-pointer un graphique après une refonte du BP** revient à corriger les quelques formules du bloc, au lieu de rouvrir chaque série du graphique.
2. **Le bloc est lisible.** Un lecteur qui doute d'une courbe voit immédiatement les nombres qui la produisent, et les libellés des lignes sources.
3. **Le bloc rend le contrôle possible.** La vérification "somme des flux égale variation du solde" se fait sur le bloc, sur les mêmes valeurs que celles tracées, et pas sur une reconstitution.
