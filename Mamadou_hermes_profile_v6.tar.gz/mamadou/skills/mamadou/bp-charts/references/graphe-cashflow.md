# Graphe de trésorerie combiné

Barres empilées des sous-totaux de flux plus courbe du solde de clôture, sur **un seul axe des valeurs**. Objet : rendre immédiatement visibles le franchissement du zéro et le point bas du runway, en montrant sur le même repère la composition des flux et le niveau de trésorerie.

Le partage d'un axe unique entre barres et courbe est le choix structurant de ce graphique : il rend comparables l'amplitude des flux et le niveau de trésorerie. C'est aussi son unique faiblesse, traitée plus bas.

## Type et séries

Graphique combiné, sans axe secondaire.

- **Blocs de flux** en histogramme empilé : `grouping = "stacked"`, `overlap = 100`, `gapWidth = 150`, contour de barre noir de 1 pt.
- **Solde de clôture** en courbe : sans marqueur, non lissée, épaisseur 2 pt.
- Style de graphique `2`, cellules vides traitées comme zéro, aucune étiquette de données sur aucune série (à 36 périodes elles seraient illisibles, et la lecture cherche ici une forme, pas des valeurs).

Une série par ligne du bloc de données, dans l'ordre de lecture du tableau de flux. Catégories : la ligne de dates du bloc, pour toutes les séries.

Palette Yelema par défaut : exploitation Teal `#38B6AB`, investissement Gold `#FDC067`, financement Deep Blue `#0077B6`, courbe de solde Deep Navy `#03045E`. Sous `palette="reference"` : vert `#92D050`, ambre `#FFC000`, bleu clair `#8EA9DB`, navy `#002060`.

## Axe des valeurs, à calculer

1. `M = MAX(|min| ; |max|)` sur l'ensemble des valeurs tracées : **cumuls des barres empilées et valeurs de la courbe de solde**.
2. Arrondir `M` au multiple propre supérieur : 1, 2, 2,5 ou 5 × 10^k.
3. `minimum = −M`, `maximum = +M`, donc axe **symétrique autour de zéro**.
4. `unité principale = M / 3`, arrondie au même pas propre.

Si le solde reste positif sur tout l'horizon, `minimum = 0` est acceptable et rend le graphique plus lisible. Dès qu'une période est négative, conserver la symétrie : c'est elle qui donne au franchissement du zéro sa lisibilité.

Quadrillage principal visible, police 9 pt noire, format `#,##0`. Pas de titre d'axe : l'unité va dans le titre du graphique.

## Axe des catégories

- Étiquettes **positionnées en bas** (`tickLblPos = "low"`). Obligatoire dès que des barres descendent sous zéro : sinon les libellés de période se retrouvent au milieu du graphique, à hauteur de l'axe.
- Graduations à l'extérieur, format `mmm-yy`, police 9 pt.
- Au-delà de 24 périodes, n'afficher qu'une étiquette sur trois. Excel honore ce réglage ; certains moteurs de rendu l'ignorent et affichent tout, ce qui n'est pas bloquant.

## Titre, légende, dimensions

Titre affiché et non superposé, de la forme `<Objet> — flux de trésorerie et solde mensuels (<unité>)`. Légende en bas, affichée, non superposée. Largeur environ `19 pt × p`, bornée à l'intervalle 480 à 900 pt ; hauteur environ 60 % de la largeur. Attention, `chart.width` et `chart.height` d'openpyxl sont en **centimètres**.

## La limite de l'axe unique, et quoi en faire

Quand le solde de trésorerie devient très supérieur à l'amplitude des flux mensuels, par exemple après une levée, les barres s'écrasent au voisinage de zéro et le graphique ne montre plus que la courbe.

Règle : si `max|solde| / max|cumul de flux| > 5`, **le signaler à l'utilisateur** en fin de génération, avec le ratio constaté. Ne pas corriger d'office : l'axe unique est le choix assumé de la spécification, et basculer la courbe sur un axe secondaire change ce que le graphique raconte. Proposer les trois options, laisser trancher :

1. garder l'axe unique (la trésorerie est le message, les flux sont le détail) ;
2. passer la courbe sur un axe secondaire (deux échelles, lisibilité des deux séries, comparabilité perdue) ;
3. produire deux graphiques séparés, flux d'un côté et solde de l'autre.

## Contrôle avant tracé

Voir `reperage-sources.md`. Somme des blocs empilés égale variation du solde, sur chaque période, sans exception.
