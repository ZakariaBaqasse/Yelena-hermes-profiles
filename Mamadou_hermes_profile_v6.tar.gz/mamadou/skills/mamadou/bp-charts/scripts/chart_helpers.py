"""Aides openpyxl pour les graphiques d'un BP (voir references/).

Trois graphiques :
  1. cashflow_chart()      barres empilees des flux + courbe du solde, AXE UNIQUE
  2. volume_revenue_chart() montant + volume, axe secondaire ou barres groupees
  3. le meme, en maille annuelle

Pieges openpyxl verifies au prototypage, encodes ici une fois pour toutes :
  - chart.width / chart.height sont en CENTIMETRES (pas en points) -> PT_TO_CM
  - chart.display_blanks = "zero"  (et non displayBlanksAs)
  - axe secondaire : poser crosses="max" sur l'axe de la COURBE (axId 200),
    surtout pas sur l'axe primaire. La recette de la doc openpyxl met le
    crosses sur le primaire et les deux axes se retrouvent etiquetes a
    l'envers au rendu (verifie).
  - etiquettes de donnees : showSerName / showCatName / showLegendKey /
    showBubbleSize / showPercent doivent etre mis explicitement a False,
    sinon le rendu affiche "Categorie; Serie; Valeur".
  - epaisseurs de trait en EMU : 12700 = 1 pt, 25400 = 2 pt, 28575 = 2,25 pt.
"""
import math

from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.drawing.line import LineProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import (Paragraph, ParagraphProperties,
                                   CharacterProperties)
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter

PT_TO_CM = 0.0352778
EMU_PT = 12700

# ------------------------------------------------------------------ palettes
Yelema = {
    "amount":    "03045E",   # Deep Navy    - serie de montant (barres)
    "volume":    "00B4D8",   # Bright Cyan  - serie de volume (courbe/barres)
    "operating": "38B6AB",   # Teal
    "investing": "FDC067",   # Gold
    "financing": "0077B6",   # Deep Blue
    "balance":   "03045E",   # Deep Navy    - courbe de solde
    "alert":     "C35A46",   # Terracotta
    "axis":      "000000",
}
REFERENCE = {                # palette de la fiche de reference du cashflow
    "amount":    "002060",
    "volume":    "8EA9DB",
    "operating": "92D050",
    "investing": "FFC000",
    "financing": "8EA9DB",
    "balance":   "002060",
    "alert":     "C00000",
    "axis":      "000000",
}
PALETTES = {"Yelema": Yelema, "reference": REFERENCE}

FMT_INT = "#,##0"
FMT_MONTH = "mmm-yy"
GREY_HDR = "808080"


# ------------------------------------------------------------------ typo
def _txpr(size=900, color="000000", bold=False):
    cp = CharacterProperties(sz=size, b=bold, solidFill=color)
    return RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=cp),
                                 endParaRPr=cp)])


def data_labels(ser, color, size=800, numfmt=FMT_INT, pos=None):
    """Etiquette de VALEUR seule. Tous les autres flags explicitement a False."""
    d = DataLabelList()
    d.showVal = True
    d.showSerName = False
    d.showCatName = False
    d.showLegendKey = False
    d.showBubbleSize = False
    d.showPercent = False
    d.numFmt = numfmt
    d.txPr = _txpr(size, color, bold=True)
    if pos:
        d.dLblPos = pos
    ser.dLbls = d


def _correl(a, b):
    n = len(a)
    ma, mb = sum(a) / n, sum(b) / n
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    da = math.sqrt(sum((x - ma) ** 2 for x in a))
    db = math.sqrt(sum((y - mb) ** 2 for y in b))
    return num / (da * db) if da and db else 0.0


def nice_step(m):
    """Arrondi au multiple superieur propre : 1 / 2 / 2,5 / 5 x 10^k."""
    if m is None or m <= 0:
        return 1
    k = math.floor(math.log10(m))
    base = 10 ** k
    for mult in (1, 2, 2.5, 5, 10):
        if m <= mult * base * (1 + 1e-9):
            return mult * base
    return 10 * base


# ------------------------------------------------- bloc de donnees graphique
def data_block(ws, row, labels, source_formulas, n_periods, first_col=2,
               date_format=FMT_MONTH, link_color="008000", title="Données graphique"):
    """Ecrit un bloc intermediaire : 1 ligne de periodes + n lignes de series.

    labels          : ["Operating cash-flow", ...] (sans la ligne de dates)
    source_formulas : liste de patrons, un par ligne, dates comprises en [0].
                      Chaque patron contient {col} = lettre de la colonne
                      SOURCE correspondante. Ex :
                        "='Cashflow_Monthly'!{col}7"
    Retourne (row_dates, row_first_serie, row_last_serie, next_row).
    """
    hdr = ws.cell(row=row, column=1, value=title)
    hdr.font = Font(name="Arial", size=10, bold=True, color=GREY_HDR)
    for i in range(n_periods):
        c = ws.cell(row=row, column=first_col + i)
        c.value = source_formulas[0].format(col=get_column_letter(4 + i))
        c.number_format = date_format
        c.font = Font(name="Arial", size=8, color=link_color)
        c.alignment = Alignment(horizontal="center")
    for j, lbl in enumerate(labels, start=1):
        r = row + j
        ws.cell(row=r, column=1, value=lbl).font = Font(name="Arial", size=9)
        for i in range(n_periods):
            c = ws.cell(row=r, column=first_col + i)
            c.value = source_formulas[j].format(col=get_column_letter(4 + i))
            c.number_format = FMT_INT
            c.font = Font(name="Arial", size=9, color=link_color)
    return row, row + 1, row + len(labels), row + len(labels) + 2


# ------------------------------------------------------------------ axes
def _style_axes(ch, palette, numfmt=FMT_INT, size=900, cat_low=False, skip=None,
                cat_numfmt=None):
    ch.y_axis.numFmt = numfmt
    ch.y_axis.txPr = _txpr(size, palette["axis"])
    ch.y_axis.delete = False
    ch.x_axis.txPr = _txpr(size, palette["axis"])
    ch.x_axis.majorTickMark = "out"
    ch.x_axis.delete = False
    if cat_numfmt:
        ch.x_axis.numFmt = cat_numfmt
    if cat_low:
        ch.x_axis.tickLblPos = "low"
    if skip:
        ch.x_axis.tickLblSkip = skip
        ch.x_axis.tickMarkSkip = skip


def _size(ch, n_periods, min_pt=480, max_pt=900, ratio=0.6):
    w_pt = min(max(19 * n_periods, min_pt), max_pt)
    ch.width = w_pt * PT_TO_CM
    ch.height = w_pt * ratio * PT_TO_CM


# ============================================================ 1. CASHFLOW
def cashflow_chart(ws, row_dates, rows_flows, row_balance, n_periods,
                   flow_kinds=("operating", "investing", "financing"),
                   title="Monthly cash flows and balance",
                   palette="Yelema", first_col=2, anchor="B5"):
    """Barres empilees des sous-totaux de flux + courbe du solde, SUR UN SEUL
    AXE, symetrique autour de zero. rows_flows = liste de numeros de ligne du
    bloc de donnees, dans l'ordre de lecture du TFT."""
    p = PALETTES[palette]
    last = first_col + n_periods - 1
    cats = Reference(ws, min_col=first_col, max_col=last,
                     min_row=row_dates, max_row=row_dates)

    bars = BarChart()
    bars.type, bars.grouping = "col", "stacked"
    bars.overlap, bars.gapWidth, bars.style = 100, 150, 2
    for r in rows_flows:
        bars.add_data(Reference(ws, min_col=1, max_col=last, min_row=r, max_row=r),
                      titles_from_data=True, from_rows=True)
    for s, kind in zip(bars.series, flow_kinds):
        s.graphicalProperties = GraphicalProperties(solidFill=p[kind])
        s.graphicalProperties.line = LineProperties(solidFill="000000", w=EMU_PT)
    bars.set_categories(cats)

    line = LineChart()
    line.add_data(Reference(ws, min_col=1, max_col=last,
                            min_row=row_balance, max_row=row_balance),
                  titles_from_data=True, from_rows=True)
    ls = line.series[0]
    ls.graphicalProperties = GraphicalProperties()
    ls.graphicalProperties.line = LineProperties(solidFill=p["balance"],
                                                 w=2 * EMU_PT)
    ls.smooth = False
    ls.marker.symbol = "none"
    bars += line                      # axe unique : ne PAS toucher aux axId

    # axe des valeurs calcule sur les cumuls de barres ET la courbe
    vals = []
    for i in range(n_periods):
        stack = sum((ws.cell(row=r, column=first_col + i).value or 0)
                    for r in rows_flows if isinstance(
                        ws.cell(row=r, column=first_col + i).value, (int, float)))
        b = ws.cell(row=row_balance, column=first_col + i).value
        vals.append(stack)
        if isinstance(b, (int, float)):
            vals.append(b)
    numeric = [v for v in vals if isinstance(v, (int, float))]
    if numeric:
        M = nice_step(max(abs(min(numeric)), abs(max(numeric))))
        bars.y_axis.scaling.min = -M if min(numeric) < 0 else 0
        bars.y_axis.scaling.max = M
        bars.y_axis.majorUnit = nice_step(M / 3)

    # Avertissement de lisibilite : un solde tres superieur aux flux ecrase
    # les barres sur l'axe unique. C'est le prix assume de l'axe partage.
    stacks = [abs(v) for v in numeric] if numeric else [0]
    bars._readability_warning = None
    if numeric:
        mx_bal = max(abs(ws.cell(row=row_balance, column=first_col + i).value or 0)
                     for i in range(n_periods))
        mx_flow = max((abs(sum((ws.cell(row=r, column=first_col + i).value or 0)
                               for r in rows_flows)) for i in range(n_periods)),
                      default=0)
        if mx_flow and mx_bal / mx_flow > 5:
            bars._readability_warning = (
                f"solde/flux = {mx_bal / mx_flow:.0f}x : les barres seront "
                "petites sur l'axe unique, signaler a l'utilisateur")
    _style_axes(bars, p, cat_low=True, skip=3 if n_periods > 24 else None,
                cat_numfmt=FMT_MONTH)
    bars.display_blanks = "zero"
    bars.title = title
    bars.legend.position = "b"
    bars.legend.overlay = False
    _size(bars, n_periods)
    ws.add_chart(bars, anchor)
    return bars


# ================================================== 2. VOLUME VS REVENUE
def volume_revenue_chart(ws, row_cats, row_amount, row_volume, n_periods,
                         title="Revenue and volume", palette="Yelema",
                         variant="auto", first_col=2, anchor="B30",
                         labels="auto", cat_numfmt=FMT_MONTH, legend="tr"):
    """Serie de montant + serie de volume.

    variant : 'line'      barres pour le montant, COURBE pour le volume sur
                          axe secondaire (lisible quand les ordres de grandeur
                          different) ;
              'clustered' deux series de barres sur un seul axe ;
              'auto'      choisit 'line' des que max(montant)/max(volume) > 20.
    """
    p = PALETTES[palette]
    last = first_col + n_periods - 1

    def _vals(r):
        out = []
        for i in range(n_periods):
            v = ws.cell(row=r, column=first_col + i).value
            if isinstance(v, (int, float)):
                out.append(abs(v))
        return out or [0]

    if variant == "auto":
        a, v = max(_vals(row_amount)), max(_vals(row_volume))
        variant = "line" if (v == 0 or a / max(v, 1e-9) > 20) else "clustered"

    cats = Reference(ws, min_col=first_col, max_col=last,
                     min_row=row_cats, max_row=row_cats)
    bars = BarChart()
    bars.type, bars.grouping, bars.style = "col", "clustered", 2
    bars.gapWidth = 80 if n_periods <= 6 else 60
    bars.add_data(Reference(ws, min_col=1, max_col=last,
                            min_row=row_amount, max_row=row_amount),
                  titles_from_data=True, from_rows=True)
    bars.series[0].graphicalProperties = GraphicalProperties(solidFill=p["amount"])
    # Regle de lisibilite des etiquettes : au-dela de 13 periodes elles se
    # chevauchent quoi qu'on fasse ; entre 7 et 13 on ne garde que le montant.
    if labels == "auto":
        lab_amount, lab_volume = n_periods <= 13, n_periods <= 6
    else:
        lab_amount = lab_volume = bool(labels)
    if lab_amount:
        # Series proportionnelles : la courbe passe au sommet des barres et les
        # deux etiquettes se superposent. On rentre alors celle du montant.
        amt, vol = _vals(row_amount), _vals(row_volume)
        prop = (len(amt) == len(vol) and len(amt) > 1
                and _correl(amt, vol) > 0.98)
        pos, colr = ("inEnd", "FFFFFF") if (prop and lab_volume) else ("outEnd", p["amount"])
        data_labels(bars.series[0], colr,
                    size=900 if n_periods <= 6 else 800, pos=pos)
    bars.set_categories(cats)

    vol_ref = Reference(ws, min_col=1, max_col=last,
                        min_row=row_volume, max_row=row_volume)
    if variant == "line":
        line = LineChart()
        line.add_data(vol_ref, titles_from_data=True, from_rows=True)
        s = line.series[0]
        s.graphicalProperties = GraphicalProperties()
        s.graphicalProperties.line = LineProperties(solidFill=p["volume"],
                                                    w=int(2.25 * EMU_PT))
        s.smooth = False
        s.marker.symbol = "none"
        if lab_volume:
            data_labels(s, p["volume"],
                        size=900 if n_periods <= 6 else 800, pos="t")
        line.y_axis.axId = 200
        line.y_axis.majorGridlines = None
        line.y_axis.numFmt = FMT_INT
        line.y_axis.delete = False
        line.y_axis.txPr = _txpr(900, p["axis"])
        line.y_axis.crosses = "max"      # sur l'axe SECONDAIRE, jamais le primaire
        # Excel attend un axe de categories propre a l'axe secondaire ; sans lui
        # un second axe de categories parasite s'affiche en haut du graphique.
        line.x_axis.axId = 20
        line.x_axis.delete = True
        bars += line
    else:
        bars.add_data(vol_ref, titles_from_data=True, from_rows=True)
        bars.series[1].graphicalProperties = GraphicalProperties(solidFill=p["volume"])
        if lab_volume:
            data_labels(bars.series[1], p["volume"],
                        size=900 if n_periods <= 6 else 800, pos="outEnd")

    _style_axes(bars, p, cat_numfmt=cat_numfmt,
                skip=3 if n_periods > 24 else None)
    bars.display_blanks = "zero"
    bars.title = title
    bars.legend.position = legend
    bars.legend.overlay = False
    _size(bars, max(n_periods, 12), min_pt=560, max_pt=760)
    ws.add_chart(bars, anchor)
    return bars, variant


# ---------------------------------------------------------------- controles
def check_cashflow_block(ws, rows_flows, row_balance, n_periods, first_col=2,
                         tol=0.5):
    """Somme des blocs empiles = variation du solde, periode par periode.
    Retourne la liste des periodes en ecart (vide = conforme). A executer sur
    un classeur RECALCULE (les formules doivent avoir une valeur)."""
    bad = []
    for i in range(1, n_periods):
        flows = sum((ws.cell(row=r, column=first_col + i).value or 0)
                    for r in rows_flows)
        b1 = ws.cell(row=row_balance, column=first_col + i).value or 0
        b0 = ws.cell(row=row_balance, column=first_col + i - 1).value or 0
        if not isinstance(flows, (int, float)):
            continue
        if abs(flows - (b1 - b0)) > tol:
            bad.append((i, flows, b1 - b0))
    return bad


# ---------------------------------------------------------------- onglet
def setup_dashboard(ws, title="DASHBOARD", n_periods=36):
    """Cartouche, largeurs et mise en page de l'onglet DASHBOARD.
    Le paysage + ajustement a la largeur rend l'export PDF lisible : sans lui
    les graphiques sont coupes en deux a l'impression."""
    ws["C1"] = "BUSINESS PLAN"
    ws["C1"].font = Font(bold=True, size=14)
    ws["C2"] = title
    ws["C2"].font = Font(bold=True, size=16)
    ws.column_dimensions["A"].width = 34
    for i in range(n_periods):
        ws.column_dimensions[get_column_letter(2 + i)].width = 11
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    return ws


def next_anchor(chart, current_row, col="B", pad=3):
    """Ligne d'ancrage du graphique suivant, deduite de la hauteur du
    precedent (une ligne standard fait environ 0,5 cm)."""
    return f"{col}{int(current_row + chart.height / 0.5 + pad)}"
