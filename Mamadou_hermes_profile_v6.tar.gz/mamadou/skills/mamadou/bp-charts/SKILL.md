---
name: "bp-charts"
version: "1.0.0"
description: "Ajoute un onglet DASHBOARD avec 3 graphiques Excel natifs à un BP existant, branchés en formules sur les onglets de calcul."
maj: 2026-09-03
---

# Graphiques d'un BP — générateur

## Ce que produit ce skill

Un onglet `DASHBOARD` ajouté à un classeur de BP existant, portant trois graphiques Excel natifs et, sous eux, les blocs de données qui les alimentent. Les graphiques sont vivants : changer un input bleu dans les onglets amont les met à jour.

Trois principes gouvernent tout :

- **Un graphique ne lit jamais directement un onglet de calcul.** Il lit un bloc de données intermédiaire posé sur le DASHBOARD, dont chaque cellule est une référence simple vers l'onglet source. Ce bloc isole le graphique de la mise en page des onglets de calcul : re-pointer un graphe après une insertion de ligne, c'est corriger trois formules, pas reconstruire un graphique.
- **Les lignes sources se repèrent par libellé, jamais par numéro de ligne.** Un BP vit, les lignes bougent. Chercher "Operating cash-flow" en colonne A et en déduire le numéro de ligne ; ne jamais écrire un numéro en dur dans le code de génération.
- **Un graphique faux est plus dangereux qu'une absence de graphique**, parce qu'il ne déclenche aucune erreur. D'où le contrôle de cohérence obligatoire avant de tracer, et le fait que les blocs de données restent visibles sous le dashboard.

## Workflow obligatoire

1. **Inventorier le classeur.** Repérer les onglets `Cashflow_Monthly`, `P&L_Monthly` et `P&L_Yearly` (ou leurs équivalents). Sans onglet de flux de trésorerie, le premier graphique n'a pas de source : proposer d'abord `bp-pl-cashflow-tabs`.
2. **Localiser les lignes sources par libellé** (voir `references/reperage-sources.md`). Relever les numéros de ligne trouvés et les afficher à l'utilisateur en fin de génération : c'est ce qui rend le câblage auditable.
3. **Exécuter le contrôle de cohérence** du graphe de trésorerie, sur un classeur recalculé, AVANT de tracer quoi que ce soit. S'il échoue, la sélection de lignes est fausse : corriger, ne pas tracer.
4. **Lire les fiches** dans `references/` : `bloc-donnees.md`, puis `graphe-cashflow.md`, puis `graphe-volume-revenue.md`.
5. **Construire avec `scripts/chart_helpers.py`.** Les pièges d'openpyxl y sont déjà résolus ; les reproduire à la main coûte une demi-journée et se voit à l'écran.
6. **Vérifier le rendu** : exporter le classeur en PDF (LibreOffice headless) et regarder les images. Un graphique ne se valide pas en lisant du XML.
7. **Exécuter les contrôles** de `references/controles.md` avant livraison.

## Les trois graphiques

| Graphique | Type | Source | Horizon |
|---|---|---|---|
| Flux de trésorerie mensuels et solde | Barres empilées + courbe, **axe unique symétrique** | `Cashflow_Monthly` | tout l'horizon (36 mois) |
| Revenu et volume, mois 1 à 13 | Barres (montant) + courbe (volume) sur axe secondaire, ou barres groupées | `P&L_Monthly` | colonnes D à P |
| Revenu et volume, Year 1 à Year 3 | Idem | `P&L_Yearly` | colonnes C à E |

Le premier répond à "quand la trésorerie casse et de combien faut-il lever". Les deux autres répondent à "à quelle vitesse ça croît, et est-ce le volume ou le prix qui porte la croissance". Ce sont les deux seules questions qu'un comité pose devant un BP.

## Conventions par défaut (appliquer sans redemander)

- **Onglet dédié `DASHBOARD`**, créé s'il n'existe pas. Les graphiques en haut, les blocs de données en dessous, séparés par des lignes vides. Quadrillage masqué, mise en page paysage et ajustée à la largeur : sans cela l'export PDF coupe les graphiques en deux.
- **Horizon du graphe mensuel volume/revenu : les mois 1 à 13**, soit les colonnes D à P de la grille du BP (12 mois de Year 1 plus le premier mois de Year 2). Le treizième mois donne le premier point de comparaison d'une année sur l'autre.
- **Palette Yelema** : Deep Navy `#03045E` pour le montant, Bright Cyan `#00B4D8` pour le volume, Teal `#38B6AB` / Gold `#FDC067` / Deep Blue `#0077B6` pour les blocs de flux, Deep Navy pour la courbe de solde. La palette d'origine de la fiche de référence du graphe de trésorerie (vert `#92D050`, ambre `#FFC000`, bleu clair `#8EA9DB`, navy `#002060`) reste disponible sous `palette="reference"` : le préciser si l'utilisateur veut retrouver exactement le rendu de ses BP antérieurs.
- **Nombre de périodes lu dynamiquement**, jamais figé. Un BP à 48 mois doit produire un graphique à 48 colonnes sans toucher au code.
- **Cellules du bloc de données en police verte** (convention de lien inter-onglets de la chaîne BP), en-tête `Données graphique` en Arial 10 gras gris `#808080`.
- **Aucune valeur en dur** dans les blocs de données : une seule formule tirée vers la droite par ligne.
- **Anonymat** : ne jamais mentionner dans le classeur généré les entreprises dont les BP ont servi de référence.

## Choix de la forme du graphe volume contre revenu

Les deux captures fournies par l'utilisateur montrent deux formes, et elles ne sont pas interchangeables : c'est l'écart d'échelle entre les deux séries qui tranche.

```
ratio = max(|montant|) / max(|volume|)
├─ ratio > 20   → barres pour le montant, COURBE pour le volume sur axe
│                 secondaire. Sans cela la petite série est écrasée à zéro.
└─ ratio <= 20  → deux séries de barres groupées sur un axe unique.
                  Plus simple à lire quand les ordres de grandeur sont proches.
```

Le helper applique cette règle sous `variant="auto"`. L'utilisateur peut forcer `"line"` ou `"clustered"` ; dans ce cas, si le ratio contredit le choix, le signaler sans le corriger d'office.

## Corrections structurelles appliquées par défaut

1. **Contrôle de cohérence avant tracé.** Pour chaque période, somme des blocs empilés égale solde de clôture moins solde d'ouverture. Un écart signifie que la sélection de lignes mélange un sous-total et ses composantes, ou saute un bloc.
2. **Jamais un sous-total empilé avec ses composantes.** C'est le double comptage le plus fréquent, et il est invisible sur le graphe.
3. **Axe des valeurs calculé, jamais recopié** : symétrique autour de zéro dès qu'une période est négative, borne arrondie au multiple propre supérieur, unité principale au tiers.
4. **Étiquettes de l'axe des catégories positionnées en bas** sur le graphe de trésorerie : dès que des barres descendent sous zéro, des étiquettes centrées se retrouvent au milieu du graphique.
5. **Étiquettes de données réduites à la valeur seule.** Les moteurs de rendu affichent "Catégorie ; Série ; Valeur" tant que les autres indicateurs ne sont pas explicitement désactivés.
6. **Densité d'étiquettes plafonnée** : les deux séries étiquetées jusqu'à 6 périodes, le montant seul jusqu'à 13, aucune au-delà. Au-delà de 13 points elles se chevauchent quel que soit le placement.
7. **Cellules vides traitées comme zéro**, sinon la courbe de solde se coupe sur les mois sans flux.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/reperage-sources.md` | Toujours, en premier — repérage par libellé et contrôle de cohérence |
| `references/bloc-donnees.md` | Toujours — structure et formules du bloc intermédiaire |
| `references/graphe-cashflow.md` | Graphe de trésorerie combiné |
| `references/graphe-volume-revenue.md` | Graphes mensuel 13 mois et annuel 3 ans |
| `references/controles.md` | Toujours, avant de livrer |
| `scripts/chart_helpers.py` | Palettes, blocs de données, constructeurs des trois graphiques, contrôles |
