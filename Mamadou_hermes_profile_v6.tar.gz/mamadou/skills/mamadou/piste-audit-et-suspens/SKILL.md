---
id: Y0659
name: piste-audit-et-suspens
version: 1.0.0
description: "Constitue et tient la trace de chaque réconciliation : dossier archivé avec les extraits d'origine et leur empreinte, la configuration appliquée, chaque appariement et sa confiance, les arbitrages non tranchés, l'équation de bouclage, et les validations humaines obtenues. Tient le registre des suspens avec leur date d'apparition, les reporte d'une période à l'autre, et fait remonter ceux qui franchissent le seuil d'ancienneté."
bucket: B
tags: [Finance, Contrôle, Conformité, Nouveau]
maj: 2026-09-03
---

# La piste d'audit et le registre des suspens

## Pourquoi cette compétence existe

Parce que le bénéfice économique du dispositif en dépend entièrement.

Une comptabilité qui rapproche elle-même est obligée de saisir chaque transaction unitairement —
sinon elle ne pourrait plus retrouver l'origine d'un écart. Elle peut passer à des mouvements
agrégés **à une seule condition** : qu'en cas d'écart, la trace du rapprochement permette de
remonter au détail sans elle.

> Si cette trace est faible, l'agrégation est une catastrophe : on aura perdu le détail sans
> avoir gagné la preuve.

## Ce que contient un dossier de rapprochement

`rapprochements/<compte>/<AAAA-MM>/`

| Fichier | Contenu | Pourquoi il est indispensable |
|---|---|---|
| `config.json` | tolérances, fenêtre, clés, mapping de colonnes | une tolérance change le résultat ; sans elle, l'état n'est pas rejouable |
| `entrees/` | les extraits **tels qu'ils ont été reçus** | pour prouver qu'on a rapproché ces données-là, et pas une version retravaillée |
| `etat-de-rapprochement.md` | l'état remis | |
| `suspens.json` | la photo arrêtée des suspens | elle ne bouge plus après l'arrêté |
| `piste-audit.json` | empreintes, appariements, arbitrages, bouclage | le cœur de la preuve |
| `validations.md` | qui a validé quoi, quand | pour savoir qui a porté le risque |

**Rien n'est jamais écrasé.** Une reprise est un nouveau dossier `_v2`.

## L'empreinte des extraits — et pourquoi c'est plus qu'un détail technique

Chaque extrait entrant est empreinté. Ce que ça permet, concrètement : établir, trois mois plus
tard, si l'écart vient du rapprochement ou d'un extrait qui a changé entre-temps.

Sans empreinte, un extrait retiré à nouveau et différent du premier — cela arrive, notamment
après une migration de plateforme bancaire — rend le débat insoluble : chacun a un fichier, et
personne ne peut prouver lequel a servi.

## Le registre des suspens

`memory/state/suspens/<compte>.json`. Un suspens porte :

```json
{
  "empreinte": "identifiant stable, calculé sur la ligne",
  "source": "releve | livres",
  "date_operation": "AAAA-MM-JJ",
  "montant": "…",
  "libelle": "…",
  "nature": "chèque non présenté | frais non enregistrés | …",
  "apparu_le": "AAAA-MM-JJ  ← ne change JAMAIS",
  "anciennete_jours": 0,
  "reporte": false,
  "commentaire": "",
  "responsable": "",
  "resolution_attendue": ""
}
```

**`apparu_le` est le champ le plus important du dispositif et le plus facile à casser.** S'il est
réécrit à chaque période, l'ancienneté repart à zéro, un écart vieux de huit mois a l'air neuf,
et le seul indicateur qui distingue une opération en transit d'une anomalie disparaît — sans
qu'aucune alerte ne se déclenche, puisque tout a l'air normal.

## Le vieillissement

Trois tranches, dont les bornes se conviennent avec le client et **se relèvent dans la
configuration, jamais de mémoire** :

- **En transit** — récent, comportement attendu, aucune action.
- **À surveiller** — au-delà du délai normal du canal, il faut une explication.
- **Anomalie** — au-delà du seuil convenu : ce n'est plus une opération en transit. Il lui faut
  un nom, une cause et une date de résolution attendue, et il remonte nommément.

Ce que révèle chaque tranche haute : un chèque émis très ancien peut avoir été perdu ou jamais
encaissé. Un virement attendu qui ne vient jamais est une opération qui n'aura pas lieu et qui
doit être annulée dans les livres. Une opération qui réapparaît à l'identique chaque mois est un
doublon d'enregistrement, pas un retard.

## Le registre des validations

Chaque mise à jour proposée suit un cycle : **proposée → validée ou refusée → portée →
constatée à la période suivante**.

Une mise à jour proposée et jamais tranchée est un point d'attention, pas un oubli à taire : au
bout d'une période, elle remonte. Une mise à jour validée mais jamais portée est pire — le
dispositif croit l'écart résolu, l'écart persiste, et il réapparaîtra sous une forme qu'on ne
reconnaîtra pas.

## Garde-fous

- **`apparu_le` ne se réécrit jamais.**
- **Un extrait remplacé après coup ne se substitue pas** au fichier archivé : il fait l'objet
  d'une reprise `_v2` documentée.
- **Aucun chemin de fichier interne dans le document remis au client.** La piste d'audit lui est
  résumée en termes de sources et de dates ; les fichiers, c'est ta plomberie.
- **Le journal se tient même quand le rapprochement boucle.** C'est justement quand tout va bien
  qu'on cesse d'archiver, et c'est le mois d'après qu'on en a besoin.
