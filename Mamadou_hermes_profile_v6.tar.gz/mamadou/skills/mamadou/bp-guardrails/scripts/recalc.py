#!/usr/bin/env python3
"""Recalcul d'un classeur .xlsx en formules -> valeurs, par cascade de backends.

Raison d'etre : un classeur genere par openpyxl ne contient AUCUNE valeur en
cache. `openpyxl.load_workbook(data_only=True)` y renvoie None partout. Un
controleur qui lit ce vide ne voit aucune anomalie et conclut a tort que tout
va bien. C'est le mode de defaillance le plus dangereux de la chaine BP :
le faux vert.

Regle absolue appliquee ici : si aucun backend ne recalcule, la fonction LEVE
une exception. Elle ne renvoie jamais un classeur non recalcule en faisant
comme si de rien n'etait.

Backends, essayes dans l'ordre :
  1. cache      - le fichier porte deja des valeurs (sauve par Excel/LibreOffice)
  2. libreoffice- soffice --headless --convert-to xlsx (recalcule a la conversion)
  3. gsheets    - upload Google Sheets via le CLI `gog`, lecture, suppression
Chacun est optionnel. Le skill reste transposable : il s'adapte a ce que
l'environnement offre, et le dit explicitement.
"""
import os, re, json, shutil, subprocess, tempfile

MONTH_COLS_DEFAULT = 36


class RecalcError(RuntimeError):
    """Aucun backend n'a pu recalculer. Ne jamais rattraper en silence."""


# --------------------------------------------------------------------------
# detection
# --------------------------------------------------------------------------
# Chemins connus d'une install LibreOffice locale (sans sudo/apt), a defaut
# de PATH modifiable dans certains environnements sandboxes. Surchargeable
# via la variable d'environnement BPGR_SOFFICE.
_SOFFICE_FALLBACKS = [
    os.path.expanduser("~/tools/bin/soffice"),
    os.path.expanduser("~/tools/libreoffice-local/opt/libreoffice26.2/program/soffice.bin"),
    "/opt/libreoffice26.2/program/soffice",
]


def _has_soffice():
    env = os.environ.get("BPGR_SOFFICE")
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env
    found = shutil.which("soffice") or shutil.which("libreoffice")
    if found:
        return found
    for p in _SOFFICE_FALLBACKS:
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def _has_gog():
    return shutil.which("gog") is not None


def available_backends():
    b = ["cache"]
    if _has_soffice():
        b.append("libreoffice")
    if _has_gog():
        b.append("gsheets")
    return b


# --------------------------------------------------------------------------
# backend 1 : valeurs deja en cache
# --------------------------------------------------------------------------
def _try_cache(path, probe_sheets=None, min_probe=20, ratio_ok=0.9):
    """Le cache n'est valide que si les cellules QUI SONT DES FORMULES portent
    une valeur.

    Piege (rencontre en construisant ce skill) : compter les cellules numeriques
    en general ne prouve rien. Un classeur genere par openpyxl contient
    quantite de constantes (les inputs saisis), qui portent evidemment une
    valeur, alors qu'AUCUNE formule n'est evaluee. Un detecteur naif y conclut
    "cache present" puis lit du vide partout : c'est precisement le faux vert
    que ce module existe pour empecher. On echantillonne donc des cellules de
    formule et on verifie qu'elles ont une valeur en face.
    """
    import openpyxl
    wbf = openpyxl.load_workbook(path, data_only=False)
    wbv = openpyxl.load_workbook(path, data_only=True)
    seen = filled = 0
    for ws in wbf.worksheets:
        if probe_sheets and ws.title not in probe_sheets:
            continue
        wsv = wbv[ws.title]
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 200)):
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("="):
                    seen += 1
                    if wsv.cell(c.row, c.column).value is not None:
                        filled += 1
                    if seen >= 400:
                        break
            if seen >= 400:
                break
        if seen >= 400:
            break
    if seen == 0:
        # aucun formule : classeur de valeurs pures, rien a recalculer
        return wbv
    if seen >= min_probe and filled / seen >= ratio_ok:
        return wbv
    return None


# --------------------------------------------------------------------------
# backend 2 : LibreOffice headless
# --------------------------------------------------------------------------
def _try_libreoffice(path, timeout=300):
    exe = _has_soffice()
    if not exe:
        return None, "soffice absent"
    outdir = tempfile.mkdtemp(prefix="bpgr_lo_")
    profile = os.path.join(outdir, "profile")
    cmd = [
        exe, "--headless", "--norestore",
        f"-env:UserInstallation=file://{profile}",
        "--convert-to", "xlsx", "--outdir", outdir, os.path.abspath(path),
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, "timeout LibreOffice"
    produced = os.path.join(outdir, os.path.splitext(os.path.basename(path))[0] + ".xlsx")
    if not os.path.exists(produced):
        msg = (r.stdout or "") + (r.stderr or "")
        return None, "conversion echouee: " + msg.strip()[:200]
    import openpyxl
    return openpyxl.load_workbook(produced, data_only=True), None


# --------------------------------------------------------------------------
# backend 3 : Google Sheets via le CLI gog
# --------------------------------------------------------------------------
def _sh(cmd, timeout=300):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)


def _try_gsheets(path, account=None, env_prelude=". ~/.config/agents/secrets.env;"):
    if not _has_gog():
        return None, "gog absent"
    account = account or os.environ.get("BPGR_GOG_ACCOUNT", "")
    acc = f"--account {account}" if account else ""
    name = "ZZ_bpgr_" + re.sub(r"[^A-Za-z0-9]", "", os.path.basename(path))[:26] + "_DELETE"
    up = _sh(f"{env_prelude} gog drive upload '{path}' --convert-to sheet "
             f"--name '{name}' {acc} -j 2>/dev/null")
    try:
        sid = json.loads(up.stdout)["file"]["id"]
    except Exception:
        return None, "upload echoue: " + (up.stdout or up.stderr)[:200]

    class _GSheet:
        """Expose la meme surface que ce dont le checker a besoin."""
        def __init__(self, sid, acc, prelude):
            self.sid, self.acc, self.prelude = sid, acc, prelude
            self._cache = {}
            self.sheetnames = self._sheetnames()

        def _get(self, rng, render="UNFORMATTED_VALUE"):
            key = (rng, render)
            if key in self._cache:
                return self._cache[key]
            r = _sh(f"{self.prelude} gog sheets get '{self.sid}' \"{rng}\" {self.acc} "
                    f"--render {render} -j 2>/dev/null")
            try:
                d = json.loads(r.stdout)
                v = d.get("values") or d.get("result", {}).get("values") or []
            except Exception:
                v = []
            self._cache[key] = v
            return v

        def _sheetnames(self):
            r = _sh(f"{self.prelude} gog sheets info '{self.sid}' {self.acc} -j 2>/dev/null")
            try:
                d = json.loads(r.stdout)
                sh = d.get("sheets") or d.get("result", {}).get("sheets") or []
                out = []
                for s in sh:
                    t = (s.get("properties") or {}).get("title") or s.get("title")
                    if t:
                        out.append(t)
                if out:
                    return out
            except Exception:
                pass
            return []

        def grid(self, sheet, last_col="AM", last_row=220):
            return self._get(f"'{sheet}'!A1:{last_col}{last_row}")

        def grid_formatted(self, sheet, last_col="AM", last_row=220):
            return self._get(f"'{sheet}'!A1:{last_col}{last_row}", render="FORMATTED_VALUE")

        def close(self):
            _sh(f"{self.prelude} gog drive delete '{self.sid}' --permanent -y {self.acc} 2>/dev/null")

    return _GSheet(sid, acc, env_prelude), None


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
class Recalculated:
    """Vue uniforme sur un classeur recalcule, quel que soit le backend.

    .grid(sheet) -> liste de listes (valeurs), indices 0-based, A1 en [0][0]
    .backend     -> nom du backend qui a effectivement recalcule
    """
    def __init__(self, backend, wb=None, gs=None, source_path=None):
        self.backend, self._wb, self._gs = backend, wb, gs
        self.source_path = source_path
        self.sheetnames = gs.sheetnames if gs is not None else wb.sheetnames

    def grid(self, sheet, last_col="AM", last_row=220):
        if self._gs is not None:
            return self._gs.grid(sheet, last_col, last_row)
        import openpyxl.utils as u
        ws = self._wb[sheet]
        maxc = u.column_index_from_string(last_col)
        out = []
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, last_row),
                                min_col=1, max_col=maxc):
            out.append([c.value for c in row])
        return out

    def grid_formatted(self, sheet, last_col="AM", last_row=220):
        if self._gs is not None:
            return self._gs.grid_formatted(sheet, last_col, last_row)
        return self.grid(sheet, last_col, last_row)

    def close(self):
        if self._gs is not None:
            self._gs.close()


def recalc(path, prefer=None, account=None):
    """Recalcule `path`. Leve RecalcError si aucun backend ne fonctionne.

    prefer : liste ordonnee de backends a essayer (defaut : cache, libreoffice, gsheets)
    """
    order = prefer or ["cache", "libreoffice", "gsheets"]
    tried = []
    for b in order:
        if b == "cache":
            wb = _try_cache(path)
            if wb is not None:
                return Recalculated("cache", wb=wb, source_path=path)
            tried.append("cache: aucune valeur en cache (classeur genere, jamais ouvert)")
        elif b == "libreoffice":
            wb, err = _try_libreoffice(path)
            if wb is not None:
                return Recalculated("libreoffice", wb=wb, source_path=path)
            tried.append("libreoffice: " + (err or "indisponible"))
        elif b == "gsheets":
            gs, err = _try_gsheets(path, account=account)
            if gs is not None:
                return Recalculated("gsheets", gs=gs, source_path=path)
            tried.append("gsheets: " + (err or "indisponible"))
    raise RecalcError(
        "Aucun backend n'a pu recalculer le classeur. Le controle ne peut PAS "
        "conclure : un classeur non recalcule ne porte aucune valeur, et l'absence "
        "d'anomalie detectee ne signifie alors rien.\nBackends essayes :\n  - "
        + "\n  - ".join(tried)
        + "\nRemedes : installer LibreOffice, ou ouvrir puis sauver le classeur dans "
          "Excel avant de relancer, ou fournir un CLI `gog` authentifie."
    )


if __name__ == "__main__":
    import sys
    p = sys.argv[1]
    print("backends disponibles :", available_backends())
    r = recalc(p)
    print("recalcule par :", r.backend)
    print("onglets :", r.sheetnames)
    r.close()
