#!/usr/bin/env python3
"""Controle de conformite d'un BP : integrite du classeur + garde-fous Yelema.

Usage :
  python3 check_guardrails.py <modele.xlsx> [--config seuils.json] [--json]
  python3 check_guardrails.py <modele.xlsx> --seed 400000   # levee visee 400k

Deux niveaux, dans cet ordre. Le second n'a aucun sens si le premier echoue :
  A. INTEGRITE  - erreurs de formule, lignes CTRL du modele, articulation du cash
  B. GARDE-FOUS - la forme Yelema attendue d'un BP pre-seed

Sortie : verdict par gate (OK / ALERTE / ECHEC / NON EVALUE) + verdict global.
Un gate non evaluable est NON EVALUE, jamais OK.
"""
import sys, os, json, re, unicodedata, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from recalc import recalc, RecalcError, available_backends  # noqa: E402

# ---------------------------------------------------------------- seuils
DEFAULTS = {
    "horizon_months": 36,
    "mrr_m12_min": 30000,
    "mrr_m12_max": 50000,
    "growth_y2_target": 3.0,          # CA Y2 = 3 x CA Y1   (regle Yelema, la direction financière 29/07)
    "growth_y3_target": 2.0,          # CA Y3 = 2 x CA Y2
    "growth_tolerance": 0.25,         # +/- 25% autour de la cible
    "seed_amount": 250000,
    "runway_months_min": 11,
    "runway_months_max": 15,
    "trough_min": 300000,
    "trough_max": 700000,
    "trough_month_min": 12,
    "trough_month_max": 18,
    "jcurve_recovery_min": 6,         # mois apres le creux ou le cash doit remonter
    "jcurve_recovery_max": 9,
    "currency": "EUR",
}

ERRS = ("#REF!", "#DIV/0!", "#N/A", "#VALUE!", "#NAME?", "#NUM!", "#NULL!", "#ERROR!", "#CYCLE!")

OK, ALERT, FAIL, NA = "OK", "ALERTE", "ECHEC", "NON EVALUE"


# ---------------------------------------------------------------- utilitaires
def _norm(s):
    if not isinstance(s, str):
        return ""
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", s).strip().lower()


def _num(x):
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        t = x.strip().replace(" ", "").replace("\xa0", "").replace(" ", "")
        neg = t.startswith("(") and t.endswith(")")
        t = t.strip("()").replace("€", "").replace("%", "")
        t = t.replace(",", ".") if t.count(",") == 1 and t.count(".") == 0 else t.replace(",", "")
        try:
            v = float(t)
            return -v if neg else v
        except ValueError:
            return None
    return None


def find_sheet(names, *cands):
    for c in cands:
        for n in names:
            if _norm(n) == _norm(c):
                return n
    for c in cands:
        for n in names:
            if _norm(c) in _norm(n):
                return n
    return None


def find_row(grid, *labels, exact_first=True):
    """Retourne (index_0based, libelle) de la premiere ligne dont la colonne A
    correspond. Les lignes CTRL sont ignorees : elles CONTIENNENT souvent le
    mot cherche (ex 'CTRL 5 - Articulation (closing - opening ...)') et sont le
    piege classique du reperage par sous-chaine."""
    cand = [_norm(l) for l in labels]
    rows = []
    for i, row in enumerate(grid):
        a = row[0] if row else None
        na = _norm(a)
        if not na or re.match(r"^(ctrl|check|controle)\b", na):
            continue
        rows.append((i, na, a))
    if exact_first:
        for i, na, a in rows:
            if na in cand:
                return i, a
    for i, na, a in rows:
        for c in cand:
            if na.startswith(c):
                return i, a
    for i, na, a in rows:
        for c in cand:
            if c in na:
                return i, a
    return None, None


def series(grid, ridx, first_col_idx, n):
    if ridx is None or ridx >= len(grid):
        return []
    row = grid[ridx]
    out = []
    for k in range(n):
        ci = first_col_idx + k
        out.append(_num(row[ci]) if ci < len(row) else None)
    return out


def detect_month_start(grid, n_months):
    """La grille standard de la chaine BP met Year 0 en C et les mois en D:AM.
    On verifie sur une ligne dense ; a defaut on retombe sur D (index 3)."""
    best, best_count = 3, -1
    for start in (3, 2):
        count = 0
        for row in grid[:120]:
            vals = [(_num(row[c]) if c < len(row) else None) for c in range(start, start + n_months)]
            filled = sum(1 for v in vals if v is not None)
            if filled >= n_months * 0.8:
                count += 1
        if count > best_count:
            best, best_count = start, count
    return best


# ---------------------------------------------------------------- A. integrite
def check_integrity(rc, cfg):
    res = []
    # A1 : erreurs de formule
    per_sheet, total = {}, 0
    for s in rc.sheetnames:
        g = rc.grid_formatted(s)
        n = 0
        for row in g:
            for v in row:
                if isinstance(v, str) and any(e in v for e in ERRS):
                    n += 1
        per_sheet[s] = n
        total += n
    res.append({
        "id": "A1", "nom": "Aucune erreur de formule",
        "statut": OK if total == 0 else FAIL,
        "detail": (f"0 erreur sur {len(rc.sheetnames)} onglets" if total == 0
                   else f"{total} cellules en erreur : "
                        + ", ".join(f"{k}={v}" for k, v in per_sheet.items() if v)),
    })

    # A2 : lignes CTRL portees par le modele
    ctrl_total, ctrl_fail, worst = 0, 0, []
    for s in rc.sheetnames:
        g = rc.grid(s)
        for i, row in enumerate(g):
            a = row[0] if row else None
            if not isinstance(a, str) or not re.match(r"^(ctrl|check)\b", _norm(a)):
                continue
            nums = [v for v in (_num(x) for x in row[2:]) if v is not None]
            if not nums:
                continue
            ctrl_total += 1
            m = max(abs(v) for v in nums)
            if m > 1.0:
                ctrl_fail += 1
                worst.append(f"{s}!L{i+1} {str(a)[:44]} (max {m:,.2f})")
    if ctrl_total == 0:
        res.append({"id": "A2", "nom": "Controles internes du modele", "statut": NA,
                    "detail": "le classeur ne porte aucune ligne CTRL"})
    else:
        res.append({
            "id": "A2", "nom": "Controles internes du modele",
            "statut": OK if ctrl_fail == 0 else FAIL,
            "detail": (f"{ctrl_total} controles, tous a zero" if ctrl_fail == 0
                       else f"{ctrl_fail}/{ctrl_total} en echec : " + " | ".join(worst[:5])),
        })
    return res


# ---------------------------------------------------------------- lecture metier
def read_model(rc, cfg):
    """Extrait les series dont les garde-fous ont besoin. Renvoie un dict avec
    la provenance de chaque grandeur (pour restitution)."""
    n = cfg["horizon_months"]
    names = rc.sheetnames
    out = {"sources": {}, "n": n}

    s_plm = find_sheet(names, "P&L_Monthly", "PL_Monthly", "P&L Monthly", "Compte de resultat mensuel")
    s_ply = find_sheet(names, "P&L_Yearly", "PL_Yearly", "P&L Yearly")
    s_cfm = find_sheet(names, "Cashflow_Monthly", "Cash-flow_Monthly", "Tresorerie mensuelle")

    # --- revenu mensuel
    if s_plm:
        g = rc.grid(s_plm)
        c0 = detect_month_start(g, n)
        r, lab = find_row(g, "total revenues", "total revenue", "chiffre d'affaires",
                          "total des revenus", "revenus totaux", "net revenue", "gross revenues")
        if r is not None:
            out["rev_monthly"] = series(g, r, c0, n)
            out["sources"]["revenu mensuel"] = f"{s_plm}!L{r+1} ({lab})"
        # EBITDA mensuel (pour le runway operationnel)
        r2, lab2 = find_row(g, "ebitda")
        if r2 is not None:
            out["ebitda_monthly"] = series(g, r2, c0, n)
            out["sources"]["EBITDA mensuel"] = f"{s_plm}!L{r2+1} ({lab2})"
        # OpEx mensuel
        r3, lab3 = find_row(g, "total opex", "total operating expenses", "total charges d'exploitation")
        if r3 is not None:
            out["opex_monthly"] = series(g, r3, c0, n)
            out["sources"]["OpEx mensuel"] = f"{s_plm}!L{r3+1} ({lab3})"

    # --- revenu annuel
    if s_ply:
        gy = rc.grid(s_ply, last_col="H")
        r, lab = find_row(gy, "total revenues", "total revenue", "chiffre d'affaires",
                          "total des revenus", "revenus totaux")
        if r is not None:
            row = gy[r]
            vals = [_num(row[c]) if c < len(row) else None for c in range(2, 6)]
            vals = [v for v in vals if v is not None]
            if len(vals) >= 3:
                out["rev_yearly"] = vals[:3]
                out["sources"]["CA annuel"] = f"{s_ply}!L{r+1} ({lab})"

    # fallback : agreger le mensuel
    if "rev_yearly" not in out and out.get("rev_monthly"):
        m = [v or 0 for v in out["rev_monthly"]]
        if len(m) >= 36:
            out["rev_yearly"] = [sum(m[0:12]), sum(m[12:24]), sum(m[24:36])]
            out["sources"]["CA annuel"] = "agrege depuis le revenu mensuel"

    # --- tresorerie
    if s_cfm:
        g = rc.grid(s_cfm)
        c0 = detect_month_start(g, n)
        r, lab = find_row(g, "closing balance", "solde de cloture", "solde final",
                          "closing cash", "tresorerie de cloture")
        if r is not None:
            out["cash_closing"] = series(g, r, c0, n)
            out["sources"]["solde de tresorerie"] = f"{s_cfm}!L{r+1} ({lab})"
        r2, lab2 = find_row(g, "operating cash-flow", "operating cash flow",
                            "flux d'exploitation", "cash-flow operationnel")
        if r2 is not None:
            out["cf_op"] = series(g, r2, c0, n)
            out["sources"]["flux d'exploitation"] = f"{s_cfm}!L{r2+1} ({lab2})"
        r3, lab3 = find_row(g, "investing cash-flow", "investing cash flow",
                            "flux d'investissement", "capex")
        if r3 is not None:
            out["cf_inv"] = series(g, r3, c0, n)
            out["sources"]["flux d'investissement"] = f"{s_cfm}!L{r3+1} ({lab3})"
    return out


# ---------------------------------------------------------------- B. garde-fous
def gate_mrr(model, cfg):
    rev = model.get("rev_monthly")
    if not rev or len(rev) < 12 or rev[11] is None:
        return {"id": "G1", "nom": f"MRR a M12 entre {cfg['mrr_m12_min']:,.0f} et {cfg['mrr_m12_max']:,.0f}",
                "statut": NA, "detail": "revenu mensuel M12 introuvable"}
    v = rev[11]
    lo, hi = cfg["mrr_m12_min"], cfg["mrr_m12_max"]
    st = OK if lo <= v <= hi else ALERT
    pos = "sous" if v < lo else ("au-dessus" if v > hi else "dans")
    return {"id": "G1", "nom": f"MRR a M12 entre {lo:,.0f} et {hi:,.0f}", "statut": st,
            "detail": f"MRR M12 = {v:,.0f} ({pos} la cible seed-ready)", "valeur": v}


def gate_growth(model, cfg):
    ry = model.get("rev_yearly")
    if not ry or len(ry) < 3 or not ry[0]:
        return {"id": "G2", "nom": "Croissance x3 en Y2 puis x2 en Y3", "statut": NA,
                "detail": "CA annuel introuvable"}
    y1, y2, y3 = ry[0], ry[1], ry[2]
    g2 = y2 / y1 if y1 else None
    g3 = y3 / y2 if y2 else None
    t2, t3, tol = cfg["growth_y2_target"], cfg["growth_y3_target"], cfg["growth_tolerance"]
    ok2 = g2 is not None and t2 * (1 - tol) <= g2 <= t2 * (1 + tol)
    ok3 = g3 is not None and t3 * (1 - tol) <= g3 <= t3 * (1 + tol)
    st = OK if (ok2 and ok3) else ALERT
    return {"id": "G2", "nom": f"Croissance x{t2:g} en Y2 puis x{t3:g} en Y3", "statut": st,
            "detail": (f"CA {y1:,.0f} / {y2:,.0f} / {y3:,.0f} -> "
                       f"Y2 x{g2:.2f} ({'ok' if ok2 else 'hors cible'}), "
                       f"Y3 x{g3:.2f} ({'ok' if ok3 else 'hors cible'})"),
            "valeur": {"y1": y1, "y2": y2, "y3": y3, "x_y2": g2, "x_y3": g3}}


def gate_runway(model, cfg):
    """Runway du seed SANS revenu : la levee doit couvrir ~12 mois d'OpEx."""
    opex = model.get("opex_monthly")
    if not opex or not any(v for v in opex[:12] if v):
        return {"id": "G3", "nom": f"{cfg['seed_amount']:,.0f} = ~12 mois de runway (hors revenu)",
                "statut": NA, "detail": "OpEx mensuel introuvable"}
    burn = [abs(v) for v in opex[:12] if v]
    avg = sum(burn) / len(burn)
    months = cfg["seed_amount"] / avg if avg else None
    lo, hi = cfg["runway_months_min"], cfg["runway_months_max"]
    st = OK if (months is not None and lo <= months <= hi) else ALERT
    return {"id": "G3", "nom": f"{cfg['seed_amount']:,.0f} = ~12 mois de runway (hors revenu)",
            "statut": st,
            "detail": (f"OpEx moyen Y1 = {avg:,.0f}/mois -> {months:.1f} mois de runway"
                       if months else "OpEx nul"),
            "valeur": months}


def gate_trough(model, cfg):
    """Creux de cash AVANT financement = cumul (exploitation + investissement)."""
    op, inv = model.get("cf_op"), model.get("cf_inv")
    if not op:
        cash = model.get("cash_closing")
        if not cash or not any(v is not None for v in cash):
            return {"id": "G4", "nom": "Creux de cash 300-700k a M12-18", "statut": NA,
                    "detail": "flux de tresorerie introuvables"}
        vals = [v for v in cash if v is not None]
        tr = min(vals)
        tm = cash.index(tr) + 1
        need = -tr if tr < 0 else 0
        note = "calcule sur le solde de cloture (financement inclus, donc minorant)"
    else:
        cum, path = 0.0, []
        for i in range(len(op)):
            o = op[i] or 0
            v = (inv[i] or 0) if inv and i < len(inv) else 0
            cum += o + v
            path.append(cum)
        tr = min(path)
        tm = path.index(tr) + 1
        need = -tr if tr < 0 else 0
        note = "cumul exploitation + investissement, avant financement"
    lo, hi = cfg["trough_min"], cfg["trough_max"]
    ml, mh = cfg["trough_month_min"], cfg["trough_month_max"]
    depth_ok = lo <= need <= hi
    time_ok = ml <= tm <= mh
    st = OK if (depth_ok and time_ok) else ALERT
    return {"id": "G4", "nom": f"Creux de cash {lo:,.0f}-{hi:,.0f} a M{ml}-{mh}", "statut": st,
            "detail": (f"besoin max {need:,.0f} au mois M{tm} "
                       f"(profondeur {'ok' if depth_ok else 'hors plage'}, "
                       f"timing {'ok' if time_ok else 'hors plage'}) [{note}]"),
            "valeur": {"besoin": need, "mois": tm}}


def gate_jcurve(model, cfg):
    """Apres le creux, le cumul doit repartir a la hausse en 6-9 mois."""
    op, inv = model.get("cf_op"), model.get("cf_inv")
    if not op:
        return {"id": "G5", "nom": "J-curve : redressement 6-9 mois apres le creux",
                "statut": NA, "detail": "flux d'exploitation introuvables"}
    cum, path = 0.0, []
    for i in range(len(op)):
        o = op[i] or 0
        v = (inv[i] or 0) if inv and i < len(inv) else 0
        cum += o + v
        path.append(cum)
    tr = min(path)
    ti = path.index(tr)
    rec = None
    for k in range(ti + 1, len(path)):
        if path[k] > tr:
            rec = k - ti
            break
    lo, hi = cfg["jcurve_recovery_min"], cfg["jcurve_recovery_max"]
    if rec is None:
        return {"id": "G5", "nom": f"J-curve : redressement {lo}-{hi} mois apres le creux",
                "statut": ALERT,
                "detail": f"aucune remontee apres le creux (M{ti+1}) sur l'horizon"}
    # tolerant : une remontee plus rapide n'est pas un defaut
    st = OK if rec <= hi else ALERT
    return {"id": "G5", "nom": f"J-curve : redressement {lo}-{hi} mois apres le creux",
            "statut": st,
            "detail": f"creux M{ti+1}, remontee amorcee {rec} mois apres (M{ti+1+rec})",
            "valeur": rec}


# ---------------------------------------------------------------- coherence des gates
def cross_check(results, model, cfg):
    """Les garde-fous peuvent se contredire selon la taille du modele. Le dire,
    plutot que d'empiler des alertes sans explication."""
    notes = []
    g = {r["id"]: r for r in results}
    ry = model.get("rev_yearly")
    if ry and len(ry) >= 3 and ry[2]:
        gp_proxy = ry[2]
        need = (g.get("G4", {}).get("valeur") or {}).get("besoin")
        if need and gp_proxy and need > gp_proxy * 0.6:
            notes.append(
                "Tension structurelle : le besoin de financement au creux "
                f"({need:,.0f}) est eleve au regard du CA de Y3 ({gp_proxy:,.0f}). "
                "A ce niveau de revenu, un creux de cette profondeur ne peut pas se "
                "resorber sur l'horizon. Soit la levee visee est superieure au seed "
                "de reference, soit le plan de charges est trop lourd pour la trajectoire.")
    if g.get("G1", {}).get("statut") == ALERT and g.get("G2", {}).get("statut") == OK:
        notes.append(
            "MRR hors cible alors que la croissance est conforme : le profil est "
            "coherent mais l'echelle ne l'est pas. Verifier le point de depart (Y1) "
            "plutot que la trajectoire.")
    return notes


# ---------------------------------------------------------------- rapport
def verdict_global(results):
    if any(r["statut"] == FAIL for r in results if r["id"].startswith("A")):
        return "NON CONFORME - integrite du modele en defaut"
    if any(r["statut"] == NA for r in results):
        if any(r["statut"] == FAIL for r in results):
            return "NON CONFORME"
        return "INCOMPLET - au moins un critere n'a pas pu etre evalue"
    if any(r["statut"] in (FAIL, ALERT) for r in results):
        return "SOUS RESERVES - ecarts a arbitrer"
    return "CONFORME - seed-ready au sens Yelema"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("xlsx")
    ap.add_argument("--config", default=None, help="JSON de seuils (surcharge les defauts)")
    ap.add_argument("--seed", type=float, default=None, help="montant de la levee visee")
    ap.add_argument("--account", default=None, help="compte pour le backend gsheets")
    ap.add_argument("--backend", default=None, help="forcer : cache|libreoffice|gsheets")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    cfg = dict(DEFAULTS)
    if a.config:
        cfg.update(json.load(open(a.config)))
    if a.seed:
        cfg["seed_amount"] = a.seed

    try:
        rc = recalc(a.xlsx, prefer=[a.backend] if a.backend else None, account=a.account)
    except RecalcError as e:
        print("RECALCUL IMPOSSIBLE\n")
        print(str(e))
        print("\nVERDICT : NON EVALUE. Aucun controle n'est fiable sur un classeur "
              "non recalcule.")
        sys.exit(2)

    try:
        results = check_integrity(rc, cfg)
        model = read_model(rc, cfg)
        results += [gate_mrr(model, cfg), gate_growth(model, cfg), gate_runway(model, cfg),
                    gate_trough(model, cfg), gate_jcurve(model, cfg)]
        notes = cross_check(results, model, cfg)
    finally:
        rc.close()

    if a.json:
        print(json.dumps({"backend": rc.backend, "resultats": results,
                          "notes": notes, "sources": model.get("sources", {}),
                          "verdict": verdict_global(results)},
                         ensure_ascii=False, indent=1))
        return

    print(f"CONTROLE BP - {os.path.basename(a.xlsx)}")
    print(f"recalcule par : {rc.backend}   (backends dispo : {', '.join(available_backends())})")
    print()
    print("A. INTEGRITE DU MODELE")
    for r in results:
        if r["id"].startswith("A"):
            print(f"  [{r['statut']:^10}] {r['nom']}")
            print(f"               {r['detail']}")
    print()
    print("B. GARDE-FOUS Yelema")
    for r in results:
        if r["id"].startswith("G"):
            print(f"  [{r['statut']:^10}] {r['nom']}")
            print(f"               {r['detail']}")
    if model.get("sources"):
        print("\nLIGNES LUES (a verifier en dix secondes)")
        for k, v in model["sources"].items():
            print(f"  {k:<24} {v}")
    if notes:
        print("\nLECTURE")
        for n in notes:
            print("  - " + n)
    print(f"\nVERDICT : {verdict_global(results)}")


if __name__ == "__main__":
    main()
