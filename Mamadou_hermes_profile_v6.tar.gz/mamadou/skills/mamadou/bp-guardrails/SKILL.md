---
name: "bp-guardrails"
version: "1.0.0"
description: "Contrôle en lecture seule la conformité d'un BP Excel aux garde-fous Yelema, avec protection anti-faux-vert par recalcul obligatoire."
maj: 2026-09-03
---

# Contrôle de conformité d'un BP — garde-fous Yelema

## Ce que fait ce skill

Il répond à une seule question : **ce BP est-il défendable devant un investisseur pré-seed, au sens Yelema ?**

Il ne construit rien et ne corrige rien. Il lit un classeur, le recalcule, et rend un verdict argumenté par critère. Un BP peut être comptablement juste et malgré tout hors forme (une trajectoire qui ne ressemble à aucun dossier finançable) : ce sont deux questions distinctes, traitées dans cet ordre.

```
A. INTÉGRITÉ     le modèle se tient-il ?        erreurs, lignes CTRL, articulation du cash
B. GARDE-FOUS    a-t-il la forme attendue ?     MRR, croissance, runway, creux, J-curve
```

L'ordre n'est pas cosmétique. Juger la forme d'un modèle qui ne boucle pas n'a aucun sens : les garde-fous liraient des chiffres faux. Si A échoue, le verdict s'arrête là.

## Lancer le contrôle

```bash
python3 scripts/check_guardrails.py <modele.xlsx>
python3 scripts/check_guardrails.py <modele.xlsx> --seed 400000     # levée visée ≠ 250k
python3 scripts/check_guardrails.py <modele.xlsx> --config seuils.json
python3 scripts/check_guardrails.py <modele.xlsx> --json            # sortie machine
```

Le script est autonome : openpyxl seul, aucun accès réseau requis, aucun chemin en dur.

## La règle qui prime sur tout : jamais de faux vert

**Un classeur généré n'est pas un classeur calculé.** Un `.xlsx` produit par openpyxl contient des formules mais aucune valeur : `data_only=True` y renvoie `None` partout. Un contrôleur qui lit ce vide ne trouve aucune anomalie et annonce que tout va bien. C'est le mode de défaillance le plus dangereux de la chaîne, parce qu'il est silencieux et rassurant.

`scripts/recalc.py` impose donc un recalcul effectif avant tout contrôle, par cascade de backends (cache réel, LibreOffice headless, Google Sheets via `gog`). **Si aucun backend ne fonctionne, le skill s'arrête et le dit.** Il ne rend jamais un verdict sur un classeur non recalculé.

Ne jamais contourner ce garde-fou, ne jamais « lire quand même les valeurs disponibles ». Détail des backends et de la portabilité : `references/recalcul.md`.

## Les cinq garde-fous

| # | Garde-fou | Cible par défaut |
|---|---|---|
| G1 | MRR à M12 | 30 000 à 50 000 € / mois |
| G2 | Trajectoire de croissance | **CA × 3 en Year 2, puis × 2 en Year 3** |
| G3 | Runway couvert par la levée | 250 000 € ≈ 12 mois d'OpEx, hors revenu |
| G4 | Creux de trésorerie avant financement | 300 000 à 700 000 €, atteint entre M12 et M18 |
| G5 | J-curve | remontée amorcée 6 à 9 mois après le creux |

Définitions exactes, méthode de calcul et façon d'arbitrer un écart : `references/garde-fous.md`.

Les seuils sont **des repères de calibrage, pas des règles comptables**. Un écart n'est pas une faute : c'est un point à défendre ou à corriger. Le skill rend `ALERTE`, pas `ÉCHEC`, sur un garde-fou hors cible, et `ÉCHEC` seulement sur un défaut d'intégrité.

## Lire le résultat

Quatre statuts, et un seul mérite de l'attention particulière :

- `OK` — dans la cible.
- `ALERTE` — hors cible. À arbitrer, pas à corriger mécaniquement.
- `ÉCHEC` — défaut d'intégrité du modèle. Bloquant.
- `NON ÉVALUÉ` — la grandeur n'a pas été trouvée dans le classeur. **Ce n'est pas un OK.** Si un critère reste non évalué, le verdict global est `INCOMPLET`, jamais `CONFORME`.

Le script affiche toujours **la table des lignes réellement lues** (onglet, ligne, libellé). C'est ce qui permet de vérifier en dix secondes que le contrôle porte sur les bonnes lignes. Un contrôle branché sur la mauvaise ligne ne lève aucune erreur : il produit un verdict plausible et faux. Toujours relire cette table avant de relayer un verdict.

## Restituer à l'utilisateur

Dans la réponse, jamais dans un fichier annexe :

1. Le verdict global, en une phrase.
2. Les critères hors cible, avec le chiffre constaté face à la cible.
3. La lecture d'ensemble quand les garde-fous se contredisent (le script la produit dans la section `LECTURE`).
4. La table des lignes lues.

Ne jamais présenter un garde-fou hors cible comme une erreur de l'entrepreneur sans avoir regardé la tension d'ensemble. Les cinq garde-fous sont calibrés sur un profil type ; sur un modèle nettement plus gros ou plus petit, plusieurs sortent hors cible **ensemble et pour la même raison**. Le dire une fois vaut mieux que cinq alertes séparées.

## Adapter les seuils

Un fichier JSON passé en `--config` surcharge les valeurs par défaut (voir `assets/seuils-Yelema.json` pour le gabarit commenté). Cas courants :

- Levée visée différente de 250 k€ : `--seed <montant>` suffit, G3 et G4 se recalibrent.
- Startup hors profil pré-seed (déjà en revenu, ou ticket beaucoup plus gros) : ajuster `mrr_m12_*` et les bornes du creux, et **le dire dans la restitution**. Un contrôle passé avec des seuils modifiés n'est pas le même contrôle.
- Horizon différent de 36 mois : `horizon_months`.

Ne jamais modifier un seuil pour faire passer un BP. Le but est de savoir où on est, pas d'obtenir un vert.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/garde-fous.md` | Interpréter ou arbitrer un critère, comprendre une tension entre garde-fous |
| `references/recalcul.md` | Recalcul impossible, portabilité, environnement sans LibreOffice |
| `scripts/check_guardrails.py` | Le contrôleur |
| `scripts/recalc.py` | La cascade de recalcul, réutilisable par les autres skills de la chaîne |
| `assets/seuils-Yelema.json` | Gabarit de configuration des seuils |
