# Les garde-fous Yelema — définition, calcul, arbitrage

Repères de calibrage d'un BP pré-seed dans le portefeuille Yelema. Ce ne sont pas des règles comptables : un BP peut être parfaitement juste et sortir hors cible. Le rôle du contrôle est de **situer** le dossier, pas de le sanctionner.

---

## G1 — MRR de 30 000 à 50 000 € par mois à M12

**Ce qu'on lit** : le revenu total du mois 12 dans `P&L_Monthly`.

**Pourquoi cette fourchette** : c'est le niveau à partir duquel un dossier pré-seed africain francophone devient défendable en seed. En dessous, la traction ne porte pas encore la levée suivante. Au-dessus, le dossier n'est plus un pré-seed : ce n'est pas un défaut, mais le reste du calibrage (montant de levée, creux de trésorerie) ne s'applique plus.

**Arbitrer un écart**
- MRR très en dessous : soit la trajectoire d'acquisition est trop lente, soit le pricing est sous-évalué. Regarder d'abord le point de départ (Year 1), pas la pente.
- MRR très au-dessus : vérifier que le modèle n'est pas un seed ou un Series A déguisé. Si c'est assumé, ajuster tous les seuils ensemble et le dire.

---

## G2 — Croissance : CA × 3 en Year 2, puis × 2 en Year 3

**Ce qu'on lit** : `Total revenues` de `P&L_Yearly` (colonnes Year 1 / 2 / 3), sinon l'agrégation des 12 mois correspondants.

**Convention, à ne pas confondre** : les multiples sont **d'une année sur la précédente**, pas par rapport à Year 1.

```
Year 2 = 3 × Year 1
Year 3 = 2 × Year 2      donc 6 × Year 1 au total sur l'horizon
```

Tolérance par défaut : ± 25 % autour de chaque cible.

**Pourquoi ce profil** : une jeune société qui part d'une base faible triple plus facilement en Year 2 qu'en Year 3, où la base est déjà lourde. Un plan qui annonce l'inverse (croissance qui s'accélère la troisième année sans changement de modèle) est un signal à challenger.

**Arbitrer un écart**
- Year 2 très au-dessus de × 3 : souvent un Year 1 tronqué (activité démarrée en cours d'année) plutôt qu'une hypothèse agressive. Vérifier le premier mois de revenu avant de conclure.
- Year 3 en dessous de × 2 : plafonnement du modèle. Regarder si la contrainte vient de l'acquisition (capacité commerciale) ou du pricing.
- Croissance qui s'accélère en Year 3 : demander ce qui la justifie (nouveau marché, nouveau produit, effet de réseau). Sans justification, c'est de l'optimisme.

---

## G3 — La levée couvre environ 12 mois de runway, hors revenu

**Ce qu'on lit** : OpEx moyen mensuel de Year 1 dans `P&L_Monthly`, rapporté au montant de la levée (250 000 € par défaut, `--seed` pour un autre montant).

```
runway (mois) = montant de la levée / OpEx moyen mensuel de Year 1
```

**Hors revenu, volontairement.** Le test est celui du scénario où le revenu ne vient pas. C'est la question que pose l'investisseur : combien de temps tenez-vous si rien ne se passe.

**Arbitrer un écart**
- Runway court (< 11 mois) : le plan de charges est trop lourd pour le ticket visé. Soit lever plus, soit décaler des recrutements.
- Runway long (> 15 mois) : structure sous-dimensionnée, ou levée surcalibrée. Ce n'est pas nécessairement bon signe : une équipe trop légère n'exécute pas le plan d'acquisition qu'elle annonce. Croiser avec G1.

---

## G4 — Creux de trésorerie de 300 000 à 700 000 €, atteint entre M12 et M18

**Ce qu'on lit** : le cumul mensuel des flux **d'exploitation + d'investissement**, à l'exclusion du financement. Le minimum de ce cumul est le besoin de financement maximal.

**Pourquoi exclure le financement** : la ligne de solde de clôture inclut les injections de capital. Elle ne descend donc jamais très bas et masque le vrai besoin. Ce qu'on veut mesurer, c'est ce que l'activité consomme avant d'être financée.

Si les lignes de flux sont introuvables, le script retombe sur le solde de clôture et **le signale** : la valeur est alors minorante, à ne pas relayer comme le besoin réel.

**Arbitrer un écart**
- Creux trop tardif (au-delà de M18) : le modèle brûle encore en fin d'horizon. Vérifier que le point mort est atteint dans les 36 mois.
- Creux trop profond au regard du CA : voir la tension structurelle ci-dessous.
- Creux nul ou positif : soit le modèle est rentable immédiatement (rare, à challenger), soit les lignes de flux n'ont pas été trouvées. Vérifier la table des lignes lues avant toute conclusion.

---

## G5 — J-curve : remontée amorcée 6 à 9 mois après le creux

**Ce qu'on lit** : le même cumul que G4. On cherche le premier mois, après le creux, où le cumul repasse au-dessus de son point bas.

**Ce que ça teste** : que le modèle raconte un retournement, pas une dérive linéaire. Un BP dont le cumul ne remonte jamais sur l'horizon décrit une société qui ne s'en sort pas.

Une remontée **plus rapide** que 6 mois n'est pas pénalisée : c'est le sens favorable.

---

## Quand les garde-fous se contredisent

C'est fréquent, et c'est une information en soi. Les cinq repères sont calibrés sur un même profil type. Sur un modèle d'une autre taille, plusieurs sortent hors cible **ensemble, pour une seule et même raison**.

Le cas le plus courant, déjà rencontré sur un BP du portefeuille :

> À un MRR de 30-50 k€ à M12 et une croissance × 3 puis × 2, le CA de Year 3 plafonne à un niveau qui ne dégage pas assez de marge pour résorber un creux de 300-700 k€ dans l'horizon. Les garde-fous G1 et G4 se contredisent alors géométriquement : le creux visé suppose un profil de revenus plus gros que celui que G1 autorise.

Dans ce cas, ne pas empiler cinq alertes. Dire une fois que **le dossier n'est pas au calibre du profil de référence**, et poser le vrai arbitrage : soit on assume un creux plus modeste, soit on assume une levée supérieure au seed de référence avec un besoin plus tardif.

Le script détecte cette tension et l'écrit dans la section `LECTURE`. Reprendre cette formulation plutôt que de commenter chaque garde-fou séparément.

---

## Ce que le contrôle ne dit pas

- **Rien sur la véracité des hypothèses.** Un modèle peut cocher les cinq garde-fous avec un taux de conversion fantaisiste. Le contrôle porte sur la forme et la cohérence interne, pas sur le réalisme des inputs. Le challenge des hypothèses se fait à la collecte, dans les skills amont.
- **Rien sur le marché ni sur l'équipe.** Ce sont des critères d'investissement, pas de modélisation.
- **Rien sur la conformité comptable.** Les lignes CTRL du modèle vérifient l'articulation interne, pas le respect d'un référentiel comptable.
