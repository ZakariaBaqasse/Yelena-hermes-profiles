# Recalcul et portabilité

## Le problème, en une phrase

Un classeur produit par openpyxl **contient des formules mais aucune valeur**. Tant que rien ne l'a évalué, `openpyxl.load_workbook(data_only=True)` renvoie `None` sur chaque cellule calculée.

Conséquence, et c'est le piège central de toute la chaîne BP :

> Un contrôle qui lit un classeur non recalculé ne trouve aucune anomalie. Il conclut que tout va bien. Le rapport est vert, le modèle peut être entièrement faux.

C'est un échec silencieux : aucune exception, aucun message, un résultat rassurant. Il est plus dangereux qu'un plantage.

## La règle

`scripts/recalc.py` lève `RecalcError` quand aucun backend ne peut recalculer. Le contrôleur s'arrête alors avec le statut `NON ÉVALUÉ` et un code de sortie 2.

**Ne jamais contourner** : ni en lisant « les valeurs quand même », ni en attrapant l'exception pour continuer, ni en supposant qu'un classeur qui vient d'être généré est à jour. Un contrôle impossible doit se dire impossible.

## Cascade de backends

Essayés dans l'ordre, le premier qui répond gagne.

### 1. `cache` — le classeur porte déjà ses valeurs

Vrai uniquement si le fichier a été ouvert puis **sauvé** par Excel ou LibreOffice. C'est le cas d'un modèle reçu d'un tiers, pas d'un modèle qu'on vient de générer.

**Détection correcte, et le piège à ne pas reproduire.** Compter les cellules numériques du classeur ne prouve rien : les inputs saisis sont des constantes, ils portent toujours une valeur même quand aucune formule n'est évaluée. Un détecteur naïf conclut « cache présent » puis lit du vide sur tout le calcul.

La détection échantillonne donc **des cellules qui sont des formules** (`=…` dans le classeur ouvert en `data_only=False`) et vérifie qu'elles ont une valeur en face dans la version `data_only=True`. Seuil : au moins 90 % des formules échantillonnées doivent porter une valeur.

*Ce bug a été commis puis corrigé pendant la construction du skill : le contrôle annonçait 2 lignes CTRL au lieu de 15, les 13 autres étant des formules vides lues comme absentes.*

### 2. `libreoffice` — recalcul local

`soffice --headless --convert-to xlsx` révalue tout le classeur à la conversion. Rapide, hors ligne, sans credentials. C'est le backend à privilégier en déploiement.

Sa présence ne garantit pas son bon fonctionnement : le binaire peut répondre à `--version` et malgré tout échouer à charger un `.xlsx` (`Error: source file could not be loaded`). Le backend renvoie alors la main au suivant au lieu de faire échouer le contrôle.

**Cause la plus fréquente, et elle ne se voit pas : le module tableur n'est pas installé.** Sur Debian/Ubuntu, `libreoffice-writer`, `-impress`, `-draw` et `-core` peuvent être présents sans `libreoffice-calc`. Le binaire `soffice` existe, répond à `--version`, convertit un `.pptx` sans broncher, et échoue sur tout classeur : il n'a aucun filtre pour lire un tableur. Le message d'erreur ne mentionne jamais le paquet manquant, ce qui fait conclure à tort que LibreOffice est cassé.

Diagnostic en une commande :

```bash
ls /usr/lib/libreoffice/program/libsclo.so /usr/lib/libreoffice/program/libscfiltlo.so
# absents => module Calc non installe
```

Remède, en alignant la version sur celle des autres paquets LibreOffice (`dpkg -l | grep libreoffice-core`) pour éviter un mélange de versions :

```bash
sudo apt-get install -y libreoffice-calc=<version_de_libreoffice-core>
```

*Cas réel : une machine de la flotte a fonctionné un mois sur le backend distant Google Sheets, à cause de ce seul paquet manquant diagnostiqué comme « LibreOffice cassé ». Après installation, recalcul local en 8 secondes au lieu de 2 à 3 minutes, hors ligne et sans credentials, pour des résultats identiques au dixième près.*

### 3. `gsheets` — recalcul par Google Sheets

Passe par le CLI `gog` : upload en conversion Sheet, lecture des plages en valeurs, suppression du fichier temporaire. Utile quand LibreOffice est absent ou cassé.

Contraintes : nécessite `gog` authentifié et un accès réseau ; plus lent ; le compte se passe par `--account` ou la variable `BPGR_GOG_ACCOUNT`. Le fichier temporaire est nommé `ZZ_bpgr_…_DELETE` et supprimé dans un `finally`.

## Portabilité — ce qui rend ce skill transposable

Le skill est conçu pour être déposé dans n'importe quel agent, sur n'importe quelle machine, sans réglage.

- **Aucun chemin absolu.** Les scripts se localisent par `os.path.dirname(__file__)`.
- **Aucune dépendance obligatoire hors openpyxl.** LibreOffice et `gog` sont détectés à l'exécution, jamais requis.
- **Aucun credential dans le code.** Le compte Google éventuel vient d'un argument ou d'une variable d'environnement.
- **Aucun appel réseau par défaut.** Le backend `gsheets` n'est tenté qu'en dernier recours, et seulement si `gog` existe.
- **Dégradation explicite.** Chaque capacité absente est nommée dans le message d'erreur, avec le remède correspondant.

Vérifier la portabilité sur une machine cible :

```bash
python3 scripts/recalc.py <un_modele.xlsx>
# affiche les backends disponibles et celui qui a effectivement recalcule
```

Si la sortie annonce `backends disponibles : ['cache']` et que le classeur vient d'être généré, le contrôle échouera : installer LibreOffice est le remède le plus simple.

### Environnement sans apt/sudo (cas de ce conteneur)

LibreOffice a été installé **en local, sans droits root**, le 18/08 : téléchargement du tarball officiel `.deb` (documentfoundation.org), extraction des paquets avec `dpkg-deb -x` (pas d'install système, juste une extraction de fichiers) vers `~/tools/libreoffice-local/`. `_has_soffice()` dans `recalc.py` connaît ce chemin en fallback (`~/tools/bin/soffice`, wrapper qui fixe `-env:UserInstallation` vers `~/tools/lo-userdir` et appelle `soffice.bin` directement — le launcher `soffice`/`oosplash` par défaut échoue ici faute de `libXinerama`, une dépendance UI absente et non nécessaire en headless).

Même logique pour Python : ni `pip`, ni `python3-venv`/`ensurepip` ne sont installés système, et `apt-get` est verrouillé (pas de droits d'écriture sur `/var/lib/apt`). Contournement : `python3 -m venv --without-pip` fonctionne quand même (le module `venv` lui-même est présent), puis `get-pip.py` (bootstrap officiel PyPA) télécharge et installe pip dans ce venv. Résultat persistant : `~/tools/py-bp/` (venv avec `openpyxl` installé), à utiliser comme interpréteur pour tous les scripts de la chaîne BP :

```bash
~/tools/py-bp/bin/python3 scripts/check_guardrails.py <modele.xlsx>
```

Aucun de ces contournements ne modifie le système ni ne requiert de droits élevés : tout vit sous `~/tools/`, réutilisable par n'importe quel skill de la chaîne BP sur cette machine.

## Réutilisation par les autres skills de la chaîne

`recalc.py` est autonome et importable. Tout skill qui doit lire des valeurs calculées (contrôles de `bp-pl-cashflow-tabs`, cohérence des blocs de flux de `bp-charts`) devrait passer par lui plutôt que par `data_only=True` en direct, pour hériter de la protection contre le faux vert.

```python
from recalc import recalc, RecalcError
try:
    rc = recalc("modele.xlsx")          # leve si rien ne peut recalculer
    grid = rc.grid("Cashflow_Monthly")  # liste de listes, A1 en [0][0]
finally:
    rc.close()                          # supprime le fichier temporaire eventuel
```