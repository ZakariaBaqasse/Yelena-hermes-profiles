---
name: "rapprochement-bancaire"
version: 1.0.0
description: "Rapproche banque, mobile money, caisse — avec discipline d'audit : mise en attente, non-suppression, double revue, pack de preuves."
id: Y0404
bucket: B
tags: [Finance, Comptabilité, Horizontal, Nouveau]
maj: 2026-09-03
---

# Le rapprochement bancaire — mettre d'accord la banque et les livres

## Ce qu'il faut avoir sous la main
- **Le ou les comptes à rapprocher** : banque, mobile money (précise l'opérateur — Orange Money, MTN Money, Moov Money, Wave…), caisse espèces.
- **Le relevé de la période** : relevé bancaire, historique de transactions mobile money, registre de caisse.
- **Le grand livre ou journal comptable** correspondant à la même période.
- **La devise** de chaque compte, et si des encaissements arrivent en devise étrangère (euro, dollar).
- **Le dernier état de rapprochement** disponible, s'il existe — pour partir d'un point vérifié plutôt que de zéro.
- **La périodicité actuelle** de rapprochement de chaque compte.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 0 — Mettre l'import en zone tampon, avant toute écriture

**Rien ne devient de la comptabilité au moment de l'import.** Un relevé bancaire, un export mobile money ou un registre de caisse importé passe d'abord par une zone tampon : source nommée, date et heure de récupération, personne qui a récupéré le fichier, empreinte du fichier (pour détecter un doublon d'import). Aucune écriture définitive ne part de cette étape — elle sert seulement à tracer ce qu'on a reçu, quand, et de qui.

Si le même fichier est réimporté à l'identique, tu le signales comme doublon et tu ne le retraites pas. Si une correction du fichier source est nécessaire, le nouvel import **remplace proprement l'ancien sans l'effacer** : l'import précédent reste consultable, marqué "remplacé", avec la date et la raison du remplacement. Un fichier corrigé qui écrase silencieusement l'ancien détruit la trace de ce qui a été vu et quand — exactement l'information qu'un audit demande en premier.

### Étape 1 — Partir du dernier point vérifié, pas de zéro

Si un état de rapprochement antérieur existe, tu pars de son solde de clôture, pas du solde d'ouverture de l'exercice. Un rapprochement qui repart de zéro à chaque fois recommence à expliquer des écarts déjà expliqués le mois précédent — et risque de perdre la trace d'une anomalie identifiée mais non corrigée depuis plusieurs périodes.

S'il n'existe aucun état antérieur, tu le signales : c'est un premier rapprochement, et le volume d'écarts à traiter sera mécaniquement plus élevé. Tu ne le traites pas comme un rapprochement de routine.

### Étape 2 — Poser les deux soldes et recenser les écarts un par un

Tu poses le solde du relevé (banque, mobile money ou caisse) et le solde comptable à la même date de coupure. Puis tu parcours chaque mouvement du relevé qui n'a pas de contrepartie évidente dans les livres, et chaque écriture des livres qui n'apparaît pas sur le relevé.

**Taxonomie de correspondance, à appliquer dans cet ordre** (une correspondance trouvée à un niveau ne redescend pas au suivant) :
1. **Correspondance exacte** : montant, devise et date identiques (ou date à ± 1 jour), avec une référence commune entre le relevé et les livres.
2. **Correspondance montant + fenêtre de date** : même montant, référence absente ou illisible sur le relevé, date proche (fenêtre à définir selon le compte — quelques jours pour une banque, plus large pour un chèque).
3. **Correspondance par tiers avec tolérance** : même contrepartie identifiée, montant proche dans une tolérance explicite (jamais silencieuse) — utile quand des frais sont prélevés en cours de route.
4. **Correspondance multi-lignes** : une seule ligne de relevé qui couvre plusieurs écritures des livres (un règlement groupé), ou l'inverse (une écriture éclatée en plusieurs mouvements sur le relevé). Documenter explicitement le regroupement, jamais le deviner silencieusement.

Tu classes chaque écart restant par nature : chèque émis non encore présenté, virement enregistré côté livres mais pas encore débité par la banque, opération bancaire (frais, agios, prélèvement automatique) non encore enregistrée côté comptabilité, opération enregistrée deux fois. Ne classe jamais un écart « divers » — un écart non catégorisé est un écart qu'on n'a pas encore compris, pas une catégorie légitime.

### Étape 3 — Isoler les frais de transaction sur le mobile money

C'est le piège le plus systématique et le plus mal traité. Un encaissement de monnaie électronique n'arrive jamais pour son montant brut : l'opérateur retient une commission au passage. Une entreprise qui enregistre le montant facturé au client et constate ensuite le montant réellement crédité aura un écart permanent, opération après opération, qui ne se résorbe jamais tout seul — parce que ce n'est pas une erreur, c'est un coût.

Le traitement correct : le montant facturé reste la créance, le montant reçu net est l'encaissement, et la différence s'enregistre comme une **charge de frais de transaction** — jamais comme une remise commerciale ou un ajustement de chiffre d'affaires. Tu vérifies ce point canal par canal (Orange Money, MTN Money, Moov Money, Wave n'ont pas la même structure de commission) et tu produis un suivi séparé de ces frais par canal, pas seulement une ligne noyée dans le rapprochement.

Cas fréquent à traiter explicitement : un règlement d'opérateur qui arrive **net des frais ET net d'un réapprovisionnement de float** dans la même ligne de relevé. Ne jamais fusionner ces deux effets dans un seul écart : sépare la ligne de frais de transaction de la ligne de mouvement de float, chacune avec sa propre justification.

### Étape 4 — Isoler les écarts de change sur les encaissements en devises

Un encaissement en euros se convertit en francs CFA à une parité fixe : l'écart éventuel, s'il existe, vient uniquement des frais bancaires de traitement, pas du cours — c'est le cas le plus simple à isoler. Un encaissement en dollars, en revanche, se convertit à un cours qui varie ; l'écart entre le montant attendu au cours du jour de facturation et le montant réellement crédité mélange un effet de change et une commission bancaire.

Tu ne mets jamais ces deux composantes dans la même ligne : sépare l'écart de change (qui se justifie par le cours appliqué, `⟦cours source à renseigner⟧`) de la commission bancaire (qui se justifie par le barème de la banque). Un écart de change n'est pas une erreur du client à relancer — c'est un mécanisme normal qu'il faut documenter, pas corriger.

### Étape 5 — Rapprocher la caisse séparément, par comptage physique

La caisse en espèces ne se rapproche pas sur pièce comme une banque : elle se rapproche par **comptage physique**, contradictoire (deux personnes présentes) et daté. C'est le point le plus exposé et le moins contrôlé d'une PME, précisément parce qu'aucun tiers indépendant (comme une banque) ne fournit de relevé à comparer.

Tu produis un procès-verbal de comptage : date, montant compté par dénomination, montant théorique selon le livre de caisse, écart constaté. Un écart de caisse non expliqué immédiatement après le comptage devient très difficile à retracer ensuite — il se traite avec la même urgence qu'un écart bancaire, pas avec plus de tolérance parce que « c'est du cash ».

### Étape 6 — Vieillir les éléments en rapprochement

Chaque écart non soldé porte une date d'apparition. Tu classes les éléments en rapprochement par ancienneté (`⟦grille d'ancienneté à renseigner : ex. < 30 jours / 30-90 jours / > 90 jours⟧`) — c'est le vieillissement, pas le montant, qui révèle l'anomalie. Un chèque émis non présenté depuis longtemps peut signaler un chèque perdu ou jamais encaissé par le bénéficiaire. Un virement en attente qui ne vient jamais peut signaler une opération qui n'aura jamais lieu et doit être annulée dans les livres. Une opération qui réapparaît à l'identique d'un mois sur l'autre signale un doublon d'enregistrement.

Un élément en rapprochement de plus de `⟦seuil à renseigner⟧` jours n'est plus une opération en transit — c'est une anomalie à investiguer nommément, avec un responsable et une date de résolution attendue.

### Étape 7 — Trancher : écriture corrective ou différence ouverte

Pour chaque écart recensé, tu poses la question centrale : **sait-on avec certitude d'où il vient ?** Si oui, tu prépares l'écriture corrective et tu la documentes (nature, montant, pièce justificative) — mais elle ne part **jamais directement en comptabilité définitive** : voir étape 8. Si non, l'écart reste **une différence non expliquée**, affichée avec son montant et sa date d'apparition — elle n'est ni soldée ni masquée par une écriture de régularisation « pour équilibrer ».

C'est le piège du métier : forcer l'équilibre. Une différence qu'on solde sans en comprendre l'origine efface le symptôme et garde la maladie ; elle revient le mois suivant, souvent plus grosse, parce que la cause réelle continue de produire des écarts. Un état de rapprochement avec une ligne « différence non expliquée : `⟦montant⟧`, apparue le `⟦date⟧` » est un livrable correct et honnête — un état parfaitement équilibré sans explication est un signal d'alarme, pas une réussite.

### Étape 8 — Double revue avant écriture définitive, puis pack de preuves de clôture

**Aucune écriture corrective préparée à l'étape 7 ne part en comptabilité sans une seconde paire d'yeux.** Le rapprochement distingue deux rôles : celui qui prépare (identifie l'écart, propose l'écriture) et celui qui valide (vérifie la pièce justificative, autorise le passage en comptabilité). Ce n'est pas une formalité — c'est ce qui rattrape une écriture corrective fondée sur une hypothèse fausse avant qu'elle ne devienne un fait comptable.

À la clôture du rapprochement, produis un **pack de preuves** : l'état de rapprochement complet, la liste des écritures correctives passées avec leurs pièces justificatives, la liste des différences restées ouvertes, l'empreinte des fichiers sources importés, et l'identité du préparateur et du validateur avec leurs dates de signature. C'est ce pack qui permet de rouvrir un rapprochement six mois plus tard et de répondre exactement à ce qui a été vérifié, par qui, et quand — la même exigence que pour un dossier de rapprochement rangé selon `piste-audit-et-suspens`.

## Format de sortie
- **Livrable** : l'état de rapprochement par compte — solde du relevé, solde comptable, éléments en rapprochement classés par nature et par ancienneté, écritures correctives à passer avec leur justification (en attente de validation), différences non expliquées avec montant et date d'apparition. En complément : le suivi des frais de transaction par canal d'encaissement (mobile money), le procès-verbal de comptage de caisse le cas échéant, et le **pack de preuves de clôture** (état complet, pièces, empreintes des imports, signatures préparateur/validateur).
- **Structure** : Markdown clair — answer-first (le solde final rapproché et le nombre de différences ouvertes en tête, le détail ensuite) ; tableaux pour le recensement des écarts et la grille d'ancienneté.
- **Longueur** : proportionnée au nombre de comptes et au volume d'écarts, sans remplissage.
- **Les seuils d'ancienneté et les cours de change sont un input**, pas une production : la skill livre la structure de classement et la question à trancher ; la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun montant, cours de change, taux de commission ou date inventés. Si une information manque, la demander ou la marquer `[à confirmer]`.

## Règles
1. **On n'équilibre jamais une différence qu'on ne comprend pas.** Une écriture corrective se passe seulement quand l'origine de l'écart est établie et documentée. Sinon, la différence reste ouverte, affichée avec son montant et sa date.
2. **Les frais de mobile money sont une charge, pas un ajustement du chiffre d'affaires.** Le montant facturé reste la créance ; l'écart avec le montant net reçu est un coût de transaction à enregistrer et à suivre par canal.
3. **Change et commission ne se mélangent jamais dans la même ligne.** Sur un encaissement en devise, l'effet de cours et les frais bancaires sont deux lignes distinctes, chacune avec sa justification propre.
4. **Le vieillissement prime sur le montant.** Un petit écart ancien mérite plus d'attention qu'un gros écart apparu la veille et déjà expliqué. C'est l'ancienneté qui révèle le doublon, le chèque perdu ou le virement qui ne viendra jamais.
5. **La caisse se rapproche par comptage physique contradictoire, pas par déduction.** Aucun rapprochement de caisse n'est valable sans un comptage daté et signé par deux personnes.
6. **La périodicité mensuelle est un minimum.** Plus l'intervalle entre deux rapprochements est long, plus le volume d'écarts s'accumule et moins on retrouve l'origine de chacun. Un compte très mouvementé se rapproche plus souvent — tu le signales si la fréquence actuelle est insuffisante.
7. **Aucun import n'est modifié après coup, aucun n'est effacé.** Une correction est un nouvel import qui remplace proprement l'ancien (marqué « remplacé », avec la raison) ; l'historique complet reste consultable.
8. **Aucune écriture corrective ne part en comptabilité sur la seule main de celui qui l'a préparée.** Une seconde personne vérifie la pièce justificative avant que l'écriture ne devienne définitive.
9. **Toute clôture de rapprochement produit son pack de preuves.** Sans lui, un rapprochement « fait » ne se distingue pas d'un rapprochement qu'on ne pourrait pas justifier six mois plus tard.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; passer une écriture comptable définitive, contacter la banque ou l'opérateur mobile money, ou modifier un livre comptable est une action validée par l'utilisateur — et par le second regard (validateur) avant toute écriture définitive.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Relevé ou journal manquant** — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lu ; tu travailles avec ce qui est disponible et tu marques le rapprochement partiel.
- **Premier rapprochement, aucun historique** — tu le dis explicitement, tu attends un volume d'écarts plus élevé qu'en routine, et tu ne compares pas ce rapprochement à un rythme de croisière qui n'existe pas encore.
- **Écart qui persiste depuis plusieurs périodes malgré des écritures correctives passées** — tu ne repasses pas une nouvelle correction sans comprendre pourquoi la précédente n'a pas résolu le problème ; tu le signales comme anomalie structurelle à investiguer.
- **Compte multi-devises sans cours de change fourni** — tu isoles la composante change et tu la marques `⟦cours à renseigner⟧`, tu ne l'estimes jamais toi-même.
- **Caisse jamais comptée physiquement** — tu le signales comme un manque de contrôle en soi, indépendamment du résultat du rapprochement comptable.
- **Écart dont le montant est significatif et l'origine introuvable** — tu le maintiens ouvert, tu le mets en évidence en tête du livrable plutôt que de le noyer dans le détail, et tu recommandes une vérification ciblée (relance banque, opérateur, ou vérification interne).
- **Soupçon de fraude ou de détournement révélé par le rapprochement** — tu le signales factuellement (montant, date, nature de l'écart) sans qualifier juridiquement les faits, et tu recommandes l'implication d'une personne habilitée en interne.
- **Réimport d'un fichier déjà traité, à l'identique** — tu le signales comme doublon d'import (même empreinte) et tu ne le retraites pas.
- **Fichier source corrigé après un premier import** — tu ne modifies jamais l'import initial ; tu en crées un nouveau marqué comme remplaçant l'ancien, avec la raison du remplacement, et l'ancien reste consultable.
- **Pas de second regard disponible pour valider une écriture** — tu le signales explicitement : l'écriture reste préparée, non définitive, en attente d'un validateur.
- **Demande hors périmètre** (audit complet, clôture des comptes, déclaration fiscale) — tu le dis en une phrase, tu traites ce qui relève du rapprochement, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (contacter la banque, l'opérateur mobile money, ou passer l'écriture en comptabilité) — tu prépares le livrable et tu t'arrêtes pour validation humaine.

## Traçabilité de cette version
Discipline d'audit (mise en attente, non-suppression/supersede, double revue, pack de preuves, taxonomie de correspondance enrichie) ajoutée le 17/08/2026, inspirée d'un skill public de référence (`chwezi-accounting-doctrine`, GitHub, consulté ce jour) conçu à l'origine pour un contexte ougandais (UGX, MTN MoMo/Airtel) — adaptée ici sans emprunter de chiffre ni de nom d'entité de ce dépôt, seulement les principes de contrôle.
