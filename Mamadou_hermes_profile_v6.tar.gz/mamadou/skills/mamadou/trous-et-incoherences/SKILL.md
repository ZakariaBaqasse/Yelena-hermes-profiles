---
id: Y0653
name: trous-et-incoherences
description: "Passe la salle de données au crible pour produire les deux listes qui décident de la suite : ce qui manque, et ce qui ne concorde pas entre les pièces. Confronte les chiffres qui doivent boucler d'un document à l'autre, remonte chaque écart à sa source probable, distingue l'absence coupable de l'absence normale, et hiérarchise par ce que chaque point coûte s'il n'est pas levé — sans jamais transformer un écart constaté en accusation."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Trous et incohérences — ce que le dossier ne dit pas, et ce qu'il dit deux fois

## Ce qu'il faut avoir sous la main
- **La liste des pièces reçues** dans la data room, ou un accès à celle-ci.
- **Le stade de l'opération** : due diligence préliminaire, avancée, closing proche — ça change ce qui doit déjà exister.
- **Les pièces déjà réclamées** et non reçues, si tu les as identifiées, pour que je ne les redemande pas à ta place sans le savoir.
- **Le type d'opération** : levée de fonds, acquisition, entrée au capital — la liste des pièces attendues n'est pas la même.
- Si tu les as : **les chiffres clés déjà annoncés par la société** (CA, effectif, nombre de clients) pour que je sache quoi confronter en priorité.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Dresser la carte des pièces attendues et croiser avec ce qui est reçu

Avant de chercher un écart, établis ce qui **devrait** être dans la salle de données compte tenu du type d'opération et du stade annoncés : statuts à jour, RCCM, pacte d'associés, table de capitalisation, états financiers des derniers exercices, déclarations sociales, contrats clients significatifs, registre des immobilisations. Marque chaque pièce attendue comme **reçue**, **absente**, ou **partielle** (reçue mais incomplète — une seule page d'un contrat, un état financier sans annexes).

Le piège ici : lister des pièces génériques sans les rattacher au dossier réel. Une pièce n'est « attendue » que si le stade ou le type d'opération la rend normalement disponible à ce moment — sinon son absence n'est pas un manque, c'est l'ordre naturel des choses.

### Étape 2 — Distinguer les trois cas d'absence

Pour chaque pièce absente ou partielle, tranche laquelle des trois situations s'applique, et ne conclus jamais avant de l'avoir fait :
- **La pièce n'a pas été fournie** — elle existe probablement, elle est simplement hors de la salle de données à ce stade. C'est le seul cas que tu écris comme un manque à réclamer.
- **La pièce n'existe pas encore** — la société est trop jeune, l'exercice n'est pas clos, l'organe qui produirait le document n'a pas encore statué. Ce n'est pas un manque, c'est un fait du calendrier ; tu le notes comme tel et tu ne le mets pas dans la même colonne que le premier cas.
- **La pièce existe et n'est délibérément pas produite** — tu ne peux l'affirmer que si un refus explicite a été opposé à une demande précise. Sans cette demande, tu restes dans le premier cas.

Une note qui écrit « absence » comme si c'était toujours la faute de la société, alors que la demande n'a même pas été formulée, coûte une relation et parfois un dossier entier. Tant que la pièce n'a pas été explicitement réclamée, le vocabulaire reste neutre : « à demander », jamais « non fournie » au sens d'un refus.

### Étape 3 — Confronter les chiffres qui doivent boucler, pas les mots qui se ressemblent

L'incohérence qui compte ne se cherche pas dans un adjectif employé différemment d'une page à l'autre — elle se cherche dans l'arithmétique. Reprends les couples qui doivent boucler entre eux et fais le calcul, pas la relecture :
- le chiffre d'affaires annoncé dans le pitch ou le mémo contre celui des états financiers ;
- le nombre de clients revendiqué contre le nombre de contrats signés et contre les encaissements bancaires correspondants ;
- la table de capitalisation présentée contre le pacte d'associés et contre les statuts réellement déposés au registre ;
- l'effectif annoncé contre la masse salariale comptabilisée et contre les déclarations sociales ;
- la date de création revendiquée contre la date d'immatriculation officielle.

Pour chaque couple, si les deux pièces existent, fais le calcul même quand rien ne semble clocher à la lecture — l'écart arithmétique ne se voit jamais en lisant, seulement en soustrayant.

### Étape 4 — Remonter chaque écart à sa source probable, sans conclure à l'intention

Un écart constaté n'est pas une accusation. Pour chaque écart trouvé à l'étape 3, écris-le sous la forme : la valeur A avec la pièce et la date qui la portent, la valeur B avec la pièce et la date qui la portent, l'ampleur de l'écart, et **les explications possibles** — décalage de périmètre comptable, chiffre pro forma contre chiffre audité, retard de mise à jour d'un registre, erreur de saisie, ou effectivement un problème de fond. Tu n'en retiens aucune : tu poses la question qui permettrait de trancher.

Le glissement à éviter : passer directement de « les deux chiffres ne collent pas » à « la société gonfle ses chiffres ». C'est parfois vrai, mais ce n'est jamais la seule lecture possible à ce stade, et l'écrire comme une certitude expose autant que ça informe.

### Étape 5 — Hiérarchiser par ce que chaque point coûte s'il n'est pas levé

Classe chaque manque et chaque écart selon ce qu'il fait à l'opération s'il reste non résolu :
- **Bloquant** — remet en cause un chiffre central de la valorisation, la réalité de la propriété du capital, ou la légalité de l'existence de la société. Tant que ce n'est pas levé, l'opération ne peut pas avancer sur ce point.
- **Conditionnant** — n'arrête rien seul, mais change les termes : une clause à renégocier, une garantie à demander, un prix à ajuster.
- **À affiner** — une pièce à jour manquante sans enjeu de fond, une adresse périmée, un formalisme mineur.

Sans cette hiérarchie, un tableau de cinquante lignes traite une adresse de siège obsolète au même niveau qu'un doute sur la propriété réelle du capital, et le lecteur perd le seul point qui pouvait faire échouer le dossier.

### Étape 6 — Synthèse et formulation neutre des demandes

Ouvre par la synthèse : ce qui est bloquant, ce qui conditionne, ce qui affine — en une ligne chacun. Puis pour chaque manque et chaque écart, formule la demande ou la question dans un langage factuel et non accusatoire : « merci de transmettre X » plutôt que « pourquoi X n'a-t-il pas été fourni », « pouvez-vous préciser l'écart entre A et B » plutôt que « le chiffre annoncé est faux ».

## Format de sortie
- **Livrable** : une synthèse en tête (bloquant / conditionnant / à affiner), suivie de deux tableaux — le tableau des manques (pièce attendue, pourquoi elle est attendue, gravité, cas parmi les trois, formulation neutre de la demande) et le tableau des écarts (le fait, valeur A et sa pièce, valeur B et sa pièce, ampleur, explications possibles, question à poser).
- **Structure** : Markdown, answer-first — la synthèse d'abord, les tableaux ensuite. Tableaux systématiques pour les manques et les écarts, pas de prose à leur place.
- **Longueur** : proportionnée à la taille réelle de la salle de données. Pas de remplissage pour atteindre un nombre de lignes.
- **Aucune ampleur d'écart n'est qualifiée** (« significatif », « préoccupant ») sans que les deux valeurs comparées soient données dans la même ligne — le lecteur juge sur les chiffres, pas sur ton adjectif.
- **Règle 0 invention** : aucune pièce, aucun chiffre, aucune date n'est supposé lu si elle n'a pas été fournie. Une pièce non transmise reste `[à confirmer]`, jamais remplacée par une estimation.

## Règles
1. **L'incohérence se cherche dans l'arithmétique, pas dans le vocabulaire.** Deux formulations différentes d'un même fait ne sont pas une incohérence ; deux chiffres qui ne s'additionnent pas en sont une. Tu fais le calcul pour chaque couple attendu, même quand rien ne semble clocher à la lecture.
2. **Une absence n'est pas une faute tant qu'elle n'a pas été qualifiée.** Tu distingues systématiquement : pièce non fournie (neutre, à demander), pièce inexistante à ce stade (normal), pièce refusée après demande explicite (le seul cas qui justifie un ton plus ferme). Par défaut, en l'absence d'information sur une demande déjà faite, tu restes dans le premier cas.
3. **Chaque écart s'écrit avec ses deux valeurs et leurs sources, jamais comme une conclusion sur une intention.** « CA annoncé de X, CA des états financiers de Y, écart de Z, à clarifier » — pas « la société a gonflé son chiffre d'affaires ».
4. **Rien n'est listé au même niveau.** Chaque manque et chaque écart porte une gravité (bloquant / conditionnant / à affiner) déterminée par ce qu'il coûte à l'opération, pas par l'ordre dans lequel tu l'as trouvé.
5. **Le ton des demandes reste factuel même quand l'écart est important.** Plus l'écart pèse, plus la formulation doit rester neutre — c'est là que le glissement vers l'accusation coûte le plus cher.
6. **Le contexte du dossier n'est pas un décor.** Le stade de l'opération et le type d'opération déterminent ce qui est réellement attendu à ce moment ; une pièce normale à un closing ne l'est pas nécessairement à un premier tour d'échanges.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer une demande de pièces à la société, publier une conclusion ou notifier un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet (salle de données partielle)** — tu produis les deux tableaux avec ce que tu as, tu marques `[à confirmer]` ce qui manque pour juger, et tu ne redemandes que ce qui est indispensable et impossible à déduire raisonnablement.
- **Pièce annoncée mais absente de fait** (« voici les états financiers », rien n'est joint) — tu le signales avant de continuer et tu ne fais jamais comme si tu l'avais lue.
- **Aucune pièce comptable disponible** — tu ne peux pas faire l'étape 3 des couples financiers ; tu le dis explicitement, tu produis le tableau des manques en priorité, et tu marques la confrontation des chiffres comme non réalisable en l'état.
- **Écart trouvé mais une seule des deux sources est datée** — tu signales que la comparaison peut être faussée par un simple décalage temporel avant de la qualifier de quelque façon que ce soit.
- **Refus de communiquer une pièce déjà opposé** — c'est le seul cas où tu peux qualifier l'absence plus fermement que « à demander » ; tu le fais alors explicitement et tu cites la demande initiale si elle t'a été transmise.
- **Demande hors périmètre** (analyse de valorisation, recommandation d'investir) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi de la demande de pièces à la société, partage de la synthèse à un tiers) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires entre deux documents internes de la société** (deux versions du pacte, deux statuts) — tu exposes les deux versions dans le tableau des écarts et tu demandes l'arbitrage plutôt que de choisir laquelle fait foi.
