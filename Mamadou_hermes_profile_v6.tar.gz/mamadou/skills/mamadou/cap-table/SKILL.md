---
id: Y0306
name: cap-table
description: "Construit et tient à jour la table de capitalisation d'une startup : répartition entre fondateurs, pool d'options, instruments convertibles et investisseurs, simulation de dilution tour par tour, scénarios de sortie par catégorie d'actionnaire, et signalement des configurations qui bloqueront une levée — sans jamais inventer un montant, un pourcentage ou une valorisation."
bucket: B
tags: [Finance, Fundraising, Vertical, Nouveau]
version: 1
maj: 2026-08-10
---

# Cap table — structure actionnariale et dilution

## Ce qu'il faut avoir sous la main
🔒 **Ceci n'est pas un conseil juridique ni financier.** Je produis un document de travail à faire valider par ton avocat et ton conseil financier avant tout usage engageant.

- **Les actionnaires actuels** : qui, combien de parts ou quel pourcentage, et à quel titre (fondateur, investisseur, salarié, structure d'accompagnement).
- **Les instruments en cours** : convertibles, BSA-AIR, prêts d'honneur, promesses faites à des salariés ou advisors — même informelles.
- **Le pool d'options** s'il existe, sa taille et ce qui est déjà attribué.
- **Ce que tu veux savoir** : état des lieux · simuler un tour · préparer une data room · vérifier que la structure tient.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Poser l'état des lieux

Reconstitue la table actuelle : par actionnaire, le nombre de parts, le pourcentage, la catégorie (fondateur, investisseur, salarié, advisor, structure d'accompagnement) et l'instrument (actions ordinaires, préférentielles, options, convertible). Total à 100 %, entièrement dilué **et** non dilué — les deux vues, elles ne racontent pas la même histoire.

Un actionnaire dont tu n'as pas le pourcentage exact reste `⟦à renseigner⟧`. Ne complète jamais pour faire tomber le total à 100.

### Étape 2 — Traiter les instruments non convertis

Convertibles, BSA-AIR, prêts d'honneur, promesses verbales à des advisors : ils n'apparaissent pas dans la table mais diluent au tour suivant. Liste-les avec leur montant, leur décote et leur plafond de valorisation quand ils existent, puis montre la table **avant** et **après** conversion. C'est l'écart entre les deux qui surprend les fondateurs.

### Étape 3 — Simuler le tour

Pour un tour donné (montant levé, valorisation pré-money, taille de pool à reconstituer) : la table après opération, la dilution subie par chaque actionnaire existant, et le prix par part. Si le pool doit être reconstitué avant le tour, montre-le explicitement — c'est presque toujours les fondateurs qui le paient, et presque jamais ce qu'ils ont compris.

### Étape 4 — Scénarios de sortie

Pour deux ou trois valeurs de sortie, ce que touche chaque catégorie d'actionnaire, en tenant compte des préférences de liquidation si elles existent. Signale le cas où les fondateurs ne touchent rien malgré une sortie apparemment réussie — il arrive plus souvent qu'on ne croit.

### Étape 5 — Ce qui bloquera la levée

Passe la structure au crible des configurations qui font reculer un investisseur : déséquilibre fort entre fondateurs actifs, fondateur parti conservant une part importante, absence de vesting, pool inexistant ou déjà épuisé, part trop élevée détenue par une structure d'accompagnement ou un investisseur early, trop d'actionnaires minoritaires au capital, promesses non formalisées. Pour chaque point : pourquoi ça bloque, et la correction habituelle.

### Étape 6 — Ce qu'il faut faire trancher

Liste des points à soumettre à un avocat : forme des instruments, vesting et clauses de sortie de fondateur, pacte d'actionnaires, régime fiscal du pool dans la juridiction concernée.

## Format de sortie
- **Livrable** : la table de capitalisation actuelle (diluée et non diluée), l'inventaire des instruments non convertis avec la table avant/après conversion, la simulation du tour visé, les scénarios de sortie par catégorie d'actionnaire, la liste des points bloquants avec leur correction, et les points à faire valider juridiquement.
- **Structure** : Markdown clair — answer-first, puis le détail ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **0 chiffre inventé.** Aucun pourcentage, montant, valorisation ou nombre de parts n'est produit sans être fourni : `⟦à renseigner⟧` sinon. Un total qui ne fait pas 100 % se signale, il ne se rattrape pas.
2. **Diluée et non diluée, toujours les deux.** Une cap table présentée sur une seule vue est trompeuse.
3. **Les promesses informelles comptent.** Un engagement verbal envers un advisor ou un premier salarié est une dilution future : il apparaît dans l'inventaire, marqué comme non formalisé.
4. **Jamais présenté comme un avis juridique ou financier.** La mention figure en tête du livrable ; le document prépare l'avocat et le conseil, il ne les remplace pas.
5. **Les points bloquants sont dits franchement**, avec leur correction. Une cap table présentée comme saine alors qu'elle ne l'est pas coûte un tour entier.
6. **Confidentialité maximale.** Une table de capitalisation est la donnée la plus sensible d'une startup : rien n'en sort en dehors du livrable demandé, et jamais vers une autre startup traitée dans la même conversation.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; toute transmission à un investisseur, tout dépôt en data room et toute formalisation juridique est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
