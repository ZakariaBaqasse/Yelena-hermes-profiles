---
name: appliquer-patch
version: 1.0.0
description: >
  Applique un patch au grain fin sur ce dispositif — une nouvelle compétence, une compétence
  corrigée, un ajustement ciblé d'un fichier de fond (identité, mémoire, règles) — SANS
  réinstaller le pack entier. Déclenché par « applique le patch suivant », « voici un patch,
  applique-le », ou « consulte le pack et applique le patch suivant » (patch à récupérer
  depuis un chemin donné). Utilisable par tout agent qui porte cette compétence : cabinet
  de direction, assistant personnel, ou autre.
intention: >
  Permettre à l'opérateur (l'équipe ou l'assistant personnel qui le sert) de faire évoluer un
  agent déployé sans cycle de réinstallation complet — pendant que l'agent reste lui-même
  responsable de l'application sûre : backup systématique, validation de forme avant
  écriture, jamais de perte silencieuse, rapport de ce qui a changé.
maj: 2026-09-03
---

# Skill — appliquer-patch (mise à jour au grain fin, côté agent)

## Ce que fait cette compétence, et ce qu'elle ne fait pas

**Fait :** ajouter une compétence, corriger une compétence existante, ajuster une portion
ciblée d'un fichier de fond (identité, mémoire, règles de conduite), monter une version.

**Ne fait pas :** réinstaller le dispositif, toucher à autre chose que ce que le patch décrit,
appliquer un patch dont la forme est douteuse, écrire sans backup préalable.

## Les deux déclencheurs

1. **« Applique le patch suivant »** suivi du contenu du patch dans le message même.
2. **« Consulte le pack et applique le patch suivant »** — un chemin ou une référence est donné
   (dossier du pack, fichier PATCH), tu vas le lire toi-même avant d'appliquer.

Dans les deux cas, **le patch est fourni par l'opérateur** (l'équipe, ou l'assistant qui le sert).
Tu ne fabriques jamais de patch de ta propre initiative sous cette compétence — modifier ta
propre méthode reste un acte délibéré, décidé ailleurs, jamais une automatisation silencieuse.

## Format d'un patch

Un patch est un document avec un en-tête et une ou plusieurs **opérations**, dans cet ordre :

```markdown
# PATCH <identifiant court> — <titre en une ligne>
Portée : <une phrase : ce que ce patch change, pour qui>
Date : <date de rédaction>

## Opération 1 — ajouter-competence
Nom : <nom-de-la-competence>
Version : 1.0.0
---
<contenu complet du futur SKILL.md, avec son propre front-matter>
---

## Opération 2 — corriger-competence
Nom : <nom-de-la-competence-existante>
Niveau : patch | minor | major
Raison : <une phrase — pourquoi ce changement>
---
<contenu complet qui remplace le SKILL.md existant>
---

## Opération 3 — ajuster-fichier
Fichier : <ex. SOUL.md, USER.md, AGENTS.md, MEMORY.md — jamais un fichier hors du dispositif>
Chercher : "<texte exact à remplacer, tel quel>"
Remplacer par : "<nouveau texte>"

## Vérification
<ce que l'opérateur attend comme preuve que le patch a pris — optionnel mais recommandé>
```

Un patch peut contenir une seule opération ou plusieurs. Les opérations s'appliquent **dans
l'ordre où elles apparaissent**.

## Procédure d'application — dans cet ordre, sans en sauter une

1. **Lire le patch en entier avant d'agir.** Comprendre la portée annoncée en tête. Si une
   opération est ambiguë ou incomplète (nom de compétence manquant, contenu tronqué), **arrêter
   et le signaler** plutôt que de deviner.

2. **Vérifier la forme de chaque opération avant d'écrire quoi que ce soit :**
   - `ajouter-competence` / `corriger-competence` : le contenu a-t-il un front-matter valide
     (`name:`, `version:`, `description:`) ? Le `name:` correspond-il au nom annoncé ?
   - `ajuster-fichier` : le fichier ciblé existe-t-il dans le dispositif ? Le texte à chercher
     existe-t-il **exactement**, une seule fois ? S'il apparaît plusieurs fois ou pas du tout,
     s'arrêter et le dire — ne jamais remplacer « à peu près ».
   - Aucune opération ne touche un fichier hors du dispositif (pas de chemin système, pas de
     configuration de la plateforme qui l'héberge).

3. **Sauvegarder avant d'écrire.** Chaque fichier touché est copié avec un horodatage avant
   toute modification. Sans exception, y compris pour un « simple » ajout.

4. **Appliquer, opération par opération, dans l'ordre.**
   - `ajouter-competence` : créer le dossier de la compétence, y écrire le fichier.
   - `corriger-competence` : remplacer le contenu, **monter la version** selon le niveau indiqué
     (patch = correction, minor = ajout compatible, major = changement de comportement).
   - `ajuster-fichier` : remplacer le texte exact repéré à l'étape 2, rien d'autre autour.

5. **Mettre à jour le registre des compétences** si le dispositif en tient un (fichier récapitulant
   nom + version de chaque compétence) — pour que l'état affiché reste vrai.

6. **Rendre compte, une fois, en clair :**
   - Ce qui a été ajouté, corrigé, ajusté — en une ligne par opération.
   - Les versions avant/après pour ce qui a été corrigé.
   - Ce qui a été refusé et pourquoi, s'il y a eu un refus à l'étape 2.
   - Jamais de dump du contenu entier des fichiers modifiés dans la réponse — un résumé suffit ;
     le détail reste sur disque, consultable si demandé.

## Garde-fous — non négociables

- **Zéro écriture sans backup préalable.** Une opération sans sauvegarde possible ne s'applique
  pas — on le signale à la place.
- **Zéro devinette.** Une correspondance de texte ambiguë, un nom de compétence qui ne matche
  pas, un front-matter cassé : on s'arrête et on demande, on ne complète pas de son propre chef.
- **Un patch, une portée.** On applique ce que le patch décrit, rien de plus. Une bonne idée qui
  passe par la tête pendant l'application n'est pas dans le patch : elle se propose après, elle
  ne s'ajoute pas au passage.
- **Le rapport final ne divulgue pas la mécanique interne** à un tiers qui ne devrait pas la
  voir (cf. doctrine propre à chaque agent sur ce qui se nomme ou non devant l'extérieur) —
  cette compétence rapporte à celui qui a fourni le patch, dans les mêmes termes que lui.

## Chaînage

- Complète, côté agent, ce que l'outillage de l'opérateur fait côté poste de travail
  (normalisation de version, propagation d'une compétence entre agents). Cette compétence est
  la **capacité symétrique côté dispositif déployé** : recevoir et appliquer, sans réinstaller.
- Après application d'une compétence ajoutée ou corrigée touchant un comportement à risque
  (sécurité, validations), signaler à l'opérateur qu'une revérification est utile — cette
  compétence applique, elle ne teste pas la robustesse du résultat.
