"""Aides openpyxl pour generer un onglet ACQUISITION_MODEL conforme au
standard de mise en forme (voir references/layout-standard.md).

Usage type :
    from xlsx_helpers import *
    wb = Workbook(); ws = wb.active; ws.title = "ACQUISITION_MODEL"
    setup_sheet(ws, n_months=36)
    write_timeline(ws, start_month="2026-01")   # Year 0 en C, mois D->AM
    r = section_header(ws, row=8, label="SEGMENT SMEs")
    ...
Toutes les formules sont ecrites comme chaines '=...' (syntaxe anglaise,
separateur virgule) : Excel les calcule a l'ouverture.
"""

from openpyxl import Workbook  # noqa: F401
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------- constantes
NAVY = "002060"          # bandeaux de section / annees
MONTH_BAND = "D9E2F3"    # fond ligne des mois
GREY_CARRY = "D0CECE"    # report de cohorte (Returning / Churned)
BLUE_INPUT = "0432FF"    # police input
GREEN_LINK = "008000"    # police lien inter-onglet
TITLE_FILL = "DEEAF6"    # encadre titre

FMT_INT = '_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ '
FMT_PCT = "0%"
FMT_PCT1 = "0.0%"
FMT_MONTH = "mmm-yy"

F_INPUT = Font(color=BLUE_INPUT)
F_FORMULA = Font(color="000000")
F_LINK = Font(color=GREEN_LINK)
F_SECTION = Font(color="FFFFFF", bold=True)

FILL_NAVY = PatternFill("solid", fgColor=NAVY)
FILL_MONTH = PatternFill("solid", fgColor=MONTH_BAND)
FILL_GREY = PatternFill("solid", fgColor=GREY_CARRY)

_double = Side(style="double", color="000000")
TOTAL_BORDER = Border(top=_double, bottom=_double)

FIRST_MONTH_COL = 4        # D = mois 1 ; C = Year 0
YEAR0_COL = 3


def last_month_col(n_months=36):
    return FIRST_MONTH_COL + n_months - 1   # 36 mois -> col AM (39)


# ---------------------------------------------------------------- structure
def setup_sheet(ws, n_months=36):
    """Largeurs de colonnes, gel des volets, lignes de titre."""
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 3.5
    ws.column_dimensions[get_column_letter(YEAR0_COL)].width = 6.5
    for c in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 9
    ws.row_dimensions[3].height = 27
    ws.freeze_panes = "C7"
    ws["C1"] = "BUSINESS PLAN"
    ws["C1"].font = Font(bold=True, size=14)
    ws["C1"].fill = PatternFill("solid", fgColor=TITLE_FILL)
    ws["C2"] = "ACQUISITION_MODEL"
    ws["C2"].font = Font(bold=True, size=16)


def write_timeline(ws, start_month, n_months=36, n_years=3):
    """Ligne 5 = bandes d'annee fusionnees (Year 0 + Year 1..n),
    ligne 6 = mois en chaine EDATE. start_month = 'YYYY-MM' du mois 0."""
    from datetime import date
    y, m = (int(x) for x in start_month.split("-"))
    # Year 0 (colonne C seule)
    c0 = get_column_letter(YEAR0_COL)
    ws[f"{c0}5"] = "Year 0"
    _style_year(ws[f"{c0}5"])
    ws[f"{c0}6"] = date(y, m, 1)
    # bandes annuelles
    col = FIRST_MONTH_COL
    for yr in range(1, n_years + 1):
        first, last = col, col + 11
        ws.merge_cells(start_row=5, start_column=first, end_row=5, end_column=last)
        cell = ws.cell(row=5, column=first, value=f"Year {yr}")
        _style_year(cell)
        for c in range(first, last + 1):
            _style_year(ws.cell(row=5, column=c))
        col = last + 1
    # mois : chaine EDATE depuis C6
    for c in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
        prev = get_column_letter(c - 1)
        ws.cell(row=6, column=c, value=f"=EDATE({prev}6,1)")
    for c in range(YEAR0_COL, last_month_col(n_months) + 1):
        cell = ws.cell(row=6, column=c)
        cell.number_format = FMT_MONTH
        cell.fill = FILL_MONTH
        cell.alignment = Alignment(horizontal="center")
    ws[f"{c0}6"].font = F_INPUT   # le mois 0 est l'input pivot


def _style_year(cell):
    cell.fill = FILL_NAVY
    cell.font = F_SECTION
    cell.alignment = Alignment(horizontal="center")


def section_header(ws, row, label, n_months=36):
    """Bandeau navy sur A:derniere colonne. Retourne row+2 (ligne vide comprise)."""
    ws.cell(row=row, column=1, value=label)
    for c in range(1, last_month_col(n_months) + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = FILL_NAVY
        cell.font = F_SECTION
    return row + 2


# ---------------------------------------------------------------- lignes
def write_row(ws, row, label, unit, kind="formula", fmt=FMT_INT,
              values=None, formula=None, n_months=36, year0=None,
              grey=False, total=False):
    """Ecrit une ligne complete.
    kind   : 'input' | 'formula' | 'link'
    values : valeur unique (repetee) ou liste par mois (inputs)
    formula: patron avec {col} = lettre de la colonne courante et
             {prev} = lettre de la colonne precedente, ex.
             '=ROUND({prev}35*{col}30,0)'
    year0  : valeur seed en colonne C (ou None)
    """
    font = {"input": F_INPUT, "formula": F_FORMULA, "link": F_LINK}[kind]
    ws.cell(row=row, column=1, value=label)
    ws.cell(row=row, column=2, value=unit)
    if year0 is not None:
        c = ws.cell(row=row, column=YEAR0_COL, value=year0)
        c.font = F_INPUT if kind == "input" or not isinstance(year0, str) else font
    for i in range(n_months):
        colno = FIRST_MONTH_COL + i
        cell = ws.cell(row=row, column=colno)
        if formula is not None:
            cell.value = formula.format(col=get_column_letter(colno),
                                        prev=get_column_letter(colno - 1))
        elif isinstance(values, (list, tuple)):
            cell.value = values[i] if i < len(values) else values[-1]
        else:
            cell.value = values
        cell.font = font
        cell.number_format = fmt
        if grey:
            cell.fill = FILL_GREY
        if total:
            cell.border = TOTAL_BORDER
    if total:
        for c in (1, 2, YEAR0_COL):
            ws.cell(row=row, column=c).border = TOTAL_BORDER
        ws.cell(row=row, column=1).font = Font(bold=True)
    return row + 1


def penetration_vector(ws, first_row, rates, fmt=FMT_PCT1):
    """Ecrit le vecteur de penetration en colonne A a cote des lignes de
    cohortes (police bleue, aligne droite). rates = liste de floats."""
    for i, rate in enumerate(rates):
        cell = ws.cell(row=first_row + i, column=1, value=rate)
        cell.font = F_INPUT
        cell.number_format = fmt
        cell.alignment = Alignment(horizontal="right")
