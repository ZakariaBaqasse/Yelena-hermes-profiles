---
name: "bp-acquisition-tab"
version: "1.0.0"
description: "Génère l'onglet ACQUISITION_MODEL Excel d'un BP (formules actives), 6 familles de moteurs de volumes."
maj: 2026-09-03
---

# Onglet ACQUISITION d'un BP — générateur

## Ce que produit ce skill

Un onglet Excel `ACQUISITION_MODEL` : le compilateur amont d'un BP. Il prend des hypothèses de go-to-market (commerciaux, budget pub, churn, plan de pose) et compile une seule sortie : la base active mois par mois (clients, utilisateurs, agents ou parc). Le P&L ne lit que les lignes de total de cet onglet.

Deux principes gouvernent tout :
- **Le canal est l'unité de composition.** On ne modélise jamais "l'acquisition" en bloc : des canaux indépendants juxtaposés, puis consolidés.
- **Séparation moteur / interface.** Le moteur peut être complexe ; il ne communique avec l'aval que par des lignes de total à adresse stable.

## Workflow obligatoire

1. **Qualifier le business model** avec l'arbre de décision ci-dessous → choisir la ou les familles de moteur.
2. **Collecter les inputs manquants** auprès de l'utilisateur (AskUserQuestion si disponible) avec la checklist de la fiche moteur. Ne jamais inventer un CAC, un churn ou une productivité commerciale : demander ou proposer un défaut explicitement marqué comme hypothèse à valider.
3. **Lire la fiche moteur** correspondante dans `references/` (formules exactes ligne par ligne).
4. **Lire `references/layout-standard.md`** (mise en forme normative, non négociable).
5. **Construire le .xlsx avec openpyxl et des formules Excel actives.** Jamais de valeurs calculées en Python et collées en dur : l'utilisateur doit pouvoir changer un input bleu et voir tout recalculer. Utiliser `scripts/xlsx_helpers.py` pour les styles et la timeline.
6. **Exécuter les contrôles** de `references/controles.md` avant livraison.

## Arbre de décision maître

Poser ces questions dans l'ordre. Chaque feuille pointe vers une fiche de `references/`.

```
Q1. Quelle ressource l'entreprise acquiert-elle ?
├─ Des CLIENTS / UTILISATEURS (une base commerciale)
│   Q2. Le revenu est-il réalisé à plein dès le 1er mois d'un client ?
│   ├─ OUI (abonnement plat, accès)          → moteur-base-recurrente.md
│   └─ NON (usage, transaction, montée en charge)
│       Q3. Marché à DEUX FACES (offre + demande à modéliser) ?
│       ├─ OUI                                → moteur-marketplace-biface.md
│       └─ NON                                → moteur-usage-cohortes.md
│
├─ Des ACTIFS PHYSIQUES / UN RÉSEAU (bornes, magasins, agents, POS)
│   Q4. L'actif est-il FINANCÉ (dette/leasing, échéancier) ?
│   ├─ OUI                                    → moteur-actifs-finances.md
│   └─ NON
│       Q5. L'unité acquise est-elle un OBJET posé par l'opérateur
│           (borne, casier, magasin) ou un HUMAIN recruté (agent) ?
│       ├─ OBJET / plan de pose               → moteur-rollout-actifs.md
│       │    (même avec attrition : le taux de survie est une
│       │     correction intégrée à ce moteur, pas un changement de moteur)
│       └─ HUMAIN / recrutement + churn       → moteur-reseau-agents.md
```

Cas composites (fréquents) : une fintech avec terminaux = usage-cohortes + bloc parc matériel (inclus dans la fiche) ; un business multi-activités = plusieurs moteurs empilés dans le même onglet ou dans deux onglets. Pour composer librement des canaux hétérogènes, lire `references/catalogue-briques.md` (briques B1-B8 : génération, rétention, rampe, entonnoir).

## Conventions par défaut (appliquer sans redemander)

- **Horizon** : Year 0 = 1 colonne d'amorçage (M0, seeds) + 36 mois mensuels (3 bandes annuelles). Colonnes C (Year 0) puis D→AM.
- **Dates** : premier mois en input, puis chaîne `=EDATE(préc;1)` — jamais de dates codées en dur.
- **Libellés** : anglais (New Users, Returning, Churned, Total Active), cohérents avec les BP existants.
- **Devise** : demander à l'utilisateur (EUR ou FCFA selon le marché).
- **Segments** : si l'activité a plusieurs populations, dupliquer le bloc en miroir strict par segment ; seuls les inputs changent.
- **Sortie** : bloc de synthèse en pied d'onglet = `Total New` + `Total Active` (consolidés et par segment). C'est le seul point lu par l'aval.
- **Anonymat** : ne jamais mentionner les entreprises des modèles de référence dans le fichier généré. Les fiches sont des frameworks, pas des exemples à citer.

## Corrections structurelles appliquées par défaut

Le corpus d'origine contient une dette de conception récurrente. Ce skill génère la version corrigée (et le note en commentaire de cellule si utile) :

1. **Organique indexé sur la base active**, pas sur le flux : `New (Organic) = ROUND(coeff × Total_Active(M-1); 0)`. Un effet réseau dépend de la base installée.
2. **Rampe de pénétration plafonnée** : le vecteur de pénétration sature à un plateau paramétrable (input bleu, défaut 100 % mais exposé pour être abaissé).
3. **Attrition sur tout parc loué ou réseau humain** : proposer un taux de survie/churn même si l'utilisateur n'y a pas pensé ; ne l'omettre que sur décision explicite.
4. **Churn câblé segment par segment** : chaque bloc référence SON taux, jamais celui du bloc voisin (bug observé dans le corpus).
5. **Constantes d'exploitation en inputs visibles** (jours ouvrés, coût unitaire de reach), jamais enfouies dans une formule.
6. **Réactivation optionnelle** : si le business le justifie (transactionnel), proposer un taux de réactivation des churned.

## Interaction avec l'utilisateur avant construction

Toujours confirmer avant de générer : famille(s) de moteur retenue(s), segments, canaux actifs par segment, devise, mois de démarrage, et les hypothèses chiffrées manquantes de la checklist de la fiche moteur. Une seule salve de questions, groupée. Si l'utilisateur fournit un brief complet, ne confirmer que les ambiguïtés réelles.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/layout-standard.md` | Toujours, avant de construire |
| `references/controles.md` | Toujours, avant de livrer |
| `references/moteur-base-recurrente.md` | Abonnement / accès récurrent, valeur pleine dès M1 |
| `references/moteur-usage-cohortes.md` | Usage/transaction avec montée en charge, ± parc matériel |
| `references/moteur-marketplace-biface.md` | Offre + demande, transactionnel |
| `references/moteur-rollout-actifs.md` | Parc physique sans churn, plan de pose |
| `references/moteur-reseau-agents.md` | Réseau humain avec churn, double vue roulante + cohortes |
| `references/moteur-actifs-finances.md` | Actifs financés, millésimes, service de dette |
| `references/catalogue-briques.md` | Cas composite ou hors familles ; catalogue B1-B8 |
| `scripts/xlsx_helpers.py` | Constantes de style + fonctions openpyxl (timeline, bandeaux, formats) |
