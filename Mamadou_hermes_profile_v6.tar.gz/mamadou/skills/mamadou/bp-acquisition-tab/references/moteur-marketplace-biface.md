# Moteur MARKETPLACE BI-FACE (offre + demande)

## Quand l'utiliser
Marché à deux faces : une demande (acheteurs, éventuellement segmentée) et une offre (vendeurs) à modéliser séparément, revenu transactionnel (GMV × take rate calculés en aval). Typique : marketplace de biens, distribution B2B, plateformes de mise en relation. Motion souvent agent-led (force de vente terrain) sur les marchés à forte informalité.

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; seeds Year 0 (acheteurs par segment, vendeurs) — les labelliser comme base préexistante.
**Demande** : segments d'acheteurs (ex. informel / formel) + mix (%) ; zones × agents par zone × acheteurs/agent/mois ; budget pub + CAC par segment ; coefficients referral et organic (sur base active) ; churn par segment (ou repeat-rate si transactionnel pur).
**Offre** : driver d'onboarding vendeurs (force de vente dédiée × vendeurs/commercial, ou funnel propre) ; churn vendeurs ; seed vendeurs.
**Liquidité (recommandé)** : ratio offre/demande cible, fill rate — pour confronter les deux faces.

## Structure de l'onglet

### Bloc 1 — Hypothèses générales (inputs bleus)
```
Online Advertising Spend  €  input
% segment 1..k            %  inputs (le dernier = 1 - somme des autres)
Zones                     #  input
Managers / Agents per zone #  inputs
Total agents              #  = zones * (agents/zone + managers/zone)
Buyers per agent          #  input
% segment (répartition force terrain)  %  inputs
```

### Bloc 2..k+1 — Demande : un bloc MIROIR par segment d'acheteurs
```
En-tête navy "BUYERS — SEGMENT k"
(vide)
New buyers From Agents   #  = ROUNDUP([X]$‹total_agents› * [X]$‹buyers/agent› * [X]$‹%seg›, 0)
(vide)
Advertising Spend        €  = [X]$‹spend› * [X]$‹%seg›
Paid CAC                 €  input
New buyers (Advertising) #  = ROUND([X]‹spend_seg› / [X]‹CAC›, 0)
(vide)
Referral coefficient     %  input
New buyers From Referral #  = ROUND([X-1]‹total_active_seg› * [X]‹coeff_ref›, 0)
(vide)
Organic coefficient      %  input
New buyers From Organic  #  = ROUND([X-1]‹total_active_seg› * [X]‹coeff_org›, 0)
(vide)
Churn rate               %  input (par segment ; l'informel churne plus que le formel)
(vide)
New Buyers (total)       #  = SUM(agents, paid, referral, organic)   ← double trait
Returning buyers         #  = [X-1]‹total_active_seg›   (Year 0 = seed) ← fond gris
Churned Buyers           #  = -ROUND([X-1]$‹total_active_seg› * [X]‹churn›, 0) ← fond gris
Total Active Buyers      #  = SUM(new, returning, churned)           ← double trait
```

### Bloc offre — Vendeurs
```
En-tête navy "SELLER ACQUISITION"
(vide)
Seller Churn             %  input
Direct Sales (headcount) #  input
Sellers per Direct Sales #  input
New Sellers              #  = [X]‹headcount› * [X]‹sellers/DS›
Returning sellers        #  = [X-1]‹total_active_sellers›  (Year 0 = seed)
Churned sellers          #  = -ROUND([X-1]$‹total_active_sellers› * [X]$‹seller_churn›, 0)
Total Active Sellers     #  = SUM(new, returning, churned)            ← double trait
```
Même convention de signe que la demande (churn négatif, ROUND) — ne pas mélanger ROUND et ROUNDDOWN entre blocs.

### Bloc liquidité (recommandé)
```
En-tête navy "LIQUIDITY"
(vide)
Supply capacity          #  = [X]‹active_sellers› * ‹débit/vendeur (input)›
Demand potential         #  = [X]‹active_buyers_total› * ‹fréquence (input)›
Served demand            #  = MIN(demand, supply)
Fill rate                %  = served / demand
```
La GMV aval doit lire `Served demand`, pas la demande brute.

### Bloc final — Synthèse
`Total New Buyers`, `Total Active Buyers` (consolidés), `Total Active Sellers`, `Fill rate`.

## Pièges connus du corpus (corrigés par défaut)
- Referral/organic sur le flux (agents+paid) → toujours sur la base active (densité de réseau).
- Churn plat sur stock agrégé pour un business transactionnel : simplification v1 acceptable, mais si le ré-achat est le vrai moteur, proposer des cohortes de repeat-rate (catalogue-briques B6).
- Faces indépendantes sans couche de liquidité → la GMV exige les deux faces + un fill rate.
- Seeds non sourcés → toujours en input bleu labellisé "existing base".
- Brique activation absente (inscrit ≠ premier achat) → proposer un taux de première commande.
