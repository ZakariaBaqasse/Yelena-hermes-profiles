# Catalogue de briques (composition libre)

Pour les business models composites ou hors familles : chaque canal se construit avec une brique de GÉNÉRATION, éventuellement combinée à une brique de RÉTENTION et/ou de RAMPE. Un onglet = N moteurs côte à côte + une addition.

## Briques de GÉNÉRATION — d'où viennent les nouveaux ?

**B1 — Driver commercial (headcount × productivité)**
`New = effectif commercial × unités/mois/commercial`
Quand : force de vente terrain. Piège : envisager une rampe de productivité pour les nouveaux embauchés.

**B2 — Driver média (budget → clients)**
Forme simple : `New = spend / CAC`. Forme entonnoir : `New = (budget / coût_unité_reach) × reach_unitaire × taux_conversion`.
Quand : achat média, performance, influence. Piège : si le budget vit dans Assumptions, lien vert obligatoire.

**B3 — Driver partenaire / sell-through**
`New = volume plateforme tierce × % capté`
Quand : distribution via des plateformes non contrôlées. Piège : le volume tiers est une hypothèse forte non pilotable — l'isoler en input visible.

**B4 — Uplift organique / referral**
`New (Organic) = ROUND(coeff × Total_Active(M-1), 0)` — TOUJOURS indexé sur la base active, jamais sur le flux d'acquisition du mois (correction par défaut de ce skill).

## Briques de RÉTENTION — comment la base évolue ?

**B5 — Cumul roulant à churn plat (le défaut)**
```
Returning = Total actif M-1
Churned   = -ROUND(Total_actif(M-1) × churn, 0)
Total     = New + Returning + Churned
```
Quand : érosion régulière, pas besoin de tracer l'âge. Piège : pas de réactivation ; churn constant même en early-life.

**B6 — Cohortes millésimées (matrice diagonale)**
Chaque mois d'acquisition = une ligne ; la cohorte vieillit via `OFFSET(cellule_au-dessus, 0, -1, 1, 1)` ; un bucket terminal accumule les cohortes âgées (et absorbe le churn si applicable). Auto-contrôle obligatoire : somme de la matrice = base active.
Quand : le comportement dépend de l'âge (rétention décroissante, montée en usage, repeat-rate transactionnel). Piège : lourd — ne l'introduire que si le taux plat fausse vraiment la courbe.

## Brique de RAMPE — l'actif est-il productif immédiatement ?

**B7 — Montée en charge décalée**
Forme staggered : chaque unité rejoue la même rampe décalée de son mois d'ouverture (référence à une colonne antérieure). Forme pénétration : `Actifs pondérés = SOMMEPROD(vecteur_pénétration ; unités par âge)`, vecteur = suite de % croissants.
Quand : magasins, bornes, POS, agents. Piège : le vecteur doit plafonner (plateau paramétrable, souvent < 100 %).

## Brique d'ENTONNOIR

**B8 — Conversion d'un flux physique**
`Clients = trafic × taux_conversion × intensité` (ex. visites/jour × conversion × jours ouvrés).
Quand : point de vente, funnel web. Piège : les constantes d'exploitation (jours ouvrés) restent des inputs visibles.

## Grammaire de composition

1. **Un canal = un bloc autonome** : bandeau navy, inputs bleus dessous, moteur (1 brique génération ± rétention/rampe), ligne de total en bas.
2. **Segments miroirs** : plusieurs populations = duplication du même bloc à l'identique, seuls les inputs changent.
3. **Consolidation** : une ligne Total par canal, puis un Total général = somme des totaux. Seul point de sortie vers l'aval.
4. **Itérer sans casser** : ajouter/retirer/remplacer une brique ne doit jamais changer l'adresse des lignes de total (contrat d'interface avec le P&L).

## Où vivent les hypothèses ?

- En ligne dans l'onglet (défaut) : simple, auto-portant.
- Colonnes-triplet dédiées (actifs financés) : montant/taux/durée par ligne.
- Control Panel / Assumptions externe avec multiplicateurs de scénario : le mieux pour piloter des scénarios — liens verts obligatoires.
Règle : tout levier de scénario = un input bleu unique référencé partout ; réutilisé par plusieurs canaux → le sortir dans Assumptions.
