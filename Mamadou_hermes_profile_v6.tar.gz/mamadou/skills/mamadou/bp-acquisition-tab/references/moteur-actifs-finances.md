# Moteur ACTIFS FINANCÉS (millésimes + service de dette)

## Quand l'utiliser
La ressource productive est un stock d'actifs durables (véhicules, machines, équipements) financés par dette ou leasing, approvisionnés par vagues et activés progressivement. L'onglet convertit le plan d'acquisition en échéancier de trésorerie mensuel. Les 4 questions discriminantes : stock durable ? financé ? activation échelonnée ? coût étalé ? Quatre oui = ce moteur.

## Lexique générique
actif productif (unité) · parc (stock) · approvisionnement (livraisons par lots) · activation (l'actif commence à produire) · millésime/vintage (lot d'actifs partageant une date d'activation) · triplet de financement (montant, coût du capital, maturité) · coût de portage initial (charge avant activation).

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; horizon (les échéanciers peuvent dépasser 36 mois : prévoir des colonnes d'extension masquées, jamais supprimées).
**Approvisionnement** : calendrier de livraisons par lot (inputs en dur, souvent trimestriels) ; règle d'activation (délai livraison → mise en production).
**Financement (par millésime)** : triplet montant unitaire / taux annuel / maturité (mois) ; coût de portage initial (montant, un-fois ou lissé) ; facteur de taxe éventuel (1 + TVA).
**Sorties attendues** : service de dette mensuel (vue cash et vue lissée), parc actif.

## Structure de l'onglet
Ce moteur déroge partiellement au layout standard : colonnes d'hypothèses par actif E/F/G (triplet de financement) intercalées entre les libellés et la timeline. Garder les bandeaux navy et le code couleur standard.

| Colonne | Rôle |
|---|---|
| A | libellés |
| B | unité |
| C/D/E | triplet de financement : montant · taux · maturité (inputs bleus, une ligne par millésime) |
| F → timeline | mois |

### Étage 1 — Approvisionnement → activation
```
En-tête navy "SUPPLY & ACTIVATION"
(vide)
Deliveries (lot)     #  inputs en dur aux mois de livraison
Activation rule      —  = IF(COUNTA(plage écoulée) < délai, 0, lot)   (un actif non activé ne coûte rien)
(vide)
Matrice d'activation : 1 ligne par millésime (index 1..n en col. A)
  chaque millésime démarre à sa date propre → remplissage triangulaire
Active units (month) #  = SUM(lignes de millésimes)                    ← double trait
Total fleet          #  = parc initial + Active units cumulés          ← double trait
```

### Étage 2 — Service de la dette (matrices triangulaires parallèles)
Une ligne par millésime, chaque ligne reprend l'index de sa ligne d'activation. Échéance mensuelle type :
```
échéance = montant/maturité + taux/12 * principal_restant + portage
```
Produire DEUX matrices parallèles plutôt qu'une formule à arbitrage caché :
- **Vue cash** : coût de portage imputé en une fois au premier mois du millésime.
- **Vue lissée** : portage réparti sur la maturité (vérité charge économique).

### Bloc final — Synthèse (contrat d'interface, fonds vert clair)
```
Monthly repayments (cash view)      = SUM(matrice cash)      ← lu par le Cashflow
Monthly repayments (smoothed view)  = SUM(matrice lissée)    ← lu par le P&L
Initial carrying cost               = formule dédiée
Active units / Total fleet          = repris de l'étage 1
```

## Pièges connus du corpus (corrigés par défaut)
- L'arbitrage cash vs charge doit rester visible (deux blocs), jamais enfoui dans une formule unique.
- Colonnes hors horizon : masquer (largeur 0), ne jamais supprimer — les échéanciers courent au-delà.
- Facteur de taxe en cellule helper nommée, pas en dur dans les formules.
- Le lag opérationnel (livraison → activation) et le lag financier (activation → 1re échéance) sont deux paramètres distincts.
- Vérifier que la somme des lignes de millésimes = livraisons cumulées activées (auto-contrôle triangulaire).
