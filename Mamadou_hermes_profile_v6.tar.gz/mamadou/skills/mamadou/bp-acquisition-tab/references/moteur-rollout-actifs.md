# Moteur ROLLOUT D'ACTIFS (parc physique, plan de pose, sans churn)

## Quand l'utiliser
Le driver de croissance est le déploiement physique d'actifs décidé par l'opérateur (bornes, magasins, kiosques, points de service), pas une conversion marketing. Il n'y a pas de funnel : les inputs sont des nombres d'unités posées. La valeur d'un actif monte avec son âge (rampe de maturation par site, 6-24 mois typiques).

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; seed Year 0 (parc initial).
**Plan de pose** : nombre d'unités posées par mois, par régime et par zone (inputs directs, souvent trimestriels).
**Segmentation** : régimes de propriété (loué / possédé) si les logiques capex diffèrent ; zones (ville principale / secondaire) si le potentiel diffère.
**Rampe** : vecteur de pénétration par âge (part du potentiel captée à 0, 1, 2, ... n mois), différencié par régime — un actif possédé/qualifié monte souvent plus vite qu'un loué. Profondeur typique : 12 mois.
**Attrition (correction par défaut)** : taux de survie du parc (panne, retrait, fin de contrat), au moins pour les unités louées.
**Conversion en valeur** : cible d'unités de valeur par actif à 100 % (déposants, clients, transactions) — l'exposer ici en input, même si la multiplication vit en aval.

## Structure de l'onglet

### Un bloc MIROIR par régime (loué / possédé)
```
En-tête navy "RENTED UNITS" (resp. "OWNED UNITS")
(vide)
# New units — zone A     #  input (plan de pose)
# New units — zone B     #  input
# New units (month)      #  = SUM(zones)
Total fleet (cumulative) #  = [X-1]‹total_fleet› + [X]‹new_month›  (Year 0 = seed) ← double trait
Total — zone A (cum.)    #  = [X-1] + [X]‹new_zone_A›
Total — zone B (cum.)    #  = [X-1] + [X]‹new_zone_B›
(vide)
Penetration rate — libellé (police #0432FF)
  âge 0   ‹p0 %›   #  = [X]‹new_month›
  âge 1   ‹p1 %›   #  = OFFSET(‹cellule au-dessus›, 0, -1, 1, 1)
  ...     ...      #  idem (la cohorte vieillit d'une colonne à l'autre)
  âge n+  ‹pn %›   #  = OFFSET(‹au-dessus›, 0, -1, 1, 1) + [X-1]‹cette ligne›  (bucket terminal)
Total cohortes      #  = SUM(lignes d'âge)   ← doit ÉGALER Total fleet (auto-contrôle) ← double trait
```
Le vecteur de pénétration vit en colonne A (police #0432FF, `0.0%`), une valeur par ligne d'âge. La sous-table stocke des effectifs ; la ligne pondérée est optionnelle :
```
Weighted active units  #  = SOMMEPROD(vecteur_pénétration ; lignes d'âge)  → à exposer si l'aval consomme la base pondérée
```

### Avec attrition (correction par défaut sur le parc loué)
Transformer le cumul monotone : `Total fleet = ROUND([X-1]‹fleet› * taux_survie, 0) + [X]‹new›`, et injecter la perte dans le bucket terminal des cohortes pour préserver l'auto-contrôle.

### Bloc final — Synthèse
`Total fleet` (tous régimes), `Weighted active units` si calculée.

## Pièges connus du corpus (corrigés par défaut)
- Aucune attrition : un parc qui ne fait que croître est irréaliste dès qu'il y a location ou usure → taux de survie par régime.
- Pénétration plafonnant universellement à 100 % → plateau paramétrable, éventuellement < 100 %.
- Pas de plafond de marché : ajouter si pertinent un cap d'unités de valeur adressables par zone (TAM local) et confronter la base pondérée à ce cap.
- Conversion actif → valeur implicite et cachée en aval → l'expliciter en input ici.
- Seed Year 0 en dur : une erreur d'amorçage se propage sur toute la chaîne cumulative — vérifier deux fois.
