# Contrôles de cohérence avant livraison

Exécuter systématiquement. Les contrôles programmables se font en relisant le fichier avec openpyxl (formules) et, si LibreOffice est disponible, en recalculant (`libreoffice --headless --convert-to xlsx`) puis en relisant les valeurs.

## Contrôles structurels (sur les formules)

- [ ] Une seule logique par ligne : la formule de la colonne D se recopie sans rupture jusqu'à AM (mêmes références relatives, pas de valeur en dur au milieu).
- [ ] Dates : C6 = input, puis chaîne `=EDATE(préc,1)` continue jusqu'à la dernière colonne.
- [ ] Chaque `New (total)` de segment = somme exacte de SES canaux (aucun oublié, aucun canal du voisin).
- [ ] Total général de synthèse = somme de tous les segments (vérifier que les plages SUM ont absorbé toutes les lignes, surtout après insertion).
- [ ] Churn câblé segment par segment : chaque bloc référence SON taux (bug classique : décalage d'une ligne qui fait pointer un segment sur le churn du voisin).
- [ ] Churn appliqué sur la base M-1, jamais sur la base M.
- [ ] Auto-contrôle des cohortes : Total cohortes = base active (ou parc cumulé) sur TOUTES les colonnes.
- [ ] `OFFSET` ne sort jamais de la grille (première colonne de mois).
- [ ] ROUND sur tous les effectifs.

## Contrôles d'hypothèses

- [ ] Les clés de répartition (% pub, % sales) somment à 100 % par période.
- [ ] Vecteurs de pénétration : croissants, saturent au plateau (jamais > 100 %).
- [ ] Churn mensuel réaliste (un churn très bas ou fortement décroissant = hypothèse à faire valider).
- [ ] Base active jamais négative sur l'horizon.
- [ ] Seeds Year 0 labellisés et sourcés (input bleu, commentaire "existing base").
- [ ] Organique/referral indexés sur la base active M-1.

## Contrôles de forme

- [ ] Code couleur exact : bleu #0432FF inputs, noir formules, vert #008000 liens inter-onglets (aucun lien en noir), bandeaux navy #002060, aucun fond orange/jaune.
- [ ] Doubles traits haut+bas sur toutes les lignes de total.
- [ ] Largeurs : A=26, B=3.5, C=6.5, mois=9 uniformes.
- [ ] Volets figés en C7.
- [ ] Respiration : 1 ligne vide après chaque bandeau, 1 entre sous-groupes, 2 entre grands blocs.
- [ ] Formats : comptable zéros en `-`, `%`, `mmm-yy`.
- [ ] Aucun nom d'entreprise des modèles de référence dans le fichier.

## Contrôle final

Ouvrir le fichier relu : vérifier sur 3 colonnes échantillons (D, O, AM) que les équations de stock tiennent : `Total Active(M) = New(M) + Active(M-1) - Churned(M)` à l'arrondi près.
