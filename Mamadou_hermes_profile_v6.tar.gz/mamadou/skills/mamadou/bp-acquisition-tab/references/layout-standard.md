# Standard de mise en forme — onglet ACQUISITION_MODEL

Spec normative issue du consensus des BP de référence. La reproduire exactement : la cohérence visuelle entre onglets et entre BP est ce qui rend les modèles auditables.

## 1. Ossature de l'onglet

| Ligne | Contenu |
|---|---|
| 1-2 | Titre : `C1` = "BUSINESS PLAN" (gras 14), `C2` = "ACQUISITION_MODEL" (gras 16), encadré pointillé fin A1:C3 |
| 3 | vide (hauteur ~27) |
| 4 | vide |
| 5 | Bandes d'année fusionnées : "Year 0" = C seule ; "Year 1" = D:O ; "Year 2" = P:AA ; "Year 3" = AB:AM. Fond navy #002060, texte blanc gras, centré |
| 6 | Mois : C6 = date du mois 0 (input), puis `=EDATE(C6;1)` tiré jusqu'à AM. Format `mmm-yy`, fond #D9E2F3 |
| 7 | vide (ligne d'appui) |
| 8+ | Contenu (blocs métier) |

- **Volets figés** : `C7` (colonnes A:B + lignes 1-6 gelées).
- **Year 0** = colonne C unique : porte les seeds (base préexistante). Si aucune base préexistante, la colonne existe quand même avec des zéros — l'horizon est toujours Year 0 + 36 mois.

## 2. Grille de colonnes (largeurs openpyxl)

| Colonne | Largeur | Rôle |
|---|---|---|
| A | 26 | Libellés (seule zone de texte) |
| B | 3.5 | Unité seule : `#` / `%` / `€` (ou FCFA) |
| C | 6.5 | Year 0 (étroite, mois unique) |
| D → AM | 9 (uniformes) | Timeline mensuelle. Jamais de largeur variable : l'indentation se fait par lignes vides |

Hauteurs de ligne : standard (ne pas fixer), sauf ligne 3 ≈ 27.

## 3. Grammaire visuelle

| Élément | Style |
|---|---|
| En-tête de section (canal, segment) | Fond navy #002060, texte blanc gras, sur A:AM |
| Input saisi | Police bleue #0432FF |
| Formule / calcul | Police noire #000000 |
| Lien vers un autre onglet | Police verte #008000 — obligatoire, l'audit visuel repose dessus |
| Cellules de report de cohorte (Returning / Churned) | Fond gris #D0CECE, optionnel mais recommandé |
| Vecteur de pénétration (col. A des sous-tables de cohortes) | Police #0432FF, format `0.0%`, aligné à droite |
| Totaux et sous-totaux | Bordure **double trait** haut + bas |
| Fonds orange / jaune de surlignage | Interdits — transparents |

## 4. Respiration (lignes vides)

- 1 ligne vide après chaque en-tête de section.
- 1 ligne vide entre chaque sous-groupe logique d'un bloc (Paid → Sales → Organic → Churn → New → Rétention).
- 2 lignes vides entre grands blocs (segments, canaux).
- Jamais deux sections collées.

## 5. Formats de nombres

| Type | Format |
|---|---|
| Effectifs / montants entiers | `_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ ` (comptable : zéros en `-`, négatifs entre parenthèses) |
| Pourcentages | `0%` (ou `0.0%` pour les vecteurs de pénétration) |
| Mois | `mmm-yy` |

## 6. Règles de construction des formules

- **Une seule logique par ligne**, posée dans la première colonne de mois (D) puis recopiée jusqu'à AM. Aucune rupture au changement d'année, aucune valeur en dur au milieu d'une ligne calculée.
- Verrouiller avec `$` les références aux lignes d'inputs partagés (`D$9`) pour que la recopie horizontale tienne.
- `ROUND(...;0)` sur tout effectif : pas de fraction d'utilisateur, d'agent ou de borne.
- Tout levier de scénario = un input bleu unique, référencé partout. Jamais de nombre magique.
- Si un input est réutilisé par plusieurs canaux ou vit dans un onglet Assumptions : lien vert.

## 7. Bloc de synthèse (pied d'onglet)

Dernières lignes de l'onglet, précédées de 2 lignes vides :
- `Total New <unité>` = somme des nouveaux de tous les segments/canaux.
- `Total Active <unité>` = somme des bases actives.
- Chaque ligne : bordure double trait haut + bas. C'est le contrat d'interface : l'aval (P&L, KPIs) ne lit que ces adresses.

## 8. Implémentation openpyxl

Utiliser `scripts/xlsx_helpers.py` : constantes de couleurs/formats et fonctions `setup_sheet`, `write_timeline`, `section_header`, `style_input`, `style_formula`, `style_link`, `total_border`. Écrire les formules comme chaînes commençant par `=` (openpyxl les stocke telles quelles ; Excel calcule à l'ouverture). Séparateur d'arguments : `,` (openpyxl exige la syntaxe anglaise ; Excel localise à l'affichage).
