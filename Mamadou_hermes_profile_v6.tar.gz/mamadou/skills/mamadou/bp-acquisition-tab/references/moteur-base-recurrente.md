# Moteur BASE RÉCURRENTE (abonnement / accès)

## Quand l'utiliser
La société monétise une base d'abonnés ou d'utilisateurs actifs récurrente (SaaS, plateforme de données, accès par abonnement), acquise via un mix paid / force de vente / organique, avec un ou plusieurs segments clients. La valeur d'un client est réputée pleine dès son premier mois (sinon → moteur-usage-cohortes).

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; seeds Year 0 par segment (0 si lancement).
**Segmentation** : nombre et noms des segments ; pour chacun, canaux actifs (Paid / Sales / Organic) ; segment complet ou réduit (mono-canal).
**Drivers (par segment, par an)** : budget pub total + clé de répartition par segment (%) ; CAC payant ; taille force de vente + users ajoutés/mois/commercial + clé de répartition ; coefficient organique (sur base active).
**Rétention** : churn mensuel par segment (peut évoluer par palier annuel) ; brique activation nécessaire (inscrit → payant) ?

## Structure de l'onglet

### Bloc 1 — Drivers partagés (en tête, inputs bleus)
```
Advertising spend        €   input
% segment 1..k           %   inputs (somme = 100 %)
Direct Sales Team        #   input
Users Added/Month/Sales  #   input
% sales segment 1..k     %   inputs (somme = 100 %)
```

### Bloc 2..k+1 — Un bloc MIROIR par segment
Structure identique pour chaque segment ; seuls les inputs changent. `[X]` = colonne courante, `[X-1]` = précédente.

```
En-tête navy "SEGMENT k"
(vide)
Advertising spend   €   = [X]$‹spend› * [X]$‹%seg›
Paid CAC            €   input
New Users (Paid)    #   = ROUND([X]‹spend_seg› / [X]‹CAC›, 0)
(vide)
New Users (Sales)   #   = ROUND([X]$‹team› * [X]$‹users/mois› * [X]$‹%sales_seg›, 0)
(vide)
Organic coefficient %   input
New Users (Organic) #   = ROUND([X-1]‹total_active_seg› * [X]‹coeff›, 0)
(vide)
User churn          %   input (paliers annuels possibles)
(vide)
New Users (total)   #   = SUM(new_paid, new_organic, new_sales)      ← double trait
Returning Users     #   = [X-1]‹total_active_seg›                     ← fond gris
Churned Users       #   = -ROUND([X-1]$‹total_active_seg› * [X]‹churn›, 0)  ← fond gris
Total Active Users  #   = SUM(new_total, returning, churned)          ← double trait
```

Segment réduit (mono-canal) : `New Users` en input direct, puis les 3 lignes de rétention identiques.

### Bloc final — Synthèse
```
Total New Users     # = SUM(New Users de chaque segment)
Total Active Users  # = SUM(Total Active de chaque segment)
```

## Options
- **Brique activation** : si le métier distingue inscrit et payant, insérer entre New Users et la rétention : `Activated = ROUND(New × taux_activation, 0)` (taux en input) ; la rétention roule alors sur les activés.
- **Réactivation** : `Reactivated = ROUND(-Churned_cumulés_disponibles × taux, 0)` — n'introduire que si le business le justifie.

## Pièges connus du corpus (corrigés par défaut)
- Organique calculé sur le flux (paid+sales) au lieu de la base active → toujours indexer sur `Total_Active(M-1)`.
- Mois codés en dur au lieu d'`EDATE` → fragile au décalage de démarrage.
- Valeur pleine dès M1 : si le revenu suit l'usage, ce moteur surestime le revenu précoce → basculer sur moteur-usage-cohortes.
- Churn décroissant agressif (ex. 5 %→2 %) : hypothèse à faire valider explicitement.
