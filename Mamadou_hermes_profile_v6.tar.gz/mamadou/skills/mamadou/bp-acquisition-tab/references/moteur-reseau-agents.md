# Moteur RÉSEAU D'AGENTS (recrutement + churn, double vue)

## Quand l'utiliser
La ressource acquise est un réseau humain distribué (agents, revendeurs, points relais) qui subit une attrition mensuelle ET dont la productivité monte avec l'ancienneté. Typique : agency banking, réseaux de distribution, VAS. Deux représentations réconciliées : base roulante (pilotage) + cohortes par âge (productivité).

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; seeds Year 0 par segment.
**Segmentation** : types d'agents (chaque type = un bloc miroir).
**Recrutement** : nouveaux agents par mois et par segment (input direct, ou headcount recruteurs × productivité).
**Churn** : taux mensuel PAR SEGMENT (2-3 %/mois ≈ 22-31 %/an est un ordre de grandeur crédible pour un réseau terrain). Idéalement par paliers annuels.
**Rampe** : courbe de montée en productivité par ancienneté (profondeur typique 6 mois ; linéaire 1/n → 100 % par défaut, différenciable par segment ; plateau paramétrable).

## Structure de l'onglet

### Bloc 1 — Taux de churn (inputs bleus, un par segment)
```
En-tête navy "AGENT NETWORK ACQUISITION"
(vide)
Churn — segment 1   %  input
Churn — segment 2   %  input
...
```

### Bloc 2..k+1 — Un bloc MIROIR par segment
```
Sous-titre "SEGMENT k" (texte noir gras, fond transparent)
(vide)
# New agents        #  input
Returning agents    #  = [X-1]‹total_active_seg›  (Year 0 = seed)   ← fond gris
Churned agents      #  = -ROUND([X-1]‹total_active_seg› * [X]$‹churn_SEGMENT_k›, 0) ← fond gris
Total Active        #  = SUM(new, returning, churned)               ← double trait
(vide)
Penetration rate agents — libellé (police #0432FF)
  âge 0  ‹p0›  #  = [X]‹new_agents›
  âge 1  ‹p1›  #  = OFFSET(‹au-dessus›, 0, -1, 1, 1)
  ...
  âge n+ ‹pn›  #  = OFFSET(‹au-dessus›, 0, -1, 1, 1) + [X-1]‹cette ligne› + [X]‹churned›
Total cohortes  #  = SUM(lignes d'âge)  ← doit ÉGALER Total Active (auto-contrôle) ← double trait
```
Le bucket terminal absorbe les cohortes anciennes ET tout le churn (le churn frappe la masse mature — simplification assumée). Le vecteur de pénétration en colonne A : `=100%/n + précédent` par défaut, ou courbe personnalisée.

### Bloc final — Synthèse
```
Total active agents  #  = SUM(Total Active de chaque segment)   ← double trait
```
Ligne pondérée optionnelle si l'aval consomme la productivité : `Weighted agents = SOMMEPROD(vecteur ; cohortes)` par segment.

## Pièges connus du corpus (corrigés par défaut)
- **Câblage du churn** : bug observé — un segment référençant le taux de churn du segment voisin. Chaque bloc doit référencer SON taux (`$` sur la bonne ligne). Contrôle obligatoire avant livraison.
- Rampe identique pour tous les segments → différencier si les profils diffèrent.
- Churn constant sur 36 mois → proposer des paliers.
- Segment dormant (seed 0, recrutement 0 au départ) → confirmer que c'est intentionnel.
- Sortie en effectifs bruts : préciser à l'utilisateur où vit la conversion agents → revenu.
