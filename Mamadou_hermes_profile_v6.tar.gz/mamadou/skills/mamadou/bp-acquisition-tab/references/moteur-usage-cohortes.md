# Moteur USAGE PAR COHORTES (montée en charge + parc matériel optionnel)

## Quand l'utiliser
Le revenu dépend de l'usage (volume de transactions, consommation) et un client n'atteint pas son plein régime dès le premier mois : il faut une rampe de réalisation de valeur. Typique : fintech de paiement marchand, services à adoption progressive. Optionnellement, un parc matériel (terminaux, équipements) accompagne les clients.

## Checklist d'inputs à collecter
**Cadre** : mois de démarrage ; seeds Year 0 par segment.
**Segmentation** : segments (ex. online / offline) ; canaux actifs par segment.
**Drivers** : budget pub + split par segment ; CAC par segment ; commerciaux + productivité par segment ; coefficient organique (sur base active).
**Rampe** : vecteur de pénétration d'usage (défaut 3 paliers : 20 % → 60 % → plateau) ; **plateau paramétrable** (input, défaut 100 % mais souvent < 100 %).
**Rétention** : churn mensuel par segment, par paliers.
**Matériel (si applicable)** : ratio équipements / nouveau client ; durée de vie (mois) ; renouvellement oui/non.

## Structure de l'onglet

### Bloc 1 — Répartiteur de budget (inputs bleus)
```
Advertising spend   €   input
% segment 1..k      %   inputs (somme = 100 %)
```

### Bloc 2..k+1 — Un bloc MIROIR par segment
```
En-tête navy "SEGMENT k"
(vide)
Advertising spend    €  = [X]$‹spend› * [X]$‹%seg›
Paid CAC             €  input
New Users (Paid)     #  = ROUND([X]‹spend_seg› / [X]‹CAC›, 0)
(vide)
Sales (headcount)    #  input
Users Added/M/Sales  #  input
New Users (Sales)    #  = [X]‹sales› * [X]‹users/mois›
(vide)
Organic coefficient  %  input
New Users (Organic)  #  = ROUND([X-1]‹total_active_seg› * [X]‹coeff›, 0)
(vide)
User churn           %  input (paliers)
(vide)
New Users (total)    #  = SUM(paid, organic, sales)          ← double trait
(vide)
Usage penetration rate — libellé
  @20%  cohorte M    #  = [X]‹new_total›
  @60%  cohorte M-1  #  = ROUND([X-1]‹cohorte_20› * (1-[X]‹churn›), 0)
  @plateau anciennes #  = ROUND(([X-1]‹cohorte_plateau› + [X-1]‹cohorte_60›) * (1-[X]‹churn›), 0)
Total Active Users   #  = SUM(des 3 cohortes)                 ← double trait
```
Les % de pénétration (20/60/plateau) vivent en colonne A à côté des lignes de cohortes (police #0432FF, `0.0%`) : ce sont des inputs. Le Total Active est une base pondérée usage : l'aval la multiplie par la valeur à plein régime.

### Bloc parc matériel (si applicable)
```
En-tête navy "EQUIPMENT FLEET"
(vide)
Units / new client   #  input (ratio)
Unit lifetime        #  input (mois — recaler sur le réel, 36-60 pour des terminaux)
New units            #  = ROUND([X]‹ratio› * [X]‹new_clients_concernés›, 0)
Renewed units        #  = unités posées il y a ‹lifetime› mois, survivantes :
                         IFERROR(IF(COLUMN()-COLUMN($D$‹new_units›)<$C$‹lifetime›, 0,
                           ROUND(OFFSET($C$‹new_units›,0,COLUMN()-COLUMN($C$‹new_units›)-$C$‹lifetime›)
                                 * (1-churn_cumulé), 0)), 0)
Units sold (total)   #  = new + renewed                        ← double trait
Active installed     #  = ROUND([X-1]‹active› * (1-[X]‹churn_seg›) + [X]‹new_clients›, 0)  ← double trait
```
Lier explicitement le parc aux cohortes de clients (ratio unités/client) — jamais un parc autonome déconnecté.

### Bloc final — Synthèse
`Total New Users` + `Total Active Users` (+ `Active installed units` si matériel).

## Pièges connus du corpus (corrigés par défaut)
- Rampe uniforme montant à 100 % : paramétrer un plateau < 100 % différencié par segment si la rétention de valeur plafonne.
- Durée de vie matériel sous-estimée (12 mois pour des terminaux réels de 3-5 ans).
- Organique sur flux → indexer sur base active.
- Brique activation absente : si sign-up ≠ actif payant, insérer un taux d'activation avant les cohortes.
- Churn identique sur tous les segments → différencier.
