---
id: Y0657
name: reconciliation-a-priori
version: 1.0.0
description: "Vérifie, transaction par transaction et avant que la comptabilité ne les reprenne, que chaque événement du système d'information a son équivalent dans les extraits des comptes de trésorerie, et l'inverse. Produit un état pré-réconcilié livrable à la comptabilité, la liste des transactions orphelines de chaque côté, et la liste des mises à jour à porter dans le système d'information — soumises à validation. Sait qu'elle ne prouve rien sur les soldes et le dit."
bucket: B
tags: [Finance, Contrôle, Fintech, Nouveau]
maj: 2026-09-03
---

# La réconciliation a priori — livrer à la comptabilité un état déjà propre

## Ce qu'il faut avoir sous la main
Je rapproche les transactions unitaires de ton système d'information avec les extraits de tes
comptes de trésorerie, **avant** que la comptabilité ne les reprenne. À la sortie : l'état
pré-réconcilié, les transactions orphelines des deux côtés, et les mises à jour proposées.

Il me faut :
- **L'export des transactions du système d'information** sur la période, avec l'identifiant qui
  les porte.
- **Les extraits de tous les comptes** par lesquels ces transactions passent, opérateur par
  opérateur.
- **La cartographie des types de transactions**, si elle existe — sinon je commence par là
  (compétence `cartographie-des-flux`).
- **Le référentiel des tiers** : marchands, points de vente, détaillants, chauffeurs, selon
  l'activité. Sans lui, pas d'appariement ligne à ligne fiable.

## Process

### Étape 1 — Cartographier les types de transactions

Avant d'apparier quoi que ce soit : quels types d'opérations existent dans le système
d'information — encaissements, transferts, reversements, décaissements, remboursements, frais,
pénalités — et **quel compte de trésorerie chacun impacte**. Sans cette carte, on apparie ce qui
tombe et on laisse le reste en vrac.

### Étape 2 — Identifier la clé disponible, canal par canal

Tous les canaux ne fournissent pas un identifiant de transaction exploitable. Tu relèves, pour
chacun : identifiant présent ou non, format d'extrait, granularité horaire, et si la commission
est visible ligne à ligne ou agrégée. **Cette information conditionne tout le reste** — un canal
sans identifiant obligera à des passes dégradées, donc à un taux de validation humaine plus élevé,
et il faut le dire avant, pas le découvrir après.

### Étape 3 — Traiter la commission avant de comparer

Un encaissement de monnaie électronique n'arrive jamais pour son montant brut : l'opérateur
retient sa commission au passage. Comparer un montant facturé à un montant crédité sans la
retrancher produit un écart sur **chaque** transaction, qui ne se résorbe jamais — parce que ce
n'est pas une erreur, c'est un coût.

Le traitement correct : le montant facturé reste la créance, le net reçu est l'encaissement, la
différence est une **charge de frais de transaction**, suivie par canal. Jamais une remise
commerciale, jamais un ajustement du chiffre d'affaires.

### Étape 4 — Apparier, et refuser les faux positifs

Cascade de `moteur-de-matching`. Le risque dominant ici est le faux positif de matching dégradé :
même montant, même minute, deux tiers différents. Sur une activité à forte volumétrie, ce cas
n'est pas rare, il est **quotidien**. Sans clé discriminante, les deux lignes restent orphelines.

### Étape 5 — Classer les orphelines par cause probable

Présente chez l'opérateur, absente du système d'information · l'inverse · présente des deux côtés
mais avec un montant qui diffère au-delà de la commission · attribuée au mauvais tiers.

La dernière est la plus coûteuse et la moins visible : la ligne existe des deux côtés, les totaux
tombent, et pourtant l'encours d'un tiers est faux. Elle se détecte par le référentiel des tiers,
pas par les montants.

### Étape 6 — Produire les mises à jour proposées

La sortie n'est pas une correction, c'est une **liste de mises à jour à porter dans le système
d'information**, chacune avec sa justification. Elles sont approuvées par quelqu'un qui accepte
d'en porter le risque : valider par erreur une transaction en échec, c'est un montant parti chez
le mauvais bénéficiaire.

## Format de sortie

Le gabarit `gabarits/rapport-de-reconciliation.md`. En tête : le taux d'appariement, le nombre
d'orphelines de chaque côté, et le nombre de mises à jour proposées. Le détail ensuite.

**Toujours une phrase, en tête, sur la limite** : cet état garantit l'exhaustivité des mouvements,
il ne dit rien des soldes.

## Règles

1. **Un état a priori ne garantit jamais un solde**, et il le dit dans son en-tête.
2. **La commission se retranche avant de comparer**, canal par canal.
3. **Un faux positif ne se tranche pas.**
4. **Le référentiel des tiers est un prérequis**, pas un confort. Sans lui, l'appariement ligne à
   ligne n'est pas fiable et tu le signales avant de commencer.
5. **La sortie est une proposition de mise à jour**, jamais une mise à jour.
6. **Une preuve de virement ne vaut pas un encaissement.** Tant que le compte de trésorerie ne
   l'a pas constaté, l'opération n'est pas réconciliée.

**Garde-fous durs** — identiques à `etat-rapprochement`.

## Cas limites

- **Canal sans identifiant de transaction** — tu l'annonces avant de commencer et tu donnes le
  taux de validation humaine attendu ; tu ne compenses pas par des critères plus permissifs.
- **Extraits à granularité différente** (une source à la seconde, l'autre au jour) — tu agrèges
  la plus fine, tu ne désagrèges jamais la plus grossière.
- **Référentiel de tiers absent** — tu produis l'appariement par montant et date en marquant
  explicitement que l'imputation par tiers n'est pas vérifiée, et tu poses la construction du
  référentiel comme premier chantier.
- **Volumétrie hors de portée** — tu passes par l'outil ou tu échantillonnes en le disant, et en
  disant sur quel critère.
