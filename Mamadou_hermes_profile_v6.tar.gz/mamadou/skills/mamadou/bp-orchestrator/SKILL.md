---
name: "bp-orchestrator"
version: "1.0.0"
description: "Pilote la chaîne complète bp-acquisition-tab → bp-assumptions-tab → bp-pl-cashflow-tabs → bp-charts pour produire un BP Excel de bout en bout."
maj: 2026-09-03
---

# Orchestrateur de BP — chaîne complète

## Ce que produit ce skill

Un classeur Excel unique, en formules actives, contenant les six onglets de calcul de la chaîne BP plus le dashboard :

```
ACQUISITION_MODEL   volumes         bp-acquisition-tab
ASSUMPTIONS         prix et coûts   bp-assumptions-tab
P&L_Monthly ─┐
P&L_Yearly   │      états           bp-pl-cashflow-tabs
Cashflow_Monthly
Cashflow_Yearly ─┘
DASHBOARD           graphiques      bp-charts
```

Le classeur est le seul livrable fichier. Tout le reste (registre des hypothèses, résultat des contrôles, table de câblage) est restitué dans la réponse, pas dans des fichiers annexes.

## Pourquoi un orchestrateur, et pas quatre appels successifs

Les quatre skills fonctionnent seuls, mais enchaînés à la main ils posent quatre problèmes que ce skill résout :

- **Quatre séries de questions au lieu d'une.** Chaque skill interroge sur ce qui le concerne, et l'utilisateur redonne quatre fois le mois de démarrage, la devise et le business model. L'orchestrateur fait une seule collecte.
- **La famille de business model doit être décidée une fois.** Les quatre skills partagent la même typologie à six familles ; si l'un d'eux la qualifie différemment, le modèle se contredit sans erreur visible.
- **Le contrat de grille doit tenir de bout en bout.** Un décalage d'une colonne entre deux onglets ne lève aucune erreur et fausse tout l'aval.
- **Les passages de relais ne sont vérifiés par personne.** Les sorties de l'étape N sont les entrées de l'étape N+1 ; sans contrôle entre les deux, une erreur d'adressage se propage jusqu'au dashboard.

## Workflow

### Étape 0 — Lire avant de demander

Lire tout ce que l'utilisateur a fourni : deck, mémo d'investissement, notes de meeting, data room, tableur existant, BP d'une version antérieure. En extraire tout ce qui alimente le brief (voir `references/brief.md` pour le schéma complet des champs).

Si un classeur existe déjà, inventorier ses onglets : la chaîne reprend à la première étape manquante, elle ne reconstruit pas ce qui est là.

### Étape 1 — Une seule salve de questions

Poser en une fois, avec AskUserQuestion quand il est disponible :

1. **Le mode.** Proposer systématiquement le mode brouillon avant le mode complet, et laisser choisir.
   - *Brouillon* : trois ou quatre questions, tout le reste pris dans les valeurs par défaut de la famille, chaque défaut marqué à valider. Sert à cadrer un ordre de grandeur en une passe.
   - *Complet* : intake détaillé, on ne devine que ce qui ne peut pas être connu.
2. **La cadence de validation** : aucun arrêt, un arrêt après les assumptions, ou un arrêt après chaque étape. Recommander l'arrêt après les assumptions, qui est le dernier moment où changer une hypothèse coûte peu.
3. **Les champs manquants du brief**, groupés par thème, dans la même salve.

Ne jamais poser une question dont la réponse est dans les documents fournis. Ne jamais poser plus d'une salve avant de commencer à produire.

### Étape 2 — Figer le brief et le contrat

Écrire `brief.json` dans le répertoire de travail (schéma dans `references/brief.md`). Ce fichier est la source de vérité de toute la chaîne : chaque étape le lit, aucune étape ne redemande ce qu'il contient. Il porte notamment la famille retenue, le contrat de grille, et le registre des hypothèses avec l'origine de chacune (fournie, défaut, inférée).

### Étape 3 — Enchaîner les quatre étapes

Chaque étape s'exécute dans un **subagent dédié** quand l'outil Agent est disponible. La raison est mécanique : les quatre skills totalisent une trentaine de fichiers de référence, et les charger tous dans un même contexte dégrade la qualité de chacun. Un subagent par étape ne charge que le skill de son étape.

Sans outil Agent, exécuter les étapes en séquence dans la session, en lisant les références d'un seul skill à la fois.

Le détail des consignes à passer à chaque étape, et de ce que chacune doit renvoyer, est dans `references/etapes.md`.

Après chaque étape, **exécuter le contrôle de relais** correspondant (`references/controles-relais.md`) avant de lancer la suivante. Un relais qui échoue arrête la chaîne : corriger l'étape en cause, ne pas continuer sur une base fausse.

### Étape 4 — Restituer

Dans la réponse, pas dans des fichiers : la famille retenue et ce qui l'a déterminée, la table de câblage entre onglets, le résultat de chaque contrôle, la liste des hypothèses marquées à valider avec leur origine, et les avertissements de calibrage relevés par les étapes.

## Le contrat de grille, à imposer aux quatre étapes

C'est l'invariant qui fait tenir la chaîne. Le rappeler explicitement dans les consignes de chaque étape :

```
colonne A   libellés
colonne B   unité (#, %, EUR)
colonne C   Year 0
colonnes D à AM   36 mois
ligne 5     bandes d'année fusionnées
ligne 6     clé d'année (Year 0/1/2/3 répété), VISIBLE
ligne 7     dates
ligne 8     vide
ligne 9+    contenu
```

Conséquence : `ASSUMPTIONS!D` correspond à `ACQUISITION_MODEL!D` et à `Cashflow_Monthly!D`. Aucun décalage de colonne entre onglets, jamais.

Les onglets annuels utilisent leur propre grille (colonnes C à E pour Year 1 à Year 3, ligne 5 pour les en-têtes d'exercice), décrite dans le skill bp-pl-cashflow-tabs.

**Une divergence à corriger explicitement.** Généré seul, `bp-acquisition-tab` place ses mois en ligne 6 et n'a pas de ligne-clé d'année, alors que les trois autres skills placent la clé en ligne 6 et les dates en ligne 7. Sous orchestrateur, l'onglet acquisition adopte la grille commune : clé d'année en ligne 6, dates en ligne 7, volets figés en C8. Le préciser dans la consigne de l'étape 1, sinon tout l'aval se branche sur la ligne des clés d'année en croyant lire des dates, ce qui casse silencieusement les `MATCH` de l'agrégation annuelle.

## Reprise et reconstruction partielle

- **Reprise** : si le classeur contient déjà certains onglets, démarrer à la première étape manquante. Vérifier tout de même le contrat de grille des onglets existants avant de continuer, et le signaler s'il n'est pas respecté.
- **Changement d'hypothèse après coup** : ne relancer que depuis l'étape concernée. Un prix ou un coût change, on repart des assumptions ; un canal d'acquisition change, on repart de l'acquisition. Les étapes aval se régénèrent, les étapes amont ne sont pas touchées.
- **Ne jamais reconstruire un onglet que rien n'oblige à reconstruire.** L'utilisateur y a peut-être fait des ajustements à la main.

## Conventions par défaut (appliquer sans redemander)

- **Horizon** : Year 0 plus 36 mois, trois exercices. Ne le changer que sur demande explicite.
- **Devise de reporting** : euro, avec les grandeurs négociées localement saisies en devise locale et converties par une cellule de taux unique.
- **Nom du fichier** : `AAAAMMJJ_<Projet>_Model_v1.xlsx`, incrémenter la version si le nom existe déjà dans le dossier de sortie.
- **Anonymat** : ne jamais mentionner dans le classeur les entreprises qui ont servi de référence aux skills.
- **Aucun fichier annexe** : ni note d'hypothèses, ni rapport de contrôles, ni image. Le classeur seul, le reste dans la réponse.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/brief.md` | Étape 0 et 1 — schéma du brief, champs par famille, défauts du mode brouillon |
| `references/etapes.md` | Étape 3 — consignes à passer à chaque étape et sorties attendues |
| `references/controles-relais.md` | Après chaque étape — les quatre contrôles de passage de relais |
| `assets/brief-template.json` | Gabarit à remplir pour figer le brief |
