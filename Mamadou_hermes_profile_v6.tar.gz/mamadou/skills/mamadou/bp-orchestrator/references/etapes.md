# Les quatre étapes — consignes et sorties attendues

Chaque étape s'exécute dans un subagent dédié quand l'outil Agent est disponible, sinon en séquence dans la session. Un subagent ne peut pas interroger l'utilisateur : tout ce dont il a besoin doit se trouver dans la consigne et dans `brief.json`.

## Gabarit de consigne, commun aux quatre étapes

Désigner le skill **par son nom** (`bp-acquisition-tab`, `bp-assumptions-tab`, `bp-pl-cashflow-tabs`, `bp-charts`) et non par un chemin en dur : les skills sont installés dans le profil de l'utilisateur et leur emplacement n'est pas garanti. En exécution inline, les invoquer avec l'outil Skill. En exécution par subagent, leur passer le chemin trouvé sur disque (typiquement sous le répertoire des skills du profil), après l'avoir vérifié.

Si l'un des quatre skills est absent, le dire et s'arrêter : l'orchestrateur ne réimplémente aucune étape, il les enchaîne.

```
- Skill: <nom du skill de l'étape>
  Lis d'abord son SKILL.md et suis son workflow et ses références.
- Brief: <chemin de brief.json>. Il fait foi. Tu ne peux pas poser de question :
  utilise ses valeurs, et pour toute hypothèse que tu ajoutes, pose un
  commentaire de cellule "hypothèse à valider" et signale-la dans ta réponse.
- Famille de business model : <famille>. Ne pas la requalifier.
- Contrat de grille : colonne A libellés, B unité, C Year 0, D à AM 36 mois,
  ligne 6 clé d'année visible, ligne 7 dates. Aucun décalage de colonne entre
  onglets.
- Classeur cible : <chemin>. Travaille sur ce fichier, conserve les onglets
  existants à l'identique.
- Vérifie ton travail en recalculant avec LibreOffice headless avant de livrer.
- Réponds avec : la table de câblage (onglet et numéro de ligne de chaque
  sortie que l'aval devra lire), le résultat de tes contrôles, et la liste des
  hypothèses que tu as ajoutées.
```

La table de câblage renvoyée par chaque étape est la matière première de l'étape suivante : elle évite au subagent aval de deviner des numéros de ligne. La consigner dans `brief.json` sous `cablage`.

## Étape 1 — ACQUISITION_MODEL

Skill : `bp-acquisition-tab`. Crée le classeur s'il n'existe pas.

À passer en plus du gabarit : segments, canaux d'acquisition par segment, base de départ, churn, budget publicitaire et CAC, effectifs commerciaux, plan de pose ou de recrutement selon la famille.

**Consigne impérative sur la grille** : ce skill place ses mois en ligne 6 quand il travaille seul. Sous orchestrateur il doit produire la grille commune, clé d'année en ligne 6 et dates en ligne 7, volets figés en C8. L'écrire noir sur blanc dans la consigne.

Sur un modèle bi-face, exiger les deux populations projetées séparément et le bloc de liquidité qui confronte capacité de l'offre et demande : c'est lui qui révèle laquelle des deux faces est le goulot, et c'est la seule raison de modéliser deux faces.

Sorties attendues dans la table de câblage : la ligne `Total New` et la ligne `Total Active` de chaque segment, plus les lignes que l'aval devra lire (effectifs commerciaux, budget publicitaire, poses du mois, parc cumulé).

## Étape 2 — ASSUMPTIONS

Skill : `bp-assumptions-tab`, en mode chaîné sur l'onglet acquisition.

À passer en plus : la table de câblage de l'étape 1, la grille tarifaire, les coûts variables, la liste des rôles avec salaires nets locaux et gross-up, les pourcentages de benefits et d'autres charges, le G&A, le capex, la fiscalité.

**Et la présentation du revenu retenue au brief**, brut ou net (voir `brief.md` §2 bis). En présentation brute, les reversements aux tiers sont une ligne de coût direct des assumptions ; en présentation nette, seule la commission remonte et les reversements n'apparaissent nulle part. Ne pas laisser l'étape trancher seule : deux exécutions du même brief donneraient deux chiffres d'affaires dans un rapport de un à cinq.

Sorties attendues : les lignes de prix, de coûts unitaires, de masse salariale par département, de quantités de capex, de taux d'impôt, et les adresses des scalaires que le P&L devra référencer en absolu.

**C'est ici que se place l'arrêt de validation recommandé.** Après cette étape, tout le reste est mécanique : le P&L et le cashflow ne font que combiner ce que l'acquisition et les assumptions ont produit. Une hypothèse changée après l'étape 2 coûte trois régénérations ; changée maintenant, elle coûte une.

## Étape 3 — P&L et CASHFLOW

Skill : `bp-pl-cashflow-tabs`. Produit les quatre onglets d'un coup.

À passer en plus : les tables de câblage des étapes 1 et 2, les délais de BFR, les tranches de financement, et la précision explicite de descendre ou non sous l'EBIT (le bloc charges financières, impôt, résultat net est optionnel, et il devient recommandé pour la famille ACTIFS FINANCÉS).

Sorties attendues : les lignes de sous-totaux de flux et de solde de clôture du cashflow, les lignes de revenu total et de volume du P&L mensuel et annuel. Ce sont exactement les entrées du dashboard.

## Étape 4 — DASHBOARD

Skill : `bp-charts`.

À passer en plus : la table de câblage de l'étape 3, et la grandeur de volume à tracer, qui dépend de la famille (clients actifs pour une base récurrente, commandes ou transactions pour un modèle transactionnel, parc en service pour un modèle à actifs). Si le brief ne tranche pas, laisser le skill choisir et le signaler.

Sorties attendues : la table de câblage des trois graphiques, le résultat du contrôle de cohérence du cashflow, les formes retenues avec leurs ratios, et les avertissements de lisibilité.

## Ordre, parallélisme et reprise

Les quatre étapes sont **strictement séquentielles** : chacune lit ce que la précédente a écrit. Aucun parallélisme n'est possible, et vouloir en introduire ne ferait que produire des adresses inventées.

En reprise, démarrer à la première étape dont l'onglet manque, mais reconstituer la table de câblage des étapes déjà faites en relisant les onglets existants par libellé. Ne pas supposer que les numéros de ligne d'un classeur existant correspondent à ceux qu'auraient produits les skills.
