# Contrôles de passage de relais

Quatre contrôles, un après chaque étape, exécutés par l'orchestrateur et non par le subagent qui vient de travailler. Le principe est celui de la relecture par un tiers : celui qui a produit un onglet est le plus mal placé pour voir ce qu'il y a oublié.

Un relais qui échoue **arrête la chaîne**. Corriger l'étape en cause avant de lancer la suivante : une erreur d'adressage se propage jusqu'au dashboard sans jamais lever d'erreur Excel.

## Contrôle commun aux quatre relais : le contrat de grille

À vérifier après chaque étape, sur les onglets qu'elle vient de créer :

- colonne A libellés, B unité, C Year 0, D à AM les 36 mois ;
- ligne 6 remplie de `Year 0/1/2/3` sur toutes les colonnes de mois, et **visible** ;
- ligne 7 en dates, liée à l'onglet maître ou en chaîne `EDATE` ;
- dans chaque formule inter-onglets, la lettre de colonne référencée est identique à celle de la cellule qui la porte ;
- aucune ligne masquée porteuse de calcul.

## Relais 1 — après ACQUISITION_MODEL

- Le classeur existe, l'onglet est là, il porte des formules et pas des valeurs collées.
- Les lignes `Total Active` sont croissantes ou expliquées, et jamais négatives.
- Les effectifs et les parcs sont entiers.
- La table de câblage renvoyée pointe bien sur des lignes qui existent et dont le libellé correspond.

## Relais 2 — après ASSUMPTIONS

- Aucun littéral métier dans les formules : taux de change, gross-up, inflation, jours ouvrés doivent être des cellules du bloc de paramètres généraux.
- Les liens vers l'acquisition sont en police verte et pointent sur les lignes annoncées par le relais 1.
- La masse salariale est le miroir ligne à ligne du plan d'embauche.
- Aucun onglet en aval n'est encore référencé (les assumptions ne lisent jamais le P&L, sauf lecture décalée d'un mois explicitement documentée).

C'est ici que se place l'arrêt de validation si l'utilisateur a choisi cette cadence. Présenter alors : la famille retenue, les grandes hypothèses de prix et de coûts, la trajectoire de volume en fin d'année 1 et d'année 3, et la liste des hypothèses à valider. Attendre le feu vert.

## Relais 3 — après P&L et CASHFLOW

Le relais le plus important de la chaîne, parce que c'est là que les erreurs coûtent le plus cher.

- **Articulation du cashflow** : pour chaque période, somme des sous-totaux de flux égale variation du solde de clôture. C'est le même contrôle que celui du dashboard, et il doit passer ici, avant que le dashboard ne soit construit.
- **Cascade du P&L** : EBITDA égale la marge de contribution moins la somme des OpEx, sur chaque colonne.
- **Agrégation annuelle** : la somme des douze mois égale la colonne annuelle pour chaque ligne de flux, et les lignes de stock sont lues par `INDEX`/`MATCH` et non sommées.
- **Décaissements** : chaque référence d'une ligne de cash-out pointe sur une ligne de charge, jamais sur un palier de marge ni sur une ligne de pourcentage.
- **Sens de lecture** : aucune formule d'un onglet mensuel ne référence un onglet annuel.
- **Trésorerie** : si le solde devient négatif sans ligne de financement en face, le signaler à l'utilisateur avec le point bas et le mois concerné. Ce n'est pas un défaut du modèle, c'est un résultat, mais il ne doit pas passer inaperçu.

## Relais 4 — après DASHBOARD

- Les trois graphiques existent et sont des graphiques Excel natifs.
- Les blocs de données sont intégralement en formules.
- Le contrôle de cohérence du cashflow a bien été exécuté par l'étape et il passe.
- Chaque axe porte l'échelle de la série qu'il gouverne, vérifié au rendu et pas dans le XML.
- Les onglets de calcul sont inchangés.

## Contrôle final, avant livraison

- Recalculer le classeur entier et vérifier qu'aucune cellule ne porte d'erreur (`#REF!`, `#VALUE!`, `#DIV/0!`, `#N/A`).
- Vérifier que toutes les lignes de contrôle posées par les skills valent zéro.
- Vérifier qu'aucun nom d'entreprise ayant servi de référence aux skills n'apparaît dans le classeur.
- Confronter les grandeurs clés aux repères de calibrage de la famille (marge brute, marge d'EBITDA, poids de la masse salariale, intensité capitalistique) et signaler les écarts marqués, sans les corriger : ce sont des hypothèses métier, pas des erreurs de modèle.
