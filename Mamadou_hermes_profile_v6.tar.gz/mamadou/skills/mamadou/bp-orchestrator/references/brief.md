# Le brief — schéma, extraction, défauts

Le brief est la source de vérité de toute la chaîne. Il se remplit d'abord par lecture des documents fournis, ensuite par une seule salve de questions, et il est figé dans `brief.json` avant que la première étape ne démarre.

## 1. Champs communs à toutes les familles

| Groupe | Champ | Où le trouver dans un deck ou un mémo |
|---|---|---|
| Identité | nom du projet, pays, ville | page de garde, slide équipe |
| Identité | devise locale, devise de reporting, taux de change | slide marché, mentions de prix |
| Temps | mois de démarrage, horizon (défaut 36 mois) | roadmap, slide levée |
| Modèle | famille de business model (voir §2) | slide business model, description du produit |
| Modèle | segments de clientèle, canaux d'acquisition | slide go-to-market, traction |
| Volumes | base actuelle, objectifs de croissance, churn | slide traction, KPIs |
| Prix | grille tarifaire, panier moyen, take-rate, commissions | slide business model, pricing |
| Coûts variables | coût unitaire, frais de paiement, logistique, provisions | rarement dans un deck, à demander |
| Équipe | rôles, plan d'embauche, salaires nets locaux | slide équipe, use of funds |
| Structure | loyer, audit, marketing, divers | use of funds |
| Capex | catégories d'actifs, prix unitaires, durées d'amortissement | use of funds, slide opérations |
| BFR | DSO, DPO, DIO | à demander |
| Financement | tranches d'equity et de dette, dates, taux, maturité, différé | slide levée, term sheet |
| Fiscalité | taux d'IS, impôt minimum, TVA | à demander, dépend du pays |

Les six derniers groupes sont presque toujours absents des documents : ce sont eux qui font le gros de la salve de questions en mode complet, et ce sont eux qui sont pris par défaut en mode brouillon.

## 2. Qualifier la famille, une fois pour toute la chaîne

C'est la décision structurante : elle détermine le moteur d'acquisition, le haut de cascade du P&L et le choix du volume tracé sur le dashboard. La poser au début, la consigner dans le brief, et la passer telle quelle aux quatre étapes.

```
Q1. Combien de populations faut-il projeter avec leur propre dynamique ?
├─ DEUX (une offre et une demande, chacune avec ses canaux et son churn)
│                                            → MARKETPLACE BI-FACE
└─ UNE SEULE
    Q2. Quelle ressource acquiert-elle ?
    ├─ Des clients ou utilisateurs
    │   Q3. Le revenu est-il plein dès le premier mois d'un client ?
    │   ├─ OUI, abonnement ou accès          → BASE RÉCURRENTE
    │   └─ NON, usage ou transaction         → USAGE / COHORTES
    ├─ Des unités physiques qu'elle vend
    │   avec un prix dérivé du coût d'achat  → ROLLOUT D'ACTIFS
    ├─ Un réseau de tiers équipés            → RÉSEAU D'AGENTS
    └─ Un parc d'actifs financés par dette   → ACTIFS FINANCÉS
```

Le discriminant de la première question est **le nombre de populations à projeter**, pas la façon dont le revenu est présenté. Une place de marché qui ne possède jamais la marchandise reste bi-face : elle doit projeter ses vendeurs et ses acheteurs séparément, avec des canaux et des taux d'attrition différents, et son goulot peut venir de l'une ou l'autre face. Confondre les deux questions conduit à modéliser une seule population et à perdre la contrainte de liquidité.

## 2 bis. Revenu brut ou revenu net — une décision séparée, et à faire trancher

C'est la question qui change le plus le BP, et elle est indépendante de la famille. Sur un même modèle, le chiffre d'affaires affiché en année 3 peut varier d'un facteur cinq selon la présentation retenue.

| Présentation | Quand | Ce qui est affiché en revenu |
|---|---|---|
| **Brut (principal)** | l'entreprise achète et revend, ou porte le risque principal (stock, crédit, casse) | la valeur totale de la transaction, les reversements aux tiers passant en coût direct |
| **Net (agent)** | l'entreprise intermédie sans jamais posséder, et ne porte pas le risque principal | la seule commission |

La règle usuelle est celle du contrôle et du risque : qui décide du prix, qui supporte la perte, qui est le débiteur en cas de litige. Un intermédiaire qui provisionne la casse sur sa propre marge a commencé à porter un risque de principal, ce qui n'est pas neutre.

**Ne jamais trancher seul.** Poser la question dans la salve d'intake, avec l'ordre de grandeur des deux présentations si les documents permettent de le calculer. Consigner le choix dans le brief sous `modele.presentation_revenu`, et le rappeler en livraison : un comité qui lit un chiffre d'affaires ne devine pas lequel des deux il regarde.

Deux familles ne sont pas instanciées dans le corpus de référence des skills, BASE RÉCURRENTE et ACTIFS FINANCÉS : leur haut de cascade est transposé. Quand l'une des deux est retenue, le signaler à l'utilisateur en fin de chaîne.

Cas composite (plusieurs activités) : retenir la famille dominante en revenu et l'indiquer, puis demander si les activités secondaires doivent être modélisées séparément. Ne pas empiler trois familles sans que l'utilisateur l'ait demandé.

## 3. Mode brouillon — ce qu'on demande, ce qu'on prend par défaut

Quatre questions seulement :

1. Que fait l'entreprise, en deux phrases (sert à qualifier la famille) ;
2. le pays et le mois de démarrage ;
3. l'ordre de grandeur du volume visé en fin d'année 3 ;
4. le prix moyen ou le take-rate.

Tout le reste vient des repères de calibrage de la famille, documentés dans les fiches des skills aval. Chaque valeur ainsi posée est **marquée à valider** dans le registre du brief, et listée en fin de chaîne.

Le mode brouillon produit un BP complet et cohérent, dont les ordres de grandeur sont plausibles et les détails faux. C'est sa raison d'être : cadrer avant d'investir une heure d'intake. Le dire clairement à l'utilisateur en livraison, sans quoi il prendra un cadrage pour un modèle.

## 4. Registre des hypothèses

Chaque valeur du brief porte son origine. C'est ce qui rend le BP défendable et ce qui permet de savoir quoi challenger en priorité.

| Origine | Sens |
|---|---|
| `fournie` | donnée par l'utilisateur ou extraite d'un document, avec la source |
| `defaut` | repère de calibrage de la famille, appliqué faute de mieux |
| `inferee` | déduite d'une autre valeur du brief (par exemple un effectif déduit d'un ratio de productivité) |

Les valeurs `defaut` et `inferee` sont toutes marquées à valider et listées en fin de chaîne. En mode brouillon elles sont majoritaires, c'est attendu ; en mode complet, plus de cinq ou six signale un intake incomplet, et il vaut mieux poser une question de plus que livrer un modèle qu'on ne sait pas défendre.

## 5. Ce qu'il ne faut pas faire à l'intake

- **Inventer un chiffre sans le marquer.** Un défaut non signalé devient une donnée dans l'esprit du lecteur.
- **Poser une question dont la réponse est dans le deck.** C'est le principal reproche fait aux chaînes de skills enchaînées à la main.
- **Multiplier les salves.** Une seule, quitte à ce qu'elle soit longue. Les allers-retours coûtent plus cher que la longueur.
- **Laisser une famille indéterminée.** Si le modèle est ambigu, trancher avec l'utilisateur avant de démarrer, jamais en cours de chaîne.
