---
id: Y0663
name: cadrage-entreprise
version: 1.1.0
description: "Conduit le cadrage financier d'une entreprise cliente en une séance : activité et modèle économique, référentiel comptable et régime constatés sur pièces, comptes et canaux d'encaissement, cycle de facturation et comportement de paiement observé, obligations déclaratives, état du référentiel de pilotage déjà en place (BP, process comptable, plan analytique, reporting), outils, personnes et circuits de validation. Produit la fiche d'entreprise, alimente USER.md et la base de référence, et sort les trois chantiers prioritaires. Ne suppose jamais un régime à partir du pays ni un usage à partir du secteur, et ne reconstruit jamais un référentiel de pilotage sans avoir vérifié qu'une version n'existe pas déjà."
bucket: A
tags: [Socle, Cadrage, Horizontal, Nouveau]
maj: 2026-09-03
---

# Le cadrage de l'entreprise

## Pourquoi cette compétence est la première de toutes

C'est elle qui fait la différence entre un agent générique et un Expert qui connaît la maison. Un
client qui doit tout réexpliquer chaque semaine n'a pas embauché, il a loué un logiciel.

Et c'est elle qui protège contre la faute la plus insidieuse : **combler un manque de contexte par
du contexte vraisemblable**. Ce qu'un modèle « sait » d'un secteur, d'un marché ou d'un usage est
plein de noms d'entreprises, de circuits et de pratiques qui appartiennent à d'autres
organisations. Les faire apparaître ici, ce n'est pas seulement inventer — c'est faire entrer chez
ce client la vie d'une autre maison.

## La règle qui gouverne l'entretien

**Trente minutes, pas un questionnaire de quatre-vingts questions.** Un Expert qui ouvre par un
formulaire se fait abandonner avant d'avoir servi. On demande ce qui commande le travail, on note
ce qui vient spontanément, et **le reste s'apprend en travaillant** — un dirigeant qui corrige un
brouillon apprend plus sur sa maison que quinze questions posées à froid.

Ce qui se demande maintenant, c'est ce dont l'absence produirait une erreur : le référentiel, le
régime, les comptes, le circuit de validation — et l'existence ou non d'un référentiel de
pilotage déjà construit (BP, plan analytique, reporting), faute de quoi le premier travail de
structuration livré écrase silencieusement l'historique de la maison.

## Les sept blocs

### 1 · L'entreprise et son activité
Ce qu'elle vend, à qui, comment elle est payée. Forme juridique, effectif, ancienneté, lieux.
Ce qui a changé récemment — une croissance rapide, un nouveau canal, une ouverture — parce que
c'est là que naissent les problèmes qu'on vient te confier.

### 2 · Le cadre comptable et fiscal — **constaté, jamais déduit**
Référentiel appliqué, régime fiscal réel, exercice social, devise de tenue.

⛔ **Le régime se lit sur les documents officiels de l'entreprise.** Il ne se déduit ni du pays,
ni du secteur, ni du chiffre d'affaires estimé — et un changement de régime modifie tout le
calendrier déclaratif. Tant qu'un document ne l'a pas établi, la ligne reste `⟦à renseigner⟧`.

### 3 · Les comptes et les canaux
Tous les comptes, avec pour chacun : type, établissement, devise, **dédié aux opérations ou non**,
qui y a accès, format d'extrait, périodicité de rapprochement actuelle.

Pour chaque canal d'encaissement : structure de commission (relevée, jamais de mémoire), délai de
crédit, identifiant de transaction disponible ou non.

### 4 · Le cycle commercial et le comportement de paiement
Comment naît une facture, qui l'émet, qui la valide, qui la relance. Délais contractuels **et**
délais observés — c'est le second qui sert à prévoir. Les impayés en cours, et ce qu'on a déjà
tenté.

### 5 · Les obligations et le calendrier
Ce que l'entreprise doit déclarer, à qui, à quelle fréquence, qui prépare et qui valide. Chaque
échéance ira dans `memory/reference/calendrier-obligations.md` **avec son lien officiel et sa date
de consultation** — jamais avec une date citée de mémoire.

### 6 · Les gens et les validations
Qui te sollicitera, à quel titre, et ce que chacun attend. Qui valide quoi : une facture, un
virement, une déclaration, une transmission à un tiers.

Cette dernière liste devient la **liste des validations humaines** du contrat, et elle se relit à
voix haute avec le client. C'est la clause qui rend l'autonomie acceptable — elle s'assume, elle
ne se glisse pas en annexe.

### 7 · L'état du référentiel existant — **constaté avant toute reconstruction**
Avant de proposer de structurer, de modéliser ou de rapporter quoi que ce soit, vérifier ce qui
existe déjà dans la maison. Une compétence de structuration lancée sans ce constat ne comble pas
un manque : elle risque d'écraser un existant qu'elle n'a jamais consulté.

- **Business plan** : en existe-t-il un ? Date, auteur, statut (hypothèses tenues, dépassées,
  jamais mises à jour). S'il existe, il est lu avant toute proposition de nouveau BP — jamais
  reconstruit à côté sans le dire.
- **Process comptable documenté** : mémos de structuration déjà écrits, comptes à suivre déjà
  identifiés et par qui, régime fiscal déjà formalisé dans un document interne (au-delà de ce
  qui est constaté au bloc 2).
- **Plan comptable analytique existant** : les axes déjà en place, qui les a posés, depuis quand.
  ⛔ **Un plan analytique préexistant ne se remplace jamais en silence.** Le reprendre, ou
  documenter explicitement pourquoi et comment il change — jamais une seconde nomenclature qui
  ne colle pas à l'historique déjà saisi.
- **Système de reporting existant** : outil utilisé, format, périodicité, destinataire actuel.
  S'il y a déjà un format qui circule, c'est lui qui sert de référence de continuité, pas un
  format neuf imposé au premier mois.

Tant qu'aucun document ne l'établit, chaque ligne reste `⟦à renseigner⟧` — on ne suppose jamais
l'absence d'un référentiel faute de l'avoir demandé.

## Ce que le cadrage produit

1. **La fiche d'entreprise** (`gabarits/fiche-entreprise.md`), rangée en mémoire.
2. **`USER.md` rempli** : contexte d'exploitation, tableau des comptes, interlocuteurs.
3. **La base de référence amorcée** : référentiel comptable, calendrier, canaux.
4. **L'inventaire du référentiel de pilotage existant** (BP, process comptable, plan analytique,
   reporting) — condition d'entrée pour toute compétence de structuration appelée ensuite
   (`bp-orchestrator`, `structuration-comptable`, `reporting-de-gestion`).
5. **Les trois chantiers prioritaires**, classés par la même règle que partout : d'abord ce dont
   la donnée existe déjà et qui ne dépend de personne d'autre.
6. **La liste des accès à ouvrir**, par valeur décroissante, avec ce que chacun débloque.

## Garde-fous

- **Rien ne se suppose à partir du pays, du secteur ou de la taille.** Ce qui n'a pas été dit ou
  montré reste `⟦à renseigner⟧`.
- **Aucun nom d'entreprise, de personne, de fournisseur ou de circuit venu d'ailleurs** n'apparaît
  dans la fiche.
- **Aucune donnée d'un autre client ne sert de repère**, même comme ordre de grandeur, même dans
  une phrase d'illustration. Si un repère est utile, on le demande à cette maison ou on le source
  publiquement.
- **Aucune compétence de structuration (`bp-orchestrator`, `structuration-comptable`,
  `reporting-de-gestion`) ne se lance sans avoir consulté le bloc 7.** Un référentiel existant
  non consulté est un référentiel silencieusement remplacé.
- **La fiche porte sa date** et se revoit à quatre-vingt-dix jours : elle se périme en silence.
