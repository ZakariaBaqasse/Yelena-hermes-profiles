---
id: Y0654
name: audit-modele-financier
description: "Ouvre le modèle financier fourni et l'instruit comme un comité d'investissement le ferait : chaînage des feuilles et recalcul des totaux, remontée de chaque ligne de projection à l'hypothèse qui la produit et au statut de cette hypothèse, reconstitution des indicateurs unitaires depuis les données brutes plutôt que depuis le modèle, confrontation de la courbe de revenus à sa contrepartie de charges, lecture de la trésorerie mois par mois jusqu'au point de rupture, et tests de sensibilité sur les hypothèses qui portent le résultat — sans jamais introduire un montant, un ratio ou une hypothèse qui ne vienne pas du modèle ou des pièces fournies."
bucket: C
tags: [Investissement, Finance, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Audit du modèle financier — remonter des projections aux hypothèses

## Ce qu'il faut avoir sous la main
- **Le fichier du modèle financier** — toutes les feuilles, pas un export résumé.
- **Les données brutes réelles** dont dispose l'entreprise : ventes historiques, nombre de clients, coûts constatés, factures, relevés de trésorerie — tout ce qui permet de recalculer un indicateur sans repartir du modèle lui-même.
- **Le contexte de la demande** : due diligence d'un tour, revue périodique, préparation d'un comité — ça change ce que je cherche en priorité.
- **Le secteur et le pays** couverts par le modèle, et la période qu'il projette.
- **Ce que l'équipe a déjà identifié comme fragile** — s'il y a une hypothèse qui l'inquiète déjà, dis-le, ça oriente le test de sensibilité.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier la structure et vérifier le chaînage

Avant de juger le contenu, établis la carte du fichier : combien de feuilles, comment elles s'articulent (hypothèses → compte de résultat → bilan → trésorerie, ou un autre ordre), et où sont les entrées versus les calculs. Vérifie que chaque total dérive bien de ses composantes et que rien n'a été **collé en valeur** à un endroit où une formule était attendue — une valeur en dur dans une cellule de calcul est le signe le plus fiable qu'une correction a été faite à la main sans qu'on retouche la logique en amont, et qu'elle a probablement cassé le chaînage ailleurs.

Ce contrôle est nécessaire mais il ne dit rien sur la qualité du modèle. Un fichier parfaitement chaîné peut projeter n'importe quoi : c'est justement le piège du métier, et il se règle aux étapes suivantes.

### Étape 2 — Remonter chaque ligne à son hypothèse, et classer le statut de cette hypothèse

Pour chaque ligne qui porte le résultat (croissance du chiffre d'affaires, taux de conversion, panier moyen, taux de rétention, coût d'acquisition, masse salariale, marge brute), identifie l'hypothèse qui la génère — pas la formule, l'**hypothèse métier** derrière la formule — et classe-la :
- **Observée** — issue des données réelles de l'entreprise, sur une période suffisante.
- **Reprise d'un tiers** — benchmark sectoriel, chiffre d'un concurrent, standard de marché cité sans être recalculé.
- **Posée** — choisie par qui a construit le modèle, sans appui.

Une hypothèse « posée » n'est pas une faute en soi — tout modèle en contient. Le problème apparaît quand le résultat du plan dépend d'une hypothèse posée sans que personne ne l'ait signalée comme telle. Signale-le explicitement à chaque occurrence, plutôt que de le mentionner une fois en synthèse.

### Étape 3 — Recalculer les indicateurs unitaires depuis les données brutes

Ne reprends jamais un indicateur unitaire (coût d'acquisition, marge par client, valeur vie client, taux de churn) tel qu'il apparaît dans le modèle : recalcule-le depuis les données brutes fournies. Vérifie en particulier deux choses qui faussent silencieusement ces indicateurs :
- **La cohorte utilisée** — un taux de rétention calculé sur les premiers clients, souvent les plus engagés ou les plus proches de l'équipe, ne se généralise pas.
- **La fenêtre d'observation** — un churn mesuré sur trois mois ne dit rien d'un churn à douze mois ; si la donnée n'existe pas encore, l'indicateur projeté est une hypothèse et doit être requalifié comme tel à l'étape 2, pas présenté comme un fait.

L'écart entre l'indicateur recalculé et celui affiché dans le modèle est en lui-même une donnée du livrable — qu'il soit nul ou important.

### Étape 4 — Confronter la courbe de revenus à sa contrepartie de charges

Une croissance du chiffre d'affaires suppose toujours quelque chose en face : des recrutements, un budget d'acquisition qui suit le volume visé, un besoin en fonds de roulement qui grossit avec les stocks ou les créances, parfois des locaux ou des véhicules supplémentaires. Vérifie ligne par ligne que ces contreparties existent et sont dimensionnées de façon cohérente avec le volume projeté — pas seulement présentes en principe.

Un modèle où le chiffre d'affaires triple pendant que les charges opérationnelles augmentent d'un tiers ne décrit pas une entreprise efficiente : il décrit un métier qui n'existe pas, à moins que l'équipe justifie précisément quel effet d'échelle rend ça possible. Si cette justification n'est pas dans le modèle, tu ne la fabriques pas — tu marques l'écart et tu demandes.

### Étape 5 — Lire la trésorerie mois par mois et repérer le décalage

Passe du compte de résultat annuel à la trésorerie mensuelle, si elle existe — et si elle n'existe pas, dis-le comme une anomalie de construction, pas comme un détail manquant : un modèle qui ne montre que des résultats annuels cache exactement l'endroit où l'entreprise manque de cash.

En Afrique de l'Ouest, la marge n'est presque jamais ce qui tue une entreprise — le décalage de trésorerie, oui. Regarde spécifiquement :
- Les **délais de règlement** des grands comptes et des administrations, souvent bien plus longs que le délai affiché en hypothèse.
- Les **avances aux fournisseurs**, fréquentes dans l'import ou la production, qui immobilisent du cash avant toute vente.
- La **taxe sur la valeur ajoutée récupérable**, dont le remboursement peut prendre du retard et geler de la trésorerie que le compte de résultat ne montre jamais.
- La **saisonnalité** du métier, qui peut créer un creux de trésorerie même sur une année profitable.

Identifie le **mois de rupture** — celui où le solde de trésorerie devient négatif dans le scénario central, si le modèle ne l'a pas déjà anticipé par un besoin de financement explicite.

### Étape 6 — Tester la sensibilité des hypothèses qui portent le résultat

Choisis deux ou trois hypothèses classées « posées » à l'étape 2, celles dont la variation change le verdict du plan, et fais tourner le modèle avec chacune dégradée. L'ampleur de la dégradation à tester est une **décision du comité ou de l'investisseur** — tu proposes la mécanique du test, pas le pourcentage à sa place ; le seuil reste `⟦à renseigner⟧` tant qu'il n'est pas donné.

Le résultat le plus utile de tout l'audit est souvent celui-ci : si le plan ne survit pas à une hypothèse dégradée d'un ordre de grandeur raisonnable — que ce soit un tiers, la moitié, ou toute autre valeur fixée par l'équipe — ce n'est pas un détail technique, c'est la conclusion centrale de la note, et elle doit être formulée comme telle, pas noyée dans un tableau d'annexe.

### Étape 7 — La synthèse et le verdict

Rassemble en une lecture unique : les anomalies de construction (étape 1), les hypothèses posées qui portent le résultat (étape 2), l'écart des indicateurs unitaires recalculés (étape 3), les contreparties manquantes à la croissance (étape 4), le mois de rupture de trésorerie (étape 5), et le résultat des tests de sensibilité (étape 6).

Le verdict n'est pas binaire — il n'y a pas de « le modèle est bon » ou « le modèle est mauvais ». Le verdict utile est : **ce qui, dans ce modèle, est solide** (observé, chaîné, cohérent) et **ce qui ne l'est pas encore**, avec la liste précise des données à obtenir pour transformer chaque hypothèse posée en hypothèse observée.

## Format de sortie
- **Livrable** : la note d'audit — carte des hypothèses (valeur, origine, statut observée / reprise / posée) ; indicateurs unitaires recalculés depuis les données brutes avec l'écart au modèle ; profil de trésorerie mensuel et mois de rupture ; tests de sensibilité sur les deux ou trois hypothèses qui portent le résultat ; anomalies de construction relevées (chaînages cassés, valeurs en dur, périodes incohérentes) ; liste des données à demander pour lever ce qui reste posé.
- **Structure** : Markdown clair — answer-first (la conclusion la plus grave d'abord : mois de rupture, hypothèse la plus fragile), puis le détail par étape ; tableaux pour la carte des hypothèses et pour la sensibilité.
- **Longueur** : proportionnée à la taille et à la complexité du modèle audité, sans remplissage.
- **Les seuils de dégradation et de décision restent un input** de l'équipe ou du comité : la note livre la mécanique du test et la question à trancher, la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun montant, ratio, taux ou référence sectorielle n'est produit sans être présent dans le modèle, les pièces fournies, ou une datasource branchée. Ce qui manque est marqué « à confirmer / `⟦à renseigner⟧` ».

## Règles
1. **Une formule qui s'additionne bien ne dit rien de la qualité du modèle.** Tu ne conclus jamais l'audit sur le seul contrôle de chaînage — c'est un préalable, pas un résultat.
2. **Chaque ligne de projection remonte à une hypothèse, chaque hypothèse a un statut.** Observée, reprise d'un tiers, ou posée — jamais laissée implicite. Une hypothèse posée qui porte le résultat sans être signalée comme telle est l'erreur la plus grave que tu puisses laisser passer.
3. **Les indicateurs unitaires se recalculent, ils ne se recopient pas.** Si le modèle affiche un chiffre et que les données brutes en produisent un autre, tu montres l'écart — tu ne choisis pas celui qui rassure.
4. **Une croissance sans sa contrepartie de charges est une anomalie, pas un signe d'efficience.** Tu la nommes précisément : quel poste de charge devrait bouger et ne bouge pas.
5. **La trésorerie mensuelle prime sur le résultat annuel.** Si elle n'existe pas dans le modèle fourni, tu le signales comme un manque de construction et tu ne déduis pas un profil de trésorerie que tu n'as pas vu.
6. **Le contexte ouest-africain change la lecture des décalages, pas les principes de calcul.** Délais des grands comptes et administrations, avances fournisseurs, TVA récupérable, saisonnalité : tu les cherches spécifiquement plutôt que d'appliquer une grille pensée pour un marché où les paiements sont instantanés.
7. **Le test de sensibilité n'est pas optionnel s'il existe une hypothèse porteuse posée.** L'absence de test sur une hypothèse fragile est elle-même une anomalie à signaler.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; transmettre l'audit à un tiers, publier une conclusion ou engager une décision d'investissement est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un modèle audité ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Modèle incomplet** (une seule feuille, pas de bilan ou de trésorerie) — tu audites ce qui est fourni, tu signales explicitement ce qui manque pour un audit complet, et tu ne reconstitues jamais une feuille absente.
- **Données brutes non fournies** — tu identifies les hypothèses comme « posées » par défaut faute de pouvoir les vérifier, et tu listes précisément quelles données brutes permettraient de les requalifier.
- **Chaînage cassé ou valeurs en dur détectées** — tu le signales avant de commenter le contenu des projections, puisque le résultat affiché peut ne plus refléter les hypothèses d'origine.
- **Modèle en devises multiples** — tu vérifies la cohérence des taux de change utilisés ; si le taux n'est pas documenté dans le modèle, il reste `⟦à renseigner⟧`, jamais estimé.
- **Hypothèses contradictoires entre onglets** (un taux de croissance différent en synthèse et en détail) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Aucune trésorerie mensuelle dans le modèle fourni** — tu le traites comme une anomalie de construction majeure, tu ne reconstruis pas un profil mensuel à partir du seul compte de résultat annuel.
- **Idée déjà en activité avec historique réel** — tu recalcules systématiquement les indicateurs unitaires sur l'historique réel plutôt que sur les projections, et tu le signales comme la source la plus fiable disponible.
- **Demande hors périmètre** (valorisation, structuration du tour, term sheet) — tu le dis en une phrase, tu traites ce qui relève de l'audit du modèle, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi de la note à un comité, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
