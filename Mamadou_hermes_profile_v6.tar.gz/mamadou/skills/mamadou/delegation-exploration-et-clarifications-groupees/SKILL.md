---
name: "delegation-exploration-et-clarifications-groupees"
version: 1.0.0
description: "Délègue aux sous-agents le travail auto-suffisant et regroupe les clarifications avant correction, pour réduire lenteur et charge de contexte."
maj: 2026-09-03
---

## Pourquoi cette pratique existe

Observé le 19/08/2026 (session Telegram "Mamadou", topic unique mélangeant plusieurs sujets) :
une session de 8h35 avait accumulé 188k tokens de contexte et subi 2 compactions en traitant à
la suite un exercice d'entraînement BP fictif, une conciliation réelle [entreprise cliente] sur plusieurs jours,
et une question méta. Deux symptômes concrets de cette dérive :

1. **Une correction appliquée au mauvais périmètre.** Une instruction de correction ("les
   1.150.000 + 550.000 + 14.892 = 1.714.892") a été appliquée par erreur à deux journées (17 et
   18/08) alors qu'elle ne concernait que le 18/08 — l'ambiguïté du périmètre n'avait pas été
   levée avant d'agir, elle a été découverte après coup par le client, qui a dû corriger.
2. **Cinq échanges pour converger sur un point qui en demandait deux.** Le rapprochement du
   solde Push a nécessité plusieurs allers-retours parce que chaque supposition non vérifiée a
   généré une nouvelle question, au lieu qu'elles soient posées ensemble dès le départ.

Ces deux symptômes ne sont pas propres à une entreprise : c'est un problème de méthode de
travail, applicable à toute session, toute entreprise du portefeuille.

## Règle 1 — Déléguer aux sous-agents le travail auto-suffisant

**Critère de délégation** : une tâche est déléguable à un sous-agent (`sessions_spawn`, sans
`context: "fork"` sauf si le sous-agent a explicitement besoin de la transcription en cours)
dès qu'elle réunit ces trois conditions :
- Elle comporte plusieurs étapes d'exploration ou de construction (lecture de fichiers multiples,
  analyse d'images, recalculs itératifs, construction d'un classeur étape par étape).
- Elle ne dépend pas de l'historique conversationnel du fil principal — le brief donné au
  sous-agent contient tout ce qui est nécessaire (objectif, sources, contraintes, format de
  sortie attendu, chemin d'écriture).
- Le fil principal n'a besoin, au retour, que du résultat fini et d'un résumé compact — pas du
  détail de chaque étape intermédiaire.

**Application concrète, déjà validée le 19/08/2026** : les 3 classeurs d'entraînement BP ont été
produits par des sous-agents en parallèle (2 tournant simultanément), pendant que le fil
principal restait disponible pour d'autres échanges. Résultat : le fil principal n'a absorbé que
les rapports de synthèse, pas les dizaines d'étapes de construction/correction de chaque
classeur.

**Ce qui manque encore et doit devenir systématique** : les phases d'exploration lourdes d'une
conciliation ou d'un rapprochement (dépouillement de plusieurs exports SI, lecture de nombreuses
captures d'écran, recalculs LibreOffice répétés pour converger sur un montant) devraient elles
aussi être déléguées quand elles ne nécessitent pas l'historique du fil — au lieu d'être
exécutées en ligne comme cela a été fait le 19/08/2026 pour la conciliation [entreprise cliente] (tout le
dépouillement SI + lecture d'images + construction de classeurs a été fait dans le fil principal,
gonflant son contexte alors que rien de tout cela ne dépendait de la conversation elle-même).

**Ce qui reste dans le fil principal** : les échanges de clarification eux-mêmes, les décisions
qui engagent (validations, arbitrages), et la restitution finale au client.

## Règle 2 — Regrouper les clarifications avant d'exécuter une correction

**Signal qui doit déclencher une clarification groupée AVANT d'agir**, pas après :
- Une instruction de correction dont le périmètre (temporel, par entité, par compte) n'est pas
  explicitement délimité dans le message reçu.
- Une correction qui, par analogie avec une correction précédente similaire, pourrait être
  étendue par réflexe à un périmètre plus large que celui réellement visé — l'analogie n'est pas
  une confirmation.
- Plusieurs inconnues distinctes qui se recoupent dans un même calcul (ex. deux références
  différentes à mettre à jour séparément) — poser toutes les questions ensemble, pas une par une
  au fil des découvertes.

**Méthode** : avant d'exécuter une modification sur un livrable existant (fichier, classeur,
rapport déjà produit), lister explicitement toutes les zones d'ambiguïté identifiées et les
poser en une seule salve de questions, plutôt que d'agir sur une hypothèse puis de corriger après
retour du client. Formulation type : "Cette correction s'applique à [périmètre A], [périmètre B],
ou aux deux ?" — jamais supposer silencieusement le périmètre le plus large ou le plus étroit.

**Exception légitime à ne pas confondre avec un manque de rigueur** : quand le contexte fourni
permet de lever l'ambiguïté sans poser de question (ex. une instruction datée qui ne peut
raisonnablement viser que la période en cours de traitement), agir directement reste correct —
la règle vise les cas où l'ambiguïté est réelle et où une hypothèse non vérifiée a un coût de
correction non négligeable (reprise d'un livrable déjà transmis).

## Ce que cette pratique ne remplace pas

- Elle ne remplace pas la discipline d'audit (mise en zone tampon, non-écrasement, double
  regard) déjà en vigueur sur les rapprochements — elle s'y ajoute.
- Elle ne dispense pas de vérifier sur disque le résultat produit par un sous-agent avant de le
  transmettre comme fini (cf. l'épisode #486 où la vérification sur disque, pas seulement le
  rapport du sous-agent, a été explicitement mentionnée comme nécessaire).
- Le levier structurel le plus fort (un fil/topic dédié par entreprise ou par sujet récurrent)
  reste hors du périmètre de cette pratique : il dépend d'une décision côté organisation
  Telegram du client, pas d'un changement de méthode de travail autonome.

## Mesure de succès

Sur les sessions suivantes, on doit observer moins d'allers-retours de correction après un
premier résultat transmis, et un contexte de fil principal qui croît plus lentement pour un
volume de travail équivalent (moins de compactions par unité de travail livré).
