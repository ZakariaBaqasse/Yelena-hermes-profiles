---
name: livrable-html-pdf
version: 1.0.0
description: "Fabriquer et livrer un document destiné à la direction : HTML autonome soigné puis export PDF (format de livraison par défaut), contrôle visuel du rendu avant envoi, pièges WeasyPrint constatés, versionnage et règle de publication. À charger dès qu'un livrable est produit — revue de presse, veille, note, brief, relevé."
maj: 2026-09-03
---

# Livrable HTML → PDF

Chaîne de fabrication de tout document destiné à la direction. Le fond passe par les skills métier
(revue de presse, note de décision, brief…) ; **celui-ci ne traite que la forme et la livraison.**

## Règle de format — arrêtée le 01/08/2026

**Le PDF est le format de livraison par défaut.** On écrit en HTML autonome, on rend en PDF, on
envoie le PDF sur Telegram et on garde le HTML à côté comme source réutilisable.

```
deliverables/<projet>/<slug>_vN.html    ← source
deliverables/<projet>/<slug>_vN.pdf     ← ce qu'on envoie
```
Même `N` pour les deux formats. Une révision = un nouveau `_v(N+1)`, jamais d'écrasement.

## Ce que le document doit porter

- **Bandeau** : entreprise, période couverte, heure d'arrêt, prochaine échéance connue.
- **Sources cliquables et datées** sur chaque affirmation — les liens restent actifs dans le PDF.
- **Un bloc « Pourquoi ça compte pour la direction »** par sujet.
- **Visa de contrôle** en fin de document (5 passes, compteurs, statuts revérifiés, réserves).
- **Pied de page** : mention « document interne — ne pas diffuser hors de l'entreprise ».

## Fabrication

```bash
weasyprint <slug>_vN.html <slug>_vN.pdf
pdfinfo <slug>_vN.pdf | grep -i pages          # contrôle du volume
pdftoppm -png -r 68 -f 1 -l 2 <slug>_vN.pdf /tmp/apercu   # relecture visuelle avant envoi
```

**Toujours relire au moins la première page en image avant d'envoyer.** Un PDF qui sort à
14 pages à moitié vides ou sans ses icônes est un livrable raté, et cela ne se voit pas
dans le HTML.

## Pièges WeasyPrint — constatés, pas supposés

| Ce qui casse | Ce qu'il faut écrire |
|---|---|
| `linear-gradient` multi-arrêts | trois `<i>` en `display:flex` avec `background` plein |
| `grid-template-columns:repeat(auto-fit,minmax(...))` | `display:flex; flex-wrap:wrap` + `flex:1 1 110px` |
| `stroke` / `fill` / `stroke-width` en CSS sur un SVG | attributs de présentation sur la balise `<svg>` |
| `@media (max-width:520px)` | `@media screen and (max-width:520px)` |
| `@media (prefers-color-scheme: dark)` | ignoré en PDF — le rendu sort en thème clair, c'est voulu |
| `font-weight:650` | valeur non standard → `600` |

## Feuille d'impression — sinon le volume double

Sans `@media print` resserré, un document de 8 pages en sort 14, à moitié vides : `break-inside:avoid`
sur des blocs d'une demi-page pousse chaque item sur une nouvelle page.

```css
@page{ size:A4; margin:14mm 13mm 16mm; }
@media print{
  body{font-size:9.6pt; line-height:1.5; background:#fff}
  .item, li{break-inside:auto}          /* PAS avoid sur les gros blocs */
  h3, h4{break-after:avoid}             /* le titre reste avec son texte */
  .facts, .encadre, .sources{break-inside:avoid}   /* avoid seulement sur les petits blocs */
}
```

## Publication

Le lien public (GitHub Pages) est réservé aux documents **bâtis sur sources publiques** :
revues de presse, veilles, fiches partenaires ou concurrents. **Ne jamais publier** une note de
décision, un cadrage de réunion, un relevé ou un brief de rendez-vous — ils sont remis en main
propre sur le canal de la direction. GitHub Pages est public : un dépôt privé ne sert pas de
site sans plan payant.

⚠ La publication suppose un jeton d'accès valide, rangé dans le magasin de secrets de la machine
(jamais en clair dans un script). Vérifier qu'il n'est pas expiré **avant** d'annoncer un lien :
un `401` se découvre sinon au moment de livrer.

## Message d'accompagnement

Le PDF part avec un message Telegram qui dit **ce qui a changé** depuis la version précédente et
**ce qui reste ouvert** — jamais un simple « voici le document ».
