---
id: Y0658
name: moteur-de-matching
version: 1.0.0
description: "Définit et applique la cascade d'appariement de deux jeux de transactions : identifiant, puis montant et date exacts, puis date décalée, puis clé métier avec tolérance de frais, puis agrégats. Marque la confiance de chaque appariement, refuse de trancher toute ambiguïté, et sait dire quel taux de validation humaine attendre selon les clés disponibles. Compétence technique appelée par les compétences de réconciliation, jamais utilisée seule."
bucket: B
tags: [Finance, Contrôle, Technique, Nouveau]
maj: 2026-09-03
---

# Le moteur de matching — apparier sans jamais deviner

## Rôle

Cette compétence ne produit pas de livrable pour le client : elle porte les règles
d'appariement qu'appliquent `etat-rapprochement` et `reconciliation-a-priori`, et le
raisonnement qui justifie leur ordre.

## La cascade, et pourquoi elle est ordonnée ainsi

L'ordre n'est pas une commodité d'implémentation : chaque passe consomme des lignes, et une
passe dégradée exécutée trop tôt vole des candidats à une passe sûre.

| # | Passe | Critère | Confiance | Ce qu'elle attrape |
|---:|---|---|---|---|
| 1 | Référence | identifiant de transaction identique | **certaine** | tout ce qui porte une clé technique commune |
| 2 | Montant et date | montant exact, même jour | **certaine** | le cas nominal quand il n'y a pas d'identifiant |
| 3 | Date décalée | montant exact, date dans une fenêtre | **forte** | le décalage de valeur, le week-end, la saisie du lendemain |
| 4 | Clé métier | téléphone ou tiers identique, montant à tolérance de frais | **à valider** | l'encaissement dont la commission a été retenue |
| 5 | Agrégat | un mouvement contre plusieurs, somme exacte | **à valider** | le virement groupé, le remboursement fractionné |

**Passe 1 avant tout.** Un identifiant partagé est la seule preuve d'appariement qui ne repose
sur aucune hypothèse. Chaque ligne qu'elle consomme est une ligne que les passes suivantes
n'auront pas à deviner.

**Passe 2 avant la 3.** Si la fenêtre de dates est ouverte trop tôt, un mouvement du jour peut
être apparié à un mouvement de la veille du même montant, et le vrai correspondant se retrouve
orphelin. Le résultat tombe juste et il est faux.

**Passe 4 après les passes exactes.** La tolérance de frais est le réglage le plus dangereux du
dispositif : elle autorise un écart de montant. Ouverte trop tôt ou trop large, elle apparie des
mouvements différents.

**Passe 5 en dernier, et bornée.** La recherche de combinaison est exponentielle. Elle se borne
en profondeur et en nombre de candidats, et quand elle renonce, elle **le dit** — un renoncement
silencieux se lit comme une absence de correspondance, ce qui est faux.

## La règle qui compte plus que la cascade

> **Plusieurs candidats équivalents = aucun appariement.**

Elle se paie cher et elle se tient. Apparier au hasard entre deux candidats identiques fait
tomber le total juste tout en associant deux mauvaises lignes — et **la justesse du total est
précisément ce qui empêche de le découvrir**. La ligne remonte en annexe avec ses candidats, et
un humain tranche.

Cas type : deux encaissements de 25 000 le même jour, deux tiers différents. Sans téléphone ni
identifiant, il n'y a pas de réponse — il y a un arbitrage.

## Ce que la cascade produit sur le bouclage

Un appariement de passe 4 laisse un résidu : le brut d'un côté, le net de l'autre. Ce résidu
n'est **pas** un suspens — la transaction est appariée — mais il entre dans l'explication de
l'écart de soldes, sur sa propre ligne : *écarts d'appariement, frais retenus*.

Un état qui oublie cette ligne ne boucle pas, et on cherche pendant une heure un suspens qui
n'existe pas.

## Le réglage, et ce qu'il coûte

| Paramètre | Trop serré | Trop large |
|---|---|---|
| Fenêtre de dates | des orphelines qui n'en sont pas, du travail humain inutile | des faux positifs invisibles |
| Tolérance de frais | les encaissements nets remontent tous en suspens | des mouvements différents appariés |
| Clés secondaires | taux d'appariement faible | **le pire des deux** : une clé peu discriminante apparie beaucoup et mal |
| Profondeur d'agrégat | les virements groupés ne se retrouvent pas | temps de calcul, et combinaisons fortuites |

**Une règle de réglage, une seule :** en cas de doute, serrer. Une orpheline coûte cinq minutes
de vérification humaine. Un faux positif coûte un écart qu'on cherchera trois mois plus tard,
dans le mauvais compte.

## Annoncer le taux de validation attendu, avant de commencer

Selon les clés disponibles, la part d'appariements « à valider » se prévoit — et elle
**s'annonce**, parce qu'elle détermine la charge humaine que le dispositif crée. Un client à qui
l'on promet l'automatisation et qui découvre qu'il doit valider un tiers des lignes se sent
trompé, à raison.

| Situation | Ce qu'on annonce |
|---|---|
| Identifiant partagé des deux côtés | l'essentiel en passe 1, validation résiduelle |
| Pas d'identifiant, montants nets, tiers identifié | les passes 2-3 portent le gros, la 4 le reste |
| Pas d'identifiant, pas de tiers, montants récurrents | **taux d'ambiguïté élevé** — le référentiel de tiers devient le premier chantier |

Ces trois lignes se disent en toutes lettres au cadrage. Elles ne se chiffrent pas de mémoire :
le taux réel se mesure sur la première période, il ne se prédit pas.

## Garde-fous

- Jamais d'appariement sans passe enregistrée.
- Jamais d'ambiguïté tranchée automatiquement.
- Jamais de renoncement silencieux.
- Jamais de tolérance élargie **pendant** un traitement pour faire tomber le total : c'est
  exactement le geste qui fabrique un état faux qui a l'air juste. Un réglage se change avant, et
  le changement se consigne dans la piste d'audit.
