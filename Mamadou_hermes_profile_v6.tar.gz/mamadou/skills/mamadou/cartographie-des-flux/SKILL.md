---
id: Y0660
name: cartographie-des-flux
version: 1.0.0
description: "Construit la carte des flux financiers d'une entreprise avant toute réconciliation : quels types d'opérations existent, quels comptes de trésorerie chacune impacte, quel identifiant la porte, quel tiers elle engage, et lesquels de ces flux appartiennent à l'entreprise ou à des tiers. Sort la matrice des rapprochements à mettre en place, priorisée, et signale les comptes non dédiés qui rendent tout contrôle ininterprétable."
bucket: B
tags: [Finance, Contrôle, Cadrage, Nouveau]
maj: 2026-09-03
---

# La cartographie des flux

## Pourquoi elle passe avant tout le reste

Un rapprochement lancé sans carte apparie ce qui tombe et laisse le reste en vrac. Pire : il donne
l'illusion du contrôle sur un périmètre qu'on n'a jamais délimité.

La question à laquelle cette compétence répond n'est pas « comment rapprocher » mais **« qu'est-ce
qu'il y a à rapprocher, et dans quel ordre ».**

## Process

### Étape 1 — Recenser les comptes, tous

Banques, wallets par opérateur, comptes d'opération chez un agrégateur, caisses, comptes de
cantonnement. Pour chacun : établissement, devise, format d'extrait, qui y a accès, et **s'il est
dédié aux opérations ou s'il sert aussi aux charges internes**.

⚠️ La dernière colonne est celle qui compte. Un compte par lequel transitent des flux
appartenant à des tiers et depuis lequel on paie aussi les salaires rend tout rapprochement
ininterprétable — un écart peut venir d'une opération client ou d'une charge interne, et rien ne
permet de trancher. Quand c'est le cas, **c'est le premier point à remonter au dirigeant**, avant
le premier état.

### Étape 2 — Recenser les types d'opérations

Encaissement, transfert, reversement, décaissement, remboursement, frais, pénalité, régularisation.
Pour chacun : quel compte il impacte, dans quel sens, quel identifiant le porte, quel tiers il
engage, et à quel moment il est constaté de chaque côté.

### Étape 3 — Distinguer ce qui appartient à l'entreprise et ce qui appartient à des tiers

C'est la question structurante pour toute activité qui manipule l'argent d'autrui. Une partie des
flux traités ne revient pas à l'entreprise : elle porte un engagement envers un tiers.

Conséquence directe : un solde de compte d'opération n'est pas de la trésorerie disponible. Le
confondre avec la trésorerie de l'entreprise est l'erreur qui fait prendre des décisions
d'investissement sur de l'argent qu'on doit à quelqu'un d'autre.

### Étape 4 — Repérer les points de rupture

Là où une information change de main ou de format : export du système d'information, réception
d'un extrait, saisie comptable, agrégation. **Chaque rupture est un endroit où un écart naît**, et
la carte doit les nommer.

### Étape 5 — Sortir la matrice des rapprochements

| Objet | Source A | Source B | Périodicité | Clé disponible | Priorité |
|---|---|---|---|---|---|
| ⟦compte⟧ | ⟦extrait⟧ | ⟦livres ou SI⟧ | ⟦⟧ | ⟦identifiant / date+montant / aucune⟧ | ⟦⟧ |

**La priorisation obéit à une règle simple, éprouvée** : commencer par ce dont la donnée existe
déjà et ne dépend de personne d'autre. Le rapprochement bancaire classique remplit ces deux
conditions dans presque toutes les entreprises — la comptabilité a déjà les extraits, elle a
souvent déjà des rapprochements faits qui servent de base de comparaison, et rien n'attend un
tiers.

Un chantier qui dépend d'un export qu'une équipe doit encore construire attend des semaines. On
le lance quand même, mais on ne le met pas en premier.

## Format de sortie

La fiche de cartographie : comptes, types d'opérations, matrice des rapprochements priorisée,
points de rupture, et **la liste des questions ouvertes** — celles dont la réponse change le
dispositif. Elle se relit avec le dirigeant et le comptable ensemble, jamais séparément : c'est
souvent en réunissant les deux qu'on découvre qu'un compte n'est pas utilisé comme on le croyait.

## Garde-fous

- **Aucun compte inventé, aucun canal supposé** parce qu'il « existe généralement » dans ce
  secteur. Ce que tu n'as pas vu, tu le demandes.
- **Aucune structure de commission de mémoire.** Elle se relève sur les extraits réels ou sur le
  barème fourni.
- **La carte porte sa date.** Elle se périme dès qu'un compte s'ouvre — et elle se périme en
  silence.
