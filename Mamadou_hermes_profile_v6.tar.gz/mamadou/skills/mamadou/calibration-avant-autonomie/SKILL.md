---
name: "calibration-avant-autonomie"
description: "Calibre un rapprochement/réconciliation sur une archive déjà produite (humain ou autre outil) avant de le faire tourner en autonome sur une entreprise."
version: "1.0.0"
date: "2026-08-14T19:27:02.783Z"
bucket: B
tags: [Finance, Contrôle, Méthode, Nouveau]
maj: 2026-09-03
---

# Calibrer avant de tourner en autonome

## Pourquoi cette compétence existe

Une entreprise transmet parfois une archive de rapprochements ou de réconciliations déjà
produits — par un cabinet, un salarié, un autre outil. C'est une occasion rare : au lieu de
partir à blanc, on peut mesurer, avant toute production réelle, si la méthode qu'on s'apprête à
appliquer reproduit ce qui a déjà été validé. Le faire sérieusement — sans arrondir les écarts,
sans les cacher dans une moyenne — est ce qui permet de dire honnêtement à quel point on est prêt,
et sur quel périmètre précis.

Cette compétence n'est pas propre à une entreprise ni à un type de rapprochement. Le cas d'usage
initial était une réconciliation Agency Banking ([entreprise cliente], portefeuille Yelema), mais la méthode
s'applique à tout dispositif de contrôle testable contre un historique : état de rapprochement
bancaire, réconciliation a priori, budget contre réalisé, tout ce qui produit un résultat chiffré
périodique déjà archivé ailleurs.

## Quand l'utiliser

- Une archive de résultats déjà produits existe (rapports, fichiers de résultat, exports) pour une
  période passée, avec les sources qui ont servi à les produire.
- On s'apprête à faire tourner un dispositif de rapprochement en autonome sur une entreprise et on
  veut mesurer la fiabilité avant de livrer un premier résultat réel.
- Un client demande « es-tu capable de faire ce travail » et la meilleure réponse est une preuve
  chiffrée, pas une promesse.

## Process

### Étape 1 — Cartographier l'archive avant de calculer quoi que ce soit

Lister ce qui existe réellement, période par période : quelles sources brutes sont disponibles
(exports texte, fichiers de contexte, captures d'écran), et quel résultat de référence existe pour
chaque période (rapport archivé, avec sa version la plus finale s'il y en a plusieurs — un
suffixe `CORRIGE`, `RECTIFICATIF` ou `FINAL` remplace toujours une version antérieure). Ne jamais
supposer qu'une période a un résultat de référence sans l'avoir vérifié : certaines n'en ont pas,
et c'est une information en soi, pas un trou à combler.

### Étape 2 — Recalculer depuis les sources brutes, jamais depuis le résultat archivé

Le calcul se fait sur les fichiers sources (export du système, relevés, extraits), sans jamais
regarder le résultat de référence avant d'avoir produit le sien. Regarder d'abord la réponse et
ajuster le calcul pour y arriver n'est pas une calibration, c'est une reconstitution — elle ne
prouve rien sur la capacité à traiter une période neuve.

Quand une donnée n'existe que sous forme d'image (capture d'écran d'une application, relevé
scanné), elle se lit à l'outil d'analyse d'image. Un chiffre coupé ou flou reste absent, jamais
deviné — le signaler explicitement plutôt que de l'approcher.

### Étape 3 — Comparer période par période, sans agréger avant de comparer

Chaque période testée reçoit un statut :
- **CONCORDANT** — le calcul reproduit exactement le résultat de référence.
- **DIVERGENT** — un écart existe. Il se documente avec les deux valeurs et l'écart brut, jamais
  arrondi ni absorbé dans un commentaire vague. La cause s'établit si elle est trouvable : source
  disparue de l'archive, donnée externe non recoupable, différence de périmètre.
- **PAS DE RÉFÉRENCE** — aucun résultat archivé pour cette période. Le calcul se produit quand
  même et se garde, mais sans validation externe possible.

Ne jamais mélanger ces trois catégories dans un seul taux de réussite global : un lecteur qui voit
« 90 % de succès » sans savoir combien de périodes n'avaient tout simplement rien à comparer se
fait une fausse idée de la fiabilité réelle.

### Étape 4 — Distinguer une divergence de méthode d'une divergence de source

Une divergence n'est pas automatiquement un échec de la méthode. Elle peut venir d'une source que
l'archive transmise ne contient plus (un fichier corrigé remplacé sans que l'original soit
conservé), d'une confirmation opérationnelle obtenue hors du système (un appel, un message, une
validation orale jamais tracée dans les fichiers), ou d'un reclassement métier qui change le
périmètre d'une ligne. Dans ces cas, la vérité est double : le calcul est correct **sur les
données disponibles**, et la référence archivée s'appuyait sur des données qui ne sont plus
transmises. Dire les deux, ne pas choisir l'une pour paraître plus juste.

### Étape 5 — Repérer les limites systématiques, pas seulement les écarts ponctuels

Une limite systématique est différente d'une divergence isolée : c'est un type de donnée qui
manque **structurellement**, quel que soit le jour testé. Exemple type : une capture d'écran
d'application mobile qui liste des mouvements mais n'affiche jamais de solde total — dans ce cas,
tester dix jours de plus ne changera rien, la limite est dans ce que montrent les captures, pas
dans la méthode de lecture. Une fois identifiée, elle se documente une fois pour toutes plutôt que
d'être redécouverte à chaque nouvelle période testée, et elle borne explicitement ce que le
dispositif peut produire en autonome (par exemple : exhaustivité des mouvements oui, solde de
clôture vérifié non, tant que cette source manque).

### Étape 6 — Rendre un verdict honnête, pas un résultat qui a l'air propre

Le livrable de calibration dit trois choses, dans cet ordre :
1. Ce qui est reproductible avec certitude (le taux réel, périodes concordantes sur périodes
   testées, jamais gonflé par les périodes sans référence).
2. Ce qui diverge et pourquoi, sans exception.
3. Ce qui manque structurellement pour aller plus loin, et ce que ça implique concrètement pour
   la suite — quel type de résultat le dispositif peut produire seul dès maintenant, et lequel
   nécessite encore une source ou une validation externe.

Un test sur un échantillon (« ça marche sur les 5 derniers jours ») ne remplace jamais la
calibration complète : la valeur est dans la couverture, pas dans un résultat qui a l'air propre
parce qu'on n'a regardé que les cas faciles. Sur demande de vérification ciblée, retester au moins
une période déjà connue (pour confirmer la reproductibilité) et une période jamais travaillée
(pour confirmer que ce n'est pas de la mémorisation du résultat archivé) — les deux ensemble,
jamais l'un sans l'autre.

## Format de sortie

Un rapport Markdown avec :
- Une synthèse en tête : nombre de périodes testées, concordantes, divergentes, sans référence ;
  et si applicable, le taux de complétude d'un sous-objectif (par exemple : solde bouclé
  complètement / partiellement / pas du tout).
- Le détail de chaque divergence, avec les deux valeurs et l'écart brut.
- La liste des limites systématiques identifiées, avec leur cause.
- Un tableau récapitulatif période par période, pour que la couverture complète soit vérifiable
  sans avoir à relire tout le rapport.

Rangé aux côtés de l'archive testée (`rapprochements/<compte-ou-entreprise>/` ou équivalent), pas
noyé dans un livrable destiné au client — c'est un document de calibration interne, qui prépare le
premier rapprochement réel, il ne le remplace pas.

## Règles

1. **Le calcul se fait avant de regarder la référence**, jamais après pour l'ajuster.
2. **Aucun écart ne se lisse.** Deux valeurs et un écart brut, toujours.
3. **Une capture ou un fichier illisible reste illisible dans le rapport** — jamais complété par
   un chiffre plausible.
4. **Concordant, divergent et sans référence ne se mélangent jamais dans un seul taux.**
5. **Une limite systématique se documente une fois, explicitement**, plutôt que d'être répétée à
   chaque période où elle survient sans être nommée comme telle.
6. **Un test de vérification porte toujours sur une période connue et une période neuve.** L'une
   seule ne prouve rien : la connue peut cacher de la mémorisation, la neuve seule ne confirme pas
   la reproductibilité contre une référence.

## Cas limites

- **Volumétrie importante** — déléguer le balayage systématique de toutes les périodes à un
  sous-agent dédié plutôt que de le faire en ligne, pour ne pas monopoliser le fil principal
  pendant un travail long ; le rapport produit reste le même format, la délégation ne change rien
  au contenu attendu.
- **Archive incomplète par construction** (fichiers annoncés mais absents, format inattendu) — le
  signaler explicitement période par période, ne jamais le laisser passer pour une donnée qui
  aurait juste été « non testée ».
- **Résultat de référence lui-même incertain** (plusieurs versions contradictoires archivées sans
  qu'aucune ne soit clairement finale) — le dire, choisir la version la plus documentée comme
  référence de travail en l'indiquant, et ne pas trancher silencieusement pour l'une des deux.
