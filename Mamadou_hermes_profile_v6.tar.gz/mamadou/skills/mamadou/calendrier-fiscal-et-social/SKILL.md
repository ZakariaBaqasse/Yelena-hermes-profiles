---
id: Y0405
name: calendrier-fiscal-et-social
version: 1.0.0
description: "Construit le calendrier des obligations déclaratives et de paiement de l'entreprise à partir de son régime réel et des sources officielles de l'administration fiscale et de l'organisme de protection sociale : qui prépare, qui fournit la donnée, qui valide, quelle date de dépôt, quelle date de paiement — chaque échéance sourcée par un lien officiel, jamais par une date ou un taux cité de mémoire."
bucket: B
tags: [Finance, Conformité, Horizontal, Nouveau]
maj: 2026-09-03
---

# Les échéances fiscales et sociales — qui prépare quoi, et pour quand

## Ce qu'il faut avoir sous la main
- **Le pays** où l'entreprise est immatriculée et opère (le calendrier change d'un pays de la zone à l'autre).
- **Le régime fiscal** tel qu'il figure sur ton attestation d'immatriculation ou ta dernière notification de l'administration fiscale — pas ton estimation, le document.
- **La forme juridique** et le **secteur d'activité**, s'il ouvre droit à un régime particulier.
- **Le nombre de salariés déclarés** et si l'entreprise a des prestataires payés en retenue à la source.
- **Ce que tu as déjà** : dernières déclarations déposées, échéancier reçu de ton conseil fiscal, avis d'imposition — même partiel.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Constater le régime, pas le supposer

Le calendrier entier dépend du régime d'imposition de l'entreprise, et le régime ne se déduit pas de sa taille apparente ni du secteur qu'on lui prête. Deux entreprises qui se ressemblent de l'extérieur peuvent relever de régimes différents selon leur chiffre d'affaires réel, leur forme juridique ou une option qu'elles ont exercée.

Tu constates le régime sur un document officiel : attestation d'immatriculation, notification de l'administration fiscale, dernière déclaration déposée. Si l'entreprise ne fournit que son estimation (« on est une PME, donc probablement ce régime »), tu la traites comme une hypothèse à confirmer, jamais comme un fait établi — et tu le marques explicitement dans le livrable.

Un changement récent de régime (franchissement de seuil, changement d'activité, nouvelle option) rebat tout le calendrier : tu demandes explicitement si un tel changement est intervenu dans les douze derniers mois.

### Étape 2 — Dresser la liste des obligations qui concernent réellement l'entreprise

À partir du régime constaté, de la présence de salariés et de la nature de l'activité, tu établis la liste des déclarations qui s'appliquent : celles liées à l'exploitation, celles liées aux salaires, celles liées à la protection sociale, celles qui relèvent de retenues opérées pour le compte de tiers.

Le piège classique ici est de ne lister que les obligations mensuelles, parce qu'elles créent un réflexe par leur répétition. Les obligations annuelles, les états récapitulatifs et les régularisations sont celles qu'on manque le plus souvent, précisément parce qu'elles ne reviennent pas assez souvent pour s'ancrer dans une routine. Tu les listes à part et tu les signales comme le point de vigilance principal du calendrier.

### Étape 3 — Aller chercher l'échéance sur la source, pas dans ta mémoire

Pour chaque obligation retenue, tu identifies l'administration compétente — administration fiscale pour les impôts et taxes, organisme de protection sociale pour les cotisations, et toute autre autorité sectorielle si l'activité en dépend — et tu cherches sur sa publication officielle : la date de dépôt, la date de paiement, le taux ou le barème applicable.

Chaque donnée reportée dans le calendrier porte son lien source et sa date de consultation. Une donnée que tu ne peux pas retrouver sur une source vérifiable reste `⟦à renseigner⟧` — tu ne la complètes jamais par une date ou un taux « habituellement pratiqué », même si tu l'as vu ailleurs dans la conversation. Une date de loi de finances antérieure ne vaut rien pour l'exercice en cours tant qu'elle n'est pas reconfirmée.

Tu distingues systématiquement la **date de dépôt** de la déclaration et la **date de paiement** de la somme due : elles ne coïncident pas toujours, et une trésorerie construite sur la mauvaise date crée un point bas non anticipé. Tu distingues aussi le **fait générateur** (l'événement qui crée l'obligation — une paie versée, une vente facturée) de l'**exigibilité** (le moment où l'administration peut réclamer) : une entreprise qui les confond déclare au bon montant mais à la mauvaise date, ce qui reste un manquement.

### Étape 4 — Distribuer la responsabilité, pas seulement la date

Une déclaration sociale dépend de données produites par la RH (effectifs, salaires bruts, mouvements du mois). Une retenue à la source sur prestataire dépend des contrats signés en dehors de la finance. Traiter la conformité comme un sujet purement finance est le quatrième piège du métier : la finance ne peut déposer une déclaration correcte que si elle a reçu, à temps, une donnée qu'elle ne produit pas elle-même.

Pour chaque obligation, tu nommes donc quatre rôles distincts, même s'ils se recoupent dans une petite structure : qui **fournit** la donnée source, qui **prépare** le document déclaratif, qui **valide** avant dépôt, qui **dépose et paie**. Une case sans nom est un trou dans le dispositif, tu le signales comme tel plutôt que de la laisser vide silencieusement.

### Étape 5 — Construire le rétroplanning

Pour chaque échéance retenue, tu recules depuis la date de dépôt : la date à laquelle la donnée source doit être disponible, la date à laquelle le document doit être prêt pour validation, la marge de sécurité avant l'échéance légale — en tenant compte de contraintes réelles : un comptable ou un conseil fiscal externe qui sert plusieurs clients au même moment de l'année, une saisie qui dépend d'un relevé bancaire ou d'un relevé mobile money pas encore rapproché, une signature qui nécessite un déplacement.

Le rétroplanning n'a de valeur que si les marges qu'il fixe sont assumées par l'équipe : tu proposes la structure et les jalons, la marge de sécurité en jours est une décision de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.

### Étape 6 — Isoler ce qui doit être confirmé par le conseil fiscal

Tu termines par une liste explicite et séparée : tout point où le régime est ambigu, où une source officielle n'a pas pu être retrouvée, où une situation particulière de l'entreprise (activité mixte, changement récent, contentieux en cours) rend l'application standard incertaine. Cette liste est adressée au conseil fiscal ou au comptable de l'entreprise — elle n'est jamais tranchée par extrapolation depuis un cas voisin.

## Format de sortie
- **Livrable** : le calendrier annuel des obligations, sous forme de tableau — intitulé de l'obligation, administration compétente, périodicité, date de dépôt, date de paiement, qui fournit la donnée, qui prépare, qui valide, qui dépose et paie, lien vers la source officielle, date de consultation de la source.
- **Complément** : le rétroplanning de préparation par échéance (jalons de collecte de donnée, de préparation, de validation, marge de sécurité `⟦à renseigner⟧`), et la liste séparée des points à faire confirmer par le conseil fiscal.
- **Structure** : Markdown — le régime constaté et ses hypothèses d'abord, puis le tableau des obligations classées par périodicité (mensuelles, puis moins fréquentes en tête de vigilance), puis le rétroplanning, puis la liste de confirmation.
- **Toute donnée chiffrée ou datée non vérifiée sur une source officielle** est marquée `⟦à renseigner⟧`, jamais remplie par une valeur plausible ou une date d'un exercice antérieur non reconfirmée.
- **Longueur** : proportionnée au nombre d'obligations réellement applicables — pas de rubriques vides pour faire nombre.

## Règles
1. **0 taux, 0 date, 0 référence légale cités de mémoire.** Chaque échéance, chaque taux, chaque barème du calendrier porte un lien vers une source officielle et une date de consultation. Sans cette source, la case reste `⟦à renseigner⟧`.
2. **Le régime se constate sur un document, il ne se déduit pas.** Une déclaration du client sur son régime sans document à l'appui est traitée comme une hypothèse à confirmer, jamais comme un fait établi.
3. **Dépôt et paiement sont deux dates distinctes**, toujours reportées séparément même quand elles coïncident pour une obligation donnée — la confusion des deux est le piège qui crée les points bas de trésorerie non anticipés.
4. **Les obligations rares sont mises en avant, pas en fin de liste.** Une déclaration annuelle ou une régularisation reçoit la même rigueur de suivi qu'une déclaration mensuelle, précisément parce qu'elle ne bénéficie pas d'un réflexe.
5. **Chaque échéance a un fournisseur de donnée nommé, distinct du préparateur.** Une case sans nom est signalée comme un trou du dispositif, pas laissée vide.
6. **Une donnée d'un exercice antérieur ne vaut pas pour l'exercice en cours** sans reconfirmation sur la source à jour — les taux et barèmes changent par loi de finances.
7. **Le doute se documente, il ne se tranche pas par analogie.** Toute situation ambiguë (activité mixte, changement de régime récent, contentieux) part dans la liste de confirmation par le conseil fiscal, jamais résolue par extrapolation.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter des clients potentiels, publier une page de test ou engager une dépense est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une startup ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Régime non confirmé par un document** — tu produis le calendrier sur l'hypothèse déclarée par le client, tu la marques `[hypothèse : régime X, non confirmé par document]`, et tu places la confirmation du régime en tête de la liste destinée au conseil fiscal.
- **Source officielle introuvable ou inaccessible pour une échéance** — tu marques la case `⟦à renseigner⟧`, tu signales explicitement que la vérification a échoué, et tu ne la remplis jamais par une date ou un taux observé sur un exercice antérieur ou chez une autre entreprise.
- **Changement de régime ou de seuil récent** — tu signales que le calendrier peut être partiellement obsolète dès la publication, et tu places ce point en tête de la liste de confirmation.
- **Entreprise multi-pays** — tu construis un calendrier par pays, sans jamais transposer une date ou un taux d'un pays à l'autre : chaque administration fiscale et chaque organisme de protection sociale sont nationaux.
- **Aucun document fourni, seulement une description orale** — tu produis le calendrier type applicable au régime probable, entièrement étiqueté `[hypothèse : …]`, et tu marques le livrable comme provisoire jusqu'à réception des documents.
- **Demande de calcul d'un montant dû** — hors périmètre de cette compétence : tu identifies l'obligation et sa base légale à sourcer, mais tu n'appliques aucun taux toi-même sans qu'il soit vérifié sur la source ; tu orientes vers le conseil fiscal ou le comptable pour le calcul engageant.
- **Action sortante demandée** (envoi d'une déclaration, paiement, transmission à l'administration) — tu prépares le calendrier et le rétroplanning, et tu t'arrêtes pour validation humaine avant toute transmission.
- **Sources contradictoires entre deux publications officielles** — tu exposes les deux versions avec leurs liens respectifs et tu places le point en confirmation par le conseil fiscal, sans trancher seul.
