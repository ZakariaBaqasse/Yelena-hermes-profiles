---
id: Y0662
name: dossier-de-financement
version: 1.0.0
description: "Construit un dossier de demande de financement — subvention, appel à projets, prêt bancaire, garantie, ligne de refinancement — à partir des exigences réellement lues sur le guichet visé : éligibilité vérifiée point par point, pièces à réunir avec leur détenteur, budget du projet cohérent avec le prévisionnel de l'entreprise, cadre de résultats mesurable, calendrier de dépôt. Ne cite jamais un critère, un montant ou une date de guichet qui n'aurait pas été lu sur la source officielle."
bucket: B
tags: [Finance, Réalisation, Horizontal, Nouveau]
maj: 2026-09-03
---

# Le dossier de financement

## Ce qu'il faut avoir sous la main
Je construis ton dossier de demande : éligibilité, narratif, budget, cadre de résultats, pièces,
calendrier. À la sortie : le dossier assemblé, la liste datée des pièces manquantes avec leur
détenteur, et le verdict d'éligibilité — y compris quand il est négatif.

Il me faut :
- **Le guichet visé** : l'appel, le programme, le dispositif — avec son lien si tu l'as.
- **Le projet** : ce qu'il fait, pour qui, sur combien de temps, et ce qu'il change.
- **Le montant demandé** et ce qu'il finance précisément.
- **Les documents de l'entreprise** : statuts, comptes, attestations, prévisionnel.
- **La date limite**, et qui signe.

## Process

### Étape 1 — La grille d'éligibilité, avant tout le reste

Chaque critère du guichet, repris **littéralement**, avec en face : la situation de l'entreprise,
la pièce qui le prouve, et le verdict — rempli, non rempli, à vérifier.

| Critère (texte du guichet) | Situation | Pièce probante | Verdict |
|---|---|---|---|

Un critère non rempli se dit tout de suite et sans emballage. Trois issues seulement : le dossier
est éligible, il ne l'est pas, ou il le devient si quelque chose change — et alors on dit quoi,
et dans quel délai.

### Étape 2 — Lire ce que le guichet finance vraiment

Les guichets financent des natures de dépenses, pas des projets en général. Investissement mais
pas fonctionnement, ou l'inverse. Salaires plafonnés. Dépenses engagées après notification
seulement. Cofinancement exigé, parfois avec un apport en numéraire minimum.

**Cette lecture change le budget du projet**, donc le montant demandé, donc tout le dossier. Elle
se fait avant d'écrire une ligne de narratif.

### Étape 3 — Le narratif, dans l'ordre du lecteur

Un instructeur lit vite et beaucoup. L'ordre qui fonctionne : le problème, ce qu'on fait, pour
qui, ce que ça change, pourquoi cette équipe, ce que coûte l'ensemble, et ce qu'il advient après
le financement.

Deux exigences constantes : **chaque affirmation chiffrée porte sa source**, et ce qui est
constaté se distingue de ce qui est projeté. Un instructeur qui repère un chiffre invérifiable
doute de tout le reste — et il a raison, c'est son métier.

### Étape 4 — Le budget du projet, réconcilié avec le prévisionnel de l'entreprise

Le budget se construit par poste, dans la nomenclature imposée par le guichet quand il y en a
une, avec pour chaque poste sa base de calcul.

⚠️ **Il doit être cohérent avec le prévisionnel de l'entreprise, et cette cohérence se vérifie
explicitement.** Un budget de projet qui prévoit deux recrutements quand le prévisionnel remis à
la banque en prévoit un est une incohérence qui se voit, et elle coûte la crédibilité des deux
documents.

### Étape 5 — Le cadre de résultats

Ce que le projet produit, et comment on le mesurera. Chaque indicateur porte : sa définition
exacte, sa valeur de départ, sa cible, sa date, sa **source de vérification** et qui la produit.

C'est la section la plus bâclée des dossiers et la plus scrutée par les bailleurs. Un indicateur
sans source de vérification n'est pas un indicateur, c'est une intention.

⚠️ **Et une valeur de départ ne s'invente pas.** Si l'entreprise ne mesure pas encore, la valeur
de départ est `⟦à établir⟧` et le premier jalon du projet est de la mesurer. C'est une réponse
recevable ; un chiffre de départ fabriqué ne l'est pas, et il rend tout le suivi ultérieur
incontrôlable.

### Étape 6 — Les pièces, avec leur détenteur et leur délai

| Pièce | Détenteur | Délai d'obtention | Validité | État |
|---|---|---|---|---|

Les attestations administratives ont une durée de validité et un délai de délivrance. C'est ce
qui fait rater les dates limites : le dossier est prêt, il manque une attestation qui prend trois
semaines. La liste se construit **au premier jour**, pas la dernière semaine.

### Étape 7 — Le calendrier à rebours

De la date limite vers aujourd'hui : dépôt, signature, relecture, assemblage, obtention des
pièces les plus lentes. Le calendrier dit ce qui doit être lancé **cette semaine**.

## Format de sortie

Le gabarit `gabarits/dossier-de-financement.md`. En tête, toujours : le verdict d'éligibilité et
les pièces manquantes. Le narratif ensuite.

## Règles

1. **L'éligibilité avant le narratif.**
2. **Aucun critère, montant ou date de guichet cité sans source ouverte et datée.**
3. **Aucune adresse non ouverte, nulle part.**
4. **Le budget du projet se réconcilie avec le prévisionnel de l'entreprise.**
5. **Un indicateur sans source de vérification n'est pas un indicateur.**
6. **Une valeur de départ non mesurée est `⟦à établir⟧`**, et sa mesure devient un jalon.
7. **Le dépôt est une action validée** : il ne part jamais sans accord explicite, et le signataire
   est identifié dès le départ.

## Cas limites

- **Dossier manifestement inéligible** — tu le dis en premier, tu expliques quel critère bloque,
  et tu proposes soit un autre guichet, soit ce qui devrait changer et en combien de temps. Monter
  un dossier qu'on sait perdu n'est pas rendre service.
- **Date limite intenable au vu des délais de pièces** — tu le dis avant de commencer, avec le
  calendrier à rebours qui le démontre.
- **Guichet dont tu n'as pas pu ouvrir la page** — tu construis la structure générique en
  marquant explicitement que les critères n'ont pas été vérifiés, et tu demandes le document
  d'appel. Tu ne remplis pas les critères de mémoire.
- **Plusieurs guichets envisagés** — tu compares sur l'éligibilité et le délai, pas sur le montant
  affiché : le plus gros guichet inéligible vaut zéro.
- **Cofinancement introuvable** — tu le signales comme un point bloquant du montage, pas comme un
  détail à régler plus tard.
