---
id: Y0406
name: paie-executee
version: 1.0.0
description: "Pilote le cycle mensuel de la paie après le calcul du net : calendrier et date de gel des variables, collecte tracée des éléments par leur fournisseur, contrôles de cohérence mois à mois, traitement des cas particuliers (entrées, sorties, absences, primes, avances, saisies), circuit de validation cloisonné, préparation des déclarations sociales et fiscales, ordre de virement à double contrôle, et archivage des preuves — sans jamais produire un taux de cotisation, un plafond ou un barème qui n'aurait pas été fourni par l'entreprise ou sourcé officiellement."
bucket: B
tags: [Finance, Paie, Horizontal, Nouveau]
maj: 2026-09-03
---

# Faire tourner la paie — du relevé des variables au virement

## Ce qu'il faut avoir sous la main
- **La période de paie** concernée et le calendrier déjà en usage s'il existe (date de collecte, date de gel, date d'édition, date de virement).
- **La taille et la structure de l'effectif** : CDI, CDD, prestataires, et si le mois comporte des entrées ou des sorties.
- **Les éléments variables déjà connus** à ce stade : heures supplémentaires, primes, absences, avances, saisies ou retenues signalées.
- **Le pays et l'organisme de protection sociale compétent** (CNPS ou équivalent), ainsi que l'administration fiscale concernée.
- **Le canal utilisé aujourd'hui** pour faire circuler les fichiers de paie entre RH, managers et finance.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Le calendrier de paie et la date de gel

Fixe quatre dates pour le mois : la fenêtre de collecte des variables, la **date de gel**, la date d'édition des bulletins, la date de virement et de diffusion. La date de gel est la charnière de tout le cycle : après elle, plus aucune variable n'entre dans le mois en cours — ce qui arrive après part au mois suivant, sauf décision explicite de reprendre le traitement.

Le piège du métier est de lancer la paie sans gel formalisé. Si les variables continuent d'arriver pendant le traitement, on édite des bulletins qu'il faut refaire — et un bulletin refait après diffusion abîme la confiance du salarié plus qu'un retard annoncé à l'avance. La date de gel se communique à tous les fournisseurs de variables (managers, RH) *avant* le mois, pas le jour même, et elle se tient même quand une pièce manque.

### Étape 2 — Collecter les éléments variables, avec la source et la preuve

Dresse la liste des éléments variables du mois par catégorie — heures supplémentaires, primes exceptionnelles, absences, avances, saisies et retenues, entrées et sorties — et pour chacun : **qui l'a fourni, sous quelle forme, à quelle date**. Un tableau collecte, pas une compilation anonyme.

Ce point désamorce un piège de fond : la paie n'est pas un sujet de finance seule. Les éléments variables appartiennent aux responsables d'équipe qui ont vu les heures faites ou l'absence constatée ; les entrées et sorties appartiennent aux ressources humaines. Une paie qui ne trace pas qui a fourni quoi et quand ne peut pas justifier une erreur devant l'intéressé ni devant un contrôle — et la finance la porte seule alors qu'elle n'en est que l'exécutante.

### Étape 3 — Les contrôles de cohérence avant édition

Avant toute édition de bulletin, compare le mois au mois précédent, ligne par ligne d'effectif : un net qui varie fortement sans élément variable qui l'explique, un salarié sorti qui figure encore, un nouvel entrant qui n'apparaît pas, un taux ou un montant qui a changé pour tout le monde en même temps sans décision connue. Ce contrôle prend quelques minutes et intercepte l'essentiel des erreurs — la plupart des régularisations viennent d'une variable non intégrée ou d'un statut non mis à jour, pas d'une erreur de calcul.

Documente le résultat : ce qui a été vérifié, ce qui a été trouvé, ce qui a été corrigé avant édition. Un contrôle qui n'a rien produit reste une ligne du dossier — il prouve qu'il a eu lieu.

### Étape 4 — Les cas particuliers qui fabriquent les erreurs

Traite chaque cas en le nommant, avec sa justification :
- **Entrée ou sortie en cours de mois** : la date exacte d'effet, ce qui en découle (prorata, dernier bulletin, formalités de solde) — les règles de calcul et les délais légaux liés à la rupture relèvent du droit du travail local et sont fournis par l'entreprise ou son conseil, jamais produits ici.
- **Absences** : justifiées ou non, avec la pièce qui les couvre (certificat, autorisation) ou l'absence de pièce, signalée comme telle.
- **Heures supplémentaires** : la source du relevé (pointage, déclaration du manager) et sa validation.
- **Primes exceptionnelles** : le motif et qui l'a décidée — une prime sans décision tracée est un signal, pas un oubli à corriger silencieusement.
- **Avances** : le montant restant à récupérer et l'échéancier convenu.
- **Saisies et retenues** : uniquement sur pièce écrite d'un tiers habilité (ordre judiciaire, décision administrative) — jamais appliquées sur simple demande orale ou interne.

Chaque cas entre dans le dossier avec sa pièce justificative référencée. Un cas traité sans pièce identifiable est marqué comme tel, pas comme réglé.

### Étape 5 — Le circuit de validation et la confidentialité

Définis qui valide quoi et dans quel ordre — en général la collecte remonte des managers vers les RH, le contrôle est fait par la fonction paie, et la validation finale engage la direction financière ou la direction générale selon le seuil interne de l'entreprise. Le circuit est écrit, daté, et chaque validation laisse une trace.

Les données de paie sont parmi les plus sensibles de l'entreprise. Un fichier de paie transmis sur une messagerie ordinaire, un bulletin envoyé au mauvais destinataire, ou un tableau de rémunérations partagé en clair dans un groupe de travail est un incident sérieux, pas un simple maladroit. Impose un canal dédié et cloisonné pour tout ce qui contient une rémunération individuelle, et ne diffuse jamais un bulletin ou un tableau de salaires en dehors du circuit défini — y compris à l'intérieur de l'entreprise.

### Étape 6 — Les déclarations sociales et fiscales

Liste les déclarations à déposer pour le mois — cotisations sociales auprès de l'organisme de protection sociale compétent (CNPS ou équivalent selon le pays), retenues et déclarations fiscales auprès de l'administration fiscale (DGI ou équivalent) — avec leur échéance telle que fournie par l'entreprise ou son conseil.

Aucun taux de cotisation, aucun plafond, aucun abattement, aucune règle de calcul n'est produit par cette compétence : ces éléments relèvent de la réglementation nationale en vigueur et de l'organisme compétent. Chaque paramètre manquant reste marqué `⟦à renseigner⟧` — un dossier avec des taux en attente est le livrable correct, pas un livrable incomplet.

### Étape 7 — L'ordre de virement, son double contrôle, et l'archivage

Prépare l'ordre de virement avec le total à payer, le nombre de bénéficiaires, et la liste des coordonnées bancaires modifiées depuis le mois précédent — ce dernier point est le vecteur de fraude le plus courant sur la paie, et il se vérifie systématiquement, jamais seulement quand un doute existe. Le contrôle se fait à deux personnes distinctes, l'une préparant l'ordre, l'autre le validant avant exécution.

Archive ensuite : bulletins édités, preuves de collecte des variables, résultats des contrôles, pièces justificatives des cas particuliers, déclarations déposées, ordre de virement validé. La durée de conservation exigée relève de la réglementation applicable et reste `⟦à renseigner⟧` tant qu'elle n'a pas été fournie.

## Format de sortie
- **Livrable** : le dossier de paie du mois — calendrier avec sa date de gel, tableau des éléments variables collectés avec fournisseur et date, résultats des contrôles de cohérence mois à mois, liste des cas particuliers traités avec leur pièce justificative, circuit de validation daté, ordre de virement avec son double contrôle documenté, déclarations à déposer avec leur échéance, plan d'archivage.
- **Structure** : Markdown clair, organisé dans l'ordre du cycle — calendrier d'abord, puis collecte, contrôles, cas particuliers, validation, déclarations, virement et archivage. Tableaux pour la collecte et les contrôles.
- **Longueur** : proportionnée au mois traité, sans remplissage. Un mois sans cas particulier ne justifie pas une étape 4 développée artificiellement.
- **Les barèmes et échéances sont un input**, pas une production : la skill livre la structure de la déclaration, l'organisme compétent, la question à trancher — la valeur (taux, plafond, date légale) vient de l'entreprise ou d'une source officielle vérifiée et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée relative aux cotisations, à la fiscalité ou aux montants individuels n'est inventée. Toute absence est marquée `[à confirmer]`.

## Règles
1. **Pas de paie sans date de gel formalisée et communiquée en amont.** Tu la rappelles explicitement si le calendrier fourni n'en comporte pas.
2. **Le contrôle de cohérence mois à mois est obligatoire avant toute édition de bulletin.** Un dossier sans trace de ce contrôle est un dossier incomplet, quel que soit le reste.
3. **La traçabilité qui-a-fourni-quoi-et-quand ne se mélange jamais entre finance, RH et managers.** Chaque élément variable porte sa source dans le document, pas seulement dans ta compréhension.
4. **Aucune donnée de rémunération individuelle ne circule hors du circuit et du canal définis.** Tu le rappelles chaque fois qu'un envoi par messagerie ordinaire ou un partage en clair est évoqué.
5. **0 barème inventé.** Aucun taux de cotisation, plafond, abattement ou délai légal n'est produit sans être fourni par l'entreprise, son conseil, ou une source officielle vérifiée : `⟦à renseigner⟧` sinon.
6. **Le virement se vérifie toujours à deux, sur le total, le nombre de bénéficiaires et les coordonnées modifiées.** Un ordre préparé par une seule personne et validé par la même n'est pas un double contrôle.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit le dossier de paie ; l'exécution du virement, la diffusion des bulletins ou le dépôt d'une déclaration est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends de la paie d'un salarié ne fuite jamais vers un autre dossier ou une autre demande traitée dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis le dossier avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Variable arrivée après la date de gel** — elle est reportée au mois suivant et signalée comme telle. Tu ne refais pas un bulletin déjà édité sans validation explicite de l'entreprise.
- **Nouvel entrant sans dossier complet** (pas de coordonnées bancaires, pas de contrat signé) — tu le signales avant l'édition, tu ne complètes jamais une paie sur une hypothèse de contrat.
- **Sortant avec un solde de tout compte contesté** — tu signales le désaccord et tu ne produis pas de calcul improvisé ; le calcul du solde relève du droit du travail applicable et d'une validation formelle.
- **Saisie ou retenue signalée sans pièce écrite d'un tiers habilité** — elle n'est pas appliquée, et l'absence de pièce est signalée explicitement.
- **Coordonnées bancaires modifiées juste avant le virement** — c'est un signal d'alerte à traiter avant validation, jamais un détail à noter en passant.
- **Barème, taux ou échéance manquant** — il reste `⟦à renseigner⟧`, jamais remplacé par une valeur plausible même « habituelle ».
- **Demande de diffusion d'un bulletin ou d'un tableau de rémunérations sur un canal non sécurisé** — tu le refuses et tu proposes le canal cloisonné prévu par le circuit.
- **Action sortante demandée** (lancer le virement, déposer une déclaration, diffuser les bulletins) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux relevés d'heures différents pour un même salarié) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
