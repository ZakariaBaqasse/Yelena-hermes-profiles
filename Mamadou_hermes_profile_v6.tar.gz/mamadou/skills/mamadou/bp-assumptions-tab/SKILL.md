---
name: "bp-assumptions-tab"
version: "1.0.0"
description: "Génère l'onglet ASSUMPTIONS Excel d'un BP : prix, coûts, masse salariale, capex, fiscalité en formules actives."
maj: 2026-09-03
---

# Onglet ASSUMPTIONS d'un BP — générateur

## Ce que produit ce skill

Un onglet Excel `ASSUMPTIONS` : le référentiel paramétrique central d'un BP. Il héberge toutes les hypothèses d'économie unitaire (prix, take-rates, commissions), de coûts variables (COGS, fees), d'organisation (headcount, salaires, opex, G&A), de capex et de fiscalité, et les expose au P&L mensuel sous forme de lignes à adresse stable. L'onglet acquisition produit les volumes ; ASSUMPTIONS produit tout le reste.

Trois principes gouvernent tout :

- **Chaque hypothèse vit à sa granularité naturelle.** Constante sur l'horizon = scalaire (une cellule). Palier annuel = mini-table Year 1/2/3 déployée par lookup. Vraiment mensuelle = ligne de 36 cellules. Jamais 36 saisies d'un palier annuel : un vecteur mensuel de valeurs identiques est un scalaire déguisé.
- **Les coûts pilotés par un driver sont calculés, pas saisis.** Staffing support = base active / productivité. Capex IT = delta d'embauches. Benefits = % masse salariale. Seuls les leviers discrétionnaires (plan d'embauche, budgets) restent des inputs.
- **Séparation référentiel / moteur.** L'onglet peut contenir des calculs (masse salariale, valorisation, dimensionnement), mais il communique avec l'aval par un contrat d'interface : des lignes de total et des scalaires à adresse stable que le P&L et le Cashflow lisent.

## Workflow obligatoire

1. **Qualifier le business model** avec l'arbre maître ci-dessous → choisir la fiche famille. Si l'onglet acquisition du même BP a été généré par bp-acquisition-tab, reprendre la même famille sans re-questionner.
2. **Déterminer le mode de chaînage** : mode chaîné (un onglet `ACQUISITION_MODEL` existe dans le classeur : timeline et volumes importés par liens) ou mode autonome (pas d'onglet acquisition : timeline locale en `EDATE`, volumes saisis ou simplifiés). Le mode chaîné est le mode nominal.
3. **Collecter les inputs manquants** auprès de l'utilisateur (AskUserQuestion si disponible) avec la checklist de la fiche famille. Ne jamais inventer un salaire, un take-rate ou un taux d'impôt : demander, ou proposer un défaut explicitement marqué comme hypothèse à valider.
4. **Lire la fiche famille** dans `references/` puis `references/catalogue-briques.md` (briques de stockage S1-S4 et moteurs M1-M6, communes à toutes les familles).
5. **Lire `references/layout-standard.md`** (mise en forme normative, non négociable).
6. **Construire le .xlsx avec openpyxl et des formules Excel actives.** Jamais de valeurs calculées en Python et collées en dur : changer un input bleu doit tout recalculer. Utiliser `scripts/xlsx_helpers.py`.
7. **Exécuter les contrôles** de `references/controles.md` avant livraison.

## Arbre de décision maître

La famille est la même que celle de l'onglet acquisition du BP (les deux skills partagent la typologie). Si elle n'est pas connue, poser les questions de l'arbre de bp-acquisition-tab. Chaque famille pointe vers une fiche qui décrit les blocs d'hypothèses spécifiques ; les blocs transverses (headcount, salaires, G&A, capex, taxes) sont dans le catalogue de briques.

```
Famille d'acquisition du BP          → Fiche assumptions
├─ Base récurrente (abonnement)      → famille-base-recurrente.md
├─ Usage / cohortes (transactionnel) → famille-usage-cohortes.md
├─ Marketplace bi-face               → famille-marketplace-biface.md
├─ Rollout d'actifs (unités posées
│  ou vendues par l'opérateur)       → famille-rollout-actifs.md
├─ Réseau d'agents (humains ou
│  équipements chez des tiers)       → famille-reseau-agents.md
└─ Actifs financés (dette/leasing)   → famille-actifs-finances.md
```

Cas composites : empiler les blocs revenus/COGS de chaque famille dans le même onglet (un bloc par activité), et mutualiser les blocs transverses (un seul bloc headcount, un seul bloc taxes).

## Structure type de l'onglet (miroir du P&L)

Les sections se succèdent dans l'ordre où le P&L les consomme. C'est la convention de rangement : on navigue dans ASSUMPTIONS comme dans le P&L.

```
0. PARAMÈTRES GÉNÉRAUX   FX, gross-up salarial, TVA, jours ouvrés (scalaires en tête)
1. REVENUES              prix, take-rates, commissions, grilles tarifaires, valorisation
2. COGS                  coûts variables, fees de paiement, provisions, coûts unitaires servis
3. OPEX                  customer service (staffing élastique), headcount, masse salariale,
                         grille de salaires, benefits, advertising, G&A
4. ASSETS                triplet capex : quantités (souvent auto-dérivées), prix unitaire, durée d'amortissement
5. FINANCIAL EXPENSES    paramètres de dette tels que documentés par la famille (le cas échéant)
6. TAXES                 taux d'IS par année, impôt minimum forfaitaire, TVA
```

## Conventions par défaut (appliquer sans redemander)

- **Horizon** : identique à l'onglet acquisition — Year 0 (colonne C) + 36 mois (D→AM). En mode autonome sans Year 0 demandé, garder la même ossature pour la compatibilité future.
- **Timeline** : mode chaîné = ligne des mois liée (`='ACQUISITION_MODEL'!C6` tiré vers la droite) — l'onglet acquisition est le maître du calendrier, aucune date recalculée localement. Mode autonome = premier mois en input puis `=EDATE(préc;1)`.
- **Ligne-clé d'année (ligne 6)** : "Year 0/1/2/3" répété dans chaque colonne de mois, formaté navy pour se fondre dans la bande, mais VISIBLE (jamais masqué à hauteur 0 : une ligne invisible structurellement critique est un piège de maintenance). C'est la clé des lookups annuels→mensuels.
- **Liens inter-onglets : police verte #008000, obligatoire.** L'audit visuel repose dessus. Pas de fond jaune, pas de liens en noir.
- **Devise** : hypothèses négociées localement (salaires, coûts terrain) saisies en devise locale dans une colonne dédiée, converties par une cellule FX unique en tête d'onglet. Jamais de taux de change en dur dans une formule.
- **Libellés** : anglais (Revenues, COGS, Headcount, Salaries), cohérents avec les BP existants.
- **Sens de câblage unique** : chaque input vit dans UN onglet. Si le budget marketing vit déjà dans l'onglet acquisition, ASSUMPTIONS le relaie en lien vert (sans le re-saisir) ; en mode autonome, il devient un input d'ASSUMPTIONS. Documenter le sens choisi en commentaire de cellule.
- **Lectures aval** : préférer le lien direct vers la source primaire (l'onglet acquisition) plutôt qu'un relais via le P&L. Si une hypothèse doit lire une métrique aval (paliers indexés sur le GMV), la lire avec UN MOIS DE DÉCALAGE — casser ce décalage crée une référence circulaire.
- **Anonymat** : ne jamais mentionner les entreprises des modèles de référence dans le fichier généré. Les fiches sont des frameworks, pas des exemples à citer.

## Corrections structurelles appliquées par défaut

Le corpus d'origine contient une dette de conception récurrente. Ce skill génère la version corrigée :

1. **Aucune constante métier enfouie dans une formule.** Taux de change, gross-up net→brut, inflation salariale, learning curve, jours ouvrés, remises : chacun est une cellule d'hypothèse bleue labellisée dans le bloc Paramètres généraux, référencée en absolu.
2. **Masse salariale appariée par position, pas par libellé.** Le bloc masse salariale est le miroir ligne à ligne du bloc headcount : chaque ligne référence directement sa ligne d'effectif et sa ligne de grille salariale (références de cellule), jamais un VLOOKUP sur texte de la colonne A (un renommage casse silencieusement le calcul). Une ligne de contrôle Total headcount vérifie la somme.
3. **Aucun hardcode au milieu d'une ligne calculée.** Une seule logique par ligne, posée en première colonne de mois et recopiée jusqu'à AM, sans rupture au changement d'année. Si une valeur doit dévier (rampe de lancement), c'est un input bleu assumé sur toute la ligne, pas une valeur noire camouflée en formule.
4. **Vecteurs et rampes liés à leur source unique.** Si un vecteur de pénétration existe dans l'onglet acquisition, ASSUMPTIONS le lie (`=ACQUISITION_MODEL!A18`), jamais de copie en dur qui diverge.
5. **Staffing élastique avec cliquet** : `=MAX(ROUNDUP(volume/productivité;0); effectif_mois_précédent)` — pas de dé-staffing mécanique.
6. **Colonne A réservée aux libellés** (exception : vecteurs de pénétration alignés à droite, convention héritée de l'acquisition). Jamais de valeurs de calcul cachées dans la colonne des libellés.
7. **Unités remplies en colonne B** (`#`, `%`, `€`, devise locale) sur toute ligne portant des valeurs.

## Interaction avec l'utilisateur avant construction

Toujours confirmer avant de générer : famille retenue, mode chaîné ou autonome (et le nom exact de l'onglet acquisition si chaîné), devise locale et devise de reporting, et les hypothèses chiffrées manquantes de la checklist de la fiche famille (salaires par rôle, plan d'embauche, prix, taux de fiscalité locale). Une seule salve de questions, groupée. Si l'utilisateur fournit un brief complet, ne confirmer que les ambiguïtés réelles.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/layout-standard.md` | Toujours, avant de construire |
| `references/catalogue-briques.md` | Toujours — briques de stockage S1-S4, moteurs M1-M6, blocs transverses |
| `references/controles.md` | Toujours, avant de livrer |
| `references/famille-base-recurrente.md` | Abonnement / SaaS, revenu plein dès M1 |
| `references/famille-usage-cohortes.md` | Transactionnel (TPV, paiements), montée en charge par cohortes |
| `references/famille-marketplace-biface.md` | Offre + demande, GMV et take-rate |
| `references/famille-rollout-actifs.md` | Unités vendues/posées par l'opérateur, pricing cost-plus |
| `references/famille-reseau-agents.md` | Réseau de tiers équipés, valorisation cohortes × pénétration |
| `references/famille-actifs-finances.md` | Parc d'actifs financés, scission unit economics / structure de coûts |
| `scripts/xlsx_helpers.py` | Constantes de style + fonctions openpyxl (timeline, ligne-clé, grilles annuelles, sections) |
