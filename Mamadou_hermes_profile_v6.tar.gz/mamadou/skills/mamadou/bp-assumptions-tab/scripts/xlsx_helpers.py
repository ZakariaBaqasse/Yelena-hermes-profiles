"""Aides openpyxl pour generer un onglet ASSUMPTIONS conforme au
standard de mise en forme (voir references/layout-standard.md).
Compatible avec les onglets produits par le skill bp-acquisition-tab
(memes constantes de style, meme ossature temporelle).

Usage type :
    from xlsx_helpers import *
    wb = Workbook(); ws = wb.active; ws.title = "ASSUMPTIONS"
    setup_sheet(ws, n_months=36)
    write_timeline(ws, linked_sheet="ACQUISITION_MODEL")   # mode chaine
    # ou : write_timeline(ws, start_month="2026-01")       # mode autonome
    r = section_header(ws, row=17, label="REVENUES")
    r = subsection_header(ws, r, "Transaction costs")
    r = scalar_row(ws, r, "Payment fees", "%", 0.025, kind="input", fmt=FMT_PCT2)
    grid = annual_grid(ws, r, "Users per support staff", ["Support"], [[300, 500, 600]])
    ...
Toutes les formules sont ecrites comme chaines '=...' (syntaxe anglaise,
separateur virgule) : Excel les calcule a l'ouverture.
"""

from openpyxl import Workbook  # noqa: F401
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------- constantes
NAVY = "002060"           # bandeaux niveau 1 / bandes d'annee / ligne-cle
SUBSECTION = "D9E2F3"     # sous-sections niveau 2 + fond ligne des mois
SUBFAMILY = "DEEAF6"      # sous-familles (niveau 2 bis) + encadre titre
STUDIO_GREEN = "E2EFD9"   # couts pris en charge par le studio
BLUE_INPUT = "0432FF"     # police input
GREEN_LINK = "008000"     # police lien inter-onglet
GREY_INFO = "A5A5A5"      # lignes informatives (ratios de controle)

FMT_INT = '_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ '
FMT_DEC2 = "#,##0.00"
FMT_PCT = "0%"
FMT_PCT1 = "0.0%"
FMT_PCT2 = "0.00%"
FMT_FX = "#,##0.000"
FMT_MONTH = "mmm-yy"

F_INPUT = Font(color=BLUE_INPUT)
F_FORMULA = Font(color="000000")
F_LINK = Font(color=GREEN_LINK)
F_SECTION = Font(color="FFFFFF", bold=True)
F_INFO = Font(color=GREY_INFO, italic=True)

FILL_NAVY = PatternFill("solid", fgColor=NAVY)
FILL_SUB = PatternFill("solid", fgColor=SUBSECTION)
FILL_SUBFAM = PatternFill("solid", fgColor=SUBFAMILY)
FILL_STUDIO = PatternFill("solid", fgColor=STUDIO_GREEN)

_double = Side(style="double", color="000000")
_thin = Side(style="thin", color="000000")
TOTAL_BORDER = Border(top=_double, bottom=_double)
GRID_BORDER = Border(top=_thin, bottom=_thin, left=_thin, right=_thin)

FIRST_MONTH_COL = 4        # D = mois 1 ; C = Year 0 (aligne sur ACQUISITION)
YEAR0_COL = 3
MONTH_ROW = 7              # ligne des mois (7, vs 6 sur ACQUISITION)
YEARKEY_ROW = 6            # ligne-cle d'annee


def last_month_col(n_months=36):
    return FIRST_MONTH_COL + n_months - 1   # 36 mois -> col AM (39)


# ---------------------------------------------------------------- structure
def setup_sheet(ws, n_months=36, title="ASSUMPTIONS"):
    """Largeurs de colonnes, gel des volets, lignes de titre."""
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 5
    ws.column_dimensions[get_column_letter(YEAR0_COL)].width = 11
    for c in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 9
    ws.row_dimensions[3].height = 27
    ws.freeze_panes = "C8"
    ws["C1"] = "BUSINESS PLAN"
    ws["C1"].font = Font(bold=True, size=14)
    ws["C1"].fill = FILL_SUBFAM
    ws["C2"] = title
    ws["C2"].font = Font(bold=True, size=16)


def write_timeline(ws, start_month=None, linked_sheet=None,
                   linked_first_cell="C6", n_months=36, n_years=3):
    """Lignes 5 (bandes fusionnees), 6 (ligne-cle d'annee, VISIBLE) et
    7 (mois).
    Mode chaine  : linked_sheet = nom de l'onglet acquisition ; la ligne 7
                   est liee (='SHEET'!C6 tire vers la droite depuis
                   linked_first_cell).
    Mode autonome: start_month = 'YYYY-MM' du mois 0 ; C7 input puis EDATE.
    """
    # ligne 5 : bandes fusionnees + ligne 6 : cle d'annee
    c0 = get_column_letter(YEAR0_COL)
    for row in (5, YEARKEY_ROW):
        cell = ws[f"{c0}{row}"]
        cell.value = "Year 0"
        _style_year(cell)
    col = FIRST_MONTH_COL
    for yr in range(1, n_years + 1):
        first, last = col, col + 11
        ws.merge_cells(start_row=5, start_column=first, end_row=5, end_column=last)
        ws.cell(row=5, column=first, value=f"Year {yr}")
        for c in range(first, last + 1):
            _style_year(ws.cell(row=5, column=c))
            key = ws.cell(row=YEARKEY_ROW, column=c, value=f"Year {yr}")
            _style_year(key)
        col = last + 1
    # ligne 7 : mois
    if linked_sheet:
        # premiere colonne liee : linked_first_cell, puis on avance d'une colonne
        from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
        letter, rownum = coordinate_from_string(linked_first_cell)
        base = column_index_from_string(letter)
        for i, c in enumerate(range(YEAR0_COL, last_month_col(n_months) + 1)):
            src = f"{get_column_letter(base + i)}{rownum}"
            cell = ws.cell(row=MONTH_ROW, column=c,
                           value=f"='{linked_sheet}'!{src}")
            cell.font = F_LINK
    else:
        from datetime import date
        y, m = (int(x) for x in start_month.split("-"))
        ws.cell(row=MONTH_ROW, column=YEAR0_COL, value=date(y, m, 1)).font = F_INPUT
        for c in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
            prev = get_column_letter(c - 1)
            ws.cell(row=MONTH_ROW, column=c, value=f"=EDATE({prev}{MONTH_ROW},1)")
    for c in range(YEAR0_COL, last_month_col(n_months) + 1):
        cell = ws.cell(row=MONTH_ROW, column=c)
        cell.number_format = FMT_MONTH
        cell.fill = FILL_SUB
        cell.alignment = Alignment(horizontal="center")


def _style_year(cell):
    cell.fill = FILL_NAVY
    cell.font = F_SECTION
    cell.alignment = Alignment(horizontal="center")


def section_header(ws, row, label, n_months=36):
    """Bandeau navy niveau 1 sur A:AM. Retourne row+2."""
    ws.cell(row=row, column=1, value=label)
    for c in range(1, last_month_col(n_months) + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = FILL_NAVY
        cell.font = F_SECTION
    return row + 2


def subsection_header(ws, row, label, n_months=36, subfamily=False):
    """Bandeau bleu clair niveau 2 (ou 2 bis) sur A:AM. Retourne row+2."""
    ws.cell(row=row, column=1, value=label)
    for c in range(1, last_month_col(n_months) + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = FILL_SUBFAM if subfamily else FILL_SUB
        cell.font = Font(bold=True)
    return row + 2


# ---------------------------------------------------------------- lignes
def scalar_row(ws, row, label, unit, value, kind="input", fmt=FMT_INT,
               comment=None, studio=False):
    """Brique S1 : un scalaire en colonne C. value peut etre une formule
    '=...' (ex. conversion FX). Retourne row+1."""
    font = {"input": F_INPUT, "formula": F_FORMULA, "link": F_LINK}[kind]
    ws.cell(row=row, column=1, value=label)
    ws.cell(row=row, column=2, value=unit)
    cell = ws.cell(row=row, column=YEAR0_COL, value=value)
    cell.font = font
    cell.number_format = fmt
    if studio:
        cell.fill = FILL_STUDIO
    if comment:
        from openpyxl.comments import Comment
        cell.comment = Comment(comment, "bp-assumptions-tab")
    return row + 1


def annual_grid(ws, row, title, labels, values, kind="input", fmt=FMT_INT,
                n_years=3):
    """Brique S3 : mini-table annuelle en C:E (Year 1..n).
    labels = libelles de lignes ; values = liste de listes [an1, an2, an3]
    (ou formules '=...'). En-tetes derives de la timeline (=D$7, =P$7...).
    Retourne (next_row, hlookup_fmt) ou hlookup_fmt est un patron :
        hlookup_fmt.format(col='D', n=2) ->
        'HLOOKUP(D$6,$C$<r0>:$E$<r1>,2,0)'
    n dans le patron = 1 + index de la ligne dans la table (1 = en-tetes).
    """
    font = {"input": F_INPUT, "formula": F_FORMULA, "link": F_LINK}[kind]
    header_row = row
    ws.cell(row=row, column=1, value=title).font = Font(bold=True)
    for yr in range(n_years):
        c = YEAR0_COL + yr
        cell = ws.cell(row=row, column=c, value=f"Year {yr + 1}")
        cell.font = Font(bold=True)
        cell.border = GRID_BORDER
        cell.alignment = Alignment(horizontal="center")
    row += 1
    for label, vals in zip(labels, values):
        ws.cell(row=row, column=1, value=label)
        for yr in range(n_years):
            cell = ws.cell(row=row, column=YEAR0_COL + yr, value=vals[yr])
            cell.font = font
            cell.number_format = fmt
            cell.border = GRID_BORDER
        row += 1
    r0, r1 = header_row, row - 1
    hlookup_fmt = ("HLOOKUP({col}$%d,$C$%d:$E$%d,{n},0)"
                   % (YEARKEY_ROW, r0, r1))
    # NB : la cle est "Year k" (ligne 6) et les en-tetes de la table sont
    # "Year k" : la jointure fonctionne. n = offset de ligne dans la table.
    return row + 1, hlookup_fmt


def write_row(ws, row, label, unit, kind="formula", fmt=FMT_INT,
              values=None, formula=None, n_months=36, year0=None,
              total=False, studio=False, info=False):
    """Ecrit une ligne mensuelle complete (brique S2 ou ligne de moteur).
    kind   : 'input' | 'formula' | 'link'
    values : valeur unique (repetee — reserver aux vrais vecteurs) ou liste
    formula: patron avec {col} = colonne courante, {prev} = precedente,
             {yk} = ref ligne-cle ('{col}$6'), {mo} = ref mois ('{col}$7')
    year0  : valeur ou formule en colonne C (ou None)
    """
    font = {"input": F_INPUT, "formula": F_FORMULA, "link": F_LINK}[kind]
    if info:
        font = F_INFO
    ws.cell(row=row, column=1, value=label)
    ws.cell(row=row, column=2, value=unit)
    if year0 is not None:
        c = ws.cell(row=row, column=YEAR0_COL, value=year0)
        c.font = font
        c.number_format = fmt
    for i in range(n_months):
        colno = FIRST_MONTH_COL + i
        letter = get_column_letter(colno)
        cell = ws.cell(row=row, column=colno)
        if formula is not None:
            cell.value = formula.format(col=letter,
                                        prev=get_column_letter(colno - 1),
                                        yk=f"{letter}${YEARKEY_ROW}",
                                        mo=f"{letter}${MONTH_ROW}")
        elif isinstance(values, (list, tuple)):
            cell.value = values[i] if i < len(values) else values[-1]
        else:
            cell.value = values
        cell.font = font
        cell.number_format = fmt
        if studio:
            cell.fill = FILL_STUDIO
        if total:
            cell.border = TOTAL_BORDER
    if total:
        for c in (1, 2, YEAR0_COL):
            ws.cell(row=row, column=c).border = TOTAL_BORDER
        ws.cell(row=row, column=1).font = Font(bold=True)
    return row + 1


def penetration_vector(ws, first_row, refs_or_rates, fmt=FMT_PCT1):
    """Vecteur de penetration en colonne A. Passer des chaines '=...' (liens
    vers l'onglet acquisition, police verte — recommande) ou des floats
    (inputs bleus, mode autonome)."""
    for i, val in enumerate(refs_or_rates):
        cell = ws.cell(row=first_row + i, column=1, value=val)
        cell.font = F_LINK if isinstance(val, str) else F_INPUT
        cell.number_format = fmt
        cell.alignment = Alignment(horizontal="right")


def define_name(wb, name, sheet, cell):
    """Plage nommee (API scalaire pour le P&L), ex.
    define_name(wb, 'Take_rate', 'ASSUMPTIONS', '$C$50')."""
    from openpyxl.workbook.defined_name import DefinedName
    wb.defined_names.add(DefinedName(name, attr_text=f"'{sheet}'!{cell}"))
