# Famille USAGE / COHORTES — assumptions d'un modèle transactionnel

Quand : le revenu est un pourcentage d'un volume transactionnel (TPV) généré par une base d'utilisateurs qui monte en charge (fintech paiement, wallet, processing). L'onglet acquisition fournit les utilisateurs actifs pondérés par cohorte de pénétration ; ASSUMPTIONS convertit en valeur et porte tous les coûts.

## Blocs spécifiques

### 1. REVENUES — TPV et monétisation

**TPV par utilisateur** : la grandeur discutée sur le terrain est journalière et en devise locale. La saisir ainsi et rendre la mensualisation visible :

```
TPV_mensuel_par_client_local = TPV_journalier_local * $C$<jours_ouvrés>     ' les deux en inputs bleus
TPV_mensuel_par_client_EUR   = ... / $C$<FX>
```

Jamais de `×30` en dur dans une formule. Si le business a plusieurs segments (online/offline, formel/informel), une paire de lignes par segment.

**TPV total par cohorte de pénétration** : les poids de pénétration (ex. 20/60/100 %) sont IMPORTÉS de l'onglet acquisition en liens verts (`=ACQUISITION_MODEL!A33`), jamais recopiés — une seule source de vérité pour la rampe. Puis :

```
TPV(cohorte, mois) = $C$<TPV_par_client> * $B<poids> * 'ACQUISITION_MODEL'!<clients de la cohorte>
Total TPV segment  = SUM(cohortes)      ' double trait, lu par le P&L
```

**Mix de méthodes de paiement** (par segment) : une ligne par méthode (Mobile Money, Carte, autre), inputs bleus, avec solde automatique sur la dernière (`=1-mm-carte`). Le mix peut varier dans le temps (S2) ou rester constant.

**Commissions par méthode** (revenu) : grille de % S1 par méthode et par segment, format 0.00%. Le P&L calcule `revenu = TPV × SUMPRODUCT(mix ; commissions)`.

**Hardware vendu** (terminal, carte) : prix de vente S1.

### 2. COGS

- **Transaction fees par méthode** : grille miroir des commissions (mêmes méthodes, même ordre). CONTRÔLE OBLIGATOIRE : pour chaque méthode × segment, vérifier `commission − fee > 0` ou faire valider explicitement une marge nulle/négative (le corpus contient un segment entier à marge de paiement nulle passé inaperçu).
- **Coût du hardware** : S1 (marge matérielle = prix − coût, à énoncer en commentaire).
- **Cloud % revenus + plancher** : S3 (voir famille base récurrente).
- **Subvention de fees** (si l'opérateur prend en charge les frais des petits clients sous un seuil) : seuil S1 en devise locale, coût unitaire par client dérivé (`=seuil × $C$<jours_ouvrés> × fee_méthode`, en cellule labellisée, pas caché en colonne A), cohortes de bénéficiaires vieillies avec le churn de l'acquisition, et switch annuel S3 (1/1/0) pour éteindre le programme. C'est un levier d'amorçage déguisé en COGS : le rendre visible.

### 3. OPEX / ASSETS / TAXES

Blocs transverses standard (M2 pour le support dimensionné par le parc actif — lien direct vers l'onglet acquisition, M3 masse salariale, M4 capex, taxes OHADA). Direct Sales = lien vert vers les commerciaux de l'onglet acquisition (tous segments).

### 4. CASH (BFR)

Si du hardware est stocké : `jours de stock` en S1 (input pour le BFR du Cashflow).

## Checklist d'inputs

- TPV journalier par segment (devise locale), jours ouvrés.
- Poids des cohortes de pénétration (confirmer qu'ils viennent de l'onglet acquisition).
- Mix de paiement par segment et sa trajectoire.
- Commissions ET fees par méthode × segment (vérifier la marge de chaque croisement).
- Prix et coût du hardware ; jours de stock.
- Programme de subvention éventuel : seuil, extinction.
- Blocs transverses : rôles, salaires, ratios support, G&A, capex, fiscalité.

## Séquence de construction

1. Ossature + Paramètres généraux (FX, jours ouvrés, TVA).
2. TPV : unitaires locaux → conversion → cohortes (liens acquisition) → totaux.
3. Mix de paiement + grilles commissions / fees (contrôle de marge croisement par croisement).
4. COGS hardware, cloud, subvention.
5. OpEx, Assets, Cash, Taxes.
6. Habillage puis contrôles.

## Repères de calibrage

- Commissions paiement marchand UEMOA : 0,5-2 % selon méthode ; fees PSP : 0,5-1,5 %.
- Marge matérielle terminal : 30-50 % du prix de vente.
- 20-23 jours ouvrés par mois.
