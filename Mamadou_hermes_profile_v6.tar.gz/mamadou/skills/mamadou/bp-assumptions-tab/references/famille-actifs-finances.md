# Famille ACTIFS FINANCÉS — assumptions d'un modèle à parc d'actifs sous financement

Quand : l'entreprise exploite un parc d'actifs productifs financés (véhicules, équipements en leasing/dette) opérés par des utilisateurs finaux qui remboursent l'entité. La couche d'hypothèses est SCINDÉE EN DEUX ONGLETS — c'est la spécificité de la famille :

- **`Operational Data`** : atelier d'unit economics — l'économie d'UNE unité (un actif / un opérateur), en devise locale, statique (aucune timeline).
- **`Costs`** : bibliothèque de coûts de L'ORGANISATION — salaires, G&A, capex, impôts — saisis en annuel et mensualisés par des ponts lookup.

Les deux natures d'hypothèses ont des cycles de révision différents (négociation terrain vs pilotage management) : deux espaces distincts.

## Onglet Operational Data (statique, double devise)

Pas de timeline, pas de gel. Axe structurant = devises : colonne F = devise locale (vérité négociée), colonne G = devise de reporting, conversion visible `=F/ $C$<FX>` sur chaque ligne. Quatre sections :

1. **Calendrier d'exploitation** : jours ouvrés/mois, jours spéciaux (S1 bleus).
2. **Taux de perte de revenus par palier de taille de parc** (S4) : le risque croît avec l'échelle (ex. 1,5 % sous 100 actifs, 5 % au-delà) — non-linéarité prudentielle à conserver.
3. **Cash-flow de l'opérateur** (cartes de calcul unitaires) : une carte bordée par type de journée — revenu brut de l'opérateur, remboursement à l'entité, commission de plateforme tierce (`=−%×revenu`), consommables → reste à vivre = SUM. Rôle : PROUVER que l'opérateur gagne sa vie, donc que le remboursement est soutenable. Carte autonome, auditable isolément, bandeau bleu vif fusionné en tête.
4. **Unit economics propriétaire** (la brique consommée en aval) : vue mensuelle par actif — collecte de loyers mensualisée HT (`=−(remb_jour_std×jours_std − remb_jour_special×jours_speciaux)/(1+$C$<TVA>)`), échéance de financement en lien vert vers l'onglet acquisition (qui porte l'échéancier), coûts récurrents par actif (assurance, tracking, maintenance, exigences administratives locales : patente, contrôles techniques, stationnement — S1 bleus en devise locale), marge par actif et % (ligne informative grise), carte one-off (installation).

Les cellules de cet onglet sont référencées directement par le P&L et par Costs : pas de bloc de sortie dédié.

## Onglet Costs (mensualisation driver-based)

Timeline importée de l'onglet acquisition. Architecture SORTIES EN TÊTE : la zone mensuelle lue par le P&L est le premier écran, les blocs de paramètres annuels sont dessous (inversion assumée : l'interface d'abord, la mécanique ensuite).

- **Zone de sortie mensuelle (haut)** : salaires par rôle (double pont : effectif mensuel × salaire annuel/12, moteur M3 en version lookup sur les blocs bas), other opex mensualisés (`table_annuelle/12`), marketing en lien vert vers l'acquisition, divers en % du CA (lecture aval décalée d'un mois), D&A mensuel des sites par fenêtrage M6.
- **Headcount** : effectifs front-office PROPORTIONNELS AU PARC : `=ROUNDUP(parc_actif/ratio ; 0)` avec parc = lien vert acquisition et ratios de couverture en S1 par rôle (ex. 100 / 200 / 40 actifs par ETP). Effectifs commerciaux = répartition d'un lien acquisition (`=MIN(x;1)`, `=MAX(0;x−1)`). Le reste en inputs S2. Lignes de contrôle : total headcount, parc au 31/12.
- **Blocs paramètres annuels (bas)** : salaires bruts par rôle × 3 années (progression `=N-1*(1+$C$<inflation>)`), charges patronales par année, G&A saisis TTC convertis HT visiblement (`=montant/(1+$C$<TVA>)` où TVA référence le paramètre, pas un littéral), capex par site (triplet date/capex HT/durée + table de contrôle dotation-cumul-NBV), fiscalité (IS, impôt minimum en devise locale convertie, TVA). Les en-têtes d'année des blocs annuels sont dérivés de la timeline (`=$Q$4` etc.), une seule source calendaire.

## Points de vigilance propres à la famille

- UN SEUL taux de change, dans les Paramètres généraux, référencé partout (le corpus contient deux parités divergentes par coquille).
- Pas de bloc documentaire orphelin : tout bloc construit doit être consommé par un onglet aval, sinon ne pas le générer.
- Le helper TVA existe pour être référencé : aucune formule ne réécrit `/(1+18%)` en littéral.
- Numérotation de sections auto (`=MAX(plage_précédente)+1`) : vérifier les plages après toute insertion.

## Checklist d'inputs

- Économie opérateur : revenus journaliers par type de jour, remboursement, % plateforme tierce, consommables.
- Coûts récurrents par actif (assurance, tracking, maintenance, administratif local) ; one-off d'installation.
- Paliers de loss rate ; calendrier d'exploitation.
- Ratios de couverture par rôle ; grilles salariales 3 ans ; charges patronales.
- Sites : dates, capex, durée d'amortissement.
- Fiscalité (IS, minimum, TVA) ; parité FX.
- Lignes acquisition à lier : parc actif, échéancier de financement, marketing, commerciaux.

## Séquence de construction

1. Operational Data : FX + calendrier → paliers de perte → cartes opérateur → unit economics propriétaire.
2. Costs : ossature (timeline liée) → blocs paramètres annuels (bas) → zone de sortie mensuelle (haut) → headcount driver-based → contrôles.
3. Habillage layout-standard (cartes à bandeau bleu vif propres à Operational Data), puis controles.md sur les deux onglets.

## Repères de calibrage

- Le reste à vivre de l'opérateur doit rester positif et crédible localement, sinon le remboursement ne tient pas : c'est le premier contrôle de viabilité du BP.
- Loss rate : 1,5-5 % selon la taille du parc.
