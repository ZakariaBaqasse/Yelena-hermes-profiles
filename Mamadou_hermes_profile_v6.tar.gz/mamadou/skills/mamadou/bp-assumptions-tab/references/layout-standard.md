# Standard de mise en forme — onglet ASSUMPTIONS

Spec normative issue du consensus des BP de référence, arbitrée pour être cohérente avec le standard de bp-acquisition-tab. La reproduire exactement : la cohérence visuelle entre onglets et entre BP est ce qui rend les modèles auditables.

## 1. Ossature de l'onglet

| Ligne | Contenu |
|---|---|
| 1-2 | Titre : `C1` = "BUSINESS PLAN" (gras 14, fond #DEEAF6), `C2` = "ASSUMPTIONS" (gras 16), encadré pointillé fin A1:C3 |
| 3 | vide (hauteur ~27) |
| 4 | vide |
| 5 | Bandes d'année fusionnées : "Year 0" = C seule ; "Year 1" = D:O ; "Year 2" = P:AA ; "Year 3" = AB:AM. Fond navy #002060, texte blanc gras, centré |
| 6 | **Ligne-clé d'année** : "Year 0" en C, "Year 1" répété D:O, "Year 2" répété P:AA, "Year 3" répété AB:AM. Fond navy, texte blanc — elle se fond visuellement dans la bande de la ligne 5 tout en restant lisible par les formules. VISIBLE (hauteur normale, jamais 0) |
| 7 | Mois : mode chaîné `='ACQUISITION_MODEL'!C6` tiré jusqu'à AM ; mode autonome C7 = date du mois 0 (input) puis `=EDATE(C7;1)`. Format `mmm-yy`, fond #D9E2F3 |
| 8 | vide (ligne d'appui) |
| 9+ | Bloc Paramètres généraux, puis blocs métier |

- **Volets figés** : `C8` (colonnes A:B + lignes 1-7 gelées).
- La ligne-clé 6 est la signature technique de l'onglet : c'est elle qui permet de déployer des hypothèses annuelles sur la grille mensuelle via `HLOOKUP(X$6; grille; n; 0)` ou `MATCH(X$6; en-têtes; 0)`. Sans elle, aucune mini-table annuelle ne fonctionne.

## 2. Grille de colonnes (largeurs openpyxl)

| Colonne | Largeur | Rôle |
|---|---|---|
| A | 38 | Libellés (plus large que l'onglet acquisition : rôles et hypothèses ont des libellés longs) |
| B | 5 | Unité seule : `#` / `%` / `€` / devise locale |
| C | 11 | Year 0 + colonne porteuse des scalaires et des mini-tables annuelles (C:E) |
| D → AM | 9 (uniformes) | Timeline mensuelle. Jamais de largeur variable |
| Colonne devise locale | 11 | Si salaires en devise locale : une colonne dédiée après AM ou en zone de grille (voir catalogue, brique salaires) |

Hauteurs de ligne : standard (ne pas fixer), sauf ligne 3 ≈ 27.

## 3. Grammaire visuelle

Deux niveaux de hiérarchie (un de plus que l'onglet acquisition) :

| Élément | Style |
|---|---|
| Section niveau 1 (Revenues, COGS, OpEx, Assets, Financial expenses, Taxes) | Fond navy #002060, texte blanc gras, sur A:AM |
| Sous-section niveau 2 (Transaction costs, Customer service, Headcount, Salaries, Advertising, G&A...) | Fond bleu clair #D9E2F3, texte noir gras, sur A:AM |
| Sous-groupe (département dans le headcount) | Gras sans fond |
| Input saisi | Police bleue #0432FF |
| Formule / calcul | Police noire #000000 |
| Lien vers un autre onglet | Police verte #008000 — obligatoire, l'audit visuel repose dessus. Pas de fond jaune, pas de lien en noir |
| Mini-table annuelle (grille Year 1/2/3 en C:E) | En-têtes "Year 1/2/3" gras, table encadrée d'un trait fin ; valeurs en bleu (inputs) ou noir (dérivées) |
| Coût pris en charge par le studio / l'actionnaire | Fond vert clair #E2EFD9 + légende explicite en tête d'onglet (ex. "Green fill = covered by studio in Year 1") |
| Totaux et sous-totaux | Bordure double trait haut + bas |
| Fonds orange / jaune de surlignage de travail | Interdits — transparents |

## 4. Respiration (lignes vides)

- 1 ligne vide après chaque bandeau de section ou de sous-section.
- 1 ligne vide entre chaque bloc logique (grille tarifaire, mini-table, groupe de lignes).
- 2 lignes vides entre grandes sections niveau 1.
- Jamais deux bandeaux collés.

## 5. Formats de nombres

| Type | Format |
|---|---|
| Montants et effectifs | `_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ ` (comptable : zéros en `-`, négatifs entre parenthèses) |
| Prix unitaires fins | `#,##0.00` |
| Pourcentages | `0%` ; commissions et fees en `0.00%` |
| Taux de change | `#,##0.000` |
| Mois | `mmm-yy` |

## 6. Règles de construction des formules

- **Une seule logique par ligne**, posée dans la première colonne de mois (D) puis recopiée jusqu'à AM. Aucune rupture au changement d'année (c'est le lookup sur la ligne 6 qui fait basculer d'année, pas la formule), aucune valeur en dur au milieu d'une ligne calculée.
- Verrouiller avec `$` : scalaires en `$C$xx`, mini-tables en `$C$xx:$E$yy`, ligne-clé en `X$6`, ligne des mois en `X$7`.
- `ROUNDUP(...;0)` sur tout effectif calculé ; `ROUND(...;0)` sur les quantités.
- Tout levier de scénario = un input bleu unique, référencé partout. Jamais de nombre magique (voir controles.md, scan des littéraux).
- Syntaxe openpyxl : formules en chaînes `=...` avec séparateur `,` (Excel localise à l'affichage).

## 7. Bloc Paramètres généraux (tête d'onglet, lignes 9-15 environ)

Premier bloc après l'ossature, sous-section #D9E2F3 "General parameters". Contient les scalaires transverses, tous inputs bleus labellisés :

- Taux de change devise locale / devise de reporting (ex. `FX rate XOF/EUR` = 655.957).
- Gross-up net→brut par catégorie (cadres / non-cadres) si salaires saisis en net.
- Taux de TVA local.
- Jours ouvrés par mois (si un calcul l'utilise).
- Inflation salariale annuelle (si uniforme ; sinon dans la grille de salaires).

Toute formule de l'onglet qui a besoin d'une de ces constantes la référence en `$C$xx`. C'est la correction structurelle numéro 1 du skill.

## 8. Contrat d'interface (sorties vers l'aval)

Chaque bloc qui produit des lignes consommées par le P&L ou le Cashflow les expose à adresse stable : lignes de total encadrées double trait (masse salariale par département, coûts mensualisés) et scalaires en `$C$xx`. Optionnel mais recommandé pour les scalaires très consommés : plages nommées Excel (`Take_rate`, `Payment_fees`) — elles rendent les formules du P&L lisibles et survivent aux insertions de lignes.

## 9. Implémentation openpyxl

Utiliser `scripts/xlsx_helpers.py` : constantes partagées avec bp-acquisition-tab plus les fonctions propres à ASSUMPTIONS — `setup_sheet` (titre "ASSUMPTIONS", colonne A large, gel C8), `write_timeline` (modes chaîné/autonome + ligne-clé d'année), `subsection_header`, `annual_grid` (mini-table Year 1/2/3 + formule HLOOKUP prête), `scalar_row`, `write_row`.
