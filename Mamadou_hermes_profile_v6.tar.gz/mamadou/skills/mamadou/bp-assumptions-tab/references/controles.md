# Contrôles avant livraison — onglet ASSUMPTIONS

Exécuter ces contrôles sur le fichier généré (script Python de relecture openpyxl recommandé). Un onglet ASSUMPTIONS est le référentiel que l'utilisateur auditera cellule par cellule devant un investisseur : chaque contrôle correspond à un défaut réellement observé dans le corpus.

## A. Contrôles structurels (programmables)

1. **Granularité unique par hypothèse** : aucun vecteur mensuel de 36 valeurs identiques (c'est un scalaire ou une mini-table déguisés). Scanner chaque ligne d'inputs : si toutes les valeurs sont égales, convertir.
2. **Aucune rupture de formule sur une ligne calculée** : pour chaque ligne de formules, vérifier que la formule est homogène de D à AM (mêmes références relatives). Une valeur en dur au milieu = hardcode camouflé, interdit.
3. **Aucun littéral métier dans les formules** : scanner les formules pour les constantes suspectes — taux de change (655, 656...), gross-up (0.6, 0.65, 0.925), inflation (1.1, 1.2, 1.3), jours (22, 30), TVA (1.18). Chacune doit être une référence vers une cellule des Paramètres généraux.
4. **Aucun #REF!, aucun #N/A latent** : tous les lookups résolvent ; tout rôle présent dans la grille de salaires existe dans le bloc headcount et réciproquement (miroir complet).
5. **Ligne-clé d'année (ligne 6)** : remplie sur toutes les colonnes de mois, alignée avec les bandes fusionnées (12 colonnes par année, vérifier les charnières O→P et AA→AB), hauteur normale (pas masquée).
6. **Timeline** : mode chaîné = tous les mois liés à l'onglet acquisition ; mode autonome = C7 input puis EDATE. Jamais de dates en dur au milieu.
7. **Colonne B (unités)** remplie sur toute ligne portant des valeurs ; colonne A sans valeurs de calcul cachées (exception : vecteurs de pénétration, alignés à droite et liés).
8. **Volets figés** en C8 ; pas de lignes fantômes (hauteur 0), pas de lignes vides formatées en dates, pas de cellules à fond jaune/orange résiduel, pas de libellés blanc-sur-blanc.
9. **Miroir headcount / masse salariale / grille de salaires** : mêmes rôles, même ordre dans les trois blocs ; `Total headcount` = somme exacte des sous-totaux ; la masse salariale couvre 100 % des rôles (aucune ligne sautée par un SUM qui contourne une erreur).
10. **Sous-totaux et totaux** encadrés double trait ; sections navy et sous-sections #D9E2F3 conformes au layout.

## B. Contrôles de convention couleur

11. Bleu #0432FF = tout input saisi (y compris les grilles de prix et les mini-tables : un input en noir est invisible à l'audit).
12. Noir = toute formule interne.
13. Vert #008000 = TOUT lien inter-onglets, sans exception. Pas de fond jaune, pas de lien noir.
14. Fond vert clair #E2EFD9 réservé aux coûts pris en charge par le studio, avec légende en tête d'onglet.

## C. Contrôles de cohérence métier

15. **Marges croisées positives** : pour tout couple (commission ; fee) par méthode/segment, `commission ≥ fee` ou validation explicite de l'utilisateur consignée en commentaire de cellule.
16. **Vecteurs liés à leur source** : tout vecteur de pénétration, poids de cohorte ou ratio partagé avec l'onglet acquisition est un lien, pas une copie.
17. **Sens de câblage unique** : le budget advertising (et tout input partagé) vit dans UN onglet ; l'autre le lit en lien vert.
18. **Anti-circularité** : toute lecture d'une métrique aval (P&L) est décalée d'un mois. Ouvrir mentalement le graphe : Acquisition → Assumptions → P&L, avec retours uniquement décalés.
19. **Effectifs entiers** : ROUNDUP/ROUND sur tout effectif ou quantité ; pas de 12,5 agents en fin d'horizon.
20. **Cliquet de staffing** : les lignes M2 contiennent le MAX anti-dé-staffing.
21. **Impôt minimum forfaitaire** présent si la juridiction en a un (zone OHADA : oui).
22. **Anonymat** : aucune mention des entreprises des modèles de référence dans les libellés, commentaires, noms d'onglets ou propriétés du fichier.

## D. Contrôle final

23. Ouvrir le fichier en relecture (openpyxl) et vérifier que chaque section attendue par la famille est présente et non vide, puis recalculer mentalement une colonne de mois de bout en bout (un mois du milieu de Year 2, pas le mois 1) : chaque ligne doit se lire sans ouvrir une autre cellule que ses références.
24. Livrer avec un court récapitulatif des hypothèses par défaut posées (marquées à valider) et des liens attendus vers les onglets absents (P&L, Cashflow) le cas échéant.
