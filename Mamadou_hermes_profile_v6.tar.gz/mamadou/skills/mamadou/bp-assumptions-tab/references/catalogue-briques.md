# Catalogue de briques — onglet ASSUMPTIONS

Briques génériques extraites du corpus de BP de référence. Chaque fiche famille assemble ces briques ; ce fichier est la définition unique de chacune. Deux familles de briques : le STOCKAGE (sous quelle forme vit un paramètre) et les MOTEURS (les calculs internes). Puis les blocs transverses présents dans presque tout onglet ASSUMPTIONS.

## Table des matières

1. Briques de stockage S1-S4
2. Moteurs M1-M6
3. Blocs transverses (headcount/salaires, staffing élastique, benefits/other, advertising, G&A, capex, taxes)
4. Règles de câblage inter-onglets

---

## 1. Briques de STOCKAGE — « sous quelle forme vit ce paramètre ? »

Règle de granularité : chaque paramètre vit dans la brique la plus petite qui capture sa variation réelle (S1 < S3 < S2). Le choix se fait avec trois questions : constant sur l'horizon → S1 ; palier annuel → S3 ; vraiment mensuel → S2 ; s'améliore par seuils de volume → S4.

### S1 — Scalaire unique

Une seule cellule bleue en colonne C, libellé en A, unité en B, référencée partout en absolu `$C$xx`.

Exemples types : % payment fees, % benefits, prix unitaire d'un actif, durée d'amortissement, taux de change, montant par referral, seuil d'un programme.

### S2 — Vecteur mensuel

Une ligne de 36 cellules bleues (inputs pilotés à la main : plan d'embauche, budget publicitaire, rampe de provisions) ou noires (calcul mensuel).

Piège : 36 cellules à maintenir. Si les valeurs ne changent qu'une fois par an, c'est un S3 déguisé — le convertir.

### S3 — Mini-table annuelle + déploiement par lookup (la brique signature)

Une mini-table en C:E (ou C:F avec Year 0) avec en-têtes `Year 1 / Year 2 / Year 3`, déployée sur la grille mensuelle via la ligne-clé d'année (ligne 6) :

```
valeur_du_mois = HLOOKUP(X$6; $C$<r1>:$E$<r2>; <n_ligne_dans_la_table>; 0)
```

Usages types : grilles de salaires annuels, productivité par rôle (clients par agent), % cloud-hosting par année, switch on/off d'un programme (1/1/0), taux d'IS par année.

Pièges : (a) les en-têtes de la table doivent être générées depuis la timeline (`=D$6`, `=P$6`...), pas retapées ; (b) les plages sont bornées à `$C:$E` — étendre l'horizon à Year 4 impose d'élargir TOUTES les tables et leurs lookups ; le noter en commentaire de la première table.

### S4 — Table de paliers (machine à états)

Une table seuil → valeur, lue en `VLOOKUP(métrique; table; 2; 1)` (recherche approchée). Modélise une hypothèse qui s'améliore par seuils de volume : remises fournisseurs par palier de GMV, taux de perte par taille de parc, take-rate dégressif.

Contraintes : seuils triés croissants (sinon le VLOOKUP approché rend n'importe quoi) ; si la métrique lue est une métrique aval (GMV du P&L), la lire avec un mois de décalage (colonne D lit la colonne C de l'aval) pour éviter la circularité.

---

## 2. MOTEURS — les calculs internes

### M1 — Pricing en cascade (cost-plus)

Le prix de vente est une sortie, pas une entrée : `ASP = coût_unitaire × (1+transport) × (1+marge) × (1+garantie)`, chaque facteur étant un S1 bleu. Variante avec dérive temporelle : `ASP_mois = ASP_initial − optimisation_cumulée × %_répercuté_client`, l'optimisation venant d'une table S4 de paliers.

Quand : l'entreprise vend un bien dont elle maîtrise le coût d'achat (hardware, négoce). Les vrais inputs sont le coût, les marges cibles et le % de l'optimisation rendu au client.

### M2 — Dimensionnement induit (activity-driven staffing)

```
Effectif(mois) = MAX( ROUNDUP( volume_activité(mois) / productivité ; 0) ; Effectif(mois−1) )
```

- `volume_activité` = lien vert vers la source primaire (base active, commandes, unités de l'onglet acquisition).
- `productivité` = S1 ou S3 (elle s'améliore souvent par année).
- Le `MAX` est le cliquet anti-dé-staffing : on ne licencie pas mécaniquement un mois creux.
- Seed du mois 1 : input bleu si l'équipe démarre non nulle.

Quand : tout rôle dont la charge suit l'activité (customer success, support, opérateurs terrain, techniciens). Les rôles fixes (CEO, CTO) restent des inputs S2.

Variante encadrement : `leads = ROUNDUP(effectif_encadré / ratio_encadrement ; 0)`.

### M3 — Masse salariale par miroir de position

Deux blocs empilés à structure strictement identique (mêmes rôles, même ordre, mêmes sous-totaux par département) :

1. **Headcount mensuel** (étage effectifs) : inputs bleus 0→1→2, ou liens verts pour les rôles pilotés par l'acquisition (commerciaux terrain, agents), ou M2 pour les rôles induits.
2. **Masse salariale mensuelle** (étage coûts) : chaque ligne référence PAR POSITION sa ligne d'effectif et sa ligne de grille de salaires :

```
Coût(rôle, mois) = X<ligne_effectif> * HLOOKUP(X$6; $C$<grille>:$E$<grille>; <n>; 0) / 12
```

Jamais de VLOOKUP sur le libellé de la colonne A : un renommage ou une faute de frappe met silencieusement un salaire à zéro (bug observé plusieurs fois dans le corpus). L'appariement par position + la ligne de contrôle `Total headcount` (somme des sous-totaux, double trait) suffisent.

3. **Grille de salaires annuels** (S3) : une ligne par rôle, mêmes rôles dans le même ordre que les deux étages. Voir bloc transverse Salaires pour la conversion devise locale.

### M4 — Capex par delta d'effectif

```
Achats_IT(mois 1) = SUM(effectifs mois 1)          ' stock initial : 1 équipement par tête
Achats_IT(mois m) = MAX( SUM(effectifs m) − SUM(effectifs m−1) ; 0 )
```

L'équipement suit le recrutement automatiquement. Le triplet (quantité ; prix unitaire S1 ; durée d'amortissement S1) est la sortie lue par le P&L (dotations) et le Cashflow (décaissement). Les autres actifs (véhicules, sites, licences) sont des inputs événementiels : quantité saisie au mois de l'achat.

### M5 — Valorisation de cohortes (onglet-pont)

Reprend cellule à cellule la matrice de cohortes de l'onglet acquisition et la valorise :

```
Valeur(cohorte i, mois m) = 'ACQUISITION_MODEL'!<même cellule> * $A<i> * $C$<valeur_unitaire>
```

- `$A<i>` = vecteur de pénétration en colonne A, LIÉ à l'onglet acquisition (jamais copié en dur : deux vérités qui divergent est l'anomalie majeure du corpus).
- `$C$<valeur_unitaire>` = S1 (ex. valeur mensuelle à pleine maturité d'une unité).
- Ligne de total = SUM de la matrice, double trait : c'est elle que lit le P&L.

Chaque cohorte garde sa ligne : on voit la contribution de chaque millésime — préférer cette forme au SUMPRODUCT compact, plus court mais opaque.

### M6 — Fenêtrage d'amortissement / d'événement

```
Charge(mois) = IF( AND(mois >= date_acquisition ; mois < EDATE(date_acquisition; durée_années*12)) ;
                   capex / (durée_années*12) ; 0 )
```

Pour les actifs localisés (sites, véhicules) dont la dotation démarre à l'acquisition. Le triplet (date ; capex ; durée) est saisi par actif dans une petite table.

---

## 3. Blocs transverses

### 3.1 Salaires en devise locale

La grandeur négociée localement est le net mensuel en devise locale : c'est elle qui est saisie (colonne dédiée, inputs bleus). La conversion est mécanique et entièrement paramétrée par les cellules du bloc Paramètres généraux :

```
Salaire_brut_annuel_EUR (Year 1) = net_mensuel_local / $C$<gross_up_catégorie> * 12 / $C$<FX>
Salaire (Year k+1) = Year_k * (1 + $C$<inflation_salariale>)      ' ou input direct par année
```

Gross-up différencié cadres / non-cadres (repère Afrique francophone : ~1/0,65 cadres, ~1/0,925 non-cadres — à confirmer avec l'utilisateur selon le pays). Repère benefits : 5-10 % de la masse salariale.

### 3.2 Benefits et other expenses

- `Benefits = % × masse salariale totale` (S1, repère 5-10 %).
- `Other expenses par département = % × masse salariale du département` (S1 par département, repères S&M 10 %, IT 5 %, Product 5 %, Exec 3 %).

### 3.3 Advertising (sens de câblage unique)

Un seul onglet possède l'input de spend :

- Mode chaîné avec spend déjà dans l'onglet acquisition : `Advertising = ='ACQUISITION_MODEL'!<ligne budget>` en lien vert, commentaire "input source : ACQUISITION_MODEL".
- Mode autonome : input S2 bleu ici, et si un onglet acquisition est créé plus tard, c'est lui qui devra lier.

Coût referral éventuel : `= $C$<montant_par_referral> * SUM(<nouveaux referrals de l'acquisition>)` (montant en S1, jamais en dur).

### 3.4 G&A

Loyer, audit, assurances, événements : S2 (paliers pilotés à la main) ou S3 si la variation est annuelle. `Misc = % × revenus` (S1 ou S3). Montants réels TTC convertis HT à la saisie de façon visible : `=3000/(1+$C$<TVA>)` — la division apparente garde la trace du montant d'origine.

### 3.5 Taxes (zone OHADA et similaires)

- Taux d'IS par année : S3 (souvent 0 % en Year 1 puis taux plein).
- Impôt minimum forfaitaire : S1 en devise locale convertie (`=montant_local/$C$<FX>`) — plancher réel dans plusieurs juridictions, ne pas l'omettre.
- TVA : S1 dans les Paramètres généraux.
- Le calcul `MAX(taux × profit ; minimum)` vit dans le P&L ; ASSUMPTIONS ne fournit que les paramètres.

### 3.6 Coûts pris en charge par le studio / l'actionnaire

Si certains coûts de Year 1 sont portés par la structure (loyer, CFO, comptabilité) : lignes à 0 sur la période couverte avec fond vert clair #E2EFD9 et légende en tête d'onglet. Distinguer coûts réels de la structure et coûts portés est lisible pour un investisseur ; les faire disparaître ne l'est pas.

---

## 4. Règles de câblage inter-onglets

1. **Timeline** : toujours héritée de l'onglet maître (acquisition) par lien. Une seule source de vérité calendaire.
2. **Entrées** (ce qu'ASSUMPTIONS lit) : volumes et effectifs commerciaux depuis l'onglet acquisition, en liens verts, vers la source primaire (jamais via un relais P&L).
3. **Sorties** (le contrat) : lignes de total à double trait + scalaires `$C$xx` (± plages nommées). Tant que ces adresses tiennent, le moteur interne est refondable librement.
4. **Anti-circularité** : toute lecture d'une métrique aval (P&L) se fait avec un mois de décalage.
5. **Attention au décalage de colonnes** : si le P&L démarre ses mois dans une autre colonne qu'ASSUMPTIONS, chaque référence croisée doit être vérifiée sur la première ET la dernière colonne. Le plus sûr est d'aligner les deux onglets sur la même grille (mois 1 en D partout).
