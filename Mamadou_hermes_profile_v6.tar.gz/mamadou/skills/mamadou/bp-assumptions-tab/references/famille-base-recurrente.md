# Famille BASE RÉCURRENTE — assumptions d'un modèle abonnement / SaaS

Quand : le revenu est récurrent et réalisé à plein dès le premier mois d'un client (abonnement, accès, licence). L'onglet acquisition fournit la base active ; ASSUMPTIONS fournit les prix, les coûts de service et toute la structure.

## Blocs spécifiques (en plus des blocs transverses du catalogue)

### 1. REVENUES — grilles tarifaires scalaires

L'onglet ne projette aucun volume : il ne porte que les prix. Deux formes selon le pricing :

- **Prix par segment** (S1 par segment) : une ligne par segment client (SME, Enterprise...), prix mensuel ou par usage en colonne C, inputs bleus.
- **Barème dégressif au volume** (table) : paliers de volume en colonne A (alignés à droite, style vecteur), prix par unité en colonne C. Le P&L le lit en `VLOOKUP(volume; barème; 2; 1)` (paliers triés croissants).
- **Tiers d'abonnement** : ligne par tier (prix S1) + ligne de mix % par tier avec solde automatique `=1-tier1-tier2` (somme garantie à 100 %, un seul degré de liberté par tier). Si les prix sont négociés en devise locale, les saisir en devise locale et convertir par `$C$<FX>`.
- **Ratios de consommation** (ex. unités consommées par abonnement) : S1, consommés par le P&L.

### 2. COGS

- Payment fees : % S1 (repère 1-3 % selon PSP local).
- Cloud-hosting : `% des revenus` en S3 (le % baisse avec l'échelle, ex. 5→3→2 %) avec plancher annuel S3 (`=MAX(%×revenus ; plancher/12)` côté P&L). Le plancher est un bon pattern anti-sous-estimation : un contrat cloud a un minimum.
- **Staffing support élastique** (moteur M2) : une ligne par rôle de service (Customer success, Support) :

```
Effectif = MAX( ROUNDUP( base_active / HLOOKUP(X$6; grille_ratio; n; 0) ; 0) ; mois_précédent )
```

avec `base_active` en lien vert DIRECT vers la ligne Total Active de l'onglet acquisition (pas via le P&L), et la grille ratio users/staff en S3 (le ratio s'améliore avec l'outillage : ex. 300→500→600 clients par agent). Salaires de ces rôles dans la grille S3 du bloc Salaries.

### 3. OPEX

Bloc headcount / masse salariale / grille de salaires standard (moteur M3 + bloc transverse Salaires en devise locale). Rôles types : Direct Sales (lien vert vers l'onglet acquisition si les commerciaux y sont dimensionnés), Marketing, CTO, devs senior/junior, Product, CEO, CFO, Legal, Accountants. Events (S2 ou S3), G&A, misc % revenus.

### 4. ASSETS

Triplet capex standard (moteur M4) : IT auto-dérivé du headcount, plus actifs événementiels propres au business (licences logicielles, certifications) en inputs datés.

## Checklist d'inputs à collecter

- Grille tarifaire complète : segments/tiers, prix, barèmes de volume éventuels, devise de négociation.
- Mix par tier si applicable.
- % payment fees ; % cloud par année + plancher.
- Ratios users/staff par rôle de service et par année ; salaires de ces rôles.
- Liste des rôles par département, plan d'embauche mensuel, salaires (net local ? gross-up ? inflation ?).
- % benefits, % other expenses par département.
- Budget marketing (ou confirmation qu'il vit dans l'onglet acquisition), events, G&A.
- Catégories capex, prix unitaires, durées d'amortissement.
- Fiscalité : IS par année, impôt minimum, TVA.

## Séquence de construction

1. Ossature + Paramètres généraux (FX, gross-up, TVA).
2. Revenues : grilles tarifaires (scalaires et barèmes).
3. COGS : fees, cloud, grilles ratio + lignes de staffing élastique.
4. OpEx : headcount → grille de salaires → masse salariale (miroir de position) → benefits/other → advertising → G&A.
5. Assets, Taxes.
6. Habillage layout-standard puis controles.md.

## Repères de calibrage

- Cloud : 2-5 % des revenus à l'échelle, plancher 1 500-3 000 €/mois au départ.
- Support : 100-600 clients par agent selon la complexité produit.
- Benefits 5-10 % ; other expenses 2-10 % de la masse par département.
