# Famille MARKETPLACE BI-FACE — assumptions d'un modèle GMV / take-rate

Quand : l'entreprise intermédie une offre et une demande (marketplace de biens ou de services, e-commerce à take-rate). L'onglet acquisition fournit les acheteurs actifs (et éventuellement les vendeurs/zones) ; ASSUMPTIONS porte l'économie du panier, les marges, la logistique humaine et toute la structure. C'est l'archétype le plus riche du corpus : l'onglet devient le hub central de 100 % des hypothèses du P&L.

## Blocs spécifiques

### 1. REVENUES — panier × fréquence × take-rate

Par segment d'acheteurs (ex. informel / formel) :

- **Valeur moyenne de commande** : S1 ou lien vert si un onglet de modélisation du panier existe.
- **Fréquence mensuelle de commande** : S2 bleu (elle rampe avec la maturité, ex. 5→9).
- **Take-rate / marge par tier de volume** (S4) : la marge d'achat s'améliore par paliers de GMV (économies d'échelle fournisseurs) :

```
tier(mois)      = VLOOKUP( GMV(mois−1 du P&L) ; table_paliers ; 2 ; 1 )      ' décalage anti-circularité
take_rate(mois) = lookup du tier dans la grille de marges
```

Le GMV dépend des paniers mais pas du take-rate : pas de circularité tant que le décalage d'un mois est respecté. Le P&L calcule `revenus = acheteurs actifs (acquisition) × panier × fréquence` puis `achats = CA × (1 − take_rate)`.

### 2. COGS

- Jours de stock (S1, lien si un onglet logistique existe) — alimente le BFR.
- Provisions pertes / denrées : % du CA en S2 (rampe) ; provisions invendus : % S1 labellisé (jamais une formule composée non documentée type `=5%*17%`).
- Payment fees ventes ET achats : deux S1/S2 distincts (les PSP diffèrent).
- Cloud-hosting : S2 rampé ou S3.

### 3. OPEX — le dimensionnement opérationnel est le cœur

- **Staffing ops piloté par les commandes** (M2) : rôles de service (customer success, préparateurs, livreurs, planificateurs) dimensionnés par `ROUNDUP(commandes_mensuelles / productivité_rôle)` avec productivité en S3 (elle s'améliore : ex. 500→750→1000 commandes/mois) et cliquet MAX. Le volume de commandes vient de l'onglet acquisition ou logistique en lien vert.
- **Effectif commercial terrain esclave de l'acquisition** : Direct Sales, managers de zone, agents = liens verts vers l'onglet acquisition (`=ACQUISITION_MODEL!<ligne>`). Une seule source de vérité pour le déploiement terrain ; la masse salariale suit automatiquement. Arrondir les effectifs à la source (dans l'onglet acquisition), pas ici.
- Headcount / grille de salaires / masse salariale : moteur M3 standard, salaires en devise locale avec gross-up différencié cadres / non-cadres.
- Advertising : voir catalogue (sens de câblage unique) ; coût referral = S1 × nouveaux filleuls de l'acquisition.
- G&A : loyer, audit, misc % CA (S3 si le % varie par année).

### 4. ASSETS

M4 (IT = delta effectifs, y compris terrain) + véhicules en inputs événementiels + équipement des agents terrain si applicable (quantité = lien vers les agents de l'acquisition × kit unitaire S1 — ne pas laisser ce bloc vide si le modèle a des agents équipés).

## Checklist d'inputs

- Panier moyen par segment ; fréquences et leur rampe.
- Table des paliers GMV → take-rate/marge (paliers triés croissants).
- Jours de stock ; % provisions (pertes, invendus) ; fees ventes/achats.
- Productivités des rôles ops par année ; seeds mois 1.
- Lignes de l'onglet acquisition à lier (commerciaux, managers, agents, referrals, spend).
- Blocs transverses : salaires, benefits, G&A, capex, fiscalité (IS, minimum forfaitaire).

## Séquence de construction

1. Ossature + Paramètres généraux.
2. Revenues : paniers, fréquences, table de tiers (S4 + décalage).
3. COGS : stock, provisions, fees, cloud.
4. Dimensionnement ops : grilles de productivité → effectifs calculés (M2).
5. Headcount (inputs + lignes esclaves de l'acquisition) → grille de salaires → masse salariale (M3).
6. Advertising (sens unique), G&A, Assets, dette éventuelle, Taxes.
7. Habillage puis contrôles.

## Repères de calibrage

- Take-rate / marge distribution de biens : 10-20 % (des tiers à 25-30 % en haut de rampe sont agressifs, à faire valider).
- Provisions pertes : 2-5 % du CA.
- Gross-up masse salariale : ~1,08-1,1 (non-cadres) à ~1,5 (cadres) en Afrique francophone.
- Impôt minimum forfaitaire : contrainte réelle en zone OHADA, toujours l'inclure.
