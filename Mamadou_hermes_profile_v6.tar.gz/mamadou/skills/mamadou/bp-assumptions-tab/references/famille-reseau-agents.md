# Famille RÉSEAU D'AGENTS — assumptions d'un modèle à unités déployées chez des tiers

Quand : l'entreprise déploie des unités génératrices de volume (équipements, points de service) chez un réseau de tiers (agents, commerçants partenaires) et se rémunère sur le volume traité. L'onglet ASSUMPTIONS est ici un ONGLET-PONT : il reprend les matrices de cohortes de l'onglet acquisition et les valorise, en plus de porter les paramètres unitaires.

## Blocs spécifiques

### 1. Valeur unitaire à pleine maturité (scalaires racine)

La formule-mère du modèle, chaque facteur en S1 bleu :

```
Valeur_mensuelle_par_unité = max_utilisateurs_par_unité * fréquence_mensuelle_par_utilisateur * ticket_moyen
```

Ticket moyen saisi en devise locale et converti par `$C$<FX>` (jamais de taux en dur). C'est l'hypothèse la plus sensible du modèle : la marquer comme telle (commentaire de cellule) et proposer une valeur basse/haute à l'utilisateur.

### 2. Matrices de valorisation (moteur M5) — une par régime

Si l'acquisition distingue plusieurs régimes de déploiement (ex. unités louées vs détenues), un bloc miroir par régime :

```
Valeur(cohorte d'âge i, mois m) = 'ACQUISITION_MODEL'!<cellule cohorte> * $A<i> * $C$<valeur_unitaire>
Total régime = SUM(...)          ' double trait, lu par le P&L
```

- Vecteur de pénétration `$A` : LIÉ à l'onglet acquisition sur toutes les lignes. L'anomalie majeure du corpus est un vecteur recopié en dur qui a divergé de l'affichage de l'acquisition : deux vérités coexistantes. Interdit.
- Chaque cohorte garde sa ligne : contribution de chaque millésime visible.

### 3. REVENUES — partage de la valeur

- Take-rate / commission sur le volume : S1 (format 0.00%).
- **Split de la commission avec le réseau** : `% conservé par l'opérateur` en S1 (le complément va aux agents, dernière ligne en solde `=1-part`), plus un éventuel `coût fixe par transaction` versé à l'agent (S1, en devise locale convertie). La distribution par des tiers est le coût variable structurel du modèle : le rendre explicite.
- **Refacturation au réseau** (si l'agent paie une part du loyer/service de l'unité) : `% refacturé` en S1.

### 4. COGS

- Coûts récurrents par unité et par régime : location/amortissement de l'unité, connectivité, maintenance — S1 par poste, en devise locale convertie.
- **Coûts logistiques par type de zone** (ex. collecte, visite) : coût mensuel par zone (S1 par type : ville principale / secondaire) × parc par zone (liens verts vers les lignes de parc de l'acquisition) = mini-matrice mensuelle avec total double trait. Si l'acquisition distingue les zones pour le déploiement, envisager de différencier AUSSI la valeur unitaire par zone (le corpus ne le fait pas et le signale comme chantier connu — poser la question à l'utilisateur).

### 5. OPEX

- Coût de set-up one-off par unité déployée : décomposé en postes S1 (installation, travaux, matériel) avec un total calculé ; le P&L le multiplie par les poses du mois (lien acquisition).
- Blocs transverses standard (headcount M3, staffing terrain éventuellement lié à l'acquisition, capex M4, taxes).

### 6. Contrat d'interface : plages nommées

Cette famille exporte beaucoup de scalaires vers le P&L. Créer des plages nommées Excel sur les plus consommés (`Take_rate`, `Unit_monthly_value`, `Agent_fixed_fee`, `Setup_cost`...) : les formules du P&L deviennent lisibles et survivent aux insertions de lignes. openpyxl : `wb.defined_names`.

## Checklist d'inputs

- Max utilisateurs par unité, fréquence, ticket moyen (et leurs fourchettes).
- Take-rate ; split opérateur/réseau ; fixe par transaction ; % refacturé.
- Coûts récurrents par unité par régime ; coûts logistiques par type de zone.
- Décomposition du set-up one-off.
- Régimes et lignes de l'onglet acquisition à lier (cohortes, parcs par zone, poses).
- Différenciation par zone de la valeur unitaire : oui/non.
- Blocs transverses.

## Séquence de construction

1. Ossature + Paramètres généraux (FX unique).
2. Scalaires racine (valeur unitaire) + Revenue (take-rate, split, refacturation).
3. Matrices de valorisation M5 (une par régime), vecteurs liés.
4. COGS : récurrents par unité, mini-matrices logistiques par zone.
5. OpEx (set-up, transverses), Assets, Taxes.
6. Plages nommées, habillage, contrôles.

## Repères de calibrage

- Split de commission avec un réseau de distribution cash-in/cash-out : 40-60 % au réseau, souvent + fixe par transaction.
- La sensibilité du modèle est concentrée sur le ticket moyen : proposer systématiquement un scénario à ±30 %.
