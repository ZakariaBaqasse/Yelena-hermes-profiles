# Famille ROLLOUT D'ACTIFS — assumptions d'un modèle de vente/pose d'unités avec pricing cost-plus

Quand : l'entreprise vend ou déploie des unités physiques (devices, équipements, y compris reconditionnés) et son prix de vente dérive de son coût d'achat. L'onglet ASSUMPTIONS de cette famille n'est pas un parking à hypothèses : c'est trois machines en une — un magasin de paramètres, un moteur de pricing, un moteur de dimensionnement.

## Blocs spécifiques

### 1. REVENUES — pricing en cascade (moteur M1)

Le prix de vente (ASP) est CONSTRUIT, pas saisi :

```
ASP_initial = coût_device * (1 + %transport) * (1 + %marge_cible) * (1 + %garantie)
Prix_canal_2 = ASP * %remise_canal          ' ex. wholesale = 95 % du prix reseller, % en S1
```

Chaque facteur est un S1 bleu labellisé. Si plusieurs segments (B2B / consumer), une marge cible par segment.

**Dérive temporelle du prix** : l'optimisation des achats est répercutée au client :

```
ASP(mois) = ASP_initial − optimisation_cumulée(mois) * $C$<%_répercuté_client>
```

**Paliers d'optimisation** (S4) : table seuils de GMV → niveau → % d'optimisation achats et transport, lue sur le GMV du P&L avec un mois de décalage (colonne D lit la colonne C du P&L — anti-circularité stricte).

**Volumes vendus** : si l'onglet acquisition les produit, liens verts ; sinon vecteurs S2 par segment.

### 2. COGS

- Coût du device : S1 (l'input racine de la cascade).
- % transport, % garantie : S1 (déjà dans la cascade, ne pas les dupliquer).
- % d'unités reconditionnées (si applicable) : S2 ou S3 — pilote le staffing technique.

### 3. OPEX — dimensionnement induit (moteur M2)

- **Techniciens** : `ROUNDUP(unités_traitées / productivité)` avec unités = volumes × % refurb, productivité S3 (learning curve PAR CELLULES, ex. ×1,2/an en input labellisé, pas en dur dans la formule).
- **Team leads** : `ROUNDUP(techniciens / ratio_encadrement)` (ratio S1).
- **Customer success** : `ROUNDUP(base_active_acquisition / clients_par_agent)` (ratio S1/S3, lien vert).
- Rôles fixes (CEO, tech lead, ops) : inputs S2. Masse salariale : moteur M3 (miroir de position), inflation salariale en S1.
- Advertising : sens de câblage unique (si l'onglet acquisition consomme le budget influenceurs, l'input vit ici et l'acquisition le lit — documenter).

### 4. ASSETS

M4 (delta headcount × prix unitaire par type d'équipement : poste bureau vs poste atelier, prix S1 distincts). Pas de lignes mortes : si "delivery delay" ou "stock days" n'ont ni valeur ni consommateur, ne pas les créer.

### 5. CASH

Jours de stock de devices : S1 si le Cashflow modélise le BFR.

## Ordre de lecture du graphe (assumé, à documenter en commentaire d'onglet)

Cette famille lit l'aval : `Acquisition → P&L (volumes, GMV) → ASSUMPTIONS (paliers, staffing induit) → P&L (masse salariale, COGS)`. C'est ce qui rend le dimensionnement automatique. La règle qui rend ce ping-pong sain : toute lecture aval est décalée d'un mois.

## Checklist d'inputs

- Coût du device et sa trajectoire ; % transport, marge cible par segment, % garantie, % remise par canal.
- Table des paliers GMV → % optimisation ; % répercuté au client.
- % refurb ; productivité technicien par année ; ratio d'encadrement ; clients par CS.
- Rôles fixes et salaires ; inflation salariale.
- Prix des équipements par type de poste ; budget marketing/influenceurs.
- Fiscalité locale.

## Séquence de construction

1. Ossature + Paramètres généraux (y compris inflation salariale, learning curve, % répercuté).
2. Cascade de pricing (M1) + table de paliers (S4, décalage).
3. Volumes (liens ou S2), % refurb.
4. Dimensionnement induit (M2) : techniciens, leads, CS.
5. Headcount fixe + grille salaires + masse salariale (M3).
6. Advertising, G&A, Assets (M4), Cash, Taxes.
7. Habillage puis contrôles.

## Repères de calibrage

- Marge cost-plus hardware : 15-40 % selon segment.
- Learning curve productivité atelier : +10-20 %/an.
- Remise canal wholesale : 5-15 % sous le prix direct.
