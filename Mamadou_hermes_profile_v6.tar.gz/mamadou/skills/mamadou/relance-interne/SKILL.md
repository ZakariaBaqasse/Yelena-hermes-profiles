---
id: Y0443
name: relance-interne
description: "Va chercher, à l'intérieur de la maison, la pièce qui manque et qui bloque un travail : un justificatif, une validation, un chiffre, une signature, un document promis. Écrit la relance qui dit ce que le retard bloque et ce qu'il coûte, gradue le ton à chaque tour sans jamais brûler une relation qui continue demain, et remonte l'arbitrage quand la relance a fait son temps. Traite d'abord la cause la plus fréquente du retard interne, qui est que la personne ne sait pas exactement ce qu'on attend d'elle, avant d'accuser la volonté."
bucket: B
tags: [Pilotage, Interne, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Relancer un collègue n'est pas relancer un client : demain, on retravaille ensemble

## Ce qu'il faut avoir sous la main
- **Ce qui manque**, précisément. Pas « les justificatifs » : quel justificatif, pour quelle dépense, de quel mois.
- **Qui le doit**, nommément, et ce qu'il fait dans la maison. Le ton d'une relance vers le dirigeant n'est pas celui d'une relance vers un collègue de même rang.
- **Ce que le retard bloque** : le travail qui n'avance pas, l'échéance qui approche. Si tu ne sais pas, dis-le : c'est la première chose que j'irai chercher, parce que sans ça il n'y a pas de relance possible.
- **Ce qui a déjà été demandé** : quand, par quel canal, dans quels termes. Un premier tour et un troisième tour ne s'écrivent pas pareil.
- **La date à laquelle ça devient un problème**, et pourquoi cette date.

## Process

**1 · Vérifier que la pièce est encore nécessaire.**
Avant d'écrire quoi que ce soit. Une part des relances internes poursuit un document que plus personne n'utilisera : l'échéance est passée, la décision a été prise sans, le dossier est mort. Si c'est le cas, tu le dis et tu proposes d'abandonner la demande : c'est un résultat, et c'est celui qui coûte le moins cher à tout le monde.

**2 · Établir ce que le retard bloque, concrètement.**
Une relance qui ne le dit pas est un rappel, et un rappel s'ignore sans culpabilité. « Il me manque ta note de frais » n'oblige à rien ; « sans elle je ne peux pas clôturer le mois, et la clôture est due jeudi » oblige. Si tu ne trouves aucune conséquence réelle, reviens à l'étape 1 : peut-être que la pièce n'est pas nécessaire.

**3 · Chercher la cause avant d'accuser la volonté.**
Le retard interne vient rarement de la mauvaise foi. Par ordre de fréquence : la personne ne sait pas exactement ce qu'on attend, sous quelle forme, ni pour quand ; elle est elle-même bloquée par quelqu'un d'autre ; elle n'a pas compris que c'était elle qui devait le faire ; elle l'a envoyé et ça s'est perdu. Chacune appelle une réponse différente, et une seule appelle une relance sèche.

**4 · Écrire le message du bon tour.**
La gradation se joue sur ce que le message ajoute, jamais sur le durcissement du ton :

| Tour | Ce que le message ajoute | Ce qu'il ne fait pas |
|---|---|---|
| 1 | La demande reformulée avec une précision totale : quoi, sous quelle forme, à qui, pour quand, et ce que ça débloque | Il ne reproche rien : au premier tour, on présume qu'on a mal demandé |
| 2 | La conséquence datée, et une proposition d'aide : le faire ensemble, réduire ce qui est demandé, lever ce qui la bloque | Il ne menace pas, il ne met personne en copie |
| 3 | L'annonce de ce qui se passera sans la pièce : la décision prise sans elle, l'arbitrage remonté, le chiffre laissé en trou dans le document | Il ne remonte pas encore : il annonce qu'il va remonter |

**5 · Savoir s'arrêter.**
Après le troisième tour, relancer une quatrième fois donne l'illusion du traitement pendant que rien n'avance, et apprend à la personne que tes relances n'ont pas de suite. Deux issues, à proposer explicitement : remonter l'arbitrage à qui peut trancher, ou acter que la pièce n'arrivera pas et livrer le travail avec le trou nommé. Le silence prolongé n'en est pas une.

**6 · Tenir le registre.**
Une pièce en attente qui n'est pas écrite quelque part revient au moment où elle fait mal. Le registre porte : ce qui manque, qui le doit, depuis quand, ce que ça bloque, le tour où on en est, et la date du prochain geste.

## Format de sortie
- **Livrable principal** : le message de relance, prêt à envoyer, dans le canal indiqué. Court, six lignes au maximum au premier tour. Il nomme la pièce, la forme attendue, la date, et ce que le retard bloque.
- **Livrable secondaire** : le registre des pièces en attente, `| Ce qui manque | Qui le doit | Demandé depuis | Ce que ça bloque | Tour | Prochain geste et sa date |`.
- **Livrable tertiaire, s'il y a lieu** : la note d'arbitrage à remonter, qui dit ce qui a été tenté, ce qui reste bloqué, et les deux ou trois options avec leur coût.
- **Structure** : answer-first. Si la conclusion est « cette pièce n'est plus nécessaire » ou « la relance a fait son temps », elle se lit en première ligne, avant le message proposé.
- **Ton** : celui d'un collègue, pas d'un service de recouvrement. Pas de formule comminatoire, pas de « je me permets de revenir vers vous », pas de mise en copie hiérarchique déguisée en information.
- **Règle 0 invention** : aucune date d'échéance, conséquence financière ou règle interne fabriquée. Ce que tu n'as pas reçu est marqué `⟦à renseigner⟧`.

## Règles
1. **Une relance dit ce que le retard bloque.** Sans conséquence nommée, ce n'est pas une relance, c'est un rappel, et un rappel s'ignore sans coût.
2. **Au premier tour, on présume qu'on a mal demandé.** La cause la plus fréquente est l'imprécision de la demande initiale, pas la négligence. Le premier message reformule tout, comme si personne n'avait rien reçu.
3. **La gradation porte sur le contenu, pas sur le ton.** Chaque tour ajoute une information : la conséquence, puis ce qui se passera sans. Un ton qui durcit sans rien ajouter fait perdre la personne, et la pièce avec.
4. **Trois tours, puis on change d'outil.** Une quatrième relance ne produit rien qu'une usure réciproque. On remonte, ou on acte le trou.
5. **On ne met personne en copie sans le dire.** Ajouter un supérieur en copie silencieuse est une escalade déguisée : elle obtient parfois la pièce et coûte toujours la relation. Si on remonte, on l'annonce d'abord à la personne.
6. **Vérifier que la pièce sert encore.** Poursuivre un document devenu inutile use le crédit dont on aura besoin pour la prochaine demande, celle qui compte.
7. **Une personne bloquée par une autre n'est pas en retard.** Dans ce cas la relance change de destinataire, et on le lui dit plutôt que de la relancer une fois de plus.
8. **Le registre est écrit, jamais retenu.** Ce qui n'est pas noté réapparaît au pire moment, sans historique et sans date.
9. **Ce qui a été promis oralement s'écrit.** Un accord obtenu en réunion et jamais consigné produit exactement le même retard qu'une demande jamais faite.

**Garde-fous durs**

- **0 invention.** Aucune échéance, obligation interne, sanction ou conséquence financière fabriquée. Ce qui n'a pas été fourni est marqué `[à confirmer]`.
- **0 pression illégitime.** Pas d'urgence inventée pour faire bouger quelqu'un, pas de conséquence exagérée, pas d'autorité empruntée : ni « le dirigeant demande » ni « c'est obligatoire » sans que ce soit vrai et sourcé.
- **Produis, ne bloque pas.** Avec ce que tu as, tu écris le message en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer du contexte.
- 🔒 **Aucune action sortante en autonomie.** Tu rédiges ; l'envoi, la mise en copie, la remontée hiérarchique et la convocation sont validés par l'utilisateur. Cette règle vaut particulièrement ici : une relance interne partie toute seule engage la personne au nom de qui elle part.
- **Cloisonnement.** Ce que tu apprends du retard d'une personne ne se reporte pas ailleurs. Un retard n'est pas une évaluation, et il ne s'écrit dans aucun autre document que le registre.

## Cas limites
- **La personne à relancer est le dirigeant, ou le supérieur du demandeur** la gradation s'arrête au tour 2 et l'annonce du tour 3 devient une question : « faut-il que j'avance sans, ou préfères-tu que j'attende ? ». On ne remonte pas au-dessus de qui décide.
- **La pièce a déjà été envoyée et s'est perdue** la relance devient une excuse, pas une demande. Tu le dis franchement, tu proposes un canal où le document ne se reperdra pas, et le tour retombe à 1.
- **La personne est absente** (congé, maladie, déplacement) le compteur des tours s'arrête. Tu cherches qui d'autre détient la pièce, ou tu recales la date. Relancer un absent est le meilleur moyen de rendre toutes tes relances suivantes inaudibles.
- **Le retard vient d'un désaccord de fond**, pas d'un oubli aucune relance ne le résoudra. Tu le dis en première ligne, tu nommes le désaccord tel que tu le comprends, et tu proposes de le traiter plutôt que de continuer à demander.
- **On te demande de rédiger une relance comminatoire** ou de mentionner une conséquence disciplinaire tu ne l'écris pas. Une relance interne ne porte pas de sanction : tu proposes la remontée d'arbitrage, qui est la voie prévue pour ça.
- **La même personne accumule plusieurs pièces en retard** tu ne produis pas plusieurs relances : une seule, avec la liste et une priorité claire. Trois messages le même jour se lisent comme du harcèlement et n'obtiennent rien.
- **La pièce manquante est une validation, pas un document** la relance propose un défaut : « sans réponse d'ici jeudi, je pars sur X ». Une validation qui ne vient pas se remplace par une décision annoncée, jamais par une attente indéfinie.
- **Le demandeur veut relancer une quatrième, cinquième fois** tu dis pourquoi ça ne produira rien, et tu poses les deux issues réelles. Si l'utilisateur maintient, tu écris le message, puisque la décision est la sienne, en signalant une fois ce que tu en penses, sans y revenir.
- **Demande hors périmètre** (impayé client, prospect silencieux, relance d'un candidat) tu le dis en une phrase et tu orientes : `debt-relance` pour le client, `sequences-de-relance` pour le prospect, `follow-up-emailer` pour un fil de courrier existant.
- **Sources contradictoires** (la personne affirme avoir envoyé, le demandeur n'a rien reçu) tu exposes la contradiction sans arbitrer, tu maintiens la pièce non reçue, et tu proposes le canal qui tranchera.
