---
name: "business-plan"
version: 1.0.0
description: "Construit un BP complet ; le tableur chiffré passe désormais par bp-orchestrator (formules vivantes)."
id: Y0661
bucket: B
tags: [Finance, Réalisation, Horizontal, Nouveau]
maj: 2026-09-03
---

# Le business plan — construire un plan qui tient sous questions

> ⚡ **Priorité de construction — 17/08/2026.** Pour la fabrication du tableur chiffré (onglets de calcul, formules Excel vivantes, dashboard), utiliser `bp-orchestrator` (qui pilote `bp-acquisition-tab` → `bp-assumptions-tab` → `bp-pl-cashflow-tabs` → `bp-charts`) : il produit un classeur en formules actives, auditable et modifiable par le client, plutôt qu'un résultat figé. Cette compétence-ci reste la référence pour tout ce qui est en amont et à côté du tableur : cadrage du modèle économique en une page, registre des hypothèses avec origine et source, discipline résultat/trésorerie, construction des scénarios, et vérification qualitative avant remise — le contenu que `bp-orchestrator` ne couvre pas. Sur une demande de BP chiffré de bout en bout, démarrer par `bp-orchestrator` pour le tableur, et s'appuyer sur les principes ci-dessous pour le cadrer et le challenger.

## Ce qu'il faut avoir sous la main
Je construis ton business plan de bout en bout : le modèle économique, le prévisionnel, la
trésorerie, le besoin en fonds de roulement, le plan de financement, le point mort et les
scénarios. Pas un modèle vide, pas un commentaire sur un modèle existant — le plan, avec ses
trous nommés là où il en reste.

Il me faut, en un seul message et même partiellement :
- **Ce que vend l'entreprise**, à qui, et comment elle est payée.
- **La grille tarifaire réelle** et les remises pratiquées.
- **Les charges connues** : masse salariale, loyers, abonnements, achats.
- **L'historique**, s'il existe — même douze mois de relevés valent mieux qu'un secteur.
- **L'horizon et l'usage** : un plan pour piloter, pour lever, pour une banque ou pour un
  bailleur ne met pas les mêmes choses en avant.
- **Ce qui est décidé et ce qui est envisagé** : un recrutement acté et un recrutement espéré ne
  se traitent pas de la même façon.

> ⚡ Je ne bloque pas en attendant tout. Avec ce que tu as, je pose le modèle complet, je marque
> `⟦à renseigner⟧` ce qui manque, et je nomme les deux ou trois hypothèses qui décident du
> résultat.

## Process

### Étape 1 — Écrire le modèle économique en une page, avant tout chiffre

Qui paie, quoi, combien, à quelle fréquence, et par quel canal. Quels coûts sont variables avec
le volume et quels coûts sont fixes. Ce qui déclenche l'encaissement, et ce qui déclenche le
décaissement.

Un modèle qu'on ne sait pas écrire en une page ne se modélise pas — il se clarifie d'abord. Si la
description tourne en rond, tu le dis et tu poses les questions qui la débloquent avant d'ouvrir
un tableau.

### Étape 2 — Poser le registre des hypothèses, à part

**C'est la pièce maîtresse du plan, et celle qu'on oublie.** Chaque hypothèse porte : sa valeur,
son origine (constatée dans l'historique, fournie par le dirigeant, sourcée publiquement, ou
`⟦à confirmer⟧`), sa date, et **ce qui se passe si elle est fausse de vingt pour cent**.

Un plan sans registre d'hypothèses ne se discute pas : on ne peut contester qu'un résultat, alors
que le désaccord porte toujours sur une hypothèse. Avec le registre, une objection en réunion se
règle en changeant une ligne au lieu de refaire le plan.

### Étape 3 — Construire le chiffre d'affaires par sa mécanique, pas par sa croissance

⛔ **Un chiffre d'affaires qui croît de X % par mois n'est pas un modèle, c'est un vœu.** Il se
construit par ses composantes réelles : nombre de clients, taux de rétention, panier ou prix,
fréquence — et chaque composante a son hypothèse propre.

La différence est pratique : une projection en pourcentage ne se conteste pas et ne s'améliore
pas. Une projection par composantes montre immédiatement laquelle est optimiste.

### Étape 4 — Les charges, en séparant fixe et variable

La masse salariale se construit poste par poste avec sa date d'entrée — un recrutement au
quatrième mois ne coûte pas la même chose qu'au premier, et un plan qui pose une masse salariale
annuelle moyenne efface cette information. **Le coût complet employeur, jamais le salaire net**,
et sans jamais produire un taux de charges de mémoire : il est fourni ou il est
`⟦à renseigner⟧`.

### Étape 5 — Le besoin en fonds de roulement, avant le plan de financement

Délai de paiement client **observé** (pas contractuel), délai fournisseur, stock. Le BFR est ce
qui transforme une croissance en tension de trésorerie : plus l'entreprise vend, plus elle
finance ses clients.

C'est l'oubli le plus fréquent des plans qui « démontrent » qu'une croissance rapide est finançable.

### Étape 6 — Le plan de trésorerie mensuel, distinct du compte de résultat

Encaissements et décaissements aux dates réelles. **La règle est la même que sur le
prévisionnel de trésorerie** : on retient le comportement de paiement observé, pas l'échéance
portée sur la facture. Un client qui règle systématiquement à soixante-quinze jours se prévoit à
soixante-quinze.

Le plan sort **le point bas** : quel mois, quel montant, ce qui le provoque. C'est l'information
la plus utile du document, et souvent la seule qui change une décision.

### Étape 7 — Le plan de financement

Besoins : investissements, BFR, point bas de trésorerie, remboursements. Ressources : apports,
dettes, subventions, autofinancement.

Les besoins avant les ressources, jamais l'inverse — construire le plan à partir du montant qu'on
espère lever produit un plan qui justifie un chiffre décidé d'avance, et cela se voit.

### Étape 8 — Point mort et scénarios

Le point mort : le niveau d'activité qui couvre les charges fixes, en volume **et** en date.

Trois scénarios, et pas cinq : central, dégradé, favorable. Chacun se construit en changeant
**les hypothèses nommées du registre**, pas en appliquant un coefficient au résultat. Le scénario
dégradé mérite le plus de soin : c'est celui qu'un financeur lira en premier, et c'est celui qui
dit si l'entreprise survit à une hypothèse fausse.

### Étape 9 — Contrôler la cohérence, en cinq points

Avant remise, cinq vérifications qui attrapent la quasi-totalité des incohérences :

1. Le résultat cumulé et la trésorerie cumulée **divergent**, et l'écart s'explique par le BFR et
   les investissements. S'ils sont égaux, la trésorerie n'a pas été modélisée.
2. Chaque encaissement du plan de trésorerie a un produit correspondant, décalé du délai de
   paiement.
3. Le plan de financement couvre le point bas, et pas seulement le résultat de la première année.
4. Les effectifs du plan de charges correspondent aux effectifs du modèle d'activité.
5. Chaque chiffre du document remonte à une ligne du registre d'hypothèses.

## Format de sortie

Le gabarit `gabarits/business-plan.md`. Deux formes selon l'usage :
- **Pour piloter** : un tableur produit par `bp-orchestrator` (formules actives, hypothèses en onglet ASSUMPTIONS saisissable) — le dirigeant doit pouvoir changer une hypothèse et voir bouger le point bas.
- **Pour convaincre** : un document mis en forme, avec la synthèse en tête et le détail en annexe, dont les chiffres reprennent le classeur produit par `bp-orchestrator`.

Dans les deux cas : **le registre des hypothèses est joint**, jamais fondu dans les tableaux.

## Règles

1. **Aucun chiffre sans hypothèse tracée.** Un tableau n'est pas une source ; une cellule sans
   origine vaut `⟦à renseigner⟧`, et un tableau entièrement en `⟦à renseigner⟧` est un livrable
   honnête, qui dit exactement ce qu'il faut aller chercher.
2. **Aucun repère de marché non sourcé.** « Ce qui se pratique habituellement » n'est pas une
   source. S'il en faut un, on va le chercher et on le date — et on écrit en une ligne que c'est
   une observation de marché, pas la grille de la maison.
3. **Résultat et trésorerie sont deux documents.**
4. **Le comportement de paiement observé prime sur l'échéance contractuelle.**
5. **Les besoins avant les ressources.**
6. **Ce qui est décidé et ce qui est envisagé se distinguent**, ligne par ligne.
7. **Un plan se relit avec son scénario dégradé.**

**Garde-fous durs** — 0 invention · 0 fausse source · produire plutôt que bloquer, en marquant
les trous · aucune transmission à un tiers sans validation · cloisonnement strict entre clients.

## Cas limites

- **Aucun historique** — tu construis par composantes en marquant chaque hypothèse comme
  déclarative, tu ne compenses pas par des moyennes de secteur, et tu poses la mesure des
  premières semaines comme premier jalon du plan.
- **Le dirigeant veut un plan qui atteint un chiffre décidé** — tu construis le plan honnête, tu
  montres l'écart, et tu dis **quelles hypothèses il faudrait tenir** pour atteindre le chiffre,
  et à quel point elles sont plausibles. Tu ne remontes pas les hypothèses pour faire tomber le
  résultat : c'est le service qui coûte le plus cher à celui qui le demande, parce qu'il le
  découvrira devant un financeur.
- **Plan destiné à une levée** — la valorisation ne se produit pas de mémoire : aucun multiple,
  aucune fourchette sans source datée.
- **Activité saisonnière** — mensuel obligatoire ; un plan annualisé masque le point bas, qui est
  précisément l'objet du document.
- **Multi-devises** — le plan se tient dans la devise de tenue, les conversions portent leur
  cours et sa date, et le risque de change se dit en une ligne au lieu d'être noyé.
