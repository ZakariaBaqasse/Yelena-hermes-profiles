#!/usr/bin/env bash
set -euo pipefail

# video-watch: fetch subtitles/transcript for an online video URL, falling
# back to audio download + Whisper transcription when no subtitles exist,
# and optionally extracting frames for visual review.
#
# Usage:
#   watch_video.sh <url> [--lang en,fr] [--out DIR] [--frames] [--whisper-model turbo]
#
# Output (stdout):
#   TRANSCRIPT:<path>   -- subtitle/transcript file (vtt or txt)
#   FRAMES_DIR:<path>   -- only if --frames was passed and it succeeded
#   AUDIO:<path>        -- only if no subtitles AND no local whisper (fallback)

URL=""
LANGS="en,fr"
OUTDIR="$(mktemp -d /tmp/video-watch.XXXXXX)"
WANT_FRAMES=0
WHISPER_MODEL="turbo"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --lang) LANGS="$2"; shift 2;;
    --out) OUTDIR="$2"; mkdir -p "$OUTDIR"; shift 2;;
    --frames) WANT_FRAMES=1; shift;;
    --whisper-model) WHISPER_MODEL="$2"; shift 2;;
    -h|--help)
      echo "Usage: $0 <url> [--lang en,fr] [--out DIR] [--frames] [--whisper-model turbo]"
      exit 0;;
    *) URL="$1"; shift;;
  esac
done

if [[ -z "$URL" ]]; then
  echo "Error: URL required" >&2
  exit 1
fi

# --- 1. Locate or fetch yt-dlp (static binary, no sudo/apt needed) -------
YTDLP="$(command -v yt-dlp || true)"
if [[ -z "$YTDLP" ]]; then
  CACHE_DIR="${OPENCLAW_HOME:-$HOME/.openclaw}/workspace/.tools/bin"
  mkdir -p "$CACHE_DIR"
  YTDLP="$CACHE_DIR/yt-dlp"
  if [[ ! -x "$YTDLP" ]]; then
    echo "Fetching yt-dlp (one-time)..." >&2
    curl -sL https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o "$YTDLP"
    chmod +x "$YTDLP"
  fi
fi

# --- 2. Try native subtitles (manual, then auto-generated) ---------------
cd "$OUTDIR"
"$YTDLP" --write-sub --write-auto-sub --skip-download \
  --sub-lang "$LANGS" --sub-format vtt \
  -o "sub.%(ext)s" "$URL" >&2 || true

SUB_FILE="$(ls sub*.vtt 2>/dev/null | head -1 || true)"

if [[ -n "$SUB_FILE" ]]; then
  echo "TRANSCRIPT:$OUTDIR/$SUB_FILE"
  exit 0
fi

echo "No subtitles found, falling back to audio + Whisper..." >&2

# --- 3. Download best audio ------------------------------------------------
"$YTDLP" -x --audio-format mp3 -o "audio.%(ext)s" "$URL" >&2
AUDIO_FILE="$(ls audio.* 2>/dev/null | head -1 || true)"

if [[ -z "$AUDIO_FILE" ]]; then
  echo "Error: could not download audio" >&2
  exit 2
fi

# --- 4. Transcribe: local whisper binary first, else point to API skill --
if command -v whisper &>/dev/null; then
  whisper "$AUDIO_FILE" --model "$WHISPER_MODEL" --output_format txt --output_dir "$OUTDIR" >&2
  TXT_FILE="$(ls "$OUTDIR"/*.txt 2>/dev/null | head -1 || true)"
  if [[ -n "$TXT_FILE" ]]; then
    echo "TRANSCRIPT:$TXT_FILE"
    exit 0
  fi
fi

echo "No local whisper binary available. Options:" >&2
echo "  - Install whisper: pip install -U openai-whisper (or brew install openai-whisper)" >&2
echo "  - Or use the openai-whisper-api skill (needs OPENAI_API_KEY) on the audio file below" >&2
echo "AUDIO:$OUTDIR/$AUDIO_FILE"

# --- 5. Optional frames for visual content ---------------------------------
if [[ "$WANT_FRAMES" -eq 1 ]]; then
  VIDEO_FILE="$(ls "$OUTDIR"/*.mp4 "$OUTDIR"/*.webm "$OUTDIR"/*.mkv 2>/dev/null | head -1 || true)"
  if [[ -z "$VIDEO_FILE" ]]; then
    echo "Downloading video for frame extraction..." >&2
    "$YTDLP" -f "bestvideo[height<=720]+bestaudio/best[height<=720]" -o "video.%(ext)s" "$URL" >&2 || true
    VIDEO_FILE="$(ls "$OUTDIR"/video.* 2>/dev/null | head -1 || true)"
  fi
  if [[ -n "$VIDEO_FILE" ]]; then
    FRAMES_DIR="$OUTDIR/frames"
    mkdir -p "$FRAMES_DIR"
    ffmpeg -y -i "$VIDEO_FILE" -vf "fps=1/30" "$FRAMES_DIR/frame-%03d.jpg" >&2 2>&1 || true
    echo "FRAMES_DIR:$FRAMES_DIR"
  fi
fi
