---
name: "video-watch"
version: 1.0.0
description: "Lire une vidéo en ligne (YouTube + ~1800 sites) : sous-titres via yt-dlp, repli Whisper si absents, frames pour le visuel."
homepage: https://github.com/yt-dlp/yt-dlp
metadata:
  {
    "openclaw":
      {
        "emoji": "🎥",
        "requires": { "bins": ["ffmpeg"] },
      },
  }
maj: 2026-09-03
---

# Video Watch — lire une vidéo en ligne

Récupère le contenu d'une vidéo en ligne (YouTube, Twitter/X, Vimeo, LinkedIn,
TikTok, et ~1800 sites supportés par `yt-dlp`) sans upload manuel du fichier.

Chaîne de repli, dans l'ordre :

1. **Sous-titres natifs** via `yt-dlp` — manuels si dispo, sinon auto-générés.
   Rapide (<1s), gratuit, pas de dépendance API. C'est la vraie transcription,
   pas la description de la vidéo (contrairement à un simple `web_fetch`).
2. **Audio + Whisper** si aucun sous-titre n'existe — télécharge l'audio,
   transcrit avec le binaire `whisper` local s'il est installé, sinon
   affiche comment brancher la skill `openai-whisper-api` (nécessite
   `OPENAI_API_KEY`).
3. **Frames** (optionnel, `--frames`) pour le contenu visuel — slides, démo
   d'écran, schéma — en s'appuyant sur `ffmpeg` (même logique que la skill
   `video-frames`).

## Quick start

Sous-titres/transcript uniquement :

```bash
{baseDir}/scripts/watch_video.sh "https://www.youtube.com/watch?v=XXXXXXXXXXX"
```

Avec langue préférée et frames pour le visuel :

```bash
{baseDir}/scripts/watch_video.sh "<url>" --lang fr,en --frames
```

Le script imprime sur stdout une ligne `TRANSCRIPT:<chemin>` (et
`FRAMES_DIR:<chemin>` si `--frames`) — lire ce fichier avec `Read` ensuite
pour analyser le contenu.

## Notes

- `yt-dlp` n'a pas besoin d'être installé au préalable : le script le
  télécharge en binaire statique (une fois) dans
  `$OPENCLAW_HOME/workspace/.tools/bin/` si absent du `PATH` — pas de sudo,
  pas d'apt requis.
- Les sous-titres auto-générés sont fiables pour du contenu parlé clair
  (conférence, interview, tuto) ; pour de l'audio bruyant ou une langue rare,
  préférer l'étape Whisper.
- Si ni sous-titres ni Whisper local ne sont disponibles, le script
  télécharge quand même l'audio et indique le chemin (`AUDIO:<chemin>`) pour
  transcription via `openai-whisper-api` si une clé est configurée.
- Respecter les CGU des plateformes sources ; usage prévu pour analyse de
  contenu (résumé, veille, formation), pas pour de la republication.

## Chaînage

- **Réutilise** `video-frames` (logique ffmpeg) pour l'étape frames.
- **Se branche sur** `openai-whisper` (binaire local) ou `openai-whisper-api`
  (clé API) pour la transcription audio quand aucun sous-titre n'existe.
