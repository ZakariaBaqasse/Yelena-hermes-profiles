---
id: Y0656
name: etat-rapprochement
version: 1.0.0
description: "Produit un état de rapprochement entre deux sources qui décrivent le même solde — relevé bancaire contre comptabilité, extrait d'opérateur contre système d'information, échéancier contre encaissements constatés — en appariant en cascade, en refusant de trancher les faux positifs, en datant l'apparition de chaque suspens, en reportant ce qui n'est pas résolu sur l'état suivant et en archivant la piste d'audit. Ne solde jamais un écart dont l'origine n'est pas établie, ne force jamais un équilibre, n'écrit jamais dans un système tiers."
bucket: B
tags: [Finance, Contrôle, Horizontal, Nouveau]
maj: 2026-09-03
---

# L'état de rapprochement — faire dire la même chose à deux sources

## Ce qu'il faut avoir sous la main
Je rapproche deux sources qui décrivent le même solde et je te dis exactement d'où vient chaque
écart. À la sortie : un état daté, la liste des éléments en rapprochement avec leur ancienneté,
les mises à jour proposées, et un dossier d'audit qui permet de rejouer le travail dans six mois.


- **L'objet à rapprocher** : un compte bancaire, un wallet, un compte d'opération, un encours de
  tiers, un échéancier, une caisse. La méthode est la même, la configuration change.
- **Les deux extraits de la période**, dans leur format d'origine.
- **Les soldes d'ouverture et de clôture** de chaque source. Ce sont eux qui permettent le
  contrôle d'auto-cohérence, et sans eux le rapprochement démarre à l'aveugle.
- **Le dernier état de rapprochement**, s'il existe — pour reprendre les suspens plutôt que de
  réexpliquer des écarts déjà expliqués.
- **La périodicité convenue** et le **seuil d'ancienneté** au-delà duquel un élément devient une
  anomalie.

> ⚡ Tu ne bloques pas en attendant tout. Avec un seul extrait, tu poses la structure, tu montres
> par où l'écart apparaîtra, et tu nommes les deux ou trois éléments qui manquent.

## Process

### Étape 1 — Vérifier que chaque source boucle sur elle-même

Avant toute comparaison : solde d'ouverture + mouvements = solde de clôture, **de chaque côté
séparément**. Si un extrait ne boucle pas, ce n'est pas un écart de rapprochement — c'est un
extrait incomplet, tronqué, ou un solde erroné, et le travail s'arrête là.

C'est le contrôle le plus rentable du métier et le plus souvent sauté. Un rapprochement mené sur
un extrait incomplet produit des dizaines de suspens qui n'existent pas, on passe des heures à
les qualifier, et l'erreur était à la première ligne.

### Étape 2 — Partir du dernier point vérifié

Si un état antérieur existe, tu pars de ses suspens, avec leurs dates d'apparition d'origine.
Un rapprochement qui repart de zéro à chaque période réexplique des écarts déjà expliqués et
perd la trace des anomalies identifiées mais non corrigées — c'est-à-dire exactement celles qui
comptent.

S'il n'en existe aucun, tu le dis : c'est un premier rapprochement, le volume d'écarts sera
mécaniquement plus élevé, et il ne se compare pas à un rythme de croisière qui n'existe pas encore.

### Étape 3 — Apparier en cascade

De la passe la plus sûre à la plus dégradée. Le détail des règles est dans `moteur-de-matching`.
Ce qui compte ici : **chaque appariement porte la passe qui l'a produit et sa confiance**. Un
appariement de passe dégradée est marqué « à valider » et n'engage rien.

Quand le volume dépasse ce qu'on relit à l'œil, tu passes par `outils/rapprocher.py` — tu ne
compares pas huit mille lignes de tête, et tu ne prétends jamais l'avoir fait.

### Étape 4 — Ne pas trancher les ambiguïtés

Deux mouvements du même montant dans la même fenêtre, sans clé discriminante, restent **non
appariés** et passent en annexe pour arbitrage.

C'est la règle qui coûte le plus à respecter, parce qu'apparier les deux ferait tomber le total
juste. Et c'est précisément pour ça qu'elle existe : un faux appariement fait disparaître deux
lignes, la somme reste bonne, et personne ne cherche jamais à cet endroit.

### Étape 5 — Qualifier chaque écart par sa nature

Chèque émis non présenté · virement enregistré non encore débité · frais bancaires ou agios non
enregistrés · commission d'opérateur · opération saisie deux fois · imputation au mauvais tiers ·
opération présente au relevé et absente des livres, et l'inverse.

**Jamais « divers ».** Un écart non catégorisé est un écart qu'on n'a pas encore compris — pas
une catégorie légitime.

### Étape 6 — Vieillir

Chaque élément porte sa **date d'apparition**, distincte de sa date d'opération. Tu classes par
ancienneté, pas par montant : c'est l'ancienneté qui révèle le chèque perdu, le doublon
d'enregistrement et le virement qui ne viendra jamais.

Au-delà du seuil convenu, un élément n'est plus en transit. Il change de nature : il devient une
anomalie qui appelle un nom, une cause et une date de résolution attendue.

### Étape 7 — Boucler, ou dire qu'on ne boucle pas

L'écart entre les deux soldes de clôture doit s'expliquer **exactement** par trois choses : ce
qui est au relevé et pas aux livres, ce qui est aux livres et pas au relevé, et le résidu des
appariements dégradés (les frais retenus sur un encaissement apparié).

S'il reste quoi que ce soit, ça s'affiche comme différence sans origine identifiée, avec son
montant et sa date. Ni soldée, ni répartie sur les autres lignes, ni rangée dans une ligne de
régularisation.

> Un état de rapprochement portant « différence non expliquée : ⟦montant⟧, apparue le ⟦date⟧ »
> est un livrable correct et honnête. Un état parfaitement équilibré sans explication est un
> signal d'alarme.

### Étape 8 — Arrêter, archiver, reporter

Tu prends la photo, tu archives le dossier complet (§ piste d'audit), tu proposes les corrections,
et **ce qui n'est pas résolu se reporte sur l'état suivant** avec sa date d'apparition d'origine.

## Format de sortie

Le gabarit `gabarits/etat-de-rapprochement.md`, dans cet ordre :

1. **Ce qu'il faut retenir** — ça boucle ou ça ne boucle pas, en une phrase, en tête
2. Les deux soldes et l'écart à expliquer
3. Ce qui a été rapproché, par passe, avec le niveau de confiance
4. Les éléments en rapprochement, classés par ancienneté décroissante
5. Le bouclage, en toutes lettres
6. Les mises à jour proposées — jamais exécutées
7. Annexe : les rapprochements non tranchés
8. Annexe : la piste d'audit
9. Le visa

## Règles

1. **On n'équilibre jamais une différence qu'on ne comprend pas.** Une écriture corrective se
   propose seulement quand l'origine est établie et documentée.
2. **Une ambiguïté ne se tranche pas.** Elle remonte à l'humain avec ses candidats.
3. **Le compte de trésorerie est la source de vérité.** L'ajustement se porte dans le système
   d'information, jamais l'inverse.
4. **Le vieillissement prime sur le montant.**
5. **Ce qui n'est pas résolu se reporte**, avec sa date d'apparition d'origine.
6. **Un extrait qui ne boucle pas sur lui-même arrête le travail.**
7. **La périodicité mensuelle est un minimum.** Un compte très mouvementé se rapproche plus
   souvent, et tu le signales si la fréquence actuelle est insuffisante.

**Garde-fous durs**

- **0 invention.** Aucun montant, taux de commission, cours ou date fabriqué. Ce qui manque est
  marqué `⟦à confirmer⟧`.
- **0 écriture.** Cette compétence produit un document de travail. Passer une écriture, modifier
  un système d'information, contacter la banque ou un opérateur sont des actions validées.
- **0 fausse exhaustivité.** Tu ne dis jamais avoir parcouru un volume que tu n'as pas parcouru.
  Sur un gros volume : tu passes par l'outil, ou tu dis que tu échantillonnes et sur quel critère.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne sert jamais de repère pour une autre,
  même comme ordre de grandeur, même dans une phrase d'illustration.

## Cas limites

- **Un seul des deux extraits disponible** — tu poses la structure et tu montres où l'écart
  apparaîtra ; tu ne simules pas l'autre côté.
- **Compte non dédié aux opérations** — tu le signales comme un problème en soi, avant même le
  premier état : un compte qui mêle flux de tiers et charges internes rend tout écart
  ininterprétable.
- **Écart qui persiste malgré des corrections passées** — tu ne repasses pas une correction sans
  comprendre pourquoi la précédente n'a rien résolu ; c'est une anomalie structurelle.
- **Multi-devises sans cours fourni** — tu isoles la composante change et tu la marques
  `⟦cours à renseigner⟧`. Tu ne l'estimes jamais.
- **Caisse jamais comptée physiquement** — c'est un manque de contrôle en soi, indépendamment du
  résultat comptable.
- **Soupçon de détournement** — tu le signales factuellement (montant, date, nature) sans
  qualifier juridiquement les faits, et tu recommandes l'implication d'une personne habilitée.
- **Volume ingérable à la main sans accès à l'outil** — tu le dis, tu ne fais pas semblant, et tu
  proposes le format d'export qui permettrait de le traiter.
