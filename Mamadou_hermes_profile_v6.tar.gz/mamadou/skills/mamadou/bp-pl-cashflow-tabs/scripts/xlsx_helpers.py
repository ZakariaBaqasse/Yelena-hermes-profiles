"""Aides openpyxl pour generer les onglets P&L_Monthly, P&L_Yearly,
Cashflow_Monthly et Cashflow_Yearly d'un BP (voir references/layout-standard.md).

Grille commune avec bp-acquisition-tab et bp-assumptions-tab :
    A = libelles, B = unite, C = Year 0, D->AM = 36 mois.
Aucun decalage de colonne entre onglets : 'P&L_Monthly'!D <-> ASSUMPTIONS!D.

Usage type :
    from xlsx_helpers import *
    wb = Workbook(); ws = wb.active; ws.title = "P&L_Monthly"
    setup_sheet(ws, "P&L_Monthly")
    write_timeline_monthly(ws, linked_sheet="ACQUISITION_MODEL")
    r = section_header(ws, 9, "VOLUMES")
    r = write_row(ws, r, "Total active buyers", "#", kind="link",
                  formula="='ACQUISITION_MODEL'!{col}32")
    r = margin_pair(ws, r, "Gross profit", eur_formula="={col}20-{col}28",
                    pct_formula="=IFERROR({col}30/{col}$20,0)")
Toutes les formules sont des chaines '=...' (syntaxe anglaise, separateur
virgule) : Excel les calcule a l'ouverture.
"""

from openpyxl import Workbook  # noqa: F401
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------- constantes
NAVY = "002060"           # bandeaux de section, bandes et cle d'annee
SUBSECTION = "D9E2F3"     # sous-sections + fond de la ligne des mois
SUBFAMILY = "DEEAF6"      # encadre titre
VOLUME_BLOCK = "F3F3F3"   # bloc de rappel des volumes en tete de P&L
ALERT_RED = "FFC7CE"      # fond d'alerte (mise en forme conditionnelle)

BLUE_INPUT = "0432FF"     # police input (financement, solde initial)
GREEN_LINK = "008000"     # police lien inter-onglet
GREY_INFO = "A5A5A5"      # lignes informatives

FMT_ACC = '_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ '
FMT_PCT = "0.0%"
FMT_MONTH = "mmm-yy"

F_INPUT = Font(color=BLUE_INPUT)
F_FORMULA = Font(color="000000")
F_LINK = Font(color=GREEN_LINK)
F_SECTION = Font(color="FFFFFF", bold=True)
F_INFO = Font(color=GREY_INFO, italic=True)

FILL_NAVY = PatternFill("solid", fgColor=NAVY)
FILL_SUB = PatternFill("solid", fgColor=SUBSECTION)
FILL_SUBFAM = PatternFill("solid", fgColor=SUBFAMILY)
FILL_VOLUME = PatternFill("solid", fgColor=VOLUME_BLOCK)

_double = Side(style="double", color="000000")
_thin = Side(style="thin", color="000000")
TOTAL_BORDER = Border(top=_double, bottom=_double)
SUBTOTAL_BORDER = Border(top=_thin, bottom=_thin)

FIRST_MONTH_COL = 4        # D = mois 1
YEAR0_COL = 3              # C = Year 0
YEARKEY_ROW = 6            # ligne-cle d'annee (VISIBLE)
MONTH_ROW = 7              # ligne des dates
FIRST_YEAR_COL = 3         # onglets annuels : C = Year 1
MPE_CELL = "$C$3"          # "Months per exercise" des onglets annuels


def last_month_col(n_months=36):
    return FIRST_MONTH_COL + n_months - 1      # 36 mois -> AM (39)


def col(i):
    return get_column_letter(i)


# ---------------------------------------------------------------- structure
def setup_sheet(ws, title, yearly=False, n_months=36):
    """Largeurs, gel des volets, cartouche de titre."""
    if yearly:
        ws.column_dimensions["A"].width = 40
        ws.column_dimensions["B"].width = 5
        for c in range(FIRST_YEAR_COL, FIRST_YEAR_COL + 3):
            ws.column_dimensions[col(c)].width = 14
        ws.freeze_panes = "C7"
        ws["A3"] = "Months per exercise"
        mpe = ws["C3"]
        mpe.value = 12
        mpe.font = F_INPUT
    else:
        ws.column_dimensions["A"].width = 38
        ws.column_dimensions["B"].width = 5
        ws.column_dimensions[col(YEAR0_COL)].width = 11
        for c in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
            ws.column_dimensions[col(c)].width = 9
        ws.freeze_panes = "C9"
    ws.row_dimensions[3].height = 27
    ws["C1"] = "BUSINESS PLAN"
    ws["C1"].font = Font(bold=True, size=14)
    ws["C1"].fill = FILL_SUBFAM
    ws["C2"] = title
    ws["C2"].font = Font(bold=True, size=16)


def _style_year(cell):
    cell.fill = FILL_NAVY
    cell.font = F_SECTION
    cell.alignment = Alignment(horizontal="center")


def write_timeline_monthly(ws, start_month=None, linked_sheet=None,
                           linked_first_cell="C7", n_months=36, n_years=3):
    """Ligne 5 bandes fusionnees, ligne 6 cle d'annee VISIBLE, ligne 7 dates.
    Mode chaine  : linked_sheet = onglet maitre du calendrier.
                   linked_first_cell depend de l'onglet source :
                     ASSUMPTIONS et P&L_Monthly  -> 'C7' (defaut, meme ligne)
                     ACQUISITION_MODEL           -> 'C6'
                   Verifier la ligne reelle avant de cabler : brancher la
                   cle d'annee au lieu des dates est silencieux et casse
                   tous les MATCH de l'agregation annuelle.
    Mode autonome: start_month = 'YYYY-MM' du mois 0 (colonne C)."""
    c0 = col(YEAR0_COL)
    for row in (5, YEARKEY_ROW):
        cell = ws[f"{c0}{row}"]
        cell.value = "Year 0"
        _style_year(cell)
    c = FIRST_MONTH_COL
    for yr in range(1, n_years + 1):
        first, last = c, c + 11
        ws.merge_cells(start_row=5, start_column=first, end_row=5, end_column=last)
        ws.cell(row=5, column=first, value=f"Year {yr}")
        for k in range(first, last + 1):
            _style_year(ws.cell(row=5, column=k))
            _style_year(ws.cell(row=YEARKEY_ROW, column=k, value=f"Year {yr}"))
        c = last + 1

    if linked_sheet:
        from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
        letter, rownum = coordinate_from_string(linked_first_cell)
        base = column_index_from_string(letter)
        for i, k in enumerate(range(YEAR0_COL, last_month_col(n_months) + 1)):
            src = f"{col(base + i)}{rownum}"
            cell = ws.cell(row=MONTH_ROW, column=k,
                           value=f"='{linked_sheet}'!{src}")
            cell.font = F_LINK
    else:
        from datetime import date
        y, m = (int(x) for x in start_month.split("-"))
        ws.cell(row=MONTH_ROW, column=YEAR0_COL, value=date(y, m, 1)).font = F_INPUT
        for k in range(FIRST_MONTH_COL, last_month_col(n_months) + 1):
            ws.cell(row=MONTH_ROW, column=k,
                    value=f"=EDATE({col(k - 1)}{MONTH_ROW},1)")
    for k in range(YEAR0_COL, last_month_col(n_months) + 1):
        cell = ws.cell(row=MONTH_ROW, column=k)
        cell.number_format = FMT_MONTH
        cell.fill = FILL_SUB
        cell.alignment = Alignment(horizontal="center")
        cell.font = Font(color=GREEN_LINK if linked_sheet else "000000", bold=True)


def write_timeline_yearly(ws, n_years=3):
    """Ligne 5 : en-tetes d'exercice, chaines identiques a la ligne-cle des
    onglets mensuels (critere d'appariement des SUMIF)."""
    for i in range(n_years):
        cell = ws.cell(row=5, column=FIRST_YEAR_COL + i, value=f"Year {i + 1}")
        _style_year(cell)


def eoy_boy_rows(ws, row, monthly_sheet, n_years=3):
    """Lignes techniques BOY / EOY en pied d'onglet annuel. Decalages derives
    du rang de colonne et de C3 (mois par exercice), jamais en dur.
    Retourne (row_boy, row_eoy, next_row)."""
    src = f"'{monthly_sheet}'!$D${MONTH_ROW}:$AM${MONTH_ROW}"
    for label, offset, r in (("BOY (first month of exercise)",
                              f"(COLUMNS($C5:{{col}}5)-1)*{MPE_CELL}+1", row),
                             ("EOY (last month of exercise)",
                              f"COLUMNS($C5:{{col}}5)*{MPE_CELL}", row + 1)):
        ws.cell(row=r, column=1, value=label).font = F_INFO
        for i in range(n_years):
            letter = col(FIRST_YEAR_COL + i)
            cell = ws.cell(row=r, column=FIRST_YEAR_COL + i,
                           value=f"=INDEX({src},{offset.format(col=letter)})")
            cell.font = F_INFO
            cell.number_format = FMT_MONTH
    return row, row + 1, row + 2


def section_header(ws, row, label, n_cols=None, yearly=False):
    """Bandeau navy pleine largeur. Retourne row+2 (ligne vide comprise)."""
    n_cols = n_cols or (FIRST_YEAR_COL + 2 if yearly else last_month_col())
    ws.cell(row=row, column=1, value=label)
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = FILL_NAVY
        cell.font = F_SECTION
    return row + 2


def subsection_header(ws, row, label, n_cols=None, yearly=False):
    """Bandeau bleu clair. Retourne row+1."""
    n_cols = n_cols or (FIRST_YEAR_COL + 2 if yearly else last_month_col())
    ws.cell(row=row, column=1, value=label)
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = FILL_SUB
        cell.font = Font(bold=True)
    return row + 1


# ---------------------------------------------------------------- lignes
def write_row(ws, row, label, unit, kind="formula", fmt=FMT_ACC,
              formula=None, values=None, n_months=36, yearly=False,
              n_years=3, total=False, subtotal=False, info=False,
              volume_block=False, year0=None):
    """Ecrit une ligne complete sur toute la grille de temps.
    kind    : 'formula' | 'link' | 'input'
    formula : patron avec {col} = colonne courante, {prev} = precedente,
              {yk} = ref ligne-cle ('D$6'), {mo} = ref date ('D$7')
    yearly  : ecrit sur C:E au lieu de C:AM
    total   : double filet ; subtotal : filet simple
    year0   : valeur ou formule specifique en colonne C (onglets mensuels)

    Indexation de `values` sur les onglets mensuels : values[0] est le MOIS 1
    (colonne D), pas la colonne C. La colonne C est pilotee par `year0` seul.
    Un vecteur de 36 valeurs se cale donc exactement sur D->AM : c'est ce que
    l'utilisateur ecrit quand il donne une trajectoire annee par annee, et un
    decalage d'un cran y ferait basculer les parametres annuels un mois trop
    tot, sans erreur visible.
    """
    font = {"input": F_INPUT, "formula": F_FORMULA, "link": F_LINK}[kind]
    if info:
        font = F_INFO
    ws.cell(row=row, column=1, value=label)
    ws.cell(row=row, column=2, value=unit)
    if yearly:
        cols = range(FIRST_YEAR_COL, FIRST_YEAR_COL + n_years)
    else:
        cols = range(YEAR0_COL, last_month_col(n_months) + 1)
    for k in cols:
        letter = col(k)
        cell = ws.cell(row=row, column=k)
        i = (k - FIRST_YEAR_COL) if yearly else (k - FIRST_MONTH_COL)
        if not yearly and k == YEAR0_COL:
            if year0 is not None:
                cell.value = year0
            elif formula is not None:
                cell.value = formula.format(col=letter, prev=col(k - 1),
                                            yk=f"{letter}${YEARKEY_ROW}",
                                            mo=f"{letter}${MONTH_ROW}")
            elif not isinstance(values, (list, tuple)):
                cell.value = values
        elif formula is not None:
            cell.value = formula.format(col=letter, prev=col(k - 1),
                                        yk=f"{letter}${YEARKEY_ROW}",
                                        mo=f"{letter}${MONTH_ROW}")
        elif isinstance(values, (list, tuple)):
            cell.value = values[i] if i < len(values) else values[-1]
        else:
            cell.value = values
        cell.font = font
        cell.number_format = fmt
        if volume_block:
            cell.fill = FILL_VOLUME
        if total:
            cell.border = TOTAL_BORDER
        elif subtotal:
            cell.border = SUBTOTAL_BORDER
    if total or subtotal:
        border = TOTAL_BORDER if total else SUBTOTAL_BORDER
        for c in (1, 2):
            ws.cell(row=row, column=c).border = border
        ws.cell(row=row, column=1).font = Font(bold=True)
    return row + 1


def margin_pair(ws, row, label, eur_formula, pct_formula, **kw):
    """Palier de marge : ligne en euros (double filet) suivie de sa ligne en
    pourcentage du revenu. Les deux libelles sont distincts, ce que le corpus
    ne fait pas. Retourne la ligne suivante."""
    row = write_row(ws, row, label, "EUR", formula=eur_formula, total=True, **kw)
    row = write_row(ws, row, f"{label} (% of revenue)", "%",
                    formula=pct_formula, fmt=FMT_PCT, **kw)
    return row


# ------------------------------------------------- constructeurs de formules
def sumif_flux(monthly_sheet, src_row, n_months=36):
    """Agregation annuelle d'un FLUX. Plage demarrant en C : Year 0 ne matche
    aucun critere 'Year 1/2/3' et se trouve exclu par construction."""
    last = col(last_month_col(n_months))
    return (f"=SUMIF('{monthly_sheet}'!$C${YEARKEY_ROW}:${last}${YEARKEY_ROW},"
            f"{{col}}$5,'{monthly_sheet}'!$C{src_row}:${last}{src_row})")


def index_stock(monthly_sheet, src_row, eoy_row, n_months=36):
    """Lecture annuelle d'un STOCK a la date de cloture. Ne JAMAIS utiliser
    sumif_flux sur une base active, un parc, un effectif ou un solde."""
    last = col(last_month_col(n_months))
    return (f"=IFERROR(INDEX('{monthly_sheet}'!$C{src_row}:${last}{src_row},"
            f"MATCH({{col}}${eoy_row},"
            f"'{monthly_sheet}'!$C${MONTH_ROW}:${last}${MONTH_ROW},0)),0)")


def second_path(monthly_sheet, src_row, yearly_row):
    """Controle d'agregation par seconde voie : doit valoir zero."""
    return (f"={{col}}{yearly_row}-SUM(OFFSET('{monthly_sheet}'!$D${src_row},0,"
            f"(COLUMNS($C5:{{col}}5)-1)*{MPE_CELL},1,{MPE_CELL}))")


def year_min(monthly_sheet, closing_row):
    """Point bas de tresorerie de l'exercice (la ligne la plus utile d'un
    cashflow annuel : une cloture confortable peut masquer un trou)."""
    return (f"=MIN(OFFSET('{monthly_sheet}'!$D${closing_row},0,"
            f"(COLUMNS($C5:{{col}}5)-1)*{MPE_CELL},1,{MPE_CELL}))")


def da_window(qty_row, price_cell, years_cell, assumptions="ASSUMPTIONS"):
    """D&A bornee par la duree de vie : somme des seuls millesimes encore en
    vie. Remplace l'accumulation '=...+C<da>' du corpus, qui amortit
    indefiniment."""
    return (f"=SUMPRODUCT(OFFSET('{assumptions}'!$D${qty_row},0,"
            f"MAX(0,COLUMNS($D5:{{col}}5)-'{assumptions}'!{years_cell}*12),1,"
            f"MIN(COLUMNS($D5:{{col}}5),'{assumptions}'!{years_cell}*12)))"
            f"*'{assumptions}'!{price_cell}"
            f"/('{assumptions}'!{years_cell}*12)")


def days_in_month():
    """Nombre de jours du mois courant, robuste aux annees bissextiles."""
    return f"DAY(EOMONTH({{col}}${MONTH_ROW},0))"


# ---------------------------------------------------------------- controles
def control_row(ws, row, label, formula, yearly=False, n_years=3,
                n_months=36, text_result=False):
    """Ligne de controle : ecart devant valoir zero, fond rouge sinon."""
    fmt = "General" if text_result else FMT_ACC
    row_written = write_row(ws, row, label, "" if text_result else "EUR",
                            formula=formula, fmt=fmt, info=True,
                            yearly=yearly, n_years=n_years, n_months=n_months)
    if not text_result:
        first = col(FIRST_YEAR_COL if yearly else YEAR0_COL)
        last = col(FIRST_YEAR_COL + n_years - 1 if yearly
                   else last_month_col(n_months))
        conditional_nonzero(ws, f"{first}{row}:{last}{row}")
    return row_written


def conditional_nonzero(ws, cell_range):
    """Fond rouge si different de zero (tolerance d'arrondi)."""
    ws.conditional_formatting.add(
        cell_range,
        CellIsRule(operator="notBetween", formula=["-0.01", "0.01"],
                   fill=PatternFill("solid", bgColor=ALERT_RED)))


def conditional_negative(ws, cell_range):
    """Fond rouge si negatif : a poser sur toute ligne de solde de tresorerie."""
    ws.conditional_formatting.add(
        cell_range,
        CellIsRule(operator="lessThan", formula=["0"],
                   fill=PatternFill("solid", bgColor=ALERT_RED)))


def note(ws, row, text):
    """Note de convention en pied d'onglet (BFR nul assume, Year 0 exclu des
    agregats, interets non repris au P&L...). Une convention ecrite n'est pas
    un defaut ; une convention deduite par le lecteur en est un."""
    cell = ws.cell(row=row, column=1, value=text)
    cell.font = F_INFO
    return row + 1
