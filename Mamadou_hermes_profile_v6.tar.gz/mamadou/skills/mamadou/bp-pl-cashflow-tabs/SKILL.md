---
name: "bp-pl-cashflow-tabs"
version: "1.0.0"
description: "Génère P&L_Monthly, P&L_Yearly, Cashflow_Monthly, Cashflow_Yearly d'un BP en formules actives, cascade de marges correcte."
maj: 2026-09-03
---

# Onglets P&L et Cashflow d'un BP — générateur

## Ce que produit ce skill

Quatre onglets Excel qui forment la couche de restitution d'un BP : `P&L_Monthly`, `P&L_Yearly`, `Cashflow_Monthly`, `Cashflow_Yearly`. Ils ne créent aucune hypothèse : ils traduisent en états financiers les volumes produits par l'onglet acquisition et les prix et coûts produits par l'onglet assumptions.

Trois principes gouvernent tout :

- **Ces onglets sont des dérivés, pas des moteurs.** Chaque ligne est soit un lien vers l'amont, soit une opération arithmétique locale entre lignes du même onglet. Toute cellule de ces onglets qui contient une hypothèse est un défaut : elle appartient à l'onglet assumptions. La seule exception admise est le bloc de financement du cashflow (tranches d'equity et de dette), et elle doit être marquée en bleu.
- **Un flux se somme, un stock se lit à une date.** C'est l'invariant central de l'agrégation annuelle et l'erreur la plus fréquente du corpus : additionner douze bases actives mensuelles produit un nombre dépourvu de sens. Un ratio ne s'agrège pas non plus, il se recalcule sur les agrégats.
- **Les décaissements se somment depuis des lignes de charges, jamais depuis des paliers de marge.** Le corpus contient une erreur de ce type qui crée 321 000 € de décaissements fictifs sur un seul exercice. Le skill pose systématiquement une ligne de contrôle qui vérifie l'articulation.

## Workflow obligatoire

1. **Inventorier le classeur cible.** Les onglets amont existent-ils (`ACQUISITION_MODEL`, `ASSUMPTIONS`) ? Si oui, relever leurs adresses de lignes de sortie (base active, volumes, prix, coûts, effectifs) : ce sont les seules entrées autorisées. Si non, voir "mode autonome" plus bas.
2. **Qualifier la famille de business model** avec l'arbre ci-dessous. Elle détermine uniquement le haut de cascade (revenus et COGS) ; tout le reste est transverse.
3. **Lire `references/familles-revenus-cogs.md`** pour le haut de cascade de la famille retenue.
4. **Lire les fiches d'onglet** dans l'ordre de construction : `references/pl-monthly.md`, puis `references/cashflow-monthly.md`, puis `references/pl-yearly.md`, puis `references/cashflow-yearly.md`.
5. **Lire `references/layout-standard.md`** (mise en forme normative, non négociable) avant d'écrire la moindre cellule.
6. **Collecter les paramètres manquants** auprès de l'utilisateur (AskUserQuestion si disponible) : délais de BFR, tranches de financement, capex, fiscalité. Ne jamais inventer un DSO ou un taux d'impôt sans le marquer comme hypothèse à valider en commentaire de cellule.
7. **Construire le .xlsx avec openpyxl et des formules Excel actives.** Jamais de valeurs calculées en Python et collées en dur. Utiliser `scripts/xlsx_helpers.py`.
8. **Exécuter les contrôles** de `references/controles.md` avant livraison, et laisser dans le classeur le bloc de contrôle qu'ils décrivent.

## Arbre de décision maître

La famille est celle des onglets amont du même BP (les trois skills de la chaîne partagent la typologie). Elle ne change que les blocs Revenus et COGS.

```
Q1. D'où vient le revenu ?
├─ D'un abonnement récurrent facturé à une base active
│                                        → famille BASE RÉCURRENTE
├─ D'une commission sur un volume intermédié (TPV, GMV)
│   Q2. L'entreprise achète-t-elle la marchandise qu'elle revend ?
│   ├─ OUI, revenu brut puis achats      → famille MARKETPLACE BI-FACE
│   └─ NON, commission pure sur flux     → famille USAGE / COHORTES
├─ De la vente d'unités physiques dont l'entreprise maîtrise le coût d'achat
│                                        → famille ROLLOUT D'ACTIFS (cost-plus)
├─ D'un parc d'unités déployées chez des tiers qui génèrent du volume
│                                        → famille RÉSEAU D'AGENTS
└─ De la location ou de la mise à disposition d'actifs financés par dette
                                         → famille ACTIFS FINANCÉS
```

Familles inférées : BASE RÉCURRENTE et ACTIFS FINANCÉS ne sont pas instanciées dans le corpus de référence ; leur haut de cascade est construit par transposition. Le signaler à l'utilisateur en livraison et marquer les lignes concernées d'un commentaire "structure inférée, à valider".

Cas composites (fréquents) : empiler un bloc revenus et un bloc COGS par activité, avec un total consolidé. Les paliers de marge, les OpEx, les assets et tout le cashflow restent uniques.

## Architecture des quatre onglets

```
ACQUISITION_MODEL ─┐
                   ├─► P&L_Monthly ─┬─► P&L_Yearly
ASSUMPTIONS ───────┘                │
                                    └─► Cashflow_Monthly ─► Cashflow_Yearly
```

Règle de sens unique : `P&L_Monthly` ne lit jamais `P&L_Yearly`. Le corpus contient trois occurrences de cette inversion (une charge assise sur le revenu annuel va le chercher dans l'onglet aval), dont une qui propage une erreur de 421 000 € sur un exercice. Quand une charge a une assiette annuelle, la calculer en local par `SUMIF` sur la ligne-clé d'année de l'onglet mensuel lui-même.

## Conventions par défaut (appliquer sans redemander)

- **Grille unique pour tout le classeur.** Colonne A = libellés, B = unité, C = Year 0, D→AM = 36 mois. Identique aux onglets produits par bp-acquisition-tab et bp-assumptions-tab, donc **aucun décalage de colonne entre onglets** : `P&L_Monthly!D` correspond à `ASSUMPTIONS!D` et à `Cashflow_Monthly!D`. Le corpus contient deux décalages d'une colonne entre onglets alignés, qui sont des pièges de maintenance permanents.
- **Ossature temporelle** : ligne 5 bandes d'année fusionnées, ligne 6 ligne-clé d'année visible (`Year 0/1/2/3` répété par colonne, clé de tous les `SUMIF` et `MATCH`), ligne 7 dates liées à l'onglet amont maître (ou chaîne `EDATE` en mode autonome), ligne 8 vide. Volets figés en C9. **Aucune ligne masquée porteuse de calcul** : grouper si besoin, jamais hauteur 0.
- **Year 0** : colonne C, visible, flux à zéro. Elle porte le solde d'ouverture de trésorerie et sert de base aux variations séquentielles. Elle est exclue des agrégats annuels par construction, puisque l'étiquette "Year 0" n'est jamais un critère de `SUMIF`. Écrire cette convention dans une note de l'onglet.
- **Cascade du P&L, arrêt à l'EBIT** : Volumes, Revenus, COGS, Marge brute, Autres coûts directs, CM1 ou Contribution profits, OpEx par département, EBITDA, D&A, EBIT. Chaque palier est immédiatement suivi d'une ligne en pourcentage du revenu total, protégée par `IFERROR`. Le prolongement charges financières, résultat avant impôt, impôt, résultat net existe en bloc optionnel : ne le poser que si l'utilisateur le demande, et alors avec report déficitaire.
- **Tableau de flux en méthode directe** : encaissements et décaissements par nature, sans passage par le résultat. Cohérent avec l'absence de bilan dans cette architecture. Trois sous-totaux distincts et jamais mélangés : exploitation (BFR inclus), investissement, financement.
- **Intérêts de la dette** : décaissement de financement du cashflow. Comme le P&L s'arrête à l'EBIT, ils n'y apparaissent pas ; le signaler dans une note de l'onglet cashflow pour que le lecteur ne cherche pas une charge financière au P&L.
- **Liens inter-onglets en police verte #008000, systématiquement.** Le corpus ne colore aucun de ses quelque 180 liens : l'audit visuel y est inopérant. C'est la correction de forme la plus rentable.
- **Libellés** : anglais, cohérents avec les onglets amont. Les lignes de ratio sont suffixées explicitement (`Gross margin (% of revenue)`) : le corpus duplique des libellés identiques sur une ligne en euros et une ligne en pourcentage, seule la colonne d'unité les distingue.
- **Anonymat** : ne jamais mentionner les entreprises des modèles de référence dans le fichier généré.

## Corrections structurelles appliquées par défaut

Le corpus contient environ 180 défauts recensés. Ce skill génère la version corrigée, et ces règles priment sur toute imitation littérale des modèles de référence.

1. **Décaissements construits depuis des lignes de charges.** Ne jamais sommer un palier de marge ni une ligne de pourcentage dans un cash-out. Poser la ligne de contrôle qui vérifie que le flux d'exploitation reconstitue bien le dernier palier repris.
2. **Plages de somme couvrant l'intégralité de leur bloc.** Six omissions de totaux ont été relevées dans le corpus (un revenu annuel amputé de deux segments sur quatre, sous-évalué de 70 %). Après chaque total, vérifier que la plage commence à la première ligne de détail et finit à la dernière.
3. **Une seule logique de formule par ligne, de D à AM.** Aucune rupture aux charnières d'année : les bascules annuelles passent par le lookup sur la ligne-clé d'année, jamais par un changement de référence de colonne. Aucune valeur en dur au milieu d'une ligne calculée.
4. **Ancrages complets.** `$C$120` et non `$C120` : un ancrage de colonne seul laisse la ligne se décaler silencieusement à la moindre insertion en amont.
5. **Chaque paramètre de segment pointe vers son propre segment.** Contrôler les couples miroirs ligne à ligne (le corpus inverse deux take-rates entre segments).
6. **`IFERROR` sur tous les ratios**, y compris celui de l'EBITDA et ceux de la colonne Year 0.
7. **D&A bornée par la durée de vie.** L'amortissement s'arrête à l'échéance de chaque millésime : fenêtre glissante, jamais une accumulation `=...+D73` qui amortit indéfiniment.
8. **Stocks jamais sommés** dans l'annuel, ratios jamais agrégés.
9. **Décalages annuels dérivés du rang de colonne**, jamais 11, 23, 35 en dur. Le nombre de mois par exercice est une cellule labellisée.
10. **Effet de bord de fin de plage neutralisé.** Toute formule qui lit le mois suivant (BFR) est bornée sur la dernière colonne, sinon elle lit une cellule vide et crée un encaissement fictif.
11. **Alerte de découvert et point bas de trésorerie affichés.** Aucun solde négatif ne doit passer inaperçu : le corpus présente jusqu'à 31 mois négatifs sans aucun signal.
12. **Pas de bloc de runway fantaisiste.** Les quatre modèles portent un bloc "Operating Runway" qui recalcule un solde selon une définition différente du solde principal, sans réconciliation. Soit un vrai runway en mois avec dénominateur explicite, soit rien.
13. **Un seul format de pourcentage par famille de ratio**, un seul format comptable pour tout le classeur.

## Mode autonome

Si le classeur n'a ni onglet acquisition ni onglet assumptions, proposer d'abord d'appeler `bp-acquisition-tab` puis `bp-assumptions-tab` : un P&L sans amont est un P&L saisi à la main, c'est-à-dire l'inverse de ce que ce skill produit. Si l'utilisateur veut malgré tout les états seuls, poser un bloc d'hypothèses minimal en tête du P&L, en bleu et clairement encadré, et le signaler comme provisoire à déplacer dans un onglet assumptions.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/layout-standard.md` | Toujours, avant de construire |
| `references/familles-revenus-cogs.md` | Toujours — haut de cascade des 6 familles |
| `references/pl-monthly.md` | Construction de l'onglet P&L mensuel |
| `references/cashflow-monthly.md` | Construction du cashflow mensuel (BFR, capex, financement) |
| `references/pl-yearly.md` | Agrégation annuelle du P&L |
| `references/cashflow-yearly.md` | Agrégation annuelle de la trésorerie (flux, soldes, point bas) |
| `references/controles.md` | Toujours, avant de livrer |
| `scripts/xlsx_helpers.py` | Styles, ossature, cascade, constructeurs de formules d'agrégation |
