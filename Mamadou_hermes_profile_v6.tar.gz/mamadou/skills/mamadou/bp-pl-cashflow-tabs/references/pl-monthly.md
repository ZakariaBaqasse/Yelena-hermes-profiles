# Onglet P&L_Monthly

Compte de résultat de gestion mensuel, pivot du classeur. C'est une table de correspondance : chaque ligne est un lien vers l'amont ou une opération entre lignes du même onglet. Aucune hypothèse n'y est saisie.

## Structure de l'onglet, bloc par bloc

L'ordre est normatif : le cashflow, le P&L annuel et le lecteur naviguent dedans par habitude.

```
ligne 9   BANDEAU  VOLUMES                        navy
          bases actives par segment (lien acquisition)     fond #F3F3F3
          volumes transactionnels (lien assumptions)
          Total volume                                     double filet
          % mom

          BANDEAU  REVENUES                       navy
          revenu par segment (volume × prix)
          Total revenues                                   double filet
          % mom

          BANDEAU  COGS                           navy
          coûts directs indexés sur les mêmes volumes
          Total COGS                                       double filet
          Gross profit                                     double filet
          Gross margin (% of revenue)

          BANDEAU  OTHER DIRECT COSTS             navy
          coûts directs de second rang (technique, service, terrain)
          Total other direct costs                         double filet
          Contribution margin                              double filet
          Contribution margin (% of revenue)

          BANDEAU  OPEX                           navy
          sous-section Sales & Marketing          #D9E2F3
              salaries / benefits / advertising / other expenses / sous-total
          sous-section IT & Product               #D9E2F3
          sous-section G&A / Exec & Admin         #D9E2F3
          Total OpEx                                       double filet

          EBITDA                                           double filet
          EBITDA margin (% of revenue)
          D&A
          EBIT                                             double filet
          EBIT margin (% of revenue)

          BANDEAU  CONTROLS                       navy
          lignes d'auto-contrôle (voir controles.md)
```

Le nombre de paliers de marge intermédiaires (un seul, ou CM1 puis CM2) dépend du nombre d'inducteurs de coût distincts : autant de paliers que de familles de coûts variables pilotables séparément. Un modèle logistique en aura deux (coûts liés au produit, puis coûts liés à la transaction et à la livraison), un modèle SaaS un seul.

## Patrons de formules

Colonne D, recopiée jusqu'à AM. `X` désigne la colonne courante.

| Élément | Patron |
|---|---|
| Base active (stock) | `=ACQUISITION_MODEL!D<ligne_total_active>` — lien vert. Vérifier que la ligne source est bien le stock et non le flux de nouveaux clients : le corpus branche un "New clients" là où il annonce un parc |
| Volume transactionnel | `=D<base_active>*ASSUMPTIONS!D<panier>` — la référence de colonne doit être **relative** pour suivre le vecteur mensuel des assumptions. Le corpus fige deux paniers sur 36 mois par un `$C$` de trop |
| Revenu par segment | `=D<volume>*ASSUMPTIONS!D<prix>` |
| Total | `=SUM(D<première>:D<dernière>)` — plage couvrant tout le bloc |
| % mom | `=IFERROR(D<total>/C<total>-1,0)` |
| Coût direct indexé volume | `=D<volume>*ASSUMPTIONS!D<coût_unitaire>` |
| Coût direct indexé revenu | `=D<revenu_total>*ASSUMPTIONS!$C$<taux>` |
| Palier de marge | `=D<palier_précédent>-D<bloc_de_coût>` |
| Ligne de ratio | `=IFERROR(D<palier>/D$<revenu_total>,0)` |
| Charge à assiette annuelle avec plancher | `=MAX(SUMIF($C$6:$AM$6,D$6,$C$<revenu>:$AM$<revenu>)*<taux>/12, <plancher>/12)` — le `SUMIF` est **local**, jamais un lookup vers l'onglet annuel |
| Salaires par département | `=ASSUMPTIONS!D<ligne_masse_salariale>` — lien vert |
| Benefits | `=D<salaires>*ASSUMPTIONS!$C$<taux_benefits>` — ancrage complet |
| Other expenses | `=D<salaires>*ASSUMPTIONS!$C$<taux_other>` |
| EBITDA | `=D<contribution>-SUM(D<sous_totaux_opex>)` |
| D&A bornée | voir ci-dessous |
| EBIT | `=D<ebitda>-D<da>` |

### D&A bornée par la durée de vie

Le corpus accumule la dotation sans jamais sortir un millésime à son échéance (`=...+C<da>`), ce qui amortit indéfiniment des actifs de deux ans sur un horizon de trois. Le patron correct additionne les seuls millésimes encore en vie :

```
=SUMPRODUCT(
   OFFSET(ASSUMPTIONS!$D$<ligne_capex_qté>, 0,
          MAX(0, COLUMNS($D5:D5) - ASSUMPTIONS!$C$<durée_années>*12),
          1,
          MIN(COLUMNS($D5:D5), ASSUMPTIONS!$C$<durée_années>*12))
 ) * ASSUMPTIONS!$C$<prix_unitaire> / (ASSUMPTIONS!$C$<durée_années>*12)
```

Une ligne par catégorie d'actif, puis un total. Alternative plus lisible si le classeur porte peu de catégories : un bloc de millésimes en pied d'onglet, une ligne par mois d'acquisition, avec fenêtrage `IF(AND(mois>=acq; mois<acq+durée); dotation; 0)`.

Contrôle associé : la somme des dotations sur l'horizon ne peut pas dépasser le capex cumulé.

## Colonne Year 0

Toutes les lignes de flux à zéro (formule identique, résultat nul puisque les volumes amont y sont nuls), toutes les lignes de ratio protégées par `IFERROR`. Ne jamais laisser une cellule vide au milieu d'une ligne calculée : le corpus laisse une cellule de ratio vide en colonne d'amorçage, ce qui casse la recopie.

Si le business a une activité préexistante, Year 0 porte son P&L réel. Dans ce cas, écrire explicitement en note que Year 0 n'entre dans aucun agrégat annuel, ou créer une colonne "Year 0" dans l'onglet annuel. Le corpus laisse un résultat de Year 0 qui n'atterrit nulle part.

## Bloc optionnel sous l'EBIT

À ne poser que sur demande explicite. Structure :

```
Financial expenses      = lien vers la ligne d'intérêts du Cashflow_Monthly (signe positif)
EBT                     = EBIT − financial expenses
Loss carryforward       = MIN(0, cumul des EBT antérieurs)   ' report déficitaire
Taxable base            = MAX(0, EBT + loss carryforward)
Corporate income tax    = IF(base>0, MAX(base*taux(année), plancher/12), plancher/12)
Net income              = EBT − tax
```

Le `MAX` avec plancher modélise l'impôt minimum forfaitaire, dû même en perte dans plusieurs juridictions (zone OHADA notamment). Le taux vient d'une grille annuelle des assumptions, lue par lookup sur la ligne-clé : le corpus fige un taux en absolu sur la première année et applique 0 % sur tout l'horizon sans s'en apercevoir.

## Pièges du corpus à ne pas reproduire

- Un total qui omet une ligne de son bloc (six occurrences relevées, dont un revenu sous-évalué de 70 %).
- Deux paramètres de segment croisés entre eux.
- Une bascule de taux annuel écrite par changement de référence de colonne en cours de ligne, à un mois qui n'est pas une charnière d'exercice, et pointant vers des cellules vides.
- Un ratio sans `IFERROR` qui affiche `#DIV/0!` en colonne d'amorçage.
- Un lookup vers l'onglet annuel pour une charge assise sur le revenu.
- Des lignes de détail masquées à hauteur 0 alors qu'elles portent tout le détail du revenu et des COGS.
