# Onglet Cashflow_Monthly

Plan de trésorerie mensuel en méthode directe. Il répond à une seule question : à quelle date la trésorerie casse, et de combien il faut lever. Il ne recopie pas le P&L, il le convertit en flux.

Méthode directe et non indirecte parce que cette architecture ne porte pas de bilan : sans disponibilités au bilan ni résultat net, la méthode indirecte n'aurait rien à retraiter. Ce choix se documente dans une note de l'onglet.

## Structure

```
BANDEAU  OPERATING CASH                                    navy
   Starting balance                    = clôture du mois précédent
   Cash-in from sales                  encaissements, corrigés du DSO
   Cash-out from COGS                  décaissements directs, corrigés du DPO
   Cash-out from OpEx                  décaissements de structure
   Change in working capital           variation du BFR
   Operating cash-flow                 double filet

BANDEAU  INVESTING CASH                                    navy
   Capex                               par catégorie d'actif
   Investing cash-flow                 double filet

BANDEAU  FINANCING CASH                                    navy
   Equity injections                   inputs bleus datés
   Debt drawdowns                      inputs bleus datés
   Debt repayments                     échéancier
   Interest paid                       sur encours d'ouverture
   Financing cash-flow                 double filet

   Closing balance                     double filet
   Cash alert                          "À FINANCER" si négatif
   Lowest balance to date              minimum glissant

BANDEAU  CONTROLS                                          navy
   lignes d'auto-contrôle
```

Les trois sous-totaux sont **strictement séparés**. Le corpus agrège investissement, financement et BFR dans une seule ligne "non-operating cash-flow", ce qui rend la ligne de flux d'exploitation inexploitable et interdit toute lecture de la structure de financement. La variation de BFR est un flux d'exploitation : elle appartient au premier bloc.

## Patrons de formules

| Élément | Patron |
|---|---|
| Solde d'ouverture | `=C<closing>` — roll-forward strict, sans saut de colonne. Le premier mois lit la colonne Year 0, dont le solde est l'input de trésorerie initiale |
| Encaissements | `=D<revenu_PL>` — le montant du P&L, **sans lissage** (voir la règle du mécanisme unique ci-dessous) |
| Décaissements directs | `=-D<cogs_PL>` |
| Décaissements de structure | `=-SUM(D<sous_totaux_opex_PL>)` — **uniquement des lignes de charges**, jamais un palier de marge |
| Variation de BFR | voir ci-dessous |
| Flux d'exploitation | `=SUM(D<cash_in>:D<change_wc>)` |
| Capex | `=-ASSUMPTIONS!D<quantité>*ASSUMPTIONS!$C$<prix_unitaire>` — une ligne par catégorie, chaque quantité appariée à SON prix |
| Tirage d'equity ou de dette | input bleu daté, zéro ailleurs |
| Remboursement | `=-IF(D$6_index>$C$<différé>, SUM($D<tirages>:D<tirages>)/$C$<maturité>, 0)` |
| Intérêts | `=-(SUM($D<tirages>:C<tirages>)+SUM($D<remb>:C<remb>))*$C$<taux_annuel>/12` — sur l'**encours d'ouverture**, jamais de clôture, sinon référence circulaire |
| Flux de financement | `=SUM(D<equity>:D<intérêts>)` |
| Solde de clôture | `=D<ouverture>+D<flux_expl>+D<flux_invest>+D<flux_fin>` |
| Alerte | `=IF(D<closing><0,"À FINANCER","")` |
| Point bas à date | `=MIN($D<closing>:D<closing>)` |

## Le bloc BFR

Le corpus le réduit à un délai fournisseur, ou l'omet complètement. Sur un modèle qui porte du stock physique, l'omission représente le plus gros écart du modèle.

### Règle du mécanisme unique

Il existe deux façons de faire entrer un délai de règlement dans un tableau de flux, et **elles s'excluent** :

- soit on lisse les lignes d'encaissement et de décaissement (`revenu du mois × (1−DSO/30) + revenu du mois précédent × DSO/30`),
- soit on porte les montants du P&L tels quels sur les lignes de cash et on fait entrer tout le décalage par une ligne unique de variation de BFR.

Appliquer les deux compte deux fois le même effet de timing, sans qu'aucune erreur Excel ne le signale. **Ce skill retient la seconde**, pour trois raisons : elle expose les postes de BFR (créances, stocks, dettes fournisseurs), qui sont l'information que le lecteur cherche ; elle garde une ligne de cash directement rapprochable du P&L, ce que le contrôle d'articulation exige ; et elle isole la totalité de l'effet de délai sur une ligne unique, donc pilotable.

Structure normative, trois postes, chacun avec son délai en jours (inputs bleus, ou liens vers les assumptions si les délais y vivent) :

```
Trade receivables   =  D<revenu_PL>   / <jours du mois> * $C$<DSO>
Inventory           =  D<cogs_PL>     / <jours du mois> * $C$<DIO>
Trade payables      = -D<achats_PL>   / <jours du mois> * $C$<DPO>
Working capital     =  SUM des trois        ' un STOCK, jamais sommé dans l'annuel
Change in WC        = -(D<wc> - C<wc>)      ' la VARIATION, seule à entrer dans le flux
```

Nombre de jours du mois : `=DAY(EOMONTH(D$7,0))`. Le corpus utilise `DAY(DATE(YEAR(x),MONTH(x)+1,1)-1)`, qui est correct mais moins lisible ; `EOMONTH` est équivalent et robuste aux années bissextiles.

Trois règles impératives :

- La ligne `Working capital` est un **stock** : elle ne doit jamais être agrégée par somme dans l'onglet annuel. Seule `Change in WC` est un flux.
- Le signe : une augmentation du BFR consomme de la trésorerie, donc `Change in WC` est négative quand l'activité croît. Poser un contrôle de signe sur les premiers mois de croissance.
- Le contrôle qui prouve que le mécanisme unique est respecté :

```
CTRL  = <flux d'exploitation> - <EBITDA> + <impôt décaissé> - <change in WC>
```

Il vaut zéro si et seulement si les lignes de cash portent bien les montants du P&L et que tout le décalage passe par la variation de BFR. S'il ne vaut pas zéro, c'est en général qu'un lissage a été appliqué en plus.

Alternative admise si le BFR est nul par choix (encaissement et décaissement comptant) : ne pas poser le bloc, mais **écrire la convention en clair** dans une ligne de note de l'onglet. Un DSO nul déduit d'une formule par le lecteur est un défaut ; un DSO nul assumé et écrit ne l'est pas.

## Le bloc financement

Version simple, suffisante pour un BP d'amorçage :

- Tranches d'equity : une ligne, montants saisis au mois de versement (inputs bleus). Plusieurs tranches possibles sur la même ligne.
- Tirages de dette : idem.
- Remboursement linéaire sur la maturité, démarrant après un différé. **Le différé est un input labellisé en mois**, jamais un choix de colonne de départ : le corpus démarre un remboursement en colonne Q sans qu'aucune hypothèse ne le justifie.
- Intérêts sur l'encours d'ouverture (capital tiré moins capital remboursé à fin du mois précédent), au taux annuel divisé par douze.
- Contrôles associés : la somme des remboursements égale la somme des tirages à l'échéance ; le capital restant dû est nul au terme ; aucun remboursement avant tirage.

Si l'utilisateur ne fournit ni montant ni taux, poser les lignes vides mais **ne jamais laisser une formule diviser une cellule vide** (le corpus calcule un remboursement en divisant un tirage vide par une maturité). Encadrer par `IFERROR` ou par un test sur le montant tiré.

## Dimensionnement de la levée

Le point bas de trésorerie sur l'horizon est le chiffre que le lecteur cherche. Le poser explicitement :

```
Lowest closing balance over horizon   = MIN($D<closing>:$AM<closing>)
Funding need                          = -MIN(0, lowest closing balance)
```

Un modèle du corpus injecte 150 000 € face à un besoin cumulé de 3,9 M€ sans que rien ne le signale. Ces deux lignes rendent l'écart impossible à manquer.

## Runway

Si l'utilisateur veut un runway, une seule définition admise, avec son dénominateur écrit :

```
Runway (months) = IF(D<closing><=0, 0,
                     D<closing> / ABS(AVERAGE(B<flux_expl>:D<flux_expl>)))
```

soit le solde disponible divisé par le burn d'exploitation moyen des trois derniers mois. Les quatre modèles du corpus portent un bloc intitulé "Operating Runway" qui recalcule un second solde selon une formule différente du solde principal, sans réconciliation, et n'affiche jamais une durée. Ne pas reproduire : soit cette ligne-ci, soit rien.
