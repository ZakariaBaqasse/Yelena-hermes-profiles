# Onglet P&L_Yearly

Synthèse annuelle du compte de résultat. Dérivé pur : il ne produit aucune information nouvelle et ne doit contenir **aucun input**. Un investisseur lit trois colonnes, pas trente-six ; c'est la seule raison d'être de l'onglet.

## La règle qui gouverne tout : trois natures de grandeur, trois mécanismes

C'est l'invariant le plus précieux du corpus, documenté indépendamment dans trois modèles sur quatre. Se tromper de mécanisme produit des nombres dépourvus de sens sans déclencher la moindre erreur Excel.

| Nature | Mécanisme | Pourquoi |
|---|---|---|
| **Flux** (revenus, coûts, marges, dotations) | `SUMIF` sur la ligne-clé d'année | Un flux s'additionne sur la période |
| **Stock** (bases actives, parc, effectifs, BFR) | `INDEX` + `MATCH` sur la date de clôture | Un stock se constate à une date. Sommer douze bases actives multiplie le parc par douze |
| **Ratio** (marges en %, croissances) | Recalcul local sur les agrégats | La moyenne de douze marges mensuelles n'est pas la marge annuelle |

Patrons exacts :

```
Flux   = SUMIF('P&L_Monthly'!$C$6:$AM$6, C$5, 'P&L_Monthly'!$C<n>:$AM<n>)
Stock  = IFERROR(INDEX('P&L_Monthly'!$C<n>:$AM<n>,
                       MATCH(C$<eoy>, 'P&L_Monthly'!$C$7:$AM$7, 0)), 0)
Ratio  = IFERROR(C<palier>/C$<revenu_total>, 0)
```

La plage source démarre en `$C` (Year 0 inclus) : Year 0 ne matche aucun critère "Year 1/2/3" et se trouve donc exclu par construction, sans exception à écrire. La plage source couvre tout l'horizon, ce qui rend l'onglet insensible à une extension du nombre de mois.

## Structure

Miroir ligne à ligne de `P&L_Monthly`, mêmes libellés, même ordre, mêmes bandeaux. Le décalage de lignes entre les deux onglets n'a pas besoin d'être constant, mais **chaque `SUMIF` doit pointer vers la ligne dont le libellé de la colonne A correspond**. Deux modèles du corpus changent de décalage en cours d'onglet et laissent des lignes de calcul manquantes.

Ajouts propres à l'onglet annuel :

- Une ligne `% yoy` sous le revenu total (`=IFERROR(D<rev>/C<rev>-1,0)`, démarre en deuxième colonne). Ne pas l'intituler `% mom` : le corpus le fait.
- Les lignes techniques `BOY` et `EOY` en pied d'onglet (voir layout-standard).
- Un bloc `CONTROLS` en pied (voir controles.md), dont la ligne d'agrégation par seconde voie.

## Ne jamais

- Utiliser `SUM` sur une plage figée de douze colonnes (`=SUM('P&L_Monthly'!D19:O19)`). Trois lignes du corpus le font au milieu d'un onglet qui emploie `SUMIF` partout ailleurs : les valeurs sont justes aujourd'hui et fausses à la première insertion de colonne.
- Sommer une base active, un parc ou un effectif.
- Agréger un ratio, ou faire une moyenne de ratios.
- Laisser un libellé sans formule (le corpus contient deux libellés orphelins inclus dans des sommes).
- Recopier une formule de stock d'une ligne à l'autre sans changer l'indice de ligne : un modèle affiche le nombre de grossistes sur la ligne des revendeurs pour cette raison.
- Coder les décalages annuels en dur (11, 23, 35). Ils se dérivent du rang de colonne et du nombre de mois par exercice.

## Bloc effectifs

Si le BP présente un bloc d'effectifs annuel, le lire comme un **stock** à la date de clôture, depuis `P&L_Monthly` ou directement depuis les assumptions. Un modèle du corpus court-circuite l'onglet mensuel pour lire les assumptions en direct : c'est acceptable si l'information n'existe pas au mensuel, à condition de ne pas créer deux chemins pour la même donnée.

## Contrôle d'agrégation par seconde voie

Une ligne par grandeur majeure, qui recalcule l'agrégat autrement et affiche l'écart. Elle doit valoir zéro :

```
= C<revenu_annuel> - SUM(OFFSET('P&L_Monthly'!$D$<revenu>, 0,
                                (COLUMNS($C5:C5)-1)*$C$3, 1, $C$3))
```

Aucun des quatre modèles de référence n'en porte. C'est le contrôle qui aurait détecté le revenu annuel amputé de deux segments sur quatre, erreur qui a traversé six versions d'un des BP.
