# Onglet Cashflow_Yearly

**Aucun des quatre BP de référence ne contient cet onglet.** L'un l'écrit explicitement ("aucun onglet Cashflow_Yearly n'existe"), les trois autres s'arrêtent au mensuel. Cette fiche est donc une construction, pas une transposition : elle applique au cashflow la discipline flux / stock que le corpus a établi pour le P&L annuel. Le signaler à l'utilisateur en livraison.

## Pourquoi l'onglet est plus subtil que le P&L annuel

Un cashflow annuel mélange trois natures dans le même écran, là où le P&L annuel n'en mélange que deux :

- Les **flux** de la période (encaissements, décaissements, capex, tirages) s'additionnent sur douze mois.
- Le **solde d'ouverture** est celui du premier mois de l'exercice, pas une somme.
- Le **solde de clôture** est celui du dernier mois de l'exercice, pas une somme.
- Le **BFR** est un stock ; seule sa variation est un flux.

Sommer les douze soldes de clôture d'un exercice produit un nombre qui ne signifie rien et que rien ne signale. C'est exactement l'erreur que la discipline du corpus prévient côté P&L.

## Structure

Miroir de `Cashflow_Monthly`, mêmes libellés, mêmes bandeaux, plus deux lignes propres à l'annuel.

```
BANDEAU  OPERATING CASH
   Starting balance                 stock, lu au premier mois de l'exercice
   Cash-in from sales               flux, SUMIF
   Cash-out from COGS               flux, SUMIF
   Cash-out from OpEx               flux, SUMIF
   Change in working capital        flux, SUMIF
   Operating cash-flow              flux, SUMIF (et non la somme des lignes ci-dessus,
                                    pour que l'écart éventuel se voie)

BANDEAU  INVESTING CASH / FINANCING CASH        flux, SUMIF

   Closing balance                  stock, lu au dernier mois de l'exercice
   Lowest monthly balance in year   minimum sur les douze mois de l'exercice
   Cash alert

BANDEAU  CONTROLS
```

## Patrons de formules

```
Flux              = SUMIF('Cashflow_Monthly'!$C$6:$AM$6, C$5,
                          'Cashflow_Monthly'!$C<n>:$AM<n>)

Solde d'ouverture = IFERROR(INDEX('Cashflow_Monthly'!$C<opening>:$AM<opening>,
                                  MATCH(C$<boy>, 'Cashflow_Monthly'!$C$7:$AM$7, 0)), 0)

Solde de clôture  = IFERROR(INDEX('Cashflow_Monthly'!$C<closing>:$AM<closing>,
                                  MATCH(C$<eoy>, 'Cashflow_Monthly'!$C$7:$AM$7, 0)), 0)

Point bas annuel  = MIN(OFFSET('Cashflow_Monthly'!$D$<closing>, 0,
                               (COLUMNS($C5:C5)-1)*$C$3, 1, $C$3))
```

Le point bas annuel est la ligne la plus utile de l'onglet : un exercice peut se clôturer avec un solde confortable après être passé par un trou de trésorerie en milieu d'année. Une lecture annuelle qui n'affiche que la clôture masque précisément ce que le plan de trésorerie sert à révéler.

## Contrôles propres à l'onglet

Ces trois lignes valent zéro ou vrai sur chaque colonne, et n'existent nulle part dans le corpus :

```
CTRL 1  Articulation      = C<closing> - C<opening> - C<flux_expl> - C<flux_inv> - C<flux_fin>
CTRL 2  Chaînage          = D<opening> - C<closing>        ' ouverture N = clôture N-1
CTRL 3  Cohérence P&L     = C<cash_in> - 'P&L_Yearly'!C<revenu>   ' nul si DSO = 0,
                            sinon égal à la variation de créances de l'exercice
```

Le contrôle 2 est celui qui attrape les erreurs de décalage de colonne entre onglets, et le contrôle 1 celui qui attrape un flux oublié dans un sous-total.

## Ce qui ne va PAS dans cet onglet

- Aucune ligne de BFR en stock (créances, stocks, dettes fournisseurs) : ce sont des postes de bilan, ils n'ont pas leur place dans un tableau de flux. Seule la variation y figure.
- Aucun runway annuel : le runway est une grandeur instantanée, il se lit au mensuel.
- Aucun input : comme le P&L annuel, l'onglet est un dérivé pur.
