# Contrôles avant livraison — onglets P&L et Cashflow

Deux niveaux : les contrôles **posés dans le classeur** (un bloc `CONTROLS` par onglet, qui reste visible pour l'utilisateur et se recalcule à chaque modification) et les contrôles **exécutés à la génération** par relecture openpyxl.

Chaque item correspond à un défaut réellement constaté dans les BP de référence. Le corpus n'en porte aucun : c'est précisément pourquoi une erreur de câblage de 321 000 € et un revenu annuel sous-évalué de 70 % ont pu traverser six versions d'un même modèle.

## A. Bloc CONTROLS à poser dans le classeur

Chaque ligne affiche un écart qui doit valoir zéro, avec mise en forme conditionnelle en rouge si différent de zéro. Les poser en pied d'onglet, sous un bandeau navy, jamais masquées.

**Dans `P&L_Monthly`**

```
CTRL 1  Cascade OpEx      = <CM> - SUM(<sous-totaux OpEx>) - <EBITDA>
CTRL 2  Cascade marges    = <revenu> - <COGS> - <autres coûts directs> - <CM>
CTRL 3  D&A cumulée       = <cumul D&A> - <capex cumulé>        ' doit rester <= 0
CTRL 4  Totaux de blocs   = <total revenus> - SUM(<lignes de détail>)
```

**Dans `Cashflow_Monthly`**

```
CTRL 5  Articulation      = <clôture> - <ouverture> - <flux expl> - <flux inv> - <flux fin>
CTRL 6  Roll-forward      = <ouverture du mois> - <clôture du mois précédent>
CTRL 7  Mécanisme unique  = <flux expl> - <EBITDA> + <impôt décaissé> - <change in WC>
                            ' non nul = un lissage de délai a été appliqué en double
CTRL 8  Dette             = SUM(<remboursements>) - SUM(<tirages>)   ' nul au terme
CTRL 9  Solde négatif     = IF(MIN(<clôtures>)<0, "BESOIN DE FINANCEMENT", "OK")
```

**Dans `P&L_Yearly`**

```
CTRL 10 Seconde voie      = <agrégat SUMIF> - SUM(OFFSET(<ligne mensuelle>, 0,
                            (COLUMNS($C5:C5)-1)*$C$3, 1, $C$3))
CTRL 11 Stocks            = les lignes de stock ne doivent JAMAIS être en SUMIF
                            (contrôle visuel : leur formule contient INDEX et MATCH)
```

**Dans `Cashflow_Yearly`**

```
CTRL 12 Articulation      = <clôture> - <ouverture> - somme des trois flux
CTRL 13 Chaînage          = <ouverture Year N> - <clôture Year N-1>
```

## B. Contrôles exécutés à la génération (relecture openpyxl)

### Structure et continuité

1. **Continuité horizontale** : pour chaque ligne calculée, la formule est homogène de D à AM (mêmes références relatives, même structure). Toute cellule qui rompt le motif est un hardcode camouflé. Contrôler aussi la colonne Year 0, qui doit porter la même formule et non une cellule vide.
2. **Charnières d'année** : aucune bascule de référence en colonne P ou AB. Les changements de paramètre annuel passent exclusivement par le lookup sur la ligne-clé.
3. **Ancrages** : toute référence à une **cellule d'hypothèse scalaire** est ancrée en ligne et en colonne (`$C$120`, jamais `$C120`) : un ancrage de colonne seul laisse la ligne se décaler à la recopie verticale et le corpus en contient quatre occurrences. En revanche, dans les formules d'agrégation annuelle, la référence à la **ligne source** reste relative en ligne (`$C20:$AM20`) : chaque ligne porte sa propre formule, elle n'est jamais recopiée verticalement, et le relatif permet à Excel de suivre une insertion de ligne dans l'onglet mensuel. Ne pas « corriger » ce cas.
4. **Plages de somme complètes** : pour chaque `SUM`, la plage commence à la première ligne de détail du bloc et finit à la dernière. Comparer au bloc délimité par les lignes vides.
5. **Aucune ligne ni colonne masquée** porteuse de calcul actif. Aucune ligne de hauteur 0.
6. **Grille unique** : dans chaque formule inter-onglets, la lettre de colonne référencée est identique à celle de la cellule porteuse. Tout écart signale un décalage de grille.
7. **Dates** : liées à l'onglet amont ou générées par `EDATE`. Aucune date en dur.
8. **Aucun libellé orphelin** : toute ligne portant un libellé en colonne A dans une zone de calcul porte une formule, et réciproquement.
9. **Pas de mise en forme résiduelle** sur les lignes et colonnes vides au-delà du contenu réel.

### Sémantique

10. **Flux contre stock** dans les onglets annuels : chaque ligne de stock (base active, parc, effectifs, BFR, soldes de trésorerie) utilise `INDEX`+`MATCH`, chaque ligne de flux utilise `SUMIF`. Aucune exception.
11. **Ratios** recalculés localement sur les agrégats, jamais agrégés.
12. **Décaissements** construits uniquement depuis des lignes de charges. Vérifier que chaque référence d'un cash-out pointe vers une ligne dont le libellé n'est ni une marge, ni un pourcentage, ni une ligne vide.
13. **Paramètres de segment** : chaque ligne de segment référence le paramètre de son propre segment. Contrôler les couples miroirs deux à deux.
14. **Marges de paiement** : pour chaque croisement méthode × canal, commission supérieure ou égale au fee, sinon validation explicite consignée en commentaire.
15. **D&A bornée** : la formule contient une fenêtre glissante ou un fenêtrage par date. Aucune auto-référence du type `+C<da>`.
16. **BFR** : la ligne de variation est bien une différence entre deux mois, la ligne de stock n'entre dans aucun flux, la dernière colonne est neutralisée contre l'effet de bord.
17. **Intérêts** calculés sur l'encours d'ouverture, jamais de clôture.
18. **Sens de lecture** : aucune formule de `P&L_Monthly` ou `Cashflow_Monthly` ne référence un onglet annuel.
19. **Aucun input** dans `P&L_Monthly`, `P&L_Yearly`, `Cashflow_Yearly`. Les seuls inputs admis sont dans le bloc financement et le solde initial de `Cashflow_Monthly`, et ils sont en bleu.

### Forme

20. **Liens inter-onglets en police verte** #008000, sans exception. Compter les formules contenant un `!` et vérifier que toutes sont vertes.
21. **Calculs locaux en noir**, inputs en bleu #0432FF.
22. **Double filet** en haut de chaque ligne de total et de palier de marge.
23. **Un seul format** de pourcentage et un seul format comptable sur les quatre onglets.
24. **Volets figés** posés sur les quatre onglets, colonne d'unité comprise dans la zone gelée.
25. **Libellés de ratio distincts** de leur ligne en euros (suffixe explicite).
26. **Anonymat** : aucune mention des entreprises des modèles de référence dans les libellés, notes, commentaires, noms d'onglets ou propriétés du fichier.

### Vraisemblance

27. **Recalculer une colonne de bout en bout** à la main, en milieu d'exercice 2 et non au premier mois : chaque ligne doit se lire sans ouvrir d'autre cellule que ses références.
28. **Confronter aux repères de calibrage** de la famille (voir familles-revenus-cogs.md) : marge brute, marge de contribution, poids de la masse salariale, intensité capitalistique. Signaler à l'utilisateur tout écart marqué, sans le corriger d'office : c'est une hypothèse métier, pas une erreur de modèle.
29. **Point bas de trésorerie** confronté aux tranches de financement saisies. Si le besoin dépasse le financement prévu, l'écrire en clair dans la note de livraison.
30. **Signaler les familles inférées** (base récurrente, actifs financés) et les hypothèses posées par défaut, avec la liste des cellules concernées.
