# Haut de cascade par famille de business model

Seuls les blocs Volumes, Revenues, COGS et Other direct costs changent d'une famille à l'autre. Tout ce qui est en dessous (OpEx par département, EBITDA, D&A, EBIT, et l'intégralité du cashflow) est transverse et décrit dans les fiches d'onglet.

Chaque fiche donne : le bloc volumes, la formule de revenu, la formule de coût direct, le nombre de paliers de marge justifié, et les repères de calibrage de la famille. Les repères sont directionnels et doivent être confrontés aux données propres de l'entreprise, jamais traités comme des cibles.

---

## 1. MARKETPLACE BI-FACE (instanciée dans le corpus)

Le modèle capte une part de valeur sur un flux qu'il achète et revend. Le revenu est brut, l'achat de marchandise est son complément.

```
Volumes     Total sellers                = ACQUISITION_MODEL!<parc offreurs>
            Active buyers par segment    = ACQUISITION_MODEL!<base active>
            Total orders                 = ACQUISITION_MODEL ou onglet logistique

Revenues    Revenue segment k            = D<buyers k> * ASSUMPTIONS!D<panier mensuel k>
            Gross revenues               = SUM

COGS        Purchases segment k          = D<revenue k> * (1 - ASSUMPTIONS!D<take-rate k>)
            Total purchases              = SUM
            Gross margin                 = revenue - purchases

CM1         First-mile logistics         = lien onglet logistique, variabilisé par volume
            Losses / provisions          = D<gross revenues> * ASSUMPTIONS!D<taux de perte>
            Contribution margin 1        = gross margin - ces coûts

CM2         Payment fees                 = revenue*taux_ventes + purchases*taux_achats
            Last-mile logistics          = coût par commande, ou effectif × salaire
            Warehousing                  = idem
            Customer service             = effectif dimensionné amont × salaire
            Contribution margin 2
```

Deux paliers parce que deux familles d'inducteurs distinctes : coûts liés au produit (logistique amont, pertes) puis coûts liés à la transaction et à la livraison. Les effectifs opérationnels dimensionnés par le volume de commandes appartiennent à la CM2 et non aux OpEx : ils sont économiquement variables même s'ils sont contractuellement fixes.

Piège vérifié : chaque take-rate doit pointer vers SON segment. Le corpus les croise, ce qui fausse la marge brute et rend le mix par segment inexploitable.

Repères : take-rate brut 8 à 18 %, marge brute 15 à 25 %, CM après logistique 5 à 12 %, pertes physiques sur frais 3 à 8 %, masse salariale 15 à 30 % du CA.

---

## 2. USAGE / COHORTES, commission sur flux (instanciée)

Le modèle ne possède jamais la marchandise : il prélève une commission sur un volume intermédié. Le revenu et le coût direct s'appliquent à la même assiette avec des grilles différentes.

```
Volumes     Active clients par canal     = ACQUISITION_MODEL!<base active>
            TPV par canal                = ASSUMPTIONS!<TPV total du canal>
            Total TPV                    = SUM

Revenues    Payment revenue canal k      = D<TPV k> * SUMPRODUCT(mix des méthodes,
                                                                 grille de commissions)
            Revenu récurrent (SaaS)      = D<abonnés> * SUMPRODUCT(mix des tiers, pricing)
            Revenu matériel              = D<unités vendues> * ASSUMPTIONS!$C$<prix>
            Total revenue                = SUM

COGS        Transaction fees canal k     = D<TPV k> * SUMPRODUCT(mix des méthodes,
                                                                 grille de fees)
            Coût matériel                = D<unités vendues> * ASSUMPTIONS!$C$<coût>
            Total COGS

Other       Customer service, DevOps     = lookup annuel sur la ligne-clé, /12,
direct                                     avec plancher contractuel par MAX
```

Un seul palier intermédiaire (Contribution profits) : les coûts techniques et de service varient avec le volume sans être des coûts de revient transactionnels.

Contrôle obligatoire : pour chaque croisement méthode × canal, `commission - fee > 0`, ou validation explicite de l'utilisateur consignée en commentaire. Le corpus contient un segment entier à marge de paiement nulle, jamais détecté.

Repères : take rate 0,3 à 1,5 % du volume, marge brute plateforme 40 à 70 %, marge matérielle 30 à 50 % du prix de vente.

---

## 3. ROLLOUT D'ACTIFS / négoce cost-plus (instanciée)

Le prix de vente est une sortie du modèle, pas une entrée : il dérive du coût d'achat.

```
Volumes     Base active par canal        = ACQUISITION_MODEL!<base active>
            Units sold par canal         = D<base active> * ASSUMPTIONS!D<panier unitaire>
            Total units sold             = SUM

Revenues    Revenue canal k              = D<units k> * ASSUMPTIONS!D<ASP du canal k>
                                           (ASP construit en cascade cost-plus dans
                                            les assumptions, avec érosion temporelle)
            Gross revenues               = SUM

COGS        Cost of device               = D<total units> * ASSUMPTIONS!D<coût unitaire>
            Transportation               = D<total units> * coût * taux de transport
            Refurbishing / preparation   = coût de CAPACITÉ (paliers de techniciens),
                                           pas un coût unitaire
            Warranty provision           = D<gross revenues> * ASSUMPTIONS!$C$<taux>
            Packaging                    = D<total units> * coût unitaire d'emballage
            Total COGS
```

Le coût de préparation est un coût de capacité : un atelier ne se dimensionne pas au décimal, on embauche au franchissement d'un seuil de volume. Il vient des assumptions déjà arrondi, et porte ses charges patronales comme le reste de l'effectif (le corpus les lui laisse alors qu'il les a supprimées ailleurs, incohérence à ne pas reproduire).

Ne pas oublier l'emballage : le corpus laisse un libellé "Packaging" sans formule, inclus dans une somme, pour un e-commerçant.

Repères : marge brute canal grossiste et revendeur 8 à 15 %, canal particulier 22 à 32 %, consolidée 12 à 20 %, marge d'EBITDA à maturité 3 à 8 %, capex sur CA 1 à 3 %.

---

## 4. RÉSEAU D'AGENTS, parc déployé chez des tiers (instanciée)

Le parc est un stock, le volume qu'il génère est un flux. Deux régimes de détention coexistent souvent (unités louées, unités détenues), et ils n'ont pas la même structure de coût : les traiter en blocs miroirs sur toute la hauteur.

```
Volumes     Parc par régime              = ACQUISITION_MODEL!<parc actif>   (stock)
            Transactions par régime      = D<TPV régime> / ASSUMPTIONS!$C$<ticket moyen>
            TPV par régime               = ASSUMPTIONS!<TPV valorisé du régime>
            Total TPV                    = SUM

Revenues    Commission régime k          = D<TPV k> * ASSUMPTIONS!$C$<take rate>
            Refacturation au réseau      = LIGNE SÉPARÉE :
                                           taux * (loyer unitaire * parc + coût de collecte)
            Total revenue                = SUM

COGS        Distribution fees régime k   = take_rate * D<TPV k> * part variable
                                           + coût fixe par transaction * D<transactions k>
            Total COGS

Other       Collecte / service terrain   = lien assumptions (coût par zone × parc par zone)
direct

OpEx ops    Loyer des unités louées      = ASSUMPTIONS!$C$<loyer> * D<parc loué>
            Coût d'exploitation détenu   = (redevance + connectivité) * D<parc détenu>
            Coût d'activation            = ASSUMPTIONS!$C$<setup> * D<nouvelles unités>
```

La refacturation au réseau se pose **sur sa propre ligne**, jamais additionnée dans la ligne de commission. Le corpus la noie dans la formule de revenu, ce qui masque une perte structurelle sur la part non refacturée. Une ligne de marge sur refacturation rend le partage de coût lisible.

Si le modèle intermédie des fonds appartenant à des tiers (collecte d'espèces, escrow), ajouter au cashflow un bloc de flottant : dette de reversement égale au volume intermédié multiplié par le délai de reversement sur trente, avec une trésorerie restreinte en contrepartie, séparée de la trésorerie disponible. Sans ce bloc, le besoin de financement est structurellement sous-estimé.

Un P&L de segment peut légitimement s'arrêter à la CM2, à condition de renvoyer explicitement vers un onglet consolidé qui porte la structure. L'écrire dans une note, sinon le lecteur croit lire un compte de résultat complet.

Repères : take rate cash-in / cash-out 0,3 à 1,5 %, part du réseau dans la commission 40 à 60 %, marge de contribution après coûts terrain 20 à 40 %.

---

## 5. BASE RÉCURRENTE / abonnement (INFÉRÉE, à marquer comme à valider)

Non instanciée dans le corpus de référence. Structure transposée depuis les familles voisines et la pratique standard du SaaS.

```
Volumes     Active subscribers par tier  = ACQUISITION_MODEL!<base active>   (stock)
            Total active subscribers     = SUM

Revenues    MRR par tier                 = D<abonnés tier k> * ASSUMPTIONS!D<prix tier k>
            Revenu d'usage éventuel      = D<volume> * prix unitaire
            Revenu de mise en service    = D<nouveaux clients> * frais d'onboarding
            Total revenues                = SUM

COGS        Hébergement / infrastructure = % du revenu, avec plancher contractuel par MAX
            Payment fees                 = D<revenu> * taux
            Support et customer success  = effectif dimensionné amont × salaire
            Total COGS
            Gross margin                 (un seul palier : pas de deuxième inducteur)
```

Trois particularités à ne pas manquer :

- Marge brute élevée par nature (70 à 85 %). Une marge brute SaaS sous 60 % signale un coût de service mal classé ou un modèle qui n'est pas du logiciel.
- Le support et le customer success sont des **COGS**, pas des OpEx : ils varient avec la base installée. Les mettre en OpEx gonfle artificiellement la marge brute.
- Côté BFR, l'abonnement facturé d'avance produit des **produits constatés d'avance**, donc un BFR négatif générateur de trésorerie. C'est le seul cas où la variation de BFR améliore le cash quand l'activité croît. À modéliser par un délai d'encaissement négatif, ou par une ligne de produits constatés d'avance dédiée, et à signaler car c'est contre-intuitif.

Repères : marge brute 70 à 85 %, hébergement 2 à 5 % du revenu à l'échelle, support 100 à 600 clients par agent, masse salariale 40 à 70 % du CA en amorçage.

---

## 6. ACTIFS FINANCÉS (INFÉRÉE, à marquer comme à valider)

Non instanciée dans le corpus de référence. C'est la famille où l'arrêt à l'EBIT est le plus trompeur : l'essentiel de l'économie du modèle vit dans la D&A et dans les charges financières, c'est-à-dire sous l'EBITDA.

```
Volumes     Parc d'actifs en production  = ACQUISITION_MODEL!<parc actif>   (stock)
            Nouvelles mises en service   = ACQUISITION_MODEL!<poses du mois>  (flux)

Revenues    Revenu brut du parc          = D<parc> * ASSUMPTIONS!<revenu mensuel par actif>
            Moins taux de perte          = * (1 - taux par palier de taille de parc)
            Total revenues

COGS        Coûts récurrents par actif   = D<parc> * somme des coûts unitaires
                                           (assurance, suivi, maintenance, obligations
                                            administratives récurrentes)
            Commission de plateforme     = D<revenu> * taux, si un tiers intermédie
            Coût d'activation            = D<nouvelles mises en service> * coût unitaire
            Total COGS
```

Quatre exigences propres à cette famille :

- **D&A par millésime obligatoire.** Chaque vague d'actifs s'amortit sur sa propre fenêtre depuis sa date de mise en service. Le patron d'accumulation simple est inutilisable ici : il fausse tout le bas de compte.
- **Le bloc optionnel sous l'EBIT devient recommandé.** Sans charges financières, un modèle d'actifs financés présente une rentabilité qui n'existe pas. Le proposer systématiquement à l'utilisateur.
- **Le cashflow porte un vrai bloc financement** : tirages par vague d'acquisition, échéancier par vague, intérêts sur encours. Le remboursement de la dette d'un actif doit démarrer à sa mise en service, pas à une date globale.
- **Contrôle de viabilité de l'opérateur** : si l'actif est exploité par un tiers qui rembourse l'entreprise, le reste à vivre de cet opérateur doit être positif et crédible localement. C'est le premier contrôle du modèle : si l'opérateur ne gagne pas sa vie, le remboursement ne tient pas et tout le P&L est théorique. Cette vérification vit dans les assumptions ; le P&L doit y renvoyer en note.

Repères : taux de perte 1,5 à 5 % selon la taille du parc, capex sur CA 15 à 40 % en phase de déploiement, coût de la dette bancaire en zone UEMOA 8 à 12 % par an, ratio de couverture du service de la dette supérieur ou égal à 1,3.
