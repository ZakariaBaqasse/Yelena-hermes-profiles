# Standard de mise en forme — onglets P&L et Cashflow

Spec normative arbitrée à partir des quatre BP de référence, alignée sur les standards de bp-acquisition-tab et bp-assumptions-tab. Là où le corpus diverge (largeurs non uniformes, trois formats de pourcentage, deux familles de format comptable dans le même onglet), la spec tranche : la cohérence visuelle entre onglets et entre BP est ce qui rend un modèle auditable.

## 1. Ossature des onglets mensuels (`P&L_Monthly`, `Cashflow_Monthly`)

| Ligne | Contenu |
|---|---|
| 1-2 | Titre : `C1` = "BUSINESS PLAN" (gras 14, fond #DEEAF6), `C2` = nom de l'onglet (gras 16), encadré pointillé fin A1:C3 |
| 3 | vide (hauteur 27) |
| 4 | vide |
| 5 | Bandes d'année fusionnées : "Year 0" = C seule ; "Year 1" = D:O ; "Year 2" = P:AA ; "Year 3" = AB:AM. Fond navy #002060, texte blanc gras, centré |
| 6 | **Ligne-clé d'année** : "Year 0" en C, "Year 1" répété D:O, "Year 2" répété P:AA, "Year 3" répété AB:AM. Fond navy, texte blanc. VISIBLE, hauteur normale |
| 7 | Dates : lien vers l'onglet maître du calendrier tiré jusqu'à AM (mode chaîné) ou `=EDATE(préc;1)` depuis un pivot unique (mode autonome). Format `mmm-yy`, fond #D9E2F3, gras |

Attention à la ligne source du lien de dates : l'onglet produit par bp-acquisition-tab porte ses mois en **ligne 6**, celui produit par bp-assumptions-tab en **ligne 7**. Vérifier la ligne réelle avant de câbler. Brancher par erreur la ligne-clé d'année au lieu de la ligne de dates est silencieux à l'écran (les deux affichent quelque chose) et casse tous les `MATCH` de l'agrégation annuelle. Le `Cashflow_Monthly` lie ses dates à `P&L_Monthly` ligne 7, jamais à un onglet amont : une seule source de vérité calendaire par onglet aval.
| 8 | vide (ligne d'appui, filet supérieur pointillé) |
| 9+ | Contenu |

- **Volets figés** : `C9` (colonnes A:B et lignes 1 à 8 gelées). La colonne B porte les unités : elle doit rester visible au défilement, ce que deux modèles du corpus ratent.
- La ligne 6 est la signature technique : c'est elle, et elle seule, qui sert de critère aux `SUMIF` et aux `MATCH` de l'agrégation annuelle. Ne jamais la masquer (trois modèles du corpus la mettent à hauteur 0 alors qu'elle porte du calcul actif) et ne jamais la dupliquer.

## 2. Ossature des onglets annuels (`P&L_Yearly`, `Cashflow_Yearly`)

| Ligne | Contenu |
|---|---|
| 1-2 | Titre, identique aux mensuels |
| 3 | `A3` = "Months per exercise", `C3` = 12 (input bleu labellisé). Remplace les décalages 11 / 23 / 35 codés en dur du corpus |
| 5 | En-têtes d'exercice : `C5` = "Year 1", `D5` = "Year 2", `E5` = "Year 3". Fond navy, texte blanc gras. **Chaînes strictement identiques à la ligne-clé des onglets mensuels** : c'est le critère d'appariement |
| 6 | vide |
| 7+ | Contenu, structure miroir de l'onglet mensuel correspondant |
| pied | Lignes techniques : `BOY` (premier mois de l'exercice) et `EOY` (dernier mois de l'exercice), format `mmm-yy`, police grise italique. Reléguées en pied car techniques, mais jamais masquées |

Formules des lignes techniques, recopiables horizontalement sans littéral :

```
EOY = INDEX('P&L_Monthly'!$D$7:$AM$7, COLUMNS($C5:C5)*$C$3)
BOY = INDEX('P&L_Monthly'!$D$7:$AM$7, (COLUMNS($C5:C5)-1)*$C$3+1)
```

- **Volets figés** : `C7`.
- Colonnes F et suivantes : laissées vides et sans mise en forme. Ne jamais laisser de mise en forme résiduelle sur des colonnes ou des lignes vides (un modèle du corpus déclare une plage utilisée de 988 lignes pour 66 lignes de contenu).

## 3. Grille de colonnes (largeurs openpyxl)

| Onglet | Colonne | Largeur | Rôle |
|---|---|---|---|
| Mensuels | A | 38 | Libellés |
| Mensuels | B | 5 | Unité seule : `#` / `%` / `€` |
| Mensuels | C | 11 | Year 0 |
| Mensuels | D → AM | 9 (uniformes) | Timeline. **Jamais de largeur variable** : le corpus varie de 64 à 98 px sur un même axe, sans justification |
| Annuels | A | 40 | Libellés |
| Annuels | B | 5 | Unité |
| Annuels | C → E | 14 (uniformes) | Exercices |

Hauteurs de ligne : standard partout (ne pas fixer), sauf ligne 3 ≈ 27.

## 4. Grammaire visuelle

| Élément | Style |
|---|---|
| Section niveau 1 (Revenues, COGS, OpEx, Operating cash...) | Fond navy #002060, texte blanc gras, sur A:AM |
| Sous-section niveau 2 (détail par segment, par département) | Fond bleu clair #D9E2F3, texte noir gras |
| Bloc de rappel de volumes en tête de P&L | Fond #F3F3F3 sur les lignes de volume, pour le distinguer du corps du compte de résultat |
| Lien vers un autre onglet | Police verte #008000 — obligatoire, sans exception |
| Calcul local (opération entre lignes du même onglet) | Police noire #000000 |
| Input saisi (uniquement le bloc de financement et le solde initial) | Police bleue #0432FF |
| Ligne informative non consommée (ratio de contrôle) | Police grise italique #A5A5A5 |
| Totaux et paliers de marge | **Double filet épais** en haut de la ligne de total et en bas de la dernière ligne de détail. C'est la signature du corpus, présente dans les quatre modèles |
| Sous-totaux de département | Filet simple fin, même position |
| Ligne de contrôle affichant un écart | Mise en forme conditionnelle : fond rouge si différent de zéro |
| Solde de trésorerie | Mise en forme conditionnelle : fond rouge si négatif |
| Fonds jaune ou orange de surlignage de travail | Interdits |

## 5. Respiration (lignes vides)

Une ligne vide avant chaque bandeau de section, avant chaque ligne de total, et entre chaque sous-groupe logique. Deux lignes vides avant un changement de palier de marge. Jamais deux bandeaux collés, jamais un total collé à son détail sans le double filet.

Le rythme du corpus, à reproduire : `volumes | revenus | COGS | marge brute + % | autres coûts directs | CM + % | OpEx par département | EBITDA + % | D&A | EBIT + %`, chaque bloc séparé d'une ligne vide.

## 6. Formats de nombres

Un seul format par famille, sur l'ensemble des quatre onglets.

| Type | Format |
|---|---|
| Tous les montants et effectifs | `_ * #,##0_) ;_ * (#,##0)_ ;_ * "-"??_)_ ;_ @_ ` (comptable : zéros en `-`, négatifs entre parenthèses) |
| Ratios de marge | `0.0%` |
| Variations séquentielles (% mom, % yoy) | `0.0%` |
| Dates | `mmm-yy` |

Le corpus fait coexister trois formats de pourcentage pour des ratios de même nature et deux familles de format comptable dans un même onglet. Ne pas reproduire.

## 7. Règles de construction des formules

- **Une seule logique par ligne**, posée en colonne D puis recopiée jusqu'à AM. Aucune rupture aux charnières d'année.
- Verrouiller : ligne-clé en `X$6`, ligne de dates en `X$7`, scalaires amont en `$C$xx`, plages de lookup en absolu complet.
- Les liens vers l'amont utilisent la **même lettre de colonne** que la cellule qui les porte (grille unique) : `D19 = ='ASSUMPTIONS'!D13`. Toute formule où la lettre diffère signale un décalage à corriger.
- Syntaxe openpyxl : formules en chaînes `=...`, séparateur `,` (Excel localise à l'affichage). Les noms d'onglets contenant `&` doivent être quotés : `='P&L_Monthly'!D19`.

## 8. Implémentation openpyxl

Utiliser `scripts/xlsx_helpers.py` : constantes partagées avec les deux skills amont, plus `setup_sheet`, `write_timeline_monthly`, `write_timeline_yearly`, `section_header`, `subsection_header`, `write_row`, `margin_pair` (ligne € + ligne % appariées avec double filet), `sumif_flux`, `index_stock`, `control_row`, `conditional_negative`.
