---
id: Y0400
name: tresorerie-13-semaines
version: 1.0.0
description: "Construit et tient à jour le prévisionnel de trésorerie glissant sur treize semaines : ce qui entre, ce qui sort, ce qui reste, semaine après semaine, en séparant strictement le certain du probable et en distinguant compte bancaire, caisse espèces et mobile money — pour repérer le point bas avant d'y être, jamais en le découvrant dedans."
bucket: B
tags: [Finance, Trésorerie, Horizontal, Nouveau]
maj: 2026-09-03
---

# La trésorerie à 13 semaines — savoir si on passe le mois prochain

## Ce qu'il faut avoir sous la main
- **Les soldes actuels** de chaque compte : banque(s), caisse espèces, compte(s) mobile money — à la date d'aujourd'hui.
- **Les décaissements connus** des treize prochaines semaines : paie, loyers, échéances d'emprunt, fournisseurs déjà commandés, déclarations à payer si tu connais leur date.
- **Les encaissements attendus** : factures clients en cours avec leur échéance contractuelle, et si tu l'as, le délai réel auquel tel client paie d'habitude.
- **Les échéances irrégulières mais connues** sur la période : régularisation sociale, treizième mois, renouvellement de stock, dédouanement d'une commande import.
- **La dernière situation comptable ou bancaire** dont tu disposes, même partielle.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Cartographier les caisses avant de les consolider

Liste chaque poche de liquidité séparément : compte(s) bancaire(s), caisse en espèces, compte(s) de monnaie électronique. Note le solde d'ouverture de chacune à la date de référence, tel que constaté — relevé bancaire, comptage de caisse, solde de l'application mobile money — jamais estimé.

Le piège ici est de raisonner tout de suite en solde consolidé. Une trésorerie globale confortable ne renseigne rien sur la capacité à honorer un virement fournisseur lundi matin si l'essentiel dort sur un compte mobile money qu'on n'a pas prévu de vider, ou en espèces dans un tiroir. Le tableau garde les poches séparées jusqu'à la dernière ligne, où seulement elles se consolident.

### Étape 2 — Poser les décaissements certains

Place à leur date réelle tout ce qui sortira quoi qu'il arrive : paie (date de versement effective, pas fin de mois si le versement se fait autrement), loyers, échéances d'emprunt, commandes fermées chez un fournisseur, déclarations dont l'échéance est connue. Ce sont des faits, pas des prévisions — ils ne se discutent pas, ils se datent.

Vérifie une classe de décaissements qu'on oublie systématiquement parce qu'ils ne reviennent pas chaque semaine : régularisation de cotisations sociales, treizième mois, renouvellement d'un stock saisonnier, dédouanement d'une importation. Ce sont eux qui creusent les points bas les plus violents, précisément parce qu'ils n'apparaissent qu'une ou deux fois dans les treize semaines et qu'un tableau construit à la hâte les laisse de côté.

### Étape 3 — Poser les encaissements en distinguant certain et probable

Deux colonnes, jamais mélangées. **Certain** : commande déjà livrée et facturée à un client dont le comportement de paiement est connu et fiable, acompte déjà reçu, virement déjà initié. **Probable** : vente prévue mais pas encore réalisée, client dont le paiement dépend d'un aléa.

Le piège central de cette étape : prendre l'échéance contractuelle pour la date réelle. Une facture à trente jours chez un client qui paie systématiquement à soixante-quinze doit être positionnée à soixante-quinze — le comportement observé sur l'historique des règlements prime toujours sur la condition écrite. Si l'historique n'existe pas ou n'est pas fourni, la date contractuelle reste utilisée mais marquée `[hypothèse : délai contractuel, comportement réel non vérifié]` — jamais présentée comme acquise.

### Étape 4 — Construire le tableau semaine par semaine

Pour chaque semaine des treize : solde d'ouverture par poche, total des encaissements (certain + probable, en colonnes distinctes), total des décaissements par nature, solde de fin de semaine par poche, puis solde consolidé. Le solde d'ouverture d'une semaine est le solde de clôture de la précédente — la continuité du tableau est ce qui le rend fiable, une rupture non expliquée est un signal d'erreur de saisie à vérifier avant de continuer.

### Étape 5 — Identifier le point bas

Parcours les treize soldes consolidés et repère la semaine la plus basse — pas la plus proche, la plus basse, où qu'elle tombe dans la période. Signale-la explicitement avec son montant et sa date, et distingue si elle tient au probable (le risque disparaît si les encaissements attendus arrivent) ou au certain (le risque est acquis, il faut agir).

Si le point bas est négatif ou proche d'un seuil de sécurité, c'est le résultat central du livrable, pas une note en bas de tableau — il se dit en premier, avant le détail semaine par semaine.

### Étape 6 — Proposer les leviers, classés par délai d'effet

Face à un point bas serré, les leviers ne se valent pas dans le temps : relancer un client en retard peut jouer en quelques jours, négocier un délai fournisseur en une à deux semaines, décaler un investissement non engagé immédiatement, mobiliser une ligne de crédit ou un découvert prend plus longtemps à activer si elle n'existe pas déjà. Classe les leviers disponibles par rapidité d'effet réel, pas par ordre de préférence — et indique lequel doit être déclenché *avant* la semaine du point bas pour avoir le temps d'agir, pas pendant.

### Étape 7 — Mettre à jour, semaine après semaine

Le tableau construit une fois ne vaut rien : sa valeur vient de la comparaison entre ce qui était prévu et ce qui s'est produit. Chaque semaine, reporte le réel constaté (relevé, comptage de caisse, solde mobile money) à la place du prévisionnel, et calcule l'écart — en montant et en explication : un client qui a payé en avance, une dépense imprévue, une hypothèse fausse depuis le début. Cet écart, documenté semaine après semaine, est ce qui apprend à l'entreprise à mieux prévoir la fois suivante. Un fichier qu'on remplit une fois et qu'on referme n'a pas rendu service.

## Format de sortie
- **Livrable** : le tableau à treize semaines — soldes d'ouverture par poche (banque, caisse, mobile money), encaissements certains et probables ligne par ligne avec date attendue et origine, décaissements par nature, solde de fin de semaine par poche et consolidé — accompagné de l'identification du point bas, de la liste des hypothèses retenues avec leur origine, de l'écart prévu-réel de la semaine écoulée si une mise à jour est demandée, et des leviers classés par délai d'effet.
- **Structure** : answer-first — le point bas (semaine, montant, nature du risque) annoncé en tête, puis le tableau complet, puis les hypothèses et les leviers. Tableau en Markdown, une ligne par semaine et par poche ou consolidée selon la lisibilité demandée.
- **Longueur** : proportionnée — le tableau des treize semaines est le cœur, le commentaire reste bref et ciblé sur le point bas et les écarts.
- **Règle 0 invention** : aucun montant, aucune date d'échéance fiscale ou sociale, aucun taux n'est produit sans être fourni par l'utilisateur ou lu dans un document branché. Toute donnée manquante reste `⟦à renseigner⟧`.

## Règles
1. **Trésorerie et résultat ne se confondent jamais.** Le tableau raisonne en encaissements et décaissements à leur date réelle, jamais en produits et charges comptables. Une charge comptabilisée ce mois qui se paiera dans trois mois n'apparaît dans le tableau qu'à sa date de paiement réelle.
2. **Le comportement de paiement observé prime sur la condition contractuelle.** Un délai de paiement écrit sans historique de règlements vérifié est une hypothèse, pas un fait — elle est marquée comme telle.
3. **Certain et probable ne se mélangent jamais dans la même case.** La distinction est visible dans la structure du tableau (colonnes séparées), pas seulement mentionnée en commentaire.
4. **Les poches de liquidité restent séparées jusqu'à la consolidation finale.** Un solde consolidé confortable ne dispense pas de vérifier que chaque poche, prise seule, peut honorer ses échéances à leur date.
5. **Les décaissements irréguliers mais massifs sont recherchés activement**, pas seulement reportés s'ils sont mentionnés par l'utilisateur : fiscalité, cotisations sociales, treizième mois, saisonnalité de stock, dédouanement. S'ils ne sont pas connus, la question est posée explicitement plutôt que supposée absente.
6. **Le point bas se dit en premier et sans l'adoucir.** Un tableau qui enterre le point bas dans le détail des cinquante lignes n'a pas rempli sa fonction.
7. **0 chiffre inventé.** Aucun solde, aucune date d'échéance, aucun montant de paie, de loyer, de cotisation ou d'impôt n'est produit sans être fourni ou lu dans un document réel : `⟦à renseigner⟧` sinon — y compris pour des montants qui « semblent » plausibles au vu du secteur.
8. **La mise à jour hebdomadaire fait partie du livrable, pas une option.** Chaque restitution rappelle que la valeur de l'outil dépend de son actualisation, et l'écart prévu-réel est traité comme une information, pas comme une erreur à cacher.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; relancer un client, initier un virement, négocier un délai fournisseur ou mobiliser une ligne de crédit est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis le tableau avec ce que tu as, en étiquetant les hypothèses (`[hypothèse : …]`) et en marquant les cases manquantes `⟦à renseigner⟧`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement (les soldes d'ouverture, notamment, ne se devinent jamais).
- **Aucun historique de comportement de paiement client** — tu utilises le délai contractuel en le marquant explicitement comme non vérifié, et tu signales que c'est le premier point à documenter pour fiabiliser le tableau suivant.
- **Soldes annoncés mais non fournis** (« je t'envoie le relevé », rien n'est joint) — tu le signales avant de continuer et tu ne poses pas de solde d'ouverture par supposition.
- **Décaissement irrégulier non mentionné par l'utilisateur** — tu poses la question explicitement (fiscalité, social, saisonnalité, import) plutôt que de supposer qu'il n'y en a pas sur la période.
- **Plusieurs poches non consolidées par l'entreprise elle-même** (le dirigeant ne sait pas ce qu'il y a en mobile money) — tu le signales comme un angle mort du pilotage, pas comme une simple case vide.
- **Point bas déjà négatif dans les données fournies** — tu le dis en premier, sans reformuler pour adoucir, et tu passes directement aux leviers.
- **Mise à jour hebdomadaire demandée sans tableau précédent fourni** — tu signales qu'il n'y a rien à comparer et tu proposes de reconstruire depuis le début plutôt que d'inventer un écart.
- **Demande hors périmètre** (calcul de rentabilité, structuration d'un prêt, plan d'affaires complet) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoyer une relance, initier un virement, contacter une banque) — tu prépares l'élément et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (solde bancaire fourni différent du dernier relevé lu) — tu exposes les deux valeurs et tu demandes l'arbitrage plutôt que de trancher seul.
