---
name: "reconciliation-mobile-money"
version: 1.0.0
description: "Réconcilie mobile money (Orange, MTN, Moov, Wave) — avec discipline d'audit : mise en attente, non-suppression, double revue, pack de preuves."
bucket: A
tags: [Finance]
maj: 2026-09-03
---

# Reconciliation Mobile Money


**Ce qu'elle suppose comme accès** : Génération de visuel interactif (Frame), Lecture de documents (OCR/PDF), Export mobile money. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. **Mettre en zone tampon.** Chaque relevé importé (par opérateur, par période) est d'abord enregistré avec sa source, son horodatage de récupération et son empreinte de fichier — avant toute réconciliation. Un réimport à l'identique (même empreinte) est signalé comme doublon et n'est pas retraité. Un relevé corrigé après coup ne remplace jamais silencieusement l'ancien : le nouvel import est marqué comme remplaçant, l'ancien reste consultable avec la raison du remplacement.
2. Normaliser les relevés hétérogènes vers un schéma commun : date · référence · montant brut · frais · montant net · opérateur · sens (entrée/sortie) · statut · contrepartie.
3. Vérifier ou calculer les frais par opérateur et le montant net attendu.
4. **Rapprocher relevés opérateurs ↔ ventes internes**, par correspondance croissante : d'abord une correspondance exacte (montant, référence, date), puis montant + fenêtre de date si la référence manque, puis contrepartie avec tolérance explicite, puis correspondance multi-lignes (un règlement qui couvre plusieurs ventes, ou l'inverse) — chaque niveau documenté, jamais deviné en silence.
5. Détecter les anomalies : transaction manquante, doublon, frais anormal, montant divergent, settlement non reçu, statut en attente ou en échec, contrepartie suspecte, règlement net à la fois des frais ET d'un mouvement de float (à séparer explicitement, jamais fusionner les deux effets).
6. Produire le journal de caisse consolidé et la liste des écarts à traiter — **en attente de validation**, jamais posté directement.
7. **Double regard avant définitif.** Toute écriture proposée par la réconciliation (frais, écart résolu, anomalie corrigée) reste à l'état préparé jusqu'à ce qu'une seconde personne (autre que celle qui a produit la réconciliation) vérifie et valide.
8. **Pack de preuves de clôture** : le journal de caisse, la liste des anomalies avec leur résolution, les empreintes des relevés importés, et l'identité du préparateur et du validateur.

## Format de sortie

Termine TOUJOURS ta réponse par un **Frame interactif** (visualisation / interactive content) qui présente le livrable de façon soignée et lisible — aux couleurs du brand kit si fourni, sinon une palette neutre et pro. Le message texte reste un court wrapper ; le livrable vit dans le Frame. Si la génération de visualisation n'est pas disponible, produis à défaut un livrable structuré prêt à l'emploi (ne bloque jamais là-dessus).

Le livrable inclut systématiquement : le tableau consolidé, le total net encaissé par opérateur, la liste des anomalies priorisées, la table de correspondance retenue par niveau (exact / montant+date / tiers+tolérance / multi-lignes), et le pack de preuves de clôture (empreintes des imports, préparateur, validateur — même si le validateur reste `⟦à désigner⟧` faute d'un second regard disponible).

## Règles

Explicite toute hypothèse (barème, taux de change s'il y a lieu). Ne « corrige » pas silencieusement une donnée : signale l'écart.

**Discipline d'audit — non négociable :**
- **Aucun import n'est modifié ou effacé après coup.** Une correction du relevé source produit un nouvel import qui remplace proprement l'ancien (marqué comme tel), jamais un écrasement silencieux.
- **Aucune écriture proposée par la réconciliation ne devient définitive sur la seule main de qui l'a produite.** Elle reste "préparée" jusqu'à validation par un second regard.
- **Toute clôture produit son pack de preuves**, même minimal : sans lui, une réconciliation « faite » ne se distingue pas d'une réconciliation qu'on ne pourrait pas justifier plus tard.

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle — une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite. Et toute écriture reste "préparée", jamais définitive, tant qu'un second regard ne l'a pas validée.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Réimport d'un relevé déjà traité, à l'identique** — tu le signales comme doublon d'import (même empreinte) et tu ne le retraites pas.
- **Relevé source corrigé après un premier import** — tu ne modifies jamais l'import initial ; tu en crées un nouveau marqué comme remplaçant, et l'ancien reste consultable.
- **Pas de second regard disponible pour valider une écriture** — tu le signales explicitement : le journal reste préparé, non définitif, en attente d'un validateur `⟦à désigner⟧`.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

## Périmètre
Opérateurs mobile money de Côte d'Ivoire : Orange Money, MTN MoMo, Moov Money, Wave. Chaque opérateur a ses formats de relevé et ses barèmes de frais distincts.

## Taxonomie de correspondance (par ordre d'application)
1. **Exacte** : montant + référence + date (± 1 jour) identiques entre relevé et ventes internes.
2. **Montant + fenêtre de date** : même montant, référence absente sur le relevé, date proche.
3. **Contrepartie + tolérance** : même client/contrepartie identifiée, montant proche dans une tolérance explicite (jamais silencieuse) — utile face à des frais prélevés en cours de route.
4. **Multi-lignes** : un règlement de l'opérateur qui couvre plusieurs ventes internes, ou une vente réglée en plusieurs mouvements côté opérateur — à documenter explicitement, jamais deviner.

## Sortie
Un tableau consolidé, le total net encaissé par opérateur, la liste des anomalies priorisées, la table de correspondance retenue par niveau, et le pack de preuves de clôture (empreintes d'import, préparateur, validateur).

## Traçabilité de cette version
Discipline d'audit (mise en attente, non-suppression/supersede, double revue, pack de preuves, taxonomie de correspondance enrichie) ajoutée le 17/08/2026, inspirée d'un skill public de référence (`chwezi-accounting-doctrine`, GitHub, consulté ce jour) conçu à l'origine pour un contexte ougandais (UGX, MTN MoMo/Airtel) — adaptée ici sans emprunter de chiffre ni de nom d'entité de ce dépôt, seulement les principes de contrôle.
