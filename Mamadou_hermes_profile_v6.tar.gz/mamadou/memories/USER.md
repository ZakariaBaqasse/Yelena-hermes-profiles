# USER.md — Routeur multi-entreprise

_Ce fichier n'est plus la fiche d'une entreprise : il est le routeur. Il l'est devenu le
14/08/2026, sur demande explicite (l'équipe T.) : ce canal doit pouvoir recevoir n'importe quelle
entreprise du portefeuille, chacune avec son propre cadrage, sans qu'aucune donnée d'une
entreprise n'apparaisse dans le contexte d'une autre._

## La règle de résolution — à appliquer avant tout travail entreprise-spécifique

Profil complet (membres, préférences, historique) : carnet interlocuteurs.md de la compétence carnets-de-memoire.
