---
id: Y0433
name: mesure-de-satisfaction-sans-outil
description: "Construit un dispositif de mesure de la satisfaction client pour une entreprise sans plateforme d'enquête, sans volume statistique et sans budget : question posée au bon moment sur le bon canal, dépouillement qualitatif honnête, exploitation des signaux gratuits déjà disponibles (réclamations, non-retours, remarques au comptoir), note de lecture qui dit ce qu'elle sait et ce qu'elle ignore, sans jamais produire un score sur un effectif trop faible ni inventer une norme de marché."
bucket: B
tags: [Support, Mesure, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Savoir si les clients sont contents quand on n'a aucun outil pour le mesurer

## Ce qu'il faut avoir sous la main
- **Ce que tu vends** et **le moment de l'expérience** que tu veux évaluer (la livraison, l'accueil en boutique, l'après-vente, une commande précise).
- **Combien de clients** tu touches sur une période (une dizaine par semaine, une centaine par mois) : ça détermine ce qu'on a le droit de calculer.
- **Comment tu joins tes clients aujourd'hui** : WhatsApp, appel, SMS, face-à-face au comptoir, réseau social.
- **Ce que tu as déjà comme signaux**, même informels : réclamations reçues, clients qui ne reviennent plus, remarques entendues au comptoir, avis laissés en ligne.
- **Qui, chez toi, lira les réponses** et pourra en faire quelque chose.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1, Cadrer ce qu'on veut vraiment savoir

Avant de choisir un outil, pose la question de fond : qu'est-ce que cette entreprise a besoin de savoir pour agir ? Pas « sont-ils satisfaits » en général, mais un moment précis de l'expérience où quelque chose peut se jouer : la livraison arrive-t-elle dans le délai annoncé, l'accueil en boutique donne-t-il envie de revenir, le service après-vente répond-il vraiment.

Le piège de départ : mesurer parce qu'il faut mesurer, sans savoir quelle décision la réponse va éclairer. Si personne ne peut dire ce qu'on ferait d'un résultat mauvais, ce n'est pas encore la bonne question. Tu la reformules avec l'entreprise jusqu'à ce qu'elle pointe vers une action possible.

### Étape 2, Choisir le moment et le canal, pas l'inverse

Le moment se fixe par rapport à l'expérience, pas par rapport à la commodité de l'entreprise : le plus près possible de l'instant vécu, tant que le souvenir est encore l'expérience et pas un résumé reconstruit. Une question posée un mois après ne mesure plus ce qui s'est passé, elle mesure ce que le client a bien voulu retenir.

Le canal se choisit par rapport à où le client est déjà, pas par rapport à ce que l'entreprise préfère gérer. Si les clients échangent par WhatsApp pour commander, la question de satisfaction passe par WhatsApp, pas par un lien vers un formulaire qui consomme des données sur un téléphone d'entrée de gamme et que personne n'ouvrira. Un appel vocal court fonctionne souvent mieux qu'un message écrit pour un client peu à l'aise avec la lecture ou pressé. Une remarque recueillie au comptoir au moment du paiement vaut une enquête entière si elle est notée.

Signale explicitement quand le canal envisagé ne correspond pas à l'usage réel du client cible : c'est le piège qui rend un dispositif entier inutile sans que personne s'en aperçoive avant des mois.

### Étape 3, Formuler la question

Une question ouverte, en langage simple, qui porte sur le moment précis identifié à l'étape 1 : « qu'est-ce qui t'a marqué, en bien ou en mal, dans [le moment] ? » plutôt qu'une échelle abstraite que le client remplit sans réfléchir. Une échelle numérique peut s'ajouter en complément, jamais seule : le chiffre sans le mot qui l'explique ne dit rien de ce qu'il faut changer.

Écarte les questions qui suggèrent la bonne réponse (« tu as apprécié notre service rapide, n'est-ce pas ? ») : elles produisent de la satisfaction déclarée, pas de l'information.

### Étape 4, Recueillir en connaissant le biais de qui répond

Les clients qui prennent la peine de répondre spontanément sont surreprésentés aux deux extrêmes : les très contents et les très mécontents. Le silence de la majorité n'est pas de la neutralité, c'est une absence de donnée. Une lecture qui traite les réponses reçues comme représentatives de l'ensemble de la clientèle conclut à une polarisation du marché alors qu'elle observe une polarisation du questionnaire.

Deux réponses possibles, à choisir selon les moyens réels : solliciter activement un échantillon plus large plutôt que d'attendre les volontaires, ou accepter la limite et l'écrire noir sur blanc dans la note de lecture. Ce qui n'est pas acceptable : présenter les réponses spontanées comme si elles racontaient tout le monde.

### Étape 5, Dépouiller sans fabriquer de faux chiffres

Construis une grille de thèmes à partir des réponses réellement reçues (pas une liste de thèmes plaquée à l'avance) : classe chaque réponse dans un ou plusieurs thèmes, compte les occurrences, et affiche **toujours le dénominateur** à côté du compte (« 6 clients sur 14 mentionnent un délai trop long », jamais « 43 % des clients »). Un pourcentage sur un petit effectif donne une fausse impression de précision qu'aucune donnée réelle ne soutient.

Retiens deux ou trois verbatims réels par thème, cités tels quels : ils portent une information que le comptage ne porte pas, et ils permettent à qui lit la note de juger par lui-même plutôt que de faire confiance à ton classement.

**Aucun score global n'est produit si l'effectif ne le supporte pas.** Il n'y a pas de seuil universel en dessous duquel un score devient absurde, mais le principe est constant : un score qui bouge de dix points parce que deux clients ont changé d'avis n'est pas un score, c'est du bruit habillé en indicateur, et il sera pourtant commenté en réunion comme une tendance si tu le publies. Tu le dis explicitement plutôt que de le produire avec une réserve illisible en bas de page. Le seuil d'effectif à partir duquel un score redevient lisible est une décision de l'équipe, marquée `⟦à renseigner⟧`.

### Étape 6, Croiser avec les signaux déjà disponibles, gratuitement

Avant de conclure sur les seules réponses à la question posée, rassemble ce qui existe déjà sans coût : les réclamations reçues (par WhatsApp, par téléphone, au comptoir), les clients qui commandaient régulièrement et qui ont arrêté sans le dire, les remarques informelles notées par le personnel en contact direct, les avis publiés spontanément en ligne. Ces signaux ne remplacent pas la mesure directe, ils la confirment ou la contredisent, et une contradiction est elle-même une information : si les réponses déclarées sont bonnes mais que les clients réguliers disparaissent en silence, c'est le silence qu'il faut croire en premier.

### Étape 7, Écrire la note de lecture, et dire ce qu'on va faire des réponses

La note distingue ce que les réponses **permettent d'affirmer**, ce qu'elles **suggèrent sans le prouver**, et ce sur quoi elles **ne disent rien** (effectif trop faible, canal qui exclut une partie de la clientèle, biais des répondants). La seule comparaison légitime est celle de l'entreprise avec elle-même sur deux périodes successives, avec la même question, le même canal, un moment comparable : jamais avec une moyenne sectorielle ou un score de référence supposé, qu'aucune source vérifiée ne fournit ici.

Termine par deux ou trois actions concrètes, et surtout : ce que l'entreprise va faire de ces réponses, et **qui** les lira. Interroger un client et ne rien changer coûte plus cher en crédibilité que ne pas l'interroger du tout : le client qui a pris le temps de répondre et qui revit le même problème la fois suivante ne répondra plus.

## Format de sortie
- **Livrable** : trois pièces liées, jamais une seule. (1) Le dispositif : la question, son moment, son canal, sa cible, ce qui en sera fait et qui la lira. (2) La grille de dépouillement : thèmes, règle de classement, comptage avec dénominateur toujours visible, verbatims retenus. (3) La note de lecture : ce que les réponses disent, ce qu'elles ne permettent pas de dire, les signaux gratuits déjà disponibles et ce qu'ils confirment ou contredisent, deux à trois actions proposées.
- **Structure** : Markdown clair, answer-first (ce qu'on sait, tout de suite, puis le détail) ; tableaux pour la grille de dépouillement.
- **Longueur** : proportionnée à la taille réelle de l'entreprise, sans remplissage. Pour une petite structure, l'ensemble tient sur une à deux pages.
- **Aucun score ni pourcentage** n'est produit sur un effectif que l'équipe n'a pas validé comme suffisant. Le seuil à partir duquel un chiffre agrégé redevient lisible est un `⟦à renseigner⟧`, jamais une valeur que tu choisis.
- **Règle 0 invention** : aucune norme de marché, aucune moyenne sectorielle, aucun seuil de bon ou mauvais score n'est cité sans être fourni et sourcé par l'utilisateur. Sinon : `⟦à renseigner⟧` ou « à confirmer ».

## Règles
1. **Pas de score sur un effectif trop faible.** Tu le dis explicitement plutôt que de le calculer avec une réserve en petits caractères. Un chiffre qui bouge de dix points au gré de deux réponses n'est pas un indicateur.
2. **Le dénominateur est toujours visible** à côté de tout comptage. « 6 sur 14 » informe, « 43 % » sur ce même effectif trompe.
3. **Aucune norme de marché n'est inventée.** Pas de moyenne sectorielle, pas de seuil de bon score, pas de comparatif avec un concurrent supposé. La seule comparaison légitime est l'entreprise avec elle-même dans le temps.
4. **Le biais de qui répond est nommé à chaque lecture.** Les réponses spontanées surreprésentent les extrêmes ; tu ne les présentes jamais comme représentatives de l'ensemble de la clientèle sans le dire.
5. **Le canal et le moment se choisissent par rapport au client, jamais par rapport à la commodité de l'entreprise.** Un dispositif conçu pour un client hyperconnecté ne se transpose pas tel quel à une clientèle qui échange par appel vocal ou au comptoir.
6. **Le verbatim n'est jamais transformé en pourcentage caché.** On classe par thème, on compte les occurrences avec leur dénominateur, on cite les phrases réelles ; on ne fait pas comme si compter des mots produisait une statistique.
7. **Chaque dispositif porte ce qu'on fera des réponses et qui les lira.** Une mesure sans suite attachée n'est pas livrée seule : tu la signales comme incomplète.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer le questionnaire, contacter des clients ou publier un résultat est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Effectif très faible (moins d'une dizaine de réponses)** : tu produis quand même le dispositif et la lecture qualitative, mais tu refuses tout comptage agrégé et tu le dis en une phrase claire, pas en note de bas de page.
- **Aucun signal disponible en dehors de la question posée** : tu le signales, tu travailles sur cette seule source, et tu proposes ce qu'il faudrait commencer à noter (cahier de réclamations, suivi des clients qui ne reviennent pas) pour la prochaine mesure.
- **Le client n'a pas de canal numérique fiable** (pas de WhatsApp Business, connexion irrégulière) : tu conçois le dispositif autour de l'oral, appel ou comptoir, et tu le dis explicitement plutôt que de proposer un outil que personne n'utilisera.
- **L'entreprise a déjà un score qu'elle utilise depuis longtemps** (calculé sur une méthode qu'elle n'a pas construite avec toi) : tu ne le rejettes pas d'office, tu vérifies l'effectif et le canal qui l'ont produit, et tu signales s'il n'est pas fiable plutôt que de l'entériner par confort.
- **Réponses contradictoires entre le déclaratif et les signaux gratuits** (satisfaction déclarée bonne, clients réguliers qui disparaissent) : tu exposes les deux et tu donnes la priorité au signal comportemental dans la lecture, en le disant.
- **Demande d'un score comparable à une moyenne sectorielle** : tu expliques qu'aucune norme fiable n'est disponible ici, tu proposes la comparaison dans le temps comme alternative, et tu ne fabriques jamais un repère.
- **Action sortante demandée** (envoyer le questionnaire, publier un résultat, relancer des clients) : tu prépares le dispositif et tu t'arrêtes pour validation humaine.
- **Pièce annoncée mais absente** (« voici les réclamations du mois », rien n'est joint) : tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
