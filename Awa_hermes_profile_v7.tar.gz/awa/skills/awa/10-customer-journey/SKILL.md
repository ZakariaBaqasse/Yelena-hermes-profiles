---
id: Y0049
name: 10-customer-journey
description: "Génère un Service Blueprint (parcours client détaillé, avant/après, gains de temps quantifiés) pour une startup à partir de ses personas, de sa synthèse Customer Discovery, de son cas d'usage principal et de son prototype produit : structure le parcours en 3 à 5 étapes documentées sur 6 dimensions (temps, evidence, parcours client, technologie, acteurs, valeur), avec une règle de format stricte, la comparaison avant/après n'existe QUE sur la dimension temps, jamais sur les autres, et sans inventer une durée, un insight ou une fonctionnalité absents des inputs fournis."
bucket: C
tags: [Design]
version: 1
maj: 2026-08-26
---

# 10-Customer Journey : Service Blueprint

## Ce qu'il faut avoir sous la main
- Les **personas** (persona principal ciblé pour le cas d'usage)
- La **synthèse Customer Discovery** (insights clés, pain points, touchpoints)
- Le **cas d'usage principal** à mapper (le parcours récurrent que tu veux documenter)
- Le **prototype** (lien Figma ou captures d'écran des interfaces clés)
- Le **nom de la startup**

Si une partie de ces éléments a déjà été partagée plus tôt dans la conversation, dis-le-moi, je réutilise ce qui est disponible et ne demande que ce qui manque. Dès que j'ai tout, je produis directement le Service Blueprint.


**Ce qu'elle suppose comme accès** : Générateur de rapport/tableau visuel. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
Avant toute interaction, vérifie la présence de ces 5 éléments dans la conversation :
- Personas (persona principal identifié)
- Synthèse Customer Discovery
- Cas d'usage principal à mapper
- Prototype (lien Figma ou captures d'écran)
- Nom de la startup

- **Tout est présent** → confirme brièvement ce que tu as identifié et enchaîne directement sur l'Étape 2.
- **Partiellement présent** → confirme ce qui est déjà là, demande uniquement ce qui manque.
- **Rien n'est présent** → affiche le message d'accueil (bloc Démarrage ci-dessus) et attends.

### Étape 2 : Rechercher des formats de référence

Avant de générer, consulte `[datasource à brancher : bibliothèque des Service Blueprints / Customer Journeys déjà produits par le studio, sert uniquement de référence de STRUCTURE (colonnes = étapes, lignes = dimensions, format des durées, types d'acteurs par secteur), jamais de contenu à copier]`.

Ce que tu regardes dans les exemples :
- Structure générale (colonnes = étapes, lignes = dimensions)
- Format des durées pour TIME (« 2 MIN », « 30 SEC », « PLUSIEURS SEMAINES », « 15 JRS »)
- Types d'acteurs selon le secteur (ex. GÉRANT, FIELD AGENT, MERCHANT)
- Niveau de détail et ton du contenu

⚠️ Ce que tu ignores : le format BEFORE/WITH utilisé dans les exemples en dehors de TIME, ne le reproduis jamais, même s'il apparaît dans un exemple de référence (cf. règle critique ci-dessus). Ne recopie jamais non plus les durées, acteurs ou évidences d'un exemple dans le blueprint en cours : les exemples informent la forme, pas le fond.

### Étape 3 : Analyser et synthétiser

Extraction silencieuse à partir des éléments fournis :
- **Personas** → identifie le persona principal pour ce cas d'usage
- **Synthèse discovery** → extrait insights clés, pain points, touchpoints
- **Cas d'usage** → comprend le scénario à mapper
- **Prototype/captures** → identifie les 3 à 5 écrans/étapes principales du parcours

Inférence intelligente si un élément est manquant :
- Durées BEFORE (TIME uniquement) → reconstruites à partir des pain points de la synthèse discovery
- Durées WITH (TIME uniquement) → estimées à partir de la nouvelle solution
- Nouvelle solution (toutes les autres dimensions) → déduite des fonctionnalités visibles (prototype) et de la value proposition
- Acteurs → identifiés à partir du contexte secteur + personas
- Secteur d'activité → déduit du nom de la startup + description des personas

**Règle d'or** : privilégie l'inférence intelligente aux questions. Si, et seulement si, un élément est **impossible** à déduire et **bloquant** pour la génération, pose UNE question ciblée unique ; sinon génère avec les meilleures hypothèses et laisse l'utilisateur affiner après coup.

Signale toujours en fin de blueprint les hypothèses posées par inférence (jamais présentées comme des données confirmées).

### Étape 4 : Générer le Service Blueprint

Structure le parcours en 3 à 5 étapes cohérentes et remplis chaque dimension selon le format strict :

| Dimension | Format |
|---|---|
| ⏱️ TIME | `**BEFORE:** [durée]` puis `**WITH:** [durée]`, quantifié, jamais « rapide »/« lent » |
| 📱 EVIDENCE | Description directe de la nouvelle solution (apps, interfaces, documents, équipements) |
| 👤 CUSTOMER JOURNEY | Actions concrètes du client avec la nouvelle solution |
| ⚙️ TECHNOLOGY | Stack technique de la nouvelle solution |
| 👥 [ACTEUR CONTEXTUEL] | Actions de l'acteur avec la nouvelle solution, rôle adapté au secteur (voir ci-dessous) |
| 💎 VALUE PROPOSITION | Valeur concrète apportée par la nouvelle solution, par étape |

Acteurs contextuels typiques par secteur (à adapter, pas une liste fermée) :
- Fintech/B2B : MERCHANT, CUSTOMER, AGENT, ACCOUNTANT
- Agritech/IoT : FIELD AGENT, FARMER, TECHNICAL TEAM
- Retail : GÉRANT, CAISSIÈRE, SERVEUR, CUSTOMER
- SaaS : USER, ADMIN, SUPPORT TEAM, MANAGER

Puis :
- Quantifie la transformation globale : temps économisé (comparaison TIME BEFORE vs WITH), process simplifiés, nouvelles capacités, ROI estimé si applicable
- Énonce 3 recommandations actionnables

## Format de sortie
Livre le Service Blueprint sous cette forme :

```json
{
  "startup": "...",
  "persona_principal": "...",
  "cas_usage": "...",
  "parcours": {
    "etapes": ["Étape 1: ...", "Étape 2: ...", "Étape 3: ..."],
    "dimensions": {
      "time": [{"etape": "...", "before": "...", "with": "..."}],
      "evidence": [{"etape": "...", "description": "..."}],
      "customer_journey": [{"etape": "...", "description": "..."}],
      "technology": [{"etape": "...", "description": "..."}],
      "acteur": {"nom": "...", "par_etape": [{"etape": "...", "description": "..."}]},
      "value_proposition": [{"etape": "...", "description": "..."}]
    }
  },
  "transformation_quantifiee": {
    "temps_economise": "...",
    "process_simplifies": "...",
    "nouvelles_capacites": "...",
    "roi_estime": "..."
  },
  "recommandations": ["...", "...", "..."],
  "hypotheses_inference": ["élément déduit et sur quelle base"]
}
```

Si un outil de mise en forme visuelle est disponible, rends aussi le blueprint sous forme de tableau brandé (colonnes = étapes, lignes = dimensions) via `[connecteur à brancher : générateur de rapport/tableau visuel, mise en forme du Service Blueprint en tableau brandé pour la startup]`. Sinon, livre le tableau au format Markdown équivalent au JSON ci-dessus, jamais uniquement le JSON brut sans lecture humaine possible.

## Règles
Le format `**BEFORE:** [valeur]` / `**WITH:** [valeur]` est **exclusivement réservé à la dimension TIME**. Il est **interdit** pour toutes les autres dimensions (EVIDENCE, CUSTOMER JOURNEY, TECHNOLOGY, [ACTEUR], VALUE PROPOSITION) : elles décrivent **uniquement la nouvelle solution**, sans jamais comparer à l'avant.

❌ **Interdit** (hors TIME) :
- EVIDENCE : « **BEFORE:** Cahier papier **WITH:** Application mobile »
- CUSTOMER JOURNEY : « **BEFORE:** Remplir manuellement **WITH:** Scanner automatiquement »

✅ **Attendu** (hors TIME) :
- EVIDENCE : « Application mobile avec scan automatique »
- CUSTOMER JOURNEY : « Ouvre l'app, scanne le document, valide en un clic »

✅ **Seule exception, TIME** :
- « **BEFORE:** 15 MIN **WITH:** 2 MIN »

C'est la source d'erreur la plus fréquente sur cette skill, revérifie-la explicitement avant de livrer (voir Checklist en bas).

- **Progression logique** entre les étapes du parcours.
- **Alignement strict** avec les personas et les insights de la synthèse discovery fournis, jamais de persona, de pain point ou de touchpoint inventé.
- **Zéro invention** : si un élément est bloquant et non déductible, pose la question plutôt que d'inventer une valeur plausible ; si une hypothèse est posée par inférence, elle est signalée comme telle dans la sortie.
- **Quantification obligatoire** sur TIME uniquement (jamais « rapide », « lent », « quelques minutes » sans chiffre).
- **Une génération directe, pas de validation intermédiaire bloquante** : livre le blueprint complet, l'utilisateur demande des ajustements après coup s'il en a besoin.
- **Cloisonnement entre startups** : ne jamais réutiliser les personas, pain points, acteurs ou durées d'une startup déjà traitée dans la conversation pour construire le blueprint d'une autre, chaque blueprint repose uniquement sur les inputs propres à sa startup.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.
- **0 invention.** Aucune donnée chiffrée, date, nom ou référence fabriquée. Une information que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Checklist de validation avant de livrer

Avant de livrer, vérifie ligne par ligne :
- [ ] Dimension TIME : contient BEFORE/WITH avec durées quantifiées
- [ ] Dimension EVIDENCE : description directe, SANS BEFORE/WITH
- [ ] Dimension CUSTOMER JOURNEY : description directe, SANS BEFORE/WITH
- [ ] Dimension TECHNOLOGY : description directe, SANS BEFORE/WITH
- [ ] Dimension ACTEUR : description directe, SANS BEFORE/WITH
- [ ] Dimension VALUE PROPOSITION : description directe, SANS BEFORE/WITH
- [ ] 3 à 5 étapes identifiées avec noms explicites
- [ ] Acteur contextuel identifié et cohérent avec le secteur
- [ ] Evidence concrète de la nouvelle solution à chaque étape
- [ ] Gains temporels quantifiés (comparaison TIME BEFORE vs WITH)
- [ ] 3 recommandations actionnables
- [ ] Hypothèses posées par inférence signalées comme telles, pas comme des faits confirmés
