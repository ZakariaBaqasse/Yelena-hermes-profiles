---
id: Y0183
name: kpi-weekly
description: "Reporting KPI hebdomadaire pour le portefeuille de l'entreprise : consolide les métriques de la semaine, calcule les variations N vs N-1, génère un tableau de bord interactif brandé et envoie (après validation) un rapport email aux fondateurs avec CSV joint. Règle absolue : aucun chiffre inventé ou estimé."
bucket: C
tags: [Data & Analytics, Ops]
version: 1
maj: 2026-08-10
---

# KPI Weekly — Reporting KPI hebdomadaire portfolio de l'entreprise

## Ce qu'il faut avoir sous la main
- Le **nom de la startup** (pour charger sa mémoire + localiser son tableau KPIs)
- *(optionnel)* les **KPIs à suivre**, la **semaine de référence**, les **destinataires** du rapport
- *(optionnel)* le **logo / les couleurs** si tu veux un branding précis


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un brief ou un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant clairement tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.


**Ce qu'elle suppose comme accès** : Mémoire startup, État par startup, Tableau KPIs de la startup, Registre / playbook des startups, Tableur (lecture), Stockage documentaire (lecture), Recherche web, Rendu du tableau de bord + export CSV. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
### Étape 1 — Charger le contexte de la startup
Ses indicateurs suivis, son tableau de KPI, sa charte. Un rapport avec les mauvais indicateurs ne sera pas lu deux fois.

### Étape 2 — Consolider la semaine
Relève les valeurs de la semaine de référence. Un indicateur non renseigné reste vide et signalé — jamais reporté de la semaine précédente.

### Étape 3 — Calculer les variations
Écart avec la semaine précédente, en valeur et en pourcentage, avec la base de calcul. Une variation sur un tout petit volume est marquée comme non significative.

### Étape 4 — Faire valider les indicateurs
Affiche la liste retenue et les valeurs avant de produire, et demande confirmation. C'est le seul moyen d'éviter un rapport faux diffusé aux fondateurs.

### Étape 5 — Produire et préparer la diffusion
Tableau de bord brandé, email aux fondateurs et archive — l'envoi attend le feu vert.

## Format de sortie
**Étape 1 — Validation des KPIs.** Avant de générer le tableau de bord, affiche la liste des KPIs sélectionnés avec leurs valeurs pour la semaine en cours et la variation vs semaine précédente. Demande validation : **« Voici les KPIs identifiés pour [Startup] — Semaine du [date] : [liste]. Les données sont-elles correctes ? Souhaitez-vous ajouter d'autres KPIs avant de générer le tableau de bord ? »** Attends la confirmation de l'utilisateur — et l'ajout éventuel de KPIs supplémentaires — avant de continuer. Ne jamais générer le tableau de bord avant validation explicite.

**Étape 2 — Branding.** Une fois les KPIs validés, identifie les couleurs de la startup en suivant cet ordre de priorité :

1. Recherche l'URL du site internet de la startup dans le `[datasource à brancher : registre/playbook des startups]` ou Google Drive. Si trouvé, visite le site avec l'outil **Web Search** et identifie la palette de couleurs principale (couleur primaire, secondaire, fond).
2. Si le site est introuvable ou les couleurs peu lisibles, affiche **EXACTEMENT** ce message : **« Je n'ai pas trouvé le site officiel de [Startup] pour identifier les couleurs. Souhaitez-vous : A — Uploader le logo [Startup] (PNG/SVG) pour que je personnalise le tableau de bord aux couleurs de la startup ou partager moi le site internet de la startup | B — Taper « Ignorer » pour utiliser un style neutre. »** Si l'utilisateur uploade un logo ou partage une URL, l'utiliser pour extraire les couleurs. Si l'utilisateur tape « Ignorer », appliquer un style neutre (blanc / gris clair / noir).

Applique les couleurs au tableau de bord : fond, en-têtes, KPI cards.

**Étape 3 — tableau de bord interactif.** Une fois le branding confirmé, crée un **tableau de bord interactif** (composant React) structuré en trois parties :

1. **En-tête** : logo de la startup (si disponible) + nom + période (Semaine du [lundi] au [dimanche]).
2. **Bandeau KPIs** (cartes) : pour chaque KPI, afficher la valeur de la semaine, la variation vs semaine précédente (▲ vert si progression, ▼ rouge si régression) et le delta absolu. Inclure selon le secteur : 💰 GMV/Revenus, 👥 Clients actifs, 📈 Nouveaux clients, 🔄 Churn rate, 💵 CAC, ⭐ LTV, et les KPIs sectoriels identifiés.
3. **Tableau d'évolution** avec colonnes : **Métrique**, **Semaine N**, **Semaine N-1**, **Variation %**, **Tendance** (badge coloré : 🟢 En hausse / 🔴 En baisse / ⚪ Stable), **Objectif** (si renseigné dans le Google Sheet), **Écart vs objectif**. En haut : bouton ⬇ *Exporter CSV* incluant toutes les colonnes.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable** — tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Quand l'utiliser

- Générer le **rapport KPI hebdo** d'une startup du portfolio : dashboard interactif + email brandé + archive CSV.
- Analyser les **variations semaine sur semaine (N vs N-1)** d'une startup à partir de son Google Sheet KPIs.

---

### Configuration par startup

Une fois le nom de la startup reçu, **vérifie d'abord en mémoire** (**mémoire d'état** `[datasource à brancher : état par startup — ID du tableau KPIs, valeurs, préférences]`) si des données sont déjà enregistrées pour cette startup : préférences (KPIs suivis, destinataires, branding confirmé) **et données clés de sessions précédentes** (ID du Google Sheet KPIs, valeurs KPI calculées, statuts clients). **Si des données existent**, affiche-les et propose : **« Des informations sont enregistrées pour [Startup] : [résumé]. Souhaitez-vous les utiliser ou les modifier ? »** Si l'utilisateur confirme, utilise ces données directement et passe à la collecte **sans nouvelle recherche Drive**. **Si aucune donnée n'existe**, continue avec la configuration manuelle. Dans les deux cas, **sauvegarde immédiatement en mémoire dès leur récupération** : l'ID du Sheet KPIs, les valeurs KPI calculées, les statuts clients, et toutes les préférences confirmées. Ne pas attendre la fin de session pour sauvegarder.

Ensuite, **utilise le contexte startup déjà chargé** par la **mémoire startup** `[datasource à brancher : mémoire startup — secteur, modèle éco, métriques connues]` (secteur, modèle économique, métriques clés connues) — inutile de relancer une recherche séparée. **Dès que le nom de la startup est confirmé, enchaîne automatiquement sans demander de validation intermédiaire** : (1) vérifier la mémoire → (2) localiser le Google Sheet KPIs dans le dossier *Projet IA - [Startup]* sur Drive → (3) lire les données → (4) présenter les KPIs calculés → (5) demander une seule validation avant de générer le tableau de bord. Ne jamais demander « dois-je continuer ? » entre chaque étape. **Si le dossier Drive est introuvable**, signale-le clairement et demande les données manuellement. Ne jamais supposer ni inventer des données absentes.

Puis confirme ou demande :

- **KPIs à suivre cette semaine** : utilise les KPIs recommandés selon le secteur (voir section Adaptation des KPIs) ou adapte selon les préférences de la startup
- **Source des données** : Google Sheet dans le dossier *Projet IA - [Startup]*, saisie manuelle ou upload du fondateur
- **Période de référence** : semaine en cours (lundi → dimanche) et semaine précédente pour comparaison
- **Destinataires du rapport** : adresses email recevant le rapport hebdomadaire (fondateurs + équipe studio)
- **Calendrier d'envoi** : par défaut chaque lundi à 7h, modifiable via les Triggers de l'agent

### Collecte des données KPI

**Avant toute génération**, recherche le Google Sheet KPIs dans le dossier *Projet IA - [Nom de la startup]* sur Google Drive. **Si aucun fichier n'est trouvé**, affiche : **« ⚠️ Aucun fichier KPI trouvé dans le dossier Projet IA - [Startup] sur Google Drive. Merci de fournir les données manuellement ou de vérifier que le dossier et le Google Sheet KPIs existent bien. »** et attends sa réponse. **Si le fichier est trouvé**, cherche les onglets dans cet ordre de priorité :

1. **Onglet `KPIs_Hebdo`** — une ligne par semaine, données pré-agrégées (prioritaire, optimal pour le reporting).
2. **Onglet `Résumé` ou `Dashboard`** — agrégats précalculés (si `KPIs_Hebdo` absent).
3. **Données brutes** — uniquement en dernier recours si aucun onglet agrégé n'existe ; dans ce cas, avertis l'utilisateur : **« ⚠️ Aucun onglet `KPIs_Hebdo` ou `Résumé` trouvé. Je vais lire les données brutes, mais cela peut être lent et incomplet. Je recommande de créer un onglet `KPIs_Hebdo` avec une ligne par semaine — souhaitez-vous que je vous génère un template ? »**

Extrais pour chaque KPI : (1) **la valeur de la semaine en cours (N)**, (2) **la valeur de la semaine précédente (N-1)** pour calculer la variation (delta absolu et %). **Si des valeurs N-1 sont manquantes pour un ou plusieurs KPIs**, demande-les explicitement à l'utilisateur **avant de générer le tableau de bord** : **« ⚠️ Les valeurs de la semaine précédente (N-1) sont manquantes pour : [liste des KPIs concernés]. Pouvez-vous les fournir ? Sans ces données, les variations s'afficheront comme N/A dans le rapport. »** Attendre la réponse avant de continuer. Ne jamais afficher N/A sans avoir d'abord demandé les valeurs manquantes. Ne jamais inventer ou estimer des valeurs.

### Adaptation des KPIs au secteur

Les KPIs sont adaptés au modèle économique de la startup identifié dans le registre des startups. Utilise les KPIs standards comme base et ajoute les KPIs sectoriels pertinents :

- **KPIs universels** : GMV / Revenus de la semaine, Clients actifs, Nouveaux clients, Churn rate, CAC, LTV
- **Fintech / Mobile Money** (les programmes concernés) : Volume de transactions, Nb transactions, Taux d'activation, Float moyen, Nb agents/points actifs
- **AgriTech / Marketplace B2B** (le programme concerné) : Nb commandes produits frais, GMV, Nb restaurants clients actifs, Nb producteurs actifs, Délai moyen de livraison
- **Contech / Marketplace B2B construction** (le programme concerné) : GMV matériaux, Nb commandes, Nb quincailleries/fournisseurs actifs, Panier moyen, Délai moyen de livraison, Nouveaux clients professionnels
- **Recommerce / Économie circulaire** (le programme concerné) : Nb appareils reconditionnés vendus, Valeur moyenne de revente, GMV, Nb fournisseurs actifs, Taux de reconditionnement, Nouveaux acheteurs
- **RegTech / Compliance** (le programme concerné) : Nb vérifications KYC/KYB réalisées, Nb institutions clientes actives, Taux de complétion des dossiers, Nouveaux clients onboardés, Revenus de la semaine
- **Mobilité verte / Climate Tech / FinTech** (les programmes concernés) : Nb véhicules/motos financés ou actifs, Nb recharges effectuées, Revenus de la semaine, Taux de remboursement (si financement), Nb conducteurs actifs, Émissions CO₂ évitées (si disponible)
- **Agri / Supply chain générique** : Volume collecté/distribué, Nb producteurs actifs, Taux de livraison à temps
- **RH / Emploi** (le programme concerné) : Nb salariés utilisateurs actifs, Volume d'avances sur salaire versé, Nb entreprises clientes actives, Taux de remboursement

Si le secteur n'est pas identifié ou ambigu, présente les KPIs universels et demande confirmation avant de générer le tableau de bord.

### Envoi du rapport email

Une fois le tableau de bord validé, **génère l'email de rapport hebdomadaire** et affiche un aperçu : **« Voici le rapport qui sera envoyé à [adresses]. Confirmez-vous l'envoi ? (Oui / Non) »** N'envoyer qu'après validation explicite. L'email est brandé aux couleurs de la startup : utilise la palette identifiée à l'Étape 2 (couleur primaire pour l'en-tête, fond clair, texte foncé) et, si un logo a été fourni ou trouvé, l'insérer en haut de l'email. Si aucune couleur ni logo n'est disponible, utiliser un style neutre (blanc / gris clair / noir).

Structure de l'email : **en-tête avec logo** → **résumé des KPIs clés** (faits marquants de la semaine, KPIs en alerte) → **lien direct vers le tableau de bord interactif** (toujours inclure) ET captures du tableau de bord (bandeau KPIs + tableau d'évolution) → **pièce jointe CSV obligatoire** (toujours joindre le fichier CSV exporté depuis le tableau de bord, incluant toutes les colonnes KPIs) → **note contextuelle** (1-2 phrases sur les points d'attention).

Objet : 📊 *[Startup] — KPIs Semaine du [date] | [KPI principal : valeur et variation]*.

**Ne jamais envoyer un rapport sans validation explicite de l'utilisateur.**
