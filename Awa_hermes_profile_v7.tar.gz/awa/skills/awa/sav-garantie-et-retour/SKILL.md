---
id: Y0432
name: sav-garantie-et-retour
description: "Organise l'après-vente matériel d'un produit qui revient : constat à l'entrée, diagnostic, décision de prise en charge, circuit physique du bien tracé de bout en bout, délai annoncé, solution d'attente pour le client, enregistrement de la cause, et relation avec le fournisseur ou l'atelier réparateur. Produit la procédure de retour, la fiche de prise en charge et le suivi des cas ouverts, sans jamais citer une durée légale, un délai de rétractation ou une obligation de garantie non fournis par l'entreprise."
bucket: B
tags: [Support, Après-vente, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le produit qui revient, le diagnostic, la décision, la circulation

## Ce qu'il faut avoir sous la main
- **Le produit ou la gamme concernée**, et ce qui revient le plus souvent (panne, casse, erreur de commande, non conformité).
- **Le document de garantie de l'entreprise ou du fabricant**, s'il existe : conditions, durées, exclusions. S'il n'existe pas encore, dis-le.
- **Qui répare aujourd'hui** : un atelier interne, un fournisseur externe, le fabricant lui même ; et le canal habituel du client pour signaler un problème (boutique, WhatsApp, appel).
- **Un cas récent**, même raconté de mémoire : ce qui a été demandé au client à l'entrée, combien de temps ça a pris, comment ça s'est terminé.
- **Ce qui existe déjà** comme trace : registre papier, fiche Excel, ticket dans un outil, ou rien du tout.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tes manques (`⟦à renseigner⟧`). Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Le constat à l'entrée, avant toute discussion

Le piège classique : accepter le produit au comptoir, promettre de "regarder ça", et découvrir deux semaines plus tard qu'on ne sait plus depuis quand il est là, ni dans quel état il est arrivé. À ce moment là, le dossier se discute indéfiniment et l'entreprise finit par céder pour avoir la paix, ou par perdre le client.

Le constat se fait à l'entrée, jamais après coup. Tu listes ce qu'il exige : identification du produit (numéro de série, référence, ou à défaut une description précise), preuve d'achat ou de date approximative si le ticket est perdu, état visuel documenté par photo au moment du dépôt, description du problème dans les mots du client. Sur un téléphone d'entrée de gamme la photo peut être floue ou lourde à envoyer sur une connexion coûteuse : prévois un format compressé et un minimum de deux angles plutôt qu'une exigence irréaliste.

Sans ce constat, aucune prise en charge ne démarre. Tu le dis même si ça ralentit le premier contact : c'est ce ralentissement qui évite les semaines perdues ensuite.

### Étape 2 : Le diagnostic et la qualification du défaut

Une fois le constat posé, le diagnostic répond à une seule question : est ce que le défaut correspond à ce que le client décrit, et de quelle nature est il (défaut de fabrication, usure normale, mauvais usage, dommage accidentel, pièce consommable). Cette qualification conditionne tout ce qui suit : elle n'est pas un détail technique, c'est la pièce qui fonde la décision de l'étape 3.

Le diagnostic est daté et signé par celui qui l'a fait. Un diagnostic qui traîne sans responsable identifié est le premier maillon d'un dossier qui se perd.

### Étape 3 : La décision de prise en charge, et ce que dit vraiment la garantie

Ici se joue le piège le plus coûteux en confiance : affirmer une garantie de mémoire. Tu ne cites AUCUNE durée légale de garantie, aucune obligation de conformité, aucun délai de rétractation. Tu appliques ce que dit le document de garantie de l'entreprise ou du fabricant, terme par terme. Ce que ce document ne couvre pas, tu le marques `⟦à vérifier dans la garantie⟧` et tu renvoies à un avis compétent (juridique ou conformité) pour trancher, en signalant que ce point ne relève pas de la présente compétence.

La décision (prise en charge gratuite, payante, refusée) est écrite avec son fondement : quelle clause de garantie, quel constat, quel diagnostic la justifie. Une décision orale sans trace écrite revient toujours en discussion plus tard, souvent devant un client énervé qui a eu le temps de comparer avec un autre commerce.

Qui décide est nommé explicitement : le support ne tranche pas seul les cas ambigus, sauf règle claire déjà donnée par l'équipe pour les cas simples et répétitifs.

### Étape 4 : Le circuit physique du bien, tracé de bout en bout

C'est le piège le plus fréquent et le plus destructeur : un produit confié au comptoir, transporté chez un réparateur, immobilisé dans un coin sans que personne ne sache où il est ni depuis quand. À Abidjan en particulier, les distances et les embouteillages font qu'un aller retour vers un atelier prend facilement plusieurs jours, et un produit "en cours de transport" invisible pendant tout ce temps devient un dossier qui échappe à tout le monde.

Chaque mouvement du produit porte trois informations : la date du mouvement, le détenteur actuel (comptoir, atelier interne, fournisseur, transporteur), et le document qui l'accompagne (bon de dépôt, bordereau de transfert). Tu dessines le circuit complet, étape par étape, avec le document dû à chaque transition. Un bien qui change de main sans document est un bien qu'on ne pourra pas réclamer si le détenteur le nie.

### Étape 5 : Le délai annoncé et la solution d'attente

Deux manques se cumulent souvent et occupent le support pour rien.

Le premier : aucune date de retour n'est donnée au client, qui rappelle tous les deux jours pour savoir où en est son dossier. Une date est due dès la prise en charge, même approximative, avec la règle explicite de ce qui se passe si elle bouge (qui prévient le client, par quel canal, WhatsApp étant souvent le plus direct et le moins coûteux pour lui).

Le second, plus souvent oublié : pour un bien que le client utilise tous les jours pour travailler (un four, un vélo utilitaire, un ordinateur professionnel), la réparation seule ne suffit pas. La vraie question est comment il continue à travailler pendant l'immobilisation. Tu poses l'option (prêt, échange temporaire, priorisation du dossier) comme une décision à remonter, pas comme un geste que le support improvise seul : elle a un coût et elle engage l'entreprise.

### Étape 6 : La relation avec le fournisseur ou l'atelier externe

Quand la réparation ne se fait pas en interne, le produit sort du contrôle direct de l'entreprise, et c'est là que les délais dérapent le plus. Tu prépares ce qui structure cette relation : le document de transfert qui accompagne le bien, l'engagement de délai obtenu du prestataire (même informel, même par appel téléphonique suivi d'un message écrit de confirmation), et le point de contact nommé chez le fournisseur plutôt qu'un service générique.

Si le fournisseur ou l'atelier est un opérateur informel sans processus écrit, ça ne dispense pas de trace côté entreprise : c'est justement là que la trace interne (photo au dépôt chez le prestataire, message WhatsApp horodaté) protège le dossier si le bien revient endommagé différemment ou ne revient pas dans le délai promis.

### Étape 7 : La cause enregistrée, la clôture et le suivi des cas ouverts

Un défaut isolé n'apprend rien. Le même défaut sur le même lot ne se voit qu'en cumulant les dossiers dans le temps : c'est pour ça que chaque prise en charge porte une cause catégorisée (liste de catégories à construire avec le responsable produit, pas inventée au fil de l'eau), remontée à qui gère le produit ou la relation fournisseur amont. Sans cette catégorisation, une série de pannes identiques ressemble à une suite de cas isolés jusqu'au jour où le volume devient un problème public.

La clôture du dossier exige : le bien remis ou remplacé, le client informé, la cause enregistrée, et la décision de prise en charge archivée avec son fondement. Un dossier "réglé" oralement sans ces quatre éléments reste rouvrable.

Le suivi des cas ouverts se lit à tout moment sur l'ancienneté : depuis combien de jours chaque dossier est ouvert, où en est le bien dans le circuit, et une alerte visible sur tout dossier immobilisé au delà du délai annoncé à l'étape 5.

## Format de sortie
- **Livrable** : trois documents distincts, ou un seul regroupé selon la demande : la procédure de retour, la fiche de prise en charge type, et le tableau de suivi des cas ouverts.
- **Procédure de retour** : ce qui est exigé à l'entrée (constat, preuves), qui décide de la prise en charge et sur quel fondement, le circuit physique du bien étape par étape avec le document dû à chaque transition, la règle de communication du délai au client.
- **Fiche de prise en charge** : identification du produit, constat et preuves (photos, date, état), diagnostic et qui l'a posé, décision et son fondement (clause de garantie citée, jamais inventée), date de retour annoncée, solution d'attente retenue si applicable, cause catégorisée.
- **Suivi des cas ouverts** : un tableau avec, par dossier, la date d'ouverture, l'ancienneté en jours, le détenteur actuel du bien, la date de retour promise, et une alerte sur tout dossier dépassant ce délai sans mise à jour.
- **Structure** : Markdown clair, answer-first (la procédure d'abord, ses justifications ensuite) ; tableaux pour la fiche type et le suivi.
- **Longueur** : proportionnée à la demande, sans remplissage. Une procédure tient en une à deux pages ; la fiche type tient sur une page.
- **Règle 0 invention** : aucune durée de garantie, aucun droit, aucun barème produit sans être fourni par le document de garantie de l'entreprise. Tout ce qui manque est marqué `⟦à vérifier dans la garantie⟧` ou `⟦à renseigner⟧`.

## Règles
1. **Aucun retour n'est accepté sans constat.** Identification du produit, preuve d'achat ou date approximative, état documenté par photo : ces trois éléments se posent à l'entrée, jamais après. Tu le rappelles même si ça ralentit le premier échange avec le client.
2. **Chaque mouvement du bien porte une date, un détenteur et un document.** Un produit qui change de main sans trace écrite (même un message WhatsApp horodaté) est un produit qu'on ne pourra pas réclamer si le détenteur conteste l'avoir reçu.
3. **Une date de retour est due dès la prise en charge**, même approximative, avec la règle de ce qui se passe si elle bouge et qui prévient le client. Un client sans date rappelle et occupe le support pour rien.
4. **0 garantie inventée.** Aucune durée légale, aucune obligation de conformité, aucun délai de rétractation n'est cité de mémoire. Seul ce qu'écrit le document de garantie de l'entreprise ou du fabricant fait foi ; le reste est `⟦à vérifier dans la garantie⟧`, renvoyé à un avis compétent.
5. **La solution d'attente pour le client se décide, elle ne s'improvise pas.** Prêt, échange temporaire ou priorisation ont un coût : la question se pose explicitement, la décision remonte au bon niveau.
6. **Chaque dossier porte une cause catégorisée.** Le même défaut sur le même lot ne se détecte qu'en cumulant les causes dans le temps ; un dossier fermé sans cause enregistrée prive l'entreprise de cette mémoire.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant, durée de garantie ou référence fabriqués. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `⟦à renseigner⟧` ou `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais une clause de garantie ou un engagement fournisseur comme "confirmé" sans document réel à l'appui. Si une datasource est inaccessible, dis le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; contacter un fournisseur, envoyer un remboursement, expédier un remplacement ou clore un dossier auprès du client est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun document de garantie fourni** : tu construis la procédure et la fiche quand même, tu marques chaque clause de décision `⟦à vérifier dans la garantie⟧`, et tu signales que la décision de prise en charge ne peut pas être fondée tant que ce document n'existe pas.
- **Produit sans preuve d'achat ni numéro de série** : tu le dis explicitement, tu proposes la marche à suivre (déclaration du client datée, recoupement avec un autre registre de vente si disponible) sans jamais fabriquer une preuve à sa place.
- **Fournisseur ou atelier informel, sans processus écrit** : tu ne dispenses pas la trace côté entreprise pour autant ; photo au dépôt, message horodaté et engagement de délai oral confirmé par écrit restent dus.
- **Dossier immobilisé bien au delà du délai promis** : tu le signales comme alerte prioritaire dans le suivi, tu ne le laisses pas se fondre dans la liste des cas ordinaires.
- **Client insistant sans constat initial** : tu ne cèdes pas la procédure pour apaiser la tension ; tu proposes le constat a posteriori en le signalant comme dégradé par rapport à la procédure normale.
- **Pièce ou produit de remplacement indisponible** : tu le dis, tu poses la question de la solution d'attente comme décision à prendre, tu ne promets pas un délai que personne n'a confirmé.
- **Lot suspecté défectueux (plusieurs cas similaires)** : tu le signales dès qu'il apparaît dans les causes enregistrées et tu recommandes la remontée au responsable produit, sans attendre la clôture individuelle de chaque dossier.
- **Action sortante demandée** (rembourser, contacter le fournisseur, notifier le client d'une décision finale) : tu prépares le contenu et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (le client dit une date d'achat, le registre en dit une autre) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (litige juridique, remboursement légal contesté) : tu le dis en une phrase, tu traites ce qui relève du parcours SAV, et tu orientes vers un avis juridique compétent pour le reste.
