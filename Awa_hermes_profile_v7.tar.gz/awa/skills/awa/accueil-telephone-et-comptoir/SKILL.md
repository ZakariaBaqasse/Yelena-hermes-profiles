---
id: Y0428
name: accueil-telephone-et-comptoir
description: "Organise la part du service client qui passe par la voix et la présence physique (téléphone, comptoir, standard) : trames d'appel, fiche de prise de message, procédure de rappel avec échéance et responsable, formulations d'attente au comptoir, trace minimale d'un échange oral, sans jamais inventer un délai ni un texte à réciter mot à mot."
bucket: B
tags: [Support, Accueil, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le support qui ne s'écrit pas, le téléphone et le comptoir

## Ce qu'il faut avoir sous la main
- **Les canaux oraux utilisés** : ligne fixe, mobile, WhatsApp vocal, comptoir physique, et lesquels sont les plus sollicités.
- **Les horaires et jours** où quelqu'un répond, et ce qui se passe en dehors (répondeur, rien, relais).
- **Qui répond à quoi** : noms ou rôles, et les types de demandes que chacun est censé traiter ou transférer.
- **Les langues réellement pratiquées** à l'accueil (celles du personnel et celles des clients).
- **Trois ou quatre motifs d'appel ou de visite fréquents**, tels qu'ils se présentent vraiment.
- **Ce qui existe déjà pour tracer un échange** : cahier, tableur, CRM, ou rien.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce qui manque. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Cartographier les points de contact oraux et qui répond à quoi
Recense chaque canal oral déclaré (fixe, mobile, WhatsApp vocal, comptoir) et, pour chacun, qui est censé répondre, à quelles heures, et ce qui se passe hors de ces heures. Si personne n'est nommé pour un canal ou un créneau, c'est un trou visible qu'il faut signaler, pas combler par supposition.

Piège à désamorcer ici : le comptoir traité comme un guichet unique où « quelqu'un s'en occupe ». Si deux personnes peuvent répondre au même type de demande sans savoir laquelle a déjà traité un client, la file s'allonge et le client raconte deux fois son problème avant même d'avoir quitté le lieu.

### Étape 2 : Construire la trame d'appel par points de passage, pas par texte à réciter
Découpe l'appel en quatre temps : prise d'appel, qualification en trois questions, réponse ou transfert, clôture. Pour chaque temps, donne le **but** et un ou deux repères de formulation, pas un texte figé. La qualification en trois questions doit permettre de savoir en moins d'une minute : qui est en face, quel est le motif réel, et ce qui a déjà été tenté ou promis.

Piège à désamorcer ici : la trame lue mot à mot. Un accueil récité s'entend immédiatement au ton et casse la relation qu'il est censé installer. La trame sert à ne rien oublier sous pression, pas à remplacer le jugement de celui qui répond.

### Étape 3 : Poser la règle du transfert accompagné
Un transfert ne se fait jamais à l'aveugle. Avant de transférer, celui qui a pris l'appel résume en une phrase le motif à la personne qui va reprendre, pour que le client n'ait pas à tout répéter. Si la personne visée est indisponible, la règle prévoit une solution de repli nommée (qui prend le relais, ou passage direct à la fiche de prise de message) plutôt qu'un silence ou un "rappelez plus tard" sans engagement.

Piège à désamorcer ici : le transfert dans le vide, celui qui fait atterrir le client sur une ligne qui sonne dans le bureau de quelqu'un d'absent. Chaque transfert a une issue prévue, y compris l'échec du transfert.

### Étape 4 : Construire la fiche de prise de message
La fiche capture, en une poignée de champs, ce qu'il faut pour qu'un autre que celui qui a décroché puisse reprendre l'échange sans perdre le fil : qui appelle (nom, contact, éventuellement mobile money ou numéro habituel si c'est un client connu), quel est le motif en une phrase, pour qui c'est destiné, le degré d'urgence tel que perçu par l'appelant, et surtout ce qui a été promis et pour quand.

La fiche existe même quand le problème a été réglé sur le coup : c'est le point de l'étape suivante, mais ça se prépare ici en gardant le format unique quel que soit l'issue de l'appel.

### Étape 5 : Verrouiller la procédure de rappel
Un rappel promis devient, au moment même où il est promis, une échéance écrite avec une heure ou un créneau, et un responsable nommé, pas "quelqu'un vous rappellera". Sans ces deux éléments, un rappel ne se promet pas : on dit au client ce qui est réellement possible plutôt que de promettre pour clore l'échange.

Piège à désamorcer ici, le plus destructeur du support téléphonique : le rappel promis et non tenu. Il ne vient presque jamais d'une mauvaise volonté, mais d'une promesse faite oralement et jamais posée nulle part. La procédure that tient est celle où l'échéance existe dans un endroit que quelqu'un consulte, pas dans la mémoire de celui qui a répondu.

### Étape 6 : Fixer la trace minimale d'un échange oral, au format identique pour tous
Chaque échange, réglé sur-le-champ ou non, laisse une ligne dans un format identique : date, canal, motif, issue, promesse et échéance s'il y en a une. Le format ne varie pas selon que l'appel a été simple ou compliqué : c'est la constance du format, pas sa richesse, qui fait qu'une trace existe vraiment.

Piège à désamorcer ici : l'échange qui ne laisse aucune trace parce qu'il a été "réglé tout de suite". C'est le trou le plus fréquent, et c'est lui qui fait qu'un client rappelant une deuxième fois pour le même sujet tombe sur quelqu'un qui ne sait rien : c'est à ce moment précis que la relation se dégrade, pas au premier appel.

### Étape 7 : Traiter la langue et l'attente comme des conditions réelles, pas des détails
Pour les formulations clés de la trame (accueil, qualification, mise en attente, clôture), prévois une version dans chaque langue réellement pratiquée à l'accueil, déclarée à l'étape de démarrage. Ne suppose jamais une langue véhiculaire par défaut : demande, et si la réponse manque, marque `⟦à renseigner⟧` plutôt que de choisir à la place de l'équipe.

Pour le comptoir, prévois des formulations d'attente qui informent plutôt que de laisser filer le silence : dire combien de personnes restent avant le client, ou à défaut reconnaître l'attente et donner un ordre de grandeur si l'équipe peut l'estimer. Une file qui s'allonge sans qu'on dise rien produit plus de mécontentement que l'attente elle-même.

## Format de sortie
- **Livrable** : les trames d'accueil (prise d'appel, qualification en trois questions, réponse ou transfert, clôture), la fiche de prise de message, la procédure de rappel avec son échéance et son responsable, les formulations d'attente et de file au comptoir, et le format de trace minimale d'un échange oral.
- **Structure** : Markdown clair, avec des tableaux pour la fiche de prise de message et le format de trace ; des listes à points pour les trames, pas des paragraphes continus qu'on ne peut pas consulter en pleine urgence.
- **Longueur** : proportionnée aux canaux réellement déclarés. Une entreprise avec un seul comptoir n'a pas besoin d'une trame de standard à trois niveaux.
- **Les échéances et responsabilités nominatives sont un input** : la skill livre la structure de la fiche et de la procédure de rappel, mais les noms, heures et créneaux réels restent `⟦à renseigner⟧` tant qu'ils ne sont pas donnés.
- **Règle 0 invention** : aucune formulation présentée comme "la phrase qui marche" sans être ancrée dans les motifs et langues déclarés par l'équipe.

## Règles
1. **Une trame donne des points de passage, jamais un texte à réciter.** Si le livrable ressemble à un script mot à mot, il a raté sa cible : il doit pouvoir être adapté sur l'instant sans perdre sa fonction.
2. **Un rappel promis est une échéance écrite avec un responsable, ou il ne se promet pas.** Tu le rappelles chaque fois qu'une procédure de rappel est décrite sans heure ni nom.
3. **Toute langue mentionnée par l'équipe est traitée, aucune n'est supposée.** Tu ne complètes jamais une formulation dans une langue non déclarée.
4. **La trace d'un échange existe même quand le problème a été réglé immédiatement.** Un format qui ne s'applique qu'aux échanges compliqués n'est pas le format qu'on demande.
5. **Un transfert a toujours une issue prévue, y compris son échec.** Tu ne laisses jamais un transfert se terminer sur une supposition que "ça va sonner quelque part".
6. **Le comptoir n'est pas un guichet muet.** Toute file d'attente mentionnée reçoit une formulation qui informe le client de ce qui l'attend, même approximativement.
7. **0 chiffre ou délai inventé.** Aucun temps d'attente estimé, aucun taux de rappel réussi, aucun seuil n'est produit sans venir de l'équipe : `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme "sourcé" sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des trames et des fiches de travail ; diffuser ces documents à l'équipe, les afficher au comptoir, ou modifier un standard téléphonique est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun canal déclaré comme prioritaire** : tu traites tous les canaux mentionnés sans en privilégier un par supposition, et tu signales si l'ordre d'importance n'a pas été donné.
- **Personne nommée pour un créneau ou un canal** : tu signales le trou explicitement plutôt que de désigner quelqu'un par défaut.
- **Langues non précisées** : tu produis les trames en français et marques `⟦à renseigner⟧` pour toute autre langue, sans supposer laquelle est parlée.
- **Outil de traçage inexistant** : tu proposes le format de trace le plus simple possible (papier ou tableur), tu ne présupposes jamais un outil numérique disponible.
- **Motifs d'appel non fournis** : tu construis la trame sur une structure générique de qualification en trois questions, et tu marques que les motifs réels restent à préciser pour l'affiner.
- **Demande hors périmètre** (script commercial, argumentaire de vente, gestion de plainte écrite) : tu le dis en une phrase, tu traites ce qui relève de l'accueil oral, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoyer les trames à l'équipe, imprimer et afficher) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Informations contradictoires** (deux personnes différentes désignées pour le même motif) : tu exposes la contradiction et tu demandes l'arbitrage plutôt que de trancher seul.
