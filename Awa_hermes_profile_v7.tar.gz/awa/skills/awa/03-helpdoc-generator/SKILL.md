---
id: Y0023
name: 03-helpdoc-generator
description: "Détecte les questions support récurrentes et génère des articles helpdoc/FAQ prêts à publier (markdown, Intercom, Notion, HTML)."
bucket: C
tags: [Support]
version: 1
maj: 2026-08-26
---

# HelpDoc Generator

## Process
Lire les tickets résolus de la fenêtre via `[connecteur à brancher : base de tickets / community inbox (Notion) ou tableur]`. Cluster par **question sous-jacente**, pas par mots-clés bruts (ex. « login bloqué » + « mot de passe ne marche pas » → cluster `connexion impossible`). Par cluster : count, 3 verbatims exemples, réponses types données par le support (pull du fil ticket).

### Étape 2 : Score & shortlist

`score = count × (1 + 0.5 × négatif_sentiment_count) × résolvabilité_par_doc` (résolvabilité = 1.0 si self-service, 0.3 si nécessite un humain type KYC manuel). Shortlist : top 5 clusters (score décroissant) qui n'ont **pas** déjà un article publié (croiser avec la base helpdoc existante si dispo).

### Étape 3 : Rédaction des articles

Par article : **Titre** (question utilisateur, pas titre marketing) ; **TL;DR** (≤ 50 mots, réponse directe en haut) ; **Étapes détaillées** (numérotées, action par action, captures `[screenshot:nom]`) ; **Cas limites & dépannage** (3-5 + solution) ; **« Toujours bloqué·e ? »** (lien vers le canal support préféré de la startup) ; **Articles liés** (3, ou recommandés à créer).

### Étape 4 : Ton et style

Charger le brand kit (`direct`, `chaleureux`, `pédagogique`, `pro corporate`…). Pas de jargon (sauf audience technique). Tu/Vous selon la convention de la startup (défaut UEMOA : « vous » B2C neutre, « tu » cible jeune/lifestyle). Phrases courtes (≤ 20 mots). Verbe à l'impératif dans les étapes.

## Format de sortie
`markdown` (titres `##`, listes, blocs code) · `intercom` (objet Article : title, body HTML) · `notion` (écriture dans la base support/FAQ de l'entité, statut `draft` : h2 sections, callout TL;DR, numbered_list étapes, quote verbatims) via `[connecteur à brancher : base de connaissances / help center]` · `html` (propre, classes minimales).

## Règles
- **Toujours partir des verbatims réels** ; ne jamais inventer une question jamais posée.
- **Une question = un article** (pas de fourre-tout « Tout savoir sur X »).
- **Mettre à jour si déjà existant** : article couvrant le sujet mais 30 % des tickets continuent → suggérer un patch ciblé, pas un nouvel article.
- **Multilingue** : startup FR + EN → double output ; bambara/wolof → signaler qu'un humain natif doit valider.
- **Citer ses sources** : lister anonymement en fin d'article les 3 verbatims déclencheurs.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Output (JSON)

`{ startup, window, tickets_analyzed, clusters_found, articles_shortlisted, articles:[{rank, title, estimated_tickets_deflected_monthly, score, tags, content, screenshots_needed}], clusters_skipped:[{cluster, reason}], next_step }`.
