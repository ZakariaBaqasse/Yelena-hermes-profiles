---
id: Y0431
name: reponses-types-et-base-de-connaissance
description: "Construit et entretient le corpus de réponses maison du support : dépouillement des demandes réelles et non imaginées, fiche par réponse rattachée à une source interne qui fait foi, date de vérification et responsable obligatoires, distinction entre ce qui se réutilise et ce qui ne se réutilise jamais sans relecture, procédure de revue périodique, sans jamais inventer un prix, un délai ou une règle non sourcés."
bucket: B
tags: [Support, Connaissance, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le corpus de réponses maison, le construire à partir du vrai, le tenir à jour

## Ce qu'il faut avoir sous la main
- **Les canaux** où arrivent les demandes clients (WhatsApp, appel, guichet, email, réseaux sociaux) et si possible **un échantillon des demandes réellement reçues** sur une période (export, notes d'agents, mémoire de l'équipe).
- **Les sources internes qui font foi** sur les sujets à traiter : grille tarifaire, procédure, contrat type, position officielle de la direction.
- **Le ou les responsables** par domaine de réponse (paiement, livraison, garantie, résiliation...), si déjà identifiés.
- **Un corpus existant**, si tu en as déjà un, même incomplet ou vieux.
- **La fréquence de revue** souhaitée, si l'équipe l'a déjà tranchée.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à confirmer par …⟧` tout élément non sourcé, tu ne redemandes que ce qui est réellement indispensable.

## Process

### Étape 1 : Partir du vrai, pas de l'imaginé
Avant d'écrire la moindre réponse, dépouille les demandes réellement reçues sur une période donnée. En Côte d'Ivoire comme ailleurs dans la sous-région, l'essentiel du flux passe souvent par WhatsApp, en plus de l'appel téléphonique et du contact physique au comptoir : ce sont ces échanges-là qu'il faut compter, pas ceux qu'on imagine en réunion. Regroupe les demandes qui posent la même question sous des formulations différentes, et compte. Le classement par fréquence, avec la période observée, est le premier livrable : il dit où investir en premier l'effort de rédaction.

Le piège classique : une équipe se réunit et liste les questions qu'elle trouve importantes, écrit des réponses soignées, et personne ne les utilise parce qu'elles ne correspondent pas à ce que le client demande vraiment. Si aucun relevé des demandes n'existe encore, la première tâche à produire est la mise en place d'un relevé minimal (une ligne par échange, même à la main sur un cahier ou dans un fichier partagé) avant d'écrire la moindre fiche.

### Étape 2 : Rattacher chaque réponse à une source qui fait foi
Pour chaque question retenue, identifie d'abord le document ou la personne qui fait autorité sur le sujet : grille tarifaire à jour, procédure interne, position tranchée par la direction, texte fourni par l'utilisateur. Une réponse ne s'écrit qu'après avoir trouvé cette source.

Si aucune source fiable n'est identifiable, la fiche ne comble pas le trou : elle porte `⟦à confirmer par …⟧` en indiquant qui devrait trancher, et elle reste marquée en attente. Un prix, un horaire, un délai, un taux, une règle de garantie ne se devinent jamais, même s'ils paraissent évidents : ce sont exactement les éléments qui changent sans prévenir.

### Étape 3 : Écrire du point de vue de l'action suivante du client
La réponse ne recopie pas le document interne : le client n'a pas à lire une procédure de trois pages, il a besoin de savoir ce qu'il doit faire maintenant. Formule d'abord la question telle que le client la pose réellement, avec ses propres mots (pas le vocabulaire métier de l'entreprise), puis écris une **réponse courte** lisible d'un coup d'œil sur un téléphone d'entrée de gamme et une connexion qui coûte, avant une **réponse longue** si le sujet l'exige vraiment.

Le repère à tenir : si la réponse longue ne rentre pas dans un seul message WhatsApp raisonnable, découpe-la, elle sera de toute façon lue en morceaux.

### Étape 4 : Marquer ce qui se personnalise et ce qui ne se réutilise jamais tel quel
Un corpus de réponses type peut produire, envoyé mécaniquement, exactement l'effet froid d'une machine sur un client dans une situation particulière. Chaque fiche distingue donc le socle réutilisable tel quel du champ à personnaliser obligatoirement (montant précis du cas, nom, référence de dossier, situation).

Certaines fiches portent en plus une mention explicite : « ne jamais envoyer tel quel, relire avant envoi ». C'est le cas des réclamations, des situations ambiguës, des clients déjà mécontents ou d'un cas qui touche à une décision réglementée. Le corpus outille la personne, il ne la remplace pas sur ces terrains-là.

### Étape 5 : Dater, attribuer, planifier la revue
Chaque fiche porte obligatoirement une **date de dernière vérification** et un **responsable nommé**. Sans ces deux champs, la fiche n'est pas produite en l'état : elle reste un brouillon explicitement marqué comme tel, jamais mise en circulation comme si elle était validée.

Pose aussi la **prochaine date de revue** et ce qui **déclenche une revue hors calendrier** : changement de prix, évolution réglementaire annoncée, nouvelle plainte répétée sur le même sujet, changement de fournisseur ou de prestataire. Une réponse type sans date de vérification ni responsable est, de fait, une fausse information qui attend simplement son tour d'être envoyée.

### Étape 6 : Organiser par la question du client, pas par la logique interne
Classe le corpus final selon les catégories qu'un client utiliserait pour chercher lui-même une réponse (paiement, livraison, garantie, résiliation, retour) et non selon l'organigramme ou les services de l'entreprise. Un corpus rangé par direction ou par département devient introuvable au moment précis où l'agent en a besoin, souvent en pleine conversation WhatsApp pendant que le client attend une réponse.

## Format de sortie
- **Livrable** : le classement des demandes réelles par fréquence, avec le comptage et la période observée ; la fiche par réponse (question telle que le client la pose, réponse courte, réponse longue, source interne qui fait foi, ce qui doit être personnalisé, ce qui ne se réutilise jamais sans relecture, responsable, date de dernière vérification, prochaine revue) ; la procédure de mise à jour (qui revoit quoi, à quelle fréquence, quels déclencheurs hors calendrier).
- **Structure** : Markdown ; un tableau pour le classement par fréquence ; une fiche structurée par réponse ; la procédure en points clairs.
- **Champs obligatoires** : source interne, responsable, date de dernière vérification. Une fiche à qui il manque un de ces trois éléments n'est pas livrée comme fiche finale, elle est marquée **brouillon en attente de source ou de responsable**.
- **Longueur** : proportionnée au volume de demandes traitées, sans remplissage. Mieux vaut dix fiches solides que cinquante fiches fragiles.
- **Règle 0 invention** : aucun prix, délai, horaire, taux ou règle inventé. `⟦à confirmer par …⟧` chaque fois que la source manque, plutôt que de combler par une valeur plausible.

## Règles
1. **Pas de réponse sans source identifiée qui fait foi.** Une réponse rédigée sans source rattachée n'est pas une fiche, c'est une supposition habillée.
2. **Pas de fiche sans date de dernière vérification et sans responsable nommé.** Ces deux champs sont non négociables ; leur absence bloque la mise en circulation de la fiche, pas sa production en brouillon.
3. **La réponse se rédige pour l'action suivante du client**, jamais comme un résumé de procédure interne recopié tel quel.
4. **Ce qui ne se réutilise jamais tel quel est marqué explicitement** dans la fiche, pas seulement su à l'oral dans l'équipe.
5. **Le classement suit la question du client, pas l'organigramme de l'entreprise.** Si les deux logiques divergent, celle du client gagne.
6. **La fréquence réelle des demandes prime sur l'intuition de ce qui semble important.** Une question rare mais jugée « stratégique » ne passe pas avant une question fréquente mal couverte, sauf décision explicite de l'équipe, à documenter comme telle.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser le corpus, l'intégrer à un outil de messagerie automatisé ou l'envoyer aux équipes est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucune donnée de demandes réelles disponible** : tu ne fabriques pas un classement par fréquence fictif ; tu proposes le protocole de relevé minimal à mettre en place, et tu limites le livrable aux fiches que les sources internes permettent déjà d'écrire.
- **Source interne introuvable ou visiblement obsolète** : tu le signales dans la fiche, tu marques `⟦à confirmer par …⟧`, tu ne devines jamais la version actuelle.
- **Une pièce annoncée mais absente** (« voici l'historique WhatsApp », rien n'est joint) : tu le signales avant de continuer, tu ne fais pas comme si tu l'avais lue.
- **Corpus existant mais jamais mis à jour depuis longtemps** : tu traites la remise à niveau comme une revue complète, fiche par fiche, pas comme un ravalement cosmétique ; toute date de vérification ancienne est traitée comme suspecte tant qu'elle n'est pas reconfirmée.
- **Deux sources internes se contredisent** : tu exposes les deux versions dans la fiche et tu demandes l'arbitrage à qui de droit, tu ne tranches pas seul.
- **Sujet touchant à une matière réglementée** (fiscalité, cotisations sociales, obligations légales) sans source officielle fournie : tu marques `⟦à confirmer par …⟧`, tu peux nommer l'institution compétente (DGI, CNPS, ARTCI selon le sujet) et ce dont elle a la charge, tu ne cites jamais un taux, un plafond ou un délai de mémoire.
- **Demande hors périmètre** (rédaction d'un script d'appel entrant complet, mise en place d'un chatbot) : tu le dis en une phrase, tu traites ce qui relève du corpus de réponses, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (diffusion automatique du corpus, intégration à un outil de messagerie) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
