# 260922_Incident de paiement - qui saisir, dans quel delai

===== onglet t.0 · Tab 1 · 27 lignes non vides =====

# Un incident de paiement : qui saisir, dans quel délai, et à quel prix
Écrite le 22/09/2026 sur la circulaire BCEAO n° 002-2020/CB/C, présente dans cette base en PDF et, depuis ce jour, en texte reconnu.

⛔ Ce texte couvre le mobile money. Son article 2 vise les établissements de crédit, les systèmes financiers décentralisés soumis au contrôle de la Commission bancaire et les établissements de monnaie électronique. Un incident sur un compte Orange Money, MTN MoMo, Wave ou Moov Money relève donc du même circuit qu'un incident bancaire. C'est la réponse à la question qu'on se pose d'habitude en premier : « à qui se plaindre ».
## Le circuit, en deux étages
### Étage 1 : l'établissement lui-même
- Il doit enregistrer chaque réclamation, sur support papier ou électronique.
- Il doit répondre dans un délai qui ne peut excéder un mois à compter de la réception (art. 7).
- ⛔ Le traitement est gratuit (art. 8). Un établissement qui facture l'examen d'une réclamation est en faute.
- Son contrôle interne doit surveiller en permanence son propre dispositif de réclamations (art. 9).
### Étage 2 : la Commission bancaire de l'UMOA
Le client qui n'a pas obtenu de réponse dans le délai d'un mois peut saisir la Commission bancaire.

- Où : Secrétariat général de la Commission bancaire, par courrier postal ou électronique, ou dépôt à la Direction nationale de l'État où l'établissement est implanté.
- Quatre conditions de recevabilité (art. 12) : la réclamation porte sur un produit ou un service financier de l'établissement · elle lui a été soumise au préalable · elle est documentée et formulée dans les délais · ⛔ elle n'est pas déjà devant une instance judiciaire, extra-judiciaire ou administrative, en particulier les mécanismes des observatoires de la qualité des services financiers.
- ⚠ Trente jours calendaires pour fournir les pièces complémentaires demandées. Passé ce délai, ou si le dossier reste incomplet, la demande est rejetée et le rejet est notifié.
- Soixante jours calendaires pour que la Commission instruise un dossier complet, délai suspendu par toute demande de pièces complémentaires (art. 13).

Contacts relevés : courrier.z02sgcb@bceao.int, +225 27 20 25 57 57.

La BCEAO tient par ailleurs une centralisation des incidents de paiement.
## Ce que ça change dans un conseil
- Le compteur démarre à la réclamation écrite auprès de l'établissement. Sans cette première étape datée, l'étage 2 est fermé.
- Ne pas saisir deux instances à la fois : c'est une cause d'irrecevabilité expresse.
- Un mois plus soixante jours : dire au client que le chemin complet se compte en mois, pas en jours, et qu'il est gratuit.
## Ce que cette fiche ne couvre pas
- ⛔ Quels incidents reviennent le plus, sur quel opérateur, et quel geste les règle. Cela se relève sur des dossiers réels, pas dans un texte. ⟦à constituer⟧
- Les parts de marché des opérateurs de mobile money. Les sources publiques se contredisent frontalement, l'une donnant Wave à 40 %, l'autre Orange à 55 % et Wave à 35 %. Aucun chiffre n'est retenu ici.
- Les observatoires de la qualité des services financiers, cités par la circulaire comme une voie concurrente, et non documentés. ⟦à chercher⟧

⚠ Le texte de cette base est une reconnaissance de caractères faite le 22/09/2026 sur un PDF numérisé. L'original fait foi : toute valeur citée se revérifie sur le PDF, surtout un délai ou un numéro d'article.

À recontrôler le 22/03/2027.
