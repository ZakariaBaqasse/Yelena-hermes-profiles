# Couche locale : Awa · Relation et service client

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-AWA-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Socle commun. Pièce déjà sur cette machine : ~/agents/lokoli/memory/reference/gouvernement-2026.md, composition du gouvernement Mambé du 23/01/2026, relevée le 10/09. Un lien symbolique suffit. Pour Awa, l'intérêt est moins le gouvernement que les recours : le Conseil national de la consommation est institué auprès du ministre chargé du Commerce (art. 261 de la loi 2016-412).

### CL-AWA-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://data.gouv.ci/datasets/liste-des-circonscriptions-administratives-et-des-communes
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || Socle commun. Jeu officiel du ministère de l'Intérieur, licence ouverte, 252 enregistrements, mise à jour 12/07/2021, qui dit 31 régions et 201 communes. MISE À JOUR DU 18/09 : ce jeu date du 12/07/2021 et il est ANTÉRIEUR au changement. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n°5 (Spécial) du 17/02/2026. Un livrable écrit donc DEUX districts autonomes, jamais douze ni quatorze. Texte primaire non lu : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66).

### CL-AWA-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Socle ~/.claude/outils-communs/droit-travail-ci/ ; art. 46 de la loi 2016-412 pour le décompte des délais
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || Socle commun, déjà sur cette machine : ~/.claude/outils-communs/droit-travail-ci/JOURS-FERIES.md distingue férié, chômé et payé article par article (art. 24.2 du Code du travail, art. 64 et 65 de la convention de 1977). Awa n'a pas de lien vers ce socle, un lien symbolique suffit. NUANCE DE MÉTIER, et elle est juridique ici : l'article 46 de la loi 2016-412 proroge au premier jour ouvrable suivant tout délai qui expire un samedi, un dimanche ou un jour férié ou chômé. Un délai de réponse mal décompté est une promesse non tenue. Les fêtes mobiles ne sont fixées par aucun texte, elles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-AWA-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || Socle commun. Source identifiée, note à fabriquer. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait. Le tarif extérieur commun n'est donc pas cité comme lu, et il y a là un écart à vérifier sur pièce, le TEC UEMOA ayant quatre bandes et celui de la CEDEAO cinq depuis 2015. Pour Awa, la distinction qui compte est ailleurs : l'OHADA couvre 17 pays, l'UEMOA 8, et la loi sur la consommation est NATIONALE. Un droit du consommateur cité comme régional serait faux.

### CL-AWA-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || Socle commun. MISE À JOUR DU 18/09, les chiffres de base sont désormais relevés sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. Règle d'usage : chiffrer en XOF d'abord, et jamais un montant en dollars sans indiquer le taux et sa date. Le SMIG reste non relevé, c'est un manque transverse distinct.

## Droit des affaires

### CL-AWA-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.ohada.org/en/uniform-acts/
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Socle commun : dix actes uniformes en vigueur (ohada.org), droit commercial général, sociétés commerciales et GIE, sûretés, procédures collectives, recouvrement et voies d'exécution, arbitrage, médiation, comptabilité SYSCOHADA, sociétés coopératives, transport de marchandises par route. La CCJA, cour commune, siège à Abidjan. NUANCE DE MÉTIER : l'OHADA sert peu un support client, le texte qui gouverne son travail est la loi NATIONALE 2016-412 sur la consommation. Une piste toutefois, non vérifiée : le vice caché n'apparaît nulle part dans la loi 2016-412, son régime est peut-être dans l'acte uniforme sur le droit commercial général.

## Langue

### CL-AWA-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Compétence parler-ivoirien (Y0487) du catalogue, à LIER au poste : elle n'y est pas
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || RÉSOLU LE 18/09, et c'était un manque d'outillage, pas de recherche : la compétence parler-ivoirien (Y0487) manquait à SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis, version du catalogue vérifiée neutre. Le corpus donne le français d'ici et la règle de registre : le premier contact reste formel, on vouvoie, l'urgence fabriquée est mal vue. ⚠ Pour un poste de relation client, c'est la règle de registre qui prime sur le lexique : reconnaître une tournure correcte d'ici évite de la corriger à tort, mais on n'écrit pas en nouchi à un client.

### CL-AWA-13 · Les formules d'adresse et de politesse en usage
- **Pourquoi** : Un ton trop sec passe pour de l'impolitesse
- **Où chercher** : Corpus parler-ivoirien, échanges réels
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, ET C'ÉTAIT UNE LIGNE DE COMPTABILITÉ. Le manque était d'outillage et il a été comblé le 18/09 : la compétence parler-ivoirien (Y0487) manquait à SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli), elle est liée sur les sept depuis, version du catalogue vérifiée neutre. Contrôle du 22/09 : le lien est bien en place dans .claude/skills/parler-ivoirien, et la colonne « Posé chez l'expert » le nomme désormais. Les formules d'adresse et de politesse sont dans ce corpus. ℹ Une compétence liée se lit directement par le poste, à la différence d'un script : c'est une pièce au sens du Mode d'emploi, pas un outil dont il faudrait d'abord tirer une note. ⚠ RÉSERVE INCHANGÉE : le corpus donne LA NORME, pas L'USAGE MAISON. Éprouver ces formules sur des échanges réels relève de CL-AWA-18 et dépend de l'accès aux historiques.

## Canaux

### CL-AWA-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : Socle commun. Établi par le corpus de Kouassi : la messagerie est le premier canal ici, devant le SMS et le courriel, utilisée par plus de 90 % des possesseurs de téléphone intelligent. RÉSERVE À CONSERVER, elle vient de lui : ses deux sources sont des éditeurs de solutions de messagerie, donc intéressées au chiffre ; il retient la pénétration, cohérente d'une source à l'autre, et rejette explicitement leurs 91 % de taux d'ouverture et 380 % de retour sur investissement, arguments commerciaux sans méthode publiée. Complément chez Fatima : memory/reference/reseaux-marques-ci.md. Ce qui reste non documenté est la part par plateforme, Facebook contre LinkedIn : bloquant pour Fatima, pas pour un support.

## Service client

### CL-AWA-11 · Les canaux par lesquels les clients d'ici écrivent vraiment
- **Pourquoi** : Ouvrir un centre d'appels quand tout se passe sur WhatsApp
- **Où chercher** : Relevés des canaux des clients de la maison
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Interne. La ligne demande les canaux DES CLIENTS DE LA MAISON, pas ceux du pays. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. CE QUE J'AI PU VÉRIFIER LE 18/09, et c'est utile : les comptes réellement connectés à Unipile sont QUATRE, trois WhatsApp et un LinkedIn, relevés par integrations/unipile/comptes.py. La messagerie est donc bien le canal branché, ce qui confirme le corpus. ⚠ L'un des trois comptes WhatsApp (22597714432) est en statut CREDENTIALS, donc déconnecté, et demande une reconnexion par un humain. ÉCART D'OUTILLAGE INCHANGÉ : Awa n'a aucune intégration de messagerie sur son propre poste (apify, brave-search, google-gogcli seulement), alors que sa compétence support-whatsapp-au-quotidien organise la tenue quotidienne de ce canal. unipile est branché chez Kouassi, chez Fatima et sur les bornes, pas chez elle.

### CL-AWA-12 · Les délais de réponse attendus ici, par canal
- **Pourquoi** : Une promesse de délai calquée sur un standard étranger
- **Où chercher** : Relevés internes, retours clients
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON RENSEIGNÉ VOLONTAIREMENT. Aucun relevé de délai attendu par canal n'existe sur cette machine, et aucune source ivoirienne sérieuse n'en publie : les chiffres qui circulent viennent d'éditeurs de logiciels de support, sans méthode ni échantillon, exactement la matière que le corpus de Kouassi a écartée pour les taux d'ouverture. Sa compétence engagement-de-delai-et-escalade (Y0430) pose la règle qui protège : AUCUN DÉLAI N'EST FIXÉ SANS QUE L'ENTREPRISE AIT CONFIRMÉ QU'ELLE PEUT LE TENIR. Un seul délai est établi et il est juridique : la circulaire BCEAO n°002-2020/CB/C fixe à UN MOIS le délai maximum de réponse à une réclamation portant sur un service financier.

### CL-AWA-23 · Le décompte des jours ouvrables, en pratique
- **Pourquoi** : Un délai mal compté est une promesse non tenue, et parfois un droit refusé
- **Où chercher** : Socle droit-travail-ci, art. 46 de la loi 2016-412
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Proposé le 18/09. L'article 46 de la loi 2016-412 proroge au premier jour ouvrable suivant tout délai qui expire un samedi, un dimanche ou un jour férié ou chômé, et l'article 11 compte en jours ouvrables. Le calendrier local porte en plus des fêtes mobiles annoncées chaque année par communiqué ministériel, donc non calculables à l'avance. La matière est déjà dans le socle droit-travail-ci, il reste à en tirer la règle de décompte.

## Réclamations

### CL-AWA-14 · Les motifs de réclamation les plus fréquents par secteur
- **Pourquoi** : Traiter chaque cas comme un cas isolé
- **Où chercher** : Historique des échanges de la maison
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Les motifs de réclamation se dépouillent sur un historique d'échanges. ACCÈS VÉRIFIÉ LE 18/09 : je n'ai pas la matière et je dis où elle manque. Mon compte [adresse interne] ne voit QUE SON PROPRE AGENDA (aucun agenda de direction partagé), sa boîte mail ne reçoit que des notifications de partage Drive (aucune correspondance métier), et il n'existe sur le Drive ni historique de tickets, ni carnet de prestataires, ni barème de gestes. Le seul corpus interne réel est celui du salon Impact IA des 9 au 11/09 (transcripts bruts par expert, déposés le 17/09), qui est de la matière de salon et non un historique client. Aucun historique de réclamation n'existe, ni sur le Drive ni dans une boîte accessible.

## Droit

### CL-AWA-15 · Les droits du consommateur en Côte d'Ivoire
- **Pourquoi** : Refuser un droit prévu par le texte
- **Où chercher** : Loi 2016-412 du 15/06/2016, base ~/.claude/outils-communs/droit-consommation-ci/ ; Conseil national de la consommation
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://faolex.fao.org/docs/pdf/Ivc172699.pdf
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Loi n° 2016-412 du 15/06/2016 relative à la consommation sur disque, 58 pages, texte exploitable, plus la circulaire BCEAO n° 002-2020/CB/C sur le traitement des réclamations. ⚠ La loi vient d'une version consolidée par un éditeur privé (droit-afrique.com) rapatriée du miroir FAOLEX : exploitable pour travailler, mais sur un point contesté c'est le Journal officiel qui fait foi. ⚠ L'extraction texte de la circulaire est VIDE, on la cite depuis le PDF. || FAIT le 18/09. La loi n°2016-412 du 15 juin 2016 relative à la consommation est désormais sur la machine, 58 pages, texte extrait et exploitable, dans une base commune NEUTRE : ~/.claude/outils-communs/droit-consommation-ci/ (avec la circulaire BCEAO et un LISEZ-MOI). LE POINT QUI CHANGE LA CONDUITE D'UNE RÉCLAMATION : une vente conclue sur une messagerie, sans présence physique simultanée, est une VENTE À DISTANCE au sens de l'article 10. L'acheteur dispose donc de DIX JOURS OUVRABLES À COMPTER DE LA LIVRAISON pour retourner le produit, pour échange ou remboursement, sans pénalités, les frais de retour restant à sa charge (art. 11). Et si le vendeur n'indique pas le nom de son entreprise, ses coordonnées téléphoniques et l'adresse de son siège, CES DIX JOURS DEVIENNENT TROIS MOIS (art. 12). PIÈGE À NE PAS REFAIRE : en cherchant « rétractation » on tombe d'abord sur dix jours à l'article 45, qui est dans la section consacrée au contrat de jouissance d'immeuble à temps partagé (art. 43 à 50). LA LOI NE POSE AUCUN DROIT DE RÉTRACTATION GÉNÉRAL : chaque délai est attaché à un type de contrat, et les confondre fait refuser un droit réel ou en accorder un qui n'existe pas. Toujours vérifier la SECTION d'un article avant de le citer. Autres appuis : art. 3 (information précontractuelle) ; art. 46 (délai expirant un samedi, dimanche ou férié prorogé au premier jour ouvrable) ; art. 69 à 71 sur les clauses abusives, avec LA CHARGE DE LA PREUVE RENVERSÉE, c'est au professionnel de prouver qu'une clause n'est pas abusive ; art. 96 (service après-vente, mentions P pour pièces, MO pour main-d'œuvre, D pour déplacement) ; art. 261 et 262 (Conseil national de la consommation). ANGLES MORTS ÉCRITS, NON COMBLÉS : les décrets d'application ne sont pas téléchargés, dont celui qui doit lister les clauses abusives (art. 69) ; AUCUNE DURÉE DE GARANTIE LÉGALE n'apparaît dans le texte, ce qui ne prouve pas qu'elle n'existe pas ailleurs ; le vice caché n'y figure pas du tout. RÉSERVE DE SOURCE : le PDF est une consolidation d'éditeur privé (en-tête droit-afrique.com) rapatriée via le miroir FAOLEX de la FAO ; pour un point contesté, c'est le Journal officiel qui fait foi et il n'est pas en accès libre.

### CL-AWA-21 · La loi 2013-450 et ce qu'on peut garder d'un échange client
- **Pourquoi** : Un support conserve des conversations, des pièces d'identité, parfois des coordonnées bancaires
- **Où chercher** : Loi 2013-450 sur la protection des données à caractère personnel, ARTCI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base données personnelles sur disque : loi n° 2013-450 du 19/06/2013 telle que publiée au Journal officiel du 08/08/2013 (p. 474 à 482), plus une seconde numérisation, la loi 2013-451 cybercriminalité et la loi 2013-546 transactions électroniques. La compétence donnees-personnelles-ci (Y0676) en est le mode d'emploi. ⛔ CES PDF N'ONT PAS DE COUCHE TEXTE : ce sont des numérisations du JO, il faut les LIRE, l'extraction ne rend rien. || Proposé le 18/09, trouvé en travaillant sur Fatima. La loi ivoirienne exige une AUTORISATION PRÉALABLE avant la constitution d'un fichier. Sa compétence support-whatsapp-au-quotidien évoque déjà le traitement des données personnelles échangées sans pouvoir s'appuyer sur le texte. Un historique de support est nominatif par nature : c'est la ligne qui expose le plus la maison. PRÉCISION DU 18/09, ma formulation était imprécise et la nuance change la charge : le régime GÉNÉRAL de la loi n°2013-450 du 19/06/2013 est la DÉCLARATION PRÉALABLE de tout traitement de données personnelles à l'ARTCI avant sa mise en œuvre, l'AUTORISATION ne visant que certaines catégories. L'ARTCI, autorité administrative indépendante et autorité de protection au titre de cette loi, statue dans un délai d'UN MOIS à compter de la réception, prorogeable d'un mois par décision motivée ; elle a un pouvoir de sanction et les manquements sont aussi punis au titre du code pénal. ⚠ TEXTE PRIMAIRE NON RAPATRIÉ : le PDF du site de l'ARTCI renvoie une page « non trouvée » depuis sa restructuration et les miroirs habituels ne le portent pas. Sources secondaires concordantes uniquement. LU SUR LE TEXTE LE 18/09 : la loi est désormais sur la machine (~/.claude/outils-communs/donnees-personnelles-ci/, Journal officiel du 08/08/2013, p. 474 à 482) et lue article par article. Ce qui change par rapport à ce qui précède. (1) ART. 11, LE SILENCE VAUT REJET : l'ARTCI statue en un mois, prorogeable d'un mois par décision motivée, et l'ABSENCE DE REPONSE dans ce délai vaut REJET de la déclaration ou de la demande, pas acceptation ; recours devant la juridiction compétente. (2) ART. 7, SIX CATEGORIES SOUS AUTORISATION et non déclaration : données génétiques ou médicales et recherche scientifique ; infractions et condamnations ; NUMERO NATIONAL D'IDENTIFICATION OU TOUT IDENTIFIANT DE MEME NATURE, Y COMPRIS LES NUMEROS DE TELEPHONE ; données biométriques ; traitement d'intérêt public à fins historiques, statistiques ou scientifiques ; TRANSFERT VERS UN PAYS TIERS. (3) ART. 6, QUATRE DISPENSES de déclaration, dont la désignation d'un correspondant à la protection des données (art. 12), dispense qui TOMBE dès qu'un transfert hors du pays est envisagé. (4) ART. 26, tout transfert hors de Côte d'Ivoire suppose un pays au niveau de protection suffisant ET l'autorisation préalable de l'ARTCI : un hébergement ou un outil de gestion client à l'étranger est un transfert. (5) ART. 51, SANCTIONS : après mise en demeure, retrait d'autorisation et sanction pécuniaire plafonnée à 10 000 000 FCFA, portée en cas de récidive dans les cinq ans à 100 000 000 FCFA ou, pour une entreprise, 5 % du chiffre d'affaires hors taxes du dernier exercice clos dans la limite de 500 000 000 FCFA, sans préjudice du pénal. (6) ART. 46, l'autorité de protection EST l'ARTCI, il n'y a pas d'autorité distincte. (7) ART. 28 à 38, droits des personnes : information au plus tard à la collecte, accès, opposition gratuite à la prospection, rectification, effacement sans délai (art. 35), portabilité. COMPETENCE ECRITE LE 18/09 : donnees-personnelles-ci (Y0676), au catalogue, adossée à ces articles. ART. 39 à 44, ce qui pèse sur un historique nominatif : le traitement est CONFIDENTIEL et n'est fait que par des personnes agissant sous l'autorité du responsable et sur ses instructions (art. 39) ; l'art. 41 énumère dix mesures de sécurité exigibles, dont la TRACABILITE A POSTERIORI de qui a accédé à quoi et quand ; le responsable ET le sous-traitant répondent des mesures (art. 20 et 40) ; un RAPPORT ANNUEL sur le respect de l'art. 41 est dû à l'ARTCI (art. 42) ; les durées de conservation sont fixées par l'ARTCI selon la finalité (art. 43).

## Paiement

### CL-AWA-16 · Les incidents de paiement courants : mobile money, virement
- **Pourquoi** : Accuser le client d'un incident bancaire
- **Où chercher** : Circulaire BCEAO n°002-2020/CB/C et Commission bancaire de l'UMOA ; relevés internes pour le terrain
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/centralisation-des-incidents-de-paiement
- **Pièce, ici** : references/pieces/1yA9urPYjlkqUB8g8Istz9jSQ8fmpFakyAyYYwcAnmYo.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, et deux choses ont changé depuis le 18/09. (1) LE DÉFAUT D'EXTRACTION EST RÉPARÉ : la circulaire BCEAO 002-2020/CB/C était un PDF numérisé sans couche de texte, elle a reçu une reconnaissance de caractères ce jour et se lit maintenant. ⚠ L'original fait toujours foi, toute valeur citée se revérifie sur le PDF. (2) Note neuve bases-locales/droit-consommation-ci/RECLAMATIONS-FINANCIERES.md. ⛔ LE POINT QUI RÉPOND VRAIMENT À LA LIGNE : SON ARTICLE 2 COUVRE LES ÉTABLISSEMENTS DE MONNAIE ÉLECTRONIQUE, donc le mobile money. Un incident sur Orange Money, MTN MoMo, Wave ou Moov Money relève du même circuit qu'un incident bancaire, ce qui répond à la question qu'on se pose en premier, à qui se plaindre. LE CIRCUIT A DEUX ÉTAGES. Étage 1, l'établissement : il doit ENREGISTRER chaque réclamation, RÉPONDRE EN UN MOIS AU PLUS à compter de la réception (art. 7), ET LE TRAITEMENT EST GRATUIT (art. 8), un établissement qui le facture est en faute. Étage 2, la Commission bancaire de l'UMOA, saisissable faute de réponse dans le mois, par courrier postal ou électronique au Secrétariat général ou par dépôt à la Direction nationale. QUATRE CONDITIONS DE RECEVABILITÉ, dont une qui piège : ⛔ LA RÉCLAMATION NE DOIT PAS ÊTRE DÉJÀ DEVANT UNE INSTANCE judiciaire, extra-judiciaire ou administrative, en particulier les observatoires de la qualité des services financiers. Ne pas saisir deux instances à la fois. DÉLAIS : 30 jours calendaires pour fournir les pièces complémentaires, à défaut LA DEMANDE EST REJETÉE ; 60 jours calendaires d'instruction sur dossier complet, délai SUSPENDU par toute demande de pièces. Le chemin complet se compte donc en mois, pas en jours, et il est gratuit. Contacts : courrier.z02sgcb@bceao.int, +225 27 20 25 57 57. La BCEAO tient par ailleurs une centralisation des incidents de paiement. ⛔ CE QUI MANQUE, ET C'EST LA MOITIÉ TERRAIN : quels incidents reviennent, sur quel opérateur, et quel geste les règle. Cela se relève sur des dossiers réels, pas dans un texte. ⛔ AUCUNE PART DE MARCHÉ D'OPÉRATEUR RETENUE : les sources publiques se contredisent frontalement, l'une donnant Wave à 40 %, l'autre Orange à 55 % et Wave à 35 %.

## Escalade

### CL-AWA-22 · Les recours du client hors de la maison
- **Pourquoi** : Savoir ce qui arrive si on ne répond pas change la manière de traiter une réclamation
- **Où chercher** : Conseil national de la consommation, Commission bancaire de l'UMOA, ARTCI
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : Proposé le 18/09, et à moitié servi par la base droit-consommation-ci. Trois voies selon la nature du litige : le Conseil national de la consommation, institué auprès du ministre chargé du Commerce (art. 261 et 262 de la loi 2016-412), pour les biens et services ; la Commission bancaire de l'UMOA pour les services financiers, après un mois sans réponse satisfaisante ; l'ARTCI pour les télécommunications. Reste à vérifier la procédure de saisine de chacune.
