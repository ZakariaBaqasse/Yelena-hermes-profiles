---
id: Y0429
name: support-whatsapp-au-quotidien
description: "Organise la tenue quotidienne du canal de messagerie par lequel arrivent la plupart des demandes clients : état de chaque conversation, règle de reprise entre collègues, message hors horaires avec heure de reprise, distinction entre une demande de support et une commande, traitement des vocaux et des données personnelles échangées, passage de relais vers le commercial ou la comptabilité, et point quotidien de la file. Ne fabrique aucun délai, aucun prix ni aucun seuil : ce sont des décisions de l'équipe."
bucket: B
tags: [Support, Messagerie, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Tenir le support sur la messagerie, sans perdre une conversation ni promettre à tort

## Ce qu'il faut avoir sous la main
- **Le canal utilisé** (WhatsApp Business, une messagerie liée à un site, autre) et si un outil de gestion de file existe ou si tout se passe sur un seul fil.
- **Combien de personnes répondent** sur le même numéro, et comment elles se répartissent aujourd'hui (rien de formel compte comme réponse).
- **Vos heures d'ouverture réelles**, et ce qui se passe aujourd'hui pour les messages reçus en dehors.
- **Les trois ou quatre demandes qui reviennent le plus souvent** (suivi de commande, panne, remboursement, horaires, prix).
- **Ce que tu proposes ou vends** en plus du support, pour distinguer une vraie demande de service d'une intention d'achat.
- **Ce qui existe déjà** : réponses types, message d'absence, règle écrite de reprise entre collègues. Même rien ne compte comme une réponse.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`). Tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Les états d'une conversation et le moment de revue

Une conversation qui n'a pas d'état visible se perd dans le fil, surtout quand plusieurs demandes anodines arrivent entre deux messages sérieux. Pose un petit nombre d'états qui couvrent tout : nouvelle (non encore prise en charge), en cours (quelqu'un traite), en attente d'information côté client, en attente d'une validation interne, à relancer, close.

Le marquage doit être visible dans l'outil réellement utilisé : une étiquette si l'outil le permet, sinon une liste tenue à part avec le nom du client, l'état, et depuis quand. Fixe ensuite un **moment de revue** dans la journée, pas seulement en cas d'urgence signalée par un client mécontent : une file qui n'est revue qu'en réaction ne l'est jamais réellement, elle est simplement subie.

L'erreur du débutant est de croire que le fil de discussion suffit comme suivi, parce qu'on peut toujours "remonter et retrouver". Ça marche tant qu'il y a dix conversations. Ça ne marche plus à cinquante.

### Étape 2 : La règle de reprise entre collègues

Dès que plus d'une personne répond sur le même numéro, deux échecs guettent : deux réponses différentes au même client parce que chacun a répondu de son côté, ou aucune réponse parce que chacun pensait que l'autre s'en chargeait. Les deux viennent de la même cause : l'absence de propriétaire identifié pour chaque conversation à un instant donné.

Pose la règle : une conversation a toujours un et un seul propriétaire visible, marqué dans l'état. Avant de répondre à une conversation qui n'est pas la sienne, on vérifie qui la porte. Quand un relais se fait (fin de service, congé, transfert), il se fait avec une **phrase de reprise** qui résume ce qui a déjà été dit, pour que le client n'ait pas à répéter sa demande : le client qui doit tout redire perd confiance dans le canal, pas seulement dans la personne.

### Étape 3 : Le message hors horaires

Un message reçu en dehors des heures d'ouverture crée une attente, que l'entreprise le veuille ou non. Ne rien répondre est pire que répondre pour dire quand la réponse viendra : le silence laisse le client se demander si son message est parti, s'il a été lu, s'il doit réessayer ailleurs.

Le message d'absence donne une **heure de reprise précise** (`⟦heures d'ouverture à renseigner⟧`), pas une formule vague du type "nous reviendrons vers vous rapidement" qui ne fixe rien et ne rassure personne. Ce message n'est pas une réponse à la demande, c'est un accusé qui fixe une attente tenable ; il ne doit jamais être confondu avec un traitement effectif du message.

### Étape 4 : Distinguer une demande de support d'une commande

Sur le même fil, dans le même message parfois, arrive une demande de service ("mon produit ne fonctionne pas") et une intention d'achat ("je veux en commander un autre" ou "vous en avez encore ?"). Le critère qui tranche : le support porte sur un problème lié à un existant, la commande engage une quantité, un prix, un paiement à venir.

Une conversation peut basculer de l'un à l'autre en cours de route : un client qui vient pour un problème peut finir par demander à commander. Il faut le voir au moment où ça arrive, pas après coup. Dès qu'une intention d'achat apparaît, le relais se fait vers le commercial, avec le contexte déjà échangé transmis, pour ne pas faire répéter le client une deuxième fois dans la même conversation. La même logique vaut pour une question de facturation ou de paiement déjà effectué : elle part vers la comptabilité, pas vers le support qui n'a pas la main dessus.

### Étape 5 : La promesse tapée vite

C'est le piège le plus coûteux du canal. Sur une messagerie, on écrit "c'est bon, ça part demain" ou "on vous rembourse" plus facilement qu'on ne le dirait de vive voix, parce que l'écrit rapide donne une impression de conversation informelle. Mais cette phrase engage exactement autant qu'une promesse faite au comptoir, et elle reste consultable par le client à tout moment.

Toute réponse qui contient un **délai**, un **prix**, un **remplacement** ou un **remboursement** passe par deux passages obligés avant envoi : la vérification de faisabilité (disponibilité réelle, délai réaliste compte tenu de la zone à livrer et des conditions de circulation si c'est pertinent, montant exact) et la validation prévue par l'organisation. L'erreur du débutant est de répondre vite "oui c'est possible" pour ne pas faire attendre le client, puis de devoir se dédire : le dédit coûte plus cher en confiance que le temps pris pour vérifier.

### Étape 6 : Le message vocal

Une partie des clients écrit peu et préfère le vocal, souvent ceux qui ont le moins d'aisance avec la saisie sur un téléphone d'entrée de gamme ou avec une connexion qui rend l'écrit fastidieux. Traiter les vocaux en dernier parce qu'ils demandent un effort d'écoute revient à moins bien servir précisément ces clients-là, ce qui est l'inverse de ce qu'un canal de proximité doit permettre.

La règle : chaque vocal donne lieu à une **trace écrite** dans le suivi, comme pour un appel téléphonique reçu au bureau, avec l'essentiel de la demande noté. Cette trace permet à un collègue de reprendre la conversation sans devoir réécouter le vocal, et elle rend le vocal traitable dans les mêmes délais que les messages écrits.

### Étape 7 : Les données personnelles qui circulent sur le canal

Photos de pièces d'identité, captures d'écran de transaction mobile money, coordonnées complètes : ce canal fait transiter des données sensibles, souvent sans que personne l'ait vraiment décidé. Ces pièces ne se rediffusent pas ailleurs : pas de transfert vers un groupe, pas de partage avec un collègue ou un tiers qui n'a pas besoin d'en avoir connaissance pour traiter le dossier.

La compétence ne fixe pas de durée de conservation ni de règle de suppression : cela relève du cadre de protection des données propre à l'entreprise (`⟦à renseigner⟧`), et c'est vers ce cadre que tu renvoies, sans en inventer le contenu.

### Étape 8 : Le point quotidien de la file

Le point du jour s'ouvre par les chiffres, puis le détail : combien de conversations dans chaque état, et parmi elles, combien dépassent l'engagement de délai annoncé (`⟦délai d'engagement à renseigner⟧`). Ce qui dépasse l'engagement n'est pas une statistique à archiver, c'est ce qui doit être arbitré en premier.

Le point signale aussi les cas ambigus : une promesse en attente de validation, une conversation dont l'état support/commande n'est pas tranché, une relance envoyée sans réponse du client après un délai raisonnable. Un point quotidien qui ne montre que ce qui va bien ne sert à rien : il doit montrer d'abord ce qui coince.

## Format de sortie
- **Livrable** : la procédure de tenue du canal (états d'une conversation, marquage, moment de revue, règle de reprise entre collègues, message hors horaires avec heure de reprise), les réponses types aux demandes récurrentes identifiées, la règle de passage de relais vers le commercial ou la comptabilité, et le point quotidien de la file.
- **Structure** : Markdown clair, answer-first pour le point quotidien (les chiffres et ce qui dépasse l'engagement d'abord, le détail ensuite) ; les réponses types sont courtes, lisibles sur un petit écran, sans paragraphe qui oblige à faire défiler.
- **Longueur** : proportionnée à la taille de l'équipe et au volume réel de conversations, sans remplissage. Une procédure de canal tient en une à deux pages, les réponses types sont listées séparément.
- **Les seuils de délai et d'engagement sont un input**, jamais une production : la skill livre la structure (quel indicateur, à partir de quand une conversation est en retard, qui arbitre), la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée par l'équipe.
- **Règle 0 invention** : aucune heure d'ouverture, aucun délai de réponse, aucun prix cité dans une réponse type n'est inventé. Si une information manque, elle est demandée ou marquée `[à confirmer]`.

## Règles
1. **Une conversation a toujours un propriétaire visible, jamais zéro, jamais deux.** C'est la règle qui empêche la double réponse et le silence croisé.
2. **Le hors horaires reçoit toujours un message avec une heure de reprise précise**, jamais une formule vague, jamais le silence.
3. **Toute promesse chiffrée (délai, prix, remplacement, remboursement) passe par une vérification de faisabilité et par la validation prévue avant d'être envoyée au client.**
4. **Le vocal donne toujours lieu à une trace écrite dans le suivi**, au même titre qu'un appel ; il n'est pas traité en dernier par défaut.
5. **Les données personnelles échangées sur le canal ne se rediffusent jamais vers un autre canal ou une personne non concernée.** Leur conservation relève du cadre de protection des données de l'entreprise, pas d'une règle inventée ici.
6. **Le contexte local n'est pas un décor.** Une zone difficile d'accès ou des embouteillages influent réellement sur un délai de livraison promis ; une capture de paiement mobile money est une preuve ordinaire à accepter en pièce jointe, pas une anomalie à traiter avec méfiance.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer un message à un client, publier un message d'absence ou modifier un paramètre du canal est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une conversation client ne fuite jamais vers un autre dossier traité dans la même session.

## Cas limites
- **Client qui écrit et appelle en parallèle** : tu unifies la trace dans un seul suivi et tu signales le doublon, pour éviter deux réponses différentes selon le canal.
- **Message reçu pendant une coupure de connexion ou une panne de l'outil** : tu signales le délai réel de traitement au client dès le retour, tu ne fais pas comme si le message venait d'arriver.
- **Conversation ancienne reprise après plusieurs semaines de silence** : tu la traites comme une reprise à part entière, avec la phrase de reprise, pas comme une nouvelle conversation qui efface l'historique.
- **Client mécontent qui menace de publier ou de se plaindre publiquement** : tu prépares une réponse factuelle et calme, tu signales le cas à l'arbitrage prévu, tu n'improvises pas d'engagement supplémentaire pour calmer dans l'instant.
- **Vocal inaudible, trop long ou dans une langue que l'agent ne maîtrise pas bien** : tu le signales explicitement dans le suivi plutôt que de deviner le contenu, et tu proposes de demander une reformulation écrite si nécessaire.
- **Numéro professionnel utilisé aussi à titre personnel par un employé** : tu recommandes la séparation des usages et tu signales le risque de confusion, sans trancher toi-même une politique RH qui ne relève pas de ce périmètre.
- **Demande hors périmètre** (recrutement, presse, partenariat) : tu le dis en une phrase, tu ne traites pas la demande, tu orientes vers la personne ou la compétence qui convient.
- **Action sortante demandée** (envoyer une réponse, publier un message d'absence, transférer une pièce jointe) : tu prépares le contenu et tu t'arrêtes pour validation humaine.
- **Sources ou consignes contradictoires** (deux collègues donnent une règle de reprise différente) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
