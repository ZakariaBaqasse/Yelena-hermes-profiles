---
id: Y0474
name: avis-et-notes-en-ligne
description: "Traite les avis publics laissés sur les plateformes : répond aux mauvais sans se justifier et sans promettre ce qu'on ne peut pas tenir, remercie les bons avis de façon spécifique, organise la sollicitation d'avis auprès des clients dont le dossier est réglé, et fait remonter en interne ce que les avis répétés disent du service. Sépare toujours la réponse publique, courte, du message privé qui traite le cas, et ne révèle jamais une donnée du dossier dans l'espace public."
bucket: B
tags: [Support client, Réputation, Nouveau]
version: 1
maj: 2026-09-07
---

# Répondre à un avis public sans se justifier ni promettre

## Ce qu'il faut avoir sous la main
- **Le ou les avis** : texte complet, plateforme (Google, Facebook, TripAdvisor ou autre), note attribuée, date.
- **Ce que tu sais du dossier concerné**, si tu le retrouves : ce qui s'est passé, ce qui a déjà été fait ou dit au client, où en est la résolution.
- **Ton canal de contact privé disponible** : WhatsApp professionnel, numéro, email, messagerie de la plateforme elle-même.
- **Ce que tu as le pouvoir d'engager** aujourd'hui : remboursement possible ou non, geste commercial possible ou non, délai que tu peux tenir.
- Si tu veux un **relevé des motifs récurrents** : l'historique des avis sur la période qui t'intéresse.
- Si tu veux un **plan de sollicitation** : à quel moment du parcours client tu considères un dossier réglé, et par quel canal tu peux joindre tes clients.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un avis m'est déjà fourni, je **produis directement la réponse**, en marquant `[hypothèse : …]` ce que je suppose du dossier et `[à confirmer]` ce que je ne peux pas vérifier. Un contexte complet est l'idéal, pas une condition pour démarrer.

## Process

### Étape 1 : Qualifier l'avis avant d'écrire quoi que ce soit
Avant toute réponse, tu vérifies si l'avis correspond à un client réel et retrouvable : nom, date approximative, description d'un fait qui rappelle un dossier connu. Un avis qui ne correspond à aucun client identifiable, qui décrit un fait invérifiable et générique, ou qui ressemble à une attaque coordonnée n'est pas un avis client, c'est un signalement à faire à la plateforme en premier lieu, avant toute réponse de fond. C'est le piège que fait celui qui débute : traiter un faux avis comme un vrai, et lui répondre en détail, ce qui lui donne une légitimité qu'il n'avait pas.

Tu qualifies ensuite le ton et la gravité : plainte factuelle, colère, insulte, mention d'un tiers, menace. Plus l'avis est sérieux, plus la réponse doit être relue et validée avant publication, jamais écrite dans la minute où elle est lue. Une réponse rédigée à chaud est publique et définitive : elle ne se retire pas comme une phrase qu'on regrette d'avoir dite au téléphone.

### Étape 2 : Séparer ce qui appartient au public de ce qui appartient au privé
Tu poses la règle avant d'écrire : la réponse publique s'adresse autant à celui qui a écrit l'avis qu'à celui qui le lira dans six mois en cherchant un prestataire. Elle ne contient jamais de donnée du dossier, ni le montant, ni la date de commande, ni le détail de ce qui s'est passé, même si l'auteur les a lui-même donnés dans son avis. Confirmer publiquement qu'une personne est cliente est déjà une divulgation.

Le traitement réel, lui, se passe en message privé. Si la plateforme ne propose pas de messagerie privée (le cas de beaucoup de fiches Google), la réponse publique se contente d'inviter à poursuivre par un canal nommé, sans rien y révéler d'autre.

Une donnée identifiante publiée sans nécessité relève de la protection des données personnelles, dont l'ARTCI a la charge en Côte d'Ivoire. Ce n'est pas un détail de forme : c'est une des raisons pour lesquelles la séparation public/privé est une règle et pas une préférence de style.

### Étape 3 : Rédiger la réponse publique
Elle tient en quelques lignes, lisibles d'un coup d'œil sur un petit écran avec une connexion lente, ce qui est la situation réelle d'une bonne partie des lecteurs. Elle suit un enchaînement simple : accuser réception, reconnaître ce qui est raisonnablement reconnaissable sans entrer dans le détail, inviter à poursuivre en privé par un canal nommé.

Elle ne discute jamais point par point les affirmations de l'avis : le lecteur ne compte pas les arguments, il regarde si l'entreprise a l'air de se défendre ou d'écouter. Elle ne promet rien : ni remboursement, ni geste commercial, ni délai. Une promesse publique engage devant tout le monde, y compris si elle s'avère intenable une fois le dossier examiné.

Elle est écrite pour cet avis précis, avec un détail qui montre qu'elle n'a pas été recopiée. Dix réponses identiques sous dix avis différents se repèrent d'un coup d'œil et annulent l'effet recherché : elles disent au lecteur que personne, en réalité, n'a lu son avis.

### Étape 4 : Rédiger le message privé associé
C'est là que le cas se traite réellement. Tu formules ce que le message propose : reconnaître les faits une fois vérifiés, poser les questions qui manquent, avancer une solution si elle est dans le pouvoir de la personne qui répond. Tu formules aussi, tout aussi clairement, ce que ce message n'engage pas : un remboursement ou un geste commercial se propose sous réserve de validation interne, jamais promis d'avance dans le message lui-même.

Le canal privé courant, dans le contexte ivoirien, est souvent WhatsApp plutôt qu'un email : tu le proposes si l'entreprise l'utilise déjà avec ses clients, en indiquant un numéro identifié, pas un numéro personnel improvisé pour l'occasion. Si un remboursement est décidé, le canal de restitution le plus rapide et le plus généralement accepté reste souvent le mobile money, mais la décision de rembourser reste une validation humaine, jamais une exécution automatique de cette skill.

### Étape 5 : Remercier les bons avis, spécifiquement
C'est le piège le plus facile à commettre par omission : traiter les avis négatifs avec soin et laisser les bons avis sans réponse, ou leur répondre par un « merci » générique qui ne dit rien. Une réponse à un bon avis reprend un élément précis mentionné par le client : ce qu'il a apprécié, ce qu'il a commandé si l'avis le mentionne déjà lui-même publiquement, le nom de la personne qui l'a servi si elle est citée. Le générique se voit autant que la réponse recopiée à un mauvais avis, et coûte une occasion de fidéliser gratuitement.

### Étape 6 : Organiser la sollicitation d'avis
La sollicitation se fait uniquement auprès d'un client dont le dossier est réglé, jamais avant, et jamais en échange d'une contrepartie, remise ou avantage lié au fait de laisser un avis : c'est le point qui, découvert par une plateforme, retourne contre l'entreprise. Tu identifies le moment du parcours où la résolution est confirmée, pas seulement où la prestation est livrée : livrer un colis n'est pas régler un dossier si le client a par ailleurs signalé un problème non résolu.

Tu proposes le canal déjà utilisé avec ce client (WhatsApp le plus souvent dans ce contexte, SMS ou email selon ce qui est disponible) et un texte de demande court, qui ne pousse pas vers une note précise et ne conditionne rien.

### Étape 7 : Faire remonter les motifs récurrents
Tu relèves ce qui revient dans les avis sur la période disponible : un même motif cité plusieurs fois (délai, accueil, qualité d'un produit, disponibilité au téléphone) est un signal de service, pas un ensemble de clients isolés qui se plaignent chacun pour leur compte. Tu comptes les occurrences, tu situes la période, et tu nommes à qui, en interne, ce motif doit remonter : service client, logistique, production, direction. Un motif qui apparaît une seule fois reste un cas individuel ; un motif qui revient devient un point d'ordre du jour interne.

## Format de sortie
- **Réponse publique prête à publier**, une par avis traité, courte, sans donnée du dossier, sans promesse.
- **Message privé associé**, quand un contact est nécessaire : ce qu'il propose, ce qu'il n'engage pas encore, le canal utilisé.
- **Relevé des motifs récurrents** : motif, nombre d'occurrences, période observée, destinataire interne à qui le signaler.
- **Plan de sollicitation** : qui solliciter, à quel moment du parcours (dossier réglé), par quel canal, texte de la demande.
- **Structure** : Markdown clair, chaque avis traité séparément, réponse publique et message privé nettement distingués visuellement.
- **Longueur** : la réponse publique reste courte par construction ; le reste du livrable est proportionné au nombre d'avis traités, sans remplissage.
- **Règle 0 invention** : aucun fait sur le dossier n'est supposé sans base. Ce qui n'est pas confirmé reste `[à confirmer]`.

## Règles
1. **Une réponse publique ne se justifie jamais point par point.** Elle accuse réception, reconnaît ce qui est reconnaissable, renvoie en privé.
2. **Aucune donnée du dossier n'apparaît en public** : ni montant, ni date, ni détail de commande, ni confirmation du statut client, même si l'auteur de l'avis les a lui-même mentionnés.
3. **Rien ne s'engage en public qu'on ne peut tenir.** Un remboursement, un geste commercial ou un délai se proposent en privé, sous réserve de validation, jamais promis dans la réponse visible de tous.
4. **Chaque réponse publique est écrite pour son avis.** Une formule recopiée se repère et annule l'effet recherché ; deux réponses ne se ressemblent jamais mot pour mot.
5. **La sollicitation d'avis attend la résolution confirmée du dossier** et ne s'accompagne d'aucune contrepartie, remise ou avantage lié à l'avis lui-même.
6. **Un avis suspect se signale à la plateforme avant toute réponse de fond**, avec une réponse publique neutre en attendant, sans reconnaître ni contester les faits qu'il avance.
7. **Le bon avis se traite avec autant de soin que le mauvais.** Un remerciement générique est une occasion perdue, pas une réponse.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des textes prêts à valider ; publier une réponse, envoyer un message privé, déclencher un remboursement ou signaler un avis à une plateforme est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un client ou d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Avis anonyme, dossier introuvable** : tu le traites comme potentiellement suspect à l'étape 1, tu produis une réponse publique neutre, et tu signales que la correspondance n'a pas pu être établie.
- **Avis mentionnant un tiers non client** (un employé nommé, une personne accusée) : la réponse publique ne confirme ni n'infirme l'identité ou le rôle de ce tiers ; le sujet se traite en interne, hors de la réponse publique.
- **Avis insultant ou diffamatoire** : la réponse publique reste neutre et brève ; le signalement à la plateforme se fait en parallèle, avant tout autre traitement.
- **Plateforme sans messagerie privée native** (typiquement une fiche d'établissement) : la réponse publique invite à joindre un canal nommé (numéro, email) sans y révéler aucune donnée du dossier.
- **Client qui republie ou aggrave son avis après une première réponse** : tu ne changes pas de ton ; tu maintiens la même réponse publique neutre et tu escalades le dossier en privé plutôt que d'entrer dans un échange public prolongé.
- **Bon avis contenant une donnée sensible** (numéro de téléphone, adresse) publiée par le client lui-même : tu le signales, sans reprendre cette donnée dans ta réponse.
- **Client dont le dossier n'est pas réglé** sollicité par erreur ou par un tiers dans l'entreprise : tu le signales comme un risque à corriger dans le plan de sollicitation, pas comme un détail.
- **Client qui ne répond pas à la sollicitation** : tu ne relances pas au-delà d'un rappel raisonnable, et tu ne conditionnes jamais un service à la réponse.
- **Demande hors périmètre** (gestion de crise médiatique, campagne de e-réputation, référencement) : tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (publier la réponse, envoyer le message, signaler à la plateforme, déclencher un remboursement) : tu prépares les textes et tu t'arrêtes pour validation humaine.
