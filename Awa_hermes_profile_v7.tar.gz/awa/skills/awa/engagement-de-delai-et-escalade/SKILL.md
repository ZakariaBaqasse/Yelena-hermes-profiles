---
id: Y0430
name: engagement-de-delai-et-escalade
description: "Construit la grille de gravité, le chemin d'escalade et les messages d'étape d'un support client : sous quel délai on accuse réception, sous quel délai on répond réellement, ce qui prime, qui prend le relais quand ça déborde et quand. La gravité se fonde sur l'impact réel du client, jamais sur son insistance, et aucun délai n'est fixé sans que l'entreprise ait confirmé qu'elle peut le tenir."
bucket: B
tags: [Support, Engagement, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Ce qu'on promet au client, et à qui on passe la main quand ça déborde

## Ce qu'il faut avoir sous la main
- **Les canaux** par lesquels les demandes arrivent réellement : téléphone, WhatsApp, email, guichet, réseaux sociaux, et lequel domine.
- **Les délais que ton équipe tient déjà**, même approximatifs : combien de temps avant qu'une demande soit accusée réception, combien avant une première réponse utile, par type de demande si ça varie.
- **Les responsables mobilisables pour l'escalade** : noms ou fonctions, et leur disponibilité réelle (pas seulement leur titre).
- **Trois ou quatre demandes passées**, racontées avec leur impact réel sur le client : ce qui a fait le plus mal, ce qui était bénin, même si le ton du client ne le montrait pas.
- **Un engagement de service déjà publié**, s'il en existe un (page web, CGU, contrat), sinon dis-le simplement.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les délais manquants `⟦à renseigner⟧` : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1, Vérifier que l'engagement est tenable avant de l'écrire

Avant toute grille, pose la question qui manque presque toujours : est-ce que l'équipe qui va tenir ce délai a été consultée, ou est-ce que le délai vient d'une intuition commerciale ou d'un chiffre trouvé « ailleurs » ? Un engagement affiché sans vérification auprès de ceux qui répondent au téléphone ou au guichet est une promesse en l'air.

Si l'entreprise donne un délai, tu le prends et tu le formalises. Si elle ne le donne pas, tu ne le complètes jamais avec une valeur plausible : tu marques `⟦à renseigner⟧` et tu poses la question précise qui permettrait à l'équipe de la trancher (sur combien de dossiers du mois dernier ce délai aurait-il tenu ?).

Signale spécifiquement le cas d'un canal saturé ou peu fiable, WhatsApp géré depuis un seul téléphone, une ligne qui coupe faute de réseau stable, un accusé de réception qui suppose une connexion que le client n'a pas au moment où il écrit : un engagement doit tenir compte du canal réel, pas du canal idéal.

### Étape 2, Construire la grille de gravité à partir de l'impact, pas du ton

La gravité ne se mesure jamais à l'insistance du client. Celui qui rappelle trois fois et hausse le ton n'est pas forcément celui qui perd le plus ; le client silencieux dont la ligne de production s'est arrêtée pour la journée ne rappellera pas, il changera de fournisseur.

Construis les niveaux de gravité à partir d'une seule question par cas : qu'est-ce que ce problème coûte réellement au client, en temps, en argent, en risque, s'il n'est pas traité aujourd'hui ? Utilise les exemples que l'entreprise t'a donnés pour ancrer chaque niveau dans du concret ; un niveau sans exemple réel reste une abstraction que personne n'appliquera correctement sous pression.

Chaque niveau reçoit ensuite le délai correspondant, fourni par l'entreprise à l'étape 1. Un niveau grave avec un délai plus long qu'un niveau mineur est une incohérence à signaler avant de livrer, pas à corriger silencieusement.

### Étape 3, Construire le chemin d'escalade avec des noms et des moments

Un chemin d'escalade qui pointe vers une fonction (« la direction », « le service technique ») sans nom ni disponibilité vérifiée n'est pas un chemin, c'est un vœu. Pour chaque niveau de gravité, fixe : qui est le responsable nommé à ce niveau, à quel moment précis (délai écoulé depuis l'ouverture, ou depuis le niveau précédent) on lui transmet le dossier, ce qu'on lui transmet exactement (pas juste « le client est mécontent »), et le délai au terme duquel, faute de réponse, on monte encore d'un cran.

Tiens compte des contraintes réelles de disponibilité : un responsable technique qui se déplace sur site à Abidjan peut être bloqué dans les embouteillages une bonne partie de la journée, un responsable joignable seulement par WhatsApp en soirée n'est pas disponible pendant les heures ouvrées annoncées. Le chemin d'escalade doit correspondre à la vie réelle des personnes qui le composent, pas à leur organigramme.

Un dossier qui atteint le dernier niveau sans solution n'est pas un échec du chemin d'escalade, c'est un signal que la grille elle-même remonte au comité qui l'a construite : dis-le, et propose de revoir le niveau concerné.

### Étape 4, Concevoir les messages d'étape

Un client sans nouvelles suppose qu'on l'a oublié, même quand le dossier avance. Prévois un message d'avancement à intervalle défini par le niveau de gravité (plus le niveau est grave, plus l'intervalle est court), qui dit où en est le dossier même quand il n'y a rien de neuf : « toujours en cours, voici ce qui a été fait, voici la prochaine étape prévue » vaut mieux que le silence.

Prépare quatre messages types : l'accusé de réception (immédiat, confirme que la demande est prise en compte et donne le délai engagé), le message d'avancement (périodique, factuel), le message de dépassement de délai (si le délai engagé n'est pas tenu, il faut le dire avant que le client le constate lui-même, avec la raison et le nouveau délai), et le message de clôture. Adapte la forme au canal réel : un message WhatsApp court et lisible sur un téléphone d'entrée de gamme, un SMS si la connexion data est incertaine, un appel si le dossier est grave et que l'écrit prend trop de temps à composer.

### Étape 5, Le message de clôture, toujours explicite

Une demande résolue mais jamais annoncée comme telle reste ouverte dans la tête du client : il revient, ouvre un nouveau dossier, et le compte de la gravité repart à zéro alors que le problème était déjà réglé. Le message de clôture dit clairement que c'est terminé, résume ce qui a été fait, et donne un moyen de rouvrir si le problème persiste.

### Étape 6, Vérifier la portée contractuelle avant publication

Un engagement de service affiché publiquement (site, contrat, conditions générales) peut engager l'entreprise juridiquement, pas seulement commercialement. Tu construis la grille et les messages, mais tu ne formules jamais la version publiée finale comme un texte contractuel validé : tu la transmets à un avis juridique compétent avant toute publication, et tu le dis explicitement dans le livrable.

## Format de sortie
- **Livrable** : la grille de gravité (niveaux, définition par l'impact, exemples réels fournis, délai associé), le chemin d'escalade (tableau : niveau, responsable nommé, moment de la remontée, contenu transmis, délai avant le niveau suivant), et les quatre messages d'étape (accusé de réception, avancement, dépassement de délai, clôture) déclinés par canal principal utilisé.
- **Structure** : Markdown, tableaux pour la grille et le chemin d'escalade, blocs de texte courts pour les messages types.
- **Longueur** : proportionnée au nombre de niveaux de gravité et de canaux réellement utilisés, sans remplissage.
- **Les délais sont un input**, jamais une production : la skill livre la structure, les niveaux, les colonnes ; la valeur du délai vient de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucun délai, nom de responsable ou taux de résolution inventé. Une information manquante est demandée ou marquée `[à confirmer]`.

## Règles
1. **Aucun délai n'est fixé de ta propre autorité.** Le délai vient de l'entreprise, vérifié auprès de ceux qui répondent réellement. Un délai plausible mais non confirmé reste `⟦à renseigner⟧`.
2. **La gravité se juge sur l'impact, jamais sur l'insistance.** Un client silencieux qui perd gros pèse plus qu'un client bruyant pour un désagrément mineur ; chaque niveau s'appuie sur un exemple réel, pas sur une définition abstraite.
3. **Chaque niveau d'escalade porte un nom et un moment**, jamais une fonction seule. « On fait remonter » sans destinataire identifié et sans délai de retour n'est pas une escalade.
4. **Le silence pendant la résolution est une faute**, pas une option acceptable. Un message d'avancement est dû à intervalle régulier, même sans nouvelle information.
5. **Une clôture non annoncée n'est pas une clôture.** Le client doit savoir explicitement que le dossier est terminé.
6. **Un engagement publié peut être contractuel.** Sa formulation finale destinée à publication est toujours renvoyée à un avis juridique compétent, jamais validée par la skill seule.
7. **Le canal réel prime sur le canal idéal.** Un engagement pensé pour l'email ne se transpose pas tel quel à un support tenu sur WhatsApp depuis un téléphone d'entrée de gamme avec une connexion instable.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; publier un engagement de service, l'inclure dans un contrat, ou envoyer un message à un client est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un dossier client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis la structure complète avec ce que tu as, tu étiquettes tes hypothèses (`[hypothèse : …]`) et tu marques les délais manquants `⟦à renseigner⟧`. Tu ne redemandes que ce qui est réellement indispensable.
- **Aucun délai confirmé par l'entreprise** : tu livres la grille et le chemin d'escalade avec toutes les valeurs en `⟦à renseigner⟧`, et tu poses la question précise qui permettrait de les trancher plutôt que d'en proposer une par défaut.
- **Aucun responsable disponible nommé pour un niveau donné** : tu le signales explicitement comme un trou dans le chemin d'escalade, tu ne combles jamais avec une fonction générique.
- **Canal qui coupe ou peu fiable** (réseau instable, téléphone partagé, connexion coûteuse) : tu le mentionnes dans le choix du message et de sa fréquence, et tu privilégies la forme la plus robuste au canal réel (SMS ou appel plutôt qu'un message qui suppose une connexion stable).
- **Client injoignable pendant la résolution** : tu prépares un protocole de relance à intervalle défini et une trace de chaque tentative, sans inventer de règle sur le nombre de tentatives si l'entreprise ne l'a pas donné.
- **Demande dupliquée sur plusieurs canaux** (même client, WhatsApp et appel) : tu signales le risque de double traitement et proposes un point de centralisation, sans trancher toi-même quel canal prime si l'entreprise ne l'a pas précisé.
- **Engagement déjà publié mais visiblement intenable** au vu des délais réels fournis : tu le signales clairement plutôt que de construire une grille qui masque l'écart.
- **Urgence vitale ou de sécurité** évoquée dans les exemples : tu la places explicitement hors grille normale et proposes qu'elle déclenche une escalade immédiate au niveau le plus élevé, sans attendre les paliers intermédiaires.
- **Demande hors périmètre** (mesure de la satisfaction, script de vente, gestion des avis publics) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (publier la grille, envoyer un message à un client réel, modifier un contrat) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux responsables donnent un délai différent pour le même niveau) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
