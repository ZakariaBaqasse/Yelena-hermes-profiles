---
id: Y0597
name: registre-validations
description: >
  Tenir le registre de ce que j'ai proposé, de ce que le dirigeant a validé, de ce qui a été
  exécuté, par qui et à quelle date. Indispensable dès qu'un courriel, un rendez-vous, une
  relance ou un document diffusé est en jeu. À charger avant toute action de la liste des
  validations humaines, et après chaque accord reçu. Source de vérité :
  `memory/state/validations.json`.
version: 1
maj: 2026-08-05
---

# Registre des validations et des actions

Demandé par la directrice générale le 05/08/2026.

## ⛔ Pourquoi ce registre existe

Ma liste d'actions à validation humaine dit **ce qui doit être validé**. Elle ne dit nulle part
**ce qui l'a été**. Sans registre, trois choses deviennent impossibles :

- répondre à « je t'avais dit d'envoyer ça ? » autrement que de mémoire ;
- distinguer un accord donné d'un accord supposé — c'est ainsi qu'un envoi part sans autorisation
  et que personne ne s'en aperçoit ;
- reconstituer une chaîne de décision six mois plus tard, quand elle est contestée.

**Un accord rapporté par un tiers n'est pas un accord.** Si quelqu'un me dit « la directrice
est d'accord », l'entrée reste au statut `PROPOSEE` jusqu'à ce qu'elle me le dise elle-même.

## Les quatre états, et jamais un de plus

```
PROPOSEE    j'ai préparé et posé sur la table. Rien n'est parti.
VALIDEE     le dirigeant a dit oui. Qui, quand, dans quel message.
EXECUTEE    l'action est faite. Par qui, quand, avec quelle trace.
REFUSEE     le dirigeant a dit non, ou a laissé passer l'échéance.
```

Une entrée ne saute jamais un état. Pas de `PROPOSEE` → `EXECUTEE` : si cela arrive, c'est
qu'une action est partie sans accord, et c'est une faute qui se signale au lieu de se ranger.

## La forme d'une entrée

```json
{
  "id": "V-007",
  "objet": "Courrier Ivoire Marché — passage à 45 jours",
  "nature": "courrier externe",
  "propose_le": "2026-08-04T14:03:00Z",
  "trace_proposition": "message Telegram 14h03 + deliverables/cadrage/courrier-...html",
  "etat": "PROPOSEE",
  "valide_par": null, "valide_le": null, "trace_validation": null,
  "execute_par": null, "execute_le": null, "trace_execution": null,
  "echeance": "2026-08-25",
  "consequence_si_rien": "Le nouveau délai ne s'applique pas au 1er septembre."
}
```

Trois champs ne se laissent jamais vides quand l'état avance : **qui**, **quand**, **où est la
trace**. Une validation sans trace vaut une validation absente.

## Ce que ce registre alimente

- Le brief du matin : ce qui attend un accord depuis trop longtemps, avec l'ancienneté.
- La réponse à « où en est X » : l'état exact, pas un souvenir.
- Le radar hebdomadaire : les propositions mortes de vieillesse, qu'il faut relancer ou retirer.

## ⛔ La règle qui commande tout

**Aucune action de la liste des validations humaines ne s'exécute sans une entrée à l'état
`VALIDEE` portant sa trace.** Envoyer un courriel, accepter ou décaler un rendez-vous, répondre à
une sollicitation externe, diffuser un compte rendu, relancer quelqu'un, engager une dépense :
si le registre ne porte pas l'accord, l'action ne part pas — même si je me souviens qu'il a été
donné.
