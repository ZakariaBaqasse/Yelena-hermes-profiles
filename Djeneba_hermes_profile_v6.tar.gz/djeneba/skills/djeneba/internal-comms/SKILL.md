---
id: Y0557
name: internal-comms
description: "Communication interne : annonces, notes, com de changement, newsletters internes, FAQ internes, ton pro/régulé, à valider avant diffusion."
bucket: A
tags: [Communication]
version: 1
maj: 2026-09-09
---

# Internal Comms

## Ce qu'il faut avoir sous la main
- Obligatoires : le sujet/message, l'audience interne (toute l'entreprise / une équipe / managers…), l'objectif (informer, mobiliser, accompagner un changement, alerter), le canal (email, intranet, Slack/Teams, réunion).
- Optionnelles : ton de l'entreprise, éléments factuels (dates, décisions validées), niveau de confidentialité, contraintes réglementaires, signataire.
- Si une obligatoire manque → demander uniquement ce qui manque, en une fois.


**Ce qu'elle suppose comme accès** : Email, Génération de visuel interactif (Frame). Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process

1. Cerner sujet + audience + objectif + canal + niveau de sensibilité.
2. Structurer le message (contexte → information clé → ce que ça change → prochaines étapes → contact/Q&R).
3. Adapter ton et longueur au canal et à la sensibilité.
4. Pour un sujet sensible, proposer une FAQ interne et signaler les points à faire valider (RH/juridique/direction).

## Format de sortie

Termine TOUJOURS ta réponse par un **Frame interactif** (visualisation / interactive content) qui présente le livrable de façon soignée et lisible, aux couleurs du brand kit si fourni, sinon une palette neutre et pro. Le message texte reste un court wrapper ; le livrable vit dans le Frame. Si la génération de visualisation n'est pas disponible, produis à défaut un livrable structuré prêt à l'emploi (ne bloque jamais là-dessus).

## Règles

- Zéro invention : aucune décision, date, chiffre ou politique non fournis. Une info absente → « à confirmer » (ne jamais annoncer une décision non validée).
- Générique : entreprise, audience interne, ton et cadre viennent des entrées, aucun client codé en dur.
- Communication INTERNE (collaborateurs), distincte de la com externe/marketing. Ton adapté (transparent, factuel, rassurant selon le sujet). Respect de la confidentialité et, le cas échéant, des contraintes réglementaires.
- Validation humaine : tout message est « à valider avant diffusion » (surtout sujets sensibles : RH, réorganisation, crise).

**Garde-fous durs**

- **0 invention.** Aucune donnée chiffrée ni fait inventé. Une information manquante se demande ou se marque « à confirmer / [à compléter] », jamais présentée comme réelle, une case vide vaut mieux qu'un chiffre faux.
- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement.
- **Aucune action sortante sans validation.** Tu prépares l'envoi, la publication ou le partage ; tu t'arrêtes pour un accord humain explicite.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite **jamais** vers une autre traitée dans la même conversation : ni chiffre, ni nom de client, ni élément de stratégie. Une donnée ne sert qu'à l'entité dont elle provient.

## Cas limites

- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires

Pour un sujet et une audience interne donnés, produire un contenu de com interne clair, aligné sur le ton de l'entreprise, prêt à valider avant diffusion.

## Sortie
- **Message prêt à diffuser** (objet + corps, format adapté au canal).
- **Variantes** si utile (version courte / longue, managers / tous).
- **FAQ interne** et **points à valider** pour les sujets sensibles. Marqué « à valider avant diffusion ».
