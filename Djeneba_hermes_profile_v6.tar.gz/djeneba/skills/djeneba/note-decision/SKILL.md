---
name: note-decision
description: >
  Transforme un sujet flou en un arbitrage prêt à trancher, en une page. Structure imposée :
  la décision à prendre (une phrase), le contexte utile, 2 à 4 options avec avantages,
  inconvénients et risques, UNE recommandation nette, et la seule question à laquelle le
  DG doit répondre. Objectif : une décision en trente secondes, pas en trente minutes.
  Utiliser quand il dit « prépare-moi la décision sur X », « aide-moi à trancher »,
  « quelles options », « fais-moi un arbitrage », « note d'aide à la décision ».
version: 1
maj: 2026-08-03
---

# Note d'aide à la décision

Le défaut classique d'une note interne est de tout dire et de ne rien recommander.
Ici c'est l'inverse : on recommande, et on assume. Une note qui se termine sur « il
appartiendra au DG d'apprécier » n'a rien produit — elle a déplacé le travail.

## L'ordre de rédaction n'est pas l'ordre de lecture

On **écrit** dans cet ordre : la question → les options → la recommandation → le contexte.
On **livre** dans l'ordre inverse de l'analyse : la décision d'abord, le détail après. Le
lecteur doit connaître la réponse avant de lire l'argument. C'est ce qui fait la différence
entre une note qu'on lit en trente secondes et une note qu'on repousse à plus tard.

## Structure imposée — une page, jamais deux

```
OBJET : <la décision à prendre, en une phrase à l'infinitif>

CONTEXTE
<3 à 6 lignes. Uniquement ce qui est nécessaire pour décider. Pas d'historique.>

OPTIONS
A. <intitulé>
   Pour : … / Contre : … / Risque principal : …
B. <intitulé>
   Pour : … / Contre : … / Risque principal : …
[C, D si nécessaire — jamais plus de quatre]

RECOMMANDATION
<Une option, nommée par sa lettre. Deux à quatre lignes de justification. Aucune formule
d'équilibre du type « les deux se défendent ».>

CE QUI EST DEMANDÉ AU DG
<Une seule question, fermée si possible. Ex : « Validez-vous l'option B et la saisine de
la direction juridique avant le 8 août ? »>

CE QUI RESTE INCERTAIN
<Les hypothèses non vérifiées, marquées ⚠. Vide si tout est sourcé.>

<visa de contrôle>
```

Les options sont **lettrées A, B, C** : le DG répond « B » d'un caractère, y compris
depuis son téléphone. C'est une contrainte de format, pas une préférence esthétique.

## Construire des options qui sont vraiment des options

Trois nuances de la même chose n'en font qu'une. Un jeu d'options est valide si :

- elles sont **mutuellement exclusives** — on ne peut pas les faire toutes ;
- elles répondent **toutes** à la question posée en objet ;
- au moins deux sont **défendables devant un tiers**. Une option construite pour être
  écartée (« ne rien faire et laisser la situation se dégrader ») est une figure de style,
  pas une option — et elle décrédibilise la note.

**Le statu quo est une option** quand il est défendable : le nommer explicitement (« ne rien
faire avant le prochain comité de direction »), avec ses coûts, plutôt que le laisser en creux.

Chaque option porte trois choses et seulement trois : ce qu'elle apporte, ce qu'elle coûte,
et **le risque qui la ferait échouer**. Le risque n'est pas l'inconvénient : l'inconvénient
est certain, le risque est ce qui peut arriver.

## Ce qui doit être chiffré

Chiffrer tout ce qui est chiffrable — coût, délai, nombre de clients ou de collaborateurs
concernés, échéance contractuelle ou réglementaire. Un ordre de grandeur **sourcé** vaut
mieux qu'un adjectif : « environ 40 000 clients actifs sur le segment ([source](…), juin
2026) » bat « un nombre important de clients ».

Quand le chiffre n'existe pas, écrire qu'il n'existe pas. Ne jamais fabriquer une précision
pour faire sérieux : c'est la faute la plus coûteuse d'une note d'arbitrage, parce qu'elle
survit à la décision et se retrouve citée ailleurs — y compris devant le conseil
d'administration.

Toute donnée factuelle passe par `fact-checker` avant d'entrer dans la note. Chaque fait
porte son **lien cliquable** et sa date.

## Exemple travaillé (structure, sur un cas générique)

```
OBJET : Arrêter la position de la direction générale sur la demande de report de l'entrée
        en vigueur de la nouvelle politique de délais de paiement fournisseurs.

CONTEXTE
La nouvelle politique entre en vigueur le 1er octobre. Deux fournisseurs stratégiques
demandent un report de six mois, invoquant un défaut de préparation de leurs systèmes de
facturation. La direction achats estime le dispositif prêt côté entreprise. Aucune position
n'a été communiquée à ce jour.

OPTIONS
A. Maintenir la date. Pour : cohérence, signal de fermeté vis-à-vis du reste du panel
   fournisseurs. Contre : risque de rupture d'approvisionnement chez ces deux fournisseurs.
   Risque principal : une application désordonnée sur le terrain en novembre.
B. Reporter de trois mois avec un calendrier d'accompagnement formalisé.
   Pour : désamorce le conflit sans céder les six mois. Contre : ouvre la porte à une
   seconde demande d'autres fournisseurs. Risque principal : le report devient permanent
   de fait.
C. Maintenir la date, avec une tolérance d'application explicite pendant trois mois.
   Pour : garde la date, absorbe le retard réel côté fournisseurs. Contre : lisibilité
   faible en interne. Risque principal : la tolérance est lue comme un report déguisé.

RECOMMANDATION
Option C. Elle préserve la date, donc l'autorité de la politique, tout en traitant le motif
réel de la demande. Elle est révocable à tout moment, ce que ni A ni B ne permettent.

CE QUI EST DEMANDÉ AU DG
Validez-vous l'option C et une communication conjointe avec la direction achats et la
direction financière avant le 15 septembre ?

CE QUI RESTE INCERTAIN
⚠ Le degré de préparation réel des systèmes de facturation des deux fournisseurs n'est pas
documenté par une source indépendante de la direction achats.
```

## Quand le livrable n'est pas bon

- Il n'y a pas de recommandation, ou elle est enveloppée (« l'option B semblerait pouvoir »).
- La note fait deux pages : le contexte a mangé l'arbitrage.
- Les options ne sont pas exclusives, ou l'une est un épouvantail.
- La question finale est ouverte (« quelle suite souhaitez-vous donner ? ») : elle renvoie
  au DG le travail qu'on devait faire.
- Un chiffre apparaît sans source ni date.
- La section « ce qui reste incertain » est vide alors que la note repose sur une hypothèse.

## Ce qu'on n'écrit pas

Pas de « il conviendrait de », pas de « il apparaît opportun », pas de « d'aucuns estiment ».
Le DG arbitre : on lui donne de la matière, pas de la prudence rédactionnelle.

## Chaînage

- **Alimenté par** `filtre-sollicitations` (une sollicitation qui cache un arbitrage),
  `veille-ci` et `veille-financements` (le fait déclencheur).
- **Alimente** `note-cadrage-reunion` quand l'arbitrage doit être porté en séance, et
  `suivi-engagements` dès que la décision crée une échéance.
- **Contrôlé par** `fact-checker` puis `controle-qualite-5-passes` avant remise.

## Gabarit

Le gabarit de ce livrable — charte graphique, blocs obligatoires, emplacement du visa —
est dans [`references/gabarit.html`](references/gabarit.html), avec son rendu PDF dans le dossier
`gabarits/` du pack. Il est rempli de **données fictives** : il sert à valider la forme, jamais à
être repris tel quel. Les champs à remplir y sont signalés en orange.
