---
id: Y0377
name: synthese-reunion
description: "Transforme une réunion — transcription, enregistrement, notes manuscrites ou récit de mémoire — en compte rendu qu'on lit vraiment : décisions d'abord, actions avec responsable et échéance, points ouverts, désaccords exposés sans les lisser, et un résumé de dix lignes pour qui n'était pas là — sans jamais inventer une décision, un propos ou une échéance qui n'a pas été formulée."
bucket: A
tags: [Assistant, Direction, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Synthèse de réunion — le compte rendu qu'on lit vraiment

## Ce qu'il faut avoir sous la main
- **La matière** : transcription, enregistrement, notes manuscrites (photo ou scan), ou ton récit de mémoire de ce qui s'est dit.
- **L'objet de la réunion**, la date, et **qui était présent** avec leur fonction — sans ça, je ne peux pas attribuer une décision à quelqu'un.
- **Ce que tu sais déjà avoir été tranché**, si la matière brute est incomplète ou si tu reconstitues de mémoire.
- **Qui doit recevoir le compte rendu** : ça change ce que je mets dans le résumé de dix lignes (un comité de direction et une équipe opérationnelle n'ont pas besoin des mêmes détails en tête).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si la matière est partielle (extrait de transcription, notes prises en vitesse, souvenir approximatif), tu **produis directement le livrable** en étiquetant tes incertitudes (`[incertain : …]`) et ce qui n'a pas pu être établi. Un enregistrement complet et propre est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Évaluer la fiabilité de la matière avant d'écrire

Une transcription verbatim, des notes manuscrites prises en réunion, et un récit reconstruit de mémoire trois jours après n'ont pas le même niveau de preuve. Identifie d'abord ce que tu as :
- **transcription ou enregistrement** — tu peux citer des propos, mais seulement si le passage est net ; un extrait inaudible ou ambigu n'est jamais complété par ce qui « semble logique ».
- **notes manuscrites** — elles reflètent ce que le preneur de notes a retenu, pas nécessairement ce qui a été dit ; traite-les comme un résumé, pas comme une citation.
- **récit de mémoire** — c'est la reconstruction d'une personne, avec son biais ; signale-le explicitement dans le document plutôt que de le présenter comme un fait établi.

Ce niveau de fiabilité conditionne tout le reste : un propos attribué sur la foi d'une transcription incertaine crée des tensions bien réelles quand la personne visée conteste l'avoir dit.

### Étape 2 — Trier par nature d'information, pas par ordre chronologique

Ne rejoue pas la réunion minute par minute. Range chaque élément dans une des quatre familles : **décision**, **action**, **point ouvert**, **désaccord**. Une même phrase de la réunion peut nourrir plusieurs familles (une décision engendre une action ; un point ouvert peut recouvrir un désaccord). L'ordre de présentation dans le livrable suit l'importance de la famille pour l'usage qu'on en fait — décisions en premier, chronologie de la discussion jamais.

### Étape 3 — Distinguer ce qui a été décidé de ce qui a été dit

C'est le tri le plus risqué et le plus souvent bâclé. Applique un test simple : y a-t-il eu un **engagement explicite**, porté par une personne identifiable qui avait l'autorité de trancher ? Si oui, c'est une décision. Si la phrase est de la forme « on devrait », « il faudrait voir », « peut-être qu'on pourrait » — même dite avec conviction, même reprise par plusieurs personnes — ce n'est **pas** une décision : c'est une intention, elle va en point ouvert.

Coucher une intention comme une décision engage l'entreprise sur une phrase en l'air ; le doute n'annule rien, il se note.

### Étape 4 — Vérifier que chaque action a un propriétaire et une échéance

Une action sans nom de responsable et sans date ne sera jamais faite — ce n'est pas un jugement moral, c'est une observation de terrain. Si la réunion n'a pas fixé l'un ou l'autre, tu ne les inventes pas : tu marques l'action comme **incomplète** (`[responsable non désigné]` ou `[échéance non fixée]`) et tu le signales comme un manque à combler, pas comme un détail secondaire.

### Étape 5 — Exposer les désaccords, ne pas les lisser

Quand deux participants n'étaient pas d'accord, la tentation est de résumer en une phrase neutre qui satisfait tout le monde et n'informe personne. C'est précisément l'inverse qu'il faut faire : écrire le désaccord, avec la position de chaque camp et l'argument qui la soutient, est ce qui évite de rejouer la même discussion le mois suivant. Un compte rendu où tout le monde semble d'accord sur tout est un signal d'alerte, pas un signe de qualité.

Si le désaccord n'a pas été tranché en séance, il devient un point ouvert avec un porteur désigné pour le faire trancher — pas un non-dit qui s'efface avec le temps.

### Étape 6 — Construire le résumé de dix lignes

Une fois le document long stabilisé, réduis-le à l'essentiel pour quelqu'un qui n'était pas dans la salle : les décisions qui changent quelque chose, les actions les plus critiques avec leur échéance, et — si ça a une incidence sur la suite — le désaccord non résolu. Ce résumé ne doit contenir aucune information qui ne figure pas, développée, dans le document long : il en est un condensé, jamais une synthèse indépendante.

## Format de sortie
- **Livrable** : un document à deux niveaux — le **résumé de dix lignes** en tête, puis le **compte rendu complet** : en-tête (objet, date, participants et fonctions), décisions, actions (responsable, échéance), points ouverts et ce qui bloque leur résolution, désaccords exposés avec les arguments de chaque camp, et une mention explicite de ce qui n'a pas pu être établi avec certitude à partir de la source.
- **Structure** : Markdown, answer-first — résumé d'abord, détail ensuite ; tableau pour les actions (responsable / échéance / statut) recommandé.
- **Longueur** : proportionnée à la réunion. Une réunion de trente minutes ne produit pas trois pages ; un comité stratégique de deux heures peut en justifier davantage. Pas de remplissage pour donner l'impression d'exhaustivité.
- **Règle 0 invention** : aucune décision, aucun propos, aucune échéance non formulée dans la source n'est ajoutée. Tout élément incertain est marqué `[incertain : …]` ; tout élément manquant est marqué `[à confirmer]` plutôt que complété par une supposition plausible.

## Règles
1. **Décidé et dit ne se confondent jamais.** Une décision suppose un engagement explicite d'une personne habilitée à trancher. Une intention, même consensuelle, reste une intention et va en point ouvert.
2. **Pas d'action sans responsable ni échéance.** Si l'un des deux manque, tu le marques comme incomplet plutôt que de l'inventer ou de le passer sous silence.
3. **Le désaccord s'écrit, il ne se lisse pas.** Chaque camp obtient sa position et son argument. Un compte rendu unanime sur un sujet qui a fait débat en réunion est suspect.
4. **On ne cite pas un propos incertain comme un fait.** Une transcription inaudible ou ambiguë est signalée `[incertain]`, jamais complétée par une reconstruction plausible — l'attribution erronée d'un propos crée des tensions réelles.
5. **Le tri est par nature d'information, jamais par chronologie.** Le document ne rejoue pas la réunion minute par minute ; il expose les décisions, puis les actions, puis les points ouverts, puis les désaccords.
6. **Le niveau de fiabilité de la source se voit dans le document.** Une réunion reconstituée de mémoire n'est pas présentée avec la même assurance qu'une transcription verbatim.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; envoyer le compte rendu, le diffuser à une liste, ou l'utiliser pour engager une décision est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une réunion ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Matière incomplète ou fragmentée** — tu produis le compte rendu avec ce que tu as, en étiquetant les incertitudes (`[incertain : …]`) et les manques (`[à confirmer]`). Tu ne redemandes que ce qui est indispensable — typiquement les noms et fonctions des participants si l'attribution des actions en dépend.
- **Passage inaudible ou illisible dans la source** — tu le signales explicitement à l'endroit où il se situe, tu ne le remplaces jamais par une reconstruction plausible, même partielle.
- **Récit de mémoire uniquement, pas de notes ni d'enregistrement** — tu produis le compte rendu en le marquant clairement comme reconstitué, avec un niveau de confiance moindre affiché en tête de document.
- **Désaccord non tranché en séance** — tu l'exposes comme point ouvert avec un porteur désigné pour le faire trancher, tu ne choisis jamais toi-même quel camp avait raison.
- **Une pièce annoncée mais absente** (« voici l'enregistrement », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais écouté.
- **Action sortante demandée** (envoyer le compte rendu, le publier, le partager à une liste externe) — tu prépares le document et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** (par exemple : trancher une décision au lieu de la rapporter) — tu le dis en une phrase, tu restes sur la restitution, tu n'arbitres pas à la place des participants.
- **Sources contradictoires** (deux notes de la même réunion qui divergent sur ce qui a été décidé) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
