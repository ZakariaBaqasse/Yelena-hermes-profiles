---
id: Y0628
name: veille-sectorielle
description: >
  Veille structurée sur l'actualité du secteur et de l'écosystème d'affaires ivoirien qui
  compte pour le DG : nominations, décisions du comité de direction, résolutions du conseil
  d'administration, résultats et indicateurs économiques, mouvements sociaux, catastrophes et
  crises, positions des clients, fournisseurs et concurrents — tout événement majeur qui
  touche l'entreprise ou son marché, pas seulement l'actualité corporate. Utiliser quand le DG
  dit « qu'est-ce qui bouge », « veille sur X », « surveille », ou en exécution des crons de
  veille.
version: 1
maj: 2026-08-03
---

# Veille sectorielle

## Ce qu'on surveille, par ordre de priorité

**1. Les mouvements de personnes.** Nominations, révocations, démissions, décès, mises en
examen — chez les dirigeants de l'entreprise, du groupe, mais aussi chez les clients,
fournisseurs, banquiers, actionnaires et concurrents clés. C'est ce qui change le plus vite et
ce qui périme le plus de documents. Toute détection met à jour `cartographie-acteurs` **le
jour même**.

**2. Les actes.** Décisions du comité de direction, résolutions du conseil d'administration,
contrats signés, arrêtés et textes réglementaires sectoriels, publications au Journal
officiel, avis de la BRVM. Un acte signé ou publié est un fait ; une intention annoncée n'en
est pas un.

**3. Les échéances institutionnelles.** Comités de direction, conseils d'administration,
assemblées générales, sommets sectoriels (CGECI, salons professionnels), échéances fiscales
et douanières, visites d'investisseurs ou de délégations partenaires.

**4. L'économie.** Indicateurs (croissance, inflation, taux directeur de la BCEAO),
financements (banques locales, BAD, marchés BRVM et UMOA-Titres), grands contrats,
investissements étrangers, cours des matières premières qui pèsent sur l'activité (cacao,
anacarde, or, pétrole selon l'exposition de l'entreprise).

**5. Le social et le sécuritaire.** Mouvements sociaux internes, grèves, tensions syndicales,
situation sécuritaire pouvant affecter les sites, les entrepôts ou la logistique — incidents
au nord du pays, sur les axes routiers ou aux frontières.

**6. Les événements qui touchent l'entreprise ou son secteur, quels qu'ils soient.** Le DG ne
doit jamais apprendre par un tiers qu'il s'est passé quelque chose d'important pour son
activité. Entrent ici, au même titre que les décisions de gestion :

- **Catastrophes et crises** — inondations, effondrements, incendies, accidents majeurs,
  épisodes climatiques pouvant affecter sites, entrepôts ou transport. Sources de référence :
  SODEXAM pour la météo, Protection civile pour les bilans, ReliefWeb pour les situations
  humanitaires (watchlist §6).
- **Santé publique** — épidémies, alertes sanitaires, campagnes nationales, avec leur impact
  sur les effectifs et la continuité d'activité.
- **Grands événements économiques** — résultats de campagne agricole, décisions de prix,
  fermetures ou implantations industrielles, mouvements sur les cours du cacao, de
  l'anacarde, de l'or et du pétrole, opérations de marché (fusions, acquisitions, levées de
  fonds).
- **Événements de société et sport** à forte charge symbolique quand ils engagent l'image de
  l'entreprise ou appellent une prise de parole publique.

> **Sur un événement grave, la discipline prime sur la vitesse.** Les premiers bilans humains
> sont presque toujours faux. Remonter le fait immédiatement, mais écrire « bilan non
> consolidé » tant qu'une source de rang 1 ou 2 (institution, agence) ne l'a pas établi. Un
> chiffre qu'il faut démentir coûte plus cher qu'une heure d'attente.

## Méthode

- Balayer les sources institutionnelles **avant** la presse : le communiqué officiel ou le
  compte-rendu de conseil prime sur son commentaire.
- Pour tout fait, établir : **quoi**, **quand exactement**, **qui l'annonce**, **est-ce
  effectif ou annoncé**. La confusion entre annonce et entrée en vigueur est l'erreur la
  plus fréquente.
- Recouper sur **deux sources indépendantes** avant de qualifier un fait d'établi.
  Sinon : `⚠ non recoupé`.
- Dater chaque information. Une actualité de plus de douze mois ne s'écrit jamais comme
  une actualité — elle passe en contexte.

## Sortie

```
VEILLE — <période>

MOUVEMENTS DE PERSONNES
• <qui> — <de quoi vers quoi> — <acte et date> — <source>

ACTES ET DÉCISIONS
• <acte> — <date de publication> — <effet> — <source>

ÉCONOMIE
• <fait chiffré> — <source, date>

À SURVEILLER
• <signal faible> — <pourquoi ça peut compter>
```

## Interdit

- Reprendre une information d'un réseau social sans source primaire.
- Écrire « selon nos informations » : ici, on ne fait pas de renseignement, on lit des
  sources publiques et on les recoupe.
- Laisser une fiche acteur périmée après détection d'un mouvement.
