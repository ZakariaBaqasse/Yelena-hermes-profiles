# Identifiant Yelema : Y0733

# Provenance

Texte et script écrits par nous le 24/09/2026. L'idée (modèle gpt-4o-transcribe-diarize,
réponse par locuteur) vient de la compétence `transcribe` du dépôt public openai/skills
(https://github.com/openai/skills, dossier skills/.curated/transcribe), licence Apache 2.0.
Aucun texte amont n'est repris.
