---
id: Y0733
name: transcrire-reunion
description: "Transcrire un enregistrement de réunion, d'entretien ou d'audience (audio ou vidéo) en texte français qui dit qui parle et à quelle minute, avant d'en faire le compte rendu. À charger dès qu'on reçoit un enregistrement à transcrire, qu'on demande « qui a dit quoi » dans une réunion enregistrée, ou qu'un compte rendu doit partir d'un fichier audio plutôt que de notes. Facturé à la durée d'audio : on ne transcrit que ce qui est demandé."
bucket: B
tags: [Réunion, Transcription, Compte rendu, Direction]
version: 1
maj: 2026-09-24
---

# Transcrire une réunion en disant qui parle

## Le geste

Tout passe par l'intégration du poste :

```bash
python3 integrations/openai/transcrire-reunion.py <fichier> --sortie <fichier.txt>
```

Le script accepte l'audio et la vidéo (mp3, m4a, wav, ogg, vocaux Telegram, mp4…), le
convertit, découpe au-delà d'environ 1 h 40 et recolle les heures. Il rend une ligne par
prise de parole : `[12:05] B : …`.

Pour un simple vocal, sans besoin de savoir qui parle : `integrations/openai/transcrire.py`,
moins cher.

## Avant de lancer

1. **Demandé, et consenti.** On transcrit un enregistrement qu'un membre de l'équipe ou le
   client a envoyé pour ça. Un enregistrement reçu à une autre fin ne se transcrit pas sans
   le demander.
2. **Facturé à la durée** par OpenAI : une réunion de deux heures n'est pas un vocal. Si on
   veut seulement un passage, on le dit et on coupe avant.

## Nommer les locuteurs

Le script sort des lettres (A, B, C…). On ne remplace une lettre par un nom **que** si la
personne s'est présentée dans l'enregistrement, si quelqu'un l'appelle par son nom, ou si
l'utilisateur le donne. Jamais d'après le timbre de la voix ni par déduction sur le contenu.
Dans le doute, on garde la lettre et on demande : « B, c'est bien M. X ? ».

## Relire avant de livrer

- Les noms propres ivoiriens, les sigles et les montants sont les mots les plus souvent
  écorchés : on les signale au lieu de les corriger au jugé.
- Un passage inaudible reste marqué comme tel, il ne se reconstruit pas.
- Deux personnes qui parlent en même temps peuvent être fondues sous une seule lettre : le
  dire si le compte rendu en dépend.

## Ensuite

La transcription est une matière, pas le livrable. Le compte rendu se fait avec la
compétence `synthese-reunion` (décisions, actions, responsables, échéances), qui interdit
d'inventer une décision ou un propos. La transcription brute reste dans le poste, elle ne
part pas dans le fil.

## Si le script échoue

Lancer `python3 integrations/openai/check.py`. S'il échoue, l'intégration est cassée :
prévenir l'utilisateur. S'il passe et que la transcription échoue quand même, le plus
probable est un crédit épuisé chez OpenAI (erreur 429) : le dire tel quel.

## Historique

- v1, 24/09/2026 : création. Idée reprise de la compétence `transcribe` d'openai/skills
  (licence Apache 2.0), texte et script réécrits pour nos postes. Script éprouvé sur un
  vocal réel de 46 secondes le jour même.
