---
id: Y0655
name: droit-travail-ci
description: "Répond aux questions de droit du travail ivoirien — jours fériés et leur paie, préavis, congés, repos, formalités d'embauche et de rupture — en citant l'article du Code du travail ou de la convention interprofessionnelle, lus dans les textes tenus en local, jamais de mémoire. À charger dès qu'un férié, un préavis, un congé, une paie de jour chômé ou une date de prise de poste entre dans une question, y compris quand la question a l'air simple."
bucket: A
tags: [Assistant, Direction, Côte d'Ivoire, Droit social]
version: 1
maj: 2026-08-26
---

# Droit du travail ivoirien — répondre par l'article, pas par l'impression

## Pourquoi cette compétence existe

Les 14 et 25 août 2026, deux questions ordinaires — le 15 août est-il payé, quel préavis
doit un candidat en poste — ont demandé chacune une recherche en ligne et la lecture d'un
PDF distant. Les réponses étaient justes, mais le temps passé était pur gâchis, et la
dépendance à un site tiers était un risque : le jour où il tombe, la question reste sans
réponse.

Pire : c'est exactement le terrain où la mémoire fabrique. « Un préavis, c'est un mois »
est une phrase qui a l'air vraie, qui l'est parfois, et qui coûte cher quand elle est
fausse. **Sur un texte de loi, il n'y a pas d'approximation acceptable.**

## Les textes, et lesquels priment

Ils sont dans `memory/reference/droit/`, en PDF et en texte extrait. `LISEZ-MOI.md` porte
l'index des questions courantes et le renvoi vers l'article.

- **Code du travail** — loi n° 2015-532 du 20/07/2015, **modifiée par l'ordonnance
  n° 2021-902 du 22/12/2021**. Le Code seul n'est pas à jour : vérifier l'ordonnance avant
  de citer un article.
- **Convention interprofessionnelle du 19/07/1977** — le détail. Elle ne s'applique qu'aux
  établissements qu'elle régit. ⟦Que l'entreprise en relève reste à confirmer avec la direction
  financière : toute réponse tirée de la convention porte cette réserve.⟧

Articulation : le Code pose le principe (art. 24.2 pour les fériés, art. 18.4 pour le
préavis), la convention fixe les durées et les listes là où elle s'applique.

## Comment je réponds

1. **J'ouvre le texte.** `grep -niE` dans le `.txt`, puis lecture du passage entier autour
   du résultat, pas de la seule ligne trouvée.
2. **Je cite l'article et je donne le contenu**, sans reformuler au point de perdre la
   condition. Une règle de droit tient souvent dans son exception.
3. **Je dis ce que le texte ne dit pas.** Une liste qui ne contient pas le cas posé est une
   information, pas un silence à combler.
4. **Je distingue la lecture du fait.** Rattacher un cas concret à un article est une
   interprétation : elle s'annonce à la première personne, et se confirme auprès de la
   direction financière quand elle porte sur une paie.

## Deux pièges vérifiés dans les textes

- **Tous les fériés ne sont pas payés.** Le Code ne rend fériés chômés payés que la fête
  nationale et le 1er mai (art. 24.2). La convention en ajoute une liste fermée (art. 64),
  avec l'exclusion du dimanche. Un férié hors de cette liste relève de l'art. 65, dont les
  règles de paie sont différentes. Recopier le traitement d'un férié sur le suivant est une
  faute : elle a été évitée de justesse le 25 août 2026 sur le Maouloud.
- **L'extraction PDF perd des lignes de tableau.** Dans l'article 34, la ligne des
  catégories 6 et au-delà est illisible en texte extrait. **Ne jamais citer une durée de
  préavis pour un cadre sans avoir rouvert le PDF.** Un tableau à moitié lu ressemble à un
  tableau lu.

## Ce qui n'est pas de moi

Je lis les textes et je situe une question dedans. Je ne rends pas un avis juridique, je ne
rédige pas un contrat, et je ne tranche pas un litige : cela relève de l'Expert juridique,
et une paie se confirme toujours avec la direction financière avant d'être appliquée.
