---
id: Y0375
name: pack-comite-direction
description: "Construit le dossier de comité de direction de bout en bout : ordre du jour bâti sur les décisions attendues et non sur les sujets, temps alloué à chaque point, dossier de lecture qui permet d'arriver en séance déjà informé, suivi des décisions du comité précédent, tri de ce qui doit basculer en information écrite hors séance, et relevé de décisions après la tenue — sans jamais fabriquer une date, une durée ou un chiffre qui n'a pas été donné."
bucket: A
tags: [Assistant, Direction, Horizontal, Nouveau]
version: 1
maj: 2026-08-03
---

# Pack de comité de direction — le dossier avant la réunion

## Ce qu'il faut avoir sous la main
- **La date, l'heure et le format** du comité (présentiel, visio, mixte) et sa durée prévue.
- **La liste des sujets** que les directions veulent porter — même en vrac, même juste des mots.
- **Le relevé de décisions du comité précédent**, si tu l'as (ou dis-moi qu'il n'existe pas).
- **Les documents déjà préparés** par point : notes, chiffres, présentations — ce qui existe, même à l'état d'ébauche.
- **Qui participe**, et s'il y a des absents notables ou des participants à distance (diaspora, actionnaire hors du pays, direction régionale).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Convertir chaque sujet en décision attendue

Pour chaque sujet transmis, pose la question qui sépare l'information du pilotage : *qu'est-ce que le comité doit trancher sur ce point, et qui a besoin de cette décision pour agir ensuite ?* Reformule le sujet en une phrase de décision — « valider ou non le budget marketing du T⟦à renseigner⟧ », « arbitrer entre les deux candidats au poste de ⟦à renseigner⟧ », « acter le report ou non du lancement ».

Si un sujet ne produit aucune décision identifiable — c'est un point d'avancement, une actualité, un partage d'information — il ne mérite pas un créneau de comité. C'est le signal à repérer en premier : un sujet qui reste vague même après reformulation est presque toujours un point d'information déguisé en point de décision, et c'est lui qui fait déraper la séance vers la discussion sans fin.

### Étape 2 — Allouer un temps à chaque point, et le dire à voix haute

Chaque point de l'ordre du jour reçoit une durée annoncée `⟦à renseigner⟧` avant la séance, pas décidée en cours de route. La durée n'est pas une prévision optimiste — c'est un engagement collectif que le comité peut choisir de respecter ou d'arbitrer explicitement en séance (« on dépasse de X minutes sur ce point, on rogne où ? »).

Ordonne les points par ce qui a le plus besoin d'attention fraîche, pas par ordre d'arrivée des demandes : les décisions les plus lourdes ou les plus disputées passent tôt, avant que la fatigue et les embouteillages du retour ne réduisent la salle à un quorum pressé de partir.

### Étape 3 — Construire le dossier de lecture, pas le dossier de découverte

Pour chaque point : l'état des lieux en quelques lignes factuelles, l'option recommandée avec son raisonnement, ce qui est explicitement demandé au comité (valider, arbitrer entre deux options, prendre acte), et les chiffres ou pièces jointes utiles — jamais reconstitués si non fournis.

Le dossier doit permettre à un participant de se présenter en séance déjà au fait du sujet. Signale explicitement le délai d'envoi prévu avant la tenue du comité `⟦à renseigner⟧` : un dossier envoyé la veille au soir n'est pas un dossier envoyé, c'est un dossier découvert en séance — et une séance qui sert à lire des documents n'a pas servi à décider. Si le délai réel constaté est trop court par rapport à la charge de lecture du dossier, tu le dis, tu ne le caches pas dans le livrable.

### Étape 4 — Reprendre les décisions du comité précédent avant d'ouvrir les nouvelles

Avant tout nouveau point, reviens sur le relevé du comité précédent et vérifie, pour chaque décision actée : a-t-elle été exécutée, partiellement, ou pas du tout — et si non, pourquoi. Une décision de comité qui n'est jamais revue apprend silencieusement à l'organisation qu'une décision de comité n'engage à rien ; c'est le mécanisme le plus discret qui vide un comité de son autorité, parce qu'il n'y a jamais de moment où ça se voit — sauf si quelqu'un compare explicitement deux relevés consécutifs.

Si le comité précédent n'a pas de relevé exploitable ou n'existe pas, marque-le et propose que ce suivi démarre à partir de ce comité-ci.

### Étape 5 — Trier ce qui n'a pas besoin de la salle

Pour chaque sujet qui ne porte pas de décision (étape 1), ou dont la décision est mineure et non disputée, propose qu'il bascule en **information écrite** transmise avant ou après le comité — une note courte, pas un point à l'ordre du jour. Le critère n'est pas l'importance du sujet mais l'existence d'un arbitrage à rendre en présence de tous : un sujet important mais sans décision à trancher collectivement encombre la séance sans la servir.

Documente cette liste séparément : elle n'est jamais silencieuse, sinon quelqu'un se demandera pourquoi son sujet a disparu de l'ordre du jour.

### Étape 6 — Préparer le squelette du relevé de décisions

Livre un relevé prêt à être complété en séance ou immédiatement après : pour chaque point, la décision prise (ou son report explicite), le porteur de la suite à donner, et un espace pour l'échéance `⟦à renseigner⟧` — jamais préremplie par supposition. Un relevé produit à froid, plusieurs jours après la séance, perd la précision des termes réellement actés ; le squelette doit permettre de le clore le jour même.

## Format de sortie
- **Livrable** : le pack de comité — ordre du jour avec décision attendue et temps par point, dossier de lecture par point (état des lieux, option recommandée, ce qui est demandé au comité), suivi des décisions du comité précédent, liste de ce qui bascule en information écrite, et squelette du relevé de décisions à compléter après séance.
- **Structure** : Markdown clair, un tableau pour l'ordre du jour (point / décision attendue / temps / porteur), une section par point pour le dossier de lecture, une section dédiée au suivi des décisions précédentes.
- **Longueur** : proportionnée au nombre de points réels ; un dossier de lecture par point tient en une demi-page à une page, pas plus — la densité doit rester lisible en `⟦à renseigner⟧` minutes avant la séance.
- **Toute durée, date ou échéance est un input** : elle vient de l'équipe et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée. Aucune durée de point, aucun délai d'envoi, aucune date butoir n'est produite par supposition.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Un point sans décision identifiable n'a pas sa place à l'ordre du jour.** Il devient information écrite hors séance, ou il est reformulé jusqu'à ce que la décision attendue soit nommable.
2. **Le temps par point est annoncé avant la séance, jamais improvisé pendant.** Un point sans durée affichée est le point qui déborde et écrase les suivants.
3. **Le dossier circule avant la séance, avec un délai suffisant pour être lu** — pas la veille au soir. Une séance qui sert à découvrir les documents n'a servi à rien.
4. **Le comité précédent est toujours rouvert avant le suivant.** Une décision jamais revue équivaut, dans les faits, à une décision jamais prise — et l'organisation l'apprend vite.
5. **0 chiffre et 0 date inventés.** Durées, délais, échéances, montants : tout reste `⟦à renseigner⟧` tant que l'équipe ne les a pas donnés. Un chiffre plausible non fourni reste un chiffre inventé.
6. **Le contexte de présence n'est pas un détail.** Participants à distance (diaspora, direction régionale), risque de retard lié aux déplacements, canal de rappel réellement utilisé par le comité (mail, WhatsApp) : le pack se prépare pour l'assemblée réelle, pas pour une salle idéale.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; convoquer les participants, envoyer le dossier ou diffuser le relevé de décisions est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un comité ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun relevé du comité précédent transmis** — tu le signales, tu proposes que le suivi démarre à ce comité, tu ne fabriques pas de décisions antérieures fictives.
- **Sujets transmis en vrac sans décision apparente** — tu proposes une reformulation en décision pour chacun, et tu marques ceux qui restent de l'information pure malgré la reformulation.
- **Une pièce annoncée mais absente** (« voici le dossier finance », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Donnée introuvable** (durée, date, montant) — tu le dis explicitement et tu poursuis sur le reste, en `⟦à renseigner⟧`.
- **Source ou connecteur inaccessible** — tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné.
- **Comité sans historique** (première tenue) — tu passes l'étape de suivi des décisions précédentes, tu le signales, et tu prépares directement le squelette du prochain suivi.
- **Demande hors périmètre** (rédiger la stratégie elle-même, trancher à la place du comité) — tu le dis en une phrase, tu prépares le cadre de décision, tu ne rends pas la décision à la place des directeurs.
- **Action sortante demandée** (convoquer, envoyer, diffuser) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions du même chiffre pour un même point) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
