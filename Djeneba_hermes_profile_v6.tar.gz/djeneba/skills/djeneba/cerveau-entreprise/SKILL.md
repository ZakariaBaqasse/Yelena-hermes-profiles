---
id: Y0523
name: cerveau-entreprise
description: >
  Construire et tenir la mémoire nominative de la maison : une fiche par dossier, une par
  personne, une par position déjà prise. C'est ce qui permet de répondre « la dernière décision
  sur ce sujet date du 12 mars » au lieu de repartir de zéro. Distinct de MEMORY.md, qui porte
  les règles générales de l'entreprise. À charger quand on dit « retiens ça », « où on en est
  sur X », « fais-moi une fiche », « qu'est-ce qu'on avait dit sur », et après toute réunion ou
  décision structurante.
version: 1
maj: 2026-08-05
---

# Le cerveau de la maison

Emprunté à un autre dispositif le 04/08/2026 et adapté à une entreprise.

`MEMORY.md` porte les **règles** : tarifs, délais tolérés, manière de travailler, ce qu'on ne
fait jamais. Ce skill construit l'autre moitié, celle qui se cherche **par nom** — ce que la
maison porte, avec qui, depuis quand, et ce qui a déjà été tranché.

C'est elle qui transforme un assistant bien informé en un assistant qui a de la suite dans les
idées.

## Où ça vit

```
memory/reference/
  dossiers/<slug>.md      un sujet qui a une histoire et des échéances
  acteurs/<slug>.md       une personne : client, fournisseur, salarié, partenaire
  positions/<sujet>.md    ce qui a déjà été dit, par qui, et quand
```

## ⛔ Le critère d'entrée

**Un dossier n'en est un que si je peux écrire une date de dernier mouvement.**

« L'énergie » n'est pas un dossier, c'est un thème. « La renégociation du délai d'Ivoire
Marché » en est un : il a un début, des acteurs, une échéance, et une trace écrite. Sans date
de dernier mouvement, la fiche devient un fourre-tout que personne ne relit.

## La fiche de dossier

```markdown
# <Intitulé>

- **État** : actif | en veille | clos
- **Ce dont il s'agit** : trois lignes maximum, en français simple.
- **Ce qui est en jeu pour la maison** : une ligne.
- **Dernier mouvement** : <date> — <quoi> — <lien vers la trace écrite>
- **Prochaine échéance** : <date> — <quoi> — <qui la porte>

## Qui y est
| Personne | Rôle sur ce dossier | Ce qu'elle veut |

## Ce qui a été décidé
| Date | Décision | Par qui | Trace |

## Ce qui reste ouvert
- <question> — depuis le <date>
```

## La fiche d'acteur

Quatre rubriques, et jamais un roman : **ce qu'il attend**, **ce qu'il refuse**, **ce qu'il a
décidé devant moi** (daté, avec la trace), **ce que je ne sais pas encore**.

La dernière rubrique est celle qui sert le plus : elle empêche de combler un trou par une
supposition six semaines plus tard.

## Les deux règles de tenue

**Chaque fait porte sa date.** La mémoire ne se périme pas toute seule, elle se périme en
silence — une fiche fausse a exactement l'air d'une fiche juste. Ce qui n'a pas été revérifié
depuis 90 jours se reprend, se recroise et se redate.

⛔ **Une fiche appartient à une maison et à une seule.** Les personnes rencontrées dans un autre
cadre ne s'écrivent pas ici, et rien d'ici ne sort. Un cadre de test ne lève pas le
cloisonnement : les gens dont on parle n'ont rien confié à cette maison.

## Ce qui alimente ces fiches sans qu'on le demande

Un compte rendu de réunion produit plus de fiches d'acteurs — et de meilleures, avec leur
contexte — que la question « donnez-moi vos dix interlocuteurs » ne l'aurait fait. On apprend
en travaillant, on n'interroge pas.
