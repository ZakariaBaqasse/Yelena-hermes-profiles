---
name: note-cadrage-reunion
description: >
  Prépare la RÉUNION, pas la personne (pour la personne, voir meeting-brief). Définit ce
  qu'on veut sortir de la salle, la ligne à tenir, les points à ne pas ouvrir, qui parle et
  dans quel ordre, et les décisions à obtenir avant la fin. Utiliser quand le DG dit
  « prépare la réunion de X », « qu'est-ce qu'on dit demain », « cadre-moi ce comité »,
  « note de cadrage », ou avant tout comité de direction ou réunion d'arbitrage inter-directions.
version: 1
maj: 2026-08-03
---

# Note de cadrage de réunion

Une réunion mal cadrée produit un tour de table. Une réunion cadrée produit des décisions.
La différence tient dans une page écrite avant d'entrer.

## La matière à réunir avant d'écrire

Une note de cadrage ne s'improvise pas depuis le titre de la réunion. Réunir, dans cet ordre :

1. **L'objet réel**, qui n'est pas toujours l'objet affiché. Une « réunion de suivi » qui
   suit un arbitrage contesté est une réunion d'arbitrage.
2. **La liste des participants et leur fonction courante** — vérifiée, pas supposée
   (`cartographie-acteurs`). Un participant dont on ignore le changement de poste fait
   dérailler une séquence entière.
3. **Ce qui a été décidé la fois précédente** : le dernier relevé de décisions sur le sujet,
   et ce qui en a été exécuté. C'est ce qui donne le rapport de force réel.
4. **Les engagements en cours** portés par les participants (`suivi-engagements`). Un
   participant en retard sur un engagement n'est pas dans la même position qu'un autre.
5. **Les positions déjà tenues** par les directions présentes sur le sujet. On ne conteste
   pas en séance une position qu'on a soutenue soi-même en comité de direction le mois
   d'avant.

Si l'un de ces cinq éléments manque et n'est pas récupérable, l'écrire dans la note plutôt
que de combler.

## Structure

```
RÉUNION : <objet réel> — <date, heure, lieu>
PRÉSIDÉE PAR : <qui> · PARTICIPANTS : <liste, fonctions vérifiées à date>
DERNIER POINT SUR CE SUJET : <date, décision prise, ce qui a suivi — lien>

CE QU'ON VEUT EN SORTIR
1. <résultat attendu, formulé comme une décision obtenue>
2. <…>
(Maximum 3. Au-delà, la réunion échouera.)

LA LIGNE
<Trois à cinq lignes : la position que tient la direction générale, et pourquoi.>

POINTS DURS ANTICIPÉS
• <objection probable> — portée par <qui> → <réponse préparée>
• <…>

À NE PAS OUVRIR
<Sujets à ne pas mettre sur la table dans cette configuration, et pourquoi.>

SÉQUENCE PROPOSÉE
<Qui introduit, qui documente, qui conclut. Combien de temps par point.>

CE QUI DOIT ÊTRE ACTÉ AVANT LA FIN
<Formulations exactes à faire inscrire au relevé de décisions — au mot près.>

SI ÇA BLOQUE
<La position de repli, et la limite à ne pas franchir.>
```

## Méthode

- **Partir de la fin.** Quelle phrase doit figurer au relevé de décisions ? L'écrire d'abord,
  au mot près, puis remonter vers ce qu'il faut pour l'obtenir. Une formulation préparée
  s'inscrit presque toujours telle quelle : c'est le levier le moins coûteux d'une réunion.
- **Identifier qui a intérêt à ce que rien ne soit décidé.** C'est souvent la vraie
  difficulté de la séance, et elle ne se lit pas dans l'ordre du jour. Les signaux : une
  direction qui demande un délai supplémentaire pour la troisième fois, un fournisseur qui
  envoie un représentant sans mandat de signature, un point ajouté tardivement à l'ordre du
  jour par le contrôle de gestion.
- **Préparer une position de repli, et une seule.** Deux replis successifs préparés à
  l'avance, c'est une capitulation planifiée.
- **Briefer en amont si nécessaire.** Une réunion se gagne souvent la veille : le dire
  explicitement, en nommant qui doit être vu et sur quoi — un appel au directeur financier
  avant le comité, un mot au directeur commercial avant l'arrivée du client.

## Les trois formats de réunion, et ce qui change

| Format | Ce qu'on prépare en priorité |
|---|---|
| **Arbitrage inter-directions** (ex. finance vs commercial sur une remise, production vs achats sur un délai) | La formulation exacte de la décision, et la position de repli. Les points durs sont portés par des directions, pas par des personnes. |
| **Comité de direction / revue de projet ou de budget** | L'écart entre ce qui était promis et ce qui est livré, avec les dates. Sans cet écart chiffré, la revue devient un tour de table. |
| **Rendez-vous ou réception d'une délégation partenaire, d'un investisseur, d'un banquier** | Ce qu'ils viennent chercher, ce qu'on peut accorder aujourd'hui, et la phrase de sortie qui n'engage pas au-delà. |

## Quand le livrable n'est pas bon

- Plus de trois résultats attendus : la réunion n'aura pas le temps, et aucun ne sera obtenu.
- « Ce qui doit être acté » est paraphrasé au lieu d'être rédigé au mot près.
- Les fonctions des participants n'ont pas été revérifiées — un directeur des achats parti
  le mois précédent, un actionnaire remplacé au conseil.
- Aucun point dur anticipé : soit la réunion est sans enjeu, soit l'analyse n'a pas été faite.
- La rubrique « à ne pas ouvrir » est vide alors que le dossier a des ramifications connues
  (un litige avec un fournisseur, un contrôle fiscal en cours).

## Après la réunion

Enchaîner avec `releve-decisions` **le jour même**. Une note de cadrage sans relevé derrière
ne sert qu'une fois ; avec le relevé, elle devient la mémoire du dossier — et la note de
cadrage suivante commence là où celle-ci s'est arrêtée.

## Gabarit

Le gabarit de ce livrable — charte graphique interne, blocs obligatoires, emplacement du visa
du DG — est dans [`references/gabarit.html`](references/gabarit.html), avec son rendu PDF dans
le dossier `gabarits/` du pack. Il est rempli de **données fictives** : il sert à valider la
forme, jamais à être repris tel quel. Les champs à remplir y sont signalés en orange.
