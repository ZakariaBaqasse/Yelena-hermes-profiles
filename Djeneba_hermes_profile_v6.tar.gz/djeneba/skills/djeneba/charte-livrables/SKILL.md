---
id: Y0524
name: charte-livrables
description: La charte que respecte TOUT livrable de cette maison, arrêtée par la directrice générale le 05/08/2026. À charger avant de produire un document, quel qu'il soit.
version: 1
maj: 2026-08-06
---

# Charte des livrables de la maison

Arrêtée par la directrice générale le **5 août 2026**, après six reprises successives sur un
même document. Sa phrase de clôture : *« là, ça ressemble à une vraie fiche. Je veux que tu
appliques ça à tous les livrables. Ça doit être quelque chose de sérieux, de beaucoup plus
strict. »*

⛔ **Aucun livrable ne sort sans être passé par `outils/controle-livrable.py`.**
Une règle appliquée au jugement s'applique inégalement. Un contrôle s'applique identiquement
à chaque pièce, et c'est toute la différence entre une intention et une garantie.

---

## 1. Le document est du type qu'on a demandé

Un nom de document est **un contrat de contenu**. Fiche de poste, compte rendu, procès-verbal,
note de service, cahier des charges, lettre de mission : chacun porte des rubriques attendues.

**Elles se vont chercher dans une pièce réelle du même type, elles ne se devinent pas.** Ce que
je crois savoir de la structure d'un document n'est pas une source, exactement comme ce que je
crois savoir d'un marché n'en est pas une.

> Faute d'origine, 05/08/2026 : quatre versions d'une « fiche de poste » qui était en réalité
> une note de cadrage. Ni activités, ni compétences, ni profil recherché.

## 2. Rien de moi dans la pièce

Le livrable contient **ce que son lecteur attend, dans le registre du document**. Tout ce qui
est de moi part dans le message : une alerte, une réserve, une justification, un conseil de
relecture, une mention de ce qui reste à valider, un avis.

**Le test** : si la phrase disparaissait sans que son lecteur perde une information dont il a
besoin **pour faire son travail**, c'est un commentaire. Elle sort.

Elle ne se perd pas pour autant : elle se dit dans le fil, à la bonne personne.

## 3. Aucun trou dans ce qui part chez un tiers

Un document destiné à quelqu'un d'autre que la direction ne porte **aucun** `⟦à renseigner⟧`.
Les trous se comblent **avant** de produire, en demandant. Et l'on ne demande que ce qui ne se
déduit pas : ce qui se déduit se propose, et se corrige d'un mot.

Pour ce que je livre **à la direction elle-même**, la règle inverse tient toujours : un
document lacunaire lui montre exactement ce qui manque, et c'est utile.

## 4 et 5. La forme dépend du TYPE de pièce

⚠️ **Ces deux règles ne sont pas universelles.** Reprise de la directrice générale du
06/08/2026 : *« le document ne sort pas sans contrôle, d'accord. Mais noir sur blanc, tout ça
dépend. Sur une fiche de poste, c'est normal ; sur une présentation, forcément il y aura des
couleurs. Cette règle-là ne s'applique pas à tout, ça dépend du type de document. »*

Les règles 1, 2, 3 et 6 valent pour **toute** pièce. Les deux suivantes se choisissent avec le
type, et le contrôle le demande explicitement.

### Pièce de travail — `--type travail`, le défaut

Fiche de poste, relevé, compte rendu, note, tableau de suivi. Elle se juge sur la vitesse
d'accès à l'information et sur son rendu imprimé en noir et blanc.

**4. Noir sur blanc.** La couleur n'y ajoute rien : elle signale qu'un document a été mis en
forme, pas qu'il est lisible.

**5. Le blanc sépare, le trait ne sépare pas.** Pas de filet sous les titres, pas de filet entre
les lignes d'un tableau, pas de souligné. La hiérarchie tient sur **l'espacement**, la **casse**
et la **graisse**. Un aplat gris se garde pour le seul bloc qui doit se voir. Chaque trait
paraît justifié seul ; ensemble ils quadrillent la page et plus rien ne ressort, puisque tout
est séparé pareil.

### Pièce de diffusion — `--type diffusion`

Présentation, plaquette, document portant une identité, pièce qui circule au-dehors. La couleur
et les filets y sont des **moyens**, pas des défauts, et une présentation sans couleur est une
présentation ratée. Le contrôle lève ces deux vérifications et garde toutes les autres.

> Faute d'origine, 06/08/2026 : une consigne donnée sur une fiche de poste transformée en règle
> universelle. Le contrôle aurait refusé une présentation correcte. C'est la faute du 05/08 sur
> le type de document, prise par l'autre bout : un nom de document impose sa structure, il
> impose aussi sa forme.

## 6. Ce qu'une pièce porte toujours

Le nom de la maison, le type de document, la **date à laquelle il dit vrai**, le format A4, et
au moins quatre rubriques. En dessous, ce n'est pas un livrable, c'est une note, et une note se
met dans le message.

---

## Avant de remettre

```bash
python3 outils/controle-livrable.py <fichier.html>                  # pièce de travail
python3 outils/controle-livrable.py --type diffusion <fichier.html> # présentation, plaquette
python3 outils/controle-livrable.py --interne <fichier.html>        # reste à la direction
python3 outils/tics-ia.py          <fichier.html>                   # qu'il ne sonne pas la machine
```

Puis le PDF par Chrome headless, l'aperçu image par `pdftoppm`, et **les deux partent
ensemble** : le fichier pour l'archive, l'image pour qu'elle voie sans ouvrir.

Ce que le contrôle ne sait pas vérifier reste mon travail : que la structure soit celle du type
demandé, que chaque fait vienne d'une source que je peux nommer, et que le document réponde à
ce qui a été demandé.
