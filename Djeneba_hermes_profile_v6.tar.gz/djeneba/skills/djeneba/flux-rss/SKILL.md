---
id: Y0732
name: flux-rss
description: "Lire les flux RSS des sites d'actualité et d'institutions pour une revue de presse ou une veille : ce que le site publie lui-même, daté, avec le lien de chaque article, sans passer par une recherche payante. À charger dès qu'on prépare une revue de presse, une veille institutionnelle ou sectorielle, un « quoi de neuf sur tel site », ou qu'on se demande si un site a un flux. Donne les flux vérifiés en Côte d'Ivoire et dans la région, ceux qui n'existent pas, et la conduite quand un flux manque."
bucket: B
tags: [Veille, Revue de presse, Sources, Côte d'Ivoire]
version: 1
maj: 2026-09-24
---

# Lire les flux RSS pour la veille et la revue de presse

Un flux RSS est la liste que le site publie lui-même de ses derniers articles : titre, date,
auteur, lien. C'est plus fiable qu'une page d'accueil lue en entier, et ça ne coûte rien.

## Le geste

Tout passe par l'intégration du poste, jamais par un appel écrit à la main :

```bash
python3 integrations/flux-rss/lire.py read <url du flux ou du site> --limit 10
python3 integrations/flux-rss/lire.py read <url> --since 2026-09-20 --json   # depuis une date
python3 integrations/flux-rss/lire.py discover <url du site>                 # quels flux existent
```

Si on ne connaît que l'adresse du site, `read` cherche le flux tout seul et dit lequel il a
pris.

1. **Borner** : `--limit` pour « les N derniers », `--since` pour « depuis la dernière revue ».
   Une tâche planifiée garde la date du dernier article vu et la repasse en `--since`.
2. **Lire l'article** quand le résumé du flux ne suffit (souvent la première phrase
   seulement) : ouvrir le lien de l'entrée, pas la page d'accueil.
3. **Citer le lien de l'article**, jamais celui du flux. Si le livrable est sourcé, inscrire
   chaque lien au registre de la compétence `citations-verifiees` au moment où on le lit.
4. **Dix articles sur le même événement comptent pour un** : on regroupe, on cite la source
   la plus directe (l'institution avant le journal qui la reprend).

## Flux vérifiés le 24/09/2026

| Source | Adresse à passer à `read` | État |
|---|---|---|
| AIP, Agence ivoirienne de presse | `https://www.aip.ci/` | se lit |
| Linfodrome | `https://www.linfodrome.com/rss` | se lit |
| RFI Afrique | `https://www.rfi.fr/fr/afrique/rss` | se lit |
| Financial Afrik | `https://www.financialafrik.com/` | se lit |
| BRVM | `https://www.brvm.org/` | se lit (publie peu souvent) |
| Fraternité Matin, gouv.ci, abidjan.net | | aucun flux trouvé (9 adresses essayées) |
| Jeune Afrique, APA News | | flux présent mais refusé aux robots (403) |
| Sikafinance, Lebanco | | flux présent mais mal formé, illisible |
| Koaci | | erreur du serveur au moment du test |

Ce tableau est un relevé daté, pas une vérité durable : un site peut ouvrir ou fermer son flux.

## Quand un flux manque

Un site sans flux lisible n'est pas un site sans nouvelles. On le dit en une ligne (« pas de
flux lisible pour X ») et on passe à la page elle-même, selon l'échelle de la compétence
`aller-chercher`. Un flux refusé (403) ne se contourne pas.

⛔ Une source en panne est un trou dans la revue, jamais un « rien à signaler » : on écrit
qu'elle n'a pas pu être lue.

## Si le script échoue

Lancer `python3 integrations/flux-rss/check.py`. S'il échoue, l'intégration est cassée :
prévenir l'utilisateur. S'il passe, c'est le site visé qui ne répond pas.

## Historique

- v1, 24/09/2026 : création. Idée et script repris de la compétence rss-feeds de Hermes Agent
  (NousResearch, licence MIT), texte réécrit pour nos postes. Flux ivoiriens testés un à un.
