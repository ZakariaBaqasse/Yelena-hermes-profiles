# Identifiant Yelema : Y0732

# Provenance

Texte écrit par nous le 24/09/2026. L'idée et le script de lecture (`lire.py`, dans
l'intégration `flux-rss` de chaque poste) viennent de la compétence `rss-feeds` du dépôt
public NousResearch/hermes-agent (https://github.com/NousResearch/hermes-agent), licence MIT.
Le script garde sa mention d'origine en tête de fichier.
