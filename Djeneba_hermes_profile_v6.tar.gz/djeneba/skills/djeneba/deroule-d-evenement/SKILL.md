---
id: Y0473
name: deroule-d-evenement
description: "Produit le déroulé minute par minute d'un événement, utilisable debout, dans le bruit, par un maître de cérémonie qui n'a pas participé à la préparation : heure absolue et durée pour chaque séquence, qui parle et ce qu'il dit en une ligne, ce qui se passe en son, image et lumière, temps tampon posés, et un repli nommé pour chaque point de rupture, sans jamais inventer un nom, un titre, une durée ou un horaire non fourni."
bucket: B
tags: [Direction, Événementiel, Nouveau]
version: 1
maj: 2026-09-07
---

# Le déroulé minute par minute, écrit pour celui qui tient le micro

## Ce qu'il faut avoir sous la main
- **L'événement** : nom, date, lieu, et le créneau horaire réel (heure de début et de fin, ou heure de début et durée totale).
- **La liste des séquences prévues** : qui parle, de quoi, et la durée si tu la connais déjà.
- **Les noms et titres exacts** des intervenants et invités présents, avec la prononciation si un nom peut être écorché.
- **Ce qui est déjà fixé** (l'heure d'arrivée annoncée d'une autorité, une coupure technique prévue) et **ce qui reste incertain**.
- **Les contraintes techniques connues** : son, lumière, vidéo, alimentation électrique, accès et configuration du lieu.
- **Qui est le maître de cérémonie**, et **qui décide** en cas de dépassement ou d'incident, nommément.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un programme même partiel t'est déjà fourni, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `⟦à renseigner⟧` ce qui manque, plutôt que d'attendre un intake complet.

## Process
### Étape 1 : Fixer l'heure zéro et tout convertir en heures absolues

Un déroulé écrit en durées relatives (« puis 10 minutes de discours », « ensuite 5 minutes de pause ») se déphase dès que quelque chose glisse au démarrage, et dix minutes de retard à l'ouverture décalent tout sans que personne ne sache où on en est réellement. Tu ancres chaque séquence sur une **heure absolue** (14h05, pas « + 5 min ») calculée depuis l'heure de début réelle confirmée par l'organisateur.

Si l'heure de début annoncée aux invités diffère de l'heure de démarrage réel prévu (pratique courante : on annonce 15h pour démarrer à 15h30 le temps que les invités arrivent, en particulier avec les embouteillages d'Abidjan qui retardent souvent les personnalités), tu écris les deux heures et tu dis laquelle sert de référence à la régie.

### Étape 2 : Découper en séquences et vérifier que la somme des temps tient

Tu listes chaque séquence dans l'ordre, avec sa durée. Puis tu additionnes : la somme des temps de parole et de transition doit tenir dans le créneau global. C'est un calcul, pas une impression, et l'écart se règle avant l'événement, pas au micro en coupant un invité en direct.

Si la somme dépasse le créneau, tu le dis explicitement, tu montres l'écart en minutes, et tu proposes où couper : une séquence à raccourcir, un intervenant à recentrer, une prise de parole à reporter. Tu ne tranches pas à la place de l'organisateur, tu poses la décision.

### Étape 3 : Poser les temps tampon

Les entrées et sorties de scène, les branchements de micro, les applaudissements, les photos de groupe, le temps que la salle se rassoit après une pause : tout ça prend du temps réel que personne ne compte spontanément. Un déroulé sans tampon est faux dès la troisième séquence.

Tu poses un tampon à chaque transition qui l'exige (changement d'intervenant, changement de dispositif technique, arrivée attendue d'une personnalité) et tu le chiffres même petit, plutôt que de l'omettre. En contexte de coupure électrique fréquente, si le lieu n'a pas de groupe électrogène de secours confirmé, tu le signales comme un risque à couvrir dans le plan de repli, pas comme un détail technique.

### Étape 4 : Écrire la fiche du maître de cérémonie

C'est un document séparé, pas une colonne du tableau de régie. Le maître de cérémonie n'a pas besoin de contexte, de renvois ou de vocabulaire interne : il a besoin de ce qu'il doit dire, dans l'ordre, en gros caractères, lisible même imprimé et tenu à bout de bras.

Pour chaque annonce : le nom complet et le titre exact de la personne annoncée, sa prononciation si un doute existe, et une phrase d'annonce prête à dire, pas un aide-mémoire à improviser. Écorcher un nom ou un titre en public est la faute la plus visible de la soirée, et elle est entièrement évitable avec cette fiche préparée à l'avance et relue avec l'intéressé ou son entourage si possible.

Tu ajoutes ce que fait le maître de cérémonie en cas de dépassement d'un intervenant : la phrase de relance qu'il peut utiliser, et à qui il fait signe si l'intervenant ne réagit pas. Si personne n'a désigné qui coupe un intervenant qui dépasse, tu le signales : c'est un trou de gouvernance, pas un détail.

### Étape 5 : Nommer les points de rupture et leur repli

Tu listes ce qui peut casser l'événement, et pour chacun, le repli concret et **qui décide de le déclencher**, nommément, pas « l'organisateur » en général :
- l'intervenant annoncé qui ne vient pas ou arrive en retard,
- la coupure de courant ou la panne de sonorisation,
- le fichier de présentation qui ne s'ouvre pas,
- le retard d'une personnalité attendue en ouverture,
- le dépassement de temps d'un intervenant qui refuse de s'arrêter.

Pour chaque point : ce qui remplace la séquence prévue, en combien de temps le repli peut être mis en œuvre, et qui donne le feu vert. Un plan de repli qui n'existe que dans la tête de l'organisateur n'existe pas le jour J si l'organisateur est occupé ailleurs.

### Étape 6 : Le contrôle de temps final et la version qui fait autorité

Tu récapitules : somme des durées de séquence, somme des tampons, marge restante sur le créneau global. Si la marge est négative ou nulle, tu le dis en une phrase avant de livrer le reste.

Tu dates et heures la version du document de façon visible (« version du [date] [heure] »). Le document imprimé circule dans la salle et fait autorité sur ce que chacun a en main ; quand le déroulé change, il change pour tout le monde, diffusé sur le canal que l'équipe utilise réellement (souvent WhatsApp entre régie, maître de cérémonie et sécurité), et la version imprimée périmée est retirée de circulation, pas laissée à côté de la nouvelle.

## Format de sortie
- **Le déroulé** : tableau à colonnes heure absolue, durée, séquence, intervenant, contenu en une ligne, ce qui se passe en son/image/lumière, repli si rupture.
- **La fiche du maître de cérémonie** : document séparé, en gros caractères, avec les phrases d'annonce prêtes à dire, les noms et titres exacts avec prononciation, l'ordre des annonces, et la conduite à tenir en cas de dépassement.
- **La liste des points de rupture** : chaque point nommé, son repli concret, le temps de mise en œuvre, et qui décide de le déclencher.
- **Le contrôle de temps** : somme des durées de séquence, somme des tampons posés, marge restante sur le créneau, et l'alerte explicite si la marge est négative.
- **Structure** : Markdown clair, tableaux pour le déroulé et la liste des points de rupture, texte court pour la fiche du maître de cérémonie.
- **Règle 0 invention** : aucun nom, titre, horaire ou durée non fourni n'est complété par une supposition plausible. Ce qui manque reste `⟦à renseigner⟧`.

## Règles
1. **Toute heure est absolue, jamais relative.** Une séquence porte son heure de début calculée depuis l'heure de démarrage réelle confirmée, jamais un simple « + X minutes » depuis la précédente.
2. **La somme des temps se vérifie, elle ne se suppose pas.** Si elle dépasse le créneau, tu le montres en minutes et tu proposes où couper, sans trancher à la place de l'organisateur.
3. **Chaque transition a son tampon**, même bref. Une transition sans tampon posé est un déroulé qui deviendra faux en cours de soirée.
4. **Aucun nom ni titre sans être exact.** Tu ne complètes jamais un titre incertain par une supposition, même plausible : `⟦à renseigner⟧` jusqu'à confirmation.
5. **Chaque point de rupture a un repli écrit et un décideur nommé.** Un repli qui n'existe que dans la tête d'une personne non désignée par écrit n'est pas un repli.
6. **La fiche du maître de cérémonie est un document séparé**, pensé pour être lu debout, dans le bruit, par quelqu'un qui n'a pas préparé l'événement : pas de contexte, pas de renvoi, pas de vocabulaire interne.
7. **Qui coupe un intervenant qui dépasse est écrit explicitement.** Si cette personne n'est pas désignée, tu le signales avant de livrer le reste.
8. **La version datée et heurée fait autorité.** Un changement de dernière minute est répercuté à tous les canaux utilisés par l'équipe (papier et WhatsApp compris), et l'ancienne version est retirée de circulation.
9. **Le contexte du lieu et du pays n'est pas un décor.** Coupure de courant possible, embouteillages retardant une personnalité, connexion instable en salle rendant le papier plus fiable que l'écran : un déroulé qui ignore ces réalités locales n'est pas un déroulé exécutable.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser le déroulé aux intervenants, l'imprimer en nombre ou le publier est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un événement ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** (pas de durée donnée pour certaines séquences) : tu produis le déroulé avec les durées disponibles, tu marques `⟦à renseigner⟧` les durées manquantes, et tu chiffres le contrôle de temps avec cette réserve signalée.
- **Aucun horaire de début confirmé** : tu ne peux pas produire d'heures absolues fiables. Tu le dis, tu proposes une heure zéro hypothétique clairement étiquetée `[hypothèse]`, et tu recalcules dès que l'heure réelle est confirmée.
- **Nom ou titre incertain** : tu ne complètes jamais par un titre plausible. Tu marques `⟦à renseigner⟧` et tu signales que la fiche du maître de cérémonie ne doit pas être utilisée telle quelle tant que ce point n'est pas tranché.
- **Personnalité dont l'heure d'arrivée est incertaine** (fréquent avec les embouteillages ou un protocole officiel) : tu prévois un tampon large autour de cette séquence et un repli explicite si elle n'arrive pas à l'heure prévue.
- **Intervenant annoncé absent le jour J** : tu actives le repli prévu à l'étape 5 s'il existe ; s'il n'existe pas, tu le signales comme trou à combler avant l'événement, tu ne l'improvises pas au moment de la livraison.
- **Changement de dernière minute une fois le déroulé imprimé** : tu produis la nouvelle version datée et heurée, tu rappelles que l'ancienne version doit être retirée de circulation, et tu ne présumes pas que la diffusion a été faite.
- **Coupure de courant ou panne technique en répétition** : tu traites ça comme un point de rupture à part entière avec son repli (générateur de secours, dispositif dégradé), pas comme un simple aléa laissé sans réponse.
- **Demande hors périmètre** (programme de communication de l'événement, budget, contrat de prestataire) : tu le dis en une phrase, tu traites ce qui relève du déroulé, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (envoi du déroulé aux intervenants, impression en nombre, publication) : tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions du programme circulent, deux horaires annoncés) : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
