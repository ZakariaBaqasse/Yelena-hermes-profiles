---
name: revue-de-presse
description: >
  Revue de presse quotidienne ciblée pour le DG : actualité du groupe et du secteur en Côte
  d'Ivoire, environnement régional (UEMOA/CEDEAO) et international quand l'entreprise ou son
  secteur est concerné. Sources publiques uniquement, chaque information datée et sourcée, le
  bruit écarté. Utiliser quand il dit « revue de presse », « qu'est-ce qui sort ce matin »,
  « la presse dit quoi sur X », ou en exécution de l'automatisation du matin.
version: 1
maj: 2026-08-03
---

# Revue de presse

## Le critère de sélection

Une information entre dans la revue si le DG **risque d'être interrogé dessus dans la
journée**, ou si elle **change une donnée d'un dossier en cours**. Tout le reste est du bruit,
même si c'est en une.

## Sources

**Institutionnelles (priorité)** — le site institutionnel du groupe, les communiqués de la
direction générale, les comptes rendus du comité de direction, le Journal officiel (textes et
réglementation sectorielle), Agence Ecofin.

**Presse nationale** — Fraternité Matin, RTI, Le Mandat Express, Abidjan.net, L'Intelligent
d'Abidjan, Soir Info.

**Régionale et internationale** — Jeune Afrique, RFI, APA News, Financial Afrik, Reuters et
AFP quand l'entreprise ou son secteur est cité. Les institutions : BCEAO, UEMOA, CEDEAO, FMI,
Banque mondiale, BAD.

**Économie** — communiqués des concurrents, des partenaires et clients cotés, et de la BRVM.

## Format

```
REVUE DE PRESSE — <date>

À SIGNALER (0 à 3)
• <fait> — <source, date> — <pourquoi ça compte pour la direction générale, une ligne>

ENTREPRISE / SECTEUR
• <fait> — <source>

ÉCONOMIE
• <fait> — <source>

RÉGIONAL / INTERNATIONAL
• <fait> — <source>

VU AILLEURS, NON CONFIRMÉ
• ⚠ <rumeur ou information à source unique> — <où> — non recoupée
```

## Règles absolues

- **Chaque ligne porte sa source et sa date.** Une information sans source ne figure pas.
- **Une information à source unique va dans « non confirmé »**, jamais dans le corps.
- **Ne jamais requalifier une opinion en fait.** Un éditorial est un éditorial : le dire.
- **Vérifier le statut courant** de toute personne citée avant de la mentionner avec un titre
  (voir `fact-checker` et `cartographie-acteurs`). Une fonction périmée est la faute n°1.
- **Rien de sensible sur un canal non sécurisé.** La revue se limite aux sources publiques.
- Si rien ne mérite d'être signalé, écrire « rien à signaler » et s'arrêter là. Une revue de
  presse qui remplit pour remplir perd sa crédibilité en une semaine.

## Longueur

Une page. Quinze lignes utiles valent mieux que soixante exhaustives.

## Gabarit

Le gabarit de ce livrable — charte graphique du groupe, blocs obligatoires, emplacement du visa —
est dans [`references/gabarit.html`](references/gabarit.html), avec son rendu PDF dans le dossier
`gabarits/` du pack. Il est rempli de **données fictives** : il sert à valider la forme, jamais à
être repris tel quel. Les champs à remplir y sont signalés en orange.
