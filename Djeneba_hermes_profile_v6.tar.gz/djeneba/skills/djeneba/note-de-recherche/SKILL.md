---
id: Y0570
name: note-de-recherche
description: "Générer une note de recherche NEUTRE 1-page A4 sur une personne à rencontrer, destinée à un dirigeant d'entreprise (ex. directeur général, assistante de direction préparant un rendez-vous pour son DG) qui prépare SON propre rendez-vous. Aucune référence au destinataire ni à ses intérêts propres : la note parle uniquement de la personne. Standard zéro-erreur : rédaction + double vérification adverse (2 IA indépendantes) contre sources primaires + annexe de traçabilité datée. Utiliser quand on demande une note RDV 'sécurisée', 'sans erreur', 'pour un tiers', 'institutionnelle', ou pour un interlocuteur de haut rang (investisseur, banquier, actionnaire, membre du conseil d'administration)."
version: 1
maj: 2026-08-03
---

# Note de recherche (meeting brief neutre, standard zéro-erreur)

Fiche préparatoire **1-page A4**, **neutre** (aucune mention du commanditaire), destinée à
un dirigeant qui prépare **son** rendez-vous. Elle décrit **uniquement la personne à
rencontrer**, à jour et vérifiée, exploitable en 90 secondes.

> Distinct du skill `meeting-brief` (personnel au décideur : angle
> relationnel « comment TOI tu lui parles », vigilance propre au décideur). Ici : **rien de tout
> ça**. Le lecteur peut être n'importe quel décideur ; la note doit être publiable telle quelle.

## Différences clés vs `meeting-brief`

| meeting-brief (perso) | note-de-recherche (neutre) |
|---|---|
| Angles propres au décideur | **Supprimé** |
| « Angle relationnel » vis-à-vis du décideur | Remplacé par **Objet du RDV / points de discussion** neutres |
| Vigilance = conflits connus avec le décideur | Vigilance = **sensibilités publiques** de la personne (sujets à manier avec prudence, généraux) |
| Posts LinkedIn | Remplacé par **Activité professionnelle récente** (datée) |
| 1 passe | **3 passes QA bloquantes** (voir plus bas) |

## Blocs de la note (dans l'ordre)

1. **En-tête** : nom, fonction exacte (+ depuis quand), rattachement, mandats parallèles (autres conseils d'administration, participations), tags.
2. **Objet du RDV** (1–2 lignes) : pourquoi cette rencontre, résultat visé. Neutre, factuel.
3. **Profil** (3–4 lignes) : parcours, formation, position actuelle, ce qui fait son poids.
4. **Fonction & périmètre** : ce qu'il pilote réellement, son pouvoir de décision, son entourage clé.
5. **Activité professionnelle récente** (LE bloc critique) : 3–5 faits **datés**, triés du plus récent
   au plus ancien — deals, nominations, déclarations, investissements, ouvertures de sites. **Voir moteur de fraîcheur.**
6. **Rapport de force / réseau** : à qui il rend compte (conseil d'administration, actionnaires), alliés/rivaux, qui l'influence, poids dans son secteur.
7. **Dossiers chauds de son périmètre** : 2–3 sujets d'actualité de son entreprise ou de son secteur (pas sur lui) pour rebondir.
8. **Ce qu'il peut apporter** (`value_offer`) — À INCLURE quand le lecteur est une entreprise et l'interlocuteur un investisseur, un partenaire ou un actionnaire potentiel : 3–5 apports concrets (financement, accès marché, technologie, réseau, expertise, capacité d'exécution rapide). C'est l'angle « pourquoi ce RDV est utile pour NOUS ». Neutre et factuel, adossé à des réalisations réelles.
9. **Points de discussion** : 3–5 sujets à aborder, rangés par priorité.
9. **⚠ Sensibilités** (si pertinent) : sujets à manier avec prudence, litiges publics, controverses connues, rien de spéculatif non sourcé.
10. **Marquage discret des faits vérifiés** : PAS de tableau de traçabilité visible (trop lourd esthétiquement). À la place, un petit **✓ vert discret** en fin de phrase/fait quand l'information est solidement vérifiée (double/triple source). La traçabilité complète (source + date par fait) reste tenue **en interne** dans le JSON (`traceability`, non rendu) pour l'audit QA, mais ne s'affiche pas sur le document. Légende `✓ = fait vérifié (multi-sources)` en pied de page.

## Moteur de fraîcheur (garde-fou anti « actu périmée »)

C'est le point qui a fait échouer la v1. Règles **bloquantes** :

1. **Toute actu porte une date explicite.** Un item sans date = **rejeté**, jamais affiché.
2. **Tri obligatoire du plus récent au plus ancien.**
3. **Seuils de recencé** selon le rang :
   - Personnalité de haut rang (dirigeant de grand groupe, actionnaire de référence, investisseur
     institutionnel) : priorité **< 30 jours**, acceptable **< 90 jours**. **Au-delà de 12 mois →
     interdit** dans « Activité récente » (un fait ancien va dans « Profil », pas dans « actu »).
   - Personne à faible exposition médiatique (cadre, dirigeant de PME) : élargir à **< 12 mois**
     seulement si rien de plus récent, et le dire (« activité publique peu médiatisée »).
4. **Convertir toute date relative** (« la semaine dernière ») en date absolue vérifiée.
5. **Rien de daté récent → écrire « Pas d'activité publique récente identifiée »**, JAMAIS un
   bouche-trou ancien présenté comme récent.
6. **Sources ciblées d'abord** (pas de web générique) : sites officiels de l'entreprise
   (communiqués, page équipe/leadership), agences de presse économiques panafricaines, presse
   de référence. Pour la Côte d'Ivoire : Agence Ecofin (`agenceecofin.com`), Sika Finance
   (`sikafinance.com`), Financial Afrik (`financialafrik.com`), Fraternité Matin (`fratmat.info`),
   Jeune Afrique, Abidjan.net, et la BRVM (`brvm.org`) pour les sociétés cotées.
7. **Horodatage visible** de la note (date + heure de génération) pour que la fraîcheur soit auditable.

## Contrôle qualité — 3 passes bloquantes (standard zéro-erreur)

La note sera lue par des personnes importantes : **aucune erreur factuelle tolérée.**

- **Passe 1 — Rédaction.** Collecte (moteur de fraîcheur) + rédaction. Chaque fait est noté avec
  sa source et sa date au fil de l'eau (pas de mémoire : toujours re-vérifier sur la source).
- **Passe 2 — Vérification adverse (IA n°2, sub-agent indépendant).** Un sous-agent reçoit le
  brouillon + la liste des faits et doit, pour **chaque fait**, retrouver la **source primaire** et
  trancher ✅ vérifié / ⚠ non vérifié / ❌ faux. Il cherche activement à **réfuter**, pas à confirmer.
  Il vérifie en priorité : titres/fonctions exacts, dates, chiffres, noms, statut courant de la personne.
  ```
  Agent(subagent_type:"general-purpose", prompt: "Vérifie de façon ADVERSE chaque fait de cette
  note contre sa source primaire. Pour chaque fait: source primaire trouvée? date exacte? statut
  ✅/⚠/❌. Signale toute date > seuil, toute fonction périmée, tout chiffre non retrouvé.")
  ```
- **Passe 3 — Second modèle (angle mort d'un seul modèle).** Refaire la vérification avec un
  **modèle différent** (ex. `model:"sonnet"` ou route d'un autre fournisseur) sur les faits sensibles restants,
  pour ne pas dépendre d'un seul modèle.
- **Passe 4 — Auto-revue de complétude AVANT envoi (obligatoire).** Avant de livrer, relire le
  rendu comme le ferait le destinataire et cocher une check-list ; corriger tout ce qui manque
  AVANT d'envoyer (ne jamais livrer puis corriger sous le reproche) :
  1. **Photo présente ?** Un portrait a-t-il été *réellement cherché* par TOUTES les méthodes
     (voir « Protocole photo » ci-dessous), pas seulement l'og:image ? Si vraiment introuvable
     par tes outils, le **dire explicitement** à l'utilisateur et lui demander l'image — jamais
     livrer des initiales en silence pour une personne dont la photo existe en ligne.
  2. **1 page A4 ?** (`pdfinfo` = 1) et **rendu visuel vérifié** (`pdftoppm` → regarder le PNG :
     photo affichée, pas de bloc vide, pas de dict brut, pas de texte tronqué).
  3. **Fraîcheur** : chaque actu datée, triée, aucune > seuil non signalée.
  4. **✓** présents sur les faits vérifiés ; aucun ⚠ non traité ; aucun placeholder oublié.
  5. **Neutralité** : zéro fuite du commanditaire ; **Objet du RDV**, **Sensibilités**,
     **Apport** (si acteur privé/institution) présents et pertinents.
  Cette passe est ce qui empêche les oublis « bêtes » (photo manquante, bloc vide) d'arriver
  jusqu'à l'utilisateur.
- **Règle bloquante finale :** tout fait resté ⚠ est **retiré** du corps ou **marqué explicitement
  « à confirmer »** ; tout ❌ est corrigé ou supprimé. **Une note avec un ⚠ non traité NE SORT PAS.**
  La traçabilité interne (JSON, non rendue) liste chaque fait avec son statut final (tous ✅ avant livraison) ; sur le document, seuls les faits vérifiés portent le ✓ vert discret.

## Boucle standard

1. **Qualifier l'input** : nom, fonction/entreprise, date du RDV, objet du RDV (si connu), rang.
2. **Recherche fraîcheur** (sources officielles d'abord ; convertir les dates ; trier ; seuils).
3. **Rédiger le brouillon** + tenir la liste des faits (fait → source URL → date → statut provisoire).
4. **Passe 2** (sub-agent adverse) → **Passe 3** (second modèle) → appliquer la règle bloquante.
5. **Remplir `brief-data.json`** avec le contenu vérifié + l'annexe `traceability`.
6. **Rendre** : `python3 scripts/render_brief.py --data-json X --slug Y` (WeasyPrint).
7. **Vérifier** : `pdfinfo` → 1 page A4 (2 pages tolérées seulement pour personnalité très dense).
8. **Livrer** le PDF.

## Format `brief-data.json`

```json
{
  "name": "Nom Prénom",
  "role": "Fonction exacte",
  "since": "depuis janvier 2026",
  "affiliation": "Groupe XYZ",
  "tags": ["Conseil d'administration", "Actionnaire", "…"],
  "meeting_object": "Objet neutre du RDV.",
  "profile_summary": "3–4 lignes.",
  "scope": "Ce qu'il pilote, pouvoir de décision, entourage.",
  "profile_verified": true,
  "scope_verified": true,
  "recent_activity": [
    {"title": "Fait daté récent.", "source": "Agence Ecofin", "date": "29 juin 2026", "url": "https://…", "verified": true}
  ],
  "power_map": "À qui il rend compte, alliés/rivaux, poids.",
  "hot_files": [{"title": "Dossier", "description": "1 ligne."}],
  "value_offer": [{"title": "Financement export", "description": "ce qu'il peut apporter à l'entreprise."}],
  "topics": ["Point de discussion 1", "…"],
  "sensitivities": [{"title": "Sujet", "description": "à manier avec prudence."}],
  "traceability": [
    {"fact": "Fonction X", "source": "site officiel de l'entreprise", "date": "26 jan 2026", "status": "✅"}
  ],
  "generation_datetime": "6 juillet 2026, 17h",
  "photo_url": "https://… (portrait officiel vérifié)"
}
```

- `recent_activity` : liste de strings interdite → toujours des objets `{title, source, date, url}`.
- `topics` / `tags` : listes de **strings**.
- `hot_files` / `sensitivities` : `{title, description}`.
- `traceability` : `{fact, source, date, status}` — tous ✅ au moment de livrer.

## Règles de style

- **Neutre** : aucun « tu », aucun conseil personnalisé au commanditaire, aucune synergie commerciale.
- **Factuel**, sans superlatif. Lisible en 90 s.
- **Photo — protocole de recherche (ne pas abandonner trop vite)** : essayer DANS L'ORDRE
  jusqu'à trouver un portrait vérifié (légende/nom) — (1) og:image de la page officielle de son
  organisation ; (2) site officiel direct (pages équipe/leadership) ; (3) images des articles de
  presse le nommant ; (4) **recherche d'images DuckDuckGo** — la plus fiable quand Google (JS) et
  les sites en Cloudflare (403) bloquent le scraping : `GET https://duckduckgo.com/?q=NOM&iax=images`
  pour récupérer le token `vqd=…`, puis `GET https://duckduckgo.com/i.js?o=json&q=NOM&vqd=VQD` qui
  renvoie un JSON `results[]` avec `image` (URL d'origine) et `thumbnail` (miniature **hébergée sur
  un CDN Bing/DDG, elle téléchargeable même si l'origine est en Cloudflare**). La note n'affiche la
  photo qu'en ~64px : une miniature suffit. (5) **Vérifier visuellement** l'image téléchargée
  (`Read` l'image) : bon plan, bonne personne. Embarquer en **data:URI base64** dans `photo_url`
  (auto-contenu, pas de fetch réseau au rendu). **Initiales seulement en dernier recours**, ET en
  le signalant à l'utilisateur.
- **Daté** partout. **Toujours** l'annexe de traçabilité.

## Références

| File | Lire quand… |
|---|---|
| [freshness-and-qa.md](references/freshness-and-qa.md) | détail du moteur de fraîcheur et du protocole 3 passes |
