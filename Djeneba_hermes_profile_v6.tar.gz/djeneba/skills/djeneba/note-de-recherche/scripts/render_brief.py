#!/usr/bin/env python3
"""Rend une note de préparation institutionnelle (1-page A4) depuis un JSON.
Usage: render_brief.py --data-json <file.json> --slug <slug> [--outdir <dir>]
Sortie: <outdir>/institutional-brief-<slug>.html + .pdf (WeasyPrint).
"""
import argparse, json, os, sys, subprocess
from jinja2 import Environment, FileSystemLoader, select_autoescape

HERE = os.path.dirname(os.path.abspath(__file__))
TPL_DIR = os.path.join(os.path.dirname(HERE), "templates")

def initials(name):
    parts = [p for p in name.replace("-", " ").split() if p]
    return (parts[0][0] + parts[-1][0]).upper() if len(parts) >= 2 else (parts[0][:2].upper() if parts else "?")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-json", required=True)
    ap.add_argument("--slug", required=True)
    ap.add_argument("--outdir", default="/tmp")
    a = ap.parse_args()
    data = json.load(open(a.data_json, encoding="utf-8"))
    data.setdefault("initials", initials(data.get("name", "?")))
    data.setdefault("meeting_date", data.get("meeting_date", ""))
    env = Environment(loader=FileSystemLoader(TPL_DIR), autoescape=select_autoescape(["html"]))
    html = env.get_template("brief.html.j2").render(**data)
    os.makedirs(a.outdir, exist_ok=True)
    hp = os.path.join(a.outdir, f"institutional-brief-{a.slug}.html")
    pp = os.path.join(a.outdir, f"institutional-brief-{a.slug}.pdf")
    open(hp, "w", encoding="utf-8").write(html)
    subprocess.run(["weasyprint", hp, pp], check=True)
    npages = ""
    try:
        out = subprocess.run(["pdfinfo", pp], capture_output=True, text=True)
        for line in out.stdout.splitlines():
            if line.startswith("Pages:"):
                npages = line.split(":", 1)[1].strip()
    except Exception:
        pass
    print(f"HTML {hp}\nPDF  {pp}\nPages {npages}")

if __name__ == "__main__":
    main()
