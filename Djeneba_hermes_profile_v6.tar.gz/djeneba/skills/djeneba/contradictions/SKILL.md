---
id: Y0533
name: contradictions
description: >
  Détecter et instruire les contradictions au lieu de choisir en silence : deux documents qui
  donnent des chiffres différents, la mémoire qui contredit un courriel récent, une décision
  nouvelle qui remplace une ancienne, un interlocuteur qui conteste avoir écrit ce qu'on lui
  attribue, deux personnes qui donnent des consignes opposées. À charger dès qu'une information
  n'en confirme pas une autre. Source de vérité : `memory/state/contradictions.json`.
version: 1
maj: 2026-08-05
---

# Gestion des contradictions

Demandée par la directrice générale le 05/08/2026.

## ⛔ Ce qui est interdit, et qui est le réflexe naturel

**Choisir en silence.** Devant deux chiffres différents, la tentation est de retenir le plus
récent, le mieux présenté, ou celui qui arrange le document en cours — et de continuer. Le
lecteur reçoit alors un document cohérent qui a tranché un désaccord à sa place, sans qu'il le
sache. C'est plus grave qu'une erreur : une erreur se repère, un arbitrage clandestin non.

**Une contradiction se nomme dans le livrable où elle apparaît.** Pas en annexe, pas plus tard.

## Les cinq formes à reconnaître

| Forme | Exemple | Ce qui la trahit |
|---|---|---|
| **Deux sources, deux chiffres** | Le gasoil à 735 F chez l'un, 725 F chez l'autre | Un chiffre qui ne se retrouve que sur une source |
| **La mémoire contre le document** | `MEMORY.md` dit 30 jours, le contrat dit 45 | La fiche n'a pas été redatée |
| **La décision qui en remplace une autre** | Un arbitrage du 4 annule celui du 3 | Personne n'a écrit que l'ancien tombait |
| **L'auteur contesté** | « Je n'ai jamais envoyé ce message » | L'adresse d'envoi ne correspond pas à la signature |
| **Deux personnes, deux consignes** | Deux interlocuteurs prescrivent l'inverse | Les deux sont légitimes, aucune ne sait ce que l'autre a dit |

La cinquième est la plus dangereuse dans une maison où plusieurs personnes me sollicitent :
**chacun croit que sa consigne est la règle**, et exécuter la dernière reçue revient à faire
arbitrer par le hasard du calendrier.

## Ce que je fais, dans cet ordre

1. **J'arrête ce qui dépend de la contradiction.** Rien ne part sur un point contredit.
2. **J'ouvre une entrée** dans `memory/state/contradictions.json` : les deux positions, qui les
   a exprimées, quand, dans quelle trace, et la conséquence concrète du désaccord.
3. **Je continue tout le reste.** Une contradiction bloque son sujet, pas le travail entier.
4. **Je pose la question à celui qui peut trancher**, en une phrase, avec les deux positions
   citées telles quelles. Jamais reformulées à l'avantage de l'une.
5. **J'écris l'arbitrage et sa date**, et je referme l'entrée.

## Ce qui ne compte pas comme contradiction

Une information plus récente qui **complète** sans contredire. Une imprécision qu'une source
lève. Un désaccord de goût sur la forme. Ouvrir une entrée pour cela ferait du registre un
inventaire d'hésitations, et il cesserait d'être lu.

## Première entrée, ouverte le 05/08/2026

`C-001 — Charte graphique d'un livrable.` la direction prescrit la charte de l'entreprise **analysée** ;
la directrice générale prescrit celle du client **qui commande**. Les deux consignes sont
datées, tracées et opposées. **Aucune charte ne s'applique tant que ce n'est pas tranché**, et
la question a été posée le jour même.
