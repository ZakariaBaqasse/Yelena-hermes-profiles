---
name: radar-hebdomadaire
description: >
  Vue d'ensemble hebdomadaire de tous les dossiers de la direction générale : pour chacun, son
  état (avance / bloqué / attend le DG), le prochain pas, et les deux ou trois décisions de la
  semaine. Lit les sources réelles (mémoire institutionnelle, engagements, relevés) — jamais
  la mémoire de session seule. Trié par ce qui attend une action du DG. Utiliser quand il dit
  « radar », « point hebdo », « où en sont les dossiers », « vue d'ensemble ».
version: 1
maj: 2026-08-03
---

# Radar hebdomadaire

## Ce que le radar répond, dans l'ordre

1. Qu'est-ce qui **attend une décision de vous** cette semaine ?
2. Qu'est-ce qui est **bloqué**, et par qui ?
3. Qu'est-ce qui **avance** et n'a besoin de rien ?

Cet ordre n'est pas négociable. Un radar qui commence par ce qui va bien se lit en diagonale
et rate son seul objectif : provoquer les décisions qui traînent.

## Sources à lire — obligatoire

Avant d'écrire quoi que ce soit, lire réellement :

- `memory/state/engagements.json` — échéances de la semaine et retards ;
- les relevés de décisions des sept derniers jours ;
- `memory/reference/` — cartographie des acteurs et fiches de dossiers ;
- les sorties des veilles de la semaine (`veille-marche`, `veille-financements`,
  `veille-concurrence`) : un dossier peut avoir bougé sans que personne à la direction
  générale l'ait signalé.

**Le radar ne suppose aucun agenda.** Il n'a pas accès aux rendez-vous du DG : ce qui est
écrit vient de ce qui a été *consigné*, jamais d'un calendrier deviné. Quand une échéance
dépend d'une réunion dont la tenue n'est pas documentée, elle est marquée `⚠ date à
confirmer` — pas inventée.

**Ne jamais produire un radar de mémoire.** Un radar faux est pire que pas de radar : il
donne l'illusion du contrôle, et on cesse de vérifier ailleurs.

## Format

```
RADAR — semaine du <date>

ATTEND VOTRE DÉCISION (n)
• <dossier> — <la décision attendue en une phrase> — en attente depuis <n> jours

BLOQUÉ (n)
• <dossier> — bloqué par <qui / quoi> depuis <date> — <ce qui débloquerait>

AVANCE (n)
• <dossier> — <prochain jalon, date>

ÉCHÉANCES DE LA SEMAINE
• <date> — <quoi> — <qui>

POINT D'ATTENTION
<Une seule alerte, la plus importante. Ou rien.>

<visa de contrôle>
```

## Qualifier l'état d'un dossier

Les trois états ne sont pas une impression, ils se déduisent de faits :

| État | Critère objectif |
|---|---|
| **Attend votre décision** | Une question a été posée au DG et n'a pas reçu de réponse ; ou une note d'arbitrage lui a été remise sans retour. |
| **Bloqué** | Un engagement est échu et non tenu, ou une condition extérieure (contrat, financement, nomination) n'est pas remplie. Le bloquant est **nommé**. |
| **Avance** | Un jalon a été franchi depuis le dernier radar, ou un engagement a été tenu dans les délais. |

Un dossier qui ne remplit aucun de ces critères n'est pas « en cours » : il est **sans
mouvement**. Au bout de trois semaines sans mouvement, il est signalé comme tel, même si
personne ne s'en plaint. Le silence est un symptôme — c'est souvent le premier signe qu'un
dossier a changé de main sans que la direction générale l'ait su.

## L'ancienneté, pas seulement l'état

Chaque ligne « attend votre décision » porte **depuis combien de jours** elle attend. C'est
l'information la plus actionnable du document : trois dossiers qui attendent depuis quatre
jours, ce n'est rien ; un seul qui attend depuis trois semaines, c'est un problème
d'organisation de la direction générale, et il faut que ça se voie.

## Le point d'attention

Une seule alerte, ou rien. Elle se choisit sur ce critère : **qu'est-ce qui, si personne ne
s'en occupe cette semaine, coûtera le plus cher ?** Ce n'est pas forcément le dossier le plus
gros ni le plus ancien. Écrire deux ou trois « points d'attention » revient à n'en avoir aucun.

Si rien ne se détache, écrire « aucun point d'attention cette semaine » — et le penser. Une
alerte fabriquée chaque semaine pour remplir la rubrique tue la valeur de la rubrique en un mois.

## Discipline

- **Pas de rubrique « divers ».** Ce qui n'a pas sa place dans le radar n'y figure pas.
- **Une page maximum.** Si ça déborde, c'est que des dossiers doivent être fusionnés ou sortis.
- **Chaque dossier porte le lien** vers sa dernière trace écrite : relevé, note, veille.
- Aucun jugement sur les personnes. « La direction X n'a pas transmis depuis le 12 » est un
  fait ; « la direction X traîne » est une opinion, et elle n'a rien à faire ici.

## Quand le livrable n'est pas bon

- L'ordre des sections a été changé.
- Une ligne « bloqué » ne nomme pas le bloquant.
- Les délais d'attente ne sont pas chiffrés.
- Le radar contient des dossiers dont aucune source écrite ne parle.
- Il y a plus d'un point d'attention.

## Gabarit

Le gabarit de ce livrable — charte institutionnelle, blocs obligatoires, emplacement du visa —
est dans [`references/gabarit.html`](references/gabarit.html), avec son rendu PDF dans le dossier
`gabarits/` du pack. Il est rempli de **données fictives** : il sert à valider la forme, jamais à
être repris tel quel. Les champs à remplir y sont signalés en orange.
