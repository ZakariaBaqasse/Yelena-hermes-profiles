---
id: Y0632
name: voix-du-dirigeant
description: >
  Construire, puis appliquer, le profil d'écriture du DG — ses ouvertures, ses formules,
  son rythme, ses tics, ce qu'il ne dit jamais — à partir de ses prises de parole passées
  (discours, allocutions, correspondances, interventions publiques). Résultat : un brouillon
  qui sonne comme lui au lieu d'être correct et anonyme. Utiliser quand il dit « apprends ma
  voix », « écris comme moi », « ça ne me ressemble pas », ou quand il fournit d'anciens
  textes. Se combine avec rediger-discours, speech-architecture et note-blanche.
version: 1
maj: 2026-08-03
---

# La voix du DG

Un texte correctement rédigé et un texte qui *sonne comme lui* ne se ressemblent pas. La
différence ne tient pas au fond — elle tient à une trentaine de détails qu'on ne peut pas
deviner et qu'on peut mesurer : par où il entre dans un sujet, comment il nomme les gens, ce
qu'il place en fin de phrase, ce qu'il ne dit jamais.

Ce skill fait deux choses : **extraire** ce profil une fois, puis **l'appliquer** à chaque
texte écrit en son nom.

## Le corpus — ce qu'il faut, et ce qui suffit

Trois à cinq textes **dont il est satisfait** valent mieux que trente ramassés au hasard. La
qualité du profil dépend entièrement de ce point : un corpus contenant des textes écrits par
d'autres et signés de lui produit une voix moyenne, c'est-à-dire aucune voix.

Par ordre d'utilité :

1. **Discours et allocutions** qu'il a réellement prononcés — vœux au personnel, lancement de
   produit, discours aux actionnaires — le registre le plus personnel ;
2. **Correspondances officielles** signées de lui — lettres aux actionnaires, courriers à la
   banque, correspondance avec le conseil d'administration — pour le formalisme et les
   formules d'usage ;
3. **Interventions publiques transcrites** (interviews médias, conférences sectorielles,
   panels) — pour l'oral, qui diffuse toujours dans l'écrit ;
4. **Notes internes** de sa main — comptes rendus de comité de direction, notes de service —
   le registre le plus direct, le plus utile pour les notes.

Toujours lui demander, pour chaque texte : **l'a-t-il écrit, ou seulement prononcé ?** Un
discours écrit par la direction de la communication ou par un consultant renseigne sur ce
qu'il accepte de dire, pas sur sa façon d'écrire. Les deux servent, mais pas au même endroit
— le noter.

## Ce qu'on extrait, précisément

Le profil vit dans `memory/reference/voix-dirigeant.md` et ne contient que de l'observable :

| Dimension | Ce qu'on relève | Exemple de constat |
|---|---|---|
| **Ouvertures** | Comment commencent ses textes | entre par la conjoncture du marché ou les chiffres du trimestre, jamais par lui-même |
| **Longueur** | Phrases et paragraphes, en mots | phrases longues à l'écrit, courtes à l'oral |
| **Adresse** | Comment il nomme l'auditoire | « Mesdames, Messieurs » puis nomination des rangs par ordre hiérarchique — conseil d'administration, cadres, collaborateurs |
| **Formules récurrentes** | Ce qui revient d'un texte à l'autre | trois ou quatre tournures signature à conserver telles quelles |
| **Chiffres** | Comment il les amène | chiffre d'affaires ou marge annoncés puis commentés, jamais listés |
| **Clôtures** | Sur quoi il finit | une projection sur le trimestre ou l'année à venir, rarement un remerciement |
| **Ce qu'il ne dit jamais** | Les absences | pas de superlatifs, pas de première personne du singulier en comité de direction |
| **Ponctuation et rythme** | Ses habitudes typographiques | usage marqué du deux-points ; peu de listes à puces |

**Les absences comptent autant que les présences.** Un mot qu'il n'emploie jamais et qu'on
place dans un brouillon se voit davantage qu'une formule manquante.

## Méthode d'extraction

1. Rassembler le corpus, noter pour chaque texte : date, occasion, auditoire, auteur réel.
2. Lire les textes **entiers**, pas des extraits : le rythme ne se voit qu'en continu.
3. Relever les régularités par dimension ; **ne retenir que ce qui apparaît dans au moins
   deux textes distincts**. Une tournure vue une fois est un accident, pas une signature.
4. Écrire le profil avec, pour chaque constat, **un exemple cité du corpus** — c'est ce qui
   permet de le contester et de le corriger.
5. Le soumettre au DG. Il corrigera deux ou trois points, et ces corrections valent plus
   que tout le reste de l'analyse.

## Application

À chaque texte écrit en son nom :

- charger le profil **avant** d'écrire, pas après (réécrire un texte « à sa manière » ne
  fonctionne pas : la structure est déjà prise) ;
- conserver **telles quelles** ses formules signature quand elles s'insèrent naturellement ;
- adapter au registre : la voix ne change pas, la tenue si — un discours de vœux, une
  allocution de lancement de produit et une note interne partagent les mêmes tics et pas la
  même distance ;
- signaler ce qui sort du profil quand la circonstance l'exige, plutôt que de le glisser.

## Entretien du profil

Le profil vieillit. Deux règles :

- après chaque texte qu'il retouche, **relever ce qu'il a changé** — ses corrections sont la
  meilleure source qui existe, meilleure que le corpus initial ;
- le profil se relit tous les six mois, ou quand ses fonctions changent.

## Garde-fous

- **Ne jamais publier ni diffuser** un texte au motif qu'il est « dans sa voix ». La voix ne
  vaut pas signature : rien ne part sans son accord.
- **Ne jamais inventer une formule signature.** Si le corpus est trop mince, le dire et
  travailler avec ce qu'on a — un profil fabriqué produit une caricature, et une caricature
  se remarque instantanément.
- Le corpus et le profil sont **confidentiels** : ils restent dans ta mémoire et
  ne sont jamais cités dans un document destiné à un tiers.
- Le même travail peut se faire pour une **institution** plutôt qu'une personne (voix de la
  direction générale, voix du groupe). Dans ce cas, le profil est rangé à part et ne se
  mélange jamais avec le profil personnel.
