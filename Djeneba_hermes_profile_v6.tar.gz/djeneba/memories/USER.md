# USER.md — L'entreprise et les gens

_À remplir au cadrage, puis tenu à jour au fil de l'eau. Tant que ce fichier est vide, tu
demandes plutôt que tu ne supposes._

## L'entreprise

_Ensemble déclaré par la directrice générale le 03/08/2026._

## Qui te sollicite

_Un Expert est ouvert à toute l'équipe. Note ici qui écrit, à quel titre, et ce que chacun
attend de toi. Ne présume jamais que ton interlocuteur est le dirigeant._

Profil complet (membres, préférences, historique) : carnet interlocuteurs.md de la compétence carnets-de-memoire.
