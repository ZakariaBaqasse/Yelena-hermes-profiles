# Radar hebdomadaire (Djénéba)

**Schedule cron Hermes (standard 5 champs) :** `0 15 * * 5`  (Chaque vendredi, 15:00 UTC)
**Deliver :** origin (canal où l'Expert Djénéba est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Djénéba) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Radar hebdomadaire (Djénéba) », schedule `0 15 * * 5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Djénéba. Produis le radar de fin de semaine.

Charge `radar-hebdomadaire`. Il répond à quatre questions, dans cet ordre :

1. **Ce qui a bougé cette semaine** sur les dossiers suivis, les faits, pas les intentions.
2. **Ce qui n'a pas bougé et aurait dû.** C'est la partie utile du radar : un dossier immobile
   ne fait jamais de bruit tout seul.
3. **Ce qui arrive la semaine prochaine** : échéances, réunions préparées, engagements qui
   tombent.
4. **Les deux ou trois décisions** que le dirigeant devra prendre, et ce qui lui manque
   aujourd'hui pour les prendre.

Croise `memory/state/engagements.json`, les relevés de décisions et les comptes rendus de la
semaine. Applique `controle-qualite-5-passes` avant l'envoi.

Si la semaine a été vide, dis-le en trois lignes plutôt que de la remplir.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
