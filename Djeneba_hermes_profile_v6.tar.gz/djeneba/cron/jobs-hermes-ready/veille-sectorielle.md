# Veille sectorielle (Djénéba)

**Schedule cron Hermes (standard 5 champs) :** `0 6 * * 2`  (Chaque mardi, 06:00 UTC)
**Deliver :** origin (canal où l'Expert Djénéba est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Djénéba) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Veille sectorielle (Djénéba) », schedule `0 6 * * 2`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Djénéba. Fais la veille du secteur de l'entreprise.

Charge `veille-sectorielle`. Sur le secteur, les concurrents et les partenaires listés dans
`USER.md`, et uniquement eux :

1. Ce qui a bougé chez les concurrents : lancements, levées, recrutements visibles, difficultés.
2. Ce qui bouge dans l'environnement : réglementation, fiscalité, appels d'offres, arrivée d'un
   acteur nouveau.
3. Ce que ça change pour l'entreprise, en une phrase par item. Une veille qui ne dit pas
   « donc » est une revue de presse, pas une veille.

**Chaque information porte sa source, sa date et un lien cliquable.** Tu ne cites qu'une page
que tu as réellement ouverte. Applique `fact-checker` avant l'envoi.

Ne redis pas ce que tu as déjà signalé (`memory/state/veille-secteur.json`). Cinq items maximum.
Si rien de significatif n'est sorti, réponds `[SILENT]`, c'est un résultat, pas un échec.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
