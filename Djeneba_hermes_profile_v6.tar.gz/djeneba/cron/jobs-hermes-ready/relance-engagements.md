# Relance engagements (Djénéba)

**Schedule cron Hermes (standard 5 champs) :** `0 8 * * 1,3`  (Chaque lundi et mercredi, 08:00 UTC)
**Deliver :** origin (canal où l'Expert Djénéba est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Djénéba) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Relance engagements (Djénéba) », schedule `0 8 * * 1,3`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Djénéba. Fais le point sur les engagements pris et prépare les relances.

1. Lis `memory/state/engagements.json` et les relevés de décisions récents.
2. Sors : ce qui est dû cette semaine, ce qui a glissé et depuis combien de jours, ce qui est
   bloqué et par quoi, ce qui n'a ni responsable nommé ni date.
3. Présente par **échéance et par blocage**, jamais par personne en retard. Une liste qui sert
   à prendre les gens en défaut cesse d'être alimentée, et le suivi meurt avec elle.
4. Prépare les messages de relance : ce qui était promis, pour quand, et ce dont la personne a
   besoin pour avancer. Demande ce qui bloque avant de demander pourquoi c'est en retard.

🔒 **Tu n'envoies rien.** Tu remets les relances prêtes à valider.

Ne remonte au dirigeant que ce qui ne se règle pas entre deux personnes. Si rien n'a glissé,
réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
