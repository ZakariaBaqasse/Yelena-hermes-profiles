---
name: memoire-entreprise
description: >
  Construire et tenir la mémoire propre de l'entreprise : une fiche par dossier que la
  direction porte, une par projet, une par sujet récurrent, historique, acteurs, décisions,
  échéances, positions déjà tenues. C'est ce qui permet de répondre « la dernière décision sur
  ce sujet date du 12 mars » au lieu de repartir de zéro. Distinct de MEMORY.md, qui est la
  mémoire du MARCHÉ. Utiliser quand la direction dit « retiens ça », « où on en est sur X »,
  « fais-moi une fiche », « qu'est-ce qu'on avait dit sur », ou après toute réunion ou décision
  structurante.
version: 1
maj: 2026-08-26
---

# La mémoire de l'entreprise

`MEMORY.md` contient la mémoire du **marché** : le secteur, les concurrents, les partenaires,
les sources. Elle est livrée remplie et se corrige quand un fait bouge.

Ce skill construit l'autre moitié, celle qui n'existe pas au premier jour : la mémoire de
**l'entreprise**, ce que la direction porte, avec qui, depuis quand, et ce qui a déjà été
décidé. C'est elle qui transforme un agent bien informé en un agent qui a de la suite dans
les idées.

## Où ça vit

```
memory/reference/
  dossiers/<slug>.md      ← un fichier par dossier ou projet
  acteurs/<slug>.md       ← une fiche par personne (voir cartographie-acteurs)
  positions/<sujet>.md    ← ce qui a déjà été dit publiquement, et par qui
```

Un dossier = **un sujet qui a une histoire et des échéances**. Pas un thème (« la logistique »),
pas une réunion. Si on ne peut pas écrire une date de dernier mouvement, ce n'est pas encore
un dossier.

## La fiche de dossier

```markdown
# <Intitulé du dossier>

- **État** : actif | en veille | clos
- **Ce dont il s'agit** : trois lignes maximum, en français simple.
- **Ce qui est en jeu pour l'entreprise** : une ligne.
- **Dernier mouvement** : <date>, <quoi>, <lien vers la trace écrite>
- **Prochaine échéance** : <date>, <quoi>, ou « aucune identifiée »
- **Vérifié le** : <date>

## Acteurs
| Qui | Fonction (vérifiée le) | Rôle dans ce dossier |

## Ce qui a été décidé
| Date | Décision | Où c'est tracé |

## Ce qui a été dit publiquement
| Date | Qui | Quoi | Lien |

## Points ouverts
- <ce qui n'est pas tranché, et ce qui manque pour trancher>

## Historique
<Append seulement. On n'efface jamais une ligne d'historique : on en ajoute une.>
```

Deux principes qui font toute la valeur de la fiche :

- **Chaque fait porte sa source en lien cliquable et sa date.** Une fiche sans liens est un
  souvenir ; avec les liens, c'est un dossier.
- **L'historique est en ajout seul.** Corriger une erreur, c'est écrire la correction en
  dessous, pas réécrire au-dessus. C'est ce qui permet de répondre « voici ce qu'on savait,
  et quand on l'a su », la seule réponse qui tienne en cas de contestation.

## Les positions publiques : la fiche qu'on oublie toujours

Un fichier par sujet sensible, qui recense **ce que le dirigeant, la direction générale et
l'entreprise ont déjà dit publiquement**, avec la date et le lien. C'est la fiche la moins
spectaculaire et la plus utile : elle évite qu'une prise de parole, une réponse ou une note
contredise une ligne officielle tenue trois mois plus tôt.

Elle se consulte **obligatoirement** avant : une prise de parole publique, une note
d'arbitrage sur un sujet sensible, une réponse à un journaliste, une prise de position en
comité de direction ou face à un partenaire.

## Comment la mémoire se remplit

Elle ne se remplit pas par des séances dédiées, personne n'a le temps. Elle se remplit
**en travaillant** :

| Quand | Ce qui est versé |
|---|---|
| Un relevé de décisions est produit | les décisions et les actions vont dans la fiche du dossier |
| Une veille signale un fait sur un dossier suivi | le fait est ajouté avec son lien |
| Le dirigeant dit « retiens ça » | une ligne d'historique, immédiatement |
| Une personne change de fonction | la fiche acteur est corrigée, et les dossiers qui la citent sont revus |
| Un brief est produit | ce qui a été vérifié enrichit la fiche acteur |

**Règle dure** : ce qui est appris se écrit tout de suite. Une information gardée « en tête »
pour la fin de la session est une information perdue.

## Ce qui n'entre pas dans la mémoire

- Le **privé** : santé, famille, opinions personnelles, conversations informelles. Si le
  dirigeant confie quelque chose de personnel, ça ne s'écrit pas, sauf demande explicite.
- Les **rumeurs et les non-vérifiés** : ils vont dans la fiche marqués `⚠ non vérifié`, avec
  leur source, ou ils n'y vont pas. Une rumeur qui perd sa marque devient un fait au bout de
  deux mois, c'est ainsi qu'on fabrique une erreur.
- Ce qui relève de la **mémoire du marché** : le secteur, les concurrents, les sources
  générales restent dans `MEMORY.md`. Mélanger les deux fait qu'on ne sait plus ce qui est
  public et ce qui est propre à l'entreprise.

## Entretien

- Toute fiche non touchée depuis **90 jours** est marquée « à revérifier ».
- Une fiche de dossier clos n'est pas supprimée : son état passe à `clos`, et elle reste
  consultable. Les dossiers reviennent.
- Une fois par mois, lister les dossiers sans mouvement depuis six semaines et le signaler
  dans le radar. Un dossier oublié est presque toujours un dossier qui a changé de main.

## Confidentialité

La mémoire de l'entreprise est **strictement interne**. Elle ne sort jamais du canal, n'est
jamais citée dans un document destiné à un tiers, et aucun de ses éléments n'est repris dans
un brief destiné à un client ou à un partenaire, lequel ne doit contenir que du public
vérifiable.
