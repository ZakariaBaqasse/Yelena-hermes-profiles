---
name: boucle-qa-adverse-livrable
description: Boucle qualité multi-agents adverse (rounds successifs, lentilles distinctes, convergence à zéro major) pour tout livrable à enjeu demandé « définitif » par la direction. Utiliser quand elle dit « tourne en boucle », « résultat définitif », « aucune erreur ».
version: 1
maj: 2026-08-26
---

# Boucle QA adverse multi-agents : livrable « définitif »

## Quand elle est OBLIGATOIRE (pas sur demande)

Cette relecture n'attend pas qu'on la réclame. Elle est **due** dès qu'un document remplit l'une
de ces trois conditions :

- il **quitte l'entreprise**, il sera lu par un service, une filiale, un partenaire, la presse ;
- il **engage l'entreprise**, communiqué, correspondance officielle, élément de langage, position publique ;
- il **porte un arbitrage**, note de décision, note de cadrage, tout document qui oriente un choix.

La raison tient en une phrase : les cinq passes de contrôle sont menées par le même modèle, et un
modèle ne voit pas ses propres angles morts. La passe 4 cherche à réfuter, mais elle cherche là où
elle sait chercher. Une IA d'un **autre fournisseur**, à qui l'on demande de faire échouer le
document, trouve ce qu'aucune auto-relecture ne trouve.

Le visa porte alors `Relecture adverse : effectuée le JJ/MM/AAAA (IA <fournisseur>)`.

**Quand elle n'a pas lieu**, sur un document courant, revue de presse quotidienne, point des
engagements commerciaux, le visa l'écrit : `Relecture adverse : non requise, revue quotidienne`. Un visa
muet sur ce point se lit comme une relecture faite : le silence vaut mensonge.

Reste toujours vrai par ailleurs : quand la direction demande un livrable de très haute qualité (« tourne en boucle », « résultat définitif », « que X ne fasse pas d'erreur »), on ne livre pas sur une seule passe. Protocole éprouvé le 22/07/2026 sur le cahier des charges Yelema Workers (79 défauts éliminés en 4 rounds, 26 majors au round 1 malgré un draft soigné, preuve que la boucle est indispensable).

## Protocole

1. **Rassembler la matière AVANT de rédiger** : relire toutes les sources primaires (captures, rapports, décisions actées dans memory/projects/). Le draft se rédige soi-même (cohérence d'ensemble), les agents relisent, ils ne rédigent pas.
2. **Round 1, panel de 5 relecteurs ADVERSES en parallèle** (tool Workflow, `parallel`, schema JSON findings) avec des lentilles DISTINCTES, chacune pointée vers ses sources de vérification :
   - fidélité aux sources primaires (chaque fait vs captures/rapports)
   - faisabilité technique (chaque brique capable de ce qu'on lui fait faire ? SLO réalistes ? contradictions internes ?)
   - complétude dev-ready (« reçois CE doc et rien d'autre : où es-tu bloqué ? » + renvois internes)
   - UX/graphisme (si livrable produit), tokens, écrans, mobile, lexique
   - cohérence business (vs décisions actées dans memory/projects/*.md, le doc contredit-il un arbitrage ?)
3. **Prompt reviewer** : « tu cherches ce qui ferait ÉCHOUER » ; major = bloque/fait produire un mauvais résultat, minor = améliorable ; NE PAS signaler les choix assumés ni les « questions ouvertes » ; max 10 findings ; preuve exacte exigée (fichier + citation). Schema : {severity, section, claim, evidence, fix_suggestion} + verdict_global.
4. **Vérifier avant d'appliquer** : spot-checker les findings structurants contre les sources (un reviewer peut se tromper). Puis appliquer TOUT ce qui est vérifié.
5. **Rounds suivants** : relancer le panel avec prompts re-signés « ROUND N » (⚠ un resumeFromRunId avec prompts identiques rejoue le CACHE, il faut changer le texte du prompt pour forcer une relecture). Consigne round N : traquer résidus ET incohérences INTRODUITES par les corrections ; « un round propre est un résultat, pas un échec » ; max findings décroissant (10→6→4→3).
6. **Convergence** : les majors des rounds 2+ sont presque toujours des contradictions entre sections éditées (renvois cassés, enums désalignées, règle énoncée différemment à 2 endroits). Porte finale = round léger à 3 vérificateurs (contradictions / renvois-exécutabilité / exactitude externe). Stop quand un round est vierge de majors.
7. **Livrer** avec le bilan de la boucle (rounds, findings, corrections), c'est une preuve de qualité que la direction valorise.

## Pièges vécus
- Le draft « soigné » du premier jet contenait 26 majors, ne JAMAIS sauter la boucle sur un doc à enjeu.
- Chaque passe de correction INTRODUIT des incohérences (enum vs règle, dépendances de lots, renvois) : les rounds 2-3 servent surtout à ça.
- Compter les majors DISTINCTS (plusieurs lentilles remontent le même défaut).
- Reviewer prompts : pointer les chemins de fichiers exacts des sources, sinon les agents jugent de mémoire.
- Rendu PDF WeasyPrint : remplacer les emojis (✅→✓ vert, 🔧→◇ orange en HTML) sinon carrés .notdef.
