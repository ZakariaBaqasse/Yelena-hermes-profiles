---
id: Y0710
name: boite-a-outils-pandas
description: "Les gestes de calcul que Nadia fait en code plutôt qu'à la main, tirés du Python Data Science Handbook (VanderPlas) et de portfolios publics d'analystes, adaptés aux règles du poste : lire un export sale, regrouper, croiser deux tables, pivoter, travailler une série temporelle (rééchantillonner, glisser, décaler), tracer un graphique sobre, et les trois modèles simples qui servent vraiment en entreprise (régression, regroupement k-moyennes, réduction de dimensions), avec la validation qui empêche de se raconter des histoires. Un aide-mémoire opérationnel, pas un cours."
bucket: B
tags: [Données, Python, pandas, Outils, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Ce qui se calcule se code, et le code se joint au livrable

Environnement : `~/.venv-office/bin/python` (pandas, numpy, scipy, statsmodels, matplotlib,
folium, duckdb, sqlalchemy, openpyxl, pdfplumber). Aucun calcul de tête dans un livrable.

## Provenance et ce qu'on en garde
Relu le 21/09/2026 : *Python Data Science Handbook* (chapitres pandas 03.04 à 03.12,
Matplotlib 04.01 à 04.14, scikit-learn 05.02, 05.03, 05.06, 05.09, 05.11) et trois portfolios
publics d'analystes (nettoyage pandas, requêtes SQL, plans de tableau de bord). On garde les
gestes ; on écarte ce qui contredit le poste : suppression silencieuse des lignes incomplètes,
plafonnement des extrêmes, seuils posés par l'analyste, modèle présenté sans son erreur.

## 1. Lire un export tel qu'il est
```python
df = pd.read_csv(f, dtype=str, sep=None, engine="python")      # tout en texte : rien n'est deviné
df = pd.read_excel(f, sheet_name=None, dtype=str)               # dict d'onglets
pd.to_datetime(col, dayfirst=True, errors="coerce", format="%d/%m/%Y")  # convention DÉCLARÉE, sinon signaler
pd.to_numeric(col.str.replace(r"[^\d,.-]", "", regex=True).str.replace(",", "."), errors="coerce")
```
Ce qui ne se lit pas devient `NaN` **et** une ligne de signalement (voir
`qualite-de-la-donnee/references/inspection-et-nettoyage.py`), jamais une ligne supprimée.

## 2. Valeurs manquantes (Handbook 03.04)
`isna().sum()` par colonne dans le rapport ; `dropna` seulement sur une copie de travail, avec le
nombre écarté écrit ; `fillna` uniquement par une règle métier documentée (jamais la moyenne « pour
que ça tourne »). Un `NaN` dans un graphique se voit ; un 0 ment.

## 3. Regrouper, croiser, pivoter (03.06 à 03.09)
```python
df.groupby(["magasin", "mois"]).agg(ventes=("montant", "sum"), tickets=("id", "nunique"), median=("montant", "median"))
df.groupby("client")["montant"].transform("sum")               # diffuse l'agrégat sur chaque ligne
pd.merge(faits, dim, on="cle", how="left", validate="m:1", indicator=True)   # _merge == "left_only" = orphelins
pd.concat([a, b], keys=["source_a", "source_b"])              # garde l'origine
df.pivot_table(index="produit", columns="mois", values="montant", aggfunc="sum", margins=True, fill_value=np.nan)
pd.cut(x, bins=⟦bornes décidées⟧) / pd.qcut(x, 5)              # cut = bornes de la maison ; qcut = quantiles observés
```
`validate=` sur chaque jointure : un « m:1 » qui échoue révèle un doublon dans la dimension.

## 4. Séries temporelles (03.11)
```python
s = df.set_index("date")["montant"]
s.resample("D").sum()                 # jours sans ligne → 0 : à distinguer des jours non saisis (calendrier)
s.resample("W-MON").sum(); s.resample("ME").sum()
s.rolling(7, min_periods=7).mean()    # lissage, jamais pour remplacer la série
s.shift(1); s.pct_change(); s.shift(12)   # mois précédent, variation, même mois N-1
s.index.dayofweek; s.index.month      # profils hebdo et mensuels
```
Toujours une table calendrier à côté (jours ouverts, fêtes) : un dimanche fermé n'est pas un
dimanche à zéro.

## 5. Chaînes (03.10)
`.str.strip().str.lower()`, `.str.normalize("NFKD")` pour les accents, `.str.extract(r"(\d+)")`,
`.str.contains(..., case=False, na=False)`. Une normalisation sert à **rapprocher** des libellés
(« Garba », « garba ») ; la valeur d'origine reste dans une colonne.

## 6. Graphiques sobres (04.01 à 04.14 ; règles dans `dataviz`)
```python
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.plot(s.index, s.values, lw=1.6); ax.set_ylabel("XOF"); ax.set_title("Ventes par semaine, 2026")
ax.errorbar(x, y, yerr=marge, fmt="o", capsize=3)             # une moyenne se trace avec sa marge
ax.annotate("ouverture Kaolack", (date, val), xytext=(10, 10), textcoords="offset points")
fig.savefig(png, dpi=160, bbox_inches="tight")
```
Un graphique = une question dans le titre, l'unité sur l'axe, la source et la période en note,
les zones non mesurées hachurées ou absentes, jamais à zéro.

## 7. Trois modèles, et la validation d'abord (05.02, 05.03, 05.06, 05.09, 05.11)
- **Régression linéaire** (`statsmodels.OLS` pour les intervalles) : ce qui explique une mesure
  (jours ouverts, pluie, prix). On lit les coefficients avec leur intervalle, on écrit
  « associé à », jamais « cause ».
- **k-moyennes** (`sklearn.cluster.KMeans`, variables standardisées) : proposer des groupes de
  clients ou de points de vente quand les critères de la maison manquent ; le nombre de groupes
  se choisit par l'inertie **et** par le sens métier, et chaque groupe reçoit un nom en
  français avant d'apparaître dans un livrable.
- **ACP** (`sklearn.decomposition.PCA`) : résumer vingt indicateurs en deux axes lisibles pour
  une carte des agences ; les axes se nomment d'après les variables qui les portent.
- **Validation** : séparer apprentissage et test (ou validation croisée), donner l'erreur sur
  le test, comparer à la méthode naïve. Un modèle sans son erreur n'entre pas dans un livrable
  (`prevision-et-estimation`, `statistiques-pour-decider`).
`scikit-learn` est installé dans `~/.venv-office` (21/09/2026).

## 8. Performance et gros fichiers (03.12)
`df.query("montant > 0 and magasin == 'Bouaké'")`, `df.eval(...)` sur des tables larges ;
au-delà de quelques millions de lignes, DuckDB lit le CSV en SQL sans le charger
(`interroger-une-base-de-donnees`).

## Règles
1. **Le code se joint au livrable** (ou se dépose avec lui) : un chiffre non rejouable n'est pas un chiffre.
2. **Aucune suppression silencieuse, aucun plafonnement** ; drapeaux et journal.
3. **Bornes de `cut` = décision de la maison** ; `qcut` = proposition étiquetée.
4. **Un modèle porte son erreur et sa comparaison à la méthode naïve.**
5. **Les colonnes d'origine restent** à côté des colonnes normalisées.
6. **Dépendances installées = notées** dans le livrable et dans `outils-qui-me-manquent` si elles manquent.

## Cas limites
- **Fichier Excel avec plusieurs tableaux sur une feuille** : lire en `header=None`, repérer les blocs par les lignes vides, découper ; documenter le découpage.
- **Dates mixtes jour/mois ambiguës** (03/07 et 07/03 dans la même colonne) : impossible à trancher par le code ; on signale et on demande la convention.
- **Modèle demandé « pour faire sérieux »** : on livre la comparaison à la méthode naïve ; si elle gagne, on le dit et on garde la méthode simple.
