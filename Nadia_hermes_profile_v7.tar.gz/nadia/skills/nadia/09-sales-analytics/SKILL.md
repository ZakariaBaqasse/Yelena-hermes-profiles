---
id: Y0048
name: 09-sales-analytics
description: "Détecte le variant A/B gagnant d'une séquence outreach (open/connect/reply/booking rate, seuil de significativité) et génère un tableau de bord de conversion du pipeline commercial par étape, avec alertes sur les drops et recommandations actionnables, jamais d'application automatique des résultats."
bucket: C
tags: [Sales]
version: 1
maj: 2026-08-26
---

# 09 Sales Analytics

## Ce qu'il faut avoir sous la main
1. l'**entité/startup** concernée (ou « toutes ») ;
2. le **mode** souhaité : détection A/B seule · tableau de bord funnel seul · les deux (défaut) ;
3. *(optionnel)* la fenêtre d'analyse en jours (défaut 30) et le seuil minimum d'échantillon par variant (défaut 30).


**Ce qu'elle suppose comme accès** : Tableur pipeline SDR, Registre central du portefeuille, Lecture/écriture de tableurs, Accès fichiers/dossiers, Rendu de tableau de bord interactif, Génération de fichier/PDF. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
- **sample_size** : nb de leads dans ce variant sur la fenêtre lookback
- **open_rate** : nb opens / nb sends (J0 uniquement)
- **connect_rate** : nb connected / nb sent_J0
- **reply_rate** : nb replied / nb connected
- **booking_rate** : nb booked / nb replied (métrique primaire pour désignation winner)

### Étapes du funnel

Pour chaque entité, calculer (sur lookback_days) :

- **Sourced** : total leads avec entrée dans cette fenêtre
- **Validated** : status ≠ rejected_icp_mismatch
- **Sent J0** : status ≥ sent_J0
- **Connected** : status ≥ connected
- **Sent J3** : status ≥ sent_J3
- **Replied** : status in {replied, engaging, booked}
- **Booked** : status = booked
- **Closed Won** : status = closed_won
- **Closed Lost** : status in {lost_blocked, lost_unfit}

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Input

- **entité** : une entité du portefeuille ou « toutes »
- **mode** : « ab_test » | « funnel_dashboard » | « both » (défaut both)
- **lookback_days** : nb jours en arrière (défaut 30)
- **min_sample_size** : seuil minimum pour déclarer un winner (défaut 30 par variant)

# PARTIE 1 : A/B TEST WINNER DETECTION

### Variants du sheet

Chaque lead a une colonne `variant_id` (col Z) avec valeur « A » | « B » | « C » etc. Les variants sont définis pour J0, J3, J7 séparément (3 séquences testables).

### Désignation winner

Pour chaque étape :

- Si `min(sample_size) < min_sample_size` → « insufficient_data » → ne pas déclarer de winner.
- Sinon : variant avec la plus haute `booking_rate` (priorité 1) puis `reply_rate` (priorité 2).
- Calculer le **lift relatif** : `(best - worst) / worst * 100`.
- Significativité : test de Bayes simplifié (proba que A > B basée sur des priors Beta), si proba > 0.8 → « significant ».

### Output A/B

```json
{
  "startup": "le programme",
  "step": "J0",
  "variants": {
    "A": {"sample": 45, "booking_rate": 0.067, "reply_rate": 0.22},
    "B": {"sample": 52, "booking_rate": 0.115, "reply_rate": 0.31}
  },
  "winner": "B",
  "lift_vs_worst": 72,
  "significance": "significant",
  "reco": "Migrer 100% sur B dans la prochaine campagne"
}
```

### Application

Tu **ne touches pas automatiquement** au sheet Setup. Tu produis la reco. L'utilisateur (ou une skill de rédaction de séquences en aval) décide de l'appliquer.

Exception : si un winner est détecté ET déjà appliqué → marquer `winner_applied_at` dans une table de log `AB_Log`.

# PARTIE 2 : FUNNEL DASHBOARD

### Métriques dérivées

- Conversion rate par étape (ratio entre 2 étapes consécutives)
- Drop-off le plus important (alerte)
- Comparaison vs période N-1 (lookback précédent)

### Tableau de bord

Génère via `[connecteur à brancher : rendu de tableau de bord interactif]` un dashboard qui contient :

1. **Funnel viz** vertical : 9 étapes avec largeurs proportionnelles
2. **Tableau** : rates par entité
3. **Alerts box** : « 🔴 le programme: connect_rate -45% vs S-1 » si drop > 30%
4. **AB winners** : box récap par étape
5. **Recos** : 3 bullets actionnables (« focus J0 sur variant B pour le programme A », « stop_loss sur 12 leads dead le programme B »)

### Export PDF

Si l'utilisateur demande un « PDF » → générer via `[connecteur à brancher : génération de fichier/PDF]` un PDF brandé selon la charte du client déployé (header couleur de marque, footer « Sales Analytics, {date} »).

# ÉTAPE 1 : LIRE DATA

Via `[connecteur à brancher : lecture/écriture de tableurs (type Sheets)]` (ou le connecteur fichiers, avec le dossier de l'entité résolu depuis le registre central, si le tableur n'est pas directement accessible) :

- `Startups_Config!A2:A100` → liste des entités actives
- Pour chaque onglet : `{entité}!A14:AC` (toutes colonnes leads)
- `AB_Log!A:G` si existe (sinon créer)

# ÉTAPE 2 : CALCULER

Selon le mode, lancer Partie 1 et/ou Partie 2.

# ÉTAPE 3 : RENDER

Tableau de bord via `[connecteur à brancher : rendu de tableau de bord interactif]` + (optionnel) PDF via `[connecteur à brancher : génération de fichier/PDF]`.

# ÉTAPE 4 : WRITE LOGS

Append à `AB_Log!A:G` les résultats : run_at, entité, étape, winner, lift, significance, applied.

# OUTPUT FINAL

```json
{
  "run_at": "ISO",
  "mode": "both",
  "startups": ["le programme A", "le programme B", "..."],
  "ab_winners": ["..."],
  "funnel_summary": {
    "le programme": {"sourced": 50, "booked": 4, "rate": 0.08}
  },
  "alerts": ["🔴 le programme connect_rate -45% vs S-1"],
  "recos": ["Migrer J0 sur variant B pour le programme A", "Stop-loss 12 leads dead le programme B"],
  "frame_url": "...",
  "pdf_url": "... (si demandé)"
}
```

# RÈGLES

- **Pas d'auto-apply des winners**, tu produis la reco, l'humain décide.
- **Tableau de bord = source unique**, pas de table ASCII en sortie chat.
- **Comparaisons** : toujours par rapport à la fenêtre N-1 équivalente.
- **Significativité** : ne jamais déclarer de winner avec un échantillon < 30 par variant.
- **Alerts** : seuil 30% de drop = rouge, 15% = orange.
- **Jamais de chiffre inventé**, si le tableur n'est pas accessible ou qu'une entité n'a aucune donnée sur la fenêtre, le signaler explicitement plutôt que d'estimer des taux plausibles.
- **Confidentialité** : les données d'une entité ne contaminent jamais l'analyse d'une autre, chaque onglet est traité indépendamment, même en mode « toutes ».

### Configuration (déployée pour l'entreprise)

>
