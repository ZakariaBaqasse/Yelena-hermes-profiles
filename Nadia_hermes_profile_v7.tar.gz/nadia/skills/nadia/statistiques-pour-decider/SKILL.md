---
id: Y0701
name: statistiques-pour-decider
description: "Les statistiques dont une entreprise a besoin pour décider, et rien de plus : taille d'échantillon avant une enquête, intervalle de confiance autour d'un taux ou d'une moyenne, test de différence entre deux périodes ou deux groupes, corrélation qui n'est pas une causalité. Rend le chiffre avec sa marge d'erreur, la phrase qui dit ce qu'il prouve, et celle qui dit ce qu'il ne prouve pas, sans jamais fixer un seuil de décision à la place de la direction."
bucket: B
tags: [Données, Statistiques, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Un chiffre sans sa marge d'erreur est une opinion

## Ce qu'il faut avoir sous la main
- **La question de décision** : qu'est-ce qu'on fera différemment si la réponse est oui plutôt que non.
- **Les données** : la série, les deux groupes, ou l'échantillon, avec la façon dont ils ont été obtenus (qui est dedans, qui n'y est pas, comment on les a choisis).
- **L'unité d'observation** : un client, un ticket, une journée, un point de vente. Se tromper d'unité gonfle artificiellement l'échantillon.
- **Le niveau de risque acceptable**, s'il a été décidé (« on veut être sûr à 95 % »). S'il ne l'a pas été, tu proposes le niveau usuel en le disant, tu ne l'imposes pas.

> ⚡ **Tu produis avec ce que tu as.** Si la façon dont les données ont été obtenues n'est pas connue, tu calcules quand même et tu écris que le résultat vaut pour cet échantillon tel qu'il est, pas pour l'ensemble de l'activité.

## Process
### Étape 1, Reformuler la question en question testable
« Est-ce que le nouveau prix marche ? » devient « la recette moyenne par jour après le 17 août est-elle différente de celle d'avant, une fois tenu compte de la pluie et des jours de la semaine ? ». Si la question ne peut pas se reformuler ainsi, la statistique ne l'aidera pas, et tu le dis.

### Étape 2, Regarder d'où viennent les données avant de calculer
Un échantillon se juge d'abord par la façon dont il a été constitué. Les clients qui ont répondu au questionnaire ne sont pas les clients ; les jours saisis ne sont pas les jours ouverts. Tu écris qui est représenté, qui ne l'est pas, et ce que ça biaise. Aucun calcul ne rattrape un échantillon choisi de travers, et il vaut mieux un petit échantillon honnête qu'un grand échantillon commode.

### Étape 3, Calculer, avec la marge
- **Un taux ou une moyenne** : la valeur, l'effectif, et l'intervalle de confiance. « 62 % de clients satisfaits sur 48 réponses, entre 48 % et 75 % à 95 % » se lit très différemment de « 62 % ».
- **Deux groupes ou deux périodes** : la différence, son intervalle, et le test adapté (t de Student ou Mann-Whitney pour des moyennes, chi² ou test exact de Fisher pour des proportions, test apparié quand ce sont les mêmes unités avant et après). Tu nommes le test et tu dis pourquoi.
- **Une relation entre deux variables** : la corrélation et son intervalle, avec la phrase obligatoire : elle ne dit pas laquelle cause l'autre, ni si une troisième explique les deux.
- **La taille d'échantillon avant une enquête** : à partir de la précision voulue et du niveau de confiance, avec le calcul montré, et le rappel que le taux de réponse réel réduit tout.

Les calculs se font en code (`~/.venv-office/bin/python`, `scipy.stats`, `statsmodels`), jamais de tête, et le code se joint au livrable.

### Étape 4, Écrire ce que ça prouve et ce que ça ne prouve pas
Deux phrases, toujours les deux. « La différence de 12 % est peu probable par hasard seul (p = 0,01) » et « elle peut venir du prix, de la pluie, ou du départ d'une serveuse : les données ne séparent pas ces causes ». Un résultat non significatif ne prouve pas l'absence d'effet, il prouve que l'échantillon ne permet pas de le voir ; tu écris lequel des deux.

### Étape 5, Ramener au vocabulaire de la maison
Pas de « p-value » dans un message à une patronne de maquis. « Sur ce qu'on a, on ne peut pas dire si le nouveau prix rapporte plus : il faudrait ⟦N⟧ jours de plus sans changer autre chose » est une phrase statistique complète.

## Format de sortie
- **Réponse dans le fil** : le chiffre, sa marge, la phrase « ça prouve », la phrase « ça ne prouve pas », en cinq lignes.
- **Note d'analyse** (gabarit `note-d-analyse`) quand la question engage une décision : méthode, données, résultats avec intervalles, limites, et ce qu'il faudrait pour trancher mieux.
- **Code** joint ou déposé avec le livrable, pour que le calcul soit rejouable.

## Règles
1. **Jamais un taux sans son effectif**, jamais une moyenne sans sa dispersion, jamais une différence sans son intervalle.
2. **Le seuil de décision (5 %, 10 %, autre) appartient à la direction.** Tu proposes l'usage courant, tu écris que c'est une convention, tu ne tranches pas.
3. **Corrélation n'est pas causalité**, et la phrase s'écrit à chaque fois, même quand elle paraît évidente.
4. **Un test se nomme** et se justifie ; un résultat sans le nom du test ne se vérifie pas.
5. **Absence de significativité n'est pas absence d'effet.** Tu écris ce que l'échantillon aurait dû être pour voir l'effet.
6. **Zéro invention** : pas de « en général on observe », pas de norme sectorielle de mémoire. Ce qui n'est pas dans les données ou dans une source ouverte s'écrit `⟦à renseigner⟧`.

## Cas limites
- **Moins de 30 observations** : tu calcules quand même, avec les méthodes exactes ou non paramétriques, et tu écris en tête que l'échantillon est petit.
- **Séries temporelles** : deux périodes ne sont pas deux groupes indépendants (saison, tendance, jours de la semaine). Tu compares à jour équivalent, ou tu passes la main à `prevision-et-estimation` pour modéliser la tendance avant de tester.
- **Données agrégées seulement** (totaux mensuels sans le détail) : tu dis ce qu'on perd et tu demandes le détail avant de conclure sur une différence.
