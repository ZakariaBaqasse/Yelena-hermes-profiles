---
id: Y0436
name: du-tableur-au-tableau-de-bord
description: "Transforme les classeurs existants d'une entreprise en un tableau de bord fiable et tenable, sans changer d'outil : séparation des couches saisie/calcul/affichage, réduction du coût de rafraîchissement, vues par destinataire, habillage de chaque chiffre avec sa période et sa comparaison, protections et procédure de mise à jour, écrites pour que le tableau survive au départ de celui qui l'a construit."
bucket: B
tags: [Données, Tableau de bord, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Construire un tableau de bord dans le tableur où vit déjà l'entreprise

## Ce qu'il faut avoir sous la main
- **Le ou les classeurs existants** (Excel, Google Sheets, ou export du logiciel de gestion), même s'ils sont désordonnés, avec des formules cassées ou des onglets dupliqués.
- **Qui doit regarder quoi** : le dirigeant, le responsable commercial, le comptable, chacun avec ce qu'il décide en regardant ce chiffre.
- **Qui saisit les données aujourd'hui**, à quelle fréquence, et à partir de quoi (cahier de vente, relevé bancaire, mobile money, facture papier).
- **Sur quel support le tableau sera réellement consulté** : ordinateur au bureau, téléphone en déplacement, capture d'écran envoyée sur WhatsApp.
- **Ce qui a déjà cassé** si un tableau de bord a existé avant : formule qui décale, fichier écrasé, personne qui ne l'a plus mis à jour.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) : tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process

### Étape 1 : Cartographier l'existant et séparer les couches
Ouvre le ou les classeurs fournis et repère, onglet par onglet, ce qui est **saisi à la main**, ce qui est **calculé par formule**, et ce qui est **affiché pour lecture**. Dans la grande majorité des classeurs qu'on te confiera, les trois sont mélangés dans le même onglet : c'est la cause numéro un des tableaux qui cassent. Quelqu'un insère une ligne pour une nouvelle vente, une formule de total se décale d'une case, et le chiffre faux circule sans que personne ne s'en aperçoive avant qu'il serve à une décision.

Découpe systématiquement en trois couches distinctes, chacune dans son ou ses propres onglets : **saisie** (les données brutes, une ligne par événement, jamais de formule dedans), **calculs** (les agrégations, jamais de saisie manuelle dedans), **affichage** (ce que les destinataires voient, alimenté uniquement par la couche calculs, jamais retouché à la main). Cette séparation est la fondation ; rien d'autre ne se construit avant qu'elle tienne.

### Étape 2 : Mesurer et réduire le coût de rafraîchissement
Avant d'ajouter un seul graphique, chronomètre ou fais estimer ce que coûte aujourd'hui une mise à jour : combien de temps, combien de fichiers à ouvrir, combien de copier-coller manuels. Un tableau qui demande deux heures de manipulation chaque mois sera tenu trois mois puis abandonné, quelle que soit sa qualité visuelle.

Identifie les manipulations répétitives qui peuvent devenir des formules ou des imports automatiques (recherche, somme conditionnelle, import d'un export bancaire ou mobile money) et élimine-les une par une. Le critère de réussite de cette étape n'est pas esthétique : c'est le temps de rafraîchissement, avant et après, que tu affiches noir sur blanc dans le livrable.

### Étape 3 : Partir des décisions à prendre, pas des données disponibles
Pour chaque destinataire identifié, liste les décisions qu'il prend régulièrement (réapprovisionner, relancer un client, ajuster un prix, valider une paie) et remonte, pour chacune, l'indicateur qui permettrait de la prendre plus tôt ou mieux. Un tableau de bord se construit à partir de ces décisions, jamais à partir de ce que le classeur contient déjà et qu'il serait facile d'afficher.

Le piège classique ici est le graphique séduisant qui ne répond à aucune question posée. Teste chaque vue candidate avec une question simple : si ce chiffre change, quelle décision change avec lui ? Si la réponse est aucune, la vue se retire, même si elle était déjà construite.

### Étape 4 : Construire une vue par destinataire
Le dirigeant, le responsable commercial et le comptable ne regardent ni les mêmes choses, ni à la même fréquence. Une vue unique qui essaie de satisfaire tout le monde finit par n'être lue en entier par personne. Construis un onglet ou une page d'affichage distincte par destinataire, courte, limitée aux indicateurs liés à ses décisions identifiées à l'étape 3.

Précise pour chaque vue sa fréquence de consultation prévue (quotidienne, hebdomadaire, mensuelle) : elle détermine la fréquence de rafraîchissement nécessaire, pas l'inverse. Une vue quotidienne alimentée par une saisie mensuelle ment par omission.

### Étape 5 : Habiller chaque valeur affichée
Un nombre seul, sans période, sans base de comparaison et sans unité, se lit comme on veut. « 12 » peut être un total du mois, du trimestre, ou depuis le début de l'année ; en francs CFA, en unités vendues, ou en pourcentage. Chaque valeur affichée dans la couche affichage porte obligatoirement ces trois éléments : la **période** qu'elle couvre, l'**unité** dans laquelle elle s'exprime, et la **comparaison** qui lui donne un sens (mois précédent, même mois l'an dernier, objectif fixé). Une comparaison sans référence chiffrée fournie par l'entreprise reste `⟦à renseigner⟧`, elle ne s'invente pas.

Vérifie aussi la cohérence des devises et des unités entre onglets : un montant en franc CFA additionné à un montant en devise étrangère sans conversion explicite produit un chiffre faux qui a l'air correct.

### Étape 6 : Poser protections, droits et sauvegarde
Un classeur partagé entre plusieurs personnes qui saisissent ou consultent en même temps perd du travail quand deux modifications se croisent, et l'historique des versions d'un tableur partagé ne restitue pas toujours fidèlement ce que l'interface laisse croire. Avant de livrer, verrouille les onglets de calcul et d'affichage en lecture seule pour tous sauf leur responsable, laisse la couche saisie ouverte uniquement à ceux qui y saisissent réellement, et fixe une règle de sauvegarde explicite (copie datée à intervalle régulier, conservée hors du fichier de travail).

Dis-le explicitement dans le livrable : ces protections ne sont pas une option de confort, elles conditionnent la fiabilité de tout ce qui a été construit dans les étapes précédentes.

### Étape 7 : Adapter au support réellement utilisé
Un tableau conçu et lu sur un écran d'ordinateur devient souvent illisible sur le téléphone d'entrée de gamme où le dirigeant le consultera réellement, surtout avec une connexion qui charge lentement un fichier lourd. Si la consultation mobile a été signalée au démarrage, prévois une vue allégée : moins de colonnes visibles à l'écran, police et cellules dimensionnées pour un petit écran, ou export en image ou PDF léger diffusable sur WhatsApp plutôt que le classeur complet.

Ne construis pas une version mobile en plus du reste : conçois la vue affichage pour qu'elle fonctionne sur les deux supports dès le départ, quitte à en sacrifier la densité sur ordinateur.

### Étape 8 : Écrire la procédure de mise à jour et organiser la passation
Le tableau de bord ne vaut que ce que vaut sa mise à jour la plus probable, celle faite par quelqu'un de pressé un jour où tout va mal. Écris la procédure comme un mode d'emploi qu'un remplaçant pourrait suivre sans explication orale : qui saisit, à quel moment du mois ou de la semaine, combien de temps ça prend d'après l'étape 2, et quelles vérifications minimales avant de considérer le tableau à jour et diffusable.

Signale explicitement le risque de dépendance à une seule personne : si un seul collaborateur comprend la structure, le tableau de bord ne survivra pas à son départ, à son absence ou à sa maladie. La procédure doit permettre à une deuxième personne de reprendre la main.

## Format de sortie
- **Livrable** : la structure du classeur en couches (onglet par onglet, ce qui est saisi, calculé, affiché), le tableau de bord avec une vue par destinataire, chaque valeur portant sa période, son unité et sa comparaison, la procédure de mise à jour (qui, quand, durée, vérifications avant diffusion), et les protections et règle de sauvegarde appliquées.
- **Structure** : Markdown clair, answer-first (la structure en couches et le diagnostic du coût de rafraîchissement d'abord, le détail ensuite) ; tableaux pour la cartographie des couches et pour la grille destinataire/décision/indicateur.
- **Longueur** : proportionnée au nombre de classeurs et de destinataires fournis, sans remplissage.
- **Les bases de comparaison et objectifs chiffrés sont un input**, pas une production : la skill livre la structure de chaque indicateur (période, unité, ce à quoi il se compare) ; la valeur de référence vient de l'entreprise et reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.
- **Règle 0 invention** : aucune donnée chiffrée, aucun seuil, aucun taux fiscal ou social n'est produit sans être fourni ou sourcé ; `⟦à renseigner⟧` sinon.

## Règles
1. **Les couches ne se mélangent jamais.** Saisie, calcul et affichage vivent dans des onglets distincts. Un onglet où une cellule de saisie côtoie une formule est un défaut à corriger avant toute autre amélioration.
2. **Le coût de rafraîchissement se mesure avant d'ajouter une visualisation.** Un tableau de bord magnifique mais trop long à tenir à jour n'est pas un livrable réussi, c'est un abandon différé.
3. **Chaque vue répond à une décision nommée.** Une visualisation qui ne change aucune décision d'aucun destinataire identifié se retire, même si la donnée était déjà disponible.
4. **Une vue par destinataire, pas une vue pour tous.** Le dirigeant, le commercial et le comptable reçoivent chacun une page courte adaptée à ses décisions et à sa fréquence de consultation.
5. **Aucun chiffre affiché sans période, unité et comparaison.** Un nombre seul est retravaillé ou marqué incomplet, jamais livré tel quel.
6. **0 chiffre inventé.** Aucun seuil, taux, objectif ou barème n'est produit sans être fourni par l'entreprise ou sourcé par un lien vérifié : `⟦à renseigner⟧` sinon. Cela vaut aussi pour les taux fiscaux, sociaux ou les échéances légales, qui ne se citent qu'avec leur source.
7. **Les protections et la sauvegarde se posent avant la livraison**, pas après un premier incident. Tu les mentionnes explicitement dans chaque livrable, même quand l'entreprise ne les a pas demandées.
8. **Le support réel de consultation prime sur l'habitude de conception.** Si le dirigeant regarde sur téléphone, la vue se conçoit pour un téléphone, pas pour l'écran sur lequel tu travailles.
9. **Le contexte local n'est pas un décor.** Des ventes notées à la main, un relevé mobile money exporté en PDF, une connexion qui coupe pendant l'import : la procédure de mise à jour se conçoit pour ces conditions réelles, pas pour un flux de données propre et automatique qui n'existe pas chez le client.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail et une structure de classeur ; modifier le fichier de production, écraser une version existante, changer des droits d'accès réels ou diffuser le tableau aux destinataires est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends des données d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun classeur structuré n'existe** (tout est sur papier ou dans des carnets de vente) : tu conçois la structure en couches à partir de zéro et tu marques la couche saisie comme point de départ à construire, sans supposer de données déjà disponibles.
- **Plusieurs classeurs incompatibles coexistent** (formats différents, un par succursale) : tu le signales, tu proposes une consolidation dans la couche calculs, et tu ne fusionnes rien sans validation de l'utilisateur sur la correspondance des colonnes.
- **Une seule personne comprend le fichier actuel** : tu le signales explicitement comme un risque de continuité et tu renforces la procédure de mise à jour en conséquence, indépendamment de la demande initiale.
- **Demande de changer d'outil** (passer à un logiciel de BI ou un ERP) : tu le dis en une phrase, tu restes sur le périmètre tableur, et tu orientes vers la compétence ou la décision qui convient si le besoin dépasse ce que le tableur peut raisonnablement porter.
- **Demande d'automatisation avancée** (script, macro complexe, connecteur API) dépassant les fonctions natives d'un tableur : tu le signales comme hors périmètre de cette compétence et tu proposes la structure qui rendrait cette automatisation possible plus tard, sans la construire toi-même en autonomie.
- **Fichier partagé sans historique fiable** : tu le signales avant de continuer et tu recommandes une sauvegarde immédiate avant toute modification de structure.
- **Connexion instable ou coûteuse chez le client** : tu conçois la procédure de mise à jour et le format de diffusion pour minimiser les échanges de fichiers lourds, en le disant explicitement.
- **Objectifs ou bases de comparaison non fournis** : tu livres la structure complète de l'indicateur avec `⟦à renseigner⟧` à la place de la valeur, tu ne devines jamais un objectif plausible.
- **Action sortante demandée** (modifier le fichier en production, changer des droits d'accès réels, diffuser aux destinataires) : tu prépares le livrable et tu t'arrêtes pour validation humaine.

## Références
- `references/modele-en-etoile-et-plan-de-tableau-de-bord.md` : table de faits et dimensions en tableur, table calendrier, catalogue de mesures nommées, plan de tableau de bord à écrire avant de construire, et ce qu'on ne reprend pas des outils de BI.
