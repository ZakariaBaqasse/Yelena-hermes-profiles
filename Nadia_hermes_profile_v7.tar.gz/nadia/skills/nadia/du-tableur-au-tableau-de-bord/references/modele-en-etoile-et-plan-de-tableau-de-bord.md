# Modèle en étoile, catalogue de mesures, plan de tableau de bord

Techniques reprises des portfolios publics d'analystes BI (STCybersec, SaifulIslamDS,
ryniewiczg ; relus le 21/09/2026) et transposées au tableur : ce qu'un outil de BI fait avec
un modèle en étoile et des mesures DAX, un Google Sheet le fait avec des onglets séparés et
des formules nommées. La règle du poste reste la même : **saisie, calcul, affichage** sont
trois couches distinctes.

## 1. Le modèle en étoile, version tableur

- **Une table de faits** : une ligne par événement (vente, ticket, livraison, admission), avec
  une date, des clés vers les référentiels, et des mesures numériques. Rien d'autre.
- **Des tables de dimensions** : une par référentiel (produits, magasins, clients, agents,
  calendrier), une ligne par élément, une clé unique, les attributs de regroupement
  (catégorie, zone, segment).
- **Une table calendrier** : une ligne par jour de la période, avec année, mois, semaine,
  jour de la semaine, jour férié, période de paie, fête mobile. C'est elle qui rend la
  saisonnalité lisible et évite les mois à 28 jours comparés à des mois à 31.
- **Clés** : les faits ne portent jamais le libellé (« Riz parfumé 5kg ») mais la clé
  (`ART1000`) ; le libellé vit dans la dimension. Une orthographe change une fois, pas sur
  10 000 lignes.

Contrôles avant d'afficher quoi que ce soit : chaque clé de la table de faits existe dans sa
dimension (`orphelins`, voir `qualite-de-la-donnee/references/inspection-et-nettoyage.py`) ;
la somme de la table de faits sur un mois connu retombe sur le chiffre déjà publié.

## 2. Le catalogue de mesures

Le nom de chaque mesure est stable et suit un motif ; sa formule est écrite une fois, et le
tableau de bord ne calcule jamais lui-même.

| Motif | Exemple | Formule (en clair) |
|---|---|---|
| Total X | Total ventes | somme de la mesure sur le périmètre comptabilisable |
| Nombre de X | Nombre de tickets | comptage des lignes de faits |
| Nombre de X distincts | Clients actifs | comptage distinct de la clé, selon la **définition** de la fiche indicateur |
| Taux de X | Taux de retour | Nombre de X ÷ Nombre total, division protégée (0 si dénominateur nul, affiché « n. d. ») |
| X moyen | Panier moyen | Total ÷ Nombre, avec la médiane à côté quand la distribution est étalée |
| X, N-1 | Ventes, même mois N-1 | même mesure décalée d'un an, périmètre constant |
| Variation X | Variation ventes | (X − X N-1) ÷ X N-1 |
| Part de X | Part du magasin | X du groupe ÷ X total |

Ce qui ne figure **jamais** dans le catalogue sans décision écrite de la direction : un objectif,
un seuil d'alerte, une bande (« gros / moyen / petit »), une pondération. Ils s'écrivent
`⟦à renseigner⟧` et la mesure s'affiche quand même.

## 3. Le plan de tableau de bord (à écrire AVANT de construire)

Repris tel quel du « dashboard build plan » des portfolios, parce que c'est ce qui manque le
plus souvent : on construit d'abord, on découvre ensuite que personne ne sait quoi regarder.

1. **Titre et décision servie** : « Tableau de bord des agences, pour décider où renforcer
   l'effectif ».
2. **Table cible** : nom de la table de faits, nombre de lignes brutes, lignes signalées,
   lignes comptabilisables, période, date du dernier rafraîchissement.
3. **Vue 1, Direction** : 5 à 7 mesures en tuiles (valeur, N-1, variation), 3 à 4 graphiques
   qui répondent chacun à une question écrite, une zone « à retenir » en trois lignes.
4. **Vue 2, Causes** : les mêmes mesures découpées par le facteur qui explique (segment, zone,
   canal, bande), un nuage de points quand deux mesures sont liées.
5. **Vue 3, Détail** : matrice entité × période, tri et filtre, export.
6. **Vue 4, Lecture et limites** : ce que le tableau montre, ce qu'il ne mesure pas, la
   définition de chaque mesure (lien vers la fiche), le statut provisoire / définitif.
7. **Filtres** : période, entité, statut ; jamais plus de cinq.
8. **Rafraîchissement** : qui, quand, combien de temps, ce qui casse si la source change.

Une vue par destinataire (`du-tableur-au-tableau-de-bord`) : le dirigeant lit la vue 1 sur
son téléphone, le chef de service vit dans la vue 3.

## 4. Ce qu'on ne reprend pas des portfolios

- Plafonner les valeurs extrêmes au 99e centile pour « lisser » : chez nous elles se signalent
  et se font qualifier ; une grosse commande réelle n'est pas un bruit.
- Supprimer les lignes incomplètes avant d'analyser : on les marque et on les compte, sinon
  le taux de remplissage disparaît avec elles.
- Fixer des bandes de valeur dans la vue nettoyée sans les avoir fait décider : les seuils
  sont des chiffres, et les chiffres viennent de la maison.
