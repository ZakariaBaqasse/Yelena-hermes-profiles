---
id: Y0691
name: dictionnaire-des-donnees
description: "Écrit et tient le référentiel des données de l'entreprise : pour chaque champ d'un fichier, d'une table ou d'un export réellement utilisé, sa définition en français courant vérifiée dans les valeurs réelles, son format, sa source, son propriétaire par fonction, sa qualité constatée et les indicateurs qui en dépendent, dans un Google Sheet daté et vivant, sans jamais consigner une valeur personnelle réelle en exemple."
bucket: B
tags: [Données, Référentiel, Nouveau]
version: 1
maj: 2026-09-21
---

# Le dictionnaire des données, pour que tout le monde parle du même chiffre

## Ce qu'il faut avoir sous la main
- **Un premier fichier, table ou export** que tu manipules réellement aujourd'hui, avec un accès en lecture (pas seulement une description) : un tableau de ventes, un export mobile money, un fichier stock, un formulaire.
- **Qui saisit ce fichier** et qui pourrait répondre sur ce que veulent dire ses champs, même approximativement.
- **Les indicateurs ou tableaux de bord** déjà suivis dans l'entreprise, pour que je puisse relier les champs à ce qu'ils font tourner.
- **Le rythme** auquel tu veux enrichir le dictionnaire : à chaque nouveau fichier reçu, une fois par mois, autre.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un fichier ou un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu ne redemandes que ce qui est réellement indispensable et impossible à déduire des données elles-mêmes.

## Process
### Étape 1 : Partir de ce qui existe

Ouvre l'inventaire par les fichiers réellement manipulés cette semaine par l'entreprise : le tableau que le commercial tient à jour, l'export du mobile money reçu chaque soir, le fichier stock, le formulaire papier scanné, le tableau croisé que quelqu'un refait à la main chaque fin de mois. Pas le schéma de données propre qu'un consultant dessinerait pour une entreprise idéale.

Le piège classique ici : documenter la base de données que l'entreprise devrait avoir, et laisser de côté les trois fichiers Excel bancals qui font tourner l'activité réelle. Le dictionnaire documente ce qui fait tourner l'entreprise aujourd'hui, même redondant, même informel, parce que c'est ce qui casse quand quelqu'un le modifie sans le savoir.

Pour chaque source retenue, note d'abord : qui l'a créée, qui la modifie, à quelle fréquence, et dans quel outil elle vit (Google Sheet, Excel local, export d'une application mobile money, base d'un logiciel de caisse). Une source sans personne qui sait en parler est déjà un signal : elle devient candidate à la feuille d'alertes.

### Étape 2 : Lire les valeurs réelles pour déduire le format

Pour chaque champ retenu, ouvre la colonne et regarde un échantillon de valeurs réelles avant d'écrire quoi que ce soit. Le nom d'un champ ment souvent : une colonne « date de vente » peut ne contenir que la date à laquelle quelqu'un a tapé la ligne dans le tableau, plusieurs jours après la vente réelle, parce que la vente s'est faite au comptoir en cash et n'a été reportée que le soir, faute de connexion disponible ou de smartphone à portée de main sur le moment. Tu ne le sais qu'en comparant la date affichée avec ce que raconte la personne qui vend.

Ce décalage entre l'événement et sa saisie est fréquent dès qu'une partie de la chaîne passe par un canal informel avant d'atterrir dans un tableau : une vente notée sur un carnet, un montant envoyé par un message WhatsApp, un export mobile money collecté à un autre moment que la transaction elle-même. Le dictionnaire ne corrige pas ce décalage, il le nomme dans la définition du champ, pour que personne ne prenne « date de vente » pour argent comptant sans savoir ce qu'elle mesure réellement.

Fais la même lecture pour les valeurs possibles : un champ « statut » censé contenir trois valeurs (payé, en attente, annulé) en contient parfois sept, à cause de fautes de frappe ou de libellés ajoutés au fil du temps sans qu'on les harmonise. Ce qui compte dans le dictionnaire, c'est ce que le champ contient réellement aujourd'hui, écarts inclus. La liste propre qu'il devrait contenir n'entre pas dans le dictionnaire.

### Étape 3 : Faire définir le champ par qui le remplit

La définition d'un champ vient d'abord de la personne qui le saisit au quotidien. Qui le lit dans un rapport la connaît rarement de la même façon. Le commercial qui remplit « montant » sait s'il inclut la remise ou non ; l'analyste qui produit le tableau de bord l'ignore souvent. Interroge la personne qui saisit, fais-la reformuler dans ses propres mots, et ne te contente pas d'une réponse d'une ligne : demande un exemple concret de cas limite (une vente annulée puis reprise, un client qui paie en deux fois) pour voir où la définition tient et où elle vacille.

Écris ensuite la définition en français courant, celle qu'un nouvel arrivant comprendrait sans qu'on lui explique le métier. « Chiffre d'affaires net » ne se définit pas par un renvoi vague à un plan comptable : elle se définit par une phrase qui dit ce qui est inclus (les ventes de quoi, sur quelle période) et ce qui est exclu (les taxes, les retours, les annulations, les remises). Si l'entreprise tient sa comptabilité selon le référentiel commun harmonisé par l'OHADA (le SYSCOHADA), aligne le vocabulaire du champ sur celui déjà utilisé par le service comptable plutôt que d'en inventer un troisième, sans jamais citer un compte ou un article que tu n'as pas toi-même vérifié.

Une définition qui ne tient qu'en jargon financier ou technique n'a rien réglé : elle a juste déplacé le malentendu d'un champ vers une phrase. Si tu ne peux pas la reformuler simplement, c'est que tu ne l'as pas encore comprise.

### Étape 4 : Nommer un propriétaire par fonction

Chaque champ porte un propriétaire, mais un propriétaire nommé par fonction (responsable commercial, gestionnaire de stock, responsable comptable) et non par le prénom de la personne en poste aujourd'hui. Les équipes tournent, et un dictionnaire qui pointe vers une personne plutôt que vers une fonction devient faux le jour où elle change de poste, sans que personne pense à le corriger.

Un champ sans propriétaire dérive en silence : personne ne s'assure que la valeur reste cohérente, personne ne signale quand le comportement du champ change. Si aucune fonction ne peut répondre du champ, c'est un signal en soi : soit le champ est orphelin (étape 6), soit il faut décider maintenant qui en devient responsable.

### Étape 5 : Relier chaque champ aux indicateurs qui en dépendent

Un champ qui n'alimente aucun indicateur mérite d'être noté comme tel, mais la vraie valeur du dictionnaire tient dans le sens inverse : pour chaque champ, la liste des indicateurs qui s'en servent. C'est ce lien qui permet, le jour où quelqu'un modifie une règle de saisie ou ajoute une valeur possible dans une liste déroulante, de savoir immédiatement quels tableaux de bord risquent de casser, plutôt que d'attendre qu'un chiffre étrange remonte en réunion des semaines plus tard.

Ce lien se construit avec la compétence dédiée au calcul des indicateurs (`definir-un-indicateur`) : elle définit comment un indicateur se calcule, ce dictionnaire définit d'où viennent ses ingrédients. Les deux se répondent : un indicateur mal défini pointe souvent vers un champ mal défini, et un champ dont personne ne sait qu'il alimente un indicateur critique est un risque qui ne se voit qu'après coup.

### Étape 6 : Détecter les orphelins et les doublons

Un champ orphelin est un champ dont personne dans l'entreprise ne sait dire d'où il vient ni à quoi il sert, souvent hérité d'un ancien fichier, d'un import mal nettoyé, ou d'une colonne ajoutée au cas où puis oubliée. Tu ne le supprimes pas : tu le signales dans la feuille d'alertes, avec ce que tu as pu observer de ses valeurs, en attendant que quelqu'un tranche.

Un doublon est plus insidieux : deux champs, parfois dans deux fichiers différents, qui prétendent mesurer la même chose sans le dire, avec deux définitions qui n'ont jamais été confrontées. Le cas le plus fréquent dans une petite entreprise : le service commercial et le service comptable ont chacun leur propre « chiffre d'affaires », sur des périmètres différents (avec ou sans taxes, avec ou sans les ventes non encore encaissées), et personne ne l'a jamais remarqué parce que les deux chiffres circulent dans des documents différents. Tu ne tranches pas laquelle des deux définitions est la bonne : tu les mets face à face dans la feuille d'alertes et tu demandes l'arbitrage aux deux fonctions concernées.

### Étape 7 : Dater chaque vérification et prévoir la revue

Chaque ligne du dictionnaire porte la date à laquelle son format, ses valeurs et sa définition ont été vérifiés. La date de création du dictionnaire ne renseigne pas sur la fraîcheur d'un champ. Un champ vérifié il y a longtemps n'est pas un champ dont on peut encore garantir qu'il dit toujours ce qu'il disait : les habitudes de saisie glissent, une liste déroulante s'enrichit, un champ change de sens sans annonce. Le délai à partir duquel un champ passe « à revérifier » est une décision de l'équipe, selon le rythme de son activité et la taille de l'équipe qui saisit : tu portes la colonne, la valeur du seuil reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.

Le dictionnaire ne se referme jamais : chaque nouveau fichier reçu, chaque nouvel export branché, chaque nouveau formulaire créé s'y ajoute au fil de l'eau. Un dictionnaire produit en une fois en fin de mission, sans plan pour continuer à l'alimenter, retombe dans le premier piège dès le mois suivant.

## Format de sortie
- **Livrable** : un Google Sheet « Dictionnaire des données », avec une feuille par source (fichier, table, export). Pour chaque champ : nom technique, nom en clair, définition en français courant, format, valeurs possibles ou fourchette observée, source et fréquence, propriétaire (fonction), qualité constatée, indicateurs qui s'en servent, date de dernière vérification.
- **Une feuille d'alertes** distincte : champs orphelins, doublons entre sources, définitions contradictoires entre deux services, chacun avec ce qui a été observé et la décision attendue.
- **Une page de présentation** en une page, écrite pour l'équipe : à quoi sert le dictionnaire, qui le consulte, qui le met à jour, comment signaler un champ suspect.
- **Structure de travail** : Markdown ou tableau pour le brouillon immédiat, mais le livrable final vit dans le Google Sheet. Un document séparé se désynchronise.
- **Le délai de revérification est un input** : la skill livre la colonne, la fonction propriétaire du champ décide de la valeur, qui reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée par l'équipe.
- **Aucune valeur personnelle réelle en exemple** : les colonnes « valeurs possibles » utilisent des exemples fictifs ou masqués (jamais un vrai nom, un vrai numéro de téléphone, un vrai montant identifiable).
- **Règle 0 invention** : aucune définition, aucun format, aucune valeur n'est produit sans avoir été lu dans les données réelles ou confirmé par la personne qui saisit. Une information manquante est marquée « à confirmer / [placeholder] ».

## Règles
1. **La définition se vérifie dans les valeurs, jamais dans le nom du champ.** Tu ouvres la colonne, tu regardes un échantillon réel, avant d'écrire quoi que ce soit.
2. **Chaque champ porte une date de dernière vérification.** Passé le délai fixé par l'équipe, il repasse « à revérifier » : le dictionnaire ne se fige jamais.
3. **La définition s'écrit en français courant.** Si elle ne tient pas sans jargon, tu ne l'as pas encore comprise ; tu la reformules jusqu'à ce qu'un nouvel arrivant la comprenne sans explication.
4. **Chaque champ a un propriétaire désigné par fonction, jamais par prénom.** Un champ sans fonction responsable est un champ qui dérive sans que personne le sache.
5. **Chaque champ dit quel indicateur casse s'il change.** Sans ce lien, une modification de saisie casse un tableau de bord sans que personne comprenne pourquoi.
6. **Le dictionnaire démarre au premier fichier reçu.** Tu ne l'écris pas en fin de mission : tu l'enrichis à chaque nouvelle source, dès le début.
7. **Aucune valeur personnelle réelle en exemple.** Nom, numéro de téléphone, montant identifiable : toujours fictif ou masqué, sans exception, même si la personne interrogée en propose un vrai spontanément.
8. **Un doublon ou une contradiction se signale, ne se tranche pas seul.** Deux services qui utilisent le même mot pour deux réalités différentes se mettent face à face dans la feuille d'alertes ; l'arbitrage revient aux fonctions concernées.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit et tient un référentiel de travail ; modifier des données de production, partager le dictionnaire hors de l'entreprise ou envoyer un fichier à un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un fichier ou d'un service ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Fichier reçu sans personne pour l'expliquer** (l'auteur est parti, personne ne se souvient) : tu documentes ce que les valeurs réelles montrent, tu marques la définition « à confirmer », tu n'inventes jamais ce que le champ voulait dire.
- **Deux définitions concurrentes pour le même mot entre deux services** : tu ne tranches pas, tu exposes les deux versions côte à côte dans la feuille d'alertes et tu demandes l'arbitrage.
- **Un champ change de sens en cours de route** (une catégorie ajoutée, un format modifié à une date donnée) : tu notes la date de bascule, tu ne fusionnes jamais silencieusement les deux périodes sous une même définition.
- **Source qui passe par un canal informel avant la saisie** (vente notée sur un carnet, montant envoyé par WhatsApp, export mobile money collecté plus tard que la transaction) : tu nommes ce décalage dans la définition du champ plutôt que de le corriger ou de le taire.
- **Tu as seulement un extrait d'un fichier** : le fichier complet ne t'est pas fourni. Le dictionnaire porte sur ce que tu as vu, tu le signales explicitement, tu ne généralises pas au fichier entier.
- **Champ sensible** (données financières, ressources humaines, données personnelles) : les valeurs consignées en exemple sont toujours fictives ou masquées, y compris quand la personne interrogée propose spontanément un vrai exemple.
- **Champ lié à une exigence réglementaire** (identification client, vérification d'identité) : tu notes qu'une définition réglementaire existe et qu'elle doit être validée par la fonction compétente ; tu ne cites aucun texte ni seuil que tu n'as pas toi-même reçu ou vérifié.
- **Action sortante demandée** (partager le dictionnaire hors de l'entreprise, le publier, l'envoyer à un tiers, modifier une donnée de production) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** (calculer effectivement un indicateur) : documenter ses ingrédients ne suffit pas à cette demande. Tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers `definir-un-indicateur`.
- **Sources contradictoires sur un même champ** : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
