---
id: Y0705
name: cartographie-et-geodonnees
description: "Met des chiffres sur une carte quand la géographie décide : points de vente, clients, livraisons, agents terrain, zones de chalandise, tournées, couverture par commune ou par ville. Géocode à partir d'adresses ou de coordonnées relevées, produit une carte interactive autoportante (HTML, lisible sur téléphone) ou une carte statique pour un document, et dit ce que la carte montre et ce qu'elle ne montre pas. Ne devine jamais une position, n'invente jamais une limite administrative, et traite une adresse de client comme une donnée personnelle."
bucket: B
tags: [Données, Cartographie, Géographie, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Une carte est un tableau de bord dont l'axe est le territoire

## Ce qu'il faut avoir sous la main
- **La question** que la carte doit trancher : où ouvrir, où sont les clients qu'on ne sert pas, quelle tournée coûte le plus, quelle commune concentre les retards.
- **Des positions** : coordonnées GPS relevées (téléphone, application de collecte), ou adresses assez précises pour être placées (commune, quartier, repère). À Abidjan, « Cocody » place au mieux dans une commune de plusieurs kilomètres : une zone, pas un point, et la carte le dira.
- **Le chiffre à porter** sur chaque point ou zone : ventes, clients, délai, stock, avec sa définition.
- **Les fonds et découpages** : limites de communes ou de départements issues d'une source ouverte identifiée (données ouvertes nationales, OpenStreetMap), avec leur date. Sans source ouverte, pas de limite tracée.

> ⚡ **Sans coordonnées, tu produis quand même** : une carte par zone déclarée (commune, ville) avec un aplat par zone, et la fiche de relevé GPS (`collecte-terrain`) pour passer aux points la fois suivante.

## Process
### Étape 1, Qualifier la précision de chaque position
Trois niveaux, écrits sur chaque ligne : **point relevé** (GPS), **adresse placée** (géocodage, avec la précision renvoyée), **zone déclarée** (commune ou ville). Une carte qui mélange les trois sans le dire fait croire à une précision qu'elle n'a pas. Le géocodage passe par une intégration déclarée (dossier `integrations/`, service gratuit ou coût annoncé), jamais par un appel improvisé, et son résultat se vérifie sur un échantillon.

### Étape 2, Choisir la représentation qui répond à la question
- **Points** pour localiser (où sont les clients, les points de vente).
- **Cercles proportionnels** pour comparer un volume par point.
- **Aplats par zone** (choroplèthe) pour une part ou un taux par commune, jamais pour un volume brut (une grande commune paraît toujours forte).
- **Lignes** pour une tournée ou un flux.
- **Grille de densité** quand les points sont trop nombreux pour se lire.
Le chiffre porté est celui de l'indicateur défini, avec sa période ; la légende dit l'unité et la source.

### Étape 3, Fabriquer
Carte interactive avec `folium` (`~/.venv-office/bin/python`), fichier HTML autoportant, lisible sur un téléphone d'entrée de gamme (couches limitées, pas d'image lourde) ; carte statique avec `matplotlib` pour un PDF ou une présentation. Charte du client appliquée (`charte-du-client`, `standard-de-rendu`), palette lisible par un daltonien, échelle et nord quand la distance compte.

### Étape 4, Écrire ce que la carte montre et ce qu'elle cache
Une concentration de points peut être une concentration de clients ou une concentration de saisies : les zones sans collecte se marquent comme non mesurées, pas comme vides (`ce-qui-ne-se-mesure-pas`). Les distances à vol d'oiseau ne sont pas des temps de trajet ; les temps de trajet ne s'inventent pas.

### Étape 5, Protéger les personnes
Une adresse de client, un domicile de salarié, la position d'un agent sont des données personnelles (`donnees-personnelles-ci`) : agrégation par zone dès que la carte sort du cercle qui en a besoin, pas de point nominatif sur une carte partagée par lien.

## Format de sortie
- **Carte interactive** HTML (une couche par indicateur, filtre par période si utile), déposée avec les livrables et partagée au périmètre strict.
- **Carte statique** PNG ou PDF pour insertion dans une note.
- **Tableau des positions** avec leur niveau de précision et leur source (`tableur-livrable`).
- **Deux paragraphes** : ce que la carte montre, ce qu'elle ne permet pas de conclure.

## Règles
1. **Aucune position devinée** : sans coordonnée ni adresse placée, le point n'existe pas, la zone le remplace.
2. **Aucune limite administrative sans source ouverte datée** ; un découpage de quartier « de mémoire » ne se trace pas.
3. **Volume brut en aplat interdit** ; un aplat porte un taux ou une part.
4. **Précision affichée** : la légende dit combien de points sont relevés, placés, ou en zone.
5. **Données personnelles agrégées** dès que la carte circule.
6. **Pas de temps de trajet, de rayon de chalandise ou de population sans source** ; un chiffre de population de commune vient d'un recensement cité avec sa date.

## Cas limites
- **Adresses ivoiriennes sans numéro ni rue** : le géocodage échoue souvent ; on relève le GPS au prochain passage, et d'ici là on cartographie par quartier déclaré.
- **Trop de points** : grille ou regroupement, jamais une carte illisible qu'on présente quand même.
- **Concurrents sur la carte** : seulement à partir d'une source ouverte, avec sa date ; jamais un emplacement « connu de tout le monde ».
