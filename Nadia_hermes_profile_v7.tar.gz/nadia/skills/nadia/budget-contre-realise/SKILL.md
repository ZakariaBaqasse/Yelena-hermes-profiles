---
id: Y0402
name: budget-contre-realise
description: "Confronte le budget au réalisé poste par poste, décompose l'écart entre effet volume et effet prix, qualifie chaque écart significatif comme décision ou dérive avec un responsable nommé, et produit une prévision de fin d'exercice actualisée — sans jamais commenter un écart sous le seuil de matérialité ni fabriquer un budget de référence qui n'existe pas."
bucket: B
tags: [Finance, Pilotage, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Budget contre réalisé — l'écart, sa cause, et ce qu'on en fait

## Ce qu'il faut avoir sous la main
- **Le budget initial**, poste par poste, avec la période couverte (exercice, trimestre, mois).
- **Le réalisé à date** — export comptable ou tableau de suivi, avec le niveau de détail disponible (par compte, par centre de coût, par projet).
- **Le seuil de matérialité** déjà retenu par la direction, s'il existe — en valeur absolue et/ou en pourcentage. S'il n'existe pas, je le construis avec toi à l'étape 2.
- **Les responsables de poste**, si un découpage existe (qui répond de quoi).
- **Les décisions connues** qui expliquent déjà certains écarts : recrutement anticipé, opportunité d'achat saisie, révision de prix fournisseur, changement de devise sur un achat importé.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Construire le budget de référence, s'il n'existe pas

Si un budget initial existe déjà, tu pars de lui tel quel — tu ne le corriges ni ne le rediscutes à ce stade. S'il n'existe pas, tu le construis à partir de deux sources uniquement : l'historique comptable de l'entreprise (plan de comptes SYSCOHADA, exercices précédents) et les engagements déjà connus et documentés — contrats de bail, masse salariale prévue avec ses charges CNPS, échéances de crédit, commandes fermes. Tu ne complètes jamais un poste manquant par une estimation sectorielle non sourcée : un poste sans historique ni engagement documenté reste `⟦à renseigner⟧`, et tu le dis à la direction plutôt que de fabriquer un chiffre plausible.

Un budget construit sur des suppositions non tracées produit un suivi qui compare le réalisé à du vent — l'écart affiché n'a alors aucune valeur de pilotage.

### Étape 2 — Fixer et écrire le seuil de matérialité

Le seuil se pose en deux termes, pas un seul : une valeur absolue (en dessous, l'écart est négligeable quel que soit le poste) et un pourcentage du poste budgété (un petit poste peut varier fortement en pourcentage sans que ça compte, un gros poste peut varier peu en pourcentage et représenter une somme significative). Les deux valeurs sont une **décision de la direction**, pas une production de la compétence : tu poses la question, tu proposes la structure, la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée.

Une fois fixé, le seuil s'applique uniformément à toute la période de suivi. Le changer en cours d'exercice pour faire rentrer ou sortir un poste du commentaire est un contournement que tu signales s'il t'est demandé.

### Étape 3 — Suivre poste par poste, filtrer avant de commenter

Pour chaque poste : budget, réalisé, écart en valeur, écart en pourcentage. Tu compares l'écart au seuil de matérialité *avant* de rédiger un commentaire. En dessous du seuil, le poste apparaît dans le tableau sans ligne d'explication — il est suivi, pas commenté. Au-dessus, il passe aux étapes suivantes.

Attention à la source du réalisé : une partie des fournisseurs ou prestataires peut être informelle et ne pas produire de facture datée dans le même mois que la dépense réelle — un décalage entre décaissement et comptabilisation peut créer un faux écart de timing plutôt qu'un vrai écart de montant. Tu le vérifies avant de qualifier.

### Étape 4 — Décomposer volume et prix, et isoler l'effet change quand il existe

Pour les postes où la notion s'applique — achats de matières, énergie, transport, sous-traitance — un dépassement se décompose en deux effets qui ne se corrigent pas de la même façon : l'écart de **volume** (on a acheté ou produit plus, ou moins, que prévu) et l'écart de **prix** (le prix unitaire a bougé, à volume constant). Confondre les deux fait dire « il faut réduire les volumes » à un poste où le vrai problème est un prix fournisseur en hausse — la bonne réponse est alors une renégociation ou une couverture, pas une coupe d'activité.

Sur les postes liés à un achat importé, distingue l'effet prix pur de l'effet change. Le franc CFA a une parité fixe avec l'euro : un achat facturé en euros ne porte pas de risque de change à surveiller ici. En revanche, un achat facturé en dollars ou dans une devise hors zone euro (carburant, certaines matières premières, pièces détachées, prestations informatiques importées) peut faire varier le réalisé en francs CFA sans qu'aucun volume ni aucun prix contractuel n'ait bougé — tu le signales comme effet de change distinct, pas comme dérive du fournisseur.

### Étape 5 — Qualifier chaque écart significatif : décision ou dérive

Pour chaque poste au-dessus du seuil, la question à trancher est binaire : cet écart vient-il d'une **décision** prise et assumée (recrutement anticipé, achat d'opportunité, arbitrage budgétaire fait en cours d'exercice), ou d'une **dérive** non pilotée (dépassement non anticipé, glissement de calendrier subi, hausse fournisseur non répercutée) ? La qualification appartient au responsable du poste, pas à la finance seule — un écart commenté uniquement par le contrôle de gestion est deviné, pas expliqué.

Le canal de collecte s'adapte au terrain : un échange WhatsApp avec le responsable de poste, une note courte, un appel — l'important est que la réponse soit tracée avec un nom, pas anonymisée dans le tableau.

### Étape 6 — Réviser la prévision de fin d'exercice

Le budget initial reste inchangé et visible — il sert de référence historique et ne se retouche jamais rétroactivement. À côté, tu produis une **prévision de fin d'exercice actualisée** : pour chaque poste, ce que le réalisé cumulé plus la trajectoire des mois restants laisse anticiper, en tenant compte des décisions déjà prises et des dérives identifiées comme susceptibles de se poursuivre. Les deux documents coexistent — un budget confronté au réel pendant toute une année sans être jamais révisé devient une fiction dont l'écart affiché ne pilote plus rien.

Le déclenchement d'une révision (à chaque clôture mensuelle, à chaque trimestre, ou sur seuil de cumul dépassé) est une règle que tu fais poser par la direction et que tu appliques ensuite avec constance.

### Étape 7 — Établir la liste de vigilance du mois suivant

Tu termines par les postes qui, sans avoir franchi le seuil ce mois-ci, montrent une tendance qui s'en approche (dérive de prix qui s'installe, volume en écart croissant, décision annoncée mais pas encore comptabilisée). C'est la partie du livrable qui évite qu'un écart devienne significatif sans avoir été vu venir.

## Format de sortie
- **Livrable** : le tableau de suivi — par poste : budget, réalisé, écart en valeur et en pourcentage, décomposition volume-prix (et effet change) quand elle s'applique, cause, nature de l'écart (décision ou dérive), responsable nommé, action décidée. Suivi de la prévision de fin d'exercice actualisée en regard du budget initial, du seuil de matérialité retenu, et de la liste des postes à surveiller le mois suivant.
- **Structure** : Markdown clair, tableau par poste, answer-first — les postes au-dessus du seuil et leur qualification d'abord, le reste ensuite.
- **Longueur** : proportionnée au nombre de postes suivis, sans remplissage — un poste sous le seuil n'a droit qu'à sa ligne de chiffres, pas à un paragraphe.
- **Le seuil de matérialité est un input**, pas une production : la structure (valeur absolue + pourcentage) est livrée, la valeur reste `⟦à renseigner⟧` tant qu'elle n'est pas donnée par la direction.
- **Règle 0 invention** : aucun montant, taux de change, ou pourcentage inventé. Poste sans donnée fiable : `[à confirmer]`, jamais une estimation qui a l'air plausible.

## Règles
1. **En dessous du seuil, on ne commente pas.** Le seuil de matérialité, une fois fixé avec la direction, s'applique sans exception à tous les postes de la période. Un commentaire sous le seuil dilue l'attention sur ce qui compte vraiment.
2. **Une décision n'est pas une dérive.** Chaque écart significatif est qualifié par le responsable du poste, jamais par défaut ni par la seule finance. Confondre les deux transforme le suivi budgétaire en outil punitif, et un outil punitif produit de la dissimulation.
3. **Volume et prix se traitent séparément.** Sur les postes où la distinction s'applique, tu ne recommandes jamais une action de volume pour corriger un écart de prix, ni l'inverse.
4. **L'effet de change n'est signalé que là où il existe réellement.** Un achat facturé en euros ne porte pas de risque de change du fait de la parité fixe du franc CFA — tu ne l'invoques pas comme explication par facilité. Un achat facturé en dollars ou en devise hors zone euro, si.
5. **Le budget initial ne se retouche jamais rétroactivement.** Toute révision produit un document distinct, daté, conservé à côté de l'original — jamais une réécriture qui efface la trace de la prévision de départ.
6. **Chaque poste a un responsable nommé.** Un écart sans nom associé n'est pas un écart expliqué — il reste en attente d'explication et tu le signales comme tel plutôt que de le clore toi-même.
7. **0 chiffre inventé.** Aucun budget de référence reconstitué à partir d'une supposition sectorielle, aucun taux de change, aucun pourcentage de seuil produit sans être fourni ou sourcé : `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser le tableau à un comité, engager une révision budgétaire officielle ou notifier un responsable est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entité ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun budget initial n'existe** — tu le construis à partir de l'historique comptable et des engagements documentés, en marquant `⟦à renseigner⟧` tout poste sans base fiable, et tu le signales comme budget reconstitué plutôt que comme budget validé par la direction.
- **Poste sans responsable identifié** — tu le signales explicitement dans le tableau plutôt que de qualifier l'écart toi-même ou de l'attribuer par défaut à la finance.
- **Fournisseur informel sans facture datée** — tu vérifies le décalage entre décaissement réel et comptabilisation avant de qualifier l'écart comme dérive ; un faux écart de timing n'est pas une dérive.
- **Seuil de matérialité non fourni** — tu livres la structure de la grille (absolu + pourcentage) avec la valeur en `⟦à renseigner⟧`, tu ne fixes jamais un seuil à la place de la direction.
- **Écart lié à une devise hors zone euro** — tu isoles l'effet de change de l'effet prix et de l'effet volume, et tu ne l'invoques pas sur un poste facturé en euros.
- **Décision annoncée mais non encore comptabilisée** — tu la mentionnes dans la liste de vigilance plutôt que dans le tableau d'écarts du mois, pour ne pas anticiper un chiffre qui n'existe pas encore.
- **Source comptable et déclaration du responsable contradictoires** — tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
- **Demande hors périmètre** (construction du budget initial complet à partir de zéro sans aucun historique, analyse de rentabilité par produit) — tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (diffusion du rapport, notification aux responsables, transmission à un comité ou à un tiers externe) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
