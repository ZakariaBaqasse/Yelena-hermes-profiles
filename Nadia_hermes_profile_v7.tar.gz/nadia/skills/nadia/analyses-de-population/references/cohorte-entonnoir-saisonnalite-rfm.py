#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Recettes pandas pour les quatre analyses de population : cohorte, entonnoir, saisonnalité, RFM.

Techniques reprises du Python Data Science Handbook (J. VanderPlas, chapitres pandas :
aggregation-and-grouping, pivot-tables, working-with-time-series) et des requêtes de rétention
de portfolios publics (STCybersec), relus le 21/09/2026, transposées aux règles du poste :
  * les bornes de segments sont des quantiles OBSERVÉS, présentés comme proposition ;
  * une étape non journalisée reste NaN, jamais 0 ;
  * les cohortes se comparent à durée égale.

Chaque fonction prend un DataFrame déjà passé par le contrôle de qualité et rend une table
prête pour le tableur ou le graphique. Exécuter avec ~/.venv-office/bin/python.
"""
import pandas as pd
import numpy as np


# ── Cohorte de rétention ─────────────────────────────────────────────────────
def cohorte(df, col_client="client", col_date="date", col_montant=None, freq="M"):
    """Triangle : cohorte (période de 1re commande) × périodes écoulées → clients actifs et % de la cohorte."""
    d = df[[col_client, col_date] + ([col_montant] if col_montant else [])].copy()
    d[col_date] = pd.to_datetime(d[col_date])
    d["periode"] = d[col_date].dt.to_period(freq)
    d["cohorte"] = d.groupby(col_client)["periode"].transform("min")
    d["ecoule"] = (d["periode"] - d["cohorte"]).apply(lambda x: x.n)
    actifs = d.groupby(["cohorte", "ecoule"])[col_client].nunique().unstack(fill_value=0)
    taille = actifs[0]
    pct = actifs.div(taille, axis=0).round(3)
    # les cases au-delà de la période observable restent NaN (pas 0) : la cohorte n'a pas ce recul
    derniere = d["periode"].max()
    for c in pct.index:
        recul = (derniere - c).n
        pct.loc[c, pct.columns > recul] = np.nan
        actifs.loc[c, actifs.columns > recul] = np.nan
    out = {"clients_actifs": actifs, "pct_de_la_cohorte": pct, "taille_cohorte": taille}
    if col_montant:
        out["montant_cumule_par_client"] = (d.groupby(["cohorte", "ecoule"])[col_montant].sum().unstack()
                                             .cumsum(axis=1).div(taille, axis=0).round(0))
    return out


# ── Entonnoir ────────────────────────────────────────────────────────────────
def entonnoir(df, etapes, col_groupe=None):
    """etapes : colonnes booléennes ou datées, dans l'ordre réel. Une colonne absente → étape non mesurée (NaN)."""
    g = df.groupby(col_groupe) if col_groupe else [("total", df)]
    lignes = []
    for nom, part in g:
        ligne = {"groupe": nom}
        prec = None
        for e in etapes:
            if e not in part.columns:
                ligne[e], ligne[f"passage_{e}"] = np.nan, np.nan   # non mesuré, pas zéro
                continue
            n = int(part[e].notna().sum()) if part[e].dtype != bool else int(part[e].sum())
            ligne[e] = n
            ligne[f"passage_{e}"] = round(n / prec, 3) if prec else np.nan
            prec = n
        lignes.append(ligne)
    return pd.DataFrame(lignes)


# ── Saisonnalité ─────────────────────────────────────────────────────────────
def profils_saisonniers(df, col_date="date", col_valeur="montant"):
    """Profils par jour de semaine, par mois, et décomposition tendance/saison/résidu si ≥ 2 cycles."""
    s = df.set_index(pd.to_datetime(df[col_date]))[col_valeur].resample("D").sum()
    jours = s.groupby(s.index.dayofweek).agg(["mean", "median", "count"]).rename(
        index=dict(enumerate(["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"])))
    mois = s.resample("ME").sum()
    par_mois = mois.groupby(mois.index.month).agg(["mean", "count"])
    out = {"par_jour_semaine": jours, "par_mois": par_mois, "serie_mensuelle": mois}
    if len(mois) >= 24:
        from statsmodels.tsa.seasonal import STL
        res = STL(mois, period=12, robust=True).fit()
        out["decomposition"] = pd.DataFrame({"tendance": res.trend, "saison": res.seasonal, "residu": res.resid})
    else:
        out["decomposition"] = "moins de deux cycles annuels : saisonnalité non établie"
    return out


# ── RFM ──────────────────────────────────────────────────────────────────────
def rfm(df, col_client="client", col_date="date", col_montant="montant", date_ref=None, n=5):
    """Récence, fréquence, montant par client ; scores en quantiles OBSERVÉS (proposition à valider)."""
    d = df.copy()
    d[col_date] = pd.to_datetime(d[col_date])
    ref = pd.Timestamp(date_ref) if date_ref else d[col_date].max()
    t = d.groupby(col_client).agg(recence_jours=(col_date, lambda x: (ref - x.max()).days),
                                  frequence=(col_date, "count"), montant=(col_montant, "sum"))
    t["R"] = pd.qcut(t["recence_jours"].rank(method="first", ascending=False), n, labels=range(1, n + 1)).astype(int)
    t["F"] = pd.qcut(t["frequence"].rank(method="first"), n, labels=range(1, n + 1)).astype(int)
    t["M"] = pd.qcut(t["montant"].rank(method="first"), n, labels=range(1, n + 1)).astype(int)
    bornes = {k: t[c].quantile([0.2, 0.4, 0.6, 0.8]).round(0).tolist() for k, c in
              [("recence_jours", "recence_jours"), ("frequence", "frequence"), ("montant", "montant")]}
    return t.sort_values(["R", "F", "M"], ascending=False), bornes   # les bornes se montrent, la maison tranche


# ── Variation période sur période ────────────────────────────────────────────
def variation(serie_mensuelle):
    """Mois précédent et même mois N-1, à périmètre constant (à vérifier avant d'utiliser)."""
    s = serie_mensuelle
    return pd.DataFrame({"valeur": s, "mois_precedent": s.shift(1), "var_mois_pct": (s.pct_change() * 100).round(1),
                         "meme_mois_n_1": s.shift(12), "var_annuelle_pct": (s.pct_change(12) * 100).round(1)})


if __name__ == "__main__":
    # démonstration sur des données inventées pour vérifier que tout tourne
    rng = np.random.default_rng(1)
    n = 3000
    demo = pd.DataFrame({"client": rng.integers(1, 300, n),
                         "date": pd.Timestamp("2024-09-01") + pd.to_timedelta(rng.integers(0, 730, n), "D"),
                         "montant": rng.integers(1000, 50000, n),
                         "source": rng.choice(["instagram", "direct", "inconnue"], n)})
    c = cohorte(demo, col_montant="montant")
    print("cohorte :", c["pct_de_la_cohorte"].shape)
    print(profils_saisonniers(demo)["par_jour_semaine"].head(3))
    t, b = rfm(demo); print("rfm :", t.shape, b["montant"])
    demo["panier"] = demo["montant"] > 5000; demo["paiement"] = demo["montant"] > 20000
    print(entonnoir(demo, ["date", "panier", "paiement", "livraison"], "source"))
