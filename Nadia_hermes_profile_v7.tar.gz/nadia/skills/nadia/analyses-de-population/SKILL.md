---
id: Y0706
name: analyses-de-population
description: "Les quatre analyses que la fiche de poste nomme et que le tableau de bord ne fait pas : la cohorte (les clients arrivés à la même période reviennent-ils ?), l'entonnoir (où perd-on les gens entre le premier contact et l'achat ?), la saisonnalité (qu'est-ce qui revient chaque semaine, chaque mois, chaque fête ?) et la segmentation (quels groupes de clients, de produits ou de points de vente se comportent pareil, par récence, fréquence, montant ou autre critère de la maison). Chaque analyse livre la table, le graphique, la lecture, et ce qu'elle ne permet pas de conclure."
bucket: B
tags: [Données, Analyse, Cohorte, Entonnoir, Saisonnalité, Segmentation, Nouveau]
version: 1
maj: 2026-09-21
---

# Quatre façons de découper une population, et ce que chacune prouve

## Ce qu'il faut avoir sous la main
- **La question de décision** : relancer qui, ouvrir quand, simplifier quelle étape, arrêter quel produit.
- **Des lignes au niveau de l'unité** : une commande, un ticket, une visite, un client, avec une date et un identifiant stable. Des totaux mensuels ne permettent ni cohorte ni segmentation.
- **La définition des événements** (`definir-un-indicateur`) : qu'est-ce qu'un « nouveau client », une « commande », une « visite ».
- **Les critères que la maison utilise déjà** pour parler de ses clients ou de ses produits (gros / petits, réguliers / occasionnels, Abidjan / intérieur) : on part de là avant d'en inventer d'autres.

> ⚡ **Un identifiant client absent n'empêche pas de livrer** : on le dit, on fait la saisonnalité et l'entonnoir (qui n'en ont pas besoin), et on livre la fiche de collecte qui permettra la cohorte et la segmentation le trimestre suivant.

## Process
### Étape 1, Contrôler avant de découper
`qualite-de-la-donnee` d'abord : un client en double casse la cohorte, un mois non saisi fabrique une saisonnalité, une étape non journalisée fait un entonnoir qui fuit au mauvais endroit.

### Étape 2, Cohorte
Regrouper les unités par période d'arrivée (mois de première commande), puis suivre pour chaque groupe ce qui se passe à 1, 2, 3… périodes : part encore active, montant cumulé, nombre de commandes. Table en triangle, graphique en courbes par cohorte. Lecture : les cohortes récentes ont moins de recul, ce n'est pas qu'elles sont moins bonnes ; on compare à durée égale. Le seuil « client perdu » (pas de commande depuis N mois) est une décision de la maison, `⟦à renseigner⟧` sinon.

### Étape 3, Entonnoir
Lister les étapes dans l'ordre réel, compter les unités qui atteignent chacune, calculer le passage d'une étape à la suivante, par période et par source ou canal. Une étape non instrumentée se marque « non mesurée », elle ne se met pas à zéro (`ce-qui-ne-se-mesure-pas`). Lecture : la plus grosse perte en volume n'est pas toujours la plus facile à réduire ; on donne les deux classements.

### Étape 4, Saisonnalité
Décomposer (`prevision-et-estimation`, étape 2) sur au moins deux cycles : profil par jour de la semaine, par semaine du mois, par mois, autour des fêtes mobiles (ramadan, tabaski, fêtes de fin d'année, rentrée) et des paies. Comparer la maison à elle-même seulement, à périmètre constant. Une norme sectorielle ne s'invente pas et ne se cite pas de mémoire.

### Étape 5, Segmentation
Partir des critères de la maison. Si elle n'en a pas, proposer la récence, la fréquence et le montant (RFM) avec des bornes issues des quantiles observés, présentées comme un point de départ à valider, pas comme une vérité. Regroupement statistique (k-moyennes ou autre) seulement si les critères simples ne suffisent pas, et toujours traduit en langage métier (« clients du samedi », « grossistes de l'intérieur »). Chaque segment livre son effectif, son poids dans le chiffre d'affaires et ce qu'on peut faire de différent avec lui ; un segment sans action possible ne sert à rien.

### Étape 6, Écrire ce que ça ne prouve pas
Une cohorte qui décline peut être un produit qui lasse ou une collecte qui s'est relâchée ; un entonnoir qui fuit au paiement peut être un problème de moyen de paiement ou de réseau ce jour-là ; une saisonnalité sur deux ans peut être une coïncidence. Le paragraphe des explications concurrentes fait partie du livrable.

## Format de sortie
- **Note d'analyse** (gabarit `note-d-analyse`) : question, données, méthode, résultats avec tables et graphiques (`dataviz`), lecture, limites, décision proposée à la maison.
- **Tableur** avec les tables (triangle de cohorte, entonnoir par période et canal, profils saisonniers, segments avec leur liste d'unités) (`tableur-livrable`).
- **Fiche de collecte** si un identifiant ou une étape manque (`collecte-terrain`).
Outils : `~/.venv-office/bin/python`, `pandas`, `scipy`, `statsmodels`, `matplotlib`.

## Règles
1. **Pas de cohorte ni de segmentation sans identifiant fiable** ; on le dit et on organise sa collecte.
2. **Étape non mesurée ≠ étape à zéro.**
3. **Cohortes comparées à durée égale**, jamais une cohorte de 2 mois contre une de 12.
4. **Bornes de segments = décision de la maison** ; les quantiles sont une proposition étiquetée comme telle.
5. **Saisonnalité : deux cycles minimum et périmètre constant**, sinon on écrit « tendance non établie ».
6. **Chaque segment porte une action possible**, sinon il disparaît du livrable.

## Cas limites
- **Clients sans identifiant mais avec un numéro de téléphone** : le numéro peut servir d'identifiant, avec les précautions de `donnees-personnelles-ci`, et en signalant les numéros partagés (famille, boutique).
- **Entonnoir avec des étapes hors ligne** (visite en boutique, appel) : on instrumente au plus simple (un trait sur une fiche) avant de conclure que l'étape « ne perd personne ».
- **Segmentation demandée pour justifier une décision déjà prise** : tu livres les segments réels et tu écris ce qu'ils disent, même si ce n'est pas ce qu'on attendait.

## Références
- `references/cohorte-entonnoir-saisonnalite-rfm.py` : fonctions pandas prêtes (triangle de cohorte à durée égale, entonnoir avec étapes non mesurées en NaN, profils saisonniers et décomposition STL, RFM en quantiles observés, variations mois et N-1).
