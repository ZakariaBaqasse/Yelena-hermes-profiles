---
id: Y0704
name: prevision-et-estimation
description: "Produit une prévision ou une estimation quand la direction en a besoin pour décider (ventes du trimestre, trésorerie à 13 semaines, stock à commander, fréquentation, effectif nécessaire) : choix de la méthode la plus simple qui tienne (moyenne mobile, saisonnalité, tendance, régression, scénarios), fourchette plutôt que chiffre unique, hypothèses écrites avec leur auteur, comparaison de la prévision au réalisé le mois suivant. Ne présente jamais une prévision comme un engagement et ne fabrique jamais une hypothèse à la place de la maison."
bucket: B
tags: [Données, Prévision, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Une prévision est une fourchette avec ses hypothèses, pas un chiffre

## Ce qu'il faut avoir sous la main
- **La décision que la prévision éclaire** et l'horizon utile (la semaine prochaine, la fin du trimestre, la saison).
- **L'historique** : au moins deux cycles de la saisonnalité qu'on veut capter (deux ans pour une saison annuelle, deux mois pour un cycle hebdomadaire), avec ses trous et ses changements de périmètre marqués.
- **Ce que la maison sait et que la série ne dit pas** : ouverture d'un point de vente, hausse de prix décidée, gros client perdu, fête mobile, campagne prévue. Ce sont les hypothèses, et elles ont un auteur.
- **Le coût d'une erreur dans chaque sens** : sur-stocker coûte moins que rupturer, ou l'inverse ; ça décide de quel bord de la fourchette on regarde.

> ⚡ **Peu d'historique n'empêche pas de livrer** : tu produis une estimation par scénarios (bas, central, haut) avec les hypothèses écrites, en disant que ce n'est pas une prévision statistique.

## Process
### Étape 1, Nettoyer et comprendre la série
Passer par `qualite-de-la-donnee` : trous, doublons, changement de périmètre, valeurs aberrantes qualifiées. Une prévision faite sur trois semaines non saisies apprend que juillet est mort, et le prédira chaque année.

### Étape 2, Décomposer avant de modéliser
Tendance, saisonnalité (hebdomadaire, mensuelle, annuelle, calendrier religieux), effets d'événements, résidu. Un graphique de la décomposition dans le livrable vaut mieux que le nom d'un modèle : c'est ce que la direction comprend, et c'est souvent là que se voit l'erreur de périmètre.

### Étape 3, Choisir la méthode la plus simple qui tienne
Dans l'ordre, et on s'arrête dès que ça suffit :
1. **Naïve saisonnière** : la même période l'an dernier, corrigée de la tendance. C'est la référence à battre.
2. **Moyenne mobile ou lissage exponentiel** (Holt-Winters) quand la saisonnalité est régulière.
3. **Régression** quand des facteurs connus expliquent la série (jours ouverts, prix, pluie, campagne).
4. **Modèles ARIMA ou plus** seulement si les précédents échouent nettement, et en disant pourquoi.
Chaque méthode est testée sur le passé (on prévoit les trois derniers mois comme si on ne les connaissait pas) et on garde celle qui se trompe le moins. L'erreur passée s'écrit dans le livrable : c'est la seule mesure honnête de ce que vaut la prévision.
Outils : `~/.venv-office/bin/python`, `pandas`, `statsmodels`, `scipy`.

### Étape 4, Livrer une fourchette et ses hypothèses
Trois chiffres (bas, central, haut) avec ce qui les sépare, et pour chaque hypothèse : qui l'a posée, sur quoi, et ce qui se passe si elle est fausse. Une hypothèse que personne n'a posée ne s'invente pas : elle s'écrit `⟦à renseigner⟧` et la prévision se livre avec ce trou nommé.

### Étape 5, Confronter la prévision au réalisé
Le mois suivant, la prévision se compare au réalisé, l'écart s'explique (hypothèse fausse, événement imprévu, méthode), et la méthode s'ajuste. Une prévision qui n'est jamais revue devient une croyance.

## Format de sortie
- **Note de prévision** (gabarit `note-d-analyse`) : décision servie, données utilisées, décomposition, méthode retenue et son erreur passée, fourchette, hypothèses avec auteur, ce qui la ferait dérailler.
- **Tableur** avec la série, la décomposition, la prévision par période et une colonne « réalisé » à remplir (`tableur-livrable`).
- **Code** rejouable joint au livrable.

## Règles
1. **Jamais un chiffre unique** : une fourchette, et ce qui la rend large ou étroite.
2. **Chaque hypothèse a un auteur** ; sans auteur, elle s'écrit `⟦à renseigner⟧`.
3. **L'erreur passée de la méthode figure dans le livrable**, sinon la prévision n'a pas de valeur.
4. **Une prévision n'est pas un objectif ni un engagement** ; la phrase s'écrit, surtout quand le chiffre part vers une banque ou un partenaire (validation humaine).
5. **Changement de périmètre = nouvelle série.** On ne prévoit pas trois magasins avec l'histoire de deux.
6. **Pas de norme sectorielle de mémoire** pour boucher un trou d'historique.

## Cas limites
- **Moins d'un cycle d'historique** : estimation par scénarios et analogie interne (un autre site, un autre produit de la maison), jamais par une donnée d'une autre entreprise.
- **Rupture récente** (nouveau prix, nouveau site) : la série d'avant ne prévoit pas l'après ; on le dit et on prévoit large.
- **Trésorerie** : la prévision de trésorerie appartient à Mamadou (finance) ; tu fournis les séries d'encaissements et de ventes prévues, tu ne montes pas le plan de trésorerie à sa place.
