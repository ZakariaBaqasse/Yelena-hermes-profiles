---
id: Y0680
name: du-jeu-de-donnees-au-rapport-brande
description: "Le déroulé d'une analyse de données tel que l'équipe l'attend : aucun brouillon sans logo, le rapport mensuel en Google Slides aux couleurs de l'entreprise avec une idée par page et les alertes en couleur, le tableau de bord dans Excel quand c'est possible, sur Tableau ou Power BI seulement s'ils sont authentifiés et, sinon, le dire clairement au lieu de bricoler, un courriel qui ne part qu'une fois, l'infographie d'une page partageable sur WhatsApp, le rapport hebdomadaire envoyé par e-mail par l'Experte elle-même avec un modèle récurrent, les problèmes de données mis en évidence visuellement, les trois points à retenir et les questions en QCM, et des liens qui s'ouvrent sans demande d'accès. Règles posées à la réunion d'entraînement du 21 septembre 2026, à charger dès qu'un fichier de données arrive."
bucket: A
tags: [Données, Processus, Nouveau]
version: 3
maj: 2026-09-23
---

# Du jeu de données au rapport brandé

## Process
### Étape 1 : regarder la donnée, puis habiller dès le premier rendu
Tu commences par la qualité du fichier (compétence `qualite-de-la-donnee`) : doublons, formats, champs vides, périodes incomplètes. Puis tout ce que tu rends, y compris un premier brouillon, porte le logo et les couleurs de l'entreprise (compétence `charte-du-client`). Un brouillon sans logo n'existe pas : la personne doit pouvoir le transférer tel quel si elle le décide.

### Étape 2 : le rapport mensuel en Google Slides
Le rapport de direction sort en **Google Slides** : une idée par page, un titre qui dit la conclusion, un chiffre ou un graphique par page, des icônes sobres, et **les alertes en couleur** (un indicateur qui décroche, une donnée manquante, un écart inexpliqué) visibles avant d'être lues. Le PDF est exporté des mêmes Slides et rendu en second. Pas de rapport en texte continu.

### Étape 3 : le tableau de bord, et dire s'il est branché
**Dans Excel quand c'est possible** : un classeur `.xlsx` fabriqué sur le poste, tables filtrables et graphiques natifs, ou le Google Sheet équivalent. Sinon Tableau ou Power BI, quand Excel ne suffit plus (connexion en direct, nombreux lecteurs, gros volume), et seulement s'ils sont authentifiés : lance d'abord `python3 integrations/tableau/check.py` et `python3 integrations/powerbi-fabric-iq/check.py`. ⛔ **Au 23/09/2026, ni Power BI ni Tableau ne sont authentifiés sur ce poste** (les deux `check.py` sortent en « identifiants absents », et l'accès Excel en ligne par `integrations/excel-microsoft-graph/` non plus). Tant que c'est le cas, tu livres en Excel ou en Google Sheet, **tu le dis en une ligne**, et tu signales ce qu'il faut pour brancher l'outil (la connexion d'une personne, décrite dans le `README.md` de l'intégration). Une image fixe présentée comme un tableau de bord est une tromperie.

### Étape 4 : l'infographie d'une page
Pour ce qui doit circuler vite (un point sur le mois, une bonne nouvelle, un chiffre clé), tu rends une **infographie d'une page en PNG**, à l'identité de l'entreprise, chiffres et icônes, partageable sur WhatsApp. Trois chiffres qu'on retient valent mieux que douze qu'on oublie.

### Étape 5 : le rapport hebdomadaire par e-mail
Le rapport de la semaine part **par e-mail, envoyé par toi**, à l'adresse de la personne servie : brandé, le tableau de bord ou son lien, les liens cliquables sur leur libellé, trois lignes de lecture. Tu proposes le **modèle récurrent** (« chaque lundi à 8 h ») dès la première semaine et tu le tiens. **Un courriel part une fois** (`integrations/google-gogcli/gmail-envoyer.py`) : quand le script a rendu un identifiant de message, il est parti, et tu ne relances pas la commande. S'il a échoué sans que tu puisses établir que le courriel est parti, tu ne le renvoies pas à l'aveugle : tu le dis à la personne et tu lui demandes si elle l'a reçu (aucun script ne lit encore les courriels envoyés). Même règle dans le fil (compétence `restitution-des-donnees`, section 9).

### Étape 6 : les problèmes de données mis en évidence
Ce qui pose problème dans les données (doublons, formats, valeurs impossibles, périodes manquantes) ressort **visuellement** dans le rapport : couleur, gras, encadré, une page dédiée si nécessaire. Une réserve écrite dans une phrase en bas de page ne protège personne ; une réserve en rouge en haut de page, si.

### Étape 7 : trois points et un QCM
Quand on te demande l'essentiel, tu rends **trois points à retenir**, une ligne chacun, puis tes questions **en QCM lettré**. « J'ai trois minutes » veut dire trois lignes et un choix.

### Étape 8 : des liens qui s'ouvrent
Chaque fichier rendu est partagé avec les bons droits avant que le lien soit envoyé, et la personne reçoit un **e-mail avec tous les liens** quand plusieurs fichiers partent ensemble. Un lien qui demande un accès n'est pas un livrable rendu.

## Format de sortie
- **Rapport mensuel** : Google Slides brandé, une idée par page, alertes en couleur, puis PDF.
- **Tableau de bord** : classeur Excel (ou Google Sheet) filtrable avec graphiques ; lien Tableau ou Power BI seulement quand l'outil est authentifié, outil nommé ; sinon une ligne qui dit que l'outil n'est pas branché.
- **Infographie** : PNG d'une page, partageable.
- **Rapport hebdomadaire** : e-mail envoyé par l'Experte, brandé, liens cliquables, modèle récurrent.
- **Qualité des données** : mise en évidence visuelle dans le rapport, Google Doc si un rapport dédié est demandé.
- **Essentiel** : trois points, un QCM.
- **Chaque livrable** nomme l'application utilisée.
- **Règle 0 invention** : aucun chiffre, aucune tendance, aucune source fabriqués ; une donnée manquante est marquée, jamais comblée.

## Règles
1. **Aucun brouillon sans logo.** Le premier rendu porte déjà l'identité de l'entreprise.
2. **Le rapport de direction sort en Slides**, une idée par page, alertes en couleur, PDF en second.
3. **Un tableau de bord sort dans Excel quand c'est possible**, sur Tableau ou Power BI seulement s'ils sont authentifiés ; sinon on le dit et on livre Excel ou le Sheet.
4. **Ce qui pose problème se voit**, en couleur, avant d'être lu.
5. **Le rapport hebdomadaire part par e-mail**, envoyé par l'Experte, avec un modèle récurrent.
6. **L'essentiel tient en trois points et un QCM.**
7. **Un lien s'ouvre avant d'être rendu**, et plusieurs liens partent dans un e-mail.
8. **L'application utilisée est nommée à chaque livrable.**
9. **Écrit pour un lecteur non technique, par défaut** (23/09/2026) : mots de tous les jours, une icône par idée, un calcul par ligne avec un vrai exemple, cinq lignes au plus par page. Le détail est dans `restitution-des-donnees`, section 0.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, aucune moyenne, aucune tendance fabriqués pour remplir une page. Ce qui manque dans le fichier est marqué `[donnée manquante]` et signalé en couleur.
- **0 fausse source.** Un tableau de bord « connecté » l'est réellement ; un chiffre cite le fichier et la période dont il vient.
- **Produis, ne bloque pas.** Un fichier imparfait donne un rapport qui montre ses limites ; refuser de produire n'est jamais la réponse.
- 🔒 **Aucune action sortante en autonomie.** L'e-mail part à la personne servie ; transmettre un rapport à un tiers ou le publier reste une action validée.
- **Cloisonnement.** Les données d'une entreprise ne servent jamais un rapport pour une autre.

## Cas limites
- **La personne demande le tableau de bord sur un outil non branché** : tu le dis, tu rends le Google Sheet avec les mêmes indicateurs, et tu nommes qui peut brancher l'outil. Tu ne rends pas une capture d'écran maquillée.
- **Le fichier est trop sale pour un rapport** : tu rends le rapport de qualité en premier, alertes en couleur, et tu proposes de corriger avant d'analyser. La personne décide.
- **Le logo et les couleurs ne sont pas en mémoire** : tu les demandes dans le même message que ta première question, et tu ne rends aucune page avant de les avoir.
- **La maison n'a pas de logo du tout** : tu ne restes pas bloquée et tu ne rends pas en gris et blanc. Tu demandes une pièce visuelle (menu, enseigne, photos), sinon tu proposes une palette qui colle au métier, annoncée comme proposition (compétence `charte-du-client`, étape 0 bis).
- **La personne veut « juste les chiffres »** : trois points dans la conversation, et le lien du Slides derrière. Elle a les chiffres, et le document existe.
- **Un lien rendu demande un accès** : tu corriges le partage et tu renvoies le lien, sans attendre qu'on te le signale une deuxième fois.
- **Le rapport doit partir à une liste de personnes** : tu l'envoies à la personne servie et tu lui proposes la liste ; tu n'écris pas à des tiers.
- **La période demandée n'est pas couverte par le fichier** : tu le dis en première page, en couleur, et tu rends ce qui est couvert.

## Historique
- v2, 23/09/2026 : cas limite de la maison sans logo, palette proposée d'après le métier au lieu d'un rendu gris et blanc, séance Sync agents training.
- v2, 23/09/2026 (même passe) : tableau de bord dans Excel d'abord, Tableau ou Power BI seulement authentifiés (ils ne le sont pas au 23/09/2026) ; un courriel part une fois, manques de la séance du 22/09 relevés par audit.
- v3, 23/09/2026 : règle 9, le lecteur non technique par défaut (retours d'Alima et du testeur, message 12778).
