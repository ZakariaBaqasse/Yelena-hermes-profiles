# Branchements proposés au client, par type d'outil

Arrêté le 23/09/2026 à la demande du testeur (vocal, message 12778 : « proposer aux clients de
faire tous ces branchements-là, que tu gardes le travail avec toute typologie d'outils, tu peux
les lister »). Sert au message d'accueil et à chaque fois qu'un client cite un outil.

Règle d'honnêteté : la colonne « État chez moi » dit ce qui est **vérifié** sur le poste à la
date indiquée. On ne promet jamais un branchement direct qui n'a pas été testé ; on propose
l'accès, et en attendant l'export.

| Type d'outil | Exemples cités par les clients | Comment je m'y branche | Ce qu'il faut du client | État chez moi (23/09/2026) |
|---|---|---|---|---|
| Tableurs | Google Sheets, Excel | Lecture directe (Google), fichier déposé (Excel) ; Excel en ligne par Microsoft Graph | Partager le fichier en lecture | Google : branché. Excel en ligne : intégration écrite, accès client à ouvrir |
| Caisse, logiciel de gestion, ERP | Caisse enregistreuse, logiciel de facturation, ERP | Export automatique (CSV ou Excel) déposé dans un dossier partagé, ou interface de lecture si l'éditeur en fournit une | Un export ou une clé en lecture seule | Rien de branché : à faire par client |
| Banque et monnaie électronique | Relevés bancaires, relevés de mobile money | Relevé PDF ou CSV déposé chaque semaine ou chaque mois | Le relevé, ou l'export de l'espace client | Lecture des relevés PDF texte éprouvée ; aucun accès direct |
| Bases de données | PostgreSQL, MySQL, SQL Server | Requêtes SQL en lecture seule | Un compte en lecture sur une copie ou une vue | Outils présents (psql, DuckDB) ; jamais testé sur une base client |
| Outils de tableau de bord | Power BI, Tableau, Looker Studio | Lecture des modèles ; publication si un compte le permet | Un compte avec droit de publication | Non connectés (Power BI et Tableau refusent la connexion ou sont en lecture seule, Looker non branché) ; paquet Power BI prêt à monter livré à la place |
| CRM et outils commerciaux | HubSpot, Salesforce, Zoho, pipeline en tableur | Export ou connecteur en lecture | Un export ou un accès en lecture | Rien de branché |
| Vente en ligne et réseaux sociaux | Boutique en ligne, commandes WhatsApp, statistiques Facebook, Instagram, TikTok | Export des statistiques et des commandes | L'export mensuel, ou un accès en lecture | Exports lus (réseaux sociaux d'un client de test, 23/09) ; aucun accès direct |
| RH et paie | Registre du personnel, logiciel de paie | Export sans nom ni matricule, ou anonymisé à la réception | L'export, et l'accord sur les données personnelles | Analyse RH sans nom éprouvée (23/09) |
| Formulaires et collecte | Tally, Google Forms, questionnaires terrain | Création du questionnaire et relève des réponses | Accord sur les questions et sur la collecte | Tally branché (23/09) |
| Documents papier | Cahier, tickets, factures photographiées | Photo ou scan, lecture puis contrôle ligne à ligne | Des photos nettes, à plat | Lecture automatique installée le 23/09 ; sur une photo décorée elle ne donne rien d'utilisable, un cahier manuscrit n'a pas encore été testé : relecture humaine obligatoire |
| Données publiques | BCEAO, Banque mondiale, INS, data.gouv.ci, ARTCI, météo | Lecture directe, source citée avec son lien et sa date | Rien | Branché (Banque mondiale, data.gouv.ci, météo, commerce extérieur, pages publiques) |

## Ce qui ne change jamais, quel que soit l'outil

- **Lecture seule.** Écrire ou corriger dans un système de production est sur la liste des
  validations.
- Un branchement se propose **quand le besoin est là** ou quand le client le demande ; au
  premier message, on liste les types d'outils, on ne réclame pas dix accès.
- En attendant l'accès, **l'export suffit pour commencer**. On ne fait jamais attendre un
  livrable derrière un branchement.
