#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analyses business réutilisables : ce que chacune prouve, et ne prouve pas. Interpréteur : ~/.venv-office/bin/python.

    from analyse_business import distribution, correlation, rfm, test_proportions, khi2, facteurs_logistiques
Aucune fonction ne modifie le DataFrame reçu. Les seuils de classes RFM sont des rangs (quintiles), pas des valeurs arbitraires.
"""
import numpy as np, pandas as pd
from scipy import stats


def distribution(s):
    """Résumé robuste d'une série numérique : la moyenne seule est interdite sur des montants à queue lourde."""
    s = pd.to_numeric(s, errors="coerce").dropna()
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    return {"n": int(s.size), "mediane": float(s.median()), "moyenne": float(s.mean()), "q1": float(q1), "q3": float(q3),
            "p90": float(s.quantile(0.9)), "part_hors_3iqr": float(((s < q1 - 3 * (q3 - q1)) | (s > q3 + 3 * (q3 - q1))).mean())}


def correlation(x, y):
    """Pearson et Spearman avec n : une corrélation sur un petit n est une piste, pas une relation."""
    d = pd.DataFrame({"x": pd.to_numeric(x, errors="coerce"), "y": pd.to_numeric(y, errors="coerce")}).dropna()
    rp, pp = stats.pearsonr(d.x, d.y); rs, ps = stats.spearmanr(d.x, d.y)
    return {"n": len(d), "pearson": rp, "p_pearson": pp, "spearman": rs, "p_spearman": ps,
            "lecture": "corrélation, pas causalité ; vérifier un facteur commun avant d'interpréter"}


def rfm(df, client="client_id", date="date", montant="montant", arret=None):
    """RFM par rangs (quintiles) ; date d'arrêt = lendemain de la dernière opération sauf indication. Classes nommées à faire valider."""
    d = df[[client, date, montant]].copy(); d[date] = pd.to_datetime(d[date]); d[montant] = pd.to_numeric(d[montant], errors="coerce")
    arret = pd.Timestamp(arret) if arret else d[date].max() + pd.Timedelta(days=1)
    g = d.groupby(client).agg(recence=(date, lambda x: (arret - x.max()).days), frequence=(date, "size"), montant=(montant, "sum")).reset_index()
    def score(s, asc):
        return pd.qcut(s.rank(method="first", ascending=asc), 5, labels=[1, 2, 3, 4, 5]).astype(int)
    g["R"] = score(g.recence, False); g["F"] = score(g.frequence, True); g["M"] = score(g.montant, True)
    g["score"] = g.R + g.F + g.M
    g["classe"] = pd.cut(g.score, bins=[0, 6, 8, 10, 12, 15], labels=["à réactiver", "à risque", "réguliers", "fidèles", "meilleurs"])
    return g, arret


def test_proportions(succes_a, n_a, succes_b, n_b):
    """Deux taux diffèrent-ils au-delà du hasard ? Test z bilatéral sur deux proportions. Ne dit rien de la cause."""
    p_a, p_b = succes_a / n_a, succes_b / n_b; p = (succes_a + succes_b) / (n_a + n_b)
    z = (p_b - p_a) / np.sqrt(p * (1 - p) * (1 / n_a + 1 / n_b)); pv = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"taux_a": p_a, "taux_b": p_b, "ecart": p_b - p_a, "z": z, "p": pv,
            "lecture": "p petite : l'écart dépasse ce que le hasard produit d'habitude ; p grande : rien à conclure, pas « égal »"}


def khi2(df, ligne, colonne):
    """Deux variables catégorielles sont-elles indépendantes ? (ex. service × départ). Renvoie aussi le tableau croisé."""
    t = pd.crosstab(df[ligne], df[colonne]); c, p, ddl, _ = stats.chi2_contingency(t)
    return {"khi2": c, "p": p, "ddl": ddl, "tableau": t, "lecture": "p petite : la répartition dépend de la ligne ; ne dit pas quelle case ni pourquoi"}


def facteurs_logistiques(df, cible, facteurs):
    """Hiérarchise des facteurs d'un événement binaire (churn, défaut). Coefficients standardisés ; AUC en validation.
    Ne dit ni la causalité, ni le levier à actionner, ni ce qu'il coûte."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score
    from sklearn.preprocessing import StandardScaler
    X = pd.get_dummies(df[facteurs], drop_first=True).astype(float); y = df[cible].astype(int)
    Xa, Xt, ya, yt = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
    sc = StandardScaler().fit(Xa); m = LogisticRegression(max_iter=1000).fit(sc.transform(Xa), ya)
    coefs = pd.Series(m.coef_[0], index=X.columns).sort_values(key=abs, ascending=False)
    return {"auc_validation": roc_auc_score(yt, m.predict_proba(sc.transform(Xt))[:, 1]), "coefficients_standardises": coefs,
            "lecture": "signe = sens de l'association ; amplitude = poids relatif ; AUC ≈ 0,5 = le modèle ne sépare rien"}
