# Catalogue des KPI business : formule, dénominateur, date de rattachement, piège

Aucune valeur cible ici : un seuil, une norme de marché, un « bon niveau » s'écrivent `⟦à renseigner⟧`
et se décident par la maison. Chaque KPI livré passe ensuite par la fiche à dix champs (nom, définition,
formule, unité, période, filtres, source, date de mise à jour, statut, limites).

| KPI | Formule | Dénominateur et rattachement | Exclusions habituelles à confirmer | Le piège |
|---|---|---|---|---|
| Revenu (chiffre d'affaires) | Σ montant des ventes de la période | période = date de facturation, de livraison ou d'encaissement : **à choisir et à écrire** | annulations, retours, avoirs, ventes internes, tests | changer de date de rattachement entre deux rapports |
| Revenu reconnu | Σ ventes au statut abouti seulement | idem | commandes annulées, retournées, en attente | compter le « pending » comme du revenu |
| Marge brute | (revenu − coût des ventes) / revenu | même périmètre que le revenu | frais de port, remises non déduites | revenu net contre coût brut |
| Croissance annuelle (YoY) | (valeur N − valeur N−1) / valeur N−1 | **même périmètre** (sites, produits, canaux) | | périmètre qui a bougé : la croissance est un artefact |
| Panier moyen (AOV) | revenu / nombre de commandes | commandes abouties | | commande à zéro, commandes fractionnées |
| GMV (volume d'affaires) | Σ valeur des transactions traitées | avant frais et retours | | présenter la GMV comme un revenu |
| ARPU | revenu / utilisateurs (ou clients) actifs | **définition de « actif » à écrire** | | dénominateur qui change avec la définition d'actif |
| Clients actifs | nombre distinct de clients avec ≥ 1 opération aboutie sur la période | période glissante ou civile : à écrire | | compter un client deux fois (doublons d'identifiant) |
| Taux de churn | clients perdus sur la période / clients au début de la période | « perdu » = résiliation, ou inactivité de N jours : à écrire | | mélanger churn volontaire et fin de contrat ; dénominateur = fin de période |
| Rétention (cohorte) | clients de la cohorte encore actifs au mois k / taille de la cohorte | cohorte = mois de première opération | | comparer des cohortes de périmètre différent |
| CAC | dépenses d'acquisition / nouveaux clients acquis | même période, même canal | coûts internes non imputés | attribuer tous les nouveaux clients au canal mesuré |
| LTV (valeur vie) | marge brute mensuelle moyenne × durée de vie moyenne (ou Σ marge réelle par cohorte) | durée = 1 / churn mensuel : **hypothèse** | | LTV en revenu au lieu de marge ; durée de vie extrapolée |
| Taux de conversion | Σ conversions / Σ entrées de l'étape | étape à étape, ou global : les deux | trafic interne, robots | numérateur et dénominateur de périodes différentes |
| Entonnoir | utilisateurs à l'étape k / utilisateurs à l'étape k−1 | utilisateurs distincts, pas événements | | compter des événements répétés comme des personnes |
| Taux d'échec (transactions) | transactions échouées / transactions enregistrées | statut « échoué » défini | statuts inconnus (pending) hors numérateur | mettre le pending dans les abouties ou dans les échecs |
| Taux de fraude **signalée** | transactions marquées / transactions enregistrées | marqueur du système | | écrire « fraude » pour un signalement |
| Taux de retour | commandes retournées / commandes livrées | rattachement à la date de vente d'origine | | retours du mois rapportés aux ventes du mois |
| Rupture de stock | 1 − moyenne(en stock) sur les références | à un instant, ou en jours-référence | | mesurer sur les références vendues seulement |
| Concentration (Pareto) | part cumulée du revenu des k premiers clients / produits | trié décroissant, fenêtre cumulée | | lire « 20 % font 80 % » sans donner k |
| Attrition (RH) | départs sur la période / effectif moyen | départs volontaires et involontaires séparés | fins de CDD, stagiaires : à écrire | attrition annualisée sans le dire |
| Délai (livraison, traitement) | médiane et 90ᵉ percentile des jours entre deux dates | dates de début et de fin définies | | moyenne tirée par quelques cas extrêmes |
| RFM | récence (jours depuis la dernière opération), fréquence (nombre), montant (Σ) par client, scores par rangs en cinq classes | date d'arrêt = lendemain de la dernière opération du fichier | | scores par seuils arbitraires ; classes nommées sans définition |

Trois vérifications avant de livrer un KPI : (1) numérateur et dénominateur sur la **même période et le
même périmètre** ; (2) la **date de rattachement** est écrite ; (3) les **exclusions** sont écrites, même
quand il n'y en a pas (« aucune exclusion »).
