-- Requêtes business réutilisables (DuckDB). Tables supposées : commandes(commande_id, client_id, date_commande, statut, montant, canal),
-- evenements(client_id, etape, ordre_etape, date_evenement), sessions_ab(session_id, variante, converti, revenu, appareil).
-- Chaque requête se garde dans travail/<projet>/NN_*.sql avec son numéro d'étape.

-- 1. Entonnoir : utilisateurs distincts par étape, conversion étape à étape (LAG)
WITH etapes AS (
  SELECT ordre_etape, etape, COUNT(DISTINCT client_id) AS utilisateurs
  FROM evenements GROUP BY 1, 2)
SELECT etape, utilisateurs,
       LAG(utilisateurs) OVER (ORDER BY ordre_etape) AS etape_precedente,
       utilisateurs * 1.0 / NULLIF(LAG(utilisateurs) OVER (ORDER BY ordre_etape), 0) AS conversion_etape,
       utilisateurs * 1.0 / NULLIF(FIRST_VALUE(utilisateurs) OVER (ORDER BY ordre_etape), 0) AS conversion_depuis_entree
FROM etapes ORDER BY ordre_etape;

-- 2. Concentration du revenu (Pareto) : part cumulée par client, trié décroissant
WITH rev AS (
  SELECT client_id, SUM(montant) AS revenu FROM commandes WHERE statut = 'Completed' GROUP BY 1)
SELECT client_id, revenu,
       SUM(revenu) OVER (ORDER BY revenu DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) / SUM(revenu) OVER () AS part_cumulee,
       ROW_NUMBER() OVER (ORDER BY revenu DESC) * 1.0 / COUNT(*) OVER () AS part_clients_cumulee
FROM rev ORDER BY revenu DESC;

-- 3. Cohortes de rétention mensuelles : clients actifs au mois k après leur premier mois
WITH premier AS (
  SELECT client_id, DATE_TRUNC('month', MIN(CAST(date_commande AS DATE))) AS cohorte FROM commandes WHERE statut = 'Completed' GROUP BY 1),
activite AS (
  SELECT DISTINCT c.client_id, p.cohorte, DATE_DIFF('month', p.cohorte, DATE_TRUNC('month', CAST(c.date_commande AS DATE))) AS k
  FROM commandes c JOIN premier p USING (client_id) WHERE c.statut = 'Completed'),
taille AS (SELECT cohorte, COUNT(*) AS n FROM premier GROUP BY 1)
SELECT a.cohorte, a.k, COUNT(DISTINCT a.client_id) AS actifs, t.n AS taille_cohorte,
       COUNT(DISTINCT a.client_id) * 1.0 / t.n AS retention
FROM activite a JOIN taille t USING (cohorte) GROUP BY 1, 2, 4 ORDER BY 1, 2;

-- 4. Déciles de clients par revenu (NTILE) : combien pèse le premier décile
WITH rev AS (SELECT client_id, SUM(montant) AS revenu FROM commandes WHERE statut = 'Completed' GROUP BY 1),
d AS (SELECT client_id, revenu, NTILE(10) OVER (ORDER BY revenu DESC) AS decile FROM rev)
SELECT decile, COUNT(*) AS clients, SUM(revenu) AS revenu, SUM(revenu) / SUM(SUM(revenu)) OVER () AS part
FROM d GROUP BY 1 ORDER BY 1;

-- 5. Pivot par CASE : statut en colonnes, par canal
SELECT canal,
       COUNT(*) AS enregistrees,
       SUM(CASE WHEN statut = 'Completed' THEN 1 ELSE 0 END) AS abouties,
       SUM(CASE WHEN statut = 'Failed' THEN 1 ELSE 0 END) AS echouees,
       SUM(CASE WHEN statut = 'Pending' THEN 1 ELSE 0 END) AS non_mises_a_jour,
       SUM(CASE WHEN statut = 'Failed' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS taux_echec
FROM commandes GROUP BY 1 ORDER BY enregistrees DESC;

-- 6. Écart A/B : taux de conversion, écart absolu et relatif, par appareil (le test statistique se fait en Python)
WITH t AS (
  SELECT appareil, variante, COUNT(*) AS sessions, SUM(converti) AS conversions, SUM(revenu) AS revenu FROM sessions_ab GROUP BY 1, 2),
p AS (
  SELECT appareil,
         MAX(CASE WHEN variante = 'A' THEN conversions * 1.0 / NULLIF(sessions, 0) END) AS tc_a,
         MAX(CASE WHEN variante = 'B' THEN conversions * 1.0 / NULLIF(sessions, 0) END) AS tc_b,
         MAX(CASE WHEN variante = 'A' THEN sessions END) AS n_a, MAX(CASE WHEN variante = 'B' THEN sessions END) AS n_b
  FROM t GROUP BY 1)
SELECT appareil, n_a, n_b, tc_a, tc_b, tc_b - tc_a AS ecart_absolu, (tc_b - tc_a) / NULLIF(tc_a, 0) AS ecart_relatif FROM p;

-- 7. Délai : médiane et 90e percentile de jours entre deux dates, par mois
SELECT DATE_TRUNC('month', CAST(date_commande AS DATE)) AS mois,
       QUANTILE_CONT(DATE_DIFF('day', CAST(date_commande AS DATE), CAST(date_livraison AS DATE)), 0.5) AS delai_median,
       QUANTILE_CONT(DATE_DIFF('day', CAST(date_commande AS DATE), CAST(date_livraison AS DATE)), 0.9) AS delai_p90
FROM commandes WHERE date_livraison IS NOT NULL GROUP BY 1 ORDER BY 1;

-- 8. Tests de cohérence à la manière de dbt (chaque requête doit renvoyer zéro ligne)
SELECT commande_id FROM commandes GROUP BY 1 HAVING COUNT(*) > 1;                                   -- clé unique
SELECT commande_id FROM commandes GROUP BY 1 HAVING COUNT(DISTINCT client_id) > 1;                 -- un client par commande
SELECT * FROM commandes WHERE statut = 'Completed' AND montant <= 0;                               -- abouties à montant positif
SELECT * FROM commandes WHERE statut NOT IN ('Completed', 'Failed', 'Pending', 'Reversed');        -- valeurs de statut admises
