---
name: raisonnement-d-analyste-business
description: "La chaîne de raisonnement d'une analyste de données orientée décision, apprise le 21/09/2026 sur 22 portfolios publics d'analystes (Power BI, DAX, SQL, Python, R, dbt) à la demande de la direction : problème d'entreprise → données → nettoyage → SQL → métriques → analyse → tableau de bord → constat → recommandation. Contient la manière de formuler un problème business, le catalogue des KPI avec leurs formules et leurs pièges, les requêtes SQL réutilisables (entonnoir, Pareto, cohortes, déciles, écart A/B), les analyses Python (RFM, tests, régression logistique) et le format obligatoire d'une recommandation : constat → preuve → implication → action. À charger dès qu'on me demande « pourquoi » ou « que faire », pas seulement « combien »."
version: 1
maj: 2026-09-21
---

# Raisonner comme une analyste business, pas comme un lecteur de graphiques

Consigne de la direction (21/09/2026) : « définir la décision → valider les données → choisir les bonnes
métriques → communiquer les limites → produire des insights utilisables », et surtout pas « je regarde
le dashboard → suivant ». Chaque mission doit pouvoir s'expliquer en neuf maillons :

**Problème business → Données → Nettoyage → SQL → Métriques → Analyse → Tableau de bord → Constat → Recommandation.**

Ce que chaque maillon produit chez moi, et où il se branche sur mon protocole de mission :

| Maillon | Ce qui sort | Où ça vit |
|---|---|---|
| 1. Problème business | la décision à éclairer, en une phrase, avec qui décide | cadrage (protocole, étape 1) |
| 2. Données | inventaire des sources, propriétaire, date de mise à jour, grain | protocole, étape 2 |
| 3. Nettoyage | tableau de contrôles, source intacte, copie de travail tracée | `controler-donnees.py`, `travail/` |
| 4. SQL | les jeux de données d'analyse, requêtes conservées | `requete-sql.py`, `references/requetes-business.sql` |
| 5. Métriques | fiche à dix champs par indicateur, seuils `⟦à renseigner⟧` | dictionnaire d'indicateurs |
| 6. Analyse | distributions, segments, tests, ce qu'ils prouvent et ne prouvent pas | `references/analyse-business.py` |
| 7. Tableau de bord | une page par décision, dictionnaire des champs, chiffres vérifiés contre la source | gabarit tableau de bord |
| 8. Constat | fait observé + preuve chiffrée + statut de la valeur | livrable, partie « résultats » |
| 9. Recommandation | constat → preuve → implication → action, en trois rubriques | livrable, partie finale |

## 1. Formuler le problème : une décision, pas un sujet

Les bons portfolios ouvrent par une **question de décision** ; les faibles ouvrent par un jeu de données.

- Faible : « Analyse des ventes 2024 ». Juste : « Le churn augmente depuis mars : sur quel segment agir
  en premier, et avec quel levier ? »
- La question porte **qui décide** et **ce qui changera** selon la réponse. Si rien ne change quelle que
  soit la réponse, ce n'est pas une analyse, c'est une curiosité.
- Deux trames vues dans les portfolios, à réutiliser : **Définir → Mesurer → Analyser (cinq pourquoi) →
  Améliorer → Contrôler** (projet fintech de STCybersec) et **Demander → Préparer → Traiter → Analyser →
  Partager → Agir** (étude Bellabeat). Les cinq pourquoi s'écrivent en chaîne, chaque maillon avec sa
  preuve ; un maillon sans preuve s'écrit `[hypothèse : …]`.
- Le problème s'écrit avant d'ouvrir un fichier, et se relit à la fin : la recommandation doit y répondre.

## 2. Choisir les métriques : formule, dénominateur, date de rattachement

Le catalogue est dans `references/catalogue-kpi.md` : revenu, ARPU, churn, rétention, CAC, LTV,
conversion, marge brute, croissance annuelle, panier moyen, GMV, rupture de stock, retours, taux de frais,
taux de fraude signalée, attrition, concentration (Pareto), RFM. Pour chacun : formule, dénominateur,
date de rattachement, exclusions, et **le piège qui le rend faux**.

Trois règles apprises en lisant les portfolios :
- **Un KPI sans dénominateur explicite est un chiffre, pas un indicateur.** « Montant des sinistres par
  marque » sans le nombre de contrats par marque ne dit rien du risque.
- **Un « meilleur canal » se juge sur ce qu'il coûte, pas sur ce qu'il rapporte.** Un revenu par canal
  sans le budget du canal ne permet aucun arbitrage.
- **Les seuils et cibles (« < 2 % de fraude », « < 5 % d'échecs ») ne viennent pas de l'analyste.**
  Dans les portfolios ils sont posés sans source ; chez moi ils s'écrivent `⟦à renseigner⟧` avec qui doit
  les décider.

## 3. SQL : produire soi-même les jeux d'analyse

`references/requetes-business.sql` (DuckDB, testé) : entonnoir avec `LAG`, part cumulée (Pareto) par
fenêtre, cohortes de rétention mensuelles, déciles `NTILE`, pivot par `CASE`, écart A/B avec `NULLIF`,
percentiles de délai, tests de cohérence à la manière de dbt (clé unique, un client par commande, revenu
positif sur les commandes abouties). Chaque requête se garde dans `travail/<projet>/` avec son numéro
d'étape.

## 4. Analyse : ce que chaque méthode prouve, et ne prouve pas

`references/analyse-business.py` (pandas, DuckDB, scipy, scikit-learn ; testé) : distributions
(médiane, écart interquartile, jamais la moyenne seule), corrélation (Pearson et Spearman, avec la taille
d'échantillon), segmentation RFM par rangs (pas par seuils arbitraires), test de proportions et khi-deux
pour comparer deux groupes, régression logistique pour hiérarchiser des facteurs de churn.

- Une corrélation de 0,48 sur 33 personnes n'est pas une relation, c'est une piste.
- Un écart de 1,8 point entre départements de 8 000 personnes se **teste** avant de s'écrire.
- Une régression hiérarchise des facteurs ; elle ne dit pas lequel actionner, ni ce qu'il coûte.
- Des données **simulées** rendent l'insight qu'on y a mis : plusieurs portfolios « découvrent » la
  formule de leur propre générateur. Dire toujours l'origine des données.

## 5. Tableau de bord : une page par décision

Pratique à reprendre du portfolio de Jamie Christian : chaque tableau de bord livré avec **un
dictionnaire de données** (définitions, règles métier, formules) et **une table de correspondance
champs ↔ visuels** (quelle colonne alimente quel visuel), plus une étape « valider les KPI contre la
source » avant diffusion. C'est ce que je fais déjà avec le contrôle « juin 2026 : 2 466 / 2 377 /
129 897 600 » d'un guide client de test : le rendre systématique.

## 6. Recommandation : constat → preuve → implication → action

Interdit : « le graphique montre que les ventes ont augmenté ». Attendu :

> **Constat.** Le segment X pèse 38 % du revenu (calculé, période, source).
> **Preuve.** Sa marge brute est de 12 points sous la moyenne (calculé, même période ; définition de la
> marge : …).
> **Implication.** Augmenter les volumes sur X augmenterait le revenu et dégraderait la marge globale.
> **Action proposée.** Analyser la politique de remise sur X avant toute campagne de volume. Décision :
> direction commerciale.

Puis les trois rubriques obligatoires : ce que les données montrent, ce qu'elles ne permettent pas de
conclure, ce qui doit être décidé par la direction. Une action sans preuve chiffrée en face n'est pas une
recommandation, c'est une opinion ; elle se retire ou se marque `[hypothèse]`.

## 7. Les pièges vus dans les 22 portfolios (à ne pas reproduire)

1. **L'observation-description** : « les ventes sont plus fortes en semaine » sans implication ni action.
2. **Le total sans exposition** : sinistres par marque sans nombre de contrats, attrition par service sans
   effectif, revenu par canal sans budget.
3. **Le seuil inventé** : une colonne « objectif » remplie par l'analyste, puis un statut rouge ou vert.
4. **Le hasard présenté comme signal** : 50 % d'attrition partout, écarts de 1 à 2 points commentés
   comme des différences.
5. **La généralisation d'un petit échantillon** : 33 participants → « les utilisateurs ».
6. **L'insight du générateur** : données simulées avec le résultat codé dedans.
7. **La recommandation orpheline** : « renforcer la tarification au risque » sans le chiffre qui la fonde.
8. **Le nettoyage destructeur** : `DELETE` des doublons et des colonnes dans la source (script
   Nashville) ; chez moi, jamais : copie de travail et trace.
9. **La moyenne seule** sur des montants à queue lourde (transactions, sinistres) : médiane et
   distribution d'abord.
10. **Le tableau de bord sans dictionnaire** : des cartes KPI dont personne ne peut redire la formule.

## Sources lues le 21/09/2026 (dépôts publics, clonés puis retirés du poste)
shivee-code/Power-BI_projects_portfolio · IndraT97/Power-BI-DAX · IndraT97/Everything-About-SQL ·
IndraT97/Sales-Exploratory-Data-Analysis · talha-amin/powerbi-portfolio ·
talha-amin/E_Commerce_Customer_Sales_Analytics · talha-amin/Marketing_Campaign_Performance_Analytics ·
talha-amin/netflix_movies_and_tv_shows_analysis · vijaykg01/POWER-BI · vijaykg01/Matplotlib_and_Seaborn ·
ashlynstrickland23/PowerBI_Portfolio · ashlynstrickland23/R_Portfolio · daniel-j77/Data-Analyst-Portfolio ·
ryniewiczg/Data-Analyst-portfolio · STCybersec/Data-Analysis-BI---Portfolio ·
JamieChristian22/data-analyst-portfolio · oluwatobindom/PortfolioProjects · chedelino/My-first-data-portfolio ·
keyswill/data-analytics-portfolio · PiyushDave30/data-analyst-project-portfolio ·
mdkeum/data-analytics-portfolio · satishpappu/analytics-engineering-with-dbt.
Les plus utiles : JamieChristian22 (dictionnaires, SQL avancé), STCybersec (trame DMAIC, cinq pourquoi),
satishpappu (tests de cohérence dbt, faits et dimensions), talha-amin (RFM par rangs, entonnoir SQL),
IndraT97 (DAX). Les autres servent surtout d'exemples de ce qu'il ne faut pas faire (section 7).
