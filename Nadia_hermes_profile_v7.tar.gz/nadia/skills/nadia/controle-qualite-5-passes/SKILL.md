---
name: controle-qualite-5-passes
description: Protocole de contrôle qualité multi-agents à 5 passes indépendantes AVANT toute publication destinée au dirigeant ou à la direction générale (ou tout décideur à enjeu). Garantit qu'aucune donnée fausse, périmée ou non sourcée ne remonte. À invoquer sur toute note, brief, revue de presse, discours ou analyse avant livraison.
version: 1
maj: 2026-08-26
---

# Contrôle qualité : 5 passes (standard zéro-erreur)

Aucune publication destinée à la direction ne sort sans avoir passé **cinq vérifications indépendantes**, menées par des passes/agents différents (idéalement des sous-agents distincts, sinon des relectures séquentielles à consigne changeante). Objectif : que la donnée qui remonte au dirigeant soit **toujours la meilleure possible**, juste, à jour, sourcée.

## Quand l'utiliser

- **Systématiquement, sans exception et sans qu'on le demande**, avant de livrer à la direction : note d'aide à la décision, brief de rendez-vous (client, fournisseur, banque), revue de presse sectorielle, éléments de langage, discours, analyse, réponse factuelle à enjeu.
- Dès qu'un contenu affirme des **faits** (personnes, fonctions, dates, chiffres, citations, statuts juridiques, événements).

## Le protocole (5 passes)

Chaque passe est menée **indépendamment** (un vérificateur ne voit pas les conclusions des autres avant d'avoir formé la sienne). Sur sujet sensible, chaque passe = un **sous-agent dédié**.

1. **Passe 1, Rédaction.** Produire le contenu, chaque fait porté par une source identifiée. Sortie : le livrable + une liste `fait → source`.
2. **Passe 2, Source primaire.** Reprendre CHAQUE affirmation et la confronter à sa **source primaire** (site officiel de l'entreprise ou du partenaire, communiqué, rapport, dépêche datée). Rejeter toute source secondaire non corroborée. Cible prioritaire : personnes, fonctions, dates, chiffres, citations, montants.
3. **Passe 3, Fraîcheur / statut courant.** Traquer toute information **périmée** présentée comme actuelle. Vérifier le **statut courant** de chaque personne citée (fonction en cours à la date du jour) et la **date réelle** de toute actualité « récente ». Danger n°1 : une fonction périmée, une actu qui date en fait de plusieurs mois/années.
4. **Passe 4, Adverse (réfutation).** Chercher activement à **RÉFUTER** chaque point sensible ("prouve que c'est faux"). Par défaut, en cas de doute → `refuté`. Sur point clé, donner des **lentilles** différentes aux vérificateurs (exactitude, statut de poste, cohérence juridique, plausibilité). Ne survit que ce qui résiste.
5. **Passe 5, Cohérence & complétude.** Relecture d'ensemble : contradictions internes, arithmétique qui boucle (chiffre d'affaires vs total, %…), ton adapté, angles morts, ce qui **manque**. Question finale : « qu'est-ce qui pourrait faire mal si c'était faux, et l'a-t-on vérifié ? ».

## Règle des sources distinctes (non négociable)

Quatre vérifications qui s'appuient sur **la même source** ne valent qu'une seule vérification.
Ce protocole ne compte que les contrôles menés sur des **sources indépendantes les unes des
autres**, éditeurs, institutions ou circuits d'information différents.

- **Un fait sensible = au minimum 3 sources primaires indépendantes**, dont au moins une
  **officielle** (site de l'entreprise ou du partenaire, rapport annuel, communiqué, texte
  réglementaire) quand elle existe.
- Deux articles qui reprennent la même dépêche d'agence = **une** source, pas deux. Vérifier
  d'où vient réellement l'information avant de la compter.
- Une source qui contredit les autres n'est pas écartée en silence : l'écart est **signalé**
  dans le livrable (c'est souvent l'écart qui porte l'information).
- Si le fait ne tient que sur **une seule** source, il ne s'écrit pas comme acquis :
  `⚠ source unique, à confirmer`.

## Visa de contrôle (obligatoire sur tout document)

**Aucun document ne quitte Yelema sans son visa.** C'est la contrepartie visible du protocole :
la direction doit pouvoir voir, en un coup d'œil, que le contrôle a réellement eu lieu et jusqu'où
il est allé. Un document sans visa est un brouillon, pas un livrable.

### Le visa nomme ses sources, il ne les compte pas

**C'est la règle qui rend le visa vérifiable.** Écrire « 7 sources primaires indépendantes » ne
prouve rien : un contrôle réellement mené et un contrôle simplement affirmé produisent
exactement la même ligne. Une liste de sources nommées, datées et cliquables, elle, s'ouvre
n'importe quel lecteur peut aller voir. Un décompte demande la confiance ; une liste la mérite.

Apposer en fin de document :

```
- Contrôle qualité
Passes effectuées : 1 rédaction · 2 source primaire · 3 fraîcheur · 4 réfutation · 5 cohérence
Sources effectivement ouvertes :
  - <intitulé de la source>, <date>, <lien>
  - <intitulé de la source>, <date>, <lien>
  - …
Statuts courants revérifiés : oui/non
Relecture adverse : effectuée le JJ/MM/AAAA (IA <autre fournisseur>) | non requise, <motif>
Points non confirmés : <liste, ou « aucun »>
Date du contrôle : JJ/MM/AAAA
```

Une source interne sans lien se cite quand même, par son intitulé et sa date (« relevé de
décisions n° 077 du 07/08/2026 ») : ce qui compte est qu'elle soit **retrouvable**, pas qu'elle
soit en ligne.

### Un lien cité est un lien ouvert : jamais un lien reconstitué

Nommer ses sources ne suffit pas si les adresses ne s'ouvrent pas : le visa se retourne alors
contre celui qui l'a signé. Le piège est précis, et il ne ressemble pas à une invention. On
connaît le fait, on connaît le site, on a même vu l'article, et l'on écrit une adresse *de la
forme habituelle de ce site* sans l'avoir ouverte. Elle tombe dans le vide.

Cas type, campagne du 02/08/2026 : le visa d'une note de cadrage attestait « statuts courants
Aya Kouadio confirmée Directrice Générale de la filiale Sud Logistique (EcoAfrik Info,
28/01/2026) » avec l'adresse `ecoafrik.info/344624/`. **Le fait était juste**, nomination le
23 janvier, prise de fonction le 28. L'adresse, elle, n'existait pas ; la véritable comportait un
intitulé après le numéro. Les deux liens EcoAfrik réduits à un numéro nu étaient morts, les liens
EcoAfrik portant leur intitulé étaient tous valides.

Deux règles en découlent :

- **On ne cite que ce qu'on a ouvert.** Fait connu mais adresse incertaine → on nomme la source
  en clair, sans lien (« EcoAfrik Info, 28 janvier 2026 »), ou on va la chercher. Un lien mort est
  plus grave qu'une absence de lien : l'absence se voit, le lien mort inspire confiance jusqu'au
  jour où quelqu'un clique.
- **La passe 5 finit par la vérification mécanique des liens**, parce qu'aucune relecture
  attentive ne distingue une adresse ouverte d'une adresse plausible :

```bash
outils/verifier-les-liens.sh <le_document>
```

`MORT` (404/410) se retire ou se remplace, sans discussion. `PROTÉGÉ` (403) est un pare-feu
anti-robot, fréquent sur la presse, et se garde. `INJOIGNABLE` peut être un site public hors
service ; à vérifier soi-même avant d'en conclure quoi que ce soit.

Cinq interdits : cocher une passe qui n'a pas été réellement menée ; **compter les sources au
lieu de les nommer** ; **citer une adresse qu'on n'a pas ouverte** ; écrire « aucun point non
confirmé » alors qu'un fait tient sur une source unique ; réutiliser un visa d'un document
antérieur. Le visa engage la crédibilité de Yelema auprès de la direction de l'entreprise, un
visa de complaisance est pire que pas de visa du tout.

### La relecture adverse externe est obligatoire

Les cinq passes partagent un défaut : elles sont menées par le même modèle, avec les mêmes
angles morts. La passe 4 cherche à réfuter, mais elle cherche là où elle sait chercher.

**Tout document qui quitte l'entreprise, engage la société ou porte un arbitrage** passe donc
en plus par `boucle-qa-adverse-livrable`, une relecture par une IA d'un **autre fournisseur**,
à qui l'on demande explicitement de faire échouer le document. C'est la seule passe qui ne
raisonne pas comme Yelema.

Sur un document courant qui n'y est pas soumis, une revue de presse quotidienne, un point
d'engagements, le visa l'écrit : `Relecture adverse : non requise, revue quotidienne`. Le
silence n'est pas une option : un visa muet sur ce point se lit comme une relecture faite.

## Règle de décision

- Une affirmation qui **ne survit pas** aux passes est **retirée** ou marquée `⚠ À VÉRIFIER`, **jamais** servie comme acquise.
- Sujet sensible en mouvement (organigramme, actionnariat, réglementation, marché) → exiger **3 sources primaires indépendantes** et vérifier le statut courant de chaque personne.
- Tout livrable factuel se termine par une **Annexe de traçabilité** : par fait sensible → source (URL) + date + statut (✅ vérifié / ⚠ à vérifier).

## Mise en œuvre multi-agents (recommandée sur sujet sensible)

Lancer les passes 2-5 comme **sous-agents parallèles** avec des consignes distinctes, chacun retournant un verdict structuré (`{fait, verdict: confirmé|réfuté|incertain, source, note}`), puis ne garder que les faits `confirmés` par ≥ la majorité et retirer/annoter le reste. C'est la logique du fact-checker, poussée à 5 angles indépendants.

## Anti-patterns

- ❌ Une seule relecture par le même modèle qui a rédigé (il ne voit pas ses propres angles morts).
- ❌ Faire confiance à la sortie d'un LLM sur ses propres sources (un agent peut **confabuler** des citations crédibles, toujours re-vérifier sur la source réelle).
- ❌ Publier un chiffre « de mémoire » sans re-lire la source d'origine.
- ❌ Présenter comme actuel un fait dont on n'a pas confirmé la date.

## Origine

Standard demandé par le commanditaire de Yelema (23/07/2026) : « toute publication vérifiée au moins cinq fois par des agents différents pour être sûr que la donnée qui ressort auprès de la direction soit toujours la meilleure. »

Renforcé le 31/07/2026 sur sa demande : les vérifications doivent s'appuyer sur des **sources différentes**, et chaque document doit porter un **visa de contrôle** attestant que les passes ont eu lieu. Ce renforcement vient d'un cas réel : la mémoire livrée avec Yelema affirmait qu'un contrat-cadre avait été signé avec un grand distributeur le 21/02/2026, **ce contrat n'a jamais existé**. L'erreur a été prise par une passe de revérification sur sources indépendantes, pas par une relecture. C'est exactement ce que ce protocole est là pour attraper.
