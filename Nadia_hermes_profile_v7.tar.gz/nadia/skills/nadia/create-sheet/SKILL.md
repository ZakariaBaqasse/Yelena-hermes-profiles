---
id: Y0115
name: create-sheet
description: Construit un Google Sheet multi-onglets propre (données, suivi, modèle), créé, rempli, formaté, figé, partagé, équivalent maison d'un générateur type Genspark Sheets.
bucket: B
tags: [Production & artefacts, Data & Analytics]
version: 1
maj: 2026-08-26
---

# create-sheet : le tableur multi-onglets

> **Skill maison Yelema.** Notre chaîne de création de Sheets
> multi-onglets (API REST) est un savoir-faire interne ; elle ne dépend d'aucun outil tiers.

## Ce qu'il faut avoir sous la main
1. **Objet** : à quoi sert le sheet (suivi, base de contacts, comparatif, modèle de calcul, catalogue…).
2. **Onglets & colonnes** : la structure voulue (ou dis « propose une structure » et je la conçois).
3. **Données** : le contenu à charger (colle-le, ou pointe une source). Chiffre absent = on ne l'invente pas.
4. **Mise en forme** : en-têtes figés, largeurs, code couleur / formatage conditionnel, formules.
5. **Partage** : avec qui, en lecture ou édition.


**Ce qu'elle suppose comme accès** : Google Sheets/Drive REST. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Concevoir la structure** : un onglet par jeu de données cohérent ; colonnes nommées ; types (texte/nombre/date) clairs.
2. **Créer le classeur multi-onglets d'un coup** : **Sheets REST** `spreadsheets.create` (tous les onglets définis dans la même requête), plus fiable que gog (qui ne crée pas d'onglets) et que les helpers ad hoc.
3. **Charger les données** : `values.update` en `USER_ENTERED` (formules/dates interprétées) ou `RAW` (texte brut, ex. numéros de téléphone alignés à gauche en format TEXT).
4. **Mettre en forme** : `batchUpdate`, figer la 1re ligne, gras sur l'en-tête, largeurs de colonnes, **formatage conditionnel** (le « code couleur » se pose en règles, pas en fond manuel).
5. **Ranger & partager** : déplacer dans le bon dossier (Drive PATCH addParents/removeParents) ; partager (domaine ou utilisateur précis selon la sensibilité).
6. **QA** : relire via `values.get` (pas `includeGridData`, qui **tronque** par intermittence) ; compter les lignes réelles avant tout dédoublonnage/suppression.

## Format de sortie
- **Livrable principal** : **Google Sheet** (lien partageable), onglets nommés, en-têtes figés, formats posés.
- **Partage** : selon sensibilité, un onglet perso/confidentiel se partage à la personne précise, jamais au domaine.
- **Support** : réponse directe (« sheet prêt, N onglets, lien ») puis le lien.
- **Règle 0 invention** : aucune valeur inventée. Placeholder à sourcer → marqué visiblement (ex. rouge italique « à sourcer »), jamais présenté comme une vraie donnée.

## Règles
- **Créer les onglets via l'API** (`spreadsheets.create` ou `AddSheet`), pas à la main : gog ne crée pas d'onglets.
- **`update SHEET_ID` avant le range** (sinon erreur « expected <range> »).
- **Ne jamais se fier à `includeGridData`** pour la complétude (troncature aléatoire) : compter/dédup/vérifier via `values.get` sur un range.
- **Ne jamais supprimer des lignes avec des index périmés** : re-lire, résoudre par identité, supprimer en ordre **descendant** dans un seul snapshot.
- **Écriture `values.update` efface les hyperliens** de la cellule → re-poser les liens **après** l'écriture.
- **Confidentialité** : pas de financier interne dans un sheet partagé au domaine/tiers.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **`values.append`** avec des lignes vides dans la table → l'insert atterrit en haut : viser `last-non-empty-row` + `values.update`, pas `append`.
- **Locale fr_FR** : séparateur de formule `;` (`=HYPERLINK("u";"u")`), pas `,`.
- **Gros volume** : charger par batch ; formats en une passe `batchUpdate`.
- **Récupération après erreur de suppression** : export d'une révision Drive (`revisions?fields=exportLinks` → xlsx → diff) pour reconstruire.

## Détails complémentaires
### Positionnement
Notre valeur : un **classeur multi-onglets structuré, formaté, versionné et rangé** dans le Drive, avec les garde-fous anti-perte de données. SKU Yelema opérable.
