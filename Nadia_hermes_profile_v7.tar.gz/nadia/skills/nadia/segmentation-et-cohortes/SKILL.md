---
id: Y0689
name: segmentation-et-cohortes
description: "Découpe la base de clients ou d'utilisateurs en groupes qui appellent des actions différentes (valeur et fréquence, ancienneté, canal), mesure la rétention cohorte par cohorte, et dit pour chaque segment quoi en faire, sans jamais nommer une personne ni recopier un seuil de manuel."
bucket: B
tags: [Données, Clients, Nouveau]
version: 1
maj: 2026-09-21
---

# La segmentation et les cohortes, savoir qui sont les clients et lesquels restent

## Ce qu'il faut avoir sous la main
- **L'export de transactions ou d'inscriptions** : identifiant client, date, montant, canal si tu l'as. Un fichier brut suffit, je nettoie.
- **Ce que tu appelles déjà « client fidèle » ou « client qui part »** dans ton métier, même en langage courant, même sans seuil précis.
- **Ce que tu veux pouvoir faire avec chaque segment** : relancer, remercier, arrêter de démarcher, comprendre un décrochage.
- **La période couverte** par l'export, et si des lancements ou campagnes particulières l'ont marquée.
- **Qui doit voir le livrable** : équipe interne uniquement, ou une liste nominative est-elle attendue en plus (auquel cas elle part dans un fichier séparé, avec ses propres droits).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un export t'est déjà fourni (même sans canal, même sans historique long), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les seuils non tranchés `⟦à renseigner⟧`, tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Nettoyer et dédoublonner avant toute chose

Tu ne segmentes jamais un export brut. Applique d'abord la logique de la compétence `qualite-de-la-donnee` : formats de date homogènes, montants dans une seule devise (le franc CFA a une parité fixe avec l'euro, donc aucune conversion à deviner, mais vérifie qu'aucune ligne n'est en devise étrangère par erreur), colonnes vides ou aberrantes signalées.

Le point qui casse le plus souvent une segmentation locale : l'identifiant client. Un numéro de téléphone écrit `+225 07 XX XX XX XX`, `0707XXXXXX` et `07 07 XX XX XX` est le même client sous trois formes. Un client qui achète parfois via un vendeur et parfois en direct peut apparaître sous deux noms. Normalise les numéros (même format, même préfixe pays), rapproche les noms proches, et **documente ta règle de rapprochement** dans la fiche de définitions : sans elle, personne ne pourra vérifier ou reproduire le dédoublonnage.

Ce qui trahit un dédoublonnage bâclé : un pic soudain de « nouveaux clients » sur un mois qui n'a connu ni campagne ni lancement. C'est le signal qu'un ancien client a été mal saisi et compté deux fois.

### Étape 2 : Construire les segments de valeur et de fréquence

Calcule pour chaque client : nombre de transactions sur la période, montant total, montant moyen, date de dernière activité. Regarde la **distribution réelle** de ces indicateurs avant de fixer quoi que ce soit : trace les quartiles, cherche les cassures visibles (un saut net dans la courbe triée du montant total, par exemple).

Le piège à nommer explicitement : un seuil du type « gros client à partir de 100 000 F CFA » parce que c'est un chiffre rond, ou parce qu'un autre secteur ou un autre pays l'utilise. Le seuil correct est celui qui correspond à une cassure ou un quartile de **cette base-là**. S'il n'y a pas de cassure nette, dis-le et propose le quartile comme convention par défaut, en le marquant explicitement comme une convention et non une loi de la donnée.

Regroupe ensuite en segments comportementaux : les clients actifs et réguliers, ceux qui ont acheté une fois et jamais revu, ceux dont la dernière activité recule (à risque de décrochage), ceux qui reviennent mais avec un panier qui baisse. **Cinq à six segments maximum.** Chaque segment doit appeler une action différente des autres ; si deux segments recevraient la même recommandation, fusionne-les.

### Étape 3 : Construire les cohortes, séparément

Une cohorte n'est pas un segment : elle se définit par une **date d'entrée** (mois du premier achat, ou mois de première inscription) et elle ne change jamais après coup. Un client de la cohorte de janvier reste dans la cohorte de janvier pour toujours, même s'il devient inactif en juin.

Construis la table : en ligne, le mois de la cohorte ; en colonne, le nombre de mois écoulés depuis l'entrée (mois 0, mois 1, mois 2…) ; dans chaque cellule, la part de la cohorte encore active (ou le montant dépensé, selon ce qui sert le plus l'entreprise) à ce mois-là.

Le piège que personne ne voit avant qu'on le lui montre : cette table est **triangulaire**. Une cohorte entrée il y a deux mois n'a de valeur qu'aux mois 0 et 1 ; les cellules au-delà sont vides, pas à zéro, vides. Comparer une cohorte récente à une cohorte ancienne sur le même mois calendaire n'a pas de sens : la lecture correcte se fait **en diagonale**, colonne par colonne (mois 0 vs mois 0, mois 3 vs mois 3), jamais ligne contre ligne sur des mois calendaires différents.

### Étape 4 : Croiser canal et produit d'entrée si la donnée le permet

Si le canal est disponible (point de vente physique, WhatsApp, application, agent terrain), regarde si la rétention diffère selon le canal d'acquisition ou le produit d'entrée. C'est souvent là que se cache l'information utile : un canal qui recrute beaucoup mais retient mal coûte cher sans qu'on le voie dans le seul volume de nouveaux clients.

Ne fais ce croisement que si l'effectif par canal est suffisant pour être lisible ; un canal à quelques clients ne produit qu'un bruit qu'il ne faut pas présenter comme un signal.

### Étape 5 : Écrire l'action derrière chaque chiffre

Chaque segment se termine par une phrase qui dit quoi en faire : relancer par tel canal (WhatsApp est souvent le plus efficace et le moins coûteux dans le contexte local, la radio ou un SMS groupé pour un segment plus large), remercier et fidéliser, ne rien faire de particulier, ou creuser pour comprendre pourquoi le segment décroche avant de dépenser un centime à le relancer.

Un livrable qui s'arrête à « ce segment représente 12 % de la base et 40 % du chiffre d'affaires » sans dire ce qu'on en fait n'est pas terminé. C'est le piège le plus fréquent : décrire est plus facile que recommander, et c'est pour ça qu'on s'y arrête trop tôt.

### Étape 6 : Anonymiser avant de livrer

Aucun nom de personne, aucun numéro de téléphone identifiable ne figure dans le Sheet de segments ni dans les Slides de synthèse. Les segments s'illustrent par des profils anonymes (« un client type de ce segment achète X fois par mois pour un montant moyen de Y »), jamais par un nom.

Si une liste nominative est demandée pour une action concrète (une campagne de relance, un appel commercial), applique la compétence `rgpd-data-protection` : elle part dans un fichier séparé du livrable de synthèse, avec les droits d'accès qui conviennent, et seulement si l'utilisateur l'a explicitement demandée à l'étape de démarrage.

## Format de sortie
- **Livrable 1, Google Sheet** : un onglet base nettoyée et dédoublonnée (avec la règle de dédoublonnage documentée en commentaire ou en onglet à part), un onglet segments (règle de chaque segment, effectif, part du chiffre d'affaires, panier moyen), un onglet table de rétention par cohorte (triangulaire, mise en forme conditionnelle par couleur pour lire la diagonale d'un coup d'œil), et les graphiques associés (répartition des segments, courbe de rétention par cohorte).
- **Livrable 2, Google Slides** : une synthèse pour la direction, un segment par page (sa taille, ce qui le distingue, la phrase d'action), plus une page dédiée à la lecture de la rétention. Aucun nom de personne.
- **Livrable 3, fiche de définitions** : une page qui fixe, pour chaque segment et chaque cohorte, la règle exacte de calcul (indicateur, période, seuil et sa justification par la distribution) afin que le mois suivant, n'importe qui dans l'équipe recalcule à l'identique.
- **Structure du rendu texte qui accompagne les livrables** : answer-first, Markdown clair, listes et tableaux quand c'est pertinent, proportionné à la demande.
- **Les seuils de segmentation sont établis à partir de la distribution réelle de la base fournie.** Un standard sectoriel non vérifié ne sert jamais de référence. Un seuil sans cassure nette est présenté comme une convention (ex. quartile). Une convention ne devient jamais une loi de la donnée.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Dédoublonnage avant segmentation, toujours.** Un identifiant client qui ne se recoupe pas fausse tout ce qui suit ; tu ne segmentes jamais un export dont tu n'as pas d'abord vérifié l'unicité des identifiants.
2. **Cinq à six segments maximum.** Un segment de plus se justifie seulement s'il appelle une action réellement différente de tous les autres ; sinon, il fusionne.
3. **Cohorte et segment ne se mélangent jamais dans le même tableau.** La cohorte est figée par une date d'entrée, le segment bouge chaque mois selon le comportement ; ce sont deux lectures séparées, jamais une colonne unique qui prétend faire les deux.
4. **La table de rétention se lit en diagonale, jamais en ligne sur des mois calendaires différents.** Une cohorte jeune n'a pas encore l'âge d'être comparée à une cohorte ancienne sur les mêmes mois de vie ; les cellules hors de portée restent vides, jamais complétées par une extrapolation.
5. **0 chiffre inventé.** Aucun seuil, aucune part de marché, aucun taux de rétention moyen « du secteur » n'est produit sans être calculé à partir de la donnée fournie ou sourcé explicitement : `⟦à renseigner⟧` sinon.
6. **Chaque segment se termine par une phrase d'action.** Décrire un segment sans dire quoi en faire n'est pas un livrable terminé.
7. **Aucun nom de personne dans les livrables de synthèse.** Les segments s'illustrent par des profils anonymes ; une liste nominative, si elle est nécessaire, part dans un fichier séparé, sous la compétence `rgpd-data-protection`.
8. **Le contexte local n'est pas un décor.** Un canal WhatsApp, une transaction en mobile money, un client acquis via un vendeur terrain plutôt qu'en ligne : ces réalités changent la lecture des segments et des canaux, elles ne sont pas des détails à uniformiser.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit des documents de travail ; envoyer une relance, exporter une liste nominative vers un tiers ou lancer une campagne est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une base client ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Export sans colonne canal**, tu produis la segmentation par valeur, fréquence et ancienneté normalement, tu marques le croisement par canal comme non réalisable, et tu ne le remplaces par aucune supposition.
- **Historique trop court pour des cohortes lisibles** (moins de trois mois de données), tu le dis explicitement, tu produis la segmentation par valeur et fréquence qui reste valide, et tu marques la table de rétention comme prématurée plutôt que de la remplir avec une seule colonne peu informative.
- **Identifiants clients manifestement non fiables** (beaucoup de doublons visibles, formats hétérogènes non normalisables avec certitude), tu signales l'ampleur du problème avant de continuer, tu appliques la règle de rapprochement la plus prudente et documentée, et tu marques le résultat comme une estimation du dédoublonnage. Le dédoublonnage ne garantit jamais une certitude.
- **Demande de liste nominative**, tu la traites à part, dans un fichier séparé du livrable de synthèse, sous la compétence `rgpd-data-protection`, et seulement si elle a été explicitement demandée.
- **Aucune cassure nette dans la distribution** pour fixer un seuil de segment, tu le dis, tu proposes le quartile comme convention par défaut en le nommant comme tel, et tu n'inventes pas une cassure qui n'existe pas.
- **Donnée introuvable ou colonne vide sur une partie de la base**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné.
- **Demande hors périmètre** (prévision de revenus, scoring de crédit, ciblage publicitaire), tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi de relance, export vers un outil marketing, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
