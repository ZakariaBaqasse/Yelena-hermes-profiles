---
name: environnement-de-calcul
description: "L'environnement de calcul du poste, exigé par la direction (Yelema) le 21/09/2026 : Python avec pandas, DuckDB et SQL pour les CSV, Excel et Parquet, openpyxl pour lire et écrire Excel, deux outils prêts (contrôles automatiques avant calcul, requête SQL sur fichiers), et la convention qui conserve chaque étape de calcul et chaque fichier intermédiaire. À charger dès qu'un fichier de données arrive, avant d'écrire une ligne de pandas."
version: 2
maj: 2026-09-21
---

# L'environnement de calcul (21/09/2026)

Consigne reçue : « Nadia doit disposer d'un environnement de calcul capable de traiter proprement les
données : Python ; pandas pour les tableaux ; DuckDB ou SQL pour les fichiers CSV, Excel et Parquet ;
openpyxl pour lire et écrire dans Excel ; règles automatiques de contrôle des doublons, valeurs
manquantes, types, dates et valeurs aberrantes ; possibilité de conserver les étapes de calcul et les
fichiers intermédiaires. La combinaison la plus utile serait : Python + pandas + DuckDB + SQL ».

## Ce qui est installé (vérifié le 21/09/2026)
Interpréteur : `~/.venv-office/bin/python`. pandas 3.0, DuckDB 1.5, openpyxl 3.1, pyarrow 25 (Parquet),
numpy, matplotlib. Toujours cet interpréteur, jamais `python3` nu, qui n'a pas ces bibliothèques.

## Les deux outils, dans `outils/`
- `controler-donnees.py <fichier> [--cle COL] [--date COL] [--schema s.json] [--positif COL]
  [--structure-precedente structure.json] [--comparer AUTRE] [--sortie DOSSIER]` : le système de
  contrôle qualité standard (consigne du 21/09/2026, 16:03 UTC), dix familles de contrôles : colonnes
  manquantes (schéma déclaré), doublons (lignes, clé), valeurs vides, formats incorrects (type déclaré ou
  mêlé), dates incohérentes (illisibles, hors 1990 à demain), valeurs négatives ou impossibles
  (`--positif`), périodes manquantes (mois sans ligne), changements de structure (contre le
  `structure.json` du contrôle précédent), écarts entre deux sources (`--comparer` sur la clé : clés
  absentes d'un côté, valeurs différentes, sommes A et B et écart), valeurs aberrantes (hors trois écarts
  interquartiles, « valeur à vérifier », jamais « erreur »). Chaque contrôle sort une ligne : règle
  appliquée, nombre d'erreurs, lignes concernées, taux d'anomalie, impact potentiel, statut de
  correction. **La source n'est jamais modifiée.** `--sortie` écrit controles.csv, controles.xlsx (une
  feuille par contrôle avec les lignes) et structure.json. 75 000 lignes en vingt secondes.
  Le schéma attendu s'écrit `{"colonnes": {"nom": "nombre|date|texte"}}` et se garde dans `travail/<projet>/schema.json`.
- `requete-sql.py "<SQL>" --table nom=chemin[:feuille] [--sortie fichier]` : DuckDB sur CSV, Excel ou
  Parquet ; agrégats, rapprochements, cohortes en SQL plutôt qu'en pandas quand la requête se lit mieux.

## Conserver les étapes : convention `travail/`
Chaque mission a son dossier `travail/<projet>/<AAAAMMJJ>/`, et chaque étape y laisse une trace :
```
[référence retirée]
  00_source_transactions.csv        ← copie intacte de ce qui a été reçu (jamais éditée)
  01_controles/                     ← sortie de controler-donnees.py
  02_normalise.parquet              ← copie de travail après normalisation (espaces, formats)
  03_agregats_mensuels.csv
  etapes.md                         ← une ligne par étape : heure, outil ou script, entrée, sortie, règle appliquée
```
- Les numéros donnent l'ordre ; on ne réécrit pas une étape, on en ajoute une.
- Toute transformation s'inscrit dans `etapes.md` avec valeur avant, valeur après, règle, date, source
  (règle 7 du protocole de mission). Le script qui a produit une étape se garde à côté (`03_agregats.py`).
- Parquet pour les intermédiaires volumineux (types conservés), CSV pour ce qu'un humain relira.
- `travail/` est de la matière interne : rien n'en part vers `deliverables/` sans passer par un gabarit.

## Ordre de marche quand un fichier arrive
1. Copier dans `travail/…/00_source_…` ; 2. `controler-donnees.py` et coller le tableau dans le livrable ;
3. requêtes et calculs, chacun tracé ; 4. gabarit, charte, dépôt.

## Outils de visualisation, vérifiés le 21/09/2026 (consigne du même jour, 16:07 UTC)
Le bon outil selon le besoin, et ce que le poste sait faire :
- **Power BI**, tableaux de bord de direction et suivi récurrent : lecture par Fabric IQ en attente de
  connexion ; construction = paquet complet (modèle CSV, requêtes M, mesures DAX, thème JSON, maquette,
  guide) car Power BI Desktop n'existe que sous Windows ; publication réservée au profil Builder.
- **Tableau Cloud**, quand la maison l'utilise : lecture par le serveur hébergé, en attente de connexion.
- **Excel**, analyses opérationnelles et fichiers manipulables : openpyxl (formules, plages nommées,
  graphiques natifs), xlsxwriter ; conversion en Google Sheet conserve formules et graphiques (testé).
- **Plotly 7**, graphiques interactifs : page HTML autonome (`write_html`) ; image fixe par kaleido avec
  `BROWSER_PATH=~/.cache/ms-playwright/chromium-1148/chrome-linux/chrome` (testé, PNG produit).
- **Matplotlib 3.11 et Seaborn 0.13**, graphiques fixes des rapports : PNG et SVG aux couleurs de la charte.
- **PowerPoint**, présentations de direction : python-pptx (compétence `pptx`), PDF par LibreOffice.
- **Google Slides**, quand l'équipe vit dans Google Workspace : création depuis Markdown ou depuis un
  modèle, ajout de diapositives-images, export PDF ou PPTX par le compte Google du poste.
- **Google Sheets** : pas de tableau de bord complexe, sauf besoin simple ou temporaire ; sert de
  livraison calculable et de collecte.
- **Looker** : rien sur le poste, aucune instance ni identifiant ; à brancher si une maison l'utilise.

## Six familles de graphiques dans tout rapport, même en Excel (consigne du 21/09/2026, 19:45 UTC)
« Assure toi qu'il ait toujours des histogrammes, camemberts, courbes, graphiques en barres (horizontal et
vertical), nuages de points, colorés et attrayants lorsque tu fais des rapports même avec excel. »

Outil : `outils/graphiques.py` (testé le 21/09/2026 sur un jeu de transactions de test, rendu vérifié à l'œil
après conversion PDF). `Palette([...couleurs de la charte...], police=...)`, puis :
- **Excel natif** (`excel.barres` vertical ou horizontal, `excel.camembert`, `excel.courbe`, `excel.nuage`,
  `excel.histogramme`) : une couleur de la charte par barre ou par part, étiquettes de valeurs propres,
  axes en milliers, légende retirée quand elle ne dit rien. Les graphiques survivent à la conversion en
  Google Sheet.
- **Images** (`image.*`, mêmes six familles) : PNG 200 dpi, titre à gauche, source en pied, milliers
  avec espace fine, histogramme borné au 99ᵉ centile avec la part au-delà écrite dessus (jamais
  supprimée), nuage coloré par catégorie si demandé. Police de la charte si installée, sinon repli sans
  bruit.

Règle de composition d'un rapport chiffré : au minimum une **courbe** (le temps), des **barres** (les
catégories, verticales pour comparer, horizontales pour classer), un **camembert** (une répartition à
cinq parts au plus), un **histogramme** (la distribution d'un montant, avec sa médiane), un **nuage**
(une relation entre deux mesures), chacun titré par ce qu'il montre, pas par ce qu'il contient. Quand
les données ne se prêtent pas à une famille (pas de série temporelle, pas de relation à montrer), le
rapport le dit en une ligne plutôt que de forcer un graphique vide de sens.
