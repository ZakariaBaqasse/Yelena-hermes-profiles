---
id: Y0692
name: reel-contre-budget
description: "Compare, période par période, le réalisé au budget (ventes, charges, marges, volumes, effectifs), calcule les écarts en montant et en pourcentage, les classe par importance, et propose pour chacun une explication vérifiée dans les données (volume, prix, mix, calendrier, événement exceptionnel) ou, à défaut, la question précise à poser à la personne qui sait, sans jamais déduire une cause qu'aucune donnée ne montre."
bucket: B
tags: [Données, Pilotage, Nouveau]
version: 1
maj: 2026-09-21
---

# Le réel contre le budget, les écarts expliqués avant qu'on les subisse

## Ce qu'il faut avoir sous la main
- **Le fichier du réel** : ventes, charges, marges, volumes ou effectifs réellement constatés, avec leurs périodes.
- **Le fichier du budget** (ou objectif, ou plan) : les mêmes lignes, telles qu'elles avaient été prévues.
- **La granularité** que tu veux voir : par mois, par trimestre, par ligne de produit, par agence.
- **Le seuil de commentaire** que la direction retient : à partir de quel montant et de quel pourcentage un écart mérite une phrase. Si tu ne l'as pas encore fixé, dis-le, je pose la grille et tu la remplis.
- **Qui peut répondre aux questions** que les données ne tranchent pas : commercial, contrôle de gestion, production, RH selon les lignes concernées.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Aligner avant de comparer

Rien ne se compare tant que le réel et le budget ne parlent pas la même langue. Tu vérifies quatre choses avant tout calcul :

- **Les périodes** : un budget trimestriel contre un réel mensuel ne se compare pas ligne à ligne sans agrégation. Tu ramènes les deux à la même maille, et tu dis laquelle.
- **Les catégories** : une ligne renommée, fusionnée ou scindée en cours d'année casse la comparaison si elle passe inaperçue. Tu repères les libellés qui ont changé et tu documentes la correspondance.
- **Les unités et le périmètre fiscal** : hors taxes contre toutes taxes, devise locale contre une devise étrangère convertie à un taux non précisé, un périmètre de filiales qui diffère entre les deux fichiers. La parité fixe du franc CFA avec l'euro simplifie une conversion CFA/EUR ; toute autre devise implique un taux à documenter, jamais à deviner.
- **Le calendrier métier** : un mois de 4 semaines contre un mois de 5, des jours ouvrés qui varient selon les fêtes locales et les jours fériés, une saison haute qui ne tombe pas au même moment dans le budget que dans le réel si le budget a été construit sur une hypothèse calendaire différente.

Si l'alignement demande un travail de correspondance ligne à ligne entre des nomenclatures différentes, c'est le métier de `croiser-des-sources-heterogenes` : tu t'appuies dessus plutôt que d'improviser un mapping à la main.

Ce qui a été aligné, et comment, se documente : c'est la première feuille du livrable, pas une étape qu'on efface une fois le tableau produit. Un écart qu'on ne sait pas expliquer six mois plus tard, souvent, vient d'un alignement qu'on a oublié d'écrire.

Piège à nommer : comparer des choses qui ne se comparent pas est l'erreur la plus fréquente de ce travail, et la plus silencieuse : le tableau sort, les chiffres semblent cohérents, et personne ne remarque que le trimestre 2 du budget a été comparé au mois d'avril seul du réel.

### Étape 2 : Calculer l'écart proprement

Pour chaque ligne et chaque période : `écart montant = réel - budget`, `écart pourcentage = écart montant / budget`. Tu précises toujours le sens : un écart positif sur une charge est défavorable, un écart positif sur une vente est favorable. Cette convention se dit une fois, en tête du tableau, et elle est respectée partout.

Tu ajoutes systématiquement le **cumul depuis le début de la période de référence** (l'exercice, le semestre selon ce qui a du sens) à côté de l'écart du mois. Un mois mauvais peut être rattrapé par le mois précédent, et un comité qui ne voit que le mois panique pour rien, ou au contraire relâche l'attention sur un cumul qui se dégrade doucement mois après mois sans qu'aucun mois pris isolément ne déclenche d'alerte.

Piège à nommer : le cumul oublié fait qu'on réagit à un accident isolé, ou qu'on manque une dérive lente. Le mois et le cumul se lisent toujours côte à côte, jamais l'un sans l'autre.

### Étape 3 : Classer par importance, pas par ordre alphabétique ou par pourcentage seul

Le classement des écarts se fait sur une importance réelle, qui combine le montant et le pourcentage, pas sur l'un des deux isolément. Une ligne à 2 % d'écart mais 50 millions de FCFA pèse plus qu'une ligne à 80 % d'écart sur un budget de 100 000 FCFA. Le montant en valeur absolue donne l'ordre de grandeur qui compte pour le compte de résultat ; le pourcentage donne l'ampleur relative de l'erreur de prévision ou de l'accident.

Piège à nommer : un pourcentage spectaculaire sur une petite base affole pour rien et détourne l'attention d'un écart plus modeste en pourcentage mais lourd en montant. Le classement final se fait sur l'importance réelle : montant et pourcentage lus ensemble, jamais un chiffre unique qui prétend résumer les deux.

### Étape 4 : Décider ce qui mérite un commentaire

Le tableau montre toutes les lignes. Le commentaire ne porte que sur celles qui franchissent le seuil convenu avec la direction, en montant et en pourcentage (ou selon la règle de combinaison que la direction préfère, si elle en a une). Ce seuil n'est jamais choisi par la compétence : il est `⟦à renseigner⟧` tant qu'il n'a pas été donné.

Piège à nommer : commenter tous les écarts revient à ne rien signaler du tout, parce que le comité ne peut pas distinguer ce qui compte de ce qui ne compte pas dans une liste de cinquante lignes. Le tableau exhaustif et la liste des écarts commentés sont deux objets différents, et le second doit tenir sur une page.

### Étape 5 : Expliquer, seulement avec ce que les données montrent

Pour chaque écart significatif, tu cherches dans les données elles-mêmes ce qui l'explique, avant de conclure quoi que ce soit :

- **Effet volume** : le nombre d'unités vendues ou produites a changé, indépendamment du prix.
- **Effet prix** : le prix unitaire moyen a bougé, indépendamment du volume.
- **Effet mix** : la composition entre produits ou lignes à marges différentes a changé, ce qui déplace la marge globale sans que chaque ligne, prise isolément, se soit beaucoup écartée.
- **Effet calendrier** : un décalage de facturation, une commande enregistrée un mois plus tôt ou plus tard que prévu, un nombre de jours ouvrés différent.
- **Événement exceptionnel identifié dans les données** : une rupture de stock documentée, une panne, une promotion ponctuelle dont la date figure dans les enregistrements.

Si la décomposition volume/prix/mix est calculable à partir des données transmises, tu la fais et tu montres le calcul. Si elle ne l'est pas (données insuffisantes pour isoler les effets), tu le dis, et tu ne remplaces pas le calcul manquant par une intuition.

Quand aucune de ces pistes n'est vérifiable dans les données reçues, tu ne devines pas. Tu formules la question précise à poser, avec la ligne concernée et la fonction la mieux placée pour y répondre : le commercial pour un effet prix ou un client perdu, le contrôle de gestion pour une erreur de saisie budgétaire, la production pour une rupture d'approvisionnement, les ressources humaines pour un écart d'effectif ou de masse salariale. Une question bien posée avec la bonne ligne et le bon destinataire vaut mieux qu'une explication plausible qu'aucune donnée ne confirme.

Piège à nommer : « les ventes baissent à cause de la pluie » ne se dit que si une donnée montre effectivement une baisse corrélée à une période pluvieuse documentée (calendrier météo, historique de saisonnalité déjà observé sur d'autres années). Sinon, c'est une hypothèse déguisée en fait, et elle devient une question : « la baisse de [tel mois] coïncide-t-elle avec la saison des pluies, ou y a-t-il une autre cause ? », adressée à qui suit le terrain.

### Étape 6 : Regarder aussi le budget, pas seulement le réel

Un écart énorme a deux causes possibles, et les deux restent ouvertes tant qu'aucune donnée ne tranche : une vraie sous-performance ou sur-performance, ou un budget mal construit dès le départ (une ligne dupliquée, un zéro de trop ou de moins, une hypothèse de volume jamais mise à jour depuis l'exercice précédent, une ligne budgétée sur un périmètre qui a changé depuis).

Pour les écarts les plus spectaculaires du classement, tu poses systématiquement la question dans les deux sens : qu'est-ce qui, dans le réel, expliquerait cet écart, et qu'est-ce qui, dans la construction du budget, pourrait expliquer qu'il soit faux. Tu ne trancheras pas seul entre les deux sans donnée qui le permette : c'est souvent la question la plus utile de toute la note.

Piège à nommer : traiter tout écart comme une information sur la performance de l'entreprise, jamais comme une information sur la qualité du budget, fait manquer la moitié des cas où l'écart le plus spectaculaire du tableau est en réalité une erreur de saisie qu'un simple contrôle de cohérence aurait révélée.

### Étape 7 : La tendance sur les dernières périodes

Un écart qui se creuse d'un mois sur l'autre et un écart qui se referme n'appellent pas la même réaction, même s'ils affichent le même montant à l'instant T. Tu affiches les trois dernières périodes côte à côte pour chaque ligne significative, et tu qualifies la tendance : se creuse, se referme, stable, ou trop récent pour conclure (une seule période disponible ne permet pas de parler de tendance, et tu le dis plutôt que de l'affirmer sur deux points).

Piège à nommer : un tableau sans tendance traite un accident ponctuel et une dérive installée de la même façon, alors que la première demande d'attendre le mois suivant et la seconde demande d'agir maintenant.

## Format de sortie

**Google Sheet** :
- **Feuille d'alignement** : ce qui a été mis en correspondance entre le réel et le budget (périodes, catégories, unités, périmètre), et comment. Cette feuille documente les choix de l'étape 1, elle n'est pas un détail technique effacé une fois le tableau produit.
- **Feuille des écarts** : une ligne par ligne budgétaire et par période, avec réel, budget, écart en montant, écart en pourcentage, cumul depuis le début de la période de référence, et une couleur selon le seuil convenu (favorable / dans la tolérance / défavorable significatif). Le seuil de coloration reste `⟦à renseigner⟧` tant qu'il n'a pas été donné par la direction.
- **Feuille de tendance** : les trois dernières périodes côte à côte pour chaque ligne significative, avec la qualification (se creuse / se referme / stable / trop tôt pour conclure).

**Note d'écarts** (Google Doc, une page) : les écarts les plus significatifs selon le classement de l'étape 3 (le nombre exact dépend de ce que révèle le classement, pas d'un chiffre fixe imposé d'avance), chacun avec son explication vérifiée dans les données ou la question posée à la bonne personne, et une mention explicite quand l'écart peut venir d'un problème de budget plutôt que de performance.

**Page de synthèse** (Slides, pour le comité) : un graphique réel contre budget sur la période, les chiffres clés du tableau, les écarts significatifs mis en couleur selon le même code que le Sheet.

Chaque chiffre affiché, dans les trois livrables, cite sa source (nom du fichier, ligne, feuille) et sa période. Un chiffre sans source ni période n'est pas publiable.

- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / `[placeholder]` ».

## Règles

1. **L'alignement précède toujours le calcul.** Tant que les périodes, catégories, unités et périmètre ne sont pas mis en correspondance et documentés, aucun écart n'est calculé.
2. **Le tableau montre tout, le commentaire ne porte que sur le seuil.** Le seuil de commentaire (montant et pourcentage) est un input de la direction, jamais une décision de la compétence, et reste `⟦à renseigner⟧` tant qu'il n'est pas donné.
3. **Une explication n'est écrite comme fait que si une donnée la montre.** Sinon, elle devient une question, formulée précisément, avec la ligne concernée et la fonction destinataire.
4. **Le budget est aussi suspect que le réel.** Tout écart spectaculaire est examiné dans les deux sens : performance réelle, ou erreur de construction budgétaire.
5. **Le classement combine montant et pourcentage.** Un pourcentage isolé sur une petite base ne détermine jamais seul l'importance d'un écart.
6. **Le mois et le cumul se lisent ensemble.** Aucun tableau ne présente l'écart du mois sans le cumul depuis le début de la période de référence.
7. **La tendance se qualifie sur au moins deux points de comparaison.** Une seule période disponible ne permet pas de dire qu'un écart se creuse ou se referme, et la compétence le dit plutôt que de trancher sur un point unique.
8. **Le contexte local n'est pas un décor.** Un calendrier métier construit sur des semaines de 4 ou 5 jours ouvrés variables selon les fêtes locales, une saisonnalité propre au secteur (récolte, rentrée scolaire, fêtes de fin d'année), une part de règlements en mobile money qui n'arrivent pas sur le compte bancaire au même rythme que les ventes enregistrées en caisse : ces éléments changent la lecture d'un écart de calendrier ou de trésorerie, et se signalent quand les données les font apparaître.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser la note ou la synthèse à un comité, modifier un budget dans un système comptable, ou informer un tiers d'un écart est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entité ou d'une période budgétaire ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites

- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun seuil de commentaire fourni** : tu produis le tableau complet et la grille de seuil vide (`⟦à renseigner⟧`), et tu ne commentes aucun écart tant que le seuil n'est pas donné : commenter selon un seuil que tu aurais choisi toi-même reviendrait à trancher une décision qui appartient à la direction.
- **Les deux fichiers ne s'alignent pas** (nomenclatures trop différentes, granularités incompatibles) : tu documentes ce qui bloque l'alignement précisément, tu proposes la correspondance que tu peux établir avec certitude, et tu marques `[à confirmer]` ce qui reste ambigu plutôt que de forcer un rapprochement douteux.
- **Le budget lui-même semble faux** (doublon, incohérence manifeste, ligne à zéro qui ne devrait pas l'être) : tu le signales explicitement dans la note, séparément des écarts de performance, avant même de chercher une explication côté réel.
- **Aucune tendance calculable** (une seule période disponible) : tu affiches l'écart de la période unique et tu écris que la tendance ne peut pas être qualifiée avec un seul point.
- **Écart qui ne trouve aucune explication vérifiable dans les données** : tu ne forces jamais une explication. La ligne reste ouverte avec sa question, adressée à la bonne fonction.
- **Source ou fichier inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** (prévision du budget suivant, analyse de rentabilité produit détaillée, audit comptable) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (diffusion, modification d'un système comptable, information d'un tiers) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux versions du budget, deux extractions du réel qui ne concordent pas) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
