---
id: Y0707
name: dictionnaire-de-donnees
description: "Documente d'où viennent les chiffres de la maison, source par source et champ par champ : quel système ou quel cahier, qui saisit, à quelle fréquence, ce que chaque champ veut dire pour le métier, ses valeurs possibles, sa qualité constatée, qui en est responsable, et quel indicateur s'en sert. Distinct du dictionnaire d'indicateurs (qui définit ce qu'on calcule) : ici on décrit la matière première. Se construit au fil des livrables, se relit avant chaque cycle de reporting, et signale ce qui n'est décrit nulle part."
bucket: B
tags: [Données, Documentation, Gouvernance, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Personne ne peut faire confiance à un chiffre dont on ne sait pas d'où il vient

## Ce qu'il faut avoir sous la main
- **La liste des endroits où la donnée vit** : logiciels, tableurs, cahiers, téléphones, formulaires, relevés reçus de tiers (banque, mobile money, plateforme).
- **Pour chacun, la personne qui saisit ou qui exporte**, et à quel rythme.
- **Un échantillon de chaque source** (export, photo de cahier, capture) pour lire les champs réels, pas les champs supposés.
- **Les indicateurs déjà définis** (`definir-un-indicateur`) pour tracer quel champ nourrit quel chiffre.

> ⚡ **Le dictionnaire n'attend pas d'être complet pour servir.** Chaque livrable qui touche une source y ajoute ses lignes ; une source non décrite s'inscrit avec `⟦à renseigner⟧` et un propriétaire à désigner, ce qui vaut mieux qu'une source oubliée.

## Process
### Étape 1, Inventorier les sources
Une ligne par source : nom courant dans la maison, type (logiciel, tableur, papier, message, relevé externe), propriétaire, fréquence de mise à jour, période couverte, mode d'accès (export, lecture directe, photo), lien ou emplacement. Les sources informelles (WhatsApp, mémoire du gérant) figurent dans la liste, c'est là que se cachent les angles morts (`ce-qui-ne-se-mesure-pas`).

### Étape 2, Décrire les champs
Pour chaque champ d'une source utile : nom tel qu'il apparaît, ce qu'il veut dire pour le métier (demandé à qui l'utilise, jamais déduit du nom), type et format attendu, unité et convention (devise, fuseau, jour d'abord ou mois d'abord), valeurs possibles s'il y a une liste, champ obligatoire ou non, qualité constatée (taux de remplissage, formats mélangés, issus de `qualite-de-la-donnee`), depuis quand il existe, ce qui a changé et quand.

### Étape 3, Tracer les usages
Quel indicateur, quel rapport, quelle automatisation lit ce champ. Un champ que rien ne lit se signale (collecte inutile) ; un indicateur qui lit un champ mal rempli se signale aussi (chiffre fragile). C'est ce croisement qui donne au dictionnaire sa valeur.

### Étape 4, Nommer les responsables et les règles
Pour chaque source, la personne qui répond quand un chiffre est douteux, et les règles de saisie en vigueur ou proposées (issues des rapports de qualité). Les décisions prises sur une définition, avec leur date, se consignent ici et ne se rouvrent pas sans nouvelle décision.

### Étape 5, Faire vivre
Relecture avant chaque cycle de reporting : nouveaux champs, champs abandonnés, changements de logiciel, changement de saisisseur. Une entrée non revérifiée depuis 90 jours se marque à revoir. Le dictionnaire est un document vivant au lien stable (`document-vivant-et-lien-stable`), jamais recréé.

## Format de sortie
- **Tableur à trois onglets** (`tableur-livrable`) : Sources, Champs, Usages ; en-têtes figés, filtres, une ligne par élément, statut de vérification et date sur chaque ligne.
- **Page de lecture** d'une page pour la direction : combien de sources, lesquelles portent les chiffres du comité, lesquelles ne sont décrites nulle part, les trois fragilités les plus coûteuses.
- **Emplacement** : dossier Livrables de la maison, référencé dans la mémoire de l'entreprise.

## Règles
1. **Le sens d'un champ se demande, il ne se déduit pas de son nom.**
2. **Une source informelle est une source** et figure dans l'inventaire.
3. **Chaque ligne porte sa date de vérification** ; sans date, la ligne vaut `⟦à vérifier⟧`.
4. **Le dictionnaire ne réécrit pas une définition d'indicateur en usage** ; il la cite et renvoie à la fiche.
5. **Un document, un lien** : on met à jour en place, on ne crée pas de version parallèle.

## Cas limites
- **Logiciel de prestataire sans documentation** : on décrit ce qu'on voit dans l'export, on marque le reste `⟦à demander au prestataire⟧`, et on écrit la demande.
- **Deux sources pour le même champ** (le stock du tableur et le stock du logiciel) : les deux figurent, avec la source de vérité désignée par la maison, ou `⟦à trancher⟧`.
- **Champ contenant des données personnelles** : signalé comme tel, avec le périmètre de partage autorisé (`donnees-personnelles-ci`).
