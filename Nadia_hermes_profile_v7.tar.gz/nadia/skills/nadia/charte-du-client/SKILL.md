---
id: Y0386
name: charte-du-client
description: "Recueille une fois pour toutes l'identité visuelle de l'entreprise cliente, logo et ses variantes, couleurs en codes exacts, polices, pied de page, mentions légales et de confidentialité, l'écrit dans la mémoire de l'entreprise et l'applique ensuite à tout document, tableur ou présentation produit, sans jamais toucher au fond ni reconstituer une couleur à l'œil. Quand la maison n'a ni logo ni charte, propose une palette qui colle à l'esprit de son métier, jamais un gris et blanc par défaut."
bucket: A
tags: [Socle, Livrables, Horizontal, Nouveau]
version: 3
maj: 2026-09-23
---

# La charte du client : que le document ressemble à la maison, pas au prestataire

> ⛔ **Contrôle avant remise, maison sans logo (23/09/2026).** Avant de rendre un livrable pour
> une maison qui n'a ni logo ni charte, vérifie que sa palette **se justifie par le métier ou
> par une pièce visuelle de la maison** (menu, enseigne, façade, photos publiées), et que le
> message dit d'où elle vient. Une palette neutre de gris et de blanc choisie faute de mieux
> ne passe pas ce contrôle : ne remets pas, reprends l'étape 0 bis.

## Ce qu'il faut avoir sous la main
- **Le logo**, dans ses versions disponibles, fond clair, fond sombre, carré (icône seule), sous la forme de fichiers ou de liens.
- **Les couleurs**, avec leurs **codes exacts** (hexadécimal ou Pantone), primaire et secondaires. Pas de description approximative (« bleu foncé »).
- **Les polices** utilisées pour les titres et pour le corps de texte, avec le nom exact.
- **Le pied de page type**, ce qui doit apparaître en bas de chaque document (nom légal, adresse, contact).
- **La mention de confidentialité** que tu utilises habituellement, si elle existe déjà.
- **Un exemple de document déjà produit** par l'entreprise (PDF, présentation), si tu en as un, c'est souvent le moyen le plus rapide de retrouver tout le reste.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un logo ou un exemple de document m'est déjà fourni, je **produis directement la fiche de charte** en marquant ce qui reste incertain (`⟦à renseigner⟧`), je ne redemande que ce qui est réellement indispensable et introuvable par déduction. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 0 (ajoutée le 21/09/2026, demande de l'utilisateur) : la charte se cherche AVANT de produire, sur le web s'il le faut

Consigne reçue le 21/09/2026 : « Assure toi d'avoir la charte, le logo et les couleurs d'une boîte avant de
produire un livrable, cherche sur le web. TOUS les livrables doivent être conforme aux chartes des entreprises
pour qui tu les produits. » Elle s'applique à chaque livrable, dès le premier, sans attendre qu'on la rappelle.

Ordre de recherche, en s'arrêtant au premier qui donne des codes exacts :
1. **La fiche en mémoire** (`memory/reference/charte-<maison>.md`) : si elle existe et a moins de 90 jours, on l'applique.
2. **Ce que le client a transmis** (charte, logo en fichier, document déjà produit par la maison).
3. **Le site officiel de la maison** : page d'accueil et feuilles de style (les couleurs les plus fréquentes du CSS,
   la police déclarée), fichier du logo (SVG de préférence : les couleurs se lisent dans le fichier). Outils : `curl`
   sur la page puis sur les `.css`, comptage des codes `#xxxxxx`, `cairosvg` pour rendre le logo en PNG sur le fond de
   la marque.
4. **Si le site refuse l'accès** (403, protection anti-robot) : le fichier du logo sur Wikimedia Commons (vérifier la
   licence sur la page du fichier) ; les couleurs se lisent dans le SVG.
5. **Les sites tiers de « palettes de marque »** ne sont pas des sources : ils se contredisent entre eux (constaté le
   21/09/2026 sur un client de test). Ils ne servent qu'à repérer un candidat, jamais à fixer un code.

Ce qui s'écrit ensuite, sans exception :
- la **fiche datée** en mémoire de référence, avec chaque source réellement ouverte et ce qui en vient ;
- dans le livrable et dans le message, **d'où viennent les codes** (« relevés sur le site public le … », « logotype
  ouvert sur Wikimedia Commons le … ») et la demande de la charte officielle pour les remplacer ;
- ce qui manque encore (`⟦à renseigner⟧` : police, pied de page, mention de confidentialité, logo avec l'emblème).

Une maison sans présence en ligne (un maquis, une boutique) n'a pas de charte à trouver : on passe à l'étape 0 bis.

### Étape 0 bis (ajoutée le 23/09/2026) : pas de logo, une palette qui ressemble au métier

Livrer « sobre » en gris et blanc pour un restaurant, c'est livrer un document qui ne
ressemble à rien de ce qu'il est : le lecteur n'y reconnaît pas sa maison. L'absence de logo
n'autorise pas l'absence d'identité. Dans l'ordre :

1. **Chercher une pièce visuelle de la maison**, même sans logo : menu, carte, enseigne,
   façade, emballage, photos publiées sur ses réseaux ou sa fiche d'établissement. Demande-la
   dans le même message que ta première question si elle n'est pas fournie. Les couleurs
   dominantes se relèvent dans le fichier (lecture des pixels d'une zone unie, pas à l'œil sur
   un écran) et s'annoncent comme « relevées sur la photo du menu du … », à valider.
2. **À défaut de toute pièce, déduire du métier** une palette proposée : ce que le métier
   évoque chez ses propres clients (pour un restaurant : les produits, la cuisine, la chaleur
   du lieu ; pour un cabinet de santé : le soin, la propreté ; pour un atelier : la matière,
   l'outil). Deux ou trois couleurs, une dominante, une d'accent, avec leurs codes.
3. **La dire pour ce qu'elle est** : « palette proposée, la maison n'a pas de charte », dans
   le livrable et dans le message, et proposer de la remplacer dès qu'une pièce arrive. Elle
   ne s'écrit pas dans la fiche de charte comme une charte officielle : la fiche la note comme
   proposition, datée.
4. **Vérifier le contraste** du texte sur chaque fond retenu, pour que la palette reste
   lisible.

La règle 2 (« une couleur non sourcée ne se reconstitue jamais à l'œil ») reste entière : elle
interdit d'inventer la couleur d'une maison qui en a une. Elle n'interdit pas de proposer une
palette à une maison qui n'en a aucune, à condition de l'annoncer comme proposition.
### Étape 1 : Vérifier ce qui existe déjà en mémoire

Avant de demander quoi que ce soit, tu regardes si une charte a déjà été enregistrée pour cette entreprise. Si oui, tu l'affiches et tu demandes seulement ce qui manque ou ce qui a changé, tu ne fais jamais recommencer l'exercice depuis zéro. C'est le piège le plus coûteux du métier : une charte qu'on redemande à chaque livrable revient exactement au problème que le client croyait résoudre en prenant un outil plutôt qu'en réexpliquant sans fin à chaque prestataire.

### Étape 2 : Recueillir ce qui manque, élément par élément

Pour chaque pièce manquante, tu poses la question précise plutôt que de deviner :
- **Logo**, quelles variantes existent, et pour quel usage chacune (fond clair, fond sombre, format carré pour icône ou favicon).
- **Couleurs**, le code exact, jamais une description. Si le client ne donne qu'un nom de couleur ou une capture d'écran floue, tu ne complètes pas par un code plausible : tu marques `⟦à renseigner⟧` et tu demandes le fichier source (charte graphique, export du logo, site web). Un bleu approximatif est pire qu'un document en noir et blanc assumé, il se voit, côte à côte avec le vrai logo, et il abîme la crédibilité qu'il devait construire.
- **Polices**, le nom exact, plus une police de repli si celle d'origine n'est pas disponible dans l'outil de production (les documents doivent rester lisibles même sans la police premium).
- **Pied de page et mentions**, la formule exacte de mention légale, et la mention de confidentialité si elle existe. Si aucune des deux n'existe encore, tu le signales : ce sont les deux éléments qu'on regrette une fois qu'un document a déjà circulé sans elles.

Si un exemple de document existant est fourni, tu en extrais logo, couleurs et police par observation directe plutôt que de tout redemander, mais tu ne devines jamais un code couleur à partir d'un rendu écran non calibré : tu le marques à confirmer et tu proposes de vérifier sur le fichier source.

### Étape 3 : Écrire la fiche de charte en mémoire, datée

Tu consolides tout dans une fiche unique, versionnée avec la date de dernière mise à jour. Cette fiche devient la référence pour tous les livrables futurs de cette entreprise, tous parcours confondus. Une charte qui vit dans une conversation ponctuelle plutôt que dans la mémoire de l'entreprise n'a rien résolu, elle se reperdra à la prochaine session.

### Étape 4 : Les gabarits par type de livrable

Au-delà des couleurs et du logo, tu tiens un gabarit par type de document récurrent, note de comité, compte rendu de réunion, présentation, tableur de suivi, pour que la structure (ordre des sections, page de garde, disposition du pied de page) soit la même d'une fois sur l'autre. Un client reconnaît sa maison autant à l'agencement qu'aux couleurs.

### Étape 5 : Appliquer la charte sans toucher au fond

Quand tu produis ou habilles un document, tu n'interviens que sur la forme : couleurs, logo, police, pied de page, mise en page. Un chiffre, une réserve d'audit, une recommandation ou une conclusion ne se reformulent ni ne se nuancent au passage, la charte est une couche visuelle, jamais une occasion de retravailler le contenu produit par une autre skill ou par l'utilisateur. Si tu repères une incohérence de fond en habillant le document, tu la signales séparément, tu ne la corriges pas toi-même.

### Étape 6 : Signaler ce qui manque encore

À chaque livrable produit, tu ajoutes une ligne courte disant si la charte appliquée est complète ou si certains éléments restent `⟦à renseigner⟧` (une couleur secondaire jamais donnée, un gabarit pas encore défini pour ce type de document). Le document part quand même, mais personne ne doit croire que la charte est plus complète qu'elle ne l'est.

## Format de sortie
- **Livrable principal** : la fiche de charte en mémoire, logo et ses variantes avec leur usage, couleurs primaires et secondaires en codes hexadécimaux, polices de titre et de corps avec solution de repli, pied de page type, mentions de confidentialité, et les gabarits par type de livrable.
- **Livrable secondaire, à chaque production** : le document (PDF, tableur, présentation) habillé selon la charte, accompagné d'une ligne signalant ce qui manquait encore.
- **Structure** : Markdown clair pour la fiche ; le format natif attendu (PDF, XLSX, PPTX) pour les livrables habillés.
- **Longueur** : la fiche de charte tient sur une page. Elle ne s'alourdit pas de commentaires esthétiques ; elle liste des faits (codes, noms, usages).
- **Règle 0 invention** : aucun code couleur, aucune police, aucune mention légale n'est inventée. Ce qui n'est pas fourni reste `⟦à renseigner⟧`.

## Règles
1. **La charte est une question de crédibilité, pas d'esthétique.** Un document aux couleurs du prestataire signale au lecteur, avant lecture, que le travail vient de l'extérieur. Tu le rappelles si un livrable est sur le point de sortir sans charte appliquée.
2. **Une couleur non sourcée ne se reconstitue jamais à l'œil.** Sans code exact, tu marques `⟦à renseigner⟧` et tu demandes le fichier source. Un bleu approximatif à côté du vrai logo est un dégât visible, pas un compromis acceptable.
3. **La charte se recueille une fois, elle se relit ensuite.** Tu vérifies toujours la mémoire de l'entreprise avant de redemander quoi que ce soit ; tu ne fais jamais recommencer l'exercice à un client qui l'a déjà fait.
4. **La charte habille, elle ne corrige jamais le fond.** Couleurs, logo, police, mise en page, jamais un chiffre, une réserve ou une recommandation. Si le fond te semble à revoir, tu le signales à part.
5. **Confidentialité et date ne s'oublient jamais** sur un document destiné à circuler à l'extérieur de l'entreprise. Ce sont les deux éléments qu'on regrette une fois le document parti.
6. **Chaque livrable dit ce qui manquait à la charte**, même quand la charte est presque complète. Une charte partielle appliquée sans le dire fait croire à une complétude qui n'existe pas.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; publier, diffuser ou envoyer un livrable à un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** La charte d'une entreprise ne fuite jamais vers un autre dossier ou une autre entreprise cliente traitée dans la même conversation.

## Cas limites
- **Ni logo ni charte, et aucune pièce visuelle** : palette proposée déduite du métier (étape 0 bis), annoncée comme telle, jamais un gris et blanc neutre par défaut.
- **Aucune charte n'existe encore**, tu recueilles ce qui est disponible, tu marques `⟦à renseigner⟧` le reste, et tu produis quand même le livrable demandé, avec la mention explicite de ce qui manque.
- **Un exemple de document est annoncé mais non joint**, tu le signales avant de continuer, tu ne fais pas comme si tu l'avais lu.
- **Couleur donnée par description plutôt que par code** (« notre bleu », capture d'écran non calibrée), tu ne devines pas, tu marques à confirmer et tu demandes le fichier source.
- **Deux documents fournis se contredisent** sur une couleur, une police ou une mention, tu exposes les deux versions et tu demandes l'arbitrage, tu ne tranches pas seul.
- **Type de livrable sans gabarit défini**, tu appliques la charte générale (logo, couleurs, police, mentions) et tu signales qu'aucun gabarit spécifique n'existe encore pour ce type de document, en proposant de le créer.
- **Demande d'aller au-delà de la forme** (« reformule cette réserve pour qu'elle passe mieux »), tu rappelles que la charte n'habille pas le fond, tu orientes vers la skill ou la personne compétente pour ce changement.
- **Document destiné à circuler à l'extérieur sans mention de confidentialité définie**, tu le signales avant de livrer, tu ne l'ajoutes pas de ton propre chef si aucune formule n'a été validée.
- **Action sortante demandée** (diffusion, envoi, publication), tu prépares le document habillé et tu t'arrêtes pour validation humaine.
- **Demande hors périmètre** (créer un logo, concevoir une identité visuelle de zéro), tu le dis en une phrase et tu orientes vers la compétence ou le prestataire adapté.

## Historique
- v3, 23/09/2026 : maison sans logo, étape 0 bis (pièce visuelle de la maison d'abord, sinon palette proposée d'après le métier, annoncée comme proposition) et contrôle avant remise en tête qui refuse le gris et blanc par défaut, séance Sync agents training.
