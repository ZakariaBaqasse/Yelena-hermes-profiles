---
id: Y0278
name: webhook-validator
description: "Valide, nettoie et normalise le payload JSON reçu d'un webhook d'automatisation (ex. notification de fin de réunion Fireflies via Make) avant qu'il n'entre dans le reste du pipeline : contrôle l'URL, formate date et durée, et sépare l'email du candidat des emails des recruteurs, sans jamais traiter le contenu métier ni inventer de donnée absente."
bucket: C
tags: [Agent Tools]
version: 1
maj: 2026-08-26
---

# Webhook Validator

## Ce qu'il faut avoir sous la main
- `url`, le lien vers l'enregistrement de la réunion ;
- `title`, le titre de la réunion (utilisé pour détecter l'email du candidat) ;
- `date` et `durée`, si disponibles ;
- `emails_participants`, la liste des emails des participants (format chaîne séparée par virgules, ou tableau d'objets `{nom, email, role}`).


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un brief ou un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant clairement tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
Champ : `url`

Format attendu : URL de l'enregistrement de l'outil de transcription (ex. `https://app.fireflies.ai/view/{meeting-id}`).

Checks :
- Non nul et non vide ;
- Respecte le motif attendu de l'outil source (ex. `^https:\/\/app\.fireflies\.ai\/view\/.+$` pour Fireflies) ;
- Longueur > 40 caractères.

Si invalide → **STOPPER**.

### Étape 2 : Formatage de la date (non bloquante)

Champ : `date` (format ISO 8601).

Convertir en format lisible français : « JJ mois AAAA ».

Si absent ou invalide → `"Date à définir"`.

### Étape 3 : Formatage de la durée (non bloquante)

Champ : `durée` (float en minutes).

Arrondir à l'entier le plus proche.

- Si < 60 → `"[N] min"`
- Si ≥ 60 → `"[X]h [Y]min"`
- Si absent → `"Durée non disponible"`

### Étape 4 : Traitement des emails (bloquante)

Description : liste **exacte et complète** des emails des destinataires (RH, managers, recruteurs).

Formats acceptés en entrée :
- **Chaîne simple** (`"email1@domain.com,email2@domain.com"`) → obligation de split dans un tableau en supprimant les doublons ;
- **Tableau d'objets** (`[{ "nom": "Prénom Nom", "email": "email@domain.com", "role": "Fonction" }]`).

Traitement obligatoire :
1. Split par virgule `,` ;
2. Trim (supprimer les espaces avant/après) ;
3. Lowercase ;
4. Supprimer les doublons ;
5. Valider le format de chaque email (regex : `.+@.+\..+`) ;
6. **Détection de l'email du candidat** :
   - Extraire le nom du candidat depuis `title` (partie avant le premier tiret `-`) ;
   - Décomposer en tokens : prénom, nom, particules (ignorer les tokens de moins de 2 caractères) ;
   - Normaliser les tokens : minuscule, sans accents ;
   - Pour chaque email, vérifier si la partie locale (avant le `@`) contient un ou plusieurs tokens du nom ;
   - L'email avec le plus de tokens matchés = `emails_candidat` ;
   - Tous les autres = `emails_recruteurs`.

Cas limites :
- Aucun match → tous les emails passent en `emails_recruteurs` + warning : « Email candidat non détecté automatiquement » ;
- Plusieurs emails matchent → prendre celui avec le plus de tokens correspondants ; si égalité → warning + prendre le premier match.

⚠️ **Règle critique** : l'email du candidat **ne doit jamais** recevoir le compte-rendu interne. `emails_recruteurs` = destinataires de l'email final. `emails_candidat` = conservé pour information uniquement, jamais utilisé comme destinataire d'un envoi interne.

Si `emails_recruteurs` est vide après filtrage → **STOPPER**. Erreur : « Aucun email recruteur valide détecté ».

## Format de sortie
- **Livrable** : le format exact est défini **à chaque étape du Process** ci-dessus (blocs et tableaux fournis), les suivre tels quels.
- **Support** : Markdown ; réponse directe d'abord, détails ensuite ; pas de remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Info manquante → la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
Les emails des destinataires sont fournis par le webhook. Ce sont les **seuls** emails valides à utiliser.

Interdictions :
- Extraire des emails depuis une transcription ou un autre document ;
- Déduire des emails depuis des noms ou des entreprises ;
- Compléter une liste partielle.

Si `emails_participants` est absent ou vide → **STOPPER immédiatement**.

### Contraintes

- ❌ **Jamais inventer** un email, une URL ou une donnée absente du payload, toute donnée manquante suit la règle de l'étape concernée (stop bloquant ou valeur par défaut non bloquante), jamais une supposition.
- ❌ Ne jamais traiter le contenu métier (résumé, analyse) : cette skill valide et normalise, elle ne synthétise rien.
- 🔒 L'email du candidat ne doit jamais atterrir dans la liste des destinataires d'un envoi interne.
- 🧾 Toute violation bloquante (URL invalide, emails absents, aucun recruteur valide) stoppe le pipeline avec un objet d'erreur structuré, jamais un objet partiel silencieux.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.

## Détails complémentaires
### Sortie : succès

```json
{
  "status": "valid",
  "title": "[tel que reçu]",
  "url": "[telle que reçue]",
  "date": "[formatée en français]",
  "duree": "[formatée]",
  "emails_participants": {
    "recruteurs": ["[liste nettoyée et dédoublonnée]"],
    "candidat": ["[email détecté via matching nom]"]
  },
  "warnings": ["[liste si applicable]"]
}
```

### Sortie : erreur

```json
{
  "status": "error",
  "etape": "[nom étape échouée]",
  "champ": "[champ concerné]",
  "message": "[description précise]",
  "valeur_recue": "[valeur ou null]"
}
```

→ **Stopper le pipeline immédiatement**, ne rien transmettre à l'étape suivante.
