---
id: Y0702
name: concevoir-une-experimentation
description: "Conçoit un test avant qu'il soit lancé (nouveau prix, nouvelle offre, nouveau canal, changement d'horaire, nouveau fournisseur) et exploite un test déjà fait : hypothèse écrite, groupe ou période de comparaison, durée et taille nécessaires, ce qu'on mesure et ce qu'on ne touche pas pendant le test, seuil de décision fixé par la direction avant de voir les résultats, puis lecture honnête de ce que le test prouve et ne prouve pas. Vaut pour tout métier, pas seulement le marketing."
bucket: B
tags: [Données, Expérimentation, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Un test dont on n'a pas écrit la règle de décision avant n'est pas un test

## Ce qu'il faut avoir sous la main
- **Le changement qu'on veut essayer** et la décision qu'il prépare (garder, généraliser, abandonner).
- **L'indicateur qui tranchera**, avec sa définition (`definir-un-indicateur`), et sa valeur habituelle sur les semaines ou mois précédents.
- **Ce qu'on peut contrôler** : peut-on faire le changement sur un site, un groupe de clients, une plage horaire, et pas sur les autres ? Ou seulement avant / après ?
- **La durée qu'on est prêt à attendre** et ce que coûte le test s'il échoue.
- **Ce qui va bouger en même temps** (saison, pluie, fête, promotion d'un concurrent, congés) : ce sont les explications concurrentes qu'il faudra écarter.

> ⚡ **Un test déjà fait s'exploite quand même.** Si on te donne les chiffres après coup, tu dis d'abord ce que le montage permet de conclure (souvent moins que ce qu'on espère), puis tu livres l'analyse avec ses limites, et le protocole propre pour la prochaine fois.

## Process
### Étape 1, Écrire l'hypothèse comme une phrase falsifiable
« Passer le garba à 700 F ne fait pas baisser la recette garba journalière de plus de ⟦X⟧ % » ou « le rappel WhatsApp à J+3 augmente le taux de retour des ardoises ». Une hypothèse qui ne peut pas être contredite par les chiffres n'est pas une hypothèse. La direction donne le ⟦X⟧ : c'est le seuil à partir duquel elle change d'avis, et il s'écrit avant les résultats.

### Étape 2, Choisir le montage le plus solide possible
Du plus au moins probant :
1. **Comparaison simultanée** : deux groupes ou deux sites en même temps, le changement sur l'un seulement, l'affectation tirée au sort si possible.
2. **Alternance** : le changement un jour sur deux, ou une semaine sur deux, pour que la saison touche les deux.
3. **Avant / après avec témoin** : le changement sur un site, un autre site comparable laissé tel quel.
4. **Avant / après seul** : le plus faible ; toute autre chose qui a changé en même temps devient une explication concurrente.
Tu proposes le meilleur montage faisable et tu écris ce que chaque cran de moins fait perdre.

### Étape 3, Dimensionner
Durée et effectif se calculent à partir de la variabilité habituelle de l'indicateur et de l'écart qu'on veut voir (`statistiques-pour-decider`). « Deux semaines » n'est pas une durée, c'est une habitude ; s'il faut six semaines pour voir un effet de 10 %, tu le dis avant, pas après.

### Étape 4, Geler le reste
Pendant le test, ce qui n'est pas testé ne bouge pas : pas de promotion, pas de changement de serveuse, pas de nouvelle carte. Ce qui bouge quand même se note avec sa date (pluie, coupure, fête). C'est ce journal qui permettra de lire les résultats.

### Étape 5, Lire les résultats sans complaisance
La différence, son intervalle, la comparaison au seuil décidé à l'étape 1, puis les explications concurrentes une par une : écartée, non écartée, impossible à écarter. Un test perdu se dit aussi clairement qu'un test gagné ; c'est ce qui donne de la valeur aux tests gagnés.

## Format de sortie
- **Protocole de test** (une page) : hypothèse, indicateur, montage, durée, ce qu'on gèle, règle de décision signée par la direction, journal à tenir.
- **Fiche de relevé** (`collecte-terrain`) si le test demande une saisie que personne ne fait aujourd'hui.
- **Rapport de test** (gabarit `note-d-analyse`) : résultat, intervalle, verdict par rapport à la règle, explications concurrentes, recommandation, et ce que le test n'a pas pu dire.

## Règles
1. **La règle de décision s'écrit avant les résultats**, avec le seuil de la direction, jamais après.
2. **Un avant / après sans témoin ne prouve pas grand-chose**, et le rapport l'écrit en tête, pas en note de bas de page.
3. **Un test qu'on arrête dès qu'il « a l'air » de marcher** est un test truqué sans le vouloir ; la durée se fixe avant.
4. **Tu ne lances rien toi-même** : changer un prix, une offre, un message client est une décision de la maison, tu prépares et tu attends.
5. **Ce qui a bougé pendant le test se liste**, même si c'est gênant pour la conclusion.

## Cas limites
- **Impossible de garder un témoin** (une seule boutique, un seul prix pour tous) : alternance par jours ou par semaines, sinon avant / après avec la saison de l'an dernier comme repère, en disant que c'est faible.
- **Effet attendu très petit** : le test coûterait plus qu'il ne rapporte ; tu le chiffres et tu proposes de ne pas tester.
- **Le résultat contredit ce que le dirigeant voulait entendre** : tu le dis d'abord, tu le documentes ensuite (`dire-les-choses-difficiles`).
