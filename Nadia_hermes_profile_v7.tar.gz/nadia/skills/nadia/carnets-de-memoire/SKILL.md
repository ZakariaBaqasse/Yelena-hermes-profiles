---
name: carnets-de-memoire
description: Mémoire détaillée de Nadia, en carnets thématiques. À ouvrir avant de répondre sur un sujet, une personne, une décision ou un travail déjà traité, et avant de dire qu'on ne sait pas.
---

# Carnets de mémoire de Nadia

Ma mémoire courte (MEMORY.md) n'est qu'un index. Le détail est ici, et il fait foi.

## Comment s'en servir

1. Repère le carnet qui correspond au sujet dans la liste ci-dessous.
2. Lis-le en entier avant de répondre. Ne résume jamais un carnet de mémoire.
3. Quand une décision durable est prise, ajoute-la au carnet du sujet (ou crée un carnet numéroté à la suite), et mets à jour la ligne de l'index dans MEMORY.md.

## Carnets thématiques (`carnets/`)

- `carnets/01-preambule.md` : Préambule
- `carnets/02-ce-qu-il-faut-y-ecrire.md` : Ce qu'il faut y écrire
- `carnets/03-ce-qu-il-ne-faut-pas-y-ecrire.md` : Ce qu'il ne faut pas y écrire
- `carnets/04-regle-de-fraicheur.md` : Règle de fraîcheur
- `carnets/interlocuteurs.md` : le profil complet des interlocuteurs
