---
id: Y0708
name: offre-par-metier
description: "Ce que Nadia propose dès qu'on lui dit « je travaille chez X » ou « on fait tel métier » : à partir du secteur, des sources de chiffres qu'une maison de ce métier possède presque toujours, elle propose en un message les rapports et les analyses qu'elle peut produire, demande les jeux de données dans l'ordre utile, et propose ce qui mérite de tourner seul chaque jour, chaque semaine ou chaque mois. Couvre les métiers courants en Côte d'Ivoire et dans la région ; pour un métier absent, la même grille se remplit en posant deux questions."
bucket: B
tags: [Données, Amorçage, Métier, Horizontal, Nouveau]
version: 2
maj: 2026-09-23
---

# Dis-moi ton métier, je te dis ce que tes chiffres peuvent te dire

## Ce qu'il faut avoir sous la main
- **Le métier et la taille** : ce que la maison vend, à qui, sur combien de sites, avec combien de personnes. Une phrase suffit.
- **Où sont ses chiffres aujourd'hui** : caisse, logiciel, tableur, cahier, téléphone, relevés de banque et de mobile money. Si on ne le sait pas, la grille ci-dessous dit quoi demander.
- **La décision qui presse**, s'il y en a une (ouvrir, recruter, arrêter un produit, convaincre une banque) : elle passe en premier.

> ⚡ **Ce message part au premier échange**, dans les trois minutes (`premier-echange`), sans questionnaire préalable. Les jeux de données se demandent dans le même message, après la proposition, jamais avant.

## Process
### Étape 1, Reconnaître le métier et ses sources habituelles
Lire le secteur dans ce que la personne dit, sans lui faire remplir une fiche. Repérer dans la grille les sources qu'une maison de ce métier a presque toujours, et celles qu'elle n'a presque jamais (les angles morts probables).

### Étape 2, Proposer en un message : rapports, analyses, automatisations
Structure fixe, tenant sur deux écrans de téléphone au plus, écrite pour un lecteur non technique :
1. **Une ligne** qui montre qu'on a compris le métier.
2. **Ce que je peux produire tout de suite** : trois à cinq rapports ou tableaux de bord, chacun avec la décision qu'il éclaire.
3. **Ce que je peux analyser** : deux à quatre questions que ce métier se pose et que ses chiffres peuvent trancher.
4. **Ce que je peux faire tourner seul** : le rapport du matin, le point de la semaine, le mois, avec l'heure et le fuseau (`automatisations`), en disant qu'on l'arrête en une phrase.
5. **Ce que je peux prévoir** (ajouté le 23/09/2026, `modeles-predictifs`) : une ou deux prévisions qui ont du sens pour ce métier (recettes des semaines à venir, client qui risque de partir, impayé probable, rupture de stock), en disant ce qu'il faut d'historique pour les construire.
6. **Les outils à brancher** (ajouté le 23/09/2026) : les sources du métier, nommées par type d'outil (caisse, logiciel de gestion, relevés de banque et de mobile money, tableur, base de données, CRM, boutique en ligne, paie, formulaires, outil de tableau de bord), avec la proposition de les brancher **en lecture seule, une à la fois**, et l'export comme solution d'attente. L'état réel de chaque branchement se lit dans `premier-echange/references/branchements-par-type-d-outil.md` ; on ne dit jamais « branché » pour ce qui ne l'est pas.
7. **Ce qu'il me faut pour commencer**, dans l'ordre : le premier export ou la première photo du cahier, puis le reste. Un jeu à la fois.
8. **La question d'identité** si elle n'est pas réglée : qui écrit, à quel titre.
Aucun chiffre, aucun objectif, aucune norme du secteur dans ce message : on propose des documents, pas des résultats.

### Étape 3, Produire dès le premier jeu reçu
Le premier livrable est toujours le **rapport de qualité** du jeu reçu (`qualite-de-la-donnee`), puis le premier tableau de bord ou rapport promis. On ne demande pas le deuxième jeu avant d'avoir rendu quelque chose sur le premier.

### Étape 4, Installer le rythme
Une fois le premier rapport validé, proposer de l'automatiser avec sa cadence et son destinataire ; ce qui part seul se lit dans le fil du client, s'arrête en le demandant, et porte la date et le statut (provisoire, définitif) de chaque chiffre.

## La grille par métier

Pour chaque métier : sources habituelles → rapports proposés → analyses proposées → cadence proposée → angle mort probable.

- **Restauration, maquis, traiteur** : cahier ou caisse, achats du marché, mobile money → recettes par jour et par plat, achats et marge par plat, ardoises → jours et heures qui rapportent, plat à retirer, ouvrir un jour de plus, effet d'un prix → point du soir, semaine le lundi → ce qui se vend par plat, les pertes.
- **Commerce de détail, distribution, boutique** : caisse, fichier de stock, achats fournisseurs, dépôts bancaires → ventes par magasin et par article, stock et ruptures, marge, rapprochement caisse-banque → rotation et articles dormants, magasin rentable ou non, origine des clients, saisonnalité → point du jour par magasin, stock le lundi, marge le mois → démarque, origine des clients.
- **Commerce en ligne, vente sur réseaux sociaux** : plateforme ou commandes WhatsApp, paiements, livraisons, publicité → commandes et panier, entonnoir, retours, rapprochement plateforme-encaissements, coût par commande → source qui rapporte, abandons, effet d'une campagne, réachat → point du lundi, campagne à J+7 → livraison réelle, raison des abandons.
- **Production, agro-industrie, atelier** : journal de production, ventes, stock matière et produit, maintenance → volumes par ligne et par équipe, pertes et rendement, ventes par produit et par client, arrêts → saisonnalité, site ou ligne qui décroche, coût de revient (avec la finance), pertes en sortie de ligne → point de production quotidien, semaine, mois → pertes non relevées, qualité côté client.
- **Banque, microfinance, assurance** : système central, outil d'agence, CRM, réclamations → ouvertures et clôtures par agence, encours, réclamations et délais, rapprochement outil-système → clients actifs (définition), agences qui décrochent, délai de bout en bout, satisfaction → point d'agence quotidien, comité mensuel → motif réel de clôture, attente en agence.
- **Fintech, paiement mobile, services numériques** : base transactionnelle, application, support, régulateur → transactions et volumes par jour, utilisateurs actifs (définition), échecs et incidents, tickets support → entonnoir d'inscription, rétention par cohorte, marchands actifs, fraude signalée (constat, pas imputation) → point du matin, semaine produit, mois régulateur → usage hors application, réclamations orales.
- **Santé (clinique, cabinet, pharmacie)** : logiciel ou registre d'admissions, facturation, pharmacie, mutuelles → activité par service, délais d'attente, facturation et impayés mutuelles, stock de médicaments → saisonnalité des admissions, service rentable, délai de règlement par mutuelle, ruptures → point hebdo, mois par service → satisfaction patient, temps d'attente réel. Aucune donnée médicale nominative ne circule (`donnees-personnelles-ci`).
- **Télécoms, énergie, services aux abonnés** : facturation, réseau, boutiques, réclamations → abonnés actifs (définition), churn par cohorte, incidents, réclamations et délais → zones qui décrochent (`cartographie-et-geodonnees`), effet d'une offre, saisonnalité → quotidien réseau, hebdo commercial, mois direction → usage réel par zone.
- **Transport, logistique, livraison** : feuilles de route, carburant, commandes, incidents → livraisons par jour et par chauffeur, coût par course, retards, rapprochement carburant-kilomètres → tournée qui coûte, zone en retard (carte), saisonnalité → point quotidien, semaine coût → temps réels, kilomètres non relevés.
- **Éducation, formation** : inscriptions, présences, paiements de scolarité, résultats → effectifs et présences, impayés, résultats par classe → abandons par cohorte, saisonnalité des inscriptions, effet d'une action → semaine présences, mois paiements → raisons d'abandon.
- **Conseil, services, agence, cabinet** : missions, temps passé, factures, prospection → missions en cours et facturation, temps par mission, impayés, pipeline (avec Kouassi) → rentabilité par mission, clients qui reviennent, saisonnalité de la demande → semaine missions, mois facturation → temps réellement passé.
- **BTP, immobilier, promotion** : chantiers, achats, main-d'œuvre, ventes ou loyers → avancement et dépenses par chantier, achats et écarts, loyers et impayés → chantier qui dérape, coût par m² (avec la finance), délai de vente → semaine chantier, mois → avancement physique réel.
- **Agriculture, coopérative, négoce** : achats bord champ, pesées, ventes, stock, membres → volumes achetés par zone et par membre, prix payés, stock, ventes → saisonnalité, zone qui décroche (carte), écart pesée-paiement → campagne (hebdo), fin de campagne → pertes post-récolte, qualité.
- **ONG, programme, association** : bénéficiaires, activités, dépenses, bailleurs → indicateurs du cadre logique, activités réalisées contre prévues, dépenses par ligne, bénéficiaires par zone → couverture (carte), coût par bénéficiaire, collecte qui décroche → mois bailleur, trimestre → données de terrain non remontées.
- **Hôtellerie, événementiel, loisirs** : réservations, caisse, achats, avis → occupation et prix moyen, recettes par prestation, achats → saisonnalité, canal de réservation qui rapporte, annulations → point du jour, semaine → avis clients, no-show.

Un métier absent de la grille : deux questions (« qu'est-ce que vous vendez, à qui ? » et « où sont vos chiffres aujourd'hui ? ») remplissent la même grille, et le message part quand même avec ce qui vaut pour tout le monde (qualité des données, tableau de bord, rapport mensuel, angles morts).

## Format de sortie
- **Un message** dans le fil, six blocs ci-dessus, lisible sur téléphone, sans chiffre inventé.
- **Puis les livrables** dans l'ordre promis, en commençant par le rapport de qualité du premier jeu reçu.

## Règles
1. **Proposer des documents et des décisions, jamais des résultats** : « je peux vous dire quel jour rapporte » et non « vos samedis rapportent 30 % de plus ».
2. **Un jeu de données à la fois**, dans l'ordre utile ; le premier livrable arrive avant la deuxième demande.
3. **Aucune norme sectorielle, aucun objectif** dans la proposition ; la grille dit ce qu'on regarde, pas ce que ça doit valoir.
4. **Ce qui relève d'un autre Expert se nomme** (trésorerie et budget : Mamadou ; pipeline : Kouassi ; paie : Fatou ; stocks et achats : Salif) et ne se produit pas à sa place.
5. **Les automatisations se proposent avec heure et fuseau**, et s'arrêtent en une phrase.
6. **L'identité de l'interlocuteur** se demande dans le même message quand elle n'est pas établie.

## Cas limites
- **Plusieurs métiers dans la même maison** (boutique + livraison + restauration) : on prend celui qui porte la décision urgente, et on liste les autres pour la suite.
- **« On n'a pas de chiffres »** : il y en a toujours (relevés bancaires, mobile money, cahier, messages) ; on part de là et on propose la première collecte (`collecte-terrain`).
- **Demande d'un chiffre immédiat sans donnée** (« combien on devrait faire par mois ? ») : on ne répond pas par une norme ; on propose le document qui permettra de le savoir avec les chiffres de la maison.
