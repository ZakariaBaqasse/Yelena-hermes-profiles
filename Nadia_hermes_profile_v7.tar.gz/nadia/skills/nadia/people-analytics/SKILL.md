---
id: Y0205
name: people-analytics
description: "Calcule le tableau de bord RH d'un studio ou d'une startup de portefeuille, effectifs, turnover, time-to-hire, parité/diversité, coût par recrutement, ancienneté, uniquement à partir des données réellement fournies, avec alertes de tendance et signalement explicite de toute donnée manquante ou échantillon trop faible."
bucket: C
tags: [Ressources Humaines]
version: 1
maj: 2026-08-26
---

# People Analytics

## Ce qu'il faut avoir sous la main
- Le **périmètre** : le studio seul, ou une startup nommée du portefeuille
- La **période** à analyser (et, si tu veux un delta, une période de comparaison)
- Les **données disponibles** : effectifs, entrées/sorties, dates de recrutement, genre, rémunération… collées dans le message, ou le tableur/la base à lire

## Process
Calcule, à partir des **données réellement fournies** :
- **Effectifs** (headcount, ETP), répartition par équipe/startup/séniorité.
- **Turnover** = départs / effectif moyen sur la période (distingue subi/volontaire si l'information est disponible).
- **Time-to-hire** = délai médian/moyen entre le sourcing et la signature, croise `[skill à brancher : talent-pipeline-manager]` si le suivi du pipeline de recrutement est géré par ailleurs.
- **Parité / diversité** : répartition par genre par niveau (et écart éventuel), toujours **agrégée**, jamais nominative.
- **Coût par recrutement**, **taux de transformation** du funnel de recrutement, **ancienneté moyenne**, **rétention à 12 mois**.

Montre la **formule** et la **période** de chaque KPI. Si une donnée manque → marque « n/d », ne l'invente jamais.

### Étape 2 : Lecture & alertes

- Tendance vs période précédente (↑/↓) et vs un repère raisonnable.
- 🔴 **Alertes** : turnover anormal, time-to-hire qui dérive, déséquilibre de parité par niveau, concentration de départs sur une équipe.
- Hypothèses prudentes sur les causes (à confirmer, jamais des conclusions hâtives) ; attention aux **petits échantillons**, une petite structure a de petits effectifs, un seul départ peut faire bouger fortement les pourcentages.

### Étape 3 : Restitution

- **Tableau de KPIs** + **synthèse en 5 points** + top 3 priorités d'action.
- Si un outil de visualisation interactive est disponible, propose des graphes (barres/lignes) ; sinon, structure les données pour un export.
- Option : génération d'un fichier rapport.

## Format de sortie
- **Livrable** : Calcule le tableau de bord RH d'un studio ou d'une startup de portefeuille, effectifs, turnover, time-to-hire, parité/diversité, coût par recrutement.
- **Structure** : Markdown clair, titres, listes, et tableaux quand c'est pertinent ; réponse directe d'abord (answer-first), détails ensuite.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] », jamais présentée comme réelle.

## Règles
- ❌ **Jamais inventer un chiffre** : ne calcule que sur les données fournies ; signale explicitement les manques et la fragilité des petits échantillons.
- 🔐 **Agrégé et anonyme** : aucune donnée nominative sensible en sortie ; pas de statistique sur un sous-groupe trop petit (risque de ré-identification).
- 🎯 **Indicateurs actionnables**, jamais de vanity metrics.
- 🌐 **FR/EN** : réponds dans la langue de la demande, et garde toujours le nom exact de l'entité tel que fourni par l'utilisateur (ne l'invente ni ne l'abrège).
- 🔗 **Résous d'abord la datasource avant de calculer** : si le périmètre est une startup nommée dans un portefeuille multi-entités, résous `[datasource à brancher : registre central des startups]` pour obtenir **ses propres** données RH avant tout calcul, jamais un chiffre réutilisé depuis une autre entité traitée plus tôt dans la conversation.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).
- **Produis, ne bloque pas.** Avec le contexte fourni, tu produis directement le livrable en étiquetant clairement tes hypothèses (`[hypothèse : …]`) plutôt que de t'arrêter pour réclamer. Tu ne demandes une donnée que si elle est réellement indispensable et impossible à supposer raisonnablement ; sinon tu avances avec un exemple représentatif explicitement marqué comme tel.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
