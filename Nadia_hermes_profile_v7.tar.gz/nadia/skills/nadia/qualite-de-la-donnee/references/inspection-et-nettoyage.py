#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inspection d'un jeu de données et nettoyage AVEC TRACE (pandas).

Structure reprise des scripts de nettoyage de portfolios publics (STCybersec, SaifulIslamDS,
relus le 21/09/2026), avec deux différences qui tiennent aux règles du poste :
  1. on ne supprime rien en silence : chaque ligne écartée ou modifiée va dans un JOURNAL
     (ligne, champ, valeur avant, valeur après, règle, date) ;
  2. une valeur aberrante se SIGNALE (colonne drapeau), elle n'est ni coupée ni plafonnée.

Usage :
    ~/.venv-office/bin/python inspection-et-nettoyage.py <fichier.csv|.xlsx> [--feuille NOM]
Sort :  <nom>_inspection.md, <nom>_propre.csv, <nom>_journal.csv, <nom>_signalements.csv
Puis : adapter les RÈGLES ci-dessous au jeu (elles sont volontairement minimales).
"""
import sys, re, datetime as dt
import pandas as pd
import numpy as np

AUJ = dt.date.today().isoformat()


# ── 1. Lecture ───────────────────────────────────────────────────────────────
def lire(chemin, feuille=None):
    if chemin.lower().endswith((".xlsx", ".xlsm", ".xls")):
        return pd.read_excel(chemin, sheet_name=feuille or 0, dtype=str)
    return pd.read_csv(chemin, dtype=str, sep=None, engine="python")   # sep=None devine ; ou ,


# ── 2. Profil par champ ──────────────────────────────────────────────────────
def forme(v):
    """Une signature de format : chiffres → 9, lettres → A, le reste tel quel."""
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "vide"
    s = str(v).strip()
    if s == "":
        return "vide"
    return re.sub(r"[A-Za-zÀ-ÿ]", "A", re.sub(r"\d", "9", s))[:12]


def profil(df):
    lignes = []
    for c in df.columns:
        col = df[c]
        vides = col.isna().sum() + (col.astype(str).str.strip() == "").sum()
        formes = col.map(forme).value_counts().head(5)
        lignes.append({
            "champ": c, "lignes": len(col), "vides": int(vides),
            "taux_remplissage": round(100 * (1 - vides / len(col)), 1),
            "valeurs_distinctes": int(col.nunique(dropna=True)),
            "formats_rencontres": " | ".join(f"{k} ({v})" for k, v in formes.items()),
            "exemples": " | ".join(map(str, col.dropna().astype(str).str.strip().replace("", np.nan).dropna().unique()[:3])),
        })
    return pd.DataFrame(lignes)


def doublons(df, cles=None):
    """Sans clé fiable : lignes strictement identiques = doublons PROBABLES. Avec clé : CERTAINS."""
    if cles:
        d = df[df.duplicated(subset=cles, keep=False)].sort_values(cles)
        return "certains", d
    d = df[df.duplicated(keep=False)].sort_values(list(df.columns))
    return "probables", d


def rapport_inspection(nom, df, prof, nature_doublons, dbl):
    md = [f"# Inspection du jeu « {nom} »", "", f"- Lignes : {len(df)} · Colonnes : {df.shape[1]} · Inspecté le {AUJ}",
          f"- Doublons {nature_doublons} : {len(dbl)} lignes concernées", "", "## Profil par champ", "",
          prof.to_markdown(index=False), "",
          "## Ce que ce rapport ne dit pas", "",
          "- le sens métier de chaque champ (à demander à qui le remplit) ;",
          "- l'unité et la convention de date (à faire déclarer, jamais devinées) ;",
          "- si une valeur bizarre est une erreur ou un fait (à faire qualifier)."]
    return "\n".join(md)


# ── 3. Nettoyage tracé ───────────────────────────────────────────────────────
class Journal:
    def __init__(self):
        self.lignes, self.signalements = [], []

    def corrige(self, df, masque, champ, apres, regle):
        """Applique une correction et la trace ligne par ligne."""
        for idx in df.index[masque]:
            self.lignes.append({"ligne": int(idx) + 2, "champ": champ, "avant": df.at[idx, champ],
                                "apres": apres(df.at[idx, champ]) if callable(apres) else apres,
                                "regle": regle, "date": AUJ, "statut": "appliquée sur la copie de travail"})
        df.loc[masque, champ] = df.loc[masque, champ].map(apres) if callable(apres) else apres

    def signale(self, df, masque, champ, motif):
        """Marque sans modifier : une colonne drapeau + une ligne de signalement."""
        drapeau = f"signal_{champ}"
        if drapeau not in df.columns:
            df[drapeau] = ""
        df.loc[masque, drapeau] = motif
        for idx in df.index[masque]:
            self.signalements.append({"ligne": int(idx) + 2, "champ": champ, "valeur": df.at[idx, champ],
                                      "motif": motif, "statut": "signalée, à qualifier par le métier"})


def nettoyer(df):
    """RÈGLES MINIMALES, à adapter au jeu. Rien n'est supprimé : les exclusions sont des drapeaux."""
    j = Journal()
    df = df.copy().astype(object)      # colonnes mixtes texte/nombre pendant le nettoyage

    # espaces et casse : correction de forme, tracée
    for c in df.columns:
        m = df[c].notna() & (df[c].astype(str) != df[c].astype(str).str.strip())
        j.corrige(df, m, c, lambda v: v.strip(), "espaces en début/fin retirés")

    # dates : on essaie jour-d'abord ; ce qui ne se lit pas est SIGNALÉ (pas jeté)
    for c in [c for c in df.columns if re.search(r"date|jour", c, re.I)]:
        lu = pd.to_datetime(df[c], dayfirst=True, errors="coerce")   # convention à faire déclarer
        j.signale(df, df[c].notna() & lu.isna(), c, "date illisible")
        df[c + "_lue"] = lu.dt.date

    # montants : « 2.000 », « 2 000 F », « 500 FCFA » → nombre ; tracé
    for c in [c for c in df.columns if re.search(r"montant|prix|total|qt", c, re.I)]:
        def num(v):
            s = str(v).replace("FCFA", "").replace("F", "").replace(" ", "").replace(" ", "")
            s = re.sub(r"\.(?=\d{3}(\D|$))", "", s).replace(",", ".")
            try:
                return float(s)
            except ValueError:
                return np.nan
        lu = df[c].map(num)
        m = df[c].notna() & (df[c].astype(str) != lu.astype(str)) & lu.notna()
        j.corrige(df, m, c, lambda v: num(v), "montant converti en nombre (F/FCFA/séparateurs retirés)")
        j.signale(df, df[c].notna() & lu.isna(), c, "montant illisible")
        df[c] = lu
        if lu.notna().any():
            p99 = lu.quantile(0.99)
            j.signale(df, lu > p99, c, f"au-delà du 99e centile ({p99:,.0f}) : à qualifier, pas à couper")
            j.signale(df, lu < 0, c, "négatif")
            j.signale(df, lu == 0, c, "nul")

    # doublons stricts : drapeau, jamais de suppression automatique
    m = df.duplicated(keep="first")
    j.signale(df, m, df.columns[0], "ligne strictement identique à une autre (doublon probable)")
    return df, j


# ── 4. Intégrité entre tables (si plusieurs fichiers) ────────────────────────
def orphelins(faits, ref, cle_faits, cle_ref):
    """Lignes de faits sans correspondance dans le référentiel : à signaler, jamais à jeter."""
    return faits[~faits[cle_faits].isin(ref[cle_ref])]


# ── 5. Exécution ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    chemin = sys.argv[1]
    feuille = sys.argv[sys.argv.index("--feuille") + 1] if "--feuille" in sys.argv else None
    nom = re.sub(r"\.[^.]+$", "", chemin.split("/")[-1])
    brut = lire(chemin, feuille)
    prof = profil(brut)
    nature, dbl = doublons(brut)
    open(f"{nom}_inspection.md", "w").write(rapport_inspection(nom, brut, prof, nature, dbl))
    propre, j = nettoyer(brut)
    propre.to_csv(f"{nom}_propre.csv", index=False)
    pd.DataFrame(j.lignes).to_csv(f"{nom}_journal.csv", index=False)
    pd.DataFrame(j.signalements).to_csv(f"{nom}_signalements.csv", index=False)
    print(f"{len(brut)} lignes · {len(j.lignes)} corrections tracées · {len(j.signalements)} signalements · "
          f"doublons {nature} : {len(dbl)}")
