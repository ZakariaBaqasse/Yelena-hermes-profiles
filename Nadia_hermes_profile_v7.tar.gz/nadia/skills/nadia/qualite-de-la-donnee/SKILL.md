---
id: Y0434
name: qualite-de-la-donnee
description: "Diagnostique la qualité d'un jeu de données d'entreprise avant toute analyse : taux de remplissage par champ, doublons et identités multiples séparés en certains et probables, formats mélangés, dates ambiguës, montants dans deux devises, valeurs aberrantes non supprimées mais qualifiées. Produit le rapport de qualité, le jeu redressé avec sa trace de correction complète, et les règles de saisie qui empêchent le défaut de revenir, sans jamais fusionner deux identités ni corriger sans laisser de trace."
bucket: B
tags: [Données, Qualité, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Avant d'analyser, regarder si la donnée est vraie

## Ce qu'il faut avoir sous la main
- **Le jeu de données** lui-même (fichier, export, accès à la base) ou un échantillon représentatif s'il est trop volumineux.
- **Ce que ce jeu doit servir à produire** ensuite : tableau de bord, facturation, relance client, reporting réglementaire. Ça change ce qui est critique à corriger en priorité.
- **Les champs que tu sais déjà fragiles**, si tu en as une idée : doublons connus, champ de devise mal renseigné, dates saisies à la main.
- **L'unité et la convention attendues** pour les champs sensibles : devise (franc CFA, euro, les deux), format de date (jour/mois/année ou l'inverse). Si tu ne sais pas, dis-le, je le signale comme point à trancher plutôt que de deviner.
- **Qui doit arbitrer** les cas de doublons probables et les valeurs aberrantes, si ce n'est pas toi.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si le jeu de données est fourni mais que le contexte d'usage manque, tu **produis directement le rapport** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu marques les champs dont l'unité ou la convention n'est pas déclarée comme point à trancher, jamais deviné.

## Process
### Étape 1 : Cartographier le jeu de données avant tout jugement
Pour chaque champ : taux de remplissage (combien de lignes sont vides ou nulles), formats effectivement rencontrés (une date en trois écritures différentes est un signal, pas un détail), nombre de valeurs distinctes, et cohérence du type (un champ montant qui contient parfois du texte).

C'est l'étape que la plupart des analyses sautent, parce qu'elle ne produit rien d'intéressant à montrer. C'est exactement pour ça qu'elle vient en premier : le contrôle de qualité s'écrit même quand il est bon, parce que « j'ai vérifié et c'est propre » est une information, pas un non-événement.

### Étape 2 : Détecter les doublons et les identités multiples
Un même client peut apparaître sous trois orthographes, deux numéros de téléphone et une raison sociale différente selon qui l'a saisi. Deux clients différents peuvent aussi porter le même nom. Construis des règles de rapprochement (numéro de téléphone identique, numéro de contribuable identique, combinaison nom et localisation) et classe chaque paire trouvée en deux colonnes strictement séparées :
- **Rapprochement certain** : l'identifiant qui ne trompe pas (numéro de contribuable, numéro de téléphone unique) coïncide.
- **Rapprochement probable** : la ressemblance est forte (nom proche, même quartier, même activité) mais aucun identifiant fiable ne tranche.

Tu ne fusionnes jamais un rapprochement probable. Tu le soumets à validation humaine avec les deux fiches côte à côte. Fusionner à tort casse un historique ; ne pas fusionner un doublon réel ne fait que laisser un chiffre légèrement gonflé, le risque n'est pas symétrique.

### Étape 3 : Traiter les champs sensibles à l'ambiguïté : dates et devises
Une date écrite en chiffres seuls est ambiguë tant que la convention (jour d'abord ou mois d'abord) n'est pas déclarée. Un montant peut être en francs CFA ou en euros, et la parité fixe entre les deux monnaies fait que l'erreur ne saute pas aux yeux par l'ordre de grandeur comme elle le ferait avec une devise flottante. Un même champ peut mélanger les deux sans qu'aucune alerte visuelle ne se déclenche.

Tu exiges que l'unité et la convention soient déclarées par l'équipe avant de traiter le champ. Tant qu'elles ne le sont pas, le champ reste marqué `⟦à renseigner⟧` et tu ne devines pas à partir du contexte, même si une valeur te semble évidente.

### Étape 4 : Qualifier les valeurs aberrantes, ne jamais les supprimer
Une commande dix fois supérieure aux autres est un signal, pas un verdict. Elle peut être une vraie commande exceptionnelle (un client institutionnel, une commande de fin d'année) ou une erreur de saisie (un zéro de trop). Tu la signales avec sa ligne complète et son contexte, tu la classes par ordre d'écart, et tu la fais qualifier par quelqu'un qui connaît le métier. Une valeur aberrante supprimée sans qualification est une donnée réelle qui disparaît, ou une erreur qui reste : dans les deux cas, une décision a été prise sans que personne ne la voie.

### Étape 5 : Construire le jeu redressé et sa trace de correction
Chaque correction appliquée (champ vidé rempli par déduction documentée, doublon certain fusionné, format de date uniformisé) laisse quatre éléments dans la trace : la **valeur avant**, la **valeur après**, la **règle appliquée**, et la **date de la correction**. Sans cette trace, le jeu redressé n'est pas reproductible, et le jour où quelqu'un retrouve la valeur d'origine dans un export ancien, la confiance dans tout le travail s'effondre d'un coup.

Le jeu redressé et sa trace sont deux objets distincts, jamais fusionnés dans le même fichier de façon à masquer l'un ou l'autre.

### Étape 6 : Remonter à la source, pas seulement au symptôme
Un défaut qui revient chaque mois n'est pas un défaut de donnée, c'est un défaut de collecte : un formulaire qui laisse le champ libre au lieu d'une liste de valeurs, une consigne de saisie absente ou mal comprise, un champ obligatoire qui ne l'est pas techniquement. Le rapport se termine toujours par la ou les règles de saisie à instaurer en amont, avec, pour chacune, ce qu'elle empêche précisément.

## Format de sortie
- **Livrable 1, le rapport de qualité** : tableau par champ (taux de remplissage, formats rencontrés, valeurs distinctes, anomalies avec leur nombre et des exemples réels tirés du jeu, pas des exemples inventés) ; liste des doublons certains et probables, en deux tableaux séparés ; liste des valeurs aberrantes signalées avec leur ligne complète, en attente de qualification.
- **Livrable 2, le jeu redressé** : accompagné de sa trace de correction complète (avant, après, règle, date), livrée comme fichier ou table séparée du jeu lui-même.
- **Livrable 3, les règles de saisie** : ce qui doit changer en amont (formulaire, liste de valeurs, consigne), avec pour chacune le défaut précis qu'elle empêche.
- **Structure** : Markdown clair, answer-first (le constat chiffré d'abord : combien de lignes touchées, combien de champs concernés), tableaux pour les données répétitives.
- **Règle 0 invention** : aucun taux, aucun seuil de tolérance, aucune règle de rapprochement n'est décidée à ta place quand elle relève d'un choix métier. Un seuil de tolérance (par exemple à partir de quel taux de remplissage un champ est jugé inexploitable) est un input de l'équipe, marqué `⟦à renseigner⟧` tant qu'il n'est pas donné.

## Règles
1. **Le contrôle de qualité passe toujours avant l'analyse**, jamais après, et son résultat s'écrit même quand il ne révèle rien : « j'ai vérifié, le champ est propre » est une ligne du rapport, pas une étape qu'on saute parce qu'elle n'a rien trouvé.
2. **Aucune correction sans trace.** Valeur avant, valeur après, règle appliquée, date : les quatre sont présents ou la correction n'est pas appliquée.
3. **Le rapprochement certain et le rapprochement probable ne se mélangent jamais.** Seul le certain (identifiant fiable qui coïncide) peut être fusionné automatiquement ; le probable est toujours soumis à validation humaine, présenté fiche contre fiche.
4. **Une valeur aberrante se signale, elle ne se supprime pas.** Elle est qualifiée par quelqu'un qui connaît le métier avant qu'une décision (garder, corriger, exclure) soit prise.
5. **L'unité et la convention d'un champ sensible (devise, date) sont déclarées par l'équipe, jamais devinées.** Tant qu'elles ne le sont pas, le champ reste marqué `⟦à renseigner⟧`, y compris quand une valeur semble évidente au premier regard.
6. **Le rapport ne s'arrête jamais au symptôme.** Un défaut récurrent doit se conclure par une règle de saisie en amont, sinon le même travail de nettoyage recommence le mois suivant sur le même champ.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un rapport et un jeu redressé de travail ; écraser la base de production, fusionner définitivement des identités, ou supprimer des lignes est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'un jeu de données ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Jeu de données trop volumineux pour être lu en entier** : tu travailles sur un échantillon représentatif clairement défini (taille, méthode de tirage) et tu le signales explicitement dans le rapport, plutôt que de présenter les résultats comme portant sur l'ensemble.
- **Champ sensible sans convention déclarée** (devise, date) : tu le marques `⟦à renseigner⟧` partout où il apparaît et tu poursuis le reste du rapport, tu ne devines jamais.
- **Rapprochement probable en grand nombre** : tu ne fusionnes rien, tu livres la liste triée par degré de ressemblance pour que l'arbitrage humain aille du plus évident au plus incertain.
- **Valeur aberrante sur un champ critique pour la facturation ou la paie** : tu la signales en priorité en tête du rapport, elle ne se traite pas comme une anomalie parmi d'autres.
- **Référentiel absent** (pas de liste officielle des clients, des produits ou des unités) : tu le dis explicitement, ça limite la fiabilité de toute déduplication, et tu le mentionnes dans les règles de saisie à instaurer.
- **Source ou connecteur inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un champ comme vérifié sans l'avoir lu.
- **Demande de fusion immédiate** sur des doublons probables : tu rappelles la règle 3, tu prépares la comparaison fiche contre fiche, tu t'arrêtes pour validation humaine.
- **Le jeu de données sert à une déclaration réglementaire ou à la paie** : tu signales que l'enjeu dépasse la simple qualité analytique et que la validation humaine doit inclure la fonction compétente (comptabilité, RH), pas seulement le demandeur.
- **Demande hors périmètre** (analyse ou interprétation des données, pas leur qualité) : tu le dis en une phrase, tu livres le contrôle de qualité qui est ton champ, et tu orientes vers la compétence d'analyse appropriée.

## Références
- `references/inspection-et-nettoyage.py` : profil par champ (formats rencontrés, remplissage, distinctes), doublons certains ou probables, nettoyage avec journal ligne par ligne (avant, après, règle, date) et signalements au lieu de suppressions ; `~/.venv-office/bin/python inspection-et-nettoyage.py <fichier>`.
