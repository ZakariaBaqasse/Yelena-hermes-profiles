---
id: Y0439
name: rapport-mensuel-de-direction
description: "Produit le rapport que la direction lit chaque mois : ce qui s'est passé, ce qui s'écarte de ce qui était attendu, pourquoi, et ce qu'il faut décider. Organise le document autour des décisions plutôt que des services, écrit un commentaire d'écart qui explique au lieu de décrire, distingue le mesuré de l'estimé, et impose une structure reproductible d'un mois sur l'autre, sans jamais combler un trou de donnée par une estimation qui aurait l'apparence d'un résultat."
bucket: B
tags: [Données, Reporting, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Le rapport mensuel qui fait décider quelque chose

## Ce qu'il faut avoir sous la main
- **Le périmètre et la période** : quel mois, quelles entités ou quels domaines sont couverts (ventes, trésorerie, effectifs, achats, autre).
- **Les données brutes du mois**, domaine par domaine, avec leur source (extraction comptable, tableur de suivi, remontée terrain).
- **Le rapport du mois précédent**, pour la comparaison et pour vérifier que la structure et les définitions n'ont pas bougé.
- **Le référentiel de définitions** : comment chaque indicateur est calculé, ce qui compte comme mesuré, provisoire, estimé.
- **Les objectifs ou le budget**, s'il y en a. S'il n'y en a pas, je ne les invente pas : la comparaison se fait alors contre le mois précédent et contre l'année précédente.
- **Les sujets que la direction attend déjà**, s'il y en a, pour que la liste des points à arbitrer ne parte pas de zéro.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process

### Étape 1 : Vérifier la reproductibilité avant de commencer

Avant de toucher aux chiffres du mois, compare la structure demandée au rapport du mois précédent : mêmes domaines, même périmètre, mêmes définitions d'indicateur. Un rapport dont l'ordre, le contenu ou le mode de calcul bougent chaque mois ne se compare plus à rien, et c'est justement la comparaison qui porte l'information, pas la photo isolée d'un mois.

Si une définition change (méthode de calcul d'un indicateur, périmètre d'une entité qui s'ajoute ou se retire, changement de source), tu le signales explicitement dans le rapport du mois où ça arrive, avec la raison. Tu ne le fais jamais taire pour que le rapport ait l'air plus lisse.

Piège local à surveiller : le calendrier de clôture n'est pas homogène. Une entité d'Abidjan et un point de vente de l'intérieur ne remontent pas leurs données au même rythme, à cause de la distance et du temps de transmission (souvent WhatsApp, souvent un tableur envoyé en fin de journée). Si le mois précédent incluait telle entité avec un décalage de collecte et que ce mois-ci elle est à l'heure, ce n'est pas un écart de performance, c'est un écart de méthode. Tu le distingues.

### Étape 2 : Consolider chaque indicateur avec son statut

Pour chaque indicateur, tu portes quatre informations, jamais trois : la valeur, la période qu'elle couvre, la comparaison (mois précédent, même mois l'an dernier, budget si fourni), et le **statut** : mesuré, provisoire, estimé, ou indisponible.

- **Mesuré** : issu d'une source arrêtée et vérifiable.
- **Provisoire** : arrêté à une date antérieure à la clôture définitive, susceptible de bouger. C'est fréquent sur les charges de personnel et les provisions fiscales, dont le montant définitif ne se stabilise qu'après les déclarations CNPS et DGI du mois, ou sur les encaissements mobile money dont le règlement par l'agrégateur peut accuser un décalage de quelques jours sur la fin de période.
- **Estimé** : reconstitué par une méthode explicite (extrapolation, moyenne des jours ouvrés), la méthode se cite.
- **Indisponible** : la donnée n'existe pas encore pour ce mois. Tu écris pourquoi, et à quelle date elle est attendue.

L'erreur qui coûte cher ici : présenter un provisoire comme s'il était définitif. Le mois suivant, l'écart entre le provisoire et le chiffre arrêté ressurgit sans explication, et la direction perd confiance dans le rapport entier plutôt que dans la seule ligne concernée. Tu marques le statut visible, dans le tableau, pas seulement dans une note de bas de page.

### Étape 3 : Calculer les écarts et les trier par ce qui mérite l'attention

Calcule l'écart de chaque indicateur contre sa référence (mois précédent, même mois l'année passée, budget si fourni). Classe ensuite ces écarts selon un seuil de significativité : ce seuil est une décision de l'équipe, il reste `⟦à renseigner⟧` tant qu'il n'est pas donné, et en son absence tu listes tous les écarts en les triant par ampleur plutôt que d'en éliminer par défaut.

Un rapport qui traite un écart de rien du tout avec la même longueur qu'un écart qui change la trésorerie du mois noie le signal. Le tri sert exactement à ça : réserver le commentaire détaillé aux écarts qui comptent, et laisser le reste en tableau.

### Étape 4 : Écrire le commentaire qui explique, pas celui qui décrit

Pour chaque écart significatif, le commentaire répond à une seule question : **pourquoi**, pas **combien**. « Les ventes ont baissé de tant » n'est pas un commentaire, c'est la lecture du tableau à voix haute. Un commentaire correct nomme la cause et ce qui la fonde : une rupture de stock constatée sur tel point de vente, un décalage de facturation, un effet de saisonnalité documenté (rentrée scolaire, fête, saison des pluies qui ralentit la logistique vers l'intérieur), une perturbation d'un canal d'encaissement.

Si la cause n'est pas encore connue, tu l'écris ainsi : « cause non identifiée à ce jour, à vérifier auprès de [service] avant le [date] ». C'est un résultat honnête, pas un trou à combler par une hypothèse qui aurait l'air d'un fait. Tu distingues dans le texte la cause **documentée** (quelqu'un l'a vérifiée, une source l'atteste) de la cause **plausible mais non vérifiée** : les deux peuvent apparaître, jamais mélangées sans étiquette.

### Étape 5 : Transformer chaque écart significatif en décision à prendre

Un rapport qui ne demande rien ne produit rien. Chaque écart significatif se termine par une proposition, même quand elle consiste à ne rien changer ce mois-ci et à observer le suivant. La proposition porte une option et sa contrepartie : ce qu'on gagne, ce qu'on risque ou ce qu'on sacrifie en la retenant.

Ces propositions alimentent la **liste des points à arbitrer**, tenue à part du corps du rapport, pour que la direction puisse la parcourir sans rouvrir les tableaux détaillés. Chaque point porte : le sujet, l'option proposée, sa contrepartie, et qui doit trancher.

### Étape 6 : Construire la page d'ouverture, puis le détail

La première page ne contient que trois choses : les faits marquants du mois (en quelques lignes), les écarts jugés significatifs (avec leur cause quand elle est connue), et les décisions attendues. Tout le reste (le détail par domaine, indicateur par indicateur, avec valeur, période, comparaison et statut) vient après, consultable mais pas imposé à la lecture.

Un rapport de trente pages n'est pas lu, il est feuilleté, et ce qui compte finit noyé. La discipline de longueur n'est pas cosmétique : elle conditionne si le document sert à quelque chose ce mois-ci.

## Format de sortie
- **Livrable 1, le rapport mensuel** : page d'ouverture (faits marquants, écarts significatifs, décisions attendues), puis détail par domaine avec pour chaque indicateur sa valeur, sa période, sa comparaison et son statut (mesuré, provisoire, estimé, indisponible).
- **Livrable 2, la note de commentaire d'écart** : cause par cause, avec ce qui la fonde, séparant explicitement documenté et plausible non vérifié.
- **Livrable 3, la liste des points à arbitrer** : chaque point avec l'option proposée, sa contrepartie, et qui tranche.
- **Structure** : Markdown clair, answer-first (la page d'ouverture avant le détail). Tableaux pour les indicateurs, texte court pour les commentaires.
- **Longueur** : la page d'ouverture tient sur une page. Le rapport complet reste proportionné au nombre de domaines couverts, sans remplissage.
- **Les seuils de significativité et les objectifs ou cibles sont un input**, pas une production : ils restent `⟦à renseigner⟧` tant que l'entreprise ne les a pas donnés.
- **Règle 0 invention** : aucune donnée chiffrée, cause ou cible inventée. Une information manquante se marque `[à confirmer]` ou `indisponible, attendue le [date]`.

## Règles
1. **Un commentaire explique, il ne décrit pas.** Reformuler le tableau en phrases n'est pas un commentaire d'écart. Tu nommes la cause et ce qui la fonde, ou tu dis qu'elle n'est pas encore connue.
2. **La structure ne bouge pas d'un mois sur l'autre sans le dire.** Tout changement de périmètre, de définition ou d'ordre se signale explicitement dans le rapport du mois où il intervient, avec la raison.
3. **Mesuré et estimé ne se mélangent jamais sans étiquette.** Chaque indicateur porte son statut visible dans le tableau, pas dans une note à part qu'on ne lit pas.
4. **Chaque écart significatif se termine par une proposition**, même quand elle consiste à ne rien changer. Un rapport qui ne demande rien ne produit rien.
5. **Une donnée indisponible reste indisponible.** Elle se marque avec la raison et la date attendue, jamais comblée par une estimation qui aurait l'apparence d'un résultat.
6. **Le contexte local n'est pas un décor.** Le calendrier de clôture CNPS et DGI, les délais de règlement mobile money, le décalage de collecte entre Abidjan et l'intérieur expliquent souvent pourquoi un chiffre est provisoire plutôt qu'arrêté. Tu le dis quand ça change la lecture de l'écart, pas par réflexe.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser le rapport, l'envoyer à la direction ou l'archiver comme version officielle est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entité ou d'un domaine ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun rapport du mois précédent (première édition)** : tu proposes une structure, tu la marques comme référence de départ, et tu le signales explicitement pour que le mois suivant s'y compare.
- **Objectifs ou budget non fournis** : tu ne fabriques aucune cible. La comparaison se limite au mois précédent et à l'année précédente, et tu le dis.
- **Seuil de significativité non fourni** : il reste `⟦à renseigner⟧`. En attendant, tu listes tous les écarts triés par ampleur plutôt que d'en filtrer arbitrairement.
- **Un provisoire du mois précédent est arrêté différemment ce mois-ci** : tu le signales comme une révision, tu montres l'écart entre le provisoire et le définitif, tu ne le glisses pas en silence.
- **Donnée introuvable** : tu le dis explicitement, avec la raison si elle est connue et la date attendue, et tu poursuis sur le reste.
- **Source ou connecteur inaccessible** : tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre** (prévision, budget prévisionnel, plan d'action détaillé) : tu le dis en une phrase, tu traites ce qui relève du rapport mensuel, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (diffusion, envoi à la direction, publication) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux extractions donnent des valeurs différentes pour le même indicateur) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
