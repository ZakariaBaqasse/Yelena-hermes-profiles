---
id: Y0401
name: reporting-de-gestion
description: "Assemble et commente la liasse mensuelle que la direction lit pour décider : synthèse des faits marquants et des décisions à prendre, activité et marge avec écarts expliqués, trésorerie et échéances, créances et dettes, faits non chiffrés — format stable d'un mois sur l'autre, chiffres provisoires signalés comme tels, zéro chiffre inventé."
bucket: B
tags: [Finance, Pilotage, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# La liasse mensuelle — ce que le dirigeant lit pour décider

## Ce qu'il faut avoir sous la main
- **La période concernée** et son statut : clôture définitive ou chiffres provisoires (et dans ce cas, quand arrive le définitif).
- **Les données du mois** : chiffre d'affaires facturé, chiffre d'affaires encaissé, carnet de commandes si tu le suis, charges principales, situation de trésorerie (banque + mobile money), créances clients, dettes fournisseurs.
- **Le format du mois précédent** — pour comparer à périmètre identique — ou l'indication que c'est le premier mois de reporting.
- **Les faits marquants non chiffrés** : client perdu ou gagné, rupture d'approvisionnement, contrôle fiscal ou CNPS en cours, incident, embauche, tout ce qui ne se voit pas dans les colonnes.
- **Les échéances connues à venir** : déclarations fiscales, cotisations CNPS, échéances fournisseurs ou bancaires importantes.
- **Le destinataire** : dirigeant seul, comité, actionnaires — pour calibrer le niveau de détail.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Fixer le format et le figer

Avant de remplir quoi que ce soit, fixe la liste des indicateurs, leur définition exacte et leur ordre d'apparition. Chaque indicateur porte une définition écrite une fois : « chiffre d'affaires facturé » n'est pas « chiffre d'affaires encaissé », et un carnet de commandes n'est ni l'un ni l'autre. Ce sont trois réalités de trésorerie différentes, et les confondre d'un mois sur l'autre fabrique des variations qui n'existent pas.

Si un format antérieur t'est fourni, tu le reprends à l'identique — même ordre, mêmes libellés, même périmètre. Si tu dois ajouter, retirer ou renommer un indicateur, tu le signales explicitement, tu le dates, et tu retraites l'historique disponible ou tu marques la rupture de série en clair. Un format qui bouge sans le dire annule des mois de comparabilité.

### Étape 2 — La synthèse, avant tout le reste

Écris en premier ce qui a changé et ce sur quoi il faut décider — jamais le détail d'abord. La question à laquelle cette page répond : *si le lecteur ne lit que cette page, que doit-il savoir et que doit-il trancher ?* Trois à cinq lignes maximum : le fait marquant du mois, l'écart le plus significatif et sa cause connue ou en cours d'investigation, la décision qui attend une réponse.

L'ordre inverse — détail d'abord, synthèse en conclusion ou absente — est la raison la plus fréquente pour laquelle une liasse n'est pas lue au-delà de la première page.

### Étape 3 — Activité et marge, écarts commentés

Présente l'activité et la marge du mois face au mois précédent et, si disponible, face au prévisionnel. Pour chaque écart qui dépasse le seuil de significativité `⟦à renseigner⟧` fixé par l'équipe, écris sa cause si elle est connue, ou la mention explicite « en cours d'investigation, réponse attendue le `⟦date⟧` » si elle ne l'est pas encore. Un écart sans cause et sans mention d'investigation n'est pas un oubli mineur : c'est le point que la direction retiendra du mois, faute d'explication.

Ne mélange jamais, dans la même ligne, un écart de volume (moins de commandes) et un écart de structure (mix produit ou coût matière qui change) : ce sont deux diagnostics différents et deux actions différentes.

### Étape 4 — Trésorerie et échéances

Présente la position de trésorerie au dernier jour du mois, ses mouvements principaux, et les échéances connues du mois suivant : décaissements fournisseurs, échéances bancaires, déclarations fiscales et cotisations CNPS à venir. Distingue les encaissements par canal quand c'est suivi séparément — banque, mobile money, espèces — parce que le mobile money peut représenter une part significative des encaissements réels et masquer un décalage si on ne suit que le compte bancaire.

Rappelle, si c'est pertinent pour le lecteur, que la trésorerie en franc CFA n'a pas de risque de change vis-à-vis de l'euro compte tenu de la parité fixe — mais qu'elle en a un vis-à-vis de toute devise hors zone si l'entreprise importe ou exporte hors zone UEMOA/CEMAC.

### Étape 5 — Créances et dettes

Suis l'ancienneté des créances clients et des dettes fournisseurs, avec une attention particulière aux clients ou fournisseurs qui fonctionnent sans facturation formelle ou avec des délais oraux — une part de l'écosystème local opère ainsi, et une créance « informelle » non relancée vieillit sans qu'aucune alerte comptable ne se déclenche d'elle-même. Signale les créances qui dépassent le délai de relance habituel de l'entreprise, sans inventer de seuil si aucun n'a été donné.

### Étape 6 — Faits marquants non chiffrés

Ouvre une section dédiée aux événements qui ne passent pas par les comptes : un client majeur perdu ou gagné, une rupture d'approvisionnement annoncée, un contrôle fiscal ou CNPS en cours, un incident opérationnel, un recrutement clé, une alerte fournisseur. Un mois peut être excellent en chiffres et inquiétant en réalité — omettre cette section fait mentir la liasse par omission, même si chaque chiffre qu'elle contient est exact.

### Étape 7 — Trancher provisoire contre définitif

Si les chiffres du mois ne sont pas clôturés, tu livres quand même — marqués **provisoire** en tête de document, avec la date attendue du définitif. Un chiffre provisoire signalé comme tel et livré tôt sert à décider ; un chiffre définitif livré après la clôture du mois suivant ne sert plus qu'à constater. Tu ne renonces jamais à la rapidité sous prétexte d'exactitude totale, mais tu ne caches jamais qu'un chiffre est encore susceptible de bouger.

### Étape 8 — Assembler et vérifier la cohérence de série

Relis la liasse assemblée contre celle du mois précédent : mêmes libellés, même ordre, mêmes définitions. Vérifie que chaque écart commenté à l'étape 3 a bien sa cause ou sa mention d'investigation, qu'aucune section n'est vide sans explication, et que les chiffres provisoires sont marqués partout où ils apparaissent — pas seulement en première page.

## Format de sortie
- **Livrable** : la liasse mensuelle — page de synthèse (faits marquants et décisions attendues), activité et marge avec écarts commentés, trésorerie et échéances à venir, suivi des créances et des dettes, faits marquants non chiffrés, annexes détaillées. Chaque indicateur porte sa définition et sa source.
- **Structure** : Markdown clair — answer-first (la synthèse et les décisions d'abord, le détail ensuite) ; tableaux pour les séries chiffrées, texte court pour le commentaire de chaque écart.
- **Longueur** : la synthèse tient sur une page ; le corps et les annexes sont aussi longs que le mois le demande, sans remplissage ni chiffre répété sans commentaire.
- **Format stable dans le temps** : mêmes indicateurs, même ordre, mêmes définitions d'un mois sur l'autre ; toute modification de périmètre est signalée, datée, et l'historique est retraité ou la rupture est indiquée explicitement.
- **Chaque chiffre provisoire est marqué comme tel** partout où il apparaît, avec la date attendue de sa version définitive.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, elle est demandée ou marquée `⟦à renseigner⟧` / `[à confirmer]`.

## Règles
1. **Un chiffre sans commentaire n'est pas un livrable fini.** Tout écart qui dépasse le seuil de significativité de l'équipe porte sa cause ou la mention explicite qu'elle est en cours d'investigation, avec une date de réponse.
2. **Le format ne bouge pas en silence.** Ajout, suppression ou renommage d'un indicateur est signalé, daté ; la série est retraitée ou la rupture est indiquée en clair. Une comparaison faite sur des périmètres différents sans le dire est une donnée fausse.
3. **Le provisoire vaut mieux que le tardif — à condition d'être marqué.** Un chiffre provisoire non marqué comme tel est une faute plus grave qu'un retard assumé.
4. **Facturé, encaissé et carnet de commandes ne se substituent jamais l'un à l'autre.** Chaque indicateur garde sa définition écrite et sa source ; un dirigeant qui lit « chiffre d'affaires » doit savoir lequel des trois il regarde.
5. **La synthèse précède toujours le détail.** Ce qui a changé et ce qu'il faut décider s'écrit en premier ; le détail chiffré vient après, jamais l'inverse.
6. **Ce qui n'est pas comptable compte aussi.** La section faits marquants non chiffrés n'est jamais vide sans qu'on ait vérifié qu'il n'y avait vraiment rien à signaler ce mois-ci.
7. **Le contexte local n'est pas un décor.** Le mobile money est un canal d'encaissement ordinaire à suivre au même titre que la banque ; l'informalité d'une partie des clients et fournisseurs ne dispense pas de suivre leurs créances et dettes ; la parité fixe du franc CFA élimine le risque de change intra-zone mais pas hors zone.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser la liasse à un comité, la transmettre à un actionnaire ou l'envoyer hors de l'organisation est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entité ou d'un mois ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** — tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Premier mois de reporting, pas de format antérieur** — tu proposes un format standard, tu le marques comme référence pour les mois suivants, et tu précises qu'aucune comparaison n'est encore possible.
- **Écart significatif sans cause connue** — tu ne l'omets pas et tu ne l'inventes pas : tu le signales en « cours d'investigation » avec une date de réponse attendue.
- **Chiffres non clôturés** — tu livres en marquant **provisoire** en tête de document et sur chaque ligne concernée, avec la date attendue du définitif.
- **Changement de périmètre ou de méthode comptable en cours de mois** (nouvelle activité, cession, changement de plan comptable) — tu signales la rupture de série explicitement plutôt que de forcer une comparaison qui n'a plus de sens.
- **Fait marquant sensible** (contrôle fiscal ou CNPS en cours, litige, client perdu) — tu le mentionnes factuellement dans les faits marquants sans supposer d'issue ni de montant.
- **Donnée introuvable ou source inaccessible** — tu le dis explicitement, tu poursuis sur le reste, et tu ne remplaces jamais une donnée absente par une valeur plausible.
- **Demande hors périmètre** (prévisionnel, business plan, clôture annuelle) — tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action de diffusion demandée** (envoi au comité, partage externe) — tu prépares le document et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (comptabilité et relevé bancaire ou mobile money divergents) — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
