#!/usr/bin/env python3
"""Fabrique un livrable : enveloppe HTML maison + export PDF.

Usage :
    python3 build.py --body corps.html --out <chemin_sans_extension> \
        --title "Titre" --subtitle "Sous-titre" \
        --chip "Période couverte : …" --chip "Arrêtée le …" [--kicker "…"]

Produit <out>.html puis <out>.pdf (WeasyPrint), et affiche le nombre de pages.
Le corps est du HTML brut : <section>, <article class="item">, <ul class="breves">, etc.
Classes disponibles : item / item flag / item warn · facts · so-what · sources · visa · tally.
"""
import argparse, re, subprocess, sys, pathlib

CSS = """
  :root{
    --ink:#15181c; --ink-soft:#4a5058; --ink-faint:#767d86;
    --paper:#fbfaf7; --card:#ffffff; --line:#e4e0d8;
    --vert:#0b6b3a; --orange:#e07a12; --rouge:#9c2c2c; --wash:#f4f1ea;
    --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
    --serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,"Times New Roman",serif;
    --sans:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  }
  @media screen and (prefers-color-scheme: dark){
    :root{--ink:#e9e6e0;--ink-soft:#b0aca4;--ink-faint:#8b8880;--paper:#14161a;
          --card:#1b1e23;--line:#2e3238;--vert:#3fae74;--orange:#f0a04b;--rouge:#e07070;--wash:#212429}
  }
  *{box-sizing:border-box}
  body{margin:0;padding:0 1rem 4rem;background:var(--paper);color:var(--ink);
       font-family:var(--sans);font-size:16px;line-height:1.62;-webkit-text-size-adjust:100%}
  .wrap{max-width:820px;margin:0 auto}
  header.masthead{margin:0 -1rem 2rem;padding:2.4rem 1rem 1.6rem;background:var(--card);
                  border-bottom:1px solid var(--line);position:relative}
  .tricolore{position:absolute;top:0;left:0;right:0;height:4px;display:flex}
  .tricolore i{flex:1 1 33.333%}
  .tricolore i:nth-child(1){background:#e07a12}
  .tricolore i:nth-child(2){background:#f2f2f2}
  .tricolore i:nth-child(3){background:#0b6b3a}
  .masthead .inner{max-width:820px;margin:0 auto}
  .eyebrow{font-family:var(--mono);font-size:.68rem;letter-spacing:.18em;text-transform:uppercase;
           color:var(--ink-faint);margin:0 0 .6rem}
  h1{font-family:var(--serif);font-weight:600;font-size:2rem;line-height:1.18;margin:0 0 .9rem;
     letter-spacing:-.01em}
  h1 .sub{display:block;font-size:1.05rem;color:var(--ink-soft);font-weight:400;margin-top:.35rem}
  .meta{display:flex;flex-wrap:wrap;gap:.45rem .5rem;margin:1.1rem 0 0;font-family:var(--mono);font-size:.7rem}
  .chip{border:1px solid var(--line);background:var(--wash);color:var(--ink-soft);
        padding:.3rem .6rem;border-radius:999px}
  .chip b{color:var(--ink);font-weight:600}
  section{margin:0 0 2.6rem}
  h2{font-family:var(--mono);font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;
     color:var(--ink-faint);font-weight:600;margin:0 0 1.1rem;padding-bottom:.5rem;
     border-bottom:1px solid var(--line)}
  .item{background:var(--card);border:1px solid var(--line);border-radius:10px;
        padding:1.15rem 1.25rem;margin:0 0 1rem}
  .item.flag{border-left:3px solid var(--orange)}
  .item.warn{border-left:3px solid var(--rouge);background:var(--wash)}
  .item.reco{border-left:3px solid var(--vert)}
  .item h3{font-family:var(--serif);font-size:1.16rem;line-height:1.3;margin:0 0 .55rem;font-weight:600}
  .rank{display:inline-flex;align-items:center;justify-content:center;width:1.35rem;height:1.35rem;
        margin-right:.5rem;vertical-align:2px;background:var(--orange);color:#fff;border-radius:5px;
        font-family:var(--mono);font-size:.72rem;font-weight:700}
  .item p{margin:0 0 .6rem}
  .item p:last-of-type{margin-bottom:0}
  .facts{margin:.7rem 0;padding:.7rem .9rem;background:var(--wash);border-radius:7px;
         font-family:var(--mono);font-size:.82rem;line-height:1.85}
  .facts .k{color:var(--ink-faint)}
  .facts .v{color:var(--ink);font-weight:600}
  .so-what{margin-top:.75rem;padding:.7rem .9rem .75rem;border-left:2px solid var(--vert);
           background:var(--wash);border-radius:0 7px 7px 0}
  .so-what .label{display:block;font-family:var(--mono);font-size:.63rem;letter-spacing:.14em;
                  text-transform:uppercase;color:var(--vert);font-weight:700;margin-bottom:.3rem}
  .so-what p{font-size:.94rem;color:var(--ink);margin:0}
  .so-what p + p{margin-top:.5rem}
  .sources{margin-top:.85rem;padding-top:.7rem;border-top:1px dashed var(--line)}
  .sources .label{font-family:var(--mono);font-size:.63rem;letter-spacing:.14em;text-transform:uppercase;
                  color:var(--ink-faint);margin-right:.4rem}
  .sources a{display:inline-block;margin:.22rem .3rem .22rem 0;padding:.24rem .55rem;
             border:1px solid var(--line);border-radius:5px;background:var(--paper);color:var(--ink);
             text-decoration:none;font-size:.8rem;line-height:1.4}
  .sources a .d{color:var(--ink-faint);font-family:var(--mono);font-size:.72rem;margin-left:.3rem}
  .sources .nolink{display:inline-block;margin:.22rem .3rem .22rem 0;padding:.24rem .55rem;
                   border:1px dashed var(--line);border-radius:5px;color:var(--ink-faint);font-size:.8rem}
  ul.breves{list-style:none;margin:0;padding:0}
  ul.breves > li{background:var(--card);border:1px solid var(--line);border-radius:10px;
                 padding:.95rem 1.1rem;margin:0 0 .7rem}
  ul.breves h4{font-family:var(--sans);font-size:.97rem;font-weight:600;margin:0 0 .35rem}
  ul.breves p{margin:0 0 .45rem;font-size:.94rem;color:var(--ink-soft)}
  ul.breves p:last-of-type{margin-bottom:0}
  ul.breves .so-what p{color:var(--ink)}
  table.grid{width:100%;border-collapse:collapse;font-size:.89rem;margin:.8rem 0}
  table.grid th{text-align:left;font-family:var(--mono);font-size:.66rem;letter-spacing:.1em;
                text-transform:uppercase;color:var(--ink-faint);padding:.45rem .4rem;
                border-bottom:1px solid var(--line);font-weight:600}
  table.grid td{padding:.5rem .4rem;border-bottom:1px solid var(--line);vertical-align:top;color:var(--ink-soft)}
  table.grid td:first-child{color:var(--ink);font-weight:600}
  .visa{margin-top:3rem;background:var(--card);border:1px solid var(--line);border-radius:10px;
        padding:1.3rem 1.35rem}
  .visa h2{margin-top:0}
  table.passes{width:100%;border-collapse:collapse;font-size:.89rem;margin:0 0 1rem}
  table.passes td{padding:.5rem .3rem;border-bottom:1px solid var(--line);vertical-align:top}
  table.passes td:first-child{width:11.5rem;font-weight:600;color:var(--ink)}
  table.passes td:last-child{color:var(--ink-soft)}
  table.passes tr:last-child td{border-bottom:none}
  .tally{display:flex;flex-wrap:wrap;gap:.6rem;margin:1rem 0}
  .tally > div{flex:1 1 110px;background:var(--wash);border:1px solid var(--line);border-radius:8px;
               padding:.65rem .7rem;text-align:center}
  .tally .n{display:block;font-family:var(--serif);font-size:1.5rem;font-weight:600;color:var(--vert)}
  .tally .l{font-family:var(--mono);font-size:.62rem;letter-spacing:.1em;text-transform:uppercase;
            color:var(--ink-faint)}
  .visa .note{font-size:.86rem;color:var(--ink-soft);margin:.6rem 0 0}
  footer{margin-top:2rem;padding-top:1.2rem;border-top:1px solid var(--line);font-family:var(--mono);
         font-size:.7rem;color:var(--ink-faint);text-align:center}
  @page{size:A4;margin:14mm 13mm 16mm}
  @media print{
    body{background:#fff;color:#15181c;font-size:9.6pt;line-height:1.5;padding:0}
    .wrap{max-width:none}
    header.masthead{margin:0 0 7mm;padding:0 0 4mm;background:none;border-bottom:1px solid #ddd}
    .tricolore{position:static;margin:0 0 4mm;height:3px}
    h1{font-size:18pt} h1 .sub{font-size:11pt}
    .chip{background:#f6f4ef}
    section{margin-bottom:6mm} h2{margin-bottom:3mm}
    .item, ul.breves > li{background:none;border:1px solid #dcd8d0;padding:.55rem .7rem;
                          margin-bottom:.45rem;break-inside:auto}
    .item h3, ul.breves h4{break-after:avoid;font-size:11.2pt}
    .facts,.so-what,.sources{break-inside:avoid}
    .facts{font-size:8.6pt;line-height:1.6}
    .so-what p{font-size:9.2pt}
    .sources a,.sources .nolink{font-size:8.4pt;padding:.15rem .4rem}
    .visa{break-inside:auto;padding:.8rem .9rem}
    table.passes,table.grid{font-size:8.6pt}
    .tally .n{font-size:1.15rem}
    a{color:#15181c}
    footer{margin-top:6mm}
  }
  @media screen and (max-width:520px){h1{font-size:1.55rem}body{font-size:15px}}
"""

SHELL = """<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>{css}</style></head><body>
<header class="masthead">
  <div class="tricolore"><i></i><i></i><i></i></div>
  <div class="inner">
    <p class="eyebrow">{kicker}</p>
    <h1>{h1}<span class="sub">{subtitle}</span></h1>
    <div class="meta">{chips}</div>
  </div>
</header>
<div class="wrap">
{body}
<footer>
  Document de travail interne, sources publiques uniquement, ne pas diffuser hors de l'entreprise<br>
  {footnote}
</footer>
</div></body></html>
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--body', required=True)
    ap.add_argument('--out', required=True, help="chemin sans extension")
    ap.add_argument('--title', required=True)
    ap.add_argument('--subtitle', default='')
    ap.add_argument('--kicker', default="Document de travail interne")
    ap.add_argument('--chip', action='append', default=[])
    ap.add_argument('--footnote', default='')
    a = ap.parse_args()

    chips = ''.join('<span class="chip">%s</span>' % c for c in a.chip)
    html = SHELL.format(title=re.sub('<[^>]+>', '', a.title), css=CSS, kicker=a.kicker,
                        h1=a.title, subtitle=a.subtitle, chips=chips,
                        body=pathlib.Path(a.body).read_text(encoding='utf-8'),
                        footnote=a.footnote)
    out = pathlib.Path(a.out)
    out.with_suffix('.html').write_text(html, encoding='utf-8')
    subprocess.run(['weasyprint', str(out.with_suffix('.html')), str(out.with_suffix('.pdf'))],
                   check=True, capture_output=True)
    info = subprocess.run(['pdfinfo', str(out.with_suffix('.pdf'))], capture_output=True, text=True).stdout
    pages = next((l.split(':')[1].strip() for l in info.splitlines() if l.startswith('Pages')), '?')
    print(f"{out.with_suffix('.html').name} + {out.with_suffix('.pdf').name}, {pages} page(s)")


if __name__ == '__main__':
    sys.exit(main())
