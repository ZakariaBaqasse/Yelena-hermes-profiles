---
id: Y0688
name: prevision-et-tendance
description: "Projette une série de chiffres de l'entreprise (ventes, encaissements, volumes, effectifs) sur les semaines ou mois qui viennent : tendance de fond, saisonnalité, ruptures identifiées, puis fourchette basse / centrale / haute plutôt qu'un chiffre unique, avec méthode explicable, erreur mesurée sur le passé, et hypothèses écrites noir sur blanc."
bucket: B
tags: [Données, Analyse, Nouveau]
version: 1
maj: 2026-09-21
---

# La prévision et la tendance, dire où vont les chiffres et avec quelle marge

## Ce qu'il faut avoir sous la main
- **La série à projeter** : quel indicateur (ventes, encaissements, volumes, effectifs, consommations), sur quelle unité (jour, semaine, mois), et le fichier ou l'export qui la contient.
- **L'historique disponible** : sur combien de périodes en arrière, et depuis quand la donnée est fiable (si une partie est douteuse, dis-le).
- **Les événements que tu connais** : une promotion, l'ouverture d'un point de vente, une hausse de prix, une rupture de stock, tout ce qui a pu faire bouger la série sans que ce soit la tendance de fond.
- **L'horizon souhaité** : sur combien de semaines ou de mois tu veux voir devant toi.
- **Ce qui doit rester vrai pour que la projection tienne** : nombre de points de vente, jours d'ouverture, prix, effectif, si tu le sais déjà.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet reste l'idéal. Le démarrage ne dépend pas d'un intake complet.

## Process
### Étape 1 : Juger si l'historique permet de projeter

Avant toute projection : la série a-t-elle assez de recul pour montrer un cycle complet ? Une saisonnalité mensuelle (les fêtes, la rentrée scolaire, la saison des pluies qui ralentit certains commerces) ne se voit que sur au moins un an complet, idéalement deux. Un historique de six mois montre une tendance, jamais une saisonnalité annuelle ; le dire explicitement plutôt que de l'inventer.

Vérifie ensuite la propreté de la donnée : périodes manquantes, doublons, changement d'unité en cours de route (un fichier qui passe du FCFA au millier de FCFA sans le signaler), fusion de deux sources qui ne comptent pas la même chose. Si un doute sérieux se pose sur la qualité de la donnée elle-même, renvoie vers la compétence `qualite-de-la-donnee` avant de poursuivre : projeter sur une base sale produit une prévision qui a l'air rigoureuse et qui ne vaut rien.

Le verdict de cette étape se dit tôt et clairement : « historique suffisant pour une saisonnalité mensuelle », ou « historique limité à une tendance, pas de saisonnalité fiable au-delà de ⟦à renseigner⟧ mois », ou « donnée trop irrégulière, correction nécessaire avant projection ».

### Étape 2 : Isoler les événements exceptionnels

Piège classique : une hausse due à une promotion, une ouverture de point de vente, un événement ponctuel (foire, salon, campagne radio) se lit comme une accélération de tendance si on ne la traite pas à part. Elle ne continue pas naturellement.

Repère les points de la série qui s'écartent nettement du reste, et pour chacun, cherche s'il correspond à un événement connu (donné par l'utilisateur, ou visible dans le calendrier de l'entreprise). Un point exceptionnel identifié est retiré du calcul de tendance et de saisonnalité, mais reste visible dans le graphique, annoté. Un point qui s'écarte sans explication trouvée est signalé comme « écart non expliqué » : tu ne l'inventes pas, tu ne le corriges pas silencieusement, tu le montres.

### Étape 3 : Décomposer : tendance, saisonnalité, résidu

Sur la série nettoyée des événements exceptionnels, dégage trois composantes, en langage clair avant tout calcul :
- **La tendance de fond** : la série monte, descend, ou est stable sur le fond, indépendamment des à-coups saisonniers.
- **La saisonnalité** : les mois forts, les jours creux, l'effet des fêtes ou de la rentrée, s'ils sont visibles avec l'historique disponible (voir étape 1).
- **Le résidu** : ce qui reste une fois tendance et saisonnalité retirées, c'est-à-dire le bruit normal de l'activité.

Choisis la méthode la plus simple qui rend compte de ces trois éléments : moyenne mobile pour lisser le bruit et voir la tendance, régression linéaire simple pour projeter la tendance de fond, moyenne par période (mois, jour de semaine) pour la saisonnalité. Un modèle plus complexe (lissage exponentiel, décomposition avancée) ne se justifie que si la méthode simple échoue visiblement, et il se raconte quand même en trois phrases à la fin.

### Étape 4 : Rejouer la méthode sur le passé et mesurer l'erreur

Avant de projeter l'avenir, cache les dernières périodes connues (par exemple les trois ou six derniers mois selon l'historique disponible), fais tourner la méthode comme si elles n'existaient pas encore, et compare ce qu'elle aurait prédit à ce qui s'est réellement passé.

Cet écart, exprimé en pourcentage moyen d'erreur sur la période testée, est le chiffre qui dit si la prévision vaut quelque chose. Un écart de test faible donne confiance dans la fourchette projetée ; un écart élevé oblige à élargir la fourchette ou à revoir la méthode. Ce test n'est jamais sauté, même sous pression de délai : une prévision qui n'a pas été confrontée au passé n'a aucune raison de mieux se comporter sur l'avenir.

### Étape 5 : Construire les trois scénarios

La projection se rend en trois courbes, jamais une seule :
- **Scénario central** : la tendance et la saisonnalité prolongées telles quelles, ajustées de l'écart mesuré à l'étape 4.
- **Scénario bas** : la même méthode avec les hypothèses les moins favorables qui restent plausibles (pas de nouvelle croissance, saisonnalité la plus faible observée).
- **Scénario haut** : les hypothèses les plus favorables qui restent plausibles (poursuite de la dynamique récente, saisonnalité la plus forte observée).

L'écart entre bas et haut n'est pas décoratif : plus l'erreur mesurée à l'étape 4 est grande, plus la fourchette s'élargit. Une fourchette resserrée sur une méthode qui s'est trompée de beaucoup dans le test historique est une fourchette mensongère.

### Étape 6 : Écrire les hypothèses et ce qui invaliderait la prévision

Toute prévision suppose un certain nombre de choses qui restent vraies : le nombre de points de vente, les prix pratiqués, les jours d'ouverture, l'effectif, l'absence de rupture d'approvisionnement, la parité fixe du franc CFA si une part de l'activité dépend d'intrants importés en devises. Liste ces hypothèses noir sur blanc dans le livrable.

Ajoute la liste des événements qui, s'ils survenaient, rendraient la prévision caduque et imposeraient de la refaire : ouverture ou fermeture d'un point de vente, changement de prix, nouvel entrant sur le marché, rupture de stock prolongée, changement réglementaire. Une prévision sans cette liste laisse croire qu'elle reste valable indéfiniment, ce qui n'est jamais le cas.

## Format de sortie
- **Livrable 1, Google Sheet** : l'historique nettoyé (avec les périodes manquantes marquées comme telles, jamais interpolées sans le dire), la décomposition en tendance / saisonnalité / événements exceptionnels, la projection en trois scénarios (bas, central, haut) période par période, et le graphique qui montre l'historique et les trois courbes de projection sur le même axe.
- **Livrable 2, Google Doc, une page, note de méthode** : la méthode choisie racontée en trois phrases maximum, la liste des hypothèses, l'erreur mesurée en rejouant la méthode sur le passé, et la liste de ce qui invaliderait la prévision.
- **Livrable 3, Google Slides, page de synthèse pour la direction** : un graphique (historique + trois scénarios), trois chiffres clés (le scénario central sur l'horizon demandé, l'erreur mesurée, l'écart entre le bas et le haut), et une alerte visuelle (couleur) si la tendance récente décroche de la trajectoire historique.
- **Chaque chiffre cite sa période et son fichier source** dans les trois livrables : pas de chiffre flottant sans origine traçable.
- **Structure** : Markdown pour tout échange intermédiaire, answer-first (le verdict sur la fiabilité de l'historique et la fourchette d'abord, le détail ensuite).
- **Règle 0 invention** : aucune donnée chiffrée fabriquée. Une période manquante reste manquante et marquée comme telle ; un seuil de décision ou une hypothèse d'entreprise non fournie reste `⟦à renseigner⟧`.

## Règles
1. **Une prévision est une fourchette, jamais un chiffre unique.** Le scénario central sans ses bornes basse et haute fait croire à une certitude qui n'existe pas ; les trois scénarios sont toujours rendus ensemble.
2. **L'historique commande l'horizon.** Tu ne projettes jamais une saisonnalité annuelle sur un historique de moins d'un an ; tu dis explicitement jusqu'où l'historique disponible permet raisonnablement d'aller, et tu t'arrêtes là.
3. **Un événement exceptionnel ne prolonge pas la tendance.** Avant de tracer une droite, tu vérifies ce qui a produit chaque pic ou creux marquant ; une promotion ponctuelle, une ouverture de point de vente ou un salon ne sont pas la tendance de fond.
4. **La méthode se raconte en trois phrases.** Si tu ne peux pas expliquer simplement pourquoi la prévision dit ce qu'elle dit, tu choisis une méthode plus simple, quitte à perdre en finesse.
5. **L'erreur passée se mesure avant de projeter l'avenir.** Tu rejoues systématiquement la méthode sur les dernières périodes connues et tu donnes l'écart obtenu ; ce chiffre conditionne la largeur de la fourchette.
6. **Les hypothèses s'écrivent, et la prévision se refait quand elles changent.** Une prévision n'est jamais un objet figé ; elle est valable sous des conditions nommées, et la première chose à vérifier quand la réalité s'écarte est de savoir laquelle a bougé.
7. **Aucun point de donnée manquant n'est fabriqué.** Un mois ou une semaine sans donnée est marqué manquant, traité comme un trou visible dans le graphique et le tableau, jamais comblé par interpolation silencieuse.
8. **Le contexte local n'est pas un détail.** La saisonnalité d'une entreprise ivoirienne suit son propre calendrier (fêtes, rentrée scolaire, saison des pluies, périodes de grande affluence liées aux salons et événements locaux) ; tu ne plaques pas une saisonnalité générique sans l'avoir vérifiée sur l'historique réel.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; diffuser la prévision en externe, l'intégrer dans un budget engagé ou la communiquer à un tiers est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une série ou d'une entité ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Historique trop court pour une saisonnalité** (moins d'un cycle complet) : tu le dis explicitement, tu limites la projection à une tendance sans composante saisonnière, et tu marques l'horizon fiable en conséquence.
- **Historique trop court pour toute méthode fiable** (quelques semaines seulement) : tu produis quand même une note, marquée provisoire, qui explique pourquoi aucune projection sérieuse n'est possible et ce qu'il faut accumuler comme données avant de refaire l'exercice.
- **Donnée suspecte ou incohérente** (changement d'unité, doublons, rupture de série) : tu signales le doute, tu orientes vers `qualite-de-la-donnee` si le problème est structurel, et tu ne projettes pas sur une base non fiabilisée sans le dire.
- **Événement exceptionnel non confirmé par l'utilisateur** : un point qui s'écarte fortement de la série sans explication donnée reste marqué « écart non expliqué », il n'est ni retiré ni intégré silencieusement à la tendance.
- **Aucune hypothèse d'entreprise fournie** (prix, effectif, points de vente à venir) : tu marques chaque hypothèse manquante `⟦à renseigner⟧` dans la note de méthode et tu produis la projection sous hypothèse de statu quo, explicitement nommée comme telle.
- **Rupture connue mais non datée précisément** (« on a augmenté les prix cette année », sans le mois) : tu le signales, tu demandes la précision si elle change le résultat, sinon tu la traites comme une hypothèse floue documentée.
- **Demande de prévision sur un horizon trop lointain par rapport à l'historique** : tu le dis, tu proposes l'horizon maximal raisonnable compte tenu des données, et tu ne rends pas la projection demandée si elle dépasse ce que l'historique permet d'assumer.
- **Demande hors périmètre** (calcul de taille de marché, business plan, budget) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (diffusion externe, intégration dans un engagement budgétaire) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux fichiers donnent des chiffres différents pour la même période) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
