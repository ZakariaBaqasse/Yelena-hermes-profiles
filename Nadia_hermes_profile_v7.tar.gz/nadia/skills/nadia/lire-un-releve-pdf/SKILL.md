---
id: Y0709
name: lire-un-releve-pdf
description: "Transforme un relevé reçu en PDF (banque, mobile money, plateforme de paiement, facture d'opérateur, export figé d'un logiciel) en table exploitable, ligne par ligne, avec contrôle du total contre le document, avant tout rapprochement ou analyse. Distingue le PDF qui contient du texte (lisible directement) du scan ou de la photo (qui demande une reconnaissance de caractères non disponible sur ce poste : on le dit, on ne devine pas les chiffres). Garde le document d'origine à côté de la table, et journalise chaque ligne qu'il a fallu corriger à la main."
bucket: B
tags: [Données, Extraction, PDF, Relevés, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Un relevé en PDF n'est pas une donnée tant qu'il n'est pas une table

## Ce qu'il faut avoir sous la main
- **Le fichier** tel que reçu (PDF, plusieurs PDF, ou photo), avec l'émetteur (quelle banque, quel opérateur) et la période qu'il couvre.
- **Ce qu'on veut en faire** : rapprochement (`croiser-des-sources-heterogenes`), suivi des encaissements, contrôle des frais. Ça décide des colonnes à garder.
- **Un total de contrôle** imprimé sur le document (solde de fin, total des crédits) : c'est lui qui prouvera que la lecture est complète.

> ⚡ **Une photo ou un scan ne se lit pas ici.** Ce poste n'a pas d'outil de reconnaissance de caractères. Tu le dis, tu demandes l'export PDF ou CSV depuis l'application ou l'espace en ligne (toutes les banques et tous les opérateurs de mobile money en fournissent), et en attendant tu livres la trame vide de la table avec ses colonnes.

## Process
### Étape 1, Savoir ce qu'on tient
`pdftotext -layout` sur la première page : si le texte sort, le PDF est lisible. S'il sort vide ou en bouillie, c'est une image : on s'arrête là et on demande l'export. Un PDF « protégé » se signale au client, on ne le force pas.

### Étape 2, Extraire ligne par ligne
`pdfplumber` (`~/.venv-office/bin/python`) pour les tableaux, `pdftotext -layout` en secours pour les relevés en colonnes fixes. Une ligne de relevé = date d'opération, date de valeur, libellé complet, débit, crédit, solde, référence. On garde le libellé intact, on n'y touche pas : c'est lui qui portera le rapprochement.

### Étape 3, Contrôler contre le document
Somme des débits, somme des crédits, solde de fin recalculé depuis le solde de début : les trois se comparent aux chiffres imprimés. Un écart, même d'un franc, veut dire une ligne manquée, coupée par un saut de page, ou un montant lu de travers ; on cherche jusqu'à ce que ça tombe juste, et si ça ne tombe pas, on écrit l'écart en tête de la table et on ne l'utilise pas pour un rapprochement.

### Étape 4, Corriger avec trace
Une ligne coupée sur deux pages, un libellé sur deux lignes, un montant avec un point de milliers mal lu : chaque correction manuelle va dans un journal (page, valeur lue, valeur retenue, raison). La table sans son journal n'est pas livrable.

### Étape 5, Livrer et ranger
Table en tableur (`tableur-livrable`), le PDF d'origine rangé à côté, le journal des corrections en onglet. Le relevé contient souvent des noms de personnes et des numéros : partage au strict périmètre (`donnees-personnelles-ci`, `partage-et-acces`).

## Format de sortie
- **Tableur** : onglet Relevé (une ligne par opération, colonnes typées), onglet Contrôle (totaux imprimés contre recalculés), onglet Corrections.
- **Trois lignes dans le fil** : période, nombre d'opérations, contrôle juste ou écart.
- **Trame vide** avec ses colonnes quand le document n'est pas lisible.

## Règles
1. **Pas de chiffre deviné sur une image.** Sans reconnaissance de caractères, on demande l'export ; on ne « lit » pas une photo à l'œil pour la retaper.
2. **Le contrôle des totaux est obligatoire** et s'écrit même quand il est juste.
3. **Libellés intacts**, corrections journalisées.
4. **Le document d'origine reste avec la table**, la table seule n'est pas une preuve.
5. **Relevé = données personnelles** : périmètre de partage strict.

## Cas limites
- **Relevé multi-mois en un PDF** : on découpe par mois, et chaque mois porte son contrôle.
- **Mobile money exporté en CSV** : on saute l'extraction et on passe direct à `qualite-de-la-donnee` (les CSV d'opérateurs ont leurs propres pièges : fuseau, frais dans une ligne séparée, statuts « en attente »).
- **Deux relevés qui se recouvrent** : on marque le recouvrement et on dédoublonne par référence d'opération, jamais par montant et date seuls.
