---
id: Y0475
name: questionnaire-et-depouillement
description: "À charger dès qu'on demande une enquête ou un questionnaire (« crée-moi le questionnaire », « fais une enquête sur… »). Conçoit un questionnaire dont chaque question est réellement dépouillable, le fabrique en formulaire Tally réel quand l'intégration `integrations/tally/` est présente sur le poste, puis, dès les premières réponses (y compris des réponses d'essai), rend le tableau de bord et le rapport. Écrit aussi le plan de dépouillement avant la collecte (croisements prévus, sous-groupes, seuil de lisibilité), suit les retours par canal et par jour, puis livre une synthèse où chaque chiffre porte sa base et sa date, et où ce que les réponses ne permettent pas de conclure est dit aussi nettement que ce qu'elles montrent."
bucket: B
tags: [Données, Enquête, Nouveau]
version: 2
maj: 2026-09-23
---

# Écrire un questionnaire exploitable, et dire ce qu'on ne peut pas conclure

> ⛔ **Contrôle avant remise (23/09/2026).** Une demande d'enquête ne se rend pas en tableau
> Markdown de questions. Avant de répondre, vérifie trois choses ; si l'une manque, ne remets pas :
> 1. **Le formulaire existe dans Tally** (en brouillon au minimum), créé par
>    `python3 integrations/tally/tally.py creer <definition.json>`, et tu donnes son lien
>    d'édition. Si `integrations/tally/` n'existe pas sur ce poste, tu le dis en une ligne et tu
>    rends le questionnaire seul, sans prétendre qu'il est en ligne.
> 2. **Le plan de dépouillement est écrit** (étape 3), dans le même rendu.
> 3. **La suite est annoncée** : dès qu'il y a des réponses, même d'essai, tu relèves, tu rends
>    le tableau de bord et le rapport (étape 4 bis). Tu ne t'arrêtes pas au formulaire.

## Ce qu'il faut avoir sous la main
- **Ce que cette enquête doit trancher** : quelle décision dépend du résultat, et qui la lira.
- **Qui tu interroges** : population visée, comment tu comptes les atteindre (WhatsApp, formulaire en ligne, passage terrain, appel, papier).
- **Combien de personnes** tu comptes solliciter, et si tu as déjà une liste de contacts.
- **Les sous-groupes qui t'intéressent** si tu en as déjà en tête (par quartier, par type de client, par canal d'achat).
- **Un brouillon de questions**, si tu en as un, même imparfait.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les seuils manquants `⟦à renseigner⟧`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Fixer ce que l'enquête doit trancher

Avant d'écrire une seule question, établis la décision qui dépend du résultat et qui la lira. Une enquête sans décision derrière est une collecte de curiosité : ça peut se faire, mais tu le dis, parce que le niveau d'exigence sur le seuil de lisibilité change selon qu'on va agir sur le résultat ou simplement s'informer.

Précise ensuite la population visée : recensement (tout le monde) ou échantillon (une partie), et sur quelle base tu vas les atteindre : une liste de contacts existante, un passage terrain, une diffusion ouverte. Une diffusion ouverte sur WhatsApp ou dans un salon touche un public qui se choisit lui-même, et ça se retient pour la lecture des résultats à l'étape 5.

### Étape 2 : Construire chaque question pour qu'elle soit dépouillable

Pour chaque question, fixe le type (choix unique, choix multiple, échelle, champ libre), les options, et **ce qu'elle sert à mesurer**. Une question sans objectif de mesure clair se supprime, elle n'ajoutera que du bruit au dépouillement.

Quatre pièges à désamorcer question par question :
- **La question qui contient sa réponse.** Une formulation qui suggère la bonne opinion (« notre service rapide vous a-t-il satisfait ? ») produit un résultat inutilisable, et ça ne se rattrape pas au dépouillement. Reformule en neutre, sans qualificatif positif ou négatif dans l'énoncé.
- **Deux questions en une.** « Le service est rapide et bien expliqué » ne se répond pas si l'un est vrai et l'autre faux. Sépare systématiquement en deux questions dès qu'un énoncé contient un « et ».
- **Les options qui ne couvrent pas tous les cas ou qui se chevauchent.** Vérifie que la liste d'options est exhaustive (un « autre, précisez » en secours si besoin) et que deux options ne peuvent pas décrire la même situation. Un répondant qui hésite entre deux options qui se recoupent choisit au hasard, et ton comptage devient faux sans que rien ne le signale.
- **Le champ libre partout.** Le champ libre est agréable à écrire et lourd à dépouiller. Réserve-le à ce que tu veux **lire** (un verbatim, une raison inattendue), jamais à ce que tu veux **compter**. Sur téléphone d'entrée de gamme et connexion facturée à la donnée, un champ libre long fait aussi chuter le taux de réponse : tiens-en compte dans la longueur du questionnaire.

### Étape 3 : Écrire le plan de dépouillement avant la collecte

Avant d'envoyer la première invitation, écris noir sur blanc :
- **Les croisements prévus** : quelle question sera lue en fonction de quelle autre (par exemple, la satisfaction croisée avec le canal d'achat).
- **Les sous-groupes qu'on regardera** : par zone, par type de client, par ancienneté, ce que la décision de l'étape 1 rend pertinent, pas tous les découpages possibles.
- **Le seuil de lisibilité** : à partir de combien de répondants un sous-groupe devient lisible. C'est une **décision de l'équipe**, tu poses la question et tu laisses la valeur en `⟦à renseigner⟧` tant qu'elle n'est pas fournie.

Un questionnaire dont on ne sait pas à l'avance ce qu'on en fera produit des réponses qu'on ne saura pas lire, même bien formulées. Ce plan écrit avant la collecte est un livrable à part entière, pas une note interne.

### Étape 3 bis : Fabriquer le formulaire dans Tally

Tout appel à Tally passe par les scripts de `integrations/tally/` (lis son `README.md` avant le
premier usage). Tu n'écris jamais d'appel à l'API ailleurs.

1. **Traduire le questionnaire arrêté** en fichier de définition JSON, au format décrit en tête
   de `tally.py` : `choix` (choix unique), `cases` (choix multiples), `liste`, `court`, `long`,
   `nombre`, `date`, `texte` (paragraphe d'information), `page` (saut de page). `"autre": true`
   ajoute l'option « Autre » à précision libre, ce qui applique la règle 3 sans champ libre
   inutile. `"obligatoire": false` pour une question facultative. Le fichier se range dans le
   dossier de la maison concernée.
2. **Créer en brouillon** : `python3 integrations/tally/tally.py creer <definition.json>`. Le
   script rend l'identifiant et le lien d'édition. Relis le formulaire avec
   `tally.py lire <id>` avant de le montrer : ce qui s'affiche est ce que verra le répondant.
3. **Publier ouvre la collecte**, et c'est une collecte de données personnelles dès qu'elle
   vise des clients ou des salariés. Tu ne publies qu'avec l'accord écrit dans le fil :
   `tally.py creer <definition.json> --publier --accord`, qui rend le lien public. Le
   brouillon devenu inutile part à la corbeille (`tally.py corbeille <id> --accord`), avec le
   même accord. Autre voie : la personne publie elle-même depuis le lien d'édition.
4. **Une maison qui impose ses propres outils** (une banque, par exemple) décide si ses clients
   peuvent répondre sur Tally : tu poses la question avant de publier, tu ne l'y mets pas
   d'office.
5. **Modifier un formulaire existant** : le script ne le fait pas. Tu recrées un brouillon
   corrigé plutôt que de toucher à un formulaire qui a déjà reçu des réponses.

### Étape 4 : Publier et suivre les retours

Choisis le ou les canaux réellement disponibles pour la population visée : diffusion WhatsApp (rapide, gratuite pour le répondant si le forfait le permet), formulaire en ligne (suppose une connexion et un smartphone), appel téléphonique ou passage terrain (couvre un public différent, mais coûte du temps et se heurte, à Abidjan, aux distances et aux embouteillages qui limitent le nombre de passages possibles par jour). Chaque canal touche un public différent : un choix de canal unique biaise déjà la population qui répondra.

Tiens un suivi quotidien : sollicités, répondants, taux de réponse, ventilé par canal et par jour. Un taux de réponse qui plafonne tôt annonce déjà un biais de qui a répondu : ceux qui répondent à une enquête ne ressemblent jamais tout à fait à ceux qui ne répondent pas, et ça se dit dans la synthèse, pas seulement dans le suivi.

### Étape 4 bis : Des réponses, même d'essai, donnent tout de suite un tableau de bord et un rapport

Dès que le formulaire a des réponses, tu ne t'arrêtes pas à les compter :
1. **Relever** : `python3 integrations/tally/tally.py reponses <id> --csv <dossier de la maison>/reponses-<date>.csv`
   (lecture seule, réponses complètes, une colonne `recue_le` par soumission). Les réponses
   restent dans le dossier de la maison concernée, jamais ailleurs.
2. **Contrôler le fichier** avant toute analyse (compétence `qualite-de-la-donnee`).
3. **Rendre le tableau de bord** (compétences `du-tableur-au-tableau-de-bord` et
   `du-jeu-de-donnees-au-rapport-brande`, étape 3 : outil nommé, et s'il n'est pas branché, un
   Google Sheet avec filtres, dit comme tel) **et le rapport** construit comme à l'étape 6.
4. **Réponses d'essai** : quand la personne remplit le formulaire elle-même pour tester la
   chaîne, c'est un vrai jeu à traiter de bout en bout, pas un prétexte à s'arrêter. Mais
   chaque page du tableau de bord et du rapport porte en tête « réponses d'essai, aucune
   conclusion », et quand la vraie collecte s'ouvre sur le même formulaire, les réponses
   d'essai s'excluent par leur date `recue_le`, en le disant. Des chiffres d'essai qui se
   mêlent aux vrais faussent l'enquête sans que rien ne le signale.

### Étape 5 : Dépouiller : chaque chiffre avec sa base

Calcule chaque pourcentage avec, à côté, sa base (n de répondants à cette question précise, pas n de sollicités) et sa date de calcul. Un pourcentage sans base est une affirmation, pas une mesure : soixante pour cent de quoi, sur combien de répondants, sur combien de sollicités.

Pour chaque sous-groupe prévu à l'étape 3, vérifie s'il atteint le seuil de lisibilité fixé. S'il ne l'atteint pas, tu ne le commentes pas, même si le résultat est séduisant : un croisement sur un petit effectif est du bruit, pas un signal, et ce n'est pas la qualité de l'histoire qu'il raconte qui le rend fiable.

Face à deux chiffres proches, demande-toi si l'écart tient compte de la taille des effectifs qui les portent. Tu ne calcules pas un intervalle de confiance de mémoire ni un test statistique inventé ; si l'équipe veut trancher ce point avec rigueur, tu le signales comme méthode à faire valider, et en attendant tu dis simplement : « l'écart est trop petit au regard des effectifs pour être commenté ».

### Étape 6 : La synthèse et ce qu'elle ne permet pas de conclure

Rends une synthèse construite dans cet ordre : les chiffres qui tiennent (base et date à côté de chacun), les écarts qui tiennent et ceux qui ne tiennent pas, le taux de réponse global et par canal avec le biais de qui a répondu explicité, puis une section à part, nommée clairement, sur **ce que ces réponses ne permettent pas de conclure**.

Cette dernière section n'est pas un aveu de faiblesse, c'est la partie qui rend le reste crédible. Une synthèse qui répond à tout sans réserve n'a probablement pas regardé ses propres effectifs d'assez près.

## Format de sortie
- **Le questionnaire** : chaque question avec son type, ses options, et ce qu'elle sert à mesurer.
- **Le formulaire Tally** : identifiant, lien d'édition, statut (brouillon ou publié), et le fichier de définition JSON qui l'a produit.
- **Dès les premières réponses** : le CSV relevé, le tableau de bord (outil nommé) et le rapport, marqués « réponses d'essai » quand c'en sont.
- **Le plan de dépouillement**, écrit avant la collecte : croisements prévus, sous-groupes retenus, seuil de lisibilité (`⟦à renseigner⟧` tant que l'équipe ne l'a pas fixé).
- **Le suivi des retours** : sollicités, répondants, taux de réponse, ventilé par canal et par jour.
- **La synthèse** : chaque chiffre avec sa base et sa date, les écarts qui tiennent et ceux qui ne tiennent pas, une section explicite « ce que ces réponses ne permettent pas de conclure ».
- **Structure** : Markdown clair, tableaux pour le questionnaire et pour le suivi des retours, texte pour la synthèse. Answer-first sur la synthèse : le constat principal d'abord, le détail ensuite.
- **Règle 0 invention** : aucun seuil de lisibilité, aucun pourcentage, aucun test statistique n'est produit de mémoire. Ce qui manque est demandé ou marqué `⟦à renseigner⟧` / `[à confirmer]`.

## Règles
1. **Une question ne se formule jamais dans le sens de la réponse souhaitée.** Toute formulation suggestive est reformulée en neutre avant d'être incluse dans le questionnaire final.
2. **Une question ne mesure qu'une seule chose.** Tout énoncé contenant un « et » entre deux qualités distinctes est scindé en deux questions.
3. **Les options sont exhaustives et mutuellement exclusives.** Un « autre, précisez » couvre les cas résiduels ; aucune option ne recoupe une autre.
4. **Le champ libre se réserve à ce qu'on veut lire, jamais à ce qu'on veut compter.** Chaque champ libre est justifié par un usage de lecture, pas de comptage.
5. **Le plan de dépouillement s'écrit avant la collecte**, jamais après. Un questionnaire envoyé sans ce plan est signalé comme tel dans la synthèse.
6. **Le seuil de lisibilité d'un sous-groupe est un input de l'équipe**, jamais une valeur produite par la skill. Il reste `⟦à renseigner⟧` tant qu'il n'est pas fourni, et s'applique même quand le résultat en dessous est intéressant.
7. **Aucun pourcentage ne circule sans sa base et sa date.** Un chiffre sans base n'est pas publié tel quel dans la synthèse.
8. **Le taux de réponse et le biais de qui a répondu se disent toujours**, même quand les résultats sont par ailleurs bons.
9. **La synthèse nomme ce qu'elle ne permet pas de conclure.** Une synthèse qui ne laisse aucune question ouverte est reprise avant d'être livrée.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un questionnaire et un plan de travail ; l'envoi, la diffusion publique ou la publication du questionnaire est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une enquête ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Questionnaire déjà envoyé sans plan de dépouillement** : tu écris le plan a posteriori, tu le signales explicitement comme construit après coup, et tu notes que certains croisements pourraient ne pas être exploitables faute d'avoir été anticipés dans la formulation des questions.
- **Taux de réponse très faible** : tu produis la synthèse sur ce qui a été recueilli, tu marques les conclusions comme fragiles, et tu proposes une relance ciblée plutôt que d'étendre artificiellement la portée du résultat.
- **Sous-groupe sous le seuil de lisibilité malgré un résultat intéressant** : tu le mentionnes comme piste à observer, pas comme un résultat, et tu dis ce qu'il faudrait collecter en plus pour le lire proprement.
- **Sujet sensible** (revenus, santé, opinions politiques) : tu proposes l'anonymisation des réponses et tu limites les champs qui permettraient de réidentifier un répondant, avant même de discuter du contenu des questions.
- **Deux canaux donnent des chiffres différents sur la même question** : tu exposes les deux résultats séparément avec leurs bases respectives, tu ne les fusionnes pas en un seul chiffre, et tu demandes l'arbitrage si une lecture unique est requise.
- **Demande hors périmètre** (dimensionner un marché, calculer un taux de conversion produit) : tu le dis en une phrase, tu traites ce qui relève du questionnaire, et tu orientes vers la compétence adaptée.
- **Action sortante demandée** (envoi du questionnaire, publication, partage des réponses brutes) : tu prépares le livrable et tu t'arrêtes pour validation humaine.

## Historique
- v2, 23/09/2026 : fabrication du formulaire dans Tally par `integrations/tally/tally.py` (brouillon, publication sur accord), relève des réponses, tableau de bord et rapport dès les réponses d'essai, contrôle avant remise en tête, séance Sync agents training.
