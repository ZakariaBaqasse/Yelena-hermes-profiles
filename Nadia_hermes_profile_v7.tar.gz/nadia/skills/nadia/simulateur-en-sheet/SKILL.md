---
id: Y0690
name: simulateur-en-sheet
description: "Construit un simulateur Google Sheet pour une décision d'entreprise (ouverture de point de vente, changement de prix, embauche, lancement de produit, changement de fournisseur) : question chiffrable posée d'abord, hypothèses sourcées séparées du calcul, trois scénarios comparés, test de réaction documenté avant livraison, sans jamais loger une constante inventée dans une formule ni remplacer le fichier vivant par une capture d'écran."
bucket: B
tags: [Données, Décision, Nouveau]
version: 1
maj: 2026-09-21
---

# Le simulateur en Google Sheet, des hypothèses qu'on peut toucher

## Ce qu'il faut avoir sous la main
- **La décision à préparer** : ouvrir un point de vente, changer un prix, embaucher, lancer un produit, changer de fournisseur, ou autre chose.
- **La question précise** à laquelle le simulateur doit répondre, si tu l'as déjà formulée (sinon je la propose et tu la valides).
- **Les chiffres réels que tu as déjà** : coûts observés, ventes d'un point de vente comparable, salaire, prix fournisseur actuel, tout ce qui n'est pas une supposition.
- **L'horizon** : sur combien de mois le simulateur doit dérouler (6, 12, 24 mois…).
- **Qui va regarder ce fichier** : direction seule, comité, banque, associé, pour calibrer le niveau de détail et la synthèse.


> ⚡ **Tu commences dès qu'un contexte, même partiel, t'est fourni.** Tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant `à confirmer` ce qui n'est pas sourcé, tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet reste l'idéal, mais tu démarres avec le contexte disponible tel quel.

## Process
### Étape 1 : Écrire la question, la faire valider

Une décision comme « simule-moi l'ouverture d'un point de vente » ne se calcule pas : il n'y a ni sortie, ni seuil de succès, ni horizon. Reformule-la en question fermée et mesurable : « combien de mois avant que le nouveau point de vente couvre ses charges fixes, si ses ventes suivent celles du premier point de vente ouvert » ; « le nouveau prix augmente-t-il la marge totale, ou la baisse de volume l'annule-t-elle » ; « à partir de quel nombre de commandes par mois l'embauche se rembourse ».

La question doit contenir : le résultat qu'on veut lire (un nombre, une date, un seuil), la condition qui le fait bouger, et l'horizon de temps. Écris-la en une phrase en tête de la première feuille, et fais-la valider par la personne avant de construire quoi que ce soit derrière : construire le modèle avant que la question soit fixée, c'est reconstruire deux fois.

Si la demande mélange plusieurs décisions (« ouvrir un point de vente ET changer de fournisseur »), sépare : un simulateur répond à une question, pas à un dossier entier. Propose deux fichiers ou deux onglets clairement distincts plutôt qu'un modèle qui essaie de tout faire et qu'on ne peut plus lire.

### Étape 2 : Lister les hypothèses, chacune avec sa source

Pour chaque paramètre qui va entrer dans le calcul, une ligne dans la feuille Hypothèses avec quatre colonnes : le nom du paramètre, sa valeur, sa source, sa fourchette (le bas et le haut, si elle existe).

La source est l'un de ces trois cas. Aucun autre cas n'est accepté :
- **Un chiffre réel de l'entreprise** (le loyer signé, le salaire proposé, le prix d'achat actuel du fournisseur, les ventes réelles d'un point de vente comparable). Cite d'où il vient : le contrat, le relevé, le tableau de bord.
- **Une hypothèse à confirmer** : personne dans l'entreprise n'a encore ce chiffre, on avance une estimation pour faire tourner le modèle. Marque-la explicitement `à confirmer`, colore la cellule, et dis ce qu'il faudrait constater pour la remplacer par une valeur réelle.
- **Une valeur de comparaison sourcée** : un chiffre qui vient d'ailleurs (un autre acteur du secteur, une étude, un document que l'entreprise t'a transmis) avec le lien ou la référence exacte. Une valeur sans référence exacte devient une invention déguisée : classe-la alors en `à confirmer`.

Le piège classique ici : un fondateur qui affirme « un point de vente comme ça fait en général tant par mois » sans dire d'où il tient le chiffre. Ce genre d'affirmation ne rentre dans le modèle qu'en `à confirmer`, jamais comme donnée dure, même si elle sonne plausible et même si elle vient d'un acteur du secteur qui a l'air de s'y connaître.

### Étape 3 : Construire le modèle, lisible avant d'être complet

Dans la feuille Calcul, déroule le résultat mois par mois (ou l'unité de temps pertinente à la décision) : chaque ligne un mois, chaque colonne une variable du calcul, la dernière colonne le résultat qui répond à la question de l'étape 1.

Règles de construction, non négociables :
- **Une constante tapée à la main dans une formule de calcul est une erreur de construction.** Toute valeur qui n'est pas elle-même le résultat d'un calcul référence une cellule de la feuille Hypothèses. Si tu es tenté d'écrire `=B2*1.18` parce que « la marge fait à peu près 18 % », le 1.18 doit être une cellule d'hypothèse nommée. Un chiffre collé dans la formule reste invisible dans le calcul.
- **Deux couleurs, deux rôles.** Les cellules d'hypothèses (entrées, dans la feuille dédiée) portent une couleur ; les cellules de calcul (dans la feuille Calcul, protégées) en portent une autre. La direction doit reconnaître d'un coup d'œil ce qu'elle a le droit de changer.
- **Formules courtes, colonnes nommées.** Une formule qui tient sur trois lignes d'écran cache un problème de découpage : ajoute une colonne intermédiaire. Empiler les opérations alourdit la formule. Nomme les colonnes par ce qu'elles contiennent (« Ventes mois », « Charges fixes », « Marge cumulée »). Une abréviation que toi seul comprends ne parle qu'à toi.
- **Protège la feuille Calcul**, laisse les cellules d'hypothèses libres. Personne ne doit pouvoir casser une formule en tapant dedans par erreur ; tout le monde doit pouvoir changer une hypothèse sans te demander la permission.

### Étape 4 : Décliner trois scénarios, le bas doit faire mal

Un scénario unique ne sert pas une décision, il l'illustre. Construis au minimum trois colonnes de résultat côte à côte dans la feuille Scénarios : bas, central, haut, chacune obtenue en faisant varier les hypothèses les plus incertaines (jamais toutes en même temps de façon incohérente : garde une logique, par exemple « le scénario bas prend les ventes les plus faibles observées ET le délai de démarrage le plus long »).

Le piège ici est un scénario bas cosmétique : une baisse de 5 % qui ne change rien à la conclusion. Le scénario bas doit représenter un vrai risque, celui qui, s'il se réalise, changerait la décision : un retard de livraison qui traîne, une saison basse plus longue que prévu, un fournisseur qui répercute une hausse, un concurrent qui baisse ses prix le mois du lancement. S'il ne fait pas mal, il ne sert à rien.

Signale dans cette feuille tout paramètre partagé entre les trois scénarios qui est en `à confirmer` : la comparaison entre bas et haut ne veut rien dire si le socle commun aux trois lui-même n'est pas fiable.

### Étape 5 : Tester la réaction avant de livrer

Avant de transmettre le fichier, bouge chaque hypothèse d'entrée, une à la fois, et vérifie que le résultat de la feuille Calcul réagit dans le sens attendu : si le loyer monte, le seuil de rentabilité doit reculer ; si le prix baisse et que le volume ne compense pas, la marge doit baisser ; si le délai d'embauche raccourcit, le point mort doit avancer.

Documente ce test dans un tableau simple : hypothèse bougée, sens du mouvement testé (hausse ou baisse), sens attendu du résultat, sens observé, conforme ou pas. Un résultat qui ne bouge pas signale une formule qui ne référence pas la bonne cellule ; un résultat qui bouge dans le mauvais sens signale une erreur de signe ou de logique. Dans les deux cas, tu corriges avant de livrer, jamais après. Un simulateur non testé est un chiffre au hasard bien présenté, quelle que soit la qualité de sa mise en forme.

### Étape 6 : La synthèse, trois chiffres et un graphique

Dans la feuille Scénarios et synthèse, retiens les **trois chiffres** que la direction va réellement regarder pour trancher : celui qui répond directement à la question de l'étape 1, et deux autres qui donnent le contexte de la décision (par exemple le seuil de rentabilité, l'impact sur la trésorerie, le point mort). N'en mets pas dix, la synthèse perd son rôle si elle liste tout ce que le modèle sait calculer.

Ajoute un graphique qui montre l'évolution du résultat dans le temps pour les trois scénarios, superposés. C'est souvent ce graphique, plus que le tableau, qui convainc en réunion.

Termine par la page Slides : elle résume la question, les trois scénarios, le verdict que le modèle suggère et le lien vers le Sheet. Elle ne remplace jamais le fichier : quelqu'un qui veut vérifier un chiffre doit pouvoir ouvrir le Sheet et le retrouver, cellule par cellule.

## Format de sortie
- **Livrable principal** : un Google Sheet en quatre feuilles.
  1. **Question et mode d'emploi** : la question validée en tête, une note de logique de dix lignes qui explique comment le modèle raisonne (d'où part le calcul, ce qui entraîne quoi), et un renvoi vers les autres feuilles.
  2. **Hypothèses** : tableau valeur / source / fourchette, avec la couleur distincte pour tout ce qui est `à confirmer`.
  3. **Calcul** : le déroulé mois par mois, protégé, formules courtes référençant uniquement des cellules d'hypothèses.
  4. **Scénarios et synthèse** : trois scénarios côte à côte, les trois chiffres clés, un graphique.
- **Livrable secondaire** : une page de synthèse en Slides pour la réunion, avec le lien vers le Sheet.
- **Preuve de robustesse** : le test de réaction documenté (hypothèse bougée, sens attendu, sens observé) livré avec le fichier. Un test mené seulement en coulisses reste invisible pour la direction.
- **Chaque hypothèse porte sa source** ou sa marque `à confirmer` : jamais un chiffre nu sans étiquette.
- **Règle 0 invention** : aucune donnée chiffrée inventée. Une valeur manquante est demandée ou marquée `à confirmer` ; elle n'est jamais remplacée par un chiffre plausible pour faire tourner le modèle sans le dire.

## Règles
1. **La question précède le modèle.** Tant qu'elle n'est pas écrite en une phrase et validée par la personne, tu ne construis pas de formule.
2. **0 chiffre inventé.** Aucune hypothèse, aucun prix, aucune fourchette, aucun seuil de succès n'est produit sans être fourni par l'entreprise ou sourcé par une référence vérifiable : `à confirmer` sinon.
3. **Aucune constante dans une formule de calcul.** Toute valeur d'entrée vit dans la feuille Hypothèses et y est référencée ; une formule de la feuille Calcul qui contient un nombre tapé à la main est une erreur à corriger immédiatement.
4. **Trois scénarios minimum, et le bas fait mal.** Un scénario unique ne prépare pas une décision. Un scénario bas cosmétique (qui ne change rien à la conclusion) ne remplit pas son rôle et doit être resserré.
5. **Le résultat est testé avant d'être livré.** Chaque hypothèse est bougée une à une, le sens de réaction attendu est écrit avant de constater le sens observé, et toute anomalie est corrigée avant transmission.
6. **Le fichier vivant est le livrable, la synthèse Slides le résume.** Une capture d'écran, un PDF figé ou une synthèse qui ne renvoie pas vers le Sheet ne suffisent jamais.
7. **Le contexte local n'est pas un détail cosmétique.** La saisonnalité d'un commerce (fêtes, rentrée scolaire, saison des pluies qui ralentit certains flux), le coût réel d'un point de vente ou d'un recrutement en franc CFA, le paiement en mobile money comme flux de caisse ordinaire à intégrer dans les entrées et sorties : ces réalités changent le modèle et ne se traitent pas comme une variable étrangère qu'on ajoute en note de bas de page.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un fichier de travail ; partager le Sheet en dehors de l'entreprise, l'envoyer à un tiers ou engager une dépense sur la base de ses chiffres est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une décision ou d'un dossier ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet**, tu construis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `à confirmer`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucune donnée réelle disponible**, tu construis quand même le modèle complet, toutes les hypothèses en `à confirmer`, et tu le dis explicitement dans la note de logique : ce simulateur sert à voir la mécanique et à savoir quoi aller mesurer, pas à trancher tel quel.
- **Une hypothèse annoncée mais non transmise** (« je t'envoie le chiffre du loyer », rien ne suit), tu le signales avant de continuer et tu ne fais pas comme si tu l'avais reçue.
- **Le résultat ne réagit pas comme attendu au test**, tu corriges le modèle avant de livrer et tu ne masques jamais l'anomalie ; si tu ne trouves pas la cause, tu le dis plutôt que de livrer un fichier dont tu doutes.
- **La décision ne se résume pas à un chiffre unique** (par exemple un changement de fournisseur qui touche aussi la qualité ou le délai), tu le dis, tu chiffres ce qui est chiffrable, et tu nommes ce qui ne l'est pas plutôt que de forcer une variable qualitative dans une cellule.
- **Demande hors périmètre** (étude de marché complète, business plan entier, prévision comptable réglementaire), tu le dis en une phrase, tu traites ce qui relève du simulateur, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (partage du fichier hors de l'entreprise, envoi à une banque, publication), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires** (deux chiffres différents fournis pour la même hypothèse), tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
