---
id: Y0309
name: pilote-poc
description: "Cadre et exploite le pilote (POC) d'une startup : périmètre, zone, cohorte et durée, grille d'hypothèses avec seuils go/no-go remplie avant le lancement, choix des indicateurs réellement décisifs, puis rapport de pilote au format des data rooms, chiffres clefs, apprentissages, limites assumées et décision tranchée : continuer, ajuster ou arrêter."
bucket: B
tags: [Produit, Vertical, Nouveau]
version: 1
maj: 2026-08-26
---

# Pilote (POC) : cadrer, mesurer, décider

## Ce qu'il faut avoir sous la main
🔒 **Les seuils se posent avant le lancement.** Un pilote dont on décide des critères de succès après coup ne prouve rien, il justifie ce qu'on avait déjà envie de faire.

- **Le produit ou le service** tel qu'il sera réellement servi pendant le pilote, même s'il est opéré à la main.
- **Ce que tu cherches à prouver** : les 3 à 5 questions auxquelles ce pilote doit répondre.
- **Le terrain envisagé** : zone, type de client, taille de cohorte accessible, durée que tu peux tenir.
- **Tes moyens** : qui opère, avec quel budget, quel niveau d'accompagnement humain.
- **Ce que tu veux** : cadrer le pilote · choisir les indicateurs · exploiter un pilote terminé.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Cadrer le périmètre

Écris la note de cadrage : ce qui est **dans** le pilote et surtout ce qui n'y est pas, la zone, le profil et la taille de la cohorte, la durée, qui opère au quotidien. Un pilote sans exclusion explicite s'étale et ne conclut rien.

Précise le **degré d'accompagnement humain** assumé : ce qui est opéré à la main pendant le pilote et ne le sera pas à l'échelle. C'est la première source de faux positifs.

Quand le pilote se construit en plusieurs temps, une première vague sur un segment, une seconde élargie, dis-le et donne à chaque temps son objectif propre.

### Étape 2 : Poser les hypothèses et les seuils go/no-go

Un tableau, rempli **avant** le lancement : hypothèse · indicateur qui la teste · seuil go · seuil no-go · où la donnée sera relevée.

Trois seuils, jamais un seul : au-dessus on continue, en dessous on arrête, entre les deux on ajuste et on reprend. Le seuil no-go est celui que personne n'écrit et c'est le seul qui protège la startup.

### Étape 3 : Choisir les indicateurs qui décident

Trois familles, et rien d'autre :
- **le funnel réel**, combien approchés, combien acquis, combien **actifs**. C'est l'écart entre acquis et actif qui dit la vérité : une startup du portefeuille a prospecté 143 commerçants, en a acquis 68 et n'en a gardé que 27 réellement actifs. Le chiffre qui compte est 27.
- **l'intensité d'usage**, fréquence, volume, ticket, sur une période nommée. « 293 transactions par semaine en moyenne » vaut mieux que « bonne traction ».
- **la répétition**, le client revient-il sans qu'on le relance. Un pilote qui ne mesure pas le retour ne mesure rien.

La traction ne se réduit pas au chiffre d'affaires : téléchargements, liste d'attente, lettres d'intention et accords de principe comptent, et sur certains modèles ils sont le seul signal disponible au stade du pilote. Mais ils se présentent **à part**, comme traction non monétaire, et **aucun seuil go ne repose sur eux seuls**, ils montent trop facilement pour pouvoir produire un no-go. Le revenu et la répétition restent le signal le plus fort quand ils sont mesurables.

### Étape 4 : Organiser la collecte

Pour chaque indicateur : qui relève, comment, à quelle fréquence, et où c'est stocké. Un pilote dont les chiffres se reconstituent de mémoire à la fin ne produit pas de rapport, il produit un récit.

### Étape 5 : Écrire le rapport de pilote

Au format qu'attendent les data rooms : **chiffres clefs**, puis **apprentissages**.

Les chiffres clefs se lisent en dix secondes : le funnel, l'intensité, la répétition, et le taux qui résume le pilote. Chaque chiffre porte sa période et sa base de calcul.

Les apprentissages sont numérotés et **comportementaux**, pas décoratifs. Le bon apprentissage ressemble à « 72 % des demandes arrivent entre le 7e et le 16e jour du mois » : il décrit un comportement daté, chiffré, qui change ce qu'on construit ensuite. « Le marché est réceptif » n'est pas un apprentissage.

### Étape 6 : Dire les limites

Ce que ce pilote ne prouve pas : taille d'échantillon, effet de nouveauté, cohorte trop proche de l'équipe, accompagnement manuel non réplicable, saison, zone atypique. Une limite assumée renforce le rapport ; une limite cachée le détruit quand l'investisseur la trouve.

### Étape 7 : Trancher

**Continuer**, **ajuster et re-tester**, ou **arrêter**, avec le chiffre qui fonde la décision et ce qui se passe concrètement ensuite. Une décision qui n'est aucune des trois n'est pas une décision.

## Format de sortie
- **Livrable** : la note de cadrage (périmètre, zone, cohorte, durée, opérateurs, accompagnement assumé), la grille hypothèses × indicateurs × seuils go/no-go remplie avant lancement, le plan de collecte, puis le rapport de pilote, chiffres clefs, apprentissages numérotés, limites, et décision continuer / ajuster / arrêter.
- **Structure** : Markdown clair, answer-first, puis le détail ; listes et tableaux quand c'est pertinent.
- **Longueur** : proportionnée à la demande, sans remplissage.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **Les seuils avant le lancement.** Une grille go/no-go produite après les résultats est signalée comme non valide.
2. **Un seuil no-go existe toujours.** Un pilote qui ne peut pas dire non n'est pas un pilote.
3. **Acquis ≠ actif.** Les deux chiffres apparaissent toujours séparément, et c'est l'actif qui sert de base aux taux.
4. **0 chiffre inventé, 0 chiffre sans base.** Chaque indicateur porte sa période et son dénominateur. Une donnée non relevée est `⟦à renseigner⟧`.
5. **Traction monétaire et non monétaire séparées.** Téléchargements, liste d'attente et lettres d'intention comptent comme traction et figurent au rapport, mais dans un tableau distinct : aucun seuil go ne repose sur eux seuls.
6. **Les apprentissages sont comportementaux.** Chiffrés, datés, et utiles à la décision suivante. Une généralité est retirée.
7. **Les limites se disent.** Notamment l'accompagnement humain du pilote qui ne tiendra pas à l'échelle.
8. **La décision est l'une des trois** : continuer, ajuster, arrêter. Jamais une formule d'attente.

**Garde-fous durs**

- **0 invention.** Aucun volume, taux, cohorte ou apprentissage fabriqué. Un pilote non mené ne se simule pas : tu produis le cadrage, pas des résultats.
- **0 fausse source.** Ne présente jamais un chiffre comme relevé sur le terrain sans l'avoir lu dans une source branchée ou reçu de l'utilisateur. Si la donnée est inaccessible, dis-le et signale le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres le cadrage complet, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante en autonomie.** Tu prépares et exploites le pilote ; son lancement, le recrutement de la cohorte et la diffusion du rapport restent des décisions de l'utilisateur.
- **Cloisonnement.** Les chiffres de pilote d'une startup ne fuitent jamais vers une autre startup traitée dans la même conversation.

## Cas limites
- **Input incomplet**, tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Donnée introuvable**, tu le dis explicitement et tu poursuis sur le reste. Une donnée absente n'est jamais remplacée par une valeur plausible.
- **Source ou connecteur inaccessible**, tu signales le trou et tu travailles avec ce que l'utilisateur t'a donné. Tu ne présentes jamais un élément comme sourcé sans l'avoir lu.
- **Demande hors périmètre**, tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (envoi, publication, paiement, partage externe), tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires**, tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
