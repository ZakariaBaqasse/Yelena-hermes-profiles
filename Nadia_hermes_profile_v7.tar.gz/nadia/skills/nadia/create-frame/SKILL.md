---
id: Y0113
name: create-frame
description: Transforme une réponse en artefact interactif autoportant (Frame), dashboard, calculateur, rapport ou visualisation qu'on explore et partage par lien.
bucket: B
tags: [Production & artefacts, Data & Analytics]
version: 1
maj: 2026-08-26
---

# create-frame : l'artefact interactif (Frame maison)

> **Skill maison Yelema.** C'est notre recréation de
> l'expérience « Frame » : un output vivant (HTML interactif) plutôt qu'un mur de texte.
> Le savoir-faire est à nous, la recette technique ci-dessous ne dépend d'aucun outil tiers.

## Ce qu'il faut avoir sous la main
1. **Objet du Frame** : ce qu'on doit pouvoir voir / faire (ex. « dashboard des KPI du mois », « calculateur de ROI », « rapport comparables cliquable »).
2. **Données** : le contenu réel (colle un CSV/JSON, un tableau, ou des chiffres), ou dis « pas de données, génère un exemple représentatif et signale-le ».
3. **Interactivité voulue** : statique joli / filtres & survol / saisie & calcul en direct / plusieurs vues.
4. **Sortie attendue** : fichier HTML à ouvrir · **lien public partageable** · export **PDF/PNG** · ou les trois.
5. **Marque** (optionnel) : Yelema par défaut, ou une charte fournie (couleurs/police/logo).


**Ce qu'elle suppose comme accès** : Pour publier un lien, Pour exporter. Tout n'est pas branché : ce qui manque se dit au client plutôt que de se contourner en silence.

## Process
1. **Cadrer** l'artefact : 1 écran ? plusieurs sections ? quels éléments interactifs ? quelle donnée pilote quoi.
2. **Structurer les données** : normaliser l'entrée (CSV/JSON/tableau) en une structure JS embarquée dans le fichier (`const DATA = [...]`). Ne jamais charger depuis un serveur externe (le Frame doit marcher hors-ligne et en partage).
3. **Construire le HTML autoportant** :
   - Un seul fichier `.html`, **tout inline** : `<style>` pour le CSS, `<script>` pour la logique, données en variable JS.
   - **Interactivité sans dépendance lourde** : vanilla JS pour filtres/onglets/calcul ; graphes en **SVG inline** (barres/lignes/donut dessinés à la main), robuste, zéro CDN. Si React est vraiment nécessaire, importmap `esm.sh` (react/react-dom), mais par défaut, vanilla.
   - **Responsive** : unités relatives, fl*box/grid, `max-width:100%`, tableaux/large contenu dans un conteneur `overflow-x:auto`.
   - **Thème clair/sombre** via `@media (prefers-color-scheme)`.
4. **Marque** : appliquer les tokens Yelema (voir Règles) ou la charte fournie ; jamais de style « défaut navigateur ».
5. **Livrer selon la sortie demandée** (voir Format de sortie) : fichier seul, lien public, et/ou export PDF/PNG.
6. **QA obligatoire** : ouvrir le rendu (screenshot) et **le regarder** avant de livrer, vérifier qu'aucune section ne déborde, que les interactions marchent, que les chiffres affichés = les données d'entrée.

## Format de sortie
- **Livrable principal** : un fichier `.html` **autoportant** (aucune ressource externe requise pour l'afficher).
- **Lien public partageable** (si demandé) : deux voies, au choix
  - **Artifact** (le plus simple, hébergé, privé par défaut, partage en un clic) quand l'environnement expose l'outil Artifact ;
  - **GitHub Pages** (compte `leslita06`, `.nojekyll`, publication depuis un dossier `/tmp` isolé) pour un lien pérenne. Prévenir que le lien est **public/non-indexé**.
- **Export PDF/PNG** (si demandé) : `WeasyPrint` (HTML→PDF) pour le PDF ; `playwright-core`/chromium screenshot d'un `.section` pour le PNG.
- **Support** : réponse directe d'abord (« voici le Frame + comment l'ouvrir »), puis le fichier/lien.
- **Règle 0 invention** : aucune donnée chiffrée inventée. Donnée absente → générer un exemple **clairement étiqueté « exemple »**, ou la demander, jamais présentée comme réelle.

## Règles
- **Autoportant, point.** Zéro dépendance réseau à l'affichage : pas de `<script src=cdn>`, pas de police Google en `<link>`, pas de `fetch()` distant. Tout inline. Un Frame qui ne s'ouvre pas hors-ligne est un Frame raté.
- **Données = vérité d'entrée.** Le Frame ne fabrique pas de chiffres ; il met en scène ceux qu'on lui donne. Toute valeur d'exemple est marquée comme telle.
- **Marque Yelema par défaut** : INK `#301667` · VIOLET `#8D68FA` · LAVANDE `#C5C4FF` · BLEU `#2E4EC4` · CORAIL `#E4765A` (accent chaud) ; titres **Space Grotesk**, corps **Funnel Display** (fallbacks système inline). Charte fournie → elle prime.
- **Beau et sobre** : hiérarchie claire, espaces, pas de surcharge. On vise « on dirait un vrai produit », pas « slide PowerPoint ».
- **Accessibilité** : contrastes suffisants, taille de police lisible, focus visible sur les contrôles.
- **Confidentialité** : si les données sont sensibles, ne PAS générer de lien public sans validation explicite, livrer le fichier local.

**Garde-fous durs**

- **0 fausse source.** Ne jamais présenter un chiffre ou un fait comme « sourcé / vérifié » sans source primaire réelle. Un chiffre déduit ou repris d'une mémoire non recoupée → « à confirmer avec l'équipe », en particulier un financier (CA, levée, valorisation, effectifs, volumes).

## Cas limites
- **Beaucoup de données** (>quelques centaines de lignes) : paginer / filtrer côté client, ne pas tout rendre d'un coup ; garder le fichier raisonnable.
- **Vrai besoin de React/graphes complexes** : importmap `esm.sh` + shims locaux ; tester en **HTTP** (le `file://` bloque les modules ES). Sinon, rester en vanilla+SVG.
- **Pas d'outil de hosting disponible** : livrer le `.html` autoportant + expliquer en une ligne comment l'ouvrir/partager ; ne pas bloquer.
- **Dégradés SVG multipages en PDF** : sous WeasyPrint, préférer un dégradé CSS sur `<div>` (les `<linearGradient url(#)>` inline rendent de façon non déterministe).

## Détails complémentaires
### Positionnement
Notre valeur : un artefact **portable et sans lock-in** (HTML autoportant hébergeable où on veut, exportable PDF/PNG), pas une fonctionnalité liée à une plateforme. Réutilisable comme SKU Yelema.
