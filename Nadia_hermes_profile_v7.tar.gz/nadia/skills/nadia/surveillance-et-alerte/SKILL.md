---
id: Y0441
name: surveillance-et-alerte
description: "Met un indicateur déjà défini sous surveillance et décide quand parler entre deux rapports : ce qui est considéré comme normal et d'où vient cette normalité, l'écart qui déclenche, qui est prévenu, ce que l'alerte doit contenir pour être actionnable, et la règle anti-bruit qui empêche qu'on apprenne à les ignorer. Traite aussi la panne silencieuse — la source qui s'arrête d'alimenter et laisse la métrique parfaitement stable — sans jamais fixer un seuil de sa propre autorité."
bucket: B
tags: [Données, Indicateurs, Horizontal, Nouveau]
version: 1
maj: 2026-09-09
---

# Le rapport du lundi arrive trop tard pour ce qui s'est cassé mardi

## Ce qu'il faut avoir sous la main
- **L'indicateur** et sa définition si elle est écrite. Si elle ne l'est pas, dis-le : on ne surveille pas un mot, on surveille une définition.
- **Son historique** : les valeurs des dernières périodes, autant que tu en as. C'est la seule matière qui permet de mesurer ce qui est normal au lieu de l'inventer.
- **Ce qui se passe quand ça dérape** : qui décide, quel geste est possible, et en combien de temps ce geste produit un effet.
- **Qui doit être prévenu**, nommément, et par quel canal il lit réellement ses messages.
- **Ce qui a déjà été raté** faute d'avoir vu à temps : c'est le meilleur guide pour savoir quoi surveiller en premier.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `⟦à renseigner⟧`. Tu ne redemandes que ce qui est réellement indispensable.

## Process
### Étape 1, Vérifier que l'indicateur mérite une alerte
Poser la question dans cet ordre, et s'arrêter dès qu'une réponse manque : *que ferait-on, concrètement, dans l'heure qui suit l'alerte ?* Si personne ne sait, ou si la réponse est « on regarderait de plus près », l'indicateur mérite un tableau de bord, pas une alerte. Le dire franchement et proposer de le laisser dans le rapport périodique.

Trois conditions doivent tenir ensemble pour qu'une surveillance se justifie : un geste correctif existe, quelqu'un a le pouvoir de le faire, et ce geste produit un effet plus vite que le prochain rapport. Si la correction prend trois semaines et que le rapport sort chaque lundi, l'alerte n'achète rien.

Voir `definir-un-indicateur` si la définition n'est pas écrite : surveiller un indicateur mal défini produit des alertes sur un changement de méthode de calcul, pas sur un événement réel.

### Étape 2, Établir ce qui est normal, et dire d'où ça vient
C'est l'étape qui décide de la valeur de tout le reste. Deux voies légitimes, et une seule interdite.

Voie mesurée. Avec un historique suffisant, la normalité se lit : l'amplitude habituelle des variations d'une période à l'autre, le niveau bas et le niveau haut atteints hors incident, et la saisonnalité si elle existe. Écrire combien de périodes ont servi, et sur quelle plage de dates. Une normalité mesurée sur six points n'a pas le même statut qu'une normalité mesurée sur deux ans, et la fiche doit permettre au lecteur de le savoir.

Voie déclarée. Sans historique, ou quand la décision appartient à l'entreprise (un seuil de trésorerie, un délai contractuel), la valeur se fait dire. Écrire qui l'a donnée et quand.

Voie interdite : l'ordre de grandeur qui « paraît raisonnable ». Tant que la valeur n'est ni mesurée ni donnée, elle reste `⟦à renseigner⟧`, et une fiche qui porte ce marqueur est un livrable correct, pas un livrable inachevé.

⚠ Deux pièges de terrain. La saisonnalité locale déforme la normalité : mois de rentrée scolaire, fêtes de fin d'année, saison des pluies dans les métiers de terrain, périodes de forte activité administrative. Une alerte calée sur une moyenne annuelle se déclenche chaque année aux mêmes dates, pour une raison connue de tous, et se fait désactiver. Et un historique qui contient un incident non signalé enseigne l'incident comme une normalité : demander explicitement si la période observée contient un événement exceptionnel, et l'écarter du calcul en le disant.

### Étape 3, Choisir la forme de l'écart
Trois formes, qui ne détectent pas la même chose. Le choix se justifie par ce qu'on cherche à attraper, pas par l'habitude.

Le franchissement de niveau, la valeur passe sous ou au-dessus d'un point fixe, convient à ce qui a un plancher réel : une trésorerie, un stock de sécurité, un délai contractuel. Il est lisible par tous et se discute facilement.

L'écart à l'habitude, la valeur s'éloigne de son amplitude ordinaire, attrape ce qui n'a pas de plancher naturel : un taux de réponse, un panier moyen, un volume d'appels. Il demande de l'historique.

La tendance, plusieurs périodes consécutives dans le même sens, attrape la dérive lente, celle qui ne franchit jamais rien et qui est pourtant la plus coûteuse. C'est la forme la plus utile et la moins employée.

Pour chaque forme, fixer aussi la durée de confirmation : combien de temps ou combien de points l'écart doit tenir avant qu'on parle. Sans elle, une valeur qui oscille autour du seuil produit une alerte à chaque passage.

### Étape 4, Traiter la panne silencieuse
C'est le cas que presque toutes les surveillances oublient, et le plus dangereux. Quand la source cesse d'alimenter, un export qui ne tourne plus, un fichier qui n'arrive plus, un système en panne, la métrique ne dérape pas : elle se fige, et un chiffre stable ressemble à un chiffre sain. Personne n'alerte, et l'entreprise pilote plusieurs semaines sur une valeur morte.

Toute fiche de surveillance porte donc, en plus de son écart, une alerte de fraîcheur : à partir de quel délai sans donnée nouvelle on considère que la source est muette, et qui est prévenu, la personne qui maintient la source, pas celle qui lit l'indicateur. Écrire aussi la conduite à tenir pendant le silence : ce qui est suspendu, et le fait que tout chiffre produit dans l'intervalle porte la mention qu'il est périmé.

Le même raisonnement vaut pour la valeur aberrante : un chiffre cent fois trop grand n'est pas un événement métier, c'est presque toujours une erreur de saisie ou d'unité. La fiche dit à quoi on la reconnaît et vers qui elle part.

### Étape 5, Écrire le message d'alerte
Une alerte qui oblige à ouvrir un tableau de bord pour être comprise n'a pas fait son travail. Cinq éléments, dans cet ordre, et rien de plus :

1. **Ce qui se passe** en une phrase, avec le chiffre et sa date.
2. **De combien ça s'écarte** de la normale, avec la normale rappelée à côté.
3. **Depuis quand**, parce que c'est ce qui distingue l'accident du glissement.
4. **Ce qu'on ne sait pas encore** : la cause probable si elle est établie, et sinon le dire. Une alerte qui affirme une cause non vérifiée envoie le destinataire réparer le mauvais problème.
5. **Le geste attendu**, et de qui.

Aucune interprétation qui ne soit pas soutenue par la donnée. « Les ventes baissent de 18 % depuis trois jours » est une alerte ; « les ventes baissent parce que le concurrent a ouvert » est une hypothèse, et elle s'écrit comme telle ou pas du tout.

### Étape 6, Régler le débit, pas seulement le seuil
Fixer un plafond d'alertes par semaine et par destinataire. Le dépasser n'est pas un incident de plus, c'est le signal que le réglage est mauvais : la fiche prévoit qu'au-delà du plafond on révise les seuils au lieu de continuer à émettre.

Prévoir également la fin de l'alerte : une situation qui revient dans sa plage produit un message de retour à la normale. Sans lui, personne ne sait si le problème est réglé, et l'absence de nouvelles finit par être lue comme une panne du dispositif.

Et prévoir le silence volontaire : une période où l'écart est attendu (un inventaire, une fermeture, une opération commerciale) se déclare à l'avance et suspend l'alerte, en le disant. Une alerte désactivée sans trace est une surveillance qui a cessé d'exister sans que personne ne le sache.

### Étape 7, Fixer la revue
Une surveillance se dégrade : l'activité change, la normalité d'il y a six mois devient fausse. Inscrire une date de revue, et la question qu'on s'y posera : combien d'alertes ont été émises, combien ont donné lieu à un geste, et combien d'événements réels n'ont pas été vus. Le rapport entre ces trois nombres est la seule mesure honnête de la qualité du réglage.

## Format de sortie
- **Livrable principal** : la fiche de surveillance, une par indicateur : indicateur surveillé et renvoi à sa définition · geste correctif possible et qui le porte · normalité retenue, sa valeur, et par quelle voie elle a été établie (mesurée sur N périodes du … au … / déclarée par … le …) · forme de l'écart et durée de confirmation · alerte de fraîcheur et son délai · destinataire nommé et canal · plafond hebdomadaire · règle de retour à la normale · périodes de silence prévues · date de revue.
- **Livrable secondaire** : le gabarit du message d'alerte, rempli avec un exemple tiré de l'historique fourni, pour que le destinataire voie ce qu'il recevra.
- **Structure** : Markdown, une fiche = un bloc structuré ou un tableau. Answer-first : ce qu'on surveille et à partir de quand, avant la justification.
- **Longueur** : une fiche tient sur une portion de page. Une surveillance qui demande deux pages d'explication est une surveillance mal réglée.
- **Les seuils sont un input**, jamais une production : la fiche livre la structure et la valeur reste `⟦à renseigner⟧` tant qu'elle n'est ni mesurée ni donnée.
- **Règle 0 invention** : aucun chiffre, taux ou seuil produit sans être fourni, mesuré sur des données reçues, ou sourcé. Toute donnée manquante est marquée `⟦à renseigner⟧` ou `[à confirmer]`.

## Règles
1. **Pas d'alerte sans geste.** Si personne ne peut agir dans un délai plus court que le prochain rapport, l'indicateur reste au tableau de bord. Une alerte sans suite possible est du bruit qui se déguise en vigilance.
2. **La normalité se mesure ou se fait dire, jamais s'invente**, et la fiche écrit laquelle des deux voies a servi, avec le nombre de périodes ou le nom de la personne.
3. **Toute surveillance porte une alerte de fraîcheur.** Une source muette laisse une métrique parfaitement stable ; sans ce garde, l'entreprise pilote sur un chiffre mort sans le savoir.
4. **Une durée de confirmation est toujours fixée.** Sans elle, une valeur qui oscille autour du seuil alerte à chaque passage et détruit la crédibilité du dispositif.
5. **L'alerte se suffit à elle-même.** Le chiffre, l'écart, depuis quand, ce qu'on ignore, le geste attendu. Si le destinataire doit ouvrir un tableau pour comprendre, l'alerte est ratée.
6. **Aucune cause affirmée sans preuve.** Une hypothèse s'écrit comme une hypothèse. Envoyer quelqu'un réparer le mauvais problème coûte plus cher que de ne rien dire.
7. **Le retour à la normale s'annonce aussi.** Sans lui, personne ne distingue un problème réglé d'un dispositif en panne.
8. **Le plafond dépassé se traite en révisant le réglage**, pas en continuant d'émettre. Trop d'alertes est un défaut de conception, pas un excès de zèle.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou seuil fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette compétence produit une fiche de réglage et un gabarit. Brancher réellement une alerte, envoyer un message à un destinataire, modifier un système de supervision sont des actions validées par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun historique disponible** tu ne mesures rien : tu écris la structure complète, tu marques la normalité `⟦à renseigner⟧`, et tu proposes une période d'observation à blanc, la surveillance tourne sans alerter, et on règle les seuils sur ce qu'elle a vu.
- **Historique trop court ou trop irrégulier pour porter une conclusion** tu le dis avec le nombre de points dont tu disposes, plutôt que de calculer une amplitude sur trois valeurs et de la présenter comme une normalité.
- **L'historique contient un incident non signalé** tu demandes confirmation avant de l'écarter ; un incident conservé dans le calcul enseigne l'anomalie comme normale et rend la surveillance aveugle à sa répétition.
- **Le destinataire demande à être prévenu de tout** tu exposes le compte d'alertes que cela produirait sur l'historique fourni, et tu laisses le chiffre faire l'argument.
- **Deux indicateurs déclenchent toujours ensemble** c'est une seule alerte, pas deux : tu le signales et tu proposes de n'en garder qu'une, avec l'autre en contexte dans le message.
- **La donnée n'est disponible qu'une fois par semaine** une alerte n'apporte alors rien de plus que le rapport : tu le dis et tu proposes soit de renoncer, soit de traiter d'abord la fréquence de la source.
- **Demande hors périmètre** (définir l'indicateur, construire le tableau de bord, produire le rapport périodique) tu le dis en une phrase, tu traites ce qui relève de la surveillance, et tu orientes vers `definir-un-indicateur`, `du-tableur-au-tableau-de-bord` ou la compétence de reporting du poste.
- **Action sortante demandée** (activer l'alerte, envoyer le premier message) tu prépares et tu t'arrêtes pour validation humaine.
- **Sources contradictoires sur la valeur historique** tu exposes les deux séries et tu demandes l'arbitrage : régler un seuil sur la mauvaise série produit une surveillance fausse pendant des mois sans que rien ne le signale.
