---
id: Y0440
name: ce-qui-ne-se-mesure-pas
description: "Cartographie ce qui n'est pas mesuré dans l'activité (vente en cash, commande sur WhatsApp, bouche-à-oreille, agent informel) : pourquoi ça ne se mesure pas, ce que ça coûte de décider sans, quelle instrumentation légère est possible, et quelle réserve écrire dans le rapport. Traite en particulier la confusion entre absence de mesure et absence d'effet, sans jamais transformer une estimation en fait ni combler un trou par un chiffre inventé."
bucket: B
tags: [Données, Méthode, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Nommer l'angle mort plutôt que le combler par une estimation

## Ce qu'il faut avoir sous la main
- **Le sujet ou la décision** que l'analyse doit éclairer (arbitrage entre canaux, évaluation d'une campagne, bilan d'activité, choix d'investissement).
- **Les sources de données disponibles** et ce qu'elles couvrent exactement : caisse, mobile money, CRM, tableur tenu à la main, rien du tout sur certains canaux.
- **Ce que tu soupçonnes mal mesuré** : commandes prises sur WhatsApp, ventes au comptant chez un revendeur informel, recommandations orales, activité d'un agent terrain, retombées d'un passage radio.
- **Les chiffres déjà en circulation** sur ces zones, s'il y en a, et qui les a produits.
- **À qui s'adresse le document final** (comité de direction, bailleur, équipe interne) : ça change la façon d'écrire la réserve.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni, même partiel, tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement.

## Process
### Étape 1 : Cartographier ce qui n'est pas mesuré, et pourquoi
Pour chaque canal, circuit ou activité concerné, pose trois questions : est-ce mesuré, partiellement mesuré, ou pas du tout ; par quel système si c'est mesuré ; et surtout, pourquoi ce n'est pas mesuré quand ça ne l'est pas. La raison change tout : un canal peut être hors mesure parce qu'aucun système n'existe (aucune caisse enregistreuse chez le revendeur du marché), parce que le canal est informel par nature (le client paie en espèces à un agent qui ne tient pas de registre), ou parce que quelqu'un devrait saisir et ne le fait pas (l'agent terrain vend par WhatsApp mais n'entre rien dans le CRM). Trois raisons, trois remèdes différents : traiter les trois comme un même problème donne une instrumentation qui ne marchera pour aucune.

### Étape 2 : Chiffrer ce que coûte l'absence
Identifie les décisions qui s'appuient, en partie ou en totalité, sur cette zone aveugle. C'est ici que se loge le premier piège du métier : le canal instrumenté paraît meilleur que le canal non instrumenté non pas parce qu'il rapporte plus, mais parce qu'il est le seul dont on sache parler avec un chiffre. Une organisation qui arbitre budget et attention sur cette seule base coupe, année après année, ce qui la faisait vivre au profit de ce qui remplit un tableau. Nomme explicitement, pour chaque angle mort, le risque d'erreur d'arbitrage qu'il fait courir : sous-investir dans un canal réel, sur-investir dans un canal qui n'est visible que parce qu'il est tracé.

### Étape 3 : Séparer mesuré et supposé, traiter l'attribution
Si des chiffres circulent déjà pour combler ces trous, sépare-les visuellement de ce qui est mesuré : jamais une estimation sans son hypothèse et son auteur. Une hypothèse posée dans une case de tableau devient un fait au bout de deux réunions si personne ne la marque comme telle.

Traite ensuite l'attribution, qui est l'erreur la plus fréquente une fois qu'on a des chiffres partiels : quand un résultat a pu venir de plusieurs sources à la fois (une annonce radio, un partage WhatsApp, une recommandation au marché), attribuer la totalité à celle qui laisse une trace numérique (le code promo scanné, le clic sur un lien) est une erreur systématique, pas une approximation acceptable. Dis ce qui est attribuable proprement et nomme le reste comme non attribué, sans le faire disparaître.

### Étape 4 : Distinguer les trois lectures du silence
Une donnée absente ou une courbe à zéro peut vouloir dire trois choses opposées : il ne s'est rien passé, quelqu'un ne saisit pas ce qui se passe, ou le système de collecte était défaillant (agence coupée par une panne réseau, agent mobile money qui n'a pas fait sa réconciliation, comptage manuel non tenu pendant une semaine de forte affluence). Ces trois cas appellent des conclusions et des actions opposées. Le seul moyen de trancher est d'aller vérifier la collecte sur le terrain, pas de raisonner sur le tableau vide : signale la question précise à poser (a-t-on vérifié que le point de vente était ouvert, que le réseau fonctionnait, que quelqu'un a saisi) plutôt que de conclure toi-même.

### Étape 5 : Proposer une instrumentation légère, classée par coût
Classe les propositions du moins coûteux au plus lourd. En bas de l'échelle : un numéro de téléphone ou un compte WhatsApp dédié pour tracer les commandes qui arrivent hors caisse, une question posée au comptoir (« comment avez-vous connu la boutique »), un code à mentionner à l'oral en fin d'appel radio, un comptage manuel tenu une semaine par trimestre par le vendeur du marché. Plus haut sur l'échelle : un carnet de suivi structuré pour un agent terrain, une réconciliation hebdomadaire des transactions mobile money par point de vente.

Pour chaque proposition, écris deux choses : ce qu'elle permettra de dire une fois en place, et ce qu'elle ne permettra toujours pas de dire, même après mise en œuvre. Une instrumentation qui coûte plus cher en temps de saisie ou en discipline qu'elle n'apporte de clarté ne sera jamais tenue durablement : le vendeur du marché a autre chose à faire pendant l'affluence, l'agent terrain n'a souvent qu'un téléphone d'entrée de gamme et une connexion coûteuse, mieux vaut une case à cocher qu'un formulaire.

### Étape 6 : Écrire la réserve, là où le chiffre est lu
Rédige la formulation de réserve à insérer directement dans le rapport, à l'endroit où le chiffre concerné apparaît, pas reléguée en annexe où elle ne sera jamais lue. Adapte le registre au destinataire : une phrase courte et directe pour un comité qui lit vite, une formulation plus détaillée avec la source du doute pour une équipe interne qui doit décider de l'instrumentation à financer. Une analyse dont les limites ne sont pas écrites à l'endroit où on la cite sera reprise sans elles.

## Format de sortie
- **Livrable** : la carte des angles morts (canal ou activité, ce qui est mesuré ou non, pourquoi, décision affectée, coût estimé de l'erreur d'arbitrage) ; les propositions d'instrumentation classées du moins coûteux au plus lourd, chacune avec ce qu'elle permettra de dire et ce qu'elle ne permettra pas ; les formulations de réserve prêtes à insérer, adaptées au niveau de lecture indiqué.
- **Structure** : Markdown, answer-first (la carte des angles morts et son coût d'abord, les propositions et les réserves ensuite) ; tableau pour la carte, liste ordonnée par coût pour l'instrumentation.
- **Longueur** : proportionnée au nombre d'angles morts identifiés, sans remplissage. Un cas simple tient sur une page.
- **Toute estimation citée dans le livrable porte son hypothèse et son auteur**, visuellement séparée de ce qui est mesuré.
- **Règle 0 invention** : aucun chiffre comblant un trou n'est produit par la skill elle-même. Ce qui manque reste `⟦à renseigner⟧` ou `[à confirmer]`.

## Règles
1. **Le canal instrumenté n'est pas automatiquement le meilleur.** Il est seulement celui dont on sait parler avec un chiffre. Tu rappelles cette distinction chaque fois qu'un arbitrage budgétaire s'appuie sur la seule disponibilité des données.
2. **Aucune estimation sans hypothèse ni auteur.** Une case remplie dans un tableau pour combler un trou est étiquetée comme telle, sinon elle devient un fait au fil des relectures.
3. **L'attribution ne va jamais en totalité à la source traçable** quand plusieurs causes ont pu produire le résultat. Tu dis ce qui est attribuable proprement et tu nommes le reste comme non attribué.
4. **Le silence n'est pas un signal univoque.** Absence de mesure, absence de saisie et panne de collecte appellent des conclusions opposées ; tu poses la question de vérification terrain, tu ne tranches pas depuis le tableau.
5. **L'instrumentation proposée commence par la plus légère.** Un instrument qui coûte plus en discipline de saisie qu'il n'apporte de clarté ne sera pas tenu ; tu le dis avant de le recommander.
6. **La réserve s'écrit dans le corps du document, à l'endroit où le chiffre est lu**, jamais reléguée en annexe où elle ne protège plus personne.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déployer une instrumentation, contacter des agents ou modifier un système de collecte est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une organisation ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucune donnée du tout sur un canal** : tu produis quand même la carte, tu marques la case « mesuré » à zéro, et tu proposes l'instrumentation la plus légère en premier. L'absence totale de mesure est un résultat, pas un blocage.
- **Un chiffre est déjà présenté comme un fait dans les documents fournis** : tu le retraces à sa source ; si c'est une estimation non déclarée comme telle, tu le signales explicitement avant de continuer.
- **Le destinataire du rapport n'est pas précisé** : tu rédiges la réserve dans un registre neutre et signales que la formulation peut être ajustée selon le lecteur final.
- **Une instrumentation proposée suppose une capacité de saisie qui n'existe pas sur le terrain** (pas de smartphone, connexion instable, forte rotation du personnel) : tu le dis et tu redescends d'un cran vers l'option la plus manuelle.
- **On te demande de « donner quand même un ordre de grandeur »** pour l'angle mort : tu expliques pourquoi tu ne le fais pas sans source, tu proposes la méthode qui permettrait de l'obtenir, et tu laisses la valeur en `⟦à renseigner⟧`.
- **Les données disponibles se contredisent** entre deux systèmes (caisse et mobile money par exemple) : tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
- **Une pièce annoncée mais absente** (« voici l'export de caisse », rien n'est joint) : tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Demande hors périmètre** (on te demande de chiffrer un marché ou de fixer un budget d'instrumentation) : tu le dis en une phrase, tu traites ce qui relève de ton champ, et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (déployer un outil, contacter des agents terrain, modifier un système) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
