---
id: Y0703
name: interroger-une-base-de-donnees
description: "Interroge en lecture seule une base de données ou un logiciel de gestion (PostgreSQL, MySQL/MariaDB, SQLite, fichiers CSV/Parquet volumineux via DuckDB, export d'ERP ou de caisse) : obtention d'un accès en lecture, découverte du schéma, requêtes SQL rejouables avec leur résultat, extraction vers un tableur ou un jeu de travail, et journal des requêtes. N'écrit jamais dans une base, ne stocke jamais un mot de passe hors du coffre, et refuse un accès plus large que la lecture."
bucket: B
tags: [Données, SQL, Bases de données, Horizontal, Nouveau]
version: 1
maj: 2026-09-21
---

# Aller chercher le chiffre là où il naît, sans rien y toucher

## Ce qu'il faut avoir sous la main
- **Où vit la donnée** : nom du logiciel (caisse, ERP, comptabilité, CRM, application maison), type de base si connu, qui l'administre.
- **Un accès en lecture seule** : compte dédié, droit SELECT uniquement, sur les tables utiles. Si la maison ne sait pas le créer, tu écris la demande pour son informaticien ou son prestataire.
- **La question métier** qui justifie la requête, et l'indicateur défini (`definir-un-indicateur`) qu'elle doit produire.
- **À défaut d'accès direct** : un export (CSV, Excel, sauvegarde SQLite) ; DuckDB permet de le requêter en SQL sans rien installer chez le client.

> ⚡ **Sans accès, tu produis quand même** : les requêtes écrites, prêtes à être exécutées par la personne qui a l'accès, avec ce qu'elles renvoient et comment te transmettre le résultat.

## Process
### Étape 1, Obtenir l'accès, et seulement celui-là
Le compte de lecture est demandé par écrit, avec le périmètre (tables, schéma, éventuellement une vue préparée par le prestataire) et la durée. Le mot de passe va dans `~/.config/agents/secrets/<service>.txt` (chmod 600) et dans `secrets.env`, jamais dans un script, un message ou un tableur. Un accès qui permettrait d'écrire se refuse et se signale : la maison ne doit pas dépendre d'une erreur de frappe.

L'appel au service passe par un script du dossier `integrations/<nom>/`, avec son `check.py` en lecture pure (la liste des tables suffit) et son README.

### Étape 2, Découvrir le schéma avant de requêter
Liste des tables, colonnes, types, clés, volumes (`information_schema`, `\d`, `SHOW CREATE TABLE`, `PRAGMA table_info`). Puis un échantillon de chaque table utile et un profil rapide (`qualite-de-la-donnee`) : une base « propre » a aussi ses doublons, ses statuts obsolètes et ses dates de test. Ce qu'un champ veut dire se demande à la personne qui l'utilise, pas à son nom.

### Étape 3, Écrire des requêtes lisibles et rejouables
- Une requête = un fichier `.sql` commenté : la question, la date, la définition d'indicateur appliquée, les exclusions (annulés, tests, internes).
- Dates de rattachement explicites (`commande`, `facture`, `encaissement`), fuseau déclaré.
- Agrégats vérifiés contre un total connu (un mois déjà publié) avant d'aller plus loin.
- `LIMIT` et filtres de période sur toute requête exploratoire ; pas de `SELECT *` sur une table de mouvements.
Outil : `~/.venv-office/bin/python` avec `sqlalchemy`, `psycopg2`, `pymysql`, `duckdb`, `pandas`.

### Étape 4, Extraire et livrer
Le résultat va dans un tableur (`tableur-livrable`) ou dans un jeu de travail, avec en première ligne la requête, la date d'exécution et le nombre de lignes. Une extraction qui contient des données personnelles se limite aux champs nécessaires et se partage au strict périmètre (`donnees-personnelles-ci`, `partage-et-acces`).

### Étape 5, Tenir le journal
`integrations/<nom>/requetes/` garde chaque requête et son résultat daté. Un chiffre présenté en comité doit pouvoir être reproduit six mois plus tard avec la même requête.

## Format de sortie
- **Demande d'accès** prête à envoyer (à valider par la maison avant envoi).
- **Carte du schéma** : tables utiles, ce qu'elles contiennent, comment elles se joignent, ce qui manque.
- **Requêtes `.sql`** commentées et leur résultat en tableur.
- **Journal des requêtes** dans le dossier d'intégration.

## Règles
1. **Lecture seule, toujours.** Aucune requête `INSERT`, `UPDATE`, `DELETE`, `ALTER`, même « pour corriger une virgule ». Une correction se propose (`qualite-de-la-donnee`) et se fait par la maison dans son outil.
2. **Aucun secret hors du coffre**, aucune chaîne de connexion dans un message.
3. **Une requête se contrôle contre un chiffre connu** avant d'être présentée.
4. **Un export n'est pas la base** : sa date et son périmètre s'écrivent sur le livrable.
5. **Une base de production ne se sature pas** : requêtes bornées, exécutées hors des heures de pointe si le prestataire le demande.

## Cas limites
- **Logiciel sans accès à sa base** (caisse fermée, logiciel en ligne) : l'export périodique est la seule voie ; tu proposes la cadence et le format, et tu documentes ce qu'on perd.
- **Base de prestataire** : la demande d'accès passe par lui, avec la maison en copie ; tu ne négocies pas les droits à sa place.
- **Schéma incompréhensible** (noms de colonnes codés) : tu demandes le dictionnaire de données ou la personne qui l'a écrit, et tu commences `dictionnaire-de-donnees` avec ce que tu comprends.

## Références
- `references/requetes-types.sql` : banque de requêtes (contrôles de qualité, vue nettoyée qui marque sans supprimer, indicateurs avec parts et variations, top N par groupe, cohortes, RFM, entonnoir, appariement de deux sources), PostgreSQL avec notes MySQL / SQLite / DuckDB.
