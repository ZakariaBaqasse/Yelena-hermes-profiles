-- =====================================================================
-- Banque de requêtes types (PostgreSQL ; notes MySQL / SQLite / DuckDB en fin)
-- Techniques reprises de portfolios publics d'analystes (SaifulIslamDS,
-- STCybersec, ryniewiczg, relus le 21/09/2026) et adaptées aux règles du poste :
--   * les seuils, bandes et catégories sont des décisions de la maison → ⟦à renseigner⟧
--   * on ne supprime pas dans la base : une vue « nettoyée » FILTRE et MARQUE, la table brute reste
--   * chaque requête est datée et commentée : la question, la définition appliquée, les exclusions
-- Remplacer <table>, <date>, <montant>, <client>, <id> par les noms réels (voir dictionnaire-de-donnees).
-- =====================================================================

-- ─────────────────────────────────────────────────────────────────────
-- A. CONTRÔLES DE QUALITÉ (avant toute analyse, résultats à reporter dans le rapport de qualité)
-- ─────────────────────────────────────────────────────────────────────

-- A1. Volume
SELECT COUNT(*) AS lignes FROM <table>;

-- A2. Remplissage par champ (NULL ou vide après TRIM) — une colonne par champ
SELECT
  COUNT(*) FILTER (WHERE <date> IS NULL)                               AS date_vide,
  COUNT(*) FILTER (WHERE <client> IS NULL OR TRIM(<client>) = '')      AS client_vide,
  COUNT(*) FILTER (WHERE <montant> IS NULL)                            AS montant_vide,
  COUNT(*) FILTER (WHERE <statut> IS NULL OR TRIM(<statut>) = '')      AS statut_vide
FROM <table>;

-- A3. Doublons stricts (toutes colonnes identiques) — doublons PROBABLES tant qu'il n'y a pas d'identifiant fiable
SELECT COUNT(*) - COUNT(DISTINCT (<date>, <client>, <produit>, <qte>, <montant>, <ref>)) AS lignes_identiques_en_trop
FROM <table>;

-- A3 bis. Doublons CERTAINS sur identifiant fiable (numéro de facture, de transaction)
SELECT <id>, COUNT(*) AS n FROM <table> GROUP BY <id> HAVING COUNT(*) > 1 ORDER BY n DESC;

-- A4. Période réellement couverte (et trous : voir A7)
SELECT MIN(<date>) AS debut, MAX(<date>) AS fin, COUNT(DISTINCT <date>) AS jours_avec_donnees FROM <table>;

-- A5. Distribution des valeurs d'un champ catégoriel (orthographes multiples se voient ici)
SELECT <statut>, COUNT(*) AS n FROM <table> GROUP BY <statut> ORDER BY n DESC;

-- A6. Règle de cohérence entre champs (ex. total = qté × prix ; débit ≠ crédit)
SELECT COUNT(*) FILTER (WHERE <qte> * <pu> <> <total>) AS totaux_faux,
       COUNT(*) FILTER (WHERE <montant> < 0)          AS montants_negatifs,
       COUNT(*) FILTER (WHERE <montant> = 0)          AS montants_nuls
FROM <table>;

-- A7. Jours sans aucune ligne dans la période (série interrompue ≠ activité nulle)
SELECT d::date AS jour
FROM generate_series((SELECT MIN(<date>) FROM <table>), (SELECT MAX(<date>) FROM <table>), interval '1 day') AS d
WHERE NOT EXISTS (SELECT 1 FROM <table> t WHERE t.<date>::date = d::date)
ORDER BY jour;

-- A8. Valeurs aberrantes à SIGNALER (pas à supprimer) : au-delà du 99e centile, avec la ligne complète
WITH seuil AS (SELECT percentile_cont(0.99) WITHIN GROUP (ORDER BY <montant>) AS p99 FROM <table>)
SELECT t.* FROM <table> t, seuil WHERE t.<montant> > seuil.p99 ORDER BY t.<montant> DESC;

-- A9. Intégrité des clés (lignes orphelines entre table de faits et référentiel)
SELECT COUNT(*) AS commandes_sans_client
FROM <faits> f LEFT JOIN <clients> c ON c.<id> = f.<client_id>
WHERE c.<id> IS NULL;

-- ─────────────────────────────────────────────────────────────────────
-- B. VUE « NETTOYÉE » : on filtre et on marque, on n'écrit rien dans la table brute
-- ─────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW <table>_propre AS
SELECT
  <date>::date                                   AS date_op,
  TO_CHAR(<date>, 'YYYY-MM')                     AS annee_mois,
  EXTRACT(ISODOW FROM <date>)::int               AS jour_semaine,     -- 1 = lundi
  TRIM(<client>)                                 AS client,
  TRIM(<produit>)                                AS produit,
  <qte>, <pu>, <montant>,
  TRIM(<statut>)                                 AS statut,
  CASE WHEN TRIM(<statut>) IN ('livré', 'payé')  THEN 'comptabilisable'
       WHEN TRIM(<statut>) IN ('annulé', 'avoir') THEN 'exclu'
       ELSE 'à qualifier' END                    AS regle_inclusion,   -- définition : voir fiche indicateur
  CASE WHEN <montant> >= ⟦seuil haut⟧ THEN 'gros'
       WHEN <montant> >= ⟦seuil moyen⟧ THEN 'moyen' ELSE 'petit' END AS bande_montant, -- seuils = décision maison
  (<qte> * <pu> <> <total>)                      AS total_incoherent,  -- marqué, pas corrigé
  <ref>
FROM <table>
WHERE <date> IS NOT NULL;   -- ce qu'on exclut ici se compte en A2 et se dit dans le rapport

-- ─────────────────────────────────────────────────────────────────────
-- C. INDICATEURS ET VUES D'ENSEMBLE
-- ─────────────────────────────────────────────────────────────────────

-- C1. Résumé (n, total, moyenne, médiane) sur le périmètre comptabilisable
SELECT COUNT(*) AS n, SUM(<montant>) AS total, ROUND(AVG(<montant>), 0) AS moyenne,
       percentile_cont(0.5) WITHIN GROUP (ORDER BY <montant>) AS mediane
FROM <table>_propre WHERE regle_inclusion = 'comptabilisable';

-- C2. Répartition avec part en % (fenêtre sur le total)
SELECT <categorie>, COUNT(*) AS n, SUM(<montant>) AS total,
       ROUND(100.0 * SUM(<montant>) / SUM(SUM(<montant>)) OVER (), 1) AS part_pct
FROM <table>_propre WHERE regle_inclusion = 'comptabilisable'
GROUP BY <categorie> ORDER BY total DESC;

-- C3. Série mensuelle avec variation mois sur mois (LAG)
WITH m AS (
  SELECT annee_mois, SUM(<montant>) AS total FROM <table>_propre
  WHERE regle_inclusion = 'comptabilisable' GROUP BY annee_mois)
SELECT annee_mois, total, LAG(total) OVER (ORDER BY annee_mois) AS mois_precedent,
       ROUND(100.0 * (total - LAG(total) OVER (ORDER BY annee_mois)) / NULLIF(LAG(total) OVER (ORDER BY annee_mois), 0), 1) AS variation_pct
FROM m ORDER BY annee_mois;

-- C4. Même période l'an dernier (comparaison de la maison à elle-même, à périmètre constant)
SELECT a.annee_mois, a.total, b.total AS total_n_moins_1
FROM (SELECT annee_mois, SUM(<montant>) total FROM <table>_propre GROUP BY 1) a
LEFT JOIN (SELECT annee_mois, SUM(<montant>) total FROM <table>_propre GROUP BY 1) b
  ON b.annee_mois = TO_CHAR(TO_DATE(a.annee_mois, 'YYYY-MM') - interval '1 year', 'YYYY-MM')
ORDER BY a.annee_mois;

-- C5. Top N par groupe (ROW_NUMBER partitionné) — ex. 3 meilleurs produits par magasin
WITH r AS (
  SELECT <magasin>, produit, SUM(<montant>) AS total,
         ROW_NUMBER() OVER (PARTITION BY <magasin> ORDER BY SUM(<montant>) DESC) AS rang
  FROM <table>_propre GROUP BY <magasin>, produit)
SELECT * FROM r WHERE rang <= 3 ORDER BY <magasin>, rang;

-- C6. Tableau de bord d'entités classées (scorecard) : taux + rang
WITH s AS (
  SELECT <agence>, COUNT(*) AS n,
         ROUND(100.0 * COUNT(*) FILTER (WHERE <delai_jours> <= ⟦délai cible⟧) / COUNT(*), 1) AS taux_dans_les_temps
  FROM <table>_propre GROUP BY <agence>)
SELECT *, RANK() OVER (ORDER BY taux_dans_les_temps DESC) AS rang FROM s ORDER BY rang;

-- ─────────────────────────────────────────────────────────────────────
-- D. POPULATION : première/dernière commande, réachat, cohortes, RFM, entonnoir
-- ─────────────────────────────────────────────────────────────────────

-- D1. Cycle de vie par client
SELECT client, MIN(date_op) AS premiere, MAX(date_op) AS derniere,
       MAX(date_op) - MIN(date_op) AS jours_client, COUNT(*) AS commandes, SUM(<montant>) AS total
FROM <table>_propre WHERE regle_inclusion = 'comptabilisable'
GROUP BY client ORDER BY total DESC;

-- D2. Clients à une seule commande vs clients qui reviennent
WITH c AS (SELECT client, COUNT(*) AS n FROM <table>_propre GROUP BY client)
SELECT CASE WHEN n = 1 THEN 'une seule commande' ELSE 'revient' END AS type_client,
       COUNT(*) AS clients, ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM c GROUP BY 1;

-- D3. Cohortes de rétention : mois de première commande × mois écoulés
WITH premiere AS (
  SELECT client, DATE_TRUNC('month', MIN(date_op)) AS cohorte FROM <table>_propre GROUP BY client),
activite AS (
  SELECT p.cohorte, t.client,
         (EXTRACT(YEAR FROM t.date_op) - EXTRACT(YEAR FROM p.cohorte)) * 12
         + (EXTRACT(MONTH FROM t.date_op) - EXTRACT(MONTH FROM p.cohorte)) AS mois_ecoules
  FROM <table>_propre t JOIN premiere p USING (client))
SELECT TO_CHAR(cohorte, 'YYYY-MM') AS cohorte, mois_ecoules,
       COUNT(DISTINCT client) AS clients_actifs,
       ROUND(100.0 * COUNT(DISTINCT client) / FIRST_VALUE(COUNT(DISTINCT client)) OVER (PARTITION BY cohorte ORDER BY mois_ecoules), 1) AS pct_de_la_cohorte
FROM activite GROUP BY cohorte, mois_ecoules ORDER BY cohorte, mois_ecoules;
-- Lecture : comparer les cohortes à durée égale ; les récentes ont moins de recul.

-- D4. RFM : récence, fréquence, montant, en quintiles observés (bornes = proposition à valider)
WITH base AS (
  SELECT client, CURRENT_DATE - MAX(date_op) AS recence_jours, COUNT(*) AS frequence, SUM(<montant>) AS montant
  FROM <table>_propre WHERE regle_inclusion = 'comptabilisable' GROUP BY client)
SELECT client, recence_jours, frequence, montant,
       NTILE(5) OVER (ORDER BY recence_jours DESC) AS r,   -- 5 = le plus récent
       NTILE(5) OVER (ORDER BY frequence)          AS f,
       NTILE(5) OVER (ORDER BY montant)            AS m
FROM base ORDER BY r DESC, f DESC, m DESC;

-- D5. Entonnoir par source (une étape non journalisée reste NULL, jamais 0)
SELECT source,
       COUNT(*)                                       AS visites,
       COUNT(*) FILTER (WHERE etape >= 2)             AS paniers,
       COUNT(*) FILTER (WHERE etape >= 3)             AS adresses,
       COUNT(*) FILTER (WHERE etape >= 4)             AS paiements,
       COUNT(*) FILTER (WHERE etape >= 5)             AS commandes,
       ROUND(100.0 * COUNT(*) FILTER (WHERE etape >= 5) / NULLIF(COUNT(*), 0), 1) AS conversion_pct
FROM <sessions> GROUP BY source ORDER BY visites DESC;

-- ─────────────────────────────────────────────────────────────────────
-- E. RAPPROCHEMENT DE DEUX SOURCES (voir croiser-des-sources-heterogenes)
-- ─────────────────────────────────────────────────────────────────────

-- E1. Appariement exact sur référence, puis sur (date ± 2 jours, montant), le reste en écart
WITH exact AS (
  SELECT a.<id> AS id_a, b.<id> AS id_b, 'référence' AS regle FROM <source_a> a JOIN <source_b> b ON a.<ref> = b.<ref>),
approx AS (
  SELECT a.<id>, b.<id>, 'date±2j + montant' FROM <source_a> a JOIN <source_b> b
    ON a.<montant> = b.<montant> AND ABS(a.<date> - b.<date>) <= 2
  WHERE a.<id> NOT IN (SELECT id_a FROM exact) AND b.<id> NOT IN (SELECT id_b FROM exact))
SELECT * FROM exact UNION ALL SELECT * FROM approx;
-- Les non appariés des deux côtés = la note d'écarts ; un appariement approx. reste PROBABLE.

-- ─────────────────────────────────────────────────────────────────────
-- Notes de portabilité
--  MySQL  : pas de FILTER → SUM(CASE WHEN … THEN 1 ELSE 0 END) ; DATE_FORMAT(d,'%Y-%m') ; pas de percentile_cont natif.
--  SQLite : strftime('%Y-%m', d) ; fenêtres OK depuis 3.25 ; pas de generate_series sans extension (utiliser un calendrier).
--  DuckDB : syntaxe très proche de PostgreSQL ; lit directement un CSV : SELECT * FROM 'fichier.csv'.
-- =====================================================================
