---
id: Y0740
name: referentiel-d-indicateurs-par-secteur
description: "À charger quand on demande les indicateurs d'un secteur, des repères pour se comparer, ou un référentiel de KPI par secteur et par taille d'entreprise. Dit COMMENT construire ce référentiel : quels indicateurs chercher selon le métier, comment définir la taille, où chercher les valeurs, comment dater et sourcer chacune, et ce qu'un repère public ne permet pas de conclure. Ne contient aucune valeur de référence : chaque valeur se relève dans une source ouverte ce jour, sinon la case reste « non disponible »."
bucket: B
tags: [Données, Indicateurs, Métier, Nouveau]
version: 1
maj: 2026-09-23
---

# Construire un référentiel d'indicateurs par secteur et par taille, sans inventer un repère

> ⛔ **Contrôle avant remise.** Avant de rendre un référentiel, vérifie que chaque valeur porte
> sa source ouverte ce jour, son producteur, sa période, sa date de publication et la
> population qu'elle couvre. Une case sans source se lit « non disponible » ; si une valeur
> de ta mémoire a rempli une case, retire-la, et ne remets pas avant.

Cette compétence ne donne **aucun chiffre**. Elle donne la méthode. Un repère sectoriel
« connu de tous » qui circule sans source est la valeur la plus dangereuse d'un livrable : on
la reprend parce qu'elle semble évidente, et personne ne peut la défendre quand on la conteste.

## Ce qu'il faut avoir sous la main
- **Le ou les secteurs**, dits avec les mots de la maison (« restauration rapide », « microfinance », « distribution de matériaux »), pas seulement une grande famille.
- **La taille qui compte pour la question** : effectif, chiffre d'affaires, nombre de sites ou de points de vente. Et qui la fixe : la maison, ou une définition légale.
- **L'usage** : se situer, préparer une demande de financement, choisir les indicateurs d'un tableau de bord. L'usage change les indicateurs à retenir.
- **Le pays ou la zone**.

> ⚡ **Tu n'attends pas d'avoir « tout ».** Avec un secteur et une zone, tu produis la grille et
> tu marques le reste `⟦à renseigner⟧`.

## Process

### Étape 1 : Poser la grille des indicateurs avant de chercher une valeur
Pour chaque secteur, liste les indicateurs qu'une maison de ce métier suit, par famille. Les
familles reviennent partout, leurs indicateurs changent avec le métier :

| Famille | Ce qu'elle mesure | Exemples de noms d'indicateurs selon le métier |
|---|---|---|
| Activité | le volume produit ou vendu | couverts servis (restauration), unités vendues (commerce), dossiers traités (services) |
| Commercial | la valeur et la fidélité des clients | ticket moyen, part de clients qui reviennent, taux de conversion |
| Rentabilité | ce qui reste après les coûts | marge brute, coût matière rapporté aux ventes, marge par produit |
| Trésorerie | le temps entre la dépense et l'encaissement | délai de paiement des clients, rotation des stocks |
| Opérations | l'usage des moyens | taux d'occupation, productivité par personne, ruptures de stock |
| Risque | ce qui peut coûter | taux d'impayés, part des ventes sur un seul client |
| Personnes | l'équipe | effectif, départs dans l'année, absentéisme |

Garde de trois à sept indicateurs par secteur, ceux qui servent l'usage annoncé. La liste
des noms vient du métier ; **les valeurs, elles, ne viennent jamais de cette grille**. Chaque
indicateur retenu reçoit sa définition écrite (compétence `definir-un-indicateur`) : formule,
unité, période, ce qui est inclus et exclu. Deux sources qui portent le même nom
d'indicateur ne mesurent pas forcément la même chose, et c'est la définition qui le dit.

### Étape 2 : Définir la taille, une fois, et ne jamais mélanger
- **Choisis une dimension** (effectif, chiffre d'affaires, nombre de sites) et des tranches.
- **Si une définition légale de la taille existe** (petite, moyenne, grande entreprise), elle
  se cite depuis son texte ouvert, avec sa référence. Elle n'est pas sur le disque du poste à
  ce jour : tu la cherches (compétence `aller-chercher`), tu la déposes dans la couche locale,
  et d'ici là tu la marques `⟦à renseigner⟧`. Tu n'écris jamais un seuil de mémoire.
- **Sinon, la maison fixe les tranches**, et le référentiel le dit.
- Une valeur relevée pour une tranche de taille ne se reporte pas sur une autre, et une
  valeur « tous secteurs » ou « toutes tailles » ne devient pas un repère pour un secteur.

⚠ Les données publiques ventilées **à la fois** par secteur et par taille sont rares. Quand la
ventilation n'existe pas, tu le dis dans la case (« publié tous secteurs confondus ») au lieu
de la reconstituer.

### Étape 3 : Chercher les valeurs, dans cet ordre
1. **Les chiffres de la maison elle-même** : son historique est son premier repère, et le
   seul qui mesure exactement la même chose.
2. **Les sources publiques ouvertes**, par les intégrations du poste quand elles existent :
   `integrations/banque-mondiale/` (séries par pays, avec l'organisme producteur réel),
   `integrations/data-gouv-ci/` (portail des données ouvertes), `integrations/un-comtrade/`
   (échanges commerciaux). Puis la couche locale : `statistiques-ci/LISEZ-MOI.md` dit où sont
   les statistiques publiques, ce qui s'ouvre et ce qui bloque, et
   `statistiques-ci/SECTEURS-ET-ACTIVITE.md` ce qui est déjà relevé par secteur (dans
   `~/.claude/outils-communs/`). La banque centrale et les régulateurs sectoriels publient
   les indicateurs de leur secteur.
3. **Les publications professionnelles** (fédérations, études d'organisations reconnues), à
   condition que la méthode soit publiée.

⛔ Ce qui n'est **jamais** une source : un blog ou un site commercial sans méthode publiée,
même quand plusieurs se recopient le même chiffre. `statistiques-ci/LISEZ-MOI.md` liste aussi
ce qui n'existe pas en donnée publique et qu'il ne sert à rien de chercher : lis-le avant de
passer une heure sur un manque déjà constaté.

Pour chaque valeur trouvée, prends **la dernière édition parue** (compétence
`restitution-des-donnees`, section 6).

### Étape 4 : Dater et sourcer chaque valeur, dans le tableau lui-même
Une ligne par secteur, par taille et par indicateur, avec ces colonnes :

| Colonne | Contenu |
|---|---|
| Secteur | tel que la maison le nomme, et le code de nomenclature si la source en utilise un |
| Taille | la tranche, ou « toutes tailles » |
| Indicateur | son nom, renvoyant à sa définition |
| Valeur | le chiffre relevé, ou « non disponible » |
| Unité | francs, pourcentage, nombre, jours |
| Période couverte | l'année ou le trimestre que la valeur décrit |
| Publication | la date de parution et l'édition |
| Producteur | l'organisme qui a produit la donnée, pas seulement celui qui la diffuse |
| Population | national, une ville, un échantillon d'entreprises, un groupe ou une filiale |
| Lien | la page ou le fichier ouvert, et la date d'ouverture |

Une valeur qui décrit un groupe ne décrit pas sa filiale ; une enquête faite dans une ville
ne décrit pas le pays ; deux sources justes sur deux populations différentes ne se
contredisent pas. La colonne « Population » est là pour que ces erreurs se voient.

### Étape 5 : Dire ce que le référentiel ne permet pas
En tête du livrable, trois lignes :
- **un repère public n'est ni un objectif ni un seuil** : il situe la maison, il ne dit pas ce
  qu'elle doit atteindre, et les objectifs restent une décision de la maison ;
- **une moyenne ne décrit pas une entreprise typique** : la dispersion n'est presque jamais
  publiée, donc on ne sait pas si la maison est « dans la norme » ;
- **ce qui manque**, secteur par secteur, et où on a cherché.

### Étape 6 : Tenir le référentiel à jour
Chaque ligne porte sa date de relevé. Le référentiel indique, quand la source l'annonce, la
prochaine édition attendue ; sinon `⟦à renseigner⟧`. Une mise à jour ajoute une colonne ou un
onglet daté, elle n'écrase pas l'ancienne valeur.

## Format de sortie
- **Livrable** : un Google Sheet (ou un classeur Excel), un onglet par secteur, les colonnes de l'étape 4, un onglet « Définitions » et un onglet « Ce qui manque », avec le PDF qui l'accompagne.
- **En tête** : les trois lignes de l'étape 5.
- **Règle 0 invention** : aucune valeur, aucun seuil de taille, aucune moyenne sectorielle sans source ouverte ce jour. Une case vide dit « non disponible » et où on a cherché.

## Règles
1. **La grille vient du métier, les valeurs viennent d'une source.** Jamais l'inverse.
2. **Une valeur sans producteur, période, date de publication et population ne s'écrit pas.**
3. **La taille se définit une fois**, par la maison ou par un texte cité ; elle ne se déduit pas.
4. **Pas de report d'une population sur une autre** : groupe et filiale, ville et pays, toutes tailles et une tranche.
5. **Un repère n'est pas un objectif.** Le référentiel situe, il ne fixe rien.
6. **La dernière édition parue, toujours**, et l'ancienne reste consultable.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, seuil, moyenne ou référence de texte fabriqué. Ce qui n'est pas relevé reste « non disponible » ou `⟦à renseigner⟧`.
- **0 fausse source.** Une source se cite parce qu'elle a été ouverte, pas parce qu'elle devrait contenir la donnée.
- **Produis, ne bloque pas.** Un référentiel à moitié rempli, qui dit ce qui manque, est un livrable correct.
- 🔒 **Aucune action sortante en autonomie.** Diffuser le référentiel hors de la maison est une action validée.
- **Cloisonnement.** Les chiffres d'une maison ne servent jamais de repère à une autre.

## Cas limites
- **Aucune donnée publique pour le secteur** : la grille et les définitions sortent quand même ; les valeurs restent « non disponible », avec la liste de ce qui a été cherché, et tu proposes un relevé propre, daté et documenté, comme substitut légitime.
- **Deux sources donnent deux valeurs** : les deux sortent, avec leur population et leur méthode ; tu ne fais pas la moyenne.
- **La personne demande « la norme du secteur » pour fixer un objectif** : tu rends le repère sourcé, et tu rappelles en une ligne que l'objectif reste sa décision.
- **Valeur trouvée seulement dans une autre devise ou un autre pays** : elle sort comme telle, marquée, sans conversion ni transposition silencieuse.
- **Demande hors périmètre** (calculer les indicateurs de la maison, construire le tableau de bord) : tu le dis en une phrase et tu orientes vers `definir-un-indicateur` ou `restitution-des-donnees`.

## Historique
- v1, 23/09/2026 : création, méthode de construction d'un référentiel d'indicateurs par secteur et par taille sans valeur de référence, manque de la séance du 22/09 relevé par audit.
