---
id: Y0715
name: informatique-decisionnelle-pme
description: "Ce que j'ai retenu du « Guide concis de mise en œuvre de la Business Intelligence au sein des PME » (Don Jones, Realtime Publishers, 2009, diffusé par IBM Cognos), lu en entier le 22/09/2026 sur demande d'Awa. Donne la distinction tableau de bord / carte de score et ce qu'elle change dans mes livrables, la règle du démarrage par le point douloureux, le cycle décision-action, et la limite d'âge du document. Existe parce qu'un rapport qui affiche un chiffre sans dire s'il est bon ou mauvais n'aide personne à décider, et parce qu'un livrable de suivi mal nommé promet ce qu'il ne peut pas tenir."
bucket: B
tags: [Données, Tableaux de bord, Lecture, Méthode]
version: 1
maj: 2026-09-22
---

# Informatique décisionnelle dans une entreprise de taille moyenne

## La source, et ce qu'elle vaut

« Guide concis de mise en œuvre de la Business Intelligence au sein des PME », Don Jones,
Realtime Publishers, 97 pages, copyright 2009, fichier produit en 2010 d'après ses propres
métadonnées. Document **hébergé et diffusé par un éditeur de logiciels décisionnels**, et dont
l'avant-propos dit que les coûts de production sont pris en charge par des sponsors. L'éditeur
affirme garder le contrôle éditorial ; je n'ai aucun moyen de le vérifier.

Ce que cela veut dire pour l'usage : la partie **méthode** (à quoi sert un tableau de bord, par où
commencer, comment relier une décision à une action) vieillit bien et je m'en sers. La partie
**outillage et coûts** a seize ans, elle décrit un marché qui n'existe plus sous cette forme : je
n'en tire aucun chiffre, aucun ordre de grandeur de prix, aucune recommandation de produit.
Un chiffre lu dans ce document ne se cite pas sans sa date.

Fichier lu : `[référence retirée]` (texte extrait du PDF reçu
d'Awa le 22/09/2026).

## Ce que j'en retiens, et ce que ça change dans mes livrables

### 1. Tableau de bord et carte de score ne sont pas la même chose

Le guide pose la distinction en une phrase : « un tableau de bord montre normalement où vous en
êtes en termes absolus, alors qu'une carte de score vous indique où vous en êtes par rapport à
vos prévisions ». La carte de score note chaque mesure bonne, moyenne ou mauvaise selon des
seuils ; le tableau de bord affiche l'état et laisse le lecteur juger.

**Conséquence directe sur mon travail** : un document qui classe des chiffres en « bon, en retard,
à surveiller » est une carte de score, pas un tableau de bord. Une carte de score **exige des
objectifs et des seuils décidés par la maison**. Tant que je ne les ai pas, deux sorties seulement
sont honnêtes :

- livrer un **tableau de bord** : l'état, l'évolution dans le temps, l'écart entre systèmes, sans
  note ni couleur de jugement ;
- livrer une **carte de score** dont les seuils sont ceux que le client a écrits, et le dire.

Ce que je ne fais pas : poser mes propres seuils et appeler ça une carte de score. Le guide
l'illustre par la bonne question : « Les dépenses se montent à 10 % ? Alors… est-ce bon ou
mauvais ? » Sans référence donnée par la maison, personne ne peut répondre, moi pas plus que le
lecteur.

### 2. Un tableau de bord ne décide pas, il déclenche une enquête

« Les tableaux de bord ne sont pas conçus pour occasionner des décisions immédiates […] l'objectif
est de vous alerter des situations de travers, qui nécessitent des investigations plus
approfondies. » Le guide insiste ensuite sur la recherche de la **cause première**, et donne un cas
où le chiffre visible désignait le mauvais coupable : la satisfaction client baissait pendant les
pics d'activité, et l'enquête a montré que le centre de distribution était **moins** sollicité à ce
moment-là, le retard venant de deux intermédiaires.

**Conséquence** : tout écart que je publie porte la question qu'il ouvre, pas la conclusion qu'il
suggère. Et je ne nomme pas de responsable : le chiffre visible désigne souvent le mauvais.

### 3. Commencer par là où ça fait le plus mal, pas par ce qui est facile

Le guide raconte un cas où le premier périmètre outillé fut celui que la direction trouvait
« intouchable et mystérieux », les frais d'expédition, parce que rien d'autre n'avait permis d'y
voir clair. Deux mois plus tard, les premières réponses ; en moins d'un an, l'investissement
remboursé par les changements de processus.

**Conséquence** : quand on me demande par quel jeu de données commencer, je propose celui dont
l'entreprise parle sans arriver à le chiffrer, pas celui qui est le plus propre. Le jeu propre
donne un joli rapport que personne n'attendait.

### 4. Le reporting n'est qu'un tiers du cycle

Collecter, analyser, simuler, décider, reporter la décision dans la planification, recommencer.
Le guide appelle ça le cycle de la gestion de la performance, et prévient que confondre
l'informatique décisionnelle avec la production de rapports est l'erreur la plus courante.

**Conséquence** : un rapport que je rends se termine par ce qu'il appelle à décider et par qui,
sinon il s'arrête au milieu du cycle. C'est déjà la douzième partie de mon protocole de mission,
le guide dit pourquoi elle n'est pas facultative.

### 5. La culture de la donnée remplace l'instinct, elle ne remplace pas le métier

« Gérer par instinct est une pratique courante […] le directeur arrête de gérer son entreprise à
partir de données simplement parce qu'il ne dispose plus de données. » Mais aussi, plus loin :
des dirigeants « passaient leur temps à regarder des feuilles de calcul, sans jamais porter une
évaluation critique aux données ». Et l'exemple d'ouverture : un cadre persuadé qu'augmenter le
prix augmente les volumes, alors que l'entreprise améliorait son produit et ses dépenses de
publicité en même temps.

**Conséquence** : c'est la confusion entre corrélation et causalité, dite par un praticien. Quand
je décris deux séries qui bougent ensemble, j'écris qu'elles bougent ensemble, et je nomme ce qui
a bougé en même temps.

### 6. Modéliser l'entreprise avant de modéliser les données

« Si le succès de votre entreprise est axé sur la régularité de votre service client, alors que
les modèles de votre système sont principalement axés sur les revenus et les coûts, votre système
ne sera pas en mesure de vous aider. »

**Conséquence** : avant de construire, je demande quelles décisions les chiffres doivent éclairer.
C'est déjà dans ma fiche de poste ; le guide en donne le contre-exemple utile à citer.

## Ce que je n'emporte pas de ce document

- Aucun chiffre de coût, de délai de mise en place ni de retour sur investissement : ils datent de
  2009 et ne concernent pas ce marché.
- Aucune recommandation d'outil. Le document est diffusé par un éditeur ; ses avantages produits
  sont des arguments commerciaux, pas des faits établis.
- Le vocabulaire anglais du document (« scorecard », « what-if », « bottom-up ») : je dis carte de
  score, scénario de simulation, construction par morceaux.
