---
id: Y0717
name: restitution-des-donnees
description: >
  Comment une analyse se rend : un rapport de lecture de trois à cinq points avec ses points
  de vigilance, un vrai tableau de bord filtrable (dans Excel quand c'est possible, sinon
  Tableau ou Power BI s'ils sont authentifiés sur le poste) plutôt qu'un classeur, un
  dispositif d'alerte sur les indicateurs clés, la réconciliation de deux jeux de données avec
  rapport d'écarts, l'analyse critique au-delà du chiffre, la recherche multi-sources, les
  formules laissées visibles, la dernière édition de chaque source publique vérifiée avant
  usage, chaque indicateur technique expliqué pour un lecteur qui n'est pas du métier, et un
  seul envoi par message, vérifié avant tout renvoi. À appliquer sur toute remise de travail
  chiffré.
version: 3
maj: 2026-09-23
---

# Rendre une analyse

> **Écrit le 22/09/2026 d'après le point de formation.** Le traitement des données était
> jugé solide ; ce qui manquait, c'est tout ce qui en fait un livrable utilisable.

> ⛔ **Contrôle avant remise (23/09/2026).** Avant d'envoyer un travail chiffré, vérifie :
> 1. **Chaque fichier ou chiffre public est la dernière édition parue** (section 6) : la page de
>    l'organisme a été ouverte ce jour, et le livrable dit l'édition retenue et sa date.
> 2. **Chaque indicateur technique a sa phrase en langage courant** (section 8), à côté du
>    chiffre, pas dans une annexe.
> 3. **L'outil du tableau de bord est réellement disponible** (section 2) : Tableau ou Power
>    BI seulement si leur vérification passe ; sinon Excel ou Google Sheet, et le message le dit.
> 4. **Ce message n'est pas déjà parti** (section 9) : un envoi, puis contrôle avant tout
>    renvoi.
> 5. **Un lecteur non technique comprend chaque page en dix secondes** (section 0) : mots de
>    tous les jours, icônes, un calcul par ligne avec un vrai exemple, cinq lignes au plus.
>
> Si l'un de ces points manque, ne remets pas : complète d'abord.

Un tableau de chiffres justes dont personne ne tire de décision n'a rien produit. Ton travail
ne s'arrête pas au calcul : il s'arrête quand le lecteur sait quoi faire.

---

## 0. Le lecteur n'est pas technique, c'est le réglage par défaut

Arrêté le 23/09/2026, après trois retours le même jour : « un peu compliqué pour une vendeuse,
essaie de simplifier » (Alima), « pense à ajouter des icônes […] les destinataires des
livrables n'ont pas forcément des profils techniques », puis « une simplicité pour le lecteur
non technique, ça doit aussi être mis dans le réglage » (testeur, message 12778).

On écrit **toujours** pour la personne la moins technique qui lira le document : la vendeuse,
le gérant, le comité, pas l'analyste. Une version experte se fait seulement si on la demande,
et elle vient en plus, jamais à la place.

| Règle | Ce que ça donne |
|---|---|
| Mots de tous les jours | « ce qui reste après le marché », pas « marge brute » ; un terme technique indispensable porte son nom développé et une phrase simple (section 8) |
| Une icône par idée, le même sens partout | Une page de calcul sans icône n'est pas finie ; l'icône ne décore pas, elle désigne toujours la même chose dans tout le document |
| Un calcul par ligne, avec un vrai exemple | « ce qui est rentré − ce qui est parti au marché = ce qui reste », suivi de la même ligne avec les chiffres d'un vrai jour du client, jamais la formule seule |
| Cinq lignes au plus par page ou par fiche | Le reste va dans les notes de travail ; les questions de définition restent dans le message, pas dans le livrable |
| Gros caractères, un chiffre qui se voit | Le chiffre qui compte en gras et plus grand que le texte ; un graphique qui montre le constat avant tout tableau |
| La décision en premier | La première phrase dit quoi faire ou quoi regarder, pas comment on a calculé |
| Ce qui est à décider se voit | Une case de couleur « à décider par … » plutôt qu'une réserve noyée dans le texte |

Le test des dix secondes : on montre la page à quelqu'un qui ne connaît pas le dossier ; s'il
ne peut pas dire en une phrase ce qu'elle raconte, elle se réécrit.

## 1. Toute analyse part avec son rapport de lecture

Court, une page au plus, qui tient sans le tableau :

- **trois à cinq points importants**, ceux qu'on retiendrait si on ne lisait que ça ;
- **les points de vigilance** : ce qui baisse, ce qui surprend, ce qui mérite méfiance ;
- un repère visuel sur les chiffres qui posent question, pour qu'ils se voient avant d'être lus.

⛔ Un chiffre en baisse qui n'est pas signalé passe inaperçu, et le lecteur découvrira le
problème un mois plus tard en se demandant pourquoi personne ne l'a vu.

## 2. Un tableau de bord n'est pas un classeur

Un classeur se lit. Un tableau de bord s'interroge : le lecteur filtre par période, par
agence, par produit, et voit la réponse changer. S'il ne peut pas filtrer, tu lui as livré un
export bien mis en page.

Ce qu'un tableau de bord porte au minimum : des filtres sur les deux ou trois dimensions qui
comptent, des graphiques qui montrent une répartition et une évolution, et une légende qui
dit ce que signifie chaque couleur porteuse de sens.

Quand l'outil de la maison n'est pas branché, tu le dis, tu livres la version la plus
interrogeable que tu puisses produire, et tu expliques ce qu'on gagnerait à brancher l'outil.

**Quel outil, dans quel ordre (22/09/2026).** Le tableau de bord se fait **dans Excel quand
c'est possible** : un classeur `.xlsx` avec des tables filtrables et des graphiques natifs, ou
son équivalent Google Sheet. Tableau ou Power BI ne viennent qu'ensuite, quand Excel ne suffit
plus (connexion en direct à une base, nombreux lecteurs, volume trop lourd pour un classeur),
**et seulement s'ils sont authentifiés sur le poste**. Avant de les proposer, lance le
`check.py` de `integrations/tableau/` et de `integrations/powerbi-fabric-iq/` quand le poste
les a : tant qu'il sort en échec, l'outil n'existe pas pour toi. Relevé du 23/09/2026 sur le
poste qui porte ces deux intégrations : enregistrées, **non authentifiées** (« identifiants
absents »), et l'accès aux classeurs Excel en ligne par Microsoft Graph ne l'est pas non plus.
Dans ce cas, tu livres en Excel ou en Google Sheet et tu le dis en une ligne, avec ce qu'il
faudrait pour brancher l'outil. Une maquette en image présentée comme un tableau Power BI
n'est pas un tableau de bord.

## 3. Les indicateurs clés se surveillent, ils ne se consultent pas

Pour tout suivi récurrent, tu poses un dispositif d'alerte : quels indicateurs, quel seuil,
qui est prévenu, à quelle fréquence.

⛔ **Un seuil ne s'invente pas.** Il se mesure sur l'historique, ou il se fait dire par le
client. Un seuil posé au jugé produit soit des alertes permanentes qu'on finit par couper,
soit un silence qui rassure à tort.

## 4. Réconcilier deux jeux de données, c'est produire un rapport d'écarts

Rapprocher ne suffit pas. Ce qui a de la valeur, c'est la liste de ce qui ne colle pas :
quelle ligne, quel montant, de combien, et dans quel sens. Un rapport d'écarts nomme, il ne
résume pas.

Tu classes ensuite les écarts par cause probable, parce qu'un défaut qui revient à chaque
cycle n'est pas un défaut de donnée : c'est un défaut de saisie ou de collecte, et c'est là
qu'il se répare.

## 5. Le chiffre ne se commente pas, il s'analyse

Au-delà du traitement, tu donnes une **lecture critique** : ce que les données établissent, ce
qu'elles ne permettent pas de conclure, et ce qui devrait alerter. C'est la différence entre
transmettre une donnée et rendre un avis.

Tu distingues toujours : le constat, la preuve, ce que ça implique pour l'activité, puis
l'action recommandée. Le constat et la preuve t'appartiennent ; la décision appartient à la
direction.

## 6. Chercher les chiffres qui existent déjà

Quand une question dépasse les données du client, tu vas chercher : publications officielles,
institutions statistiques, organisations internationales. Tu recoupes, tu cites, tu dates.

⛔ Ce qui vient de la mémoire n'est pas une source. Chaque chiffre repris porte son lien et
sa date, et une donnée introuvable reste `non disponible`, jamais remplacée par une moyenne.

⛔ **Avant d'utiliser un fichier public, cherche l'édition plus récente.** Un rapport, une
série ou un tableau publié par une institution (Banque mondiale, BCEAO, institut statistique,
régulateur) a presque toujours une édition suivante. Avant de t'en servir :
- ouvre la page de publication de l'organisme et regarde la dernière édition parue, y compris
  celles qui ne sont diffusées que par un lien de téléchargement ou de transfert ;
- pour une série de la Banque mondiale, `integrations/banque-mondiale/indicateur.py` rend les
  années réellement publiées et la date de mise à jour annoncée par la base, quand le poste a
  cette intégration ;
- écris dans le livrable l'édition retenue et sa date. Quand le chiffre le plus récent reste
  ancien (une enquête qui ne paraît que certaines années), tu le dis en tête, avec la raison.

Un fichier qu'on a sous la main n'est pas le plus récent pour autant : c'est celui qu'on a
trouvé en premier. La même règle vaut pour les fichiers du client (dernier export, dernier
onglet, dernière version) : tu prends le plus récent qui répond à la question posée, et tu dis
lequel.

## 7. Les formules restent visibles

Le classeur que tu remets laisse voir ses calculs. Un rapport chiffré n'est presque jamais lu
par la seule personne qui l'a demandé : il circule, et le suivant voudra cliquer sur une
cellule pour comprendre d'où sort le total. Une valeur collée en dur casse cette chaîne et
oblige à te redemander.

## 8. Un indicateur technique s'explique à qui n'est pas du métier

Le lecteur d'un rapport est rarement analyste. Un sigle ou un indicateur technique (NPS, taux
d'attrition, marge, médiane, intervalle, écart type, taux de conversion) qui arrive sans
explication est un chiffre qu'il ne sait pas lire, donc qu'il ne peut pas défendre devant sa
direction.

Pour chaque indicateur technique, à côté du chiffre et à sa première apparition :
- **ce qu'il mesure, en une phrase de langage courant**, sans autre terme technique dedans ;
- **comment le lire** : ce qu'un chiffre haut ou bas veut dire, et sur quelle échelle il vit ;
- **un exemple chiffré simple**, pris dans les données du client quand c'est possible ;
- **ce qu'il ne dit pas**, quand l'erreur de lecture est fréquente (un score lu comme un
  pourcentage, une moyenne lue comme un cas typique).

Le test : la personne peut-elle répéter le chiffre et son sens en une phrase à quelqu'un
d'autre ? Si non, l'explication est à reprendre.

## 9. Un message part une fois

Recevoir deux fois le même message fait douter de tout le reste : lequel est le bon, l'autre
a-t-il changé, faut-il relire les deux ?

- **Un envoi, puis on s'arrête.** Un envoi dont l'outil a rendu un identifiant de message est
  parti : il ne se renvoie pas.
- **Avant tout renvoi, vérifie qu'il n'est pas déjà parti** : relis dans la session le résultat
  des envois précédents (message du fil, courriel). Si l'outil a échoué ou n'a rien rendu et
  que tu ne peux pas établir que le message est parti, tu ne renvoies pas le même texte à
  l'aveugle : tu envoies une ligne qui dit que le premier envoi a peut-être échoué, et le
  contenu une seule fois.
- **Corriger n'est pas renvoyer.** Un message déjà parti qui contient une erreur se modifie
  quand l'outil le permet, sinon la correction part seule, en disant ce qui change. Jamais le
  même texte une deuxième fois.

## Historique
- v2, 23/09/2026 : contrôle avant remise en tête ; vérifier la dernière édition d'un fichier public avant de l'utiliser (section 6) ; chaque indicateur technique expliqué pour un lecteur hors métier (section 8), séance Sync agents training.
- v2, 23/09/2026 (même passe) : ordre des outils du tableau de bord, Excel d'abord, Tableau ou Power BI seulement authentifiés (section 2) ; un message part une fois, contrôle avant tout renvoi (section 9), manques de la séance du 22/09 relevés par audit.
- v3, 23/09/2026 : section 0, le lecteur non technique comme réglage par défaut (mots simples, icônes, un calcul par ligne avec un vrai exemple, cinq lignes au plus), contrôle 5 ajouté ; retours d'Alima et du testeur (message 12778).
