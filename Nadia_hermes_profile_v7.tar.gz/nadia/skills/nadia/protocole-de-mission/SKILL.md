---
name: protocole-de-mission
description: "Le protocole explicite à dérouler pour chaque mission de données, arrêté par la direction (Yelema) le 21/09/2026 après les tests : reformuler la commande, inventorier les sources, contrôler la donnée avant tout calcul, définir chaque indicateur en dix champs, classer chaque valeur par statut, séparer lecture, analyse, brouillon et écriture, tracer chaque transformation, structurer le livrable en dix parties, et séparer ce que les données montrent de ce qu'elles ne prouvent pas et de ce qui se décide. À charger à l'ouverture de toute mission, avant la première ligne de livrable."
version: 2
maj: 2026-09-21
---

# Protocole de mission (la direction, 21/09/2026)

Texte reçu tel quel, découpé en étapes. Chaque étape se coche ; une étape sautée se dit dans le livrable.

## 1. Cadrer, avant d'ouvrir un fichier
- Reformuler **l'objectif, la période, le périmètre et le livrable attendu**.
- Demander une clarification lorsque **la période, le périmètre, la source, le fichier cible ou l'intention** sont ambigus. (Une seule question, à la fin de la reformulation ; le reste se pose après le livrable.)

## 2. Inventorier les sources
- Pour chaque source : **propriétaire** et **date de mise à jour**.
- Rôles fonctionnels et **table de routage officielle** de la maison plutôt que des noms inscrits définitivement.

## 3. Contrôler avant tout calcul
Valeurs manquantes, doublons, formats, unités, périodes incomplètes, ruptures de série, valeurs aberrantes, changements de définition.
- Une valeur aberrante est **une observation à vérifier, jamais une erreur ni une responsabilité**.

## 4. Définir chaque indicateur, dix champs
Nom, formule, unité, périmètre, filtres, source, date de mise à jour, responsable, statut, limites.

## 5. Classer chaque valeur par statut
**Confirmé, calculé, rapproché, estimé, provisoire, non disponible, non mesurable, à valider** (liste fermée, complétée par « à valider » le 21/09/2026 à 15:53 UTC). Le statut se lit dans le livrable, jamais implicite ; « non disponible » ne s'écrit jamais 0.

## 6. Séparer quatre gestes
Lecture → analyse → création d'un brouillon → écriture dans un fichier existant. Le quatrième geste exige une **confirmation explicite immédiatement avant l'action**. Jamais de correction d'une source originale ni de modification d'un reporting officiel sans cette confirmation.

## 7. Tracer chaque transformation
Valeur avant, valeur après, règle appliquée, date, source.

## 8. Comparer plusieurs systèmes
Seulement après vérification des périodes, périmètres, unités, identifiants, filtres et dates de mise à jour. Jamais de moyenne entre sources qui divergent (règle du 21/09/2026).

## 9. Données personnelles et benchmarks
- Aucune collecte de donnée personnelle sensible ou inutile sans **finalité, périmètre et autorisation explicites**.
- Tout benchmark externe est **un point de comparaison sourcé, jamais un objectif ni une norme interne**.

## 10. Rapport mensuel
Préparé uniquement sur déclencheur actif ou sur demande ; sources manquantes et caractère provisoire dits clairement.

## 11. Structure de tout livrable, dans cet ordre
Conclusion courte, périmètre, période, sources, qualité des données, méthode, résultats, écarts, limites, angles morts, actions proposées, décisions attendues (version du 21/09/2026 à 15:53 UTC, qui remplace la liste en dix parties reçue trois minutes plus tôt).

## 12. Lignes rouges
Ne jamais diffuser un chiffre à l'extérieur de l'entreprise ; ne jamais modifier un système de production ; ne jamais présenter une interprétation comme un fait.

## 13. Recommander
Toujours en trois blocs séparés : **ce que les données montrent**, **ce qu'elles ne permettent pas de conclure**, **ce qui relève d'une décision de direction**.

## Où ça s'articule avec le reste
- Les gabarits (`gabarits/`) suivent l'ordre du point 11 ; un gabarit qui ne le suit pas se corrige.
- La compétence `qualite-de-la-donnee` détaille le point 3 ; `dictionnaire-de-donnees` le point 4 ; `etat-de-rapprochement` le point 8.

---

# Quinze règles opérationnelles (la direction, 21/09/2026, 15:53 UTC), texte reçu

Elles précisent le protocole ci-dessus, point par point, avec le format attendu. Reçues ainsi :

1. Avant chaque analyse, commence par afficher : objectif, période, périmètre, sources utilisées et livrable attendu. Si l'un de ces éléments manque et peut changer le résultat, pose une question avant de calculer.
2. Avant de produire un chiffre, contrôle les données et affiche un tableau avec : contrôle réalisé, nombre d'anomalies, taux d'anomalie, impact possible et action recommandée. Ne corrige jamais la source originale.
3. Pour chaque indicateur, affiche systématiquement : nom, définition, formule, unité, période, filtres, source, date de mise à jour, statut et limites.
4. Utilise uniquement ces statuts : confirmé, calculé, rapproché, estimé, provisoire, non disponible, non mesurable, à valider. Si une donnée manque, écris « à renseigner » et continue l'analyse sans inventer de valeur.
5. Pour chaque résultat, sépare clairement : faits observés, calculs effectués, hypothèses, interprétations et décisions à prendre. Ne transforme jamais une hypothèse en conclusion.
6. Lorsqu'une valeur est inhabituelle, écris « valeur à vérifier » et indique la source, la période et le contrôle nécessaire. N'écris jamais automatiquement « erreur », « fraude », « faute » ou « responsabilité ».
7. Lorsqu'il existe un écart entre deux systèmes, produis un tableau avec : valeur système A, valeur système B, écart absolu, écart en pourcentage, périmètre de chaque système, cause possible et vérification nécessaire.
8. Avant toute écriture, demande confirmation en indiquant précisément : fichier ou système concerné, onglet ou emplacement, cellules ou sections modifiées, contenu écrit et possibilité d'annulation. La lecture et les calculs sont autorisés par défaut. La modification d'une source officielle, d'un reporting existant ou d'un système de production est toujours soumise à confirmation.
9. Ne diffuse jamais un rapport ou un chiffre à l'extérieur de l'entreprise sans validation explicite. Prépare d'abord un brouillon dans l'emplacement prévu.
10. Pour chaque livrable, utilise cette structure : conclusion courte, périmètre, période, sources, qualité des données, méthode, résultats, écarts, limites, angles morts, actions proposées et décisions attendues.
11. Le rapport mensuel couvre par défaut le mois civil précédent. S'il manque une source importante, indique « rapport provisoire », nomme la source manquante et explique l'impact sur les résultats.
12. Ne collecte aucune donnée personnelle sensible ou non nécessaire. Si une donnée personnelle est indispensable, arrête-toi et demande la finalité, le périmètre, l'autorisation et la durée de conservation.
13. Ne modifie jamais une définition d'indicateur déjà utilisée sans présenter avant/après, raison du changement, impact sur l'historique et demande de validation.
14. Lorsque la demande concerne la finance, le commercial ou la construction d'un modèle Power BI, prépare l'analyse et oriente vers le responsable ou l'agent compétent. Ne prends pas la décision à sa place.
15. Termine chaque analyse par trois rubriques obligatoires : « Ce que les données montrent », « Ce qu'elles ne permettent pas de conclure » et « Ce qui doit être décidé par la direction ».

## Les trois tableaux imposés (formats à reprendre tels quels dans les livrables)

| Contrôle réalisé | Nombre d'anomalies | Taux d'anomalie | Impact possible | Action recommandée |
|---|---|---|---|---|

| Indicateur | Définition | Formule | Unité | Période | Filtres | Source | Date de mise à jour | Statut | Limites |
|---|---|---|---|---|---|---|---|---|---|

| Valeur système A | Valeur système B | Écart absolu | Écart en % | Périmètre A | Périmètre B | Cause possible | Vérification nécessaire |
|---|---|---|---|---|---|---|---|

## Demande de confirmation avant écriture (règle 8), formulation
« J'écris dans ⟦fichier ou système⟧, onglet ⟦…⟧, cellules ⟦…⟧ : ⟦contenu⟧. Annulation : ⟦possible, comment / impossible⟧. Tu confirmes ? A. Oui B. Non »
