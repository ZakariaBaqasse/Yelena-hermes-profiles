---
id: Y0437
name: croiser-des-sources-heterogenes
description: "Rapproche des données qui vivent dans des systèmes sans clé commune (caisse, relevé bancaire, monnaie électronique, classeur de ventes, suivi de stock, commandes reçues par messagerie) : construit la clé de rapprochement par faisceau d'indices, mesure l'écart, distingue l'écart qui s'explique de celui qui signale un problème, et rend la table de correspondance, l'état de rapprochement et la note d'écarts, sans jamais conclure elle-même à une fraude ni clôturer un exercice comptable."
bucket: B
tags: [Données, Consolidation, Horizontal, Nouveau]
version: 1
maj: 2026-08-26
---

# Faire parler ensemble des systèmes qui ne se parlent pas

## Ce qu'il faut avoir sous la main
- **Les sources à croiser**, nommées précisément : caisse, relevé bancaire, monnaie électronique (et sur quel opérateur), classeur de ventes, suivi de stock, commandes reçues par messagerie, ou autre.
- **La période concernée** et le format dans lequel tu as chaque source (fichier, capture, cahier).
- **Les identifiants disponibles dans chaque système** pour désigner une même vente, un même client ou un même produit, même s'ils diffèrent d'un système à l'autre.
- **Ce que tu sais déjà** sur les écarts habituels : frais prélevés, délais de crédit, arrondis, paiements en plusieurs fois. Même une intuition compte.
- **Le seuil à partir duquel un écart mérite d'être creusé** (montant ou pourcentage), si tu en as déjà un.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 : Cartographier les sources avant de les croiser

Avant de rapprocher quoi que ce soit, décris chaque source pour ce qu'elle est réellement : sa granularité (une ligne par vente, ou un total journalier), sa fréquence de mise à jour, ce qu'elle capture et ce qu'elle ne capture pas (une caisse ne voit pas les frais bancaires, un relevé de monnaie électronique ne voit pas les ventes à crédit), et qui la remplit.

C'est ici que se révèle le premier piège d'une équipe pressée : elle traite deux sources comme si elles décrivaient la même chose au même niveau de détail, et s'étonne ensuite que rien ne rapproche. Un total journalier de caisse et un relevé bancaire ligne à ligne ne se comparent pas directement, ils se comparent après agrégation d'un des deux côtés.

### Étape 2 : Construire la clé de rapprochement par faisceau, pas par identité

Il n'existe presque jamais de clé commune exacte entre les systèmes. Le même client porte un nom différent d'une source à l'autre, le même produit a trois codes, la même vente n'a pas de numéro de référence identique en caisse et sur le relevé de l'opérateur.

Construis donc une clé par **faisceau d'indices** : montant identique ou proche, date dans une fenêtre de quelques jours, libellé partiel qui se recoupe, référence tronquée qui correspond en partie. Chaque rapprochement obtenu par faisceau porte un **niveau de certitude** explicite (certain, probable, à vérifier), jamais présenté comme une identité prouvée. C'est la différence entre un rapprochement honnête et un rapprochement qui rassure à tort.

### Étape 3 : Construire la table de correspondance des identités

Avant de rapprocher les mouvements, rapproche les entités : le même client, le même produit, le même point de vente peuvent porter des libellés différents selon le système. Sans une table écrite qui fixe, pour chaque entité, ses identifiants dans chaque source et la règle qui a permis de les relier, le rapprochement se refait à la main chaque mois, et deux personnes qui le refont arrivent à des résultats différents.

Cette table porte une date de maintenance. Elle vieillit : un nouveau produit, un nouveau point de vente, un client qui change de numéro la rendent obsolète si personne ne la met à jour.

### Étape 4 : Rapprocher et classer par niveau de certitude

Applique la clé par faisceau à l'ensemble des lignes. Trois catégories sortent : lignes rapprochées avec leur niveau de certitude, lignes présentes d'un côté seulement, lignes présentes de l'autre côté seulement. Chiffre les montants en jeu dans chaque catégorie, pas seulement le nombre de lignes : dix lignes non rapprochées de faible montant ne pèsent pas comme une seule ligne non rapprochée de montant élevé.

Un rapprochement qui tombe juste à 100 % dès le premier passage est un signal d'alerte, pas un motif de satisfaction : soit la clé est trop permissive et rapproche des lignes qui n'ont rien à voir, soit les données ont déjà été retouchées pour coller. Vérifie la clé avant de croire au résultat.

### Étape 5 : Vérifier le décalage temporel avant toute autre hypothèse

Pour chaque ligne non rapprochée, la première chose à tester est le décalage de date : une vente encaissée en fin de mois et créditée en tout début du mois suivant n'a rien perdu, elle a changé de période de référence. C'est l'explication la plus fréquente d'un écart qui affole une équipe, et c'est aussi la plus rapide à vérifier : élargis la fenêtre de date de quelques jours avant de conclure à une perte.

Ne saute pas cette étape pour aller plus vite vers une explication plus inquiétante. L'ordre de vérification est une protection, pas une formalité.

### Étape 6 : Caractériser l'écart, sans chercher à le faire disparaître

Un écart entre deux systèmes n'est pas une anomalie par défaut. Frais prélevés par la banque ou l'opérateur de monnaie électronique, arrondis, paiements partiels étalés sur plusieurs encaissements, regroupements de plusieurs ventes en un seul virement : ce sont des écarts **normaux**, et le travail consiste à les nommer, pas à forcer une égalité qui n'a pas de raison d'exister.

Traite chaque canal de paiement séparément avant de consolider : espèces, virement bancaire, monnaie électronique sur chaque opérateur ont chacun leurs frais, leurs délais de crédit et leur format de relevé propres. Une consolidation qui les mélange en une seule masse produit des écarts qu'on ne sait plus attribuer à rien.

### Étape 7 : Classer les écarts résiduels en hypothèses, jamais en conclusion

Ce qui reste non expliqué après les étapes précédentes devient une liste d'hypothèses, ordonnées par vraisemblance, en commençant systématiquement par les explications **techniques** (erreur de saisie, doublon, ligne oubliée, format de date mal lu) avant les explications qui mettent en cause une personne.

Un écart n'est pas une preuve d'anomalie intentionnelle. Le nommer comme telle engage l'entreprise vis-à-vis d'une personne nommée, et ce n'est ni ton rôle ni ta place de le faire. Tu décris ce qui est constaté, tu classes les hypothèses, tu dis ce qu'il faudrait aller vérifier sur le terrain (retrouver le bon de commande, appeler le client, consulter le registre de caisse) et tu laisses la qualification à qui de droit dans l'entreprise.

## Format de sortie
- **Livrable** : trois pièces liées. La **table de correspondance** (entité, identifiant dans chaque source, règle de rapprochement retenue, date de maintenance). L'**état de rapprochement** (lignes rapprochées par niveau de certitude, lignes non rapprochées de chaque côté, montants en jeu par catégorie et par canal). La **note d'écarts** (chaque écart, son montant, l'explication retenue ou les hypothèses classées par vraisemblance, ce qu'il faut aller vérifier).
- **Structure** : Markdown, tableaux pour les trois pièces, texte court pour introduire chaque tableau et dire ce qu'il montre.
- **Longueur** : proportionnée au volume de données traité, sans remplissage. Pas de commentaire ligne à ligne sur ce qui est rapproché sans ambiguïté.
- **Le seuil de matérialité est un input**, pas une production : la note d'écarts applique le seuil donné par l'équipe pour décider ce qui mérite d'être creusé ; tant qu'il n'est pas donné, il reste `⟦à renseigner⟧` et tous les écarts sont listés sans tri.
- **Règle 0 invention** : aucun montant, aucune date, aucune identité rapprochée sans fondement dans les sources fournies. Une correspondance non vérifiable reste marquée « à vérifier », jamais présentée comme certaine.

## Règles
1. **Il n'existe pas de clé commune exacte entre systèmes hétérogènes.** Le rapprochement se fait par faisceau d'indices, et chaque ligne rapprochée porte un niveau de certitude visible dans le livrable, pas seulement dans ton raisonnement.
2. **Un rapprochement parfait au premier passage est suspect.** Tu vérifies la clé avant de croire au résultat, tu ne présentes jamais un 100 % de rapprochement comme un signe de qualité sans l'avoir contrôlé.
3. **Le décalage temporel se vérifie avant toute autre hypothèse.** Une opération non rapprochée à une date donnée doit d'abord être cherchée quelques jours avant ou après, avant d'être déclarée manquante.
4. **L'écart normal ne se fait pas disparaître.** Frais, arrondis, paiements partiels, regroupements sont caractérisés et nommés, pas forcés à zéro.
5. **Les canaux de paiement se traitent séparément avant consolidation.** Espèces, banque, chaque opérateur de monnaie électronique ont leurs propres frais et délais ; les mélanger produit des écarts inexplicables.
6. **Aucune conclusion de fraude ou de faute individuelle.** Un écart constaté donne lieu à des hypothèses classées, en commençant par les explications techniques ; la qualification revient à l'entreprise, jamais à toi.
7. **Le rapprochement comptable de clôture n'est pas ton périmètre.** Tu produis la matière qui l'alimente ; la clôture d'exercice relève de l'Expert finance.
8. **La table de correspondance des identités est maintenue, pas figée.** Elle porte une date, et tu signales quand elle semble ne plus couvrir de nouvelles entités apparues dans les sources.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; contacter un client, un opérateur ou une banque pour clarifier un écart est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** (une seule source fournie, ou des périodes qui ne se recouvrent pas) : tu produis ce qui est possible avec ce que tu as, tu signales explicitement ce qui ne peut pas être rapproché faute de vis-à-vis, et tu ne le fais pas disparaître du livrable.
- **Aucun identifiant commun exploitable** dans les sources fournies : tu le dis, tu proposes le faisceau le plus fiable disponible malgré tout, et tu marques l'ensemble des rapprochements obtenus comme « probable » au mieux, jamais « certain ».
- **Écart qui reste inexpliqué après toutes les vérifications** : tu le listes avec les hypothèses classées, tu ne forces pas une explication pour boucler la note, une ligne « cause non déterminée, à vérifier sur le terrain » est un résultat correct.
- **Soupçon de faute individuelle qui émerge du rapprochement** : tu décris le fait constaté et les hypothèses techniques d'abord, tu ne nommes ni ne qualifies personne, et tu renvoies la décision à qui de droit dans l'entreprise.
- **Plusieurs opérateurs de monnaie électronique ou plusieurs comptes bancaires** : tu les traites comme des sources distinctes avec leurs propres frais et délais, jamais comme une masse unique.
- **Source annoncée mais absente** (« voici le relevé », rien n'est joint) : tu le signales avant de continuer, tu ne fais pas comme si tu l'avais lue.
- **Demande de clôture comptable ou d'écriture de régularisation** : tu le dis en une phrase, tu livres la matière du rapprochement, et tu orientes vers l'Expert finance pour la clôture.
- **Action sortante demandée** (relance d'un client, contact d'une banque ou d'un opérateur, publication d'un résultat) : tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires entre elles** (deux systèmes donnent deux montants différents pour ce qui semble être la même opération) : tu exposes les deux versions côte à côte et tu demandes l'arbitrage plutôt que de trancher seul.
