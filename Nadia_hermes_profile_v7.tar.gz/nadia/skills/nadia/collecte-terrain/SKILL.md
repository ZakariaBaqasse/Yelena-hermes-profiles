---
id: Y0438
name: collecte-terrain
description: "Conçoit la collecte d'une donnée que l'entreprise ne possède pas encore : relevé de points de vente, inventaire, enquête client, comptage, suivi de tournée. Produit la fiche pensée pour celui qui la remplit debout sur un téléphone d'entrée de gamme, le protocole terrain (support, mode hors connexion, identifiant du point de collecte) et le plan de contrôle qualité posé à la saisie plutôt qu'après, sans jamais fixer elle-même un seuil, un barème ou une durée de conservation."
bucket: B
tags: [Données, Collecte, Horizontal, Nouveau]
version: 2
maj: 2026-09-23
---

# Recueillir une donnée qui n'existe pas encore, sur le terrain et sur un téléphone

## Ce qu'il faut avoir sous la main
- **La donnée cherchée** et **la décision qu'elle doit servir** : à quoi elle va répondre une fois consolidée.
- **Qui collecte** : équipe interne, agents payés à la visite ou au forfait, prestataire externe, et combien de personnes.
- **Où et dans quelles conditions** : marché, boutique, domicile client, en mouvement ; réseau disponible sur la zone ; niveau des téléphones utilisés.
- **La fréquence** : ponctuelle, ou relevé répété dans le temps sur les mêmes points.
- **Ce qui existe déjà** : un référentiel de points de vente ou de clients, une fiche antérieure, un outil de collecte déjà en place.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`), tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1, Cadrer la donnée et son usage avant d'écrire une seule question

Avant toute fiche : à quelle décision cette donnée sert, qui la lira, à quelle fréquence elle sera reprise. Une fiche conçue sans destination précise dérive vers l'exhaustivité, « on demande tout pendant qu'on y est », et c'est exactement ce qui la rend trop longue pour le terrain.

Distingue collecte **ponctuelle** (un état des lieux, une fois) et collecte **répétée** (un suivi dans le temps, où la comparabilité entre passages compte plus que le détail d'un seul passage). Le choix conditionne tout ce qui suit, en particulier l'étape du référentiel.

### Étape 2, Construire le référentiel des points de collecte

Piège nommé : sans identifiant stable de lieu, de point de vente ou de client, les relevés successifs ne se comparent pas. Une même boutique notée « Boutique Adjamé » un mois et « Boutique du marché d'Adjamé » le mois suivant devient deux points distincts dans la consolidation, et le suivi dans le temps s'effondre sans que personne ne le remarque avant l'analyse.

Avant la première collecte, fixe un identifiant unique par point (code, numéro, ou combinaison stable de champs fermés) et une liste de référence que l'agent choisit dedans plutôt que de la ressaisir. Si ce référentiel n'existe pas encore, dis-le explicitement : le construire est un prérequis, pas une option, et la première collecte sert souvent à le fonder.

### Étape 3, Écrire la fiche dans l'ordre du terrain, pas dans l'ordre de l'analyse

Piège nommé, le plus fréquent : une fiche écrite du point de vue de celui qui analysera, avec les questions rangées par thème logique pour un tableau croisé plutôt que dans l'ordre où l'information se présente réellement sur le terrain. Résultat, l'agent revient en arrière, saute des champs, ou remplit de mémoire en fin de journée : cette donnée-là est pire qu'aucune donnée, parce qu'elle a l'apparence de la fiabilité.

Règle de coupe : la fiche tient dans le temps réel disponible sur place, pas dans le temps qu'on souhaiterait lui accorder. Compte le nombre de champs, estime le temps de remplissage par champ dans les conditions réelles (debout, client qui attend, lumière du jour qui baisse), et coupe jusqu'à ce que le total soit crédible. Chaque champ retiré doit pouvoir se justifier par son absence à l'étape 1 : s'il ne sert à aucune décision nommée, il sort.

Deuxième piège nommé : le champ libre. Une question ouverte sur un nom de lieu, une activité ou un motif produit autant d'orthographes que de collecteurs, et rend le comptage impossible en aval. Chaque fois que la liste des réponses possibles est connaissable à l'avance, on la ferme : liste déroulante, cases à cocher, échelle courte. On garde une valeur « autre », mais avec précision obligatoire associée (un petit champ texte qui ne s'ouvre que si « autre » est coché), pour ne pas perdre l'information imprévue tout en gardant le gros du flux fermé et comptable.

### Étape 4, Choisir le support en fonction des conditions réelles, pas de l'idéal

Piège nommé : la connexion supposée. Un formulaire qui exige d'être en ligne au moment de la saisie perd purement et simplement les relevés faits dans une zone sans réseau, en marge de marché, en zone rurale, dans un sous-sol de commerce, ce qui est une part significative du terrain ouest-africain. Le protocole prévoit toujours un **mode hors connexion** : saisie possible sans réseau, stockage local sur l'appareil, synchronisation différée à un moment identifié (retour au dépôt, passage en zone couverte, fin de journée).

Quand le support retenu est un formulaire en ligne et que le poste a l'intégration `integrations/tally/`, la fiche se fabrique réellement dans Tally, en brouillon, par `python3 integrations/tally/tally.py creer <definition.json>` : la marche à suivre (définition, publication sur accord, relève des réponses) est dans la compétence `questionnaire-et-depouillement`, étapes 3 bis et 4 bis. Tally est un formulaire web : avant de le proposer pour une zone sans réseau, vérifie qu'il couvre le mode hors connexion décrit ci-dessus, et si tu ne peux pas l'établir, dis-le au lieu de le supposer.

Le support tient compte du parc réel : téléphones d'entrée de gamme, écran petit, saisie tactile parfois lente, batterie à ménager. Une fiche pensée pour un smartphone récent avec beaucoup de défilement ne se transpose pas telle quelle. Le papier reste une option légitime dans certains contextes (zone durablement sans réseau, agent non équipé), à condition de prévoir explicitement la ressaisie et son délai : le papier n'est pas la donnée finale, c'est une étape avant elle, et cette étape a un coût qu'il faut nommer, pas ignorer.

### Étape 5, Poser les contrôles au moment de la saisie, pas après coup

Piège nommé : contrôler après coup. Une incohérence détectée au bureau trois jours plus tard, un chiffre hors norme, une réponse qui contredit une autre, ne se corrige quasiment jamais : l'agent est reparti, le client n'est plus là, le souvenir s'est effacé. Un relevé douteux découvert tard est un relevé perdu, pas un relevé corrigé.

Les contrôles se posent donc dans l'outil de saisie lui-même :
- **Bornes** sur les champs numériques (une quantité négative ou absurdement élevée est refusée à la saisie, pas signalée après).
- **Formats obligatoires** sur les champs qui en ont un (numéro de téléphone, code du point de collecte pris dans le référentiel et non retapé).
- **Cohérence entre deux réponses** vérifiée en direct (un stock déclaré à zéro ne peut pas cohabiter avec une vente déclarée sur le même produit sans qu'une alerte se déclenche).
- **Photo exigée** pour certaines valeurs sensibles ou extrêmes, comme preuve mobilisable en cas de doute a posteriori.

### Étape 6, Compter le coût de la collecte pour celui qui la fait, et poser le cadre des données personnelles

Piège nommé : oublier ce que la collecte coûte à celui qui la fait. Un agent payé au nombre de visites, pas au nombre de champs remplis correctement, qui doit renseigner quinze champs par point, remplira quinze champs faux plutôt que de perdre du temps sur une visite non rémunérée à sa juste valeur. La fiche et le mode de rémunération de la collecte ne sont pas deux sujets séparés : une fiche trop lourde pour l'incitation en place produit mécaniquement une donnée dégradée, et ce n'est pas la faute de l'agent.

Piège nommé, cadre juridique : on ne recueille que ce qui sert une décision nommée à l'étape 1, on dit à la personne concernée pourquoi cette information est demandée quand elle porte sur elle (client, employé), et la conservation de toute donnée personnelle relève du cadre de protection des données personnelles, dont l'autorité compétente (ARTCI en Côte d'Ivoire) a la charge. Cette skill **ne fixe** ni durée de conservation, ni base légale précise, ni sanction : ces éléments sont `⟦à renseigner⟧` par l'équipe juridique ou conformité, et la fiche les respecte une fois qu'ils sont donnés.

### Étape 7, Organiser la remontée, la consolidation et le plan de contrôle final

Le protocole précise : qui synchronise, à quel rythme, sur quel canal (upload direct de l'outil, transfert via un point de collecte central, remontée par WhatsApp d'un fichier consolidé si c'est le canal réellement en usage dans l'équipe), et qui reçoit la responsabilité de vérifier que rien ne manque avant la fin de la fenêtre de collecte.

Le plan de contrôle distingue trois niveaux : ce qui est vérifié **à la saisie** (étape 5), ce qui est vérifié **à la remontée** (complétude, cohérence entre points, doublons sur l'identifiant), et un **échantillon recontrôlé** a posteriori par rappel téléphonique, revisite ou recoupement avec une source indépendante quand elle existe. Pour un relevé jugé douteux, le protocole dit explicitement ce qu'on en fait : rejet, marquage « à vérifier » sans le supprimer, ou recontrôle ciblé, mais jamais une correction silencieuse qui remplace la valeur douteuse par une valeur plausible.

## Format de sortie
- **Livrable** : la fiche de collecte (questions dans l'ordre du terrain, listes fermées, champs obligatoires, contrôles à la saisie, temps de remplissage estimé), le protocole (qui collecte, où, quand, avec quel support, mode hors connexion, moment de synchronisation, identifiant du point de collecte), et le plan de contrôle (vérifications à la saisie, à la remontée, échantillon recontrôlé, traitement d'un relevé douteux).
- **Structure** : Markdown clair, answer-first (la fiche et le protocole d'abord, le raisonnement de conception ensuite en points courts) ; tableaux pour la fiche de collecte et le plan de contrôle.
- **Longueur** : proportionnée à la collecte réelle. Une fiche de collecte tient sur une page ; le protocole et le plan de contrôle, une à deux pages supplémentaires.
- **Les seuils, barèmes et durées de conservation sont un input**, pas une production : bornes numériques, effectif d'échantillon recontrôlé, durée de conservation des données personnelles restent `⟦à renseigner⟧` tant que l'équipe ne les a pas donnés.
- **Règle 0 invention** : aucune donnée chiffrée ou factuelle inventée. Si une information manque, la demander ou la marquer « à confirmer / [placeholder] ».

## Règles
1. **La fiche s'écrit du point de vue de celui qui la remplit, jamais de celui qui l'analysera.** Le test de validité d'une fiche est le temps réel disponible sur le terrain, pas la richesse souhaitable du tableau de sortie.
2. **Tout champ fermable est fermé.** Une question ouverte n'est conservée que si la liste des réponses possibles est réellement inconnaissable à l'avance ; sinon, liste fermée avec valeur « autre » à précision obligatoire.
3. **Le mode hors connexion est la norme, pas l'exception.** Un protocole qui suppose un réseau disponible en continu n'est pas un protocole terrain valide pour cette skill.
4. **Les contrôles se posent à la saisie.** Un contrôle prévu « à l'analyse » sur une donnée qu'on ne peut plus recorriger n'est pas un contrôle, c'est un constat tardif.
5. **Pas d'identifiant stable, pas de collecte répétée.** Tant que le référentiel des points de collecte n'existe pas, on le construit avant, ou on le dit explicitement comme limite de la première collecte.
6. **0 chiffre, seuil ou durée inventés.** Bornes de contrôle, taille d'échantillon recontrôlé, durée de conservation des données personnelles : jamais produits sans être fournis par l'équipe, `⟦à renseigner⟧` sinon.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]`, jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; déployer un outil de collecte, envoyer une fiche à des agents ou lancer une campagne de terrain est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une collecte ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Input incomplet** : tu produis avec ce que tu as, en étiquetant tes hypothèses (`[hypothèse : …]`) et en marquant les manques `[à confirmer]`. Tu ne redemandes que ce qui est indispensable et impossible à supposer raisonnablement.
- **Aucun référentiel de points de collecte** : tu le dis explicitement, tu proposes de le construire comme premier livrable, et la collecte de données proprement dite attend cette base pour être répétable dans le temps.
- **Zone sans réseau confirmée** : le protocole part du mode hors connexion par défaut, sans qu'il faille le redemander.
- **Agent payé au volume plutôt qu'à la qualité** : tu signales la tension entre incitation et longueur de fiche, et tu proposes une version resserrée compatible avec le temps réellement rémunéré.
- **Donnée personnelle en jeu (client, employé) sans cadre de conservation défini** : tu nommes l'autorité compétente sur la protection des données et tu marques la durée et la base légale `⟦à renseigner⟧`, tu ne les inventes jamais.
- **Collecte déjà en cours avec une fiche existante qui pose problème** : tu diagnostiques la fiche en place à l'aune des sept pièges avant de proposer une refonte, plutôt que de repartir de zéro sans expliquer ce qui ne va pas.
- **Support papier imposé par le contexte** : tu l'acceptes comme option légitime, mais tu rends obligatoire la description explicite de l'étape de ressaisie et de son délai.
- **Demande hors périmètre** (analyse des données une fois collectées, dimensionnement de l'échantillon statistique, choix de l'outil logiciel précis) : tu le dis en une phrase, tu traites ce qui relève de la conception de la collecte, et tu orientes vers la compétence ou l'expertise qui convient.
- **Action sortante demandée** (envoi de la fiche aux agents, activation d'un outil, lancement de la campagne) : tu prépares le livrable et tu t'arrêtes pour validation humaine.

## Historique
- v2, 23/09/2026 : renvoi vers la fabrication du formulaire dans Tally (`integrations/tally/tally.py`, marche à suivre dans `questionnaire-et-depouillement`), avec la réserve du mode hors connexion, séance Sync agents training.
