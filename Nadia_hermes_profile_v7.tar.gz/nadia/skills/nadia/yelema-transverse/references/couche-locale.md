# Couche locale : Nadia · Donnée et mesure

Tirée du tableur « Yelema, Couches locales centralisées » le 30/09/2026. Elle porte le PAYS (Côte d'Ivoire, UEMOA, OHADA), jamais la maison ni le client.

**Comment la lire.** Chaque élément dit pourquoi tu en as besoin, où est la source primaire (elle fait foi) et, quand la pièce existe, où la lire ici : `references/pieces/<fichier>.md`, dans ce même skill. Les chemins `memory/reference/bases-locales/...` cités dans les commentaires désignent l'ancien emplacement OpenClaw : dans ce profil, la pièce est dans `references/pieces/`. Un élément sans pièce se cherche avec `aller-chercher`, et une absence se dit avec l'endroit où tu as regardé.

⛔ Une date « À revérifier le » dépassée : le chiffre n'engage plus, rouvre la source avant de le citer.

## Contexte pays

### CL-NADIA-01 · Repères institutionnels de la Côte d'Ivoire
- **Pourquoi** : Savoir qui décide quoi avant d'écrire à qui que ce soit
- **Où chercher** : Sites officiels de la présidence, de la primature et des ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MaLTEATML7MTUOV8am5VqHrbw1Sa5N3EaGb9Lp5E6qo.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/12/2026
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Elle donne la composition du gouvernement en fonction et SURTOUT la hiérarchie de fiabilité quand deux sources divergent (1 fait foi : JO, décret, communiqué du Conseil des ministres, site de l'institution ; 2 quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM ; 3 fiable à dater : AIP, Reuters, AFP, APA), plus les cinq régulateurs qui peuvent arrêter un travail : CSP, HACA, ANP, Autorité de protection des données, ARTCI. ⛔ La liste des ministres se rouvre sur gouv.ci avant toute citation : le fichier local dit qui était en fonction le 10/09, pas qui l'est aujourd'hui. || Source identifiée, note encore à fabriquer. Le relevé du gouvernement de 2026 existe sur la machine (memory/reference/gouvernement-2026.md chez LOKOLI) et sert de base. Pour un poste juridique, la note utile n'est pas la liste des ministres mais la chaîne qui décide d'un texte : Assemblée nationale et Sénat pour la loi, Président pour l'ordonnance, Secrétariat général du Gouvernement pour la publication au Journal officiel, juridictions pour l'application. POINT DUR À PORTER : le Journal officiel n'est PAS en accès libre en ligne ; le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66). Toute date de publication citée sans avoir ouvert le JO est une date de seconde main, et doit être annoncée comme telle. Écart tranché le 18/09 : décret n°2026-05/2 du 07/01/2026, publié au Journal officiel n°5 (Spécial) du 17/02/2026, il ne reste que DEUX districts autonomes, Abidjan et Yamoussoukro.

### CL-NADIA-02 · Carte administrative et découpage du territoire
- **Pourquoi** : Un district, une région et une commune ne se confondent pas dans un livrable
- **Où chercher** : Ministère de l'Intérieur, Institut national de la statistique
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://web.sgg.gouv.ci/journal-officiel
- **Pièce, ici** : references/pieces/1ZU_xQOPr96SfkXmO467cACEnfXsCtbxG-CQtIg_sCII.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, et elle désamorce un piège. ⛔ IL NE RESTE QUE DEUX DISTRICTS AUTONOMES, Abidjan et Yamoussoukro : décret n° 2026-05/2 du 07/01/2026, JO n° 5 spécial du 17/02/2026. Jamais douze ni quatorze. ⛔ ET LE JEU DE DONNÉES OFFICIEL EST PÉRIMÉ : téléchargé et compté le 20/09, circonscriptions-et-communes.csv porte 19 régions, 57 départements, 243 sous-préfectures, 198 communes, c'est-à-dire le découpage d'AVANT la réforme de 2011 (AGNEBY, FROMAGER, MOYEN CAVALLY, N'ZI COMOE n'existent plus). Il sert à retrouver une commune, pas à nommer une région. Le découpage actuel se lit sur population-densite-par-region.csv. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. RÉSOLU le 17/09 au soir. Le décret n°2026-05/2 du 07/01/2026 abroge le décret n°2021-276 du 09/06/2021 qui créait douze districts autonomes ; restent Abidjan et Yamoussoukro, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. PUBLIÉ AU JOURNAL OFFICIEL N°5 (SPÉCIAL) DU 17/02/2026, d'après le recensement mensuel d'Ivoire-Juriste, qui cite systématiquement numéro et date de JO ; cohérence vérifiée, le texte est absent de son récapitulatif de janvier (JO n°2, 3, 4, 9 et Spécial n°1 du 12/01) et présent dans celui de février. La presse ne l'a relevé que le 18/03/2026, d'où l'idée fausse d'une suppression non publiée : il n'y a pas eu de communiqué, il y a bien eu publication, dans un numéro spécial, six semaines après la signature. Absence de publicité n'est pas absence de publication. TEXTE PRIMAIRE NON LU : le J.O. n'est pas en accès libre, le service JO du SGG délivre un code de téléchargement par téléphone (+225 20 32 59 66), la rubrique Décrets gratuite de web.sgg.gouv.ci s'arrête en 2012 et sa rubrique Journal officiel n'expose que des numéros de 2002. Wikipédia annonce encore 14 districts. Un livrable écrit DEUX districts autonomes en citant le décret et son numéro de JO, jamais douze.

### CL-NADIA-03 · Calendrier local : fériés, saisons, périodes creuses
- **Pourquoi** : Une relance en pleine fête ou en pleine saison des pluies tombe à plat
- **Où chercher** : Journal officiel, calendrier des fêtes légales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Pièce, ici** : references/pieces/1MBCinHoB9CqfwM3sqIjFd57Iyt_vU6Cjzwd8W2e9NE4.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/01/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve, adossée à bases-locales/droit-travail-ci/JOURS-FERIES.md qui est complet. Le point qui commande une planification : SEULS LE 1er MAI ET LE 7 AOÛT sont fériés, chômés ET payés pour tous, parce qu'ils tiennent de la loi (Code du travail art. 24.2) ; le reste dépend de la convention interprofessionnelle de 1977 art. 64, et le Maouloud comme le lendemain de la nuit du destin n'y figurent pas. ⛔ LES SAISONS NE SONT PAS COUVERTES : sodexam.com a refusé la connexion le 20/09, rien sur disque. Ne pas écrire de fenêtre de saison sans ouvrir une source. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Déjà sur cette machine, dans le socle commun ~/.claude/outils-communs/droit-travail-ci/ : JOURS-FERIES.md distingue férié, chômé et payé article par article, l'article 64 de la convention de 1977 liste les fériés chômés payés, l'article 65 prévoit la majoration de 100 %. Kouassi n'a pas de lien vers ce socle : un lien symbolique suffit, aucune recherche. Ce qui manque et qui est signalé dans le socle : le décret fixant la liste n'a pas été téléchargé, et les fêtes mobiles s'annoncent chaque année par communiqué ministériel.

## Zone UEMOA

### CL-NADIA-04 · Ce qui est commun aux huit pays, et ce qui ne l'est pas
- **Pourquoi** : Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout
- **Où chercher** : Commission de l'UEMOA, BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.uemoa.int/tarif-exterieur-commun
- **Pièce, ici** : references/pieces/12eaIaZTCpT-DvtT--4OcqMWQZZTGaY2SGbdlfY_Srgg.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Trois périmètres qu'on confond : OHADA 17 États (droit des affaires), UEMOA 8 États (monnaie, relations financières extérieures), CEDEAO 15 États. Ce qui est commun : le droit des affaires, la monnaie, les relations financières extérieures. ⛔ CE QUI NE L'EST PAS : le droit du travail, la fiscalité (TVA 18 %, réduit 9 %, vérifié le 20/09 sur la synthèse DGI), la publicité, le SMIG, les jours fériés. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Non renseigné faute de source lisible. uemoa.int répond mais sert une chaîne de certificat incomplète : un navigateur la complète, aucun de nos outils ne le fait (curl code 60, verifier.py CERTIFICATE_VERIFY_FAILED, 200 seulement en désactivant la vérification). Même défaut que dgddl.gouv.ci. Le tarif extérieur commun n'est donc PAS cité comme lu, d'autant qu'il y a là un écart réel à vérifier sur pièce : le TEC de l'UEMOA a quatre bandes, celui de la CEDEAO en a cinq depuis 2015, et savoir lequel s'applique change un devis à l'import.

### CL-NADIA-05 · Monnaie, ordres de grandeur et unités d'ici
- **Pourquoi** : Convertir mentalement en euros produit des montants qui ne parlent à personne
- **Où chercher** : BCEAO
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.bceao.int/fr/content/billets-et-pieces
- **Pièce, ici** : references/pieces/1TmSy8upehxlJP9AoUJSYUkPoNViLg66TY-11S2O89tE.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage neuve. Parité fixe 655,957 XOF pour 1 EUR. ⛔ On chiffre en FCFA d'abord, la conversion vient après et entre parenthèses ; jamais un montant en dollars sans son taux et sa date. Repères posés avec leur source : SMIG 75 000 FCFA/mois depuis le 01/01/2023, TVA 18 %, population 29 389 150 au RGPH 2021, urbanisation 53,5 %, PIB nominal 2023 47 913,3 milliards FCFA (croissance réelle 7,2 %), Abidjan 5 654 633 habitants soit 19,2 % du pays et 35,9 % de l'urbain. Le SMIG donne le pas de raisonnement : 300 000 FCFA valent quatre SMIG. NON COUVERT : panier moyen, revenu médian, prix de détail. || REPRIS LE 18/09 du socle commun déjà établi sur les onglets renseignés : la réponse ne dépend pas du métier du poste. Établi sur bceao.int : huit États membres (Bénin, Burkina, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo), parité fixe 655,957 XOF pour 1 EUR, coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500. La parité est déjà recalculée et vérifiée dans le PND de Lokoli. La règle d'usage est déjà dans son corpus : chiffrer en XOF d'abord, la conversion ensuite et seulement si l'interlocuteur la demande. Aucun montant en dollars sans indiquer le taux et sa date, les conversions circulent à des valeurs divergentes.

## Droit des affaires

### CL-NADIA-06 · OHADA : les actes uniformes qui touchent mon métier
- **Pourquoi** : Le droit applicable aux sociétés n'est pas national, il est régional
- **Où chercher** : Site de l'OHADA, textes des actes uniformes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/09/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base complète sur disque, et c'est la plus solide des dix-sept : les DIX actes uniformes en PDF et en texte cherchable, avec leur date d'adoption et leur nombre d'articles, plus l'AUDCIF tel que publié au Journal officiel. AUDCG-2010 (307 art.), AUSCGIE-2014 (920), AUSCOOP-2010 (397), AUS-2010 (228), AUPSRVE-2023 (338), AUPCAP-2015 (258), AUDCIF-2017 (113), AUA-2017 (36), AUM-2017 (17), AUCTMR-2003 (31). ⛔ Une réponse se cite par son article, jamais de mémoire : les fichiers .txt existent pour chercher. ⚠ ohadalegis.com sert aussi les versions ABROGÉES de 1997 sous des noms proches, vérifier l'année. || Les dix actes uniformes sont sur la machine depuis le 18/09, dans ~/.claude/outils-communs/ohada/, avec une fiche LISEZ-MOI. POUR UN MÉTIER DE DONNÉE, deux comptent vraiment. L'AUDCIF (droit comptable et information financière, 26/01/2017, 113 articles) commande CE QUI EXISTE COMME CHIFFRE dans une entreprise de la zone : plan de comptes, états financiers, dates d'arrêté. Un indicateur financier qui ne se raccroche à aucun poste du référentiel n'est pas auditable. L'AUSCGIE (sociétés commerciales, 30/01/2014, 920 articles) commande les seuils : commissariat aux comptes, publication des comptes, affectation du résultat. ⚠ CE QUI MANQUE ET QUI LA CONCERNE DIRECTEMENT : le SYSCOHADA lui-même, plan comptable général et dispositif des comptes consolidés, annexes de l'AUDCIF de plus de mille pages, introuvable en libre au 18/09. On peut donc citer une obligation comptable par son article, PAS donner un numéro de compte. Voir aussi la ligne 12 de l'onglet MAMADOU, même manque, même conséquence.

## Langue

### CL-NADIA-07 · Le français d'ici, et quand le nouchi est juste
- **Pourquoi** : Corriger une tournure correcte d'ici en croyant corriger une faute
- **Où chercher** : Corpus interne parler-ivoirien, relevés sur des publications locales
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Vérifié poste par poste le 20/09 : la compétence est bien liée sur les QUINZE. Trois registres et 122 mots nouchis. ⛔ Règle à ne pas défaire : le lexique sert à COMPRENDRE un message reçu, pas à écrire à la place d'un Ivoirien. Le tri des mots qu'une marque peut reprendre demande une passe humaine, toujours due. || CORRIGÉ LE 18/09 : le socle affirmait que la compétence parler-ivoirien était déjà liée à ce poste. C'ÉTAIT FAUX — elle l'était chez KOUASSI, d'où le socle a été repris, et elle manquait sur SEPT postes sur quinze (Awa, Mamadou, Nadia, Alioune, Ibrahim, Salif, Lokoli). Elle est liée sur les sept depuis le 18/09, version du catalogue vérifiée neutre. ⚠ LA LEÇON : un socle transverse porte la réponse du poste SOURCE, pas celle du poste cible. Une affirmation du type « déjà chez lui » doit se vérifier poste par poste avant d'être propagée. Ce que sert ce corpus : la règle de registre (le premier contact reste formel ici, on vouvoie, l'urgence fabriquée est mal vue) autant que le lexique.

## Canaux

### CL-NADIA-10 · Ce qui marche vraiment ici : WhatsApp, Facebook, LinkedIn
- **Pourquoi** : Les usages locaux ne sont pas ceux des articles américains
- **Où chercher** : Relevés d'audience réels sur les comptes de marques ivoiriennes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://www.artci.ci/wp-content/uploads/2026/06/Rsum_Excutif_MSI_2024_200226.pdf
- **Pièce, ici** : references/pieces/1MccNdioS21woKd9T61JJTY8F1sZnVpvnFlkBFtOgI3A.md
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : RÉSOLU LE 18/09 : LA MESURE EXISTE, elle était au mauvais endroit. Enquête MESURE DE LA SOCIÉTÉ DE L'INFORMATION 2024 de l'ARTCI, avec le cabinet Axes Marketing, sur disque dans ~/.claude/outils-communs/numerique-ci/artci/. Méthode publiée : échantillon stratifié représentatif, base 7 474 189 ménages et 27 216 065 individus de 5 ans et plus, entretiens en face à face assistés par tablette, 33 districts et régions. RÉSEAUX SOCIAUX UTILISÉS : WhatsApp 92,8 % · Facebook 82,1 % · TikTok 81,5 % · Messenger 36,6 % · YouTube 35,0 % · Instagram 19,0 % · Telegram 11,0 % · X 2,0 % · LINKEDIN 1,3 % · Ayoba 0,9 % · Skype 0,9 %. ACCÈS : 75,1 % des ménages connectés (87,6 % urbain, 60,4 % rural ; 69 % en 2022, 74 % en 2023), 91,6 % se connectent par le téléphone mobile, 7,11 % par la fibre. ÉQUIPEMENT : mobile 99,3 %, RADIO 99,3 %, télévision 81,1 %, fixe 3,9 %. ⛔ DEUX CHIFFRES QUI CHANGENT UNE RECOMMANDATION : TikTok est au niveau de Facebook, et LinkedIn est à 1,3 %, soit 1,3 % DES INTERNAUTES, et les internautes ne sont que 41,4 % des individus de 5 ans et plus : cela fait environ un Ivoirien sur deux cents. ⚠ CORRIGÉ LE 20/09 : la version précédente écrivait « un habitant sur soixante-dix », ce qui prenait la part des internautes pour une part de population. L'écart vaut un facteur 2,4 et vaut pour TOUS les pourcentages de plateformes de cette enquête — ciblage de dirigeants possible, canal de masse impossible. ⚠ POURQUOI ÇA AVAIT ÉTÉ MANQUÉ : je cherchais dans le rapport trimestriel du marché, qui ne porte que ce que les opérateurs déclarent (parc, trafic, chiffre d'affaires). L'usage des plateformes est une donnée d'enquête ménages, publiée par l'ARTCI sous une rubrique distincte, artci.ci/enquetes-etudes/. UN RÉGULATEUR PUBLIE DEUX FAMILLES DE CHIFFRES QUI NE SONT PAS AU MÊME ENDROIT. ⚡ POUR CE POSTE : l'enquête est aussi un objet d'étude. Sa méthode est publiée, ce qui en fait un des rares jeux ivoiriens citables sans réserve, et un modèle pour CL-NADIA-13 sur les biais des enquêtes locales.

## Sources

### CL-NADIA-11 · Les statistiques publiques disponibles, et leur fraîcheur réelle
- **Pourquoi** : Un chiffre de 2015 présenté comme actuel
- **Où chercher** : Institut national de la statistique, BCEAO, ministères
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base statistiques sur disque : carte des sources, leurs pièges, et des séries mises à l'abri (population RGPH 1975-2021, densité par district et région, hiérarchie urbaine, PIB et croissance 1960-2023, urbanisation, abonnements téléphonie et internet 2023, annuaire de l'état civil). ⛔ UN AGRÉGAT SE CITE EN TROIS MORCEAUX : la valeur, l'année, la source. ⛔ anstat.ci est INACCESSIBLE (épreuve Cloudflare, pas un filtrage d'agent) : le contournement qui marche est de chercher le ministère CO-ÉDITEUR, qui héberge sans protection. ⛔ data.gouv.ci annonce 526 jeux, 256 seulement sont ivoiriens : l'instance est mutualisée et une recherche naïve rend des données FRANÇAISES. || FAIT LE 18/09, base montée : ~/.claude/outils-communs/statistiques-ci/ avec sa fiche, six séries en CSV et l'annuaire de l'état civil de l'INS. ⛔ PREMIER PIÈGE, ET IL FAUSSE TOUT CE QU'ON BÂTIT DESSUS : le portail data.gouv.ci annonce 526 jeux de données, 256 SEULEMENT SONT IVOIRIENS. L'instance est mutualisée, les 270 autres appartiennent à Koumoul, Enedis, EDF, l'ADEME, Grand Poitiers, Saint-Pierre-et-Miquelon ; une recherche naïve y rend des données FRANÇAISES, bilan électrique et annuaire santé Ameli compris. Le producteur ivoirien s'appelle data354-CI, c'est le filtre à poser sur le champ owner.name. Interrogation : https://data.gouv.ci/data-fair/api/v1/datasets?size=500&select=id,title,updatedAt puis /datasets/<id>/lines?size=2000&format=csv. Fraîcheur des 256 jeux ivoiriens : 82 mis à jour en 2026, 114 en 2025, 20 en 2024, 25 en 2023, 15 en 2022. ⛔ SECOND PIÈGE, LE PLUS COÛTEUX : LA DATE DE MISE À JOUR D'UN JEU N'EST PAS LA DATE DE SES DONNÉES. Mesuré : hévéa et palmier à huile, fichier du 19/08/2026, données 2022-2023 ; indicateurs de l'emploi, fichier du 09/07/2026, données 2016, 2017 et 2019 ; abonnements télécoms, fichier du 11/11/2025, données 2023 ; série du PIB dite de 1960 à 2023, fichier du 03/06/2026, s'arrête bien à 2023. La question n'est jamais c'est à jour, mais ça couvre quelle période, et la réponse se lit DANS le jeu. ⚠ L'ORGANISME A CHANGÉ DE NOM : l'Institut national de la statistique publie sous ANStat, sur anstat.ci. ⛔ ANSTAT.CI EST INACCESSIBLE : épreuve de sécurité Cloudflare, Performing security verification, JavaScript et cookies exigés dans un vrai navigateur. Essayé trois fois le 18/09, en direct, avec un navigateur sans interface à la demande de l'équipe, et par miroir. Ce n'est pas un filtrage d'agent qu'on contourne en changeant d'en-tête. ✅ LE CONTOURNEMENT QUI MARCHE, ET IL EST GÉNÉRAL : les publications de l'ANStat sont CO-ÉDITÉES AVEC LES MINISTÈRES, qui les hébergent sans protection. L'annuaire des statistiques de l'état civil de la base vient ainsi de interieur.gouv.ci. Avant de conclure qu'une publication est hors d'atteinte, chercher le ministère co-signataire.

### CL-NADIA-12 · Ce qui n'existe pas en donnée publique ici, et comment faire sans
- **Pourquoi** : Chercher indéfiniment une donnée qui n'est pas publiée
- **Où chercher** : Relevé des manques constatés
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base statistiques sur disque : carte des sources, leurs pièges, et des séries mises à l'abri (population RGPH 1975-2021, densité par district et région, hiérarchie urbaine, PIB et croissance 1960-2023, urbanisation, abonnements téléphonie et internet 2023, annuaire de l'état civil). ⛔ UN AGRÉGAT SE CITE EN TROIS MORCEAUX : la valeur, l'année, la source. ⛔ anstat.ci est INACCESSIBLE (épreuve Cloudflare, pas un filtrage d'agent) : le contournement qui marche est de chercher le ministère CO-ÉDITEUR, qui héberge sans protection. ⛔ data.gouv.ci annonce 526 jeux, 256 seulement sont ivoiriens : l'instance est mutualisée et une recherche naïve rend des données FRANÇAISES. || FAIT LE 18/09, et c'est la ligne qui fait gagner le plus de temps parce qu'elle arrête les recherches vaines. QUATRE MANQUES ÉTABLIS EN CHERCHANT, pas supposés, écrits dans la fiche de ~/.claude/outils-communs/statistiques-ci/ : (1) LA PART D'AUDIENCE PAR PLATEFORME, rien de mesuré sur WhatsApp, Facebook, Instagram ou LinkedIn en Côte d'Ivoire ; l'accès à internet est documenté par le rapport ARTCI du premier trimestre 2026, la répartition entre plateformes n'est documentée nulle part et ce qui circule vient de blogs commerciaux qui se recopient ; (2) LES DÉLAIS BANCAIRES DE PRATIQUE, virement interbancaire, remise de chèque avant disponibilité, aucun texte et aucune source consolidée, cela se relève banque par banque ; (3) LE BARÈME DES TAXES DE L'OAPI, fixé par décision du Conseil d'administration et révisé indépendamment de l'Accord ; (4) LES PANELS DE CONSOMMATION et les données de sortie de caisse. COMMENT FAIRE SANS, dans l'ordre de préférence : un relevé propre fait par nous, daté et documenté, comme les 132 publications relevées sur 11 comptes de marques ivoiriennes le 06/09 ; une donnée voisine dont on assume l'écart EN LE NOMMANT ; une fourchette avec ses bornes. ⛔ Ce qui n'est JAMAIS un substitut : un chiffre trouvé sur un blog sans méthode publiée. Précédent à suivre : les 91 % d'ouverture annoncés par les éditeurs WhatsApp ont été écartés pour ce motif.

## Méthode

### CL-NADIA-13 · Les biais des enquêtes locales : couverture, échantillon, saisonnalité
- **Pourquoi** : Présenter une enquête urbaine comme nationale
- **Où chercher** : Notes méthodologiques des enquêtes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Source primaire** : https://microdata.worldbank.org/index.php/catalog/6273
- **Pièce, ici** : references/pieces/1ZSHXCJj9YarYwIvQcOIROSY2E79xpjzMAAzMY28lQ6c.md
- **Mis à jour** : 22/09/2026
- **À revérifier le** : 22/03/2027
- **Commentaire** : INTÉGRÉ LE 22/09, et le blocage du 18/09 est levé par le co-éditeur, pas par anstat.ci qui reste derrière son épreuve Cloudflare, fichiers compris (/assets/projet/ehcvm2021.pdf rend 403 comme le reste). Les grandes enquêtes ivoiriennes sont CO-PRODUITES : l'EHCVM avec la Commission de l'UEMOA et la Banque mondiale, l'EDS avec le Programme DHS. Les deux co-éditeurs publient la documentation méthodologique en accès libre. Base neuve bases-locales/statistiques-ci/methodologie/ : plan de sondage, base de sondage, terrain, domaines de représentativité et taux de réponse de l'EHCVM 2021/22 et de l'EDS-CI 2021, plus le DDI complet de l'EHCVM. CE QUE LA LECTURE APPORTE, ET ELLE CORRIGE LA RÉSERVE QUE NOUS SERVIONS. (1) La base de sondage de l'EHCVM 2021/22 est le recensement de 2014 : une enquête publiée « 2021-2022 » ignore structurellement tout quartier bâti depuis, c'est-à-dire là où la croissance urbaine est la plus rapide ; et c'est un panel qui revisite les grappes de 2018/19, pas un tirage neuf. (2) LA SAISONNALITÉ NE SE RESERVE PLUS EN BLOC : l'EHCVM coupe son échantillon en deux vagues explicitement pour en tenir compte, novembre-janvier puis avril-juillet, donc l'objection ne la vise pas ; l'EDS-CI 2021 en revanche a collecté du 8 septembre au 30 décembre, une seule fenêtre, et tout ce qui est saisonnier en santé y est mesuré dans cette fenêtre, pas sur l'année. (3) Le domaine de représentativité n'est pas celui dont on a envie : l'EDS est représentative des 14 districts, pas des régions ni des communes. (4) Dans une même enquête les chiffres n'ont pas la même assise : les hommes ne sont interrogés que dans un ménage sur deux, la qualité de l'eau sur 5 ménages par grappe de 28. (5) Un taux de réponse de 99 % mesure les ménages tirés qui ont répondu, il ne dit rien des ménages que la base n'a jamais vus. CHIFFRES : EHCVM 13 693 ménages, 5 675 urbains et 8 018 ruraux, 12 ménages par grappe ; EDS 28 strates, 539 grappes, 15 093 ménages tirés, 14 766 enquêtés, 99 % ménages, 98 % femmes, 97 % hommes. CE QUI RESTE DÛ : les taux de réponse de l'EHCVM, absents de cette documentation, à ne pas supposer semblables à ceux de l'EDS ; le rapport final de l'EDS avec les erreurs de sondage ; le rapport général de l'EHCVM en français ; et les rapports thématiques du RGPH 2021, toujours introuvables chez un ministère co-éditeur.

## Mesure

### CL-NADIA-14 · Ce qu'on peut mesurer sur les canaux réels d'ici
- **Pourquoi** : Promettre un tableau de bord sur des données inaccessibles
- **Où chercher** : Outils des plateformes, relevés internes
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 18/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Note d'usage tirée de la MSI 2024 de l'ARTCI. ⛔ CE QU'ELLE APPORTE EST LA BASE DE CALCUL : les parts de plateformes se comptent sur les INTERNAUTES, qui ne sont que 41,4 % des individus de 5 ans et plus. Facteur 2,4 entre les deux lectures. WhatsApp 92,8 %, Facebook 82,1 %, TikTok 81,5 %, LinkedIn 1,3 %. Et ce que l'enquête NE mesure PAS : ni heures d'audience, ni engagement, ni tarifs. || TROUVÉ LE 18/09, et le constat est sévère. L'inventaire du parc d'outils connectés a été fait par integrations/unipile/comptes.py : QUATRE COMPTES, TROIS WHATSAPP ET UN LINKEDIN. Il n'y a NI INSTAGRAM NI FACEBOOK. Et l'un des trois comptes WhatsApp (22597714432) est en état CREDENTIALS, c'est-à-dire déconnecté, en attente d'une reconnexion humaine. CE QUI EST MESURABLE AUJOURD'HUI : WhatsApp sur deux comptes sur trois, LinkedIn sur un compte. CE QUI NE L'EST PAS : Instagram, Facebook, et l'audience du site web, dont aucun accès analytique n'est connu. ⛔ CONSÉQUENCE À ÉCRIRE AVANT TOUTE PROMESSE : un tableau de bord multicanal sur ce parc est une promesse intenable. La ligne honnête est : on mesure WhatsApp et LinkedIn, le reste se relève à la main ou ne se mesure pas. ⚠ UN COMPTE QUI SE DÉCONNECTE REND LE TABLEAU DE BORD FAUX SANS PRÉVENIR, et c'est déjà arrivé : la vérification périodique de l'état des connexions relève de surveillance-et-alerte, que Nadia porte déjà.

## Outils

### CL-NADIA-15 · Ce que les clients savent ouvrir : tableur, PDF, téléphone
- **Pourquoi** : Livrer un tableau croisé que personne n'ouvre
- **Où chercher** : Retours de missions
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : DONNÉE INTERNE, NON DISPONIBLE. Aucun retour de mission consolidé n'existe sur ce que les clients savent réellement ouvrir. DEUX ÉLÉMENTS ÉTABLIS QUI POINTENT DANS LA BONNE DIRECTION : un rapport envoyé en .md n'a pas pu être ouvert par l'équipe depuis Telegram le 31/08, d'où la règle maison un document destiné à être LU part en PDF ou en Google Doc, jamais en .md dans un fil ; et la compétence standard-de-rendu impose un contrôle à 390 pixels de large, c'est-à-dire sur un écran de téléphone. CE QUI MANQUE POUR RÉPONDRE VRAIMENT : est-ce que les destinataires ouvrent un tableur, sur quel appareil, et utilisent-ils un tableau croisé. Cela ne se cherche pas en ligne, cela se demande en trois questions à la fin d'une mission. ⟦à faire remonter par les postes en contact client⟧

## Démographie

### CL-NADIA-16 · Population, urbanisation, langues, taux d'équipement
- **Pourquoi** : Dimensionner un marché à l'aveugle
- **Où chercher** : INS, recensement, ARTCI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base statistiques sur disque : carte des sources, leurs pièges, et des séries mises à l'abri (population RGPH 1975-2021, densité par district et région, hiérarchie urbaine, PIB et croissance 1960-2023, urbanisation, abonnements téléphonie et internet 2023, annuaire de l'état civil). ⛔ UN AGRÉGAT SE CITE EN TROIS MORCEAUX : la valeur, l'année, la source. ⛔ anstat.ci est INACCESSIBLE (épreuve Cloudflare, pas un filtrage d'agent) : le contournement qui marche est de chercher le ministère CO-ÉDITEUR, qui héberge sans protection. ⛔ data.gouv.ci annonce 526 jeux, 256 seulement sont ivoiriens : l'instance est mutualisée et une recherche naïve rend des données FRANÇAISES. || TROUVÉ POUR TROIS DES QUATRE VOLETS, séries rapatriées dans ~/.claude/outils-communs/statistiques-ci/jeux-data-gouv-ci/. POPULATION, recensement de 2021, résultats définitifs publiés le 07/07/2022 : 29 389 150 habitants, densité moyenne 91,14 habitants au kilomètre carré sur 322 467 km². Série complète des cinq recensements : 6 709 600 en 1975, 10 615 694 en 1988 (+3,8 %/an), 15 366 672 en 1998 (+3,3 %), 22 671 331 en 2014 (+2,6 %), 29 389 150 en 2021 (+2,9 %). URBANISATION : 53,46 %, rural 46,54 %. ⚠ ÉCART TRANCHÉ PAR l'équipe LE 18/09 : le communiqué de résultats définitifs repris par la presse donne 52,5 %, le jeu du portail donne 53,46 %, les deux viennent du même recensement et la différence tient vraisemblablement au périmètre retenu. ON RETIENT 53,46 % ; la valeur de presse ne se cite plus. Abidjan concentre 36 % de la population urbaine, Bouaké 4,7 %, et Abidjan a crû de 490 % entre 1975 et 2021. ÉQUIPEMENT EN TÉLÉCOMMUNICATIONS, exercice 2023, par opérateur déclarant : Moov 10 259 793 abonnements en voix mobile et 6 010 293 en internet mobile, GVA 28 114 en internet fixe, Konnect Africa 702. ⛔ CE SONT DES ABONNEMENTS, PAS DES PERSONNES : le multi équipement est courant, un même individu porte souvent deux cartes, et on ne convertit jamais un nombre d'abonnements en taux de pénétration sans le dire. LANGUES : deux jeux existent sur le portail, non ouverts au 18/09. ⟦à relever⟧

## Économie

### CL-NADIA-17 · Les grands agrégats et leur source, avec la date
- **Pourquoi** : Citer un PIB sans année
- **Où chercher** : BCEAO, INS, FMI
- **Trouvé** : Oui
- **Intégré** : Oui
- **Mis à jour** : 20/09/2026
- **À revérifier le** : 20/03/2027
- **Commentaire** : INTÉGRÉ LE 20/09. Base statistiques sur disque : carte des sources, leurs pièges, et des séries mises à l'abri (population RGPH 1975-2021, densité par district et région, hiérarchie urbaine, PIB et croissance 1960-2023, urbanisation, abonnements téléphonie et internet 2023, annuaire de l'état civil). ⛔ UN AGRÉGAT SE CITE EN TROIS MORCEAUX : la valeur, l'année, la source. ⛔ anstat.ci est INACCESSIBLE (épreuve Cloudflare, pas un filtrage d'agent) : le contournement qui marche est de chercher le ministère CO-ÉDITEUR, qui héberge sans protection. ⛔ data.gouv.ci annonce 526 jeux, 256 seulement sont ivoiriens : l'instance est mutualisée et une recherche naïve rend des données FRANÇAISES. || TROUVÉ, AVEC SA LIMITE, série rapatriée en ~/.claude/outils-communs/statistiques-ci/jeux-data-gouv-ci/pib-croissance-1960-2023.csv. PIB nominal en milliards de FCFA et croissance réelle : 2023, 47 913,3 et 7,2 % ; 2022, 42 881,1 et 6,9 % ; 2021, 39 190,4 et 7,4 % ; 2020, 35 311,4 et 2,0 % ; 2019, 34 298,9 et 6,2 %. ⛔ LA SÉRIE S'ARRÊTE À 2023. Nous sommes en septembre 2026 : citer le PIB ivoirien sans année, c'est citer un chiffre vieux de trois ans. POUR 2024, 2025 ET 2026, il n'y a pas de mesure dans cette base ; la note de présentation de l'annexe fiscale 2026, désormais en ~/.claude/outils-communs/fiscalite-ci/, annonce une croissance attendue de 6,7 % EN 2026 CONTRE 6,5 % EN 2025. ⚠ Ce sont des PRÉVISIONS inscrites dans un document budgétaire de l'État, à citer comme telles et jamais comme des mesures. LA RÈGLE QUI EST LE FOND DE CETTE LIGNE : un agrégat se cite en trois morceaux, la valeur, l'année, la source. Deux sur trois ne suffisent pas.

## Références

### CL-NADIA-18 · Tableaux de bord réellement utilisés par des maisons d'ici
- **Pourquoi** : Inventer un format que personne n'utilise
- **Où chercher** : Documents publics, retours de missions
- **Trouvé** : Non
- **Intégré** : Non
- **Mis à jour** : 18/09/2026
- **Commentaire** : NON DISPONIBLE, ni document public ni retour de mission. Nadia porte déjà tout l'outillage de fabrication (du-tableur-au-tableau-de-bord, kpi-weekly, reporting-de-gestion, rapport-mensuel-de-direction, data-visualization-designer) : ce qui lui manque n'est pas la méthode, c'est L'USAGE RÉEL, quels indicateurs une PME ivoirienne regarde vraiment, à quelle fréquence, et sur quel support. ⟦à collecter en mission, pas à chercher en ligne⟧ Deux questions suffisent en fin de mission : que regardez-vous chaque semaine, et où le regardez-vous.
