## Les financeurs actifs en Côte d'Ivoire

Inventaire construit à la main le 18/09/2026, à la demande de l'équipe, pour la ligne CL-ALIOUNE-11 de la couche locale. Il répond à un constat : les fonds de capital investissement et de capital risque ne sont dans aucun registre public. Ils ne sont pas des intermédiaires de marché, donc pas agréés par l'AMF-UMOA, et aucune autorité ne les recense. La liste se bâtit donc opération par opération, à partir des communiqués et des annuaires.

Règle de tenue, qui vaut plus que le contenu : aucun nom n'entre ici sans une source qui l'atteste, et la source est datée. Un fonds cité de mémoire coûte un trimestre au dossier qu'on lui envoie.

### Ce que cet inventaire est, et ce qu'il n'est pas

Il n'est pas exhaustif et ne peut pas l'être. Il porte ce qui a été vérifié dans la journée du 18/09. Trois réserves à garder devant les yeux :

La plupart des lignes viennent de la presse économique ou du site du financeur, pas d'un registre. Ce sont des sources secondaires ou auto-déclarées. Avant d'orienter un dossier, on rappelle le fonds et on fait confirmer sa thèse du moment.

Un ticket et un stade annoncés au lancement d'un fonds ne disent pas ce qu'il fait aujourd'hui. Un véhicule levé en 2018 peut être en fin de période d'investissement.

Une opération unique ne fait pas une présence. Un fonds qui a signé une fois à Abidjan n'est pas nécessairement actif sur le pays.

### Famille 1 : les gérants implantés en Côte d'Ivoire

Ceux dont l'équipe est à Abidjan. Ce sont les premiers à saisir, parce qu'ils instruisent sur place et qu'ils connaissent le tissu.

| Gérant | Nature | Ticket et stade | Périmètre |
|---|---|---|---|
| Comoé Capital | Fonds d'impact, cinquième fonds africain parrainé par Investisseurs & Partenaires au titre d'I&P Développement 2, dirigé par Issa Sidibé | 0 à 500 000 € | PME et start-up ivoiriennes |
| Adiwale Partners | Capital investissement indépendant, fondé en 2016 à Abidjan | Participations minoritaires significatives dans 10 à 12 entreprises, capital de croissance de 3 à 8 M€ | Afrique de l'Ouest francophone : Côte d'Ivoire, Sénégal, Mali, Burkina Faso, Togo, Bénin, Guinée |
| CDC-CI Capital | Filiale à 100 % de la Caisse des Dépôts et Consignations de Côte d'Ivoire, initiative publique à gestion et gouvernance privées, deux guichets | Amorçage et développement, tickets non publiés sur le site | Agro-industrie, fintech, industries culturelles, projets verts |

Trois précisions utiles au montage d'un dossier :

Comoé Capital a levé 4,4 milliards FCFA, et la CDC-CI est entrée à son capital. Le fonds appartient au réseau d'I&P, qui compte aussi Sinergi Niger, Sinergi Burkina, Teranga Capital au Sénégal et Miarakap à Madagascar. Un dossier régional peut donc se relayer d'un véhicule à l'autre.

Adiwale Fund I a clôturé à 60 M€, soit 69,6 M$, sous la cible initiale de 75 M€. La Banque africaine de développement y a engagé 12,5 M€. L'équipe revendique une vingtaine d'opérations dans la région avant ce fonds, dont quatorze entièrement cédées.

CDC-CI Capital a déployé 720 millions FCFA, soit 1,2 M$, dans huit start-up locales selon une annonce de mai 2026, portant le total sur douze mois à au moins 2,6 milliards FCFA. Une convention de 1 milliard 50 millions FCFA a été signée en février 2026 pour l'amorçage et le prototypage de projets étudiants. Le site publie un formulaire de soumission de projet, avec des tranches de besoin allant de moins de 50 M à plus de 501 M FCFA.

### Famille 2 : les fonds régionaux et panafricains qui ont signé ici

Présence attestée par une opération, pas par un bureau. À traiter comme des pistes à qualifier, chacune avec la date de l'opération qui la fonde.

| Fonds | Ce qui atteste sa présence | Réserve |
|---|---|---|
| Janngo Capital | Co-chef de file du tour de GoCab Côte d'Ivoire, 45 M$ dont 15 M$ en fonds propres et 30 M$ en dette | Une opération relevée, thèse à confirmer |
| E3 Capital | Co-chef de file du même tour | Idem |
| KawiSafi Ventures | Participant au même tour | Idem |
| Cur8 Capital | Participant au même tour | Idem |
| Saviu Ventures | Véhicule Saviu II, 6,5 M€ approuvés par la Banque africaine de développement, amorçage et premier tour institutionnel | Périmètre Afrique de l'Ouest et Centrale francophone, pas Côte d'Ivoire exclusivement |

Le tour de GoCab pèse lourd dans ce tableau : quatre des cinq lignes en viennent. C'est exactement le piège de la base au deal que décrit referentiel-sources-afrique, une seule opération qui donne l'illusion d'un marché. Ces quatre noms valent d'être appelés, ils ne valent pas d'être présentés comme quatre acteurs installés.

### Famille 3 : les guichets publics ivoiriens

Ceux qui ne prennent pas de participation mais qui débloquent le crédit bancaire, souvent la vraie contrainte d'une PME ivoirienne.

| Dispositif | Ce qu'il fait | Base juridique ou date |
|---|---|---|
| GUDE-PME, Guichet unique de développement des PME | Holding dont l'État est l'actionnaire unique, chapeaute deux filiales | Créé en janvier 2022 |
| Côte d'Ivoire PME, CI-PME | Accompagnement des PME, filiale du GUDE-PME |  |
| SGPME, Société de garantie des crédits aux PME | Garantie, filiale du GUDE-PME | Depuis mai 2023 : 1 080 PME soutenues, plus de 35 milliards FCFA |
| FGPME, Fonds de garantie des crédits aux PME | Garantit les crédits demandés par les PME ivoiriennes auprès des banques et fournit les cautions exigées dans les marchés publics | Loi 68-346 du 29 juillet 1968, décret 2020-18 du 8 janvier 2020 |

Le programme PACA-CI, prolongé jusqu'en 2026, a octroyé plus d'un milliard FCFA à la SGPME pour renforcer le fonds de garantie.

Un point reste ouvert et il est central pour conseiller : la quotité de garantie, les plafonds, la durée et le coût du FGPME ne figurent ni sur pme.gouv.ci, ni sur le site dédié, dont l'adresse relevée ne résout plus. Ces paramètres sont à demander directement à CI-PME ou à lire dans le décret 2020-18, qui n'est pas encore sur disque.

### Famille 4 : les bailleurs et institutions de financement du développement

Ils financent rarement une PME en direct. Ils passent par une banque locale, par un fonds, ou par un programme. Savoir lequel finance quoi fait gagner une étape.

| Institution | Canal observé en Côte d'Ivoire |
|---|---|
| Banque africaine de développement | Engagements en fonds de fonds : 12,5 M€ dans Adiwale Fund I, 6,5 M€ dans Saviu II |
| Banque d'investissement et de développement de la CEDEAO | Accord de prêt de 10 milliards FCFA signé le 20 mai 2026 avec Afriland First Bank Côte d'Ivoire, pour le financement du secteur privé |
| Proparco, groupe AFD | Offre dédiée aux PME ivoiriennes ; premier financement Choose Africa 2 en Côte d'Ivoire, pour l'accès au crédit de plusieurs milliers de TPME, avec un axe entrepreneuriat féminin |
| Société financière internationale, groupe Banque mondiale | Appui au secteur privé par des partenaires institutionnels locaux ; entrée au capital de CDCI, grande distribution, aux côtés de Valoris Group |
| Banque mondiale, Bpifrance, JICA, PNUD, Digital Africa | Cités comme partenaires de la feuille de route innovation et intelligence artificielle 2026-2028 du pays |

### Ce qu'il reste à faire

Obtenir les paramètres du FGPME, soit par le décret 2020-18, soit auprès de CI-PME.

Reprendre sur le registre de l'AMF-UMOA le relevé de presse des 394 cartes professionnelles renouvelées pour 2026, dont 242 sociétés de gestion et d'intermédiation. Le chiffre sûr dont nous disposons reste celui du bulletin officiel de la cote de la BRVM au 17/09/2026 : 37 sociétés de gestion et d'intermédiation participantes.

Vérifier sur source primaire le projet de fonds national de 100 milliards FCFA destiné aux start-up technologiques, relevé dans la presse et non confirmé. Il n'entre pas dans les tableaux ci-dessus tant qu'il n'est pas établi.

Qualifier les quatre fonds issus du seul tour GoCab, un appel chacun.

Ajouter les banques commerciales et leurs lignes dédiées aux PME, absentes de cet inventaire.

### Sources

Relevées le 18/09/2026.

Comoé Capital : ietp.com, comoecapital.com, cdc.ci pour l'entrée au capital, Agence Ecofin pour le lancement.

Adiwale Partners : adiwale.fr et adiwale.com, Agence Ecofin pour le premier closing, Togo First pour le montant final et l'engagement de la Banque africaine de développement.

CDC-CI Capital : cdccapital.ci, cdc.ci, gouv.ci pour le lancement, Launch Base Africa pour le déploiement de mai 2026, KOACI pour la convention de février 2026.

Guichets publics : pme.gouv.ci, sgpme.ci, Agence ivoirienne de presse pour le PACA-CI, Abidjan.net pour le FGPME.

Bailleurs : afd.fr et proparco.fr pour Choose Africa 2, Financial Afrik et Fraternité Matin pour l'accord BIDC, Abidjan.net pour l'opération CDCI, TechCabal pour la feuille de route innovation.
