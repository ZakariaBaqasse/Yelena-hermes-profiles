# Commandes des Experts IA


## /s <sujet>
- **À quoi elle sert** : Aller chercher pour de vrai au lieu de répondre de mémoire.
- **Ce qu'elle fait, dans l'ordre** : 1. Ouvre des pages avant d'écrire. 2. Monte l'échelle dans l'ordre : site deviné, WebSearch, WebFetch, puis Brave, puis Apify. 3. Trois angles au minimum. 4. Rend ce qui a été trouvé, rangé pour servir.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : C'EST le garde anti-hallucination du parc. Chaque fait porte son lien. Une déduction est marquée comme hypothèse contestable, avec ce sur quoi elle s'appuie. Une absence dit OÙ on a regardé, sinon rien ne distingue une recherche menée d'une recherche non menée.
- **Ce qu'elle ne fait pas** : Ne franchit pas un mur de connexion, ne moissonne pas en volume, ne touche pas aux données personnelles. Apify se facture à la page et refuse de consommer sans accord.
- **État** : En service depuis le 10/09/2026

## /impactia
- **À quoi elle sert** : Ouvrir un visiteur neuf sur une borne de salon.
- **Ce qu'elle fait, dans l'ordre** : 1. Coupe le visiteur précédent. 2. Ouvre la ligne du registre. 3. Déroule l'ouverture complète : qui vous êtes, votre entreprise, ce qu'elle fait.
- **Où elle marche** : Les 4 bornes de salon (Adjoua, Fatima, Koffi, Kouassi)
- **Contrôle qualité et anti-hallucination** : La coupure est le contrôle : sans elle, les données d'un visiteur seraient lues par le suivant. Déclenche même sur une orthographe de travers, parce que ne pas couper coûte infiniment plus cher que couper pour rien.
- **Ce qu'elle ne fait pas** : Ne diffère la coupure que si le visiteur a déjà écrit après le tag. N'envoie rien lui-même : la borne prépare, le visiteur envoie.
- **État** : En service depuis le 06/09/2026

## /form
- **À quoi elle sert** : Rappeler au visiteur la liste du formulaire pour qu'il se reconnaisse d'un chiffre.
- **Ce qu'elle fait, dans l'ordre** : Affiche les entrées du formulaire Tally en attente, à la demande.
- **Où elle marche** : Les 4 bornes de salon (Adjoua, Fatima, Koffi, Kouassi)
- **Contrôle qualité et anti-hallucination** : Un domaine qui répond n'est pas le bon domaine : le recoupement écrit HOMONYME PROBABLE plutôt que de servir un homonyme comme un fait.
- **Ce qu'elle ne fait pas** : Ne crée pas d'entrée, ne modifie pas le formulaire.
- **État** : En service depuis le 10/09/2026

## /update
- **À quoi elle sert** : Mettre les quinze experts à jour en une passe, et dire ce qui ne peut pas se faire tout seul.
- **Ce qu'elle fait, dans l'ordre** : 1. Redescend les règles de communication. 2. Redescend les couches locales. 3. Relève les livrables non déposés. 4. Repose la carte des design systems lue dans Figma. 5. Sonde les connecteurs de chaque poste. 6. Compte les socles et nomme les manques. 7. Liste les experts dont la session doit être rouverte.
- **Où elle marche** : l'administrateur seulement (topic General) : une commande s'exécute dans la session du topic où elle est tapée, depuis un expert elle ne pourrait rien faire aux quatorze autres.
- **Contrôle qualité et anti-hallucination** : Les deux synchronisations n'écrivent RIEN si la lecture du tableur échoue ou rend moins de cinq lignes : un tableur momentanément illisible ne doit jamais vider les fichiers des quinze postes.
- **Ce qu'elle ne fait pas** : Ne dépose aucun livrable sans accord explicite : le relevé d'abord, le téléversement après. Ne rouvre aucune session tout seul, rouvrir emporte le fil de travail en cours.
- **État** : Nouvelle, 21/09/2026

## /reset
- **À quoi elle sert** : Repartir d'une conversation neuve dans ce topic.
- **Ce qu'elle fait, dans l'ordre** : 1. Archive le transcript. 2. Retire le label de la table des sessions. 3. Ferme la session. Au message suivant, une session neuve s'ouvre dans le même workspace.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : Le transcript est archivé AVANT la coupure : la perte est réversible à la lecture. Sur une borne, la remise à zéro entre deux visiteurs est le geste de sécurité et prime sur tout le reste.
- **Ce qu'elle ne fait pas** : N'efface ni les compétences, ni la mémoire longue, ni les journaux, ni les livrables. Emporte le fil de la conversation, donc le contexte non écrit.
- **État** : Nouvelle, 21/09/2026

## /historique <client>
- **À quoi elle sert** : Retrouver tout ce que la maison sait d'un client.
- **Ce qu'elle fait, dans l'ordre** : Cherche dans les livrables et leur index, la mémoire longue et les journaux du jour, les registres, l'index Drive du poste, et la couche locale. Rend une chronologie.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : Chaque élément porte sa source, fichier ou lien. Ce qui n'a pas été trouvé est dit avec l'endroit où l'on a regardé : sinon rien ne distingue un client sans historique d'une recherche non menée.
- **Ce qu'elle ne fait pas** : Ne devine pas un nom de client. Sans nom, la commande demande de qui il s'agit.
- **État** : Nouvelle, 21/09/2026

## /livrable
- **À quoi elle sert** : Déposer le document du moment sur le Drive de l'expert et l'inscrire à l'index.
- **Ce qu'elle fait, dans l'ordre** : 1. Retrouve le fichier sur le disque, version la plus haute. 2. Fabrique la paire manquante s'il le faut. 3. Dépose avec un titre lisible et le projet. 4. Vérifie la ligne d'index et rend le lien.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : La version vient du DISQUE, jamais de l'index ni de la date : le N le plus grand, comparé comme un nombre, v10 avant v2. Un livrable sort par paire, Doc plus PDF.
- **Ce qu'elle ne fait pas** : Une révision ne se redépose pas sous un nouveau lien : elle remplace en place, pour que la personne qui a gardé le premier lien voie la nouvelle version.
- **État** : Nouvelle, 21/09/2026

## /etat
- **À quoi elle sert** : Savoir où en est ce poste.
- **Ce qu'elle fait, dans l'ordre** : Relève les engagements sans trace de réalisation, les livrables sans retour avec le nombre de jours, les questions restées en l'air, l'état réel des automatisations, et ce qui attend une décision humaine.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : Le marqueur « failed » de systemd ment dans les deux sens : la vérité est la ligne finale du journal de la tâche, pas l'état de l'unité. Un état faussement rempli est pire qu'un état vide.
- **Ce qu'elle ne fait pas** : Pas de mention « en cours » : un dossier est fait, ou bloqué sur quelque chose de nommable. « En cours » est ce qui laisse un dossier stagner sans que personne le voie.
- **État** : Nouvelle, 21/09/2026

## /relire
- **À quoi elle sert** : Contrôler un texte avant qu'il parte.
- **Ce qu'elle fait, dans l'ordre** : 1. Tics de machine. 2. Chiffres et sources. 3. Rendu : tailles, familles, sections, logo, contrôle à 390 px.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : Zéro tiret cadratin, c'est le marqueur qui fait reconnaître un texte de machine. Aucun chiffre ni prix inventé ; un marquage se mérite, il vient après la recherche. Trois marquages sur une page veulent dire que le livrable est inachevé.
- **Ce qu'elle ne fait pas** : L'outil de relecture a des faux positifs connus : ne pas déformer une phrase correcte pour le satisfaire. Rend ce qui n'a pas été corrigé et pourquoi.
- **État** : Nouvelle, 21/09/2026

## /couche
- **À quoi elle sert** : Savoir ce que la couche locale sait d'un sujet, et ce qui y manque.
- **Ce qu'elle fait, dans l'ordre** : Lit le référentiel local du poste et rend les trois listes : acquis, repéré, à chercher, rapportées au sujet demandé.
- **Où elle marche** : Les 16 postes
- **Contrôle qualité et anti-hallucination** : Deux gardes. Intégré ne veut pas dire lu : une pièce marquée acquise doit être ouverte avant d'être citée. À chercher n'autorise pas à inventer : une case vide reste vide, et renvoie vers /s.
- **Ce qu'elle ne fait pas** : Ne collecte rien : elle dit l'état, elle ne le corrige pas.
- **État** : Nouvelle, 21/09/2026
