## Habiller chaque document aux couleurs de l'entreprise

Demandé par la direction le 25/09/2026 : « dès que tu as le branding de l'entreprise, tous les documents doivent être dans ce branding, que ce soit un G-Sheet, un G-Doc, un PDF. Il faut vraiment que tu travailles le branding même du G-Sheet, le branding même de l'Excel. »

Recueillir la charte ne suffit pas. Un tableur livré avec la police Arial, un en-tête gris et des listes déroulantes toutes identiques dit au client que l'Expert ne l'a pas regardé. La règle est simple : dès que la charte est dans la mémoire, aucun document ne sort avec les réglages par défaut de l'outil.

### Quand elle s'applique

À chaque document produit ou mis à jour, quel que soit son format, dès que la charte de l'entreprise est connue (compétence charte-du-client). Sans charte, tu produis une mise en forme sobre, tu le signales, et tu demandes le logo et les couleurs.

### Ce que tu poses sur un Google Sheet ou un Excel

La police de la marque sur tout le classeur. Si elle n'existe pas dans l'outil, la plus proche disponible (même famille : géométrique, humaniste, à empattements), notée dans l'onglet Lisez-moi.

L'en-tête : fond dans la couleur principale, texte blanc en gras, ligne figée, filtre posé.

Des bandes alternées dans une teinte très claire de la couleur principale, jamais le gris par défaut.

Chaque liste déroulante colorée option par option. Un statut, une priorité, une étape ou une catégorie reçoit une couleur par valeur, toujours la même d'un onglet à l'autre :

les couleurs de sens restent lisibles (vert pour fait ou validé, orange pour en cours ou à surveiller, rouge pour bloqué ou refusé), mais dans des teintes accordées à la charte ;

les catégories sans ordre prennent les couleurs de la charte puis leurs dégradés ;

dans Google Sheets, la couleur se règle sur chaque option de la liste ; dans Excel, qui n'a pas de pastilles, une mise en forme conditionnelle par valeur donne le même rendu.

Une mise en forme conditionnelle pour ce qui doit sauter aux yeux : échéance dépassée, montant hors budget, case vide obligatoire.

Les formats de nombre : montants en FCFA avec séparateur de milliers, pourcentages, dates au format jour/mois/année.

Les onglets : couleur de la marque sur l'onglet principal, le Lisez-moi en premier avec le logo, l'objet du fichier et la légende de chaque couleur.

Les largeurs de colonne réglées à la main, aucun texte coupé, aucune colonne de 10 cm.

### Ce que tu poses sur un Google Doc, un Word ou un PDF

Le logo en en-tête, à sa taille et sans déformation.

Les titres dans la police et la couleur de la marque, le corps dans sa police de texte.

Les tableaux avec la même logique que le tableur : en-tête coloré, bandes claires.

Le pied de page de l'entreprise (nom, mention de confidentialité si elle existe).

Le PDF s'exporte depuis le document déjà habillé, jamais depuis un brouillon.

### Ce qui est interdit

Livrer un document aux couleurs par défaut de l'outil alors que la charte est connue.

Inventer une couleur ou une police qui n'est pas dans la charte.

Des couleurs sans légende : une couleur qui porte un sens se déclare dans le Lisez-moi.

Une liste déroulante dont toutes les options ont la même couleur.

### Avant de remettre

Ouvre le document comme le client l'ouvrira et regarde-le. Trois questions : reconnaît-on l'entreprise sans lire le nom, chaque couleur a-t-elle un sens déclaré, et une liste déroulante se lit-elle d'un coup d'œil. Si l'une des réponses est non, le document n'est pas prêt.

### Exemple

Un suivi de recrutement pour une entreprise dont la couleur principale est un bleu marine. En-tête bleu marine, texte blanc, police de la marque. Colonne Étape en liste déroulante : Reçu (bleu clair), Entretien (bleu de la marque), Offre (orange doux), Embauché (vert), Refusé (rouge doux). Colonne Date limite en rouge quand elle est dépassée. Onglet Lisez-moi avec le logo et la légende des cinq couleurs.
