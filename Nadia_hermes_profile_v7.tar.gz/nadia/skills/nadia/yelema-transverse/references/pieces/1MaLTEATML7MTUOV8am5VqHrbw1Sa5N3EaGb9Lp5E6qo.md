# 260920_Socle local institutions-ci

===== onglet t.0 · Tab 1 · 19 lignes non vides =====

# Qui décide quoi en Côte d'Ivoire, et quelle source fait foi
Relevé le 20/09/2026. À revérifier le 20/12/2026, et à rouvrir avant tout remaniement annoncé : un gouvernement change sans prévenir et une liste périmée se voit tout de suite.
## La pièce qui fait foi
~/agents/lokoli/memory/reference/gouvernement-2026.md, relevé intégralement le 10/09/2026 sur le portail officiel gouv.ci/gouvernement. Composition du « Gouvernement Robert Beugré Mambé du 23 janvier 2026 », Premier ministre reconduit par décret du 21 janvier 2026 : 1 Premier ministre, 1 vice-Premier ministre, 2 ministres d'État, 27 ministres, 4 ministres délégués.

⛔ Avant de nommer un ministre dans un livrable sortant, rouvrir la page. C'est la seule source qui se met à jour. Le fichier local dit qui était en fonction au 10/09, pas qui l'est aujourd'hui.
## La hiérarchie de fiabilité, quand deux sources divergent
Elle vit dans watchlist-sources-ci.md, présent chez LOKOLI, BENKAN et YIRIWA. ⚠ Les trois versions diffèrent : prendre celle du poste où l'on travaille, et ne pas supposer qu'elles disent la même chose.

- Fait foi : Journal officiel, décret, communiqué du Conseil des ministres, site de l'institution elle-même.
- Quasi-foi : BCEAO, ANStat, DGTCP, ARTCI, BRVM. Producteurs officiels de chiffres.
- Fiable, à dater : AIP, Reuters, AFP, APA. On cite la dépêche avec sa date, jamais comme un fait intemporel.
## Les régulateurs qui peuvent arrêter un travail
Quatre reviennent sans cesse, et un livrable qui les ignore se fait arrêter en aval :

- CSP, Conseil supérieur de la publicité, csp.communication.gouv.ci : tout message publicitaire est validé avant diffusion, quel que soit le support, et les agences comme les régies doivent être agréées.
- HACA, Haute autorité de la communication audiovisuelle, haca.ci : radios et télévisions, et le répertoire des opérateurs.
- ANP, Autorité nationale de la presse, anp.ci : presse imprimée et en ligne.
- Autorité de protection des données, autoritedeprotection.ci : tout fichier de personnes. Voir ../donnees-personnelles-ci/.

Pour le numérique et les télécommunications, l'ARTCI (artci.ci) s'ajoute à cette liste.
## Ce que cette note ne couvre pas
Ni l'organisation de la Présidence, ni le circuit du Conseil des ministres, ni le corps diplomatique accrédité. Ces trois pièces restent dues, et leur absence ne se comble pas en déduisant. Pour le ministère des Affaires étrangères, ../diplomatie-ci/ porte l'organigramme et le répertoire des missions.

