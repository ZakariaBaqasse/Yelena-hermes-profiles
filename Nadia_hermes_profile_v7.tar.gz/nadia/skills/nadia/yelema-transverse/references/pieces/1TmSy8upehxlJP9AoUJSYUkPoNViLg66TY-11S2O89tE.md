# 260920_Socle local monnaie-et-ordres-de-grandeur

===== onglet t.0 · Tab 1 · 22 lignes non vides =====

# Le franc CFA, et les repères de montant d'ici
Relevé le 20/09/2026. À revérifier le 20/03/2027 pour le SMIG et les agrégats ; la parité avec l'euro, elle, est fixe et ne bouge pas.
## La monnaie
Franc CFA (XOF), émis par la BCEAO pour les huit États de l'UEMOA. Parité fixe : 655,957 XOF pour 1 EUR. Coupures de 500, 1 000, 2 000, 5 000 et 10 000 FCFA, pièces jusqu'à 500 (relevé sur bceao.int le 18/09/2026).
## ⛔ La règle d'écriture, et elle n'a pas d'exception
On chiffre en FCFA d'abord. Convertir mentalement en euros produit des montants qui ne parlent à personne ici, et un devis en euros se fait relire deux fois. Si une conversion est utile, elle vient entre parenthèses, après.

Jamais un montant en dollars sans son taux et sa date. Le XOF est arrimé à l'euro, pas au dollar : un montant en dollars converti sans date est faux dès le lendemain.
## Les repères qui donnent l'échelle
| Repère | Valeur | Source |
| SMIG | 75 000 FCFA par mois depuis le 01/01/2023 | ../droit-travail-ci/LISEZ-MOI.md |
| SMAG (agricole) | 39 960 FCFA | source secondaire, non vérifiée sur le décret |
| TVA | 18 %, réduit 9 % | synthèse DGI, ../fiscalite-ci/ |
| Population | 29 389 150 habitants au RGPH 2021 | ../statistiques-ci/jeux-data-gouv-ci/population-rgph-1975-2021.csv |
| Croissance de la population | 2,9 % par an | même source |
| Urbanisation | 53,5 % urbain, 46,5 % rural | urbanisation-indicateurs-cles.csv |
| PIB nominal 2023 | 47 913,3 milliards FCFA, croissance réelle 7,2 % | pib-croissance-1960-2023.csv |
| Abidjan | 5 654 633 habitants, 19,2 % du pays, 35,9 % de l'urbain | hierarchie-urbaine.csv |
| Bouaké, 2e ville | 738 753 habitants | même source |

Le SMIG donne le pas de raisonnement : un tarif mensuel de 300 000 FCFA vaut quatre SMIG. C'est cette échelle-là qu'un interlocuteur ivoirien a en tête, pas la conversion.

⚠ Abidjan pèse près d'un habitant sur cinq et plus d'un urbain sur trois. Un plan qui traite Abidjan comme une ville parmi d'autres se trompe d'ordre de grandeur, et un plan qui ne voit qu'Abidjan laisse dehors quatre cinquièmes du pays.
## Ce que cette note ne couvre pas
Ni le panier moyen, ni le revenu médian, ni les prix de détail. Le SMIG est un plancher légal, pas une dépense observée. ⟦à récupérer⟧ Pour tout ce qui touche aux mouvements de fonds vers l'étranger, voir ../change-uemoa/.

