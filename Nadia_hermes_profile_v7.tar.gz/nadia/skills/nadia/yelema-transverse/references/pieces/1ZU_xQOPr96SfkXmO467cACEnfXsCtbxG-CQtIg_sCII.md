# 260920_Socle local decoupage-administratif-ci

===== onglet t.0 · Tab 1 · 16 lignes non vides =====

# Le découpage du territoire ivoirien, et le jeu officiel qui est périmé
Relevé le 20/09/2026. À revérifier le 20/09/2027.
## Les niveaux, dans l'ordre
District autonome · district · région · département · sous-préfecture · commune. Un district et une région ne se confondent pas, une sous-préfecture et une commune non plus. Écrire « la région d'Abidjan » est faux : Abidjan est un district autonome.
## Le point qui a changé, et que presque personne n'a relevé
⛔ Il ne reste que DEUX districts autonomes, Abidjan et Yamoussoukro. Le décret n° 2026-05/2 du 07/01/2026 abroge le décret n° 2021-276 du 09/06/2021 et supprime douze des quatorze districts autonomes, les transferts de personnels et de biens étant renvoyés à un arrêté du Premier ministre. Publié au Journal officiel n° 5 (Spécial) du 17/02/2026. La presse ne l'a relevé que le 18/03.

Un livrable écrit deux districts autonomes, jamais douze ni quatorze. ⚠ Le texte primaire n'a pas été lu : le Journal officiel n'est pas en accès libre. La référence est établie sur le recensement mensuel d'Ivoire-Juriste, recoupé avec son récapitulatif de janvier. ⟦à récupérer⟧
## ⛔ Le jeu de données officiel est périmé, et c'est un piège
../statistiques-ci/jeux-data-gouv-ci/circonscriptions-et-communes.csv, téléchargé du portail officiel data.gouv.ci, producteur data354-CI, 252 enregistrements. Compté le 20/09/2026 : 19 régions · 57 départements · 243 sous-préfectures · 198 communes.

Ses dix-neuf régions sont AGNEBY, BAFFING, BAS-SASSANDRA, DENGUELE, FROMAGER, HAUT-SASSANDRA, LACS, LAGUNES, MARAHOUE, MONTAGNES, MOYEN CAVALLY, MOYEN COMOE, N'ZI COMOE, SAVANES, SUD-BANDAMA, SUD-COMOE, VALLEE DU BANDAMA, WORODOUGOU, ZANZAN. C'est le découpage d'avant la réforme de 2011. AGNEBY, FROMAGER, MOYEN CAVALLY et N'ZI COMOE ne sont plus des régions.

Un expert qui prend ce jeu pour la carte actuelle écrit des noms de régions qui n'existent plus, sur un fichier qui porte le tampon officiel. Il sert à retrouver une commune et son département, pas à nommer une région.
## Le jeu qui porte le découpage actuel
../statistiques-ci/jeux-data-gouv-ci/population-densite-par-region.csv, issu du RGPH : districts et régions d'aujourd'hui, avec population, superficie et densité. On y lit Gbôklé, Nawa, Indénié-Djuablin, San-Pédro, Tonkpi, Poro, Bagoué, Tchologo, Gbêkê, Hambol, Béré, Bounkani, Gontougo, qui sont les noms en vigueur.

⚠ Ce fichier a deux défauts de saisie vus le 20/09 : « Hfou » pour Iffou, et « Hambol » en double. Compter sur lui pour les noms, pas pour un dénombrement.
## Ce qui reste ouvert
Le nombre exact de communes, 198 dans le jeu officiel, 197 selon les sources encyclopédiques. Écart non tranché, à ne pas lisser : on cite le jeu, avec sa date.

