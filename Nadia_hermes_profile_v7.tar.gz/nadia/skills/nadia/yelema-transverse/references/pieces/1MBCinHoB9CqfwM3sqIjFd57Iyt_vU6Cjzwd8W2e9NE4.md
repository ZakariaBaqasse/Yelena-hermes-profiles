# 260920_Socle local calendrier-ci

===== onglet t.0 · Tab 1 · 16 lignes non vides =====

# Le calendrier ivoirien : férié, chômé, payé, et les saisons
Relevé le 20/09/2026. À revérifier le 20/01/2027 : les dates mobiles musulmanes et chrétiennes changent chaque année, et un communiqué ministériel les fixe au cas par cas.
## La pièce, et elle est complète
../droit-travail-ci/JOURS-FERIES.md, arrêtée le 26/08/2026. On l'ouvre, on ne résume pas ce qui suit. Elle sépare trois choses que tout le monde confond :

- férié : la liste réglementaire, décret n° 96-205 ;
- chômé : on ne travaille pas ;
- payé : la convention interprofessionnelle de 1977, article 64, et elle ne couvre pas tout le monde.

Le point le moins intuitif, et il commande une planification : seuls le 1er mai et le 7 août sont fériés, chômés ET payés pour tous, parce que ces deux-là tiennent de la loi elle-même, Code du travail article 24.2. Le reste dépend de la convention, et le Maouloud et le lendemain de la nuit du destin n'y figurent pas : ils relèvent de l'article 65, compensation ou majoration.

⚠ Le décret n° 2011-371, cité par la presse comme fondement des communiqués ministériels, n'a pas été lu. La liste en vigueur vient du décret 96-205 rapporté par une page officielle, pas du texte constaté. ⟦à récupérer⟧
## Ce qui commande une relance ou une campagne
Un envoi tombe à plat pendant une fête, et le mois du Ramadan change les rythmes de travail bien au-delà de la Korité qui le clôt. Les deux fêtes musulmanes majeures sont mobiles : leur date se prend sur le communiqué de l'année, jamais sur un calendrier de l'an dernier.
## ⛔ Les saisons ne sont PAS établies ici
La Côte d'Ivoire n'a pas un régime climatique unique, le sud et le nord ne suivent pas le même calendrier de pluies. Aucune source n'a été ouverte pour cette note. sodexam.com, le service météorologique national, a refusé la connexion le 20/09/2026 (Connection reset by peer), et rien sur disque ne couvre le sujet.

Donc : ne pas écrire de fenêtre de saison dans un livrable sans avoir ouvert une source. Une « saison des pluies » posée de mémoire est exactement l'erreur que cette couche locale existe pour empêcher. ⟦à récupérer⟧
## Le calendrier des fêtes UEMOA
Demandé le 14/09, toujours dû. Il ne se déduit pas du calendrier ivoirien : les huit pays n'ont ni les mêmes fêtes nationales ni les mêmes jours chômés. ⟦à récupérer⟧

