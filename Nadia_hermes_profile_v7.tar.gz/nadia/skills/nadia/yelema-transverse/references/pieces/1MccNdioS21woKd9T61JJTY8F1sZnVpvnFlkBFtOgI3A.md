# 260920_Audience réelle des plateformes en Côte d'Ivoire

===== onglet t.0 · Tab 1 · 31 lignes non vides =====

# Ce qui marche vraiment en Côte d'Ivoire : audience réelle des plateformes
Source unique et primaire : ARTCI, « Mesure de la Société de l'Information 2024 », Résumé exécutif, enquête conduite avec le cabinet Axes Marketing. Pièce sur disque : ../artci/msi-2024-resume-executif.pdf (et .txt). Relevé le 18/09/2026. À revérifier le 18/03/2027 (l'ARTCI publie la MSI chaque année).
## La base de calcul, et c'est tout le sujet
Les pourcentages de plateformes ci-dessous sont donnés dans le chapitre « Usages d'Internet et comportements numériques ». Leur base est donc les utilisateurs d'Internet, pas la population. Et les utilisateurs d'Internet sont 41,4 % des individus de 5 ans et plus (44,5 % des hommes, 38,3 % des femmes).

⚠ Le résumé exécutif n'écrit pas la base sous le tableau lui-même : elle se déduit du chapitre qui le porte. Un livrable qui cite ces chiffres écrit « des internautes », jamais « des Ivoiriens ». L'écart n'est pas cosmétique : il vaut un facteur 2,4.
## Les chiffres
| Plateforme | Part des internautes | Ordre de grandeur sur la population 5 ans et plus |
| WhatsApp | 92,8 % | ~38 % |
| Facebook | 82,1 % | ~34 % |
| TikTok | 81,5 % | ~34 % |
| Messenger | 36,6 % | ~15 % |
| YouTube | 35,0 % | ~14 % |
| Instagram | 19,0 % | ~8 % |
| Telegram | 11,0 % | ~4,6 % |
| X (ex Twitter) | 2,0 % | ~0,8 % |
| LinkedIn | 1,3 % | ~0,5 % |
| Ayoba | 0,9 % | ~0,4 % |
| Skype | 0,9 % | ~0,4 % |

La colonne de droite est un produit, pas un chiffre de l'ARTCI : part des internautes × 41,4 %. Elle sert à garder l'échelle en tête, elle ne se cite pas comme une donnée d'enquête.
## Ce que ces chiffres commandent
- LinkedIn n'est pas un canal de masse ici. 1,3 % des internautes, soit environ un Ivoirien sur deux cents. Un plan qui met LinkedIn au centre d'une campagne grand public ivoirienne est faux avant d'être discutable. Il reste défendable pour une cible professionnelle étroite, et cela se dit comme tel.
- TikTok est au niveau de Facebook, à 0,6 point. Le traiter comme un canal secondaire est un réflexe importé, pas une lecture du terrain.
- WhatsApp est le canal par défaut, pas une option. 92,8 % des internautes.
- Messenger n'est pas Facebook : 36,6 % contre 82,1 %. Publier sur une page et espérer une conversation ne touche pas la même audience.
## Le reste de l'enquête, utile au même endroit
- Téléphone mobile 72,4 % des individus, mais smartphone 42,4 % seulement (58,5 % des mobiles utilisés sont des smartphones). Un format lourd exclut la moitié du pays.
- Ordinateur 9,6 % sur les trois derniers mois.
- Parmi les internautes, 74 % se connectent quotidiennement, 94 % à domicile.
- Méthode : échantillon stratifié, 7 474 189 ménages, 27 216 065 individus de 5 ans et plus, entretiens face à face assistés par tablette, 33 districts et régions.
## Ce que cette note ne dit pas
Elle ne donne ni les heures d'audience, ni les taux d'engagement, ni les tarifs. La MSI mesure l'usage déclaré, pas la performance d'une publication. Pour l'engagement réel des marques ivoiriennes, voir memory/reference/reseaux-marques-ci.md, qui n'existe aujourd'hui que chez FATIMA (vérifié le 20/09/2026 : absent chez KOFFI, KOUASSI et ADJOUA).

