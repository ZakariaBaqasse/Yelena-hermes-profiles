# 260920_Socle local uemoa-commun-ou-national

===== onglet t.0 · Tab 1 · 22 lignes non vides =====

# Régional ou national : trois périmètres qu'on confond
Relevé le 20/09/2026. À revérifier le 20/09/2027.

Une règle citée comme régionale alors qu'elle est nationale décrédibilise tout le livrable qui la porte. Trois ensembles se superposent sur la Côte d'Ivoire, et ils n'ont ni la même taille ni le même objet.

| Ensemble | Ce qu'il couvre | Portée |
| OHADA | Droit des affaires : sociétés, sûretés, recouvrement, comptabilité, arbitrage | 17 États, bien au-delà de l'UEMOA |
| UEMOA | Monnaie, relations financières extérieures, marché commun | 8 États |
| CEDEAO | Libre circulation, commerce régional | 15 États |

Les huit États de l'UEMOA : Bénin, Burkina Faso, Côte d'Ivoire, Guinée-Bissau, Mali, Niger, Sénégal, Togo (relevé sur bceao.int le 18/09/2026).
## Ce qui est commun
- Le droit des affaires. Les dix actes uniformes OHADA sont directement applicables en Côte d'Ivoire et priment sur le droit interne contraire. Ce n'est pas un droit étranger, c'est le socle du droit des affaires ivoirien. Sur disque, article par article : ../ohada/.
- La monnaie. Franc CFA, BCEAO, parité fixe avec l'euro. Voir monnaie-et-ordres-de-grandeur.md.
- Les relations financières extérieures, règlement n° 09/2010/CM/UEMOA du 1er octobre 2010 : ../change-uemoa/. Règle centrale et asymétrique, l'entrée est libre, la sortie ne l'est pas : tout investissement à l'étranger par un résident est subordonné à une autorisation préalable du ministre chargé des Finances.
## ⛔ Ce qui ne l'est pas, et c'est là que les erreurs se font
- Le droit du travail est national. Code du travail ivoirien, loi 2015-532, et convention interprofessionnelle de 1977. L'OHADA ne le régit pas. ../droit-travail-ci/.
- La fiscalité est nationale. TVA à 18 %, taux réduit 9 % (vérifié le 20/09 sur la synthèse de la DGI). Un taux du Sénégal ou du Bénin ne s'applique pas ici. ../fiscalite-ci/.
- La publicité est nationale. L'OHADA ne régit pas la publicité : c'est le CSP qui valide, et il est ivoirien.
- Le SMIG est national : 75 000 FCFA par mois depuis le 1er janvier 2023.
- Les fêtes et jours chômés sont nationaux.
## La règle d'écriture
Avant de citer une règle, se demander de quel texte elle vient, pas de quel pays on parle. Un acte uniforme se cite par son article et vaut dans dix-sept pays ; un code ivoirien se cite par son article et ne vaut qu'ici. Écrire « dans l'UEMOA » à propos d'une règle de droit des affaires est faux deux fois : c'est l'OHADA, et son périmètre est plus large.
## Un détail technique qui fait perdre du temps
uemoa.int sert une chaîne de certificat incomplète : les scripts échouent (CERTIFICATE_VERIFY_FAILED), un navigateur passe. Ce n'est ni une panne ni un blocage. integrations/web-public/telecharger.py complète la chaîne et rejoue la requête.

