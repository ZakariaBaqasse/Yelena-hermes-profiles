# 260922_Notes methodologiques des enquetes ivoiriennes - EHCVM et EDS

===== onglet t.0 · Tab 1 · 34 lignes non vides =====

# Les notes méthodologiques des grandes enquêtes ivoiriennes
Constituée le 22/09/2026. Elle répond à une question précise : de quoi une enquête ivoirienne est-elle réellement représentative, avant qu'un chiffre qui en sort serve à dimensionner un marché ou à cadrer une recommandation.

⛔ Un taux de réponse de 99 % ne dit rien de la couverture. Il mesure la part des ménages tirés qui ont répondu. Il ne dit rien des ménages que la base de sondage n'a jamais vus.
## Comment ces pièces ont été obtenues
anstat.ci reste derrière une épreuve gérée de Cloudflare, y compris sur ses fichiers (/assets/projet/ehcvm2021.pdf rend 403). La règle du co-éditeur a de nouveau fonctionné : ces deux enquêtes sont co-produites, l'EHCVM avec la Commission de l'UEMOA et la Banque mondiale, l'EDS avec le Programme DHS. Les deux co-éditeurs publient la documentation méthodologique en accès libre.

| Pièce | Ce qu'elle contient | Origine |
| ehcvm-2021-2022-ci-documentation.pdf | plan de sondage, tailles, vagues, questionnaires, conditions de citation | catalogue de microdonnées de la Banque mondiale, étude 6273 |
| ehcvm-2021-2022-ci-ddi.xml | les mêmes métadonnées en DDI, plus le dictionnaire des variables | même source, export DDI |
| eds-ci-2021-indicateurs-cles.pdf / .txt | plan de sondage, strates, grappes, terrain, taux de réponse | Programme DHS, publication PR140 |

Adresses : https://microdata.worldbank.org/index.php/catalog/6273 · https://dhsprogram.com/pubs/pdf/PR140/PR140.pdf
## Les deux enquêtes en regard
|  | EHCVM 2021/22 (pauvreté, consommation) | EDS-CI 2021 (santé, démographie) |
| Base de sondage | RGPH 2014, grappes de l'EHCVM 2018/19 revisitées | cartographie censitaire de 2019, préparatoire au RGPH |
| Tirage | stratifié à deux degrés, grappes avec probabilité proportionnelle à la taille, puis 12 ménages à probabilité égale | stratifié à deux degrés, 28 strates, 539 grappes (261 urbaines, 278 rurales), tirage systématique avec probabilité proportionnelle à la taille |
| Échantillon | 13 693 ménages, 5 675 urbains et 8 018 ruraux | 15 093 ménages tirés, 14 873 occupés, 14 766 enquêtés |
| Terrain | deux vagues : nov. 2021 à janv. 2022, puis avril à juil. 2022 | une seule fenêtre : 8 septembre au 30 décembre 2021 |
| Représentativité | national, urbain et rural, régions administratives, districts d'Abidjan et de Yamoussoukro | national, urbain et rural, 14 districts administratifs |
| Taux de réponse | non publié dans cette documentation | 99 % ménages, 98 % femmes de 15 à 49 ans, 97 % hommes de 15 à 59 ans |
| Mode | entretien assisté par ordinateur | entretien assisté par ordinateur, 196 enquêteurs, 24 équipes |

⚠ Elles ne reposent pas sur la même base de sondage. L'une part du recensement de 2014, l'autre de la cartographie de 2019. Deux chiffres tirés de ces deux enquêtes se citent chacun avec sa source ; ils ne se croisent pas au niveau fin comme s'ils décrivaient la même population de départ.
## Les biais, nommés
- La base de sondage de l'EHCVM a sept ans de retard. Une enquête publiée « 2021-2022 » tire ses grappes du recensement de 2014. Un quartier bâti depuis, un lotissement neuf, une zone périurbaine née de l'étalement d'Abidjan ont une probabilité nulle d'être tirés. C'est précisément là que la croissance urbaine est la plus rapide.
- C'est un panel de grappes, pas un tirage neuf. L'enquête de 2021/22 revisite les grappes de 2018/19 et complète à 12 ménages là où il en manque. Excellent pour comparer une même zone dans le temps ; mauvais pour représenter ce qui est apparu entre-temps.
- La saisonnalité est traitée dans l'EHCVM, elle ne l'est pas dans l'EDS. L'EHCVM coupe son échantillon en deux vagues explicitement pour tenir compte de la saisonnalité de la consommation. L'EDS-CI 2021, elle, a collecté du 8 septembre au 30 décembre : une seule fenêtre, fin de saison des pluies au sud et récoltes au nord. Tout ce qui est saisonnier en santé, paludisme et alimentation en tête, est mesuré dans cette fenêtre, pas sur l'année. ⛔ La réserve de saisonnalité ne se sert donc plus en bloc : elle vise l'EDS, et elle ne vise pas l'EHCVM.
- Le domaine de représentativité n'est pas le découpage dont on a envie. L'EDS-CI 2021 est représentative des 14 districts, pas des régions ni des communes. Un chiffre « par région » ou « pour Cocody » n'existe pas dans cette enquête, et un sous-total calculé à la main sur les microdonnées n'a pas la précision d'un résultat publié.
- Dans une même enquête, tous les chiffres n'ont pas la même assise. Dans l'EDS, les hommes ne sont interrogés que dans un ménage sur deux ; l'anthropométrie et les tests d'anémie et de paludisme portent sur ce même sous-échantillon ; la qualité de l'eau de boisson, sur cinq ménages par grappe sur vingt-huit. Un chiffre « hommes » et un chiffre « ménages » du même rapport ne se citent pas avec la même assurance.
- Le nom du producteur a changé. Ces documents nomment l'Institut national de la statistique (INS) : c'est l'ANStat d'aujourd'hui. Même organisme.
## Ce que cette base ne contient pas
- Le rapport général de l'EHCVM en français, publié par l'ANStat et inatteignable. La documentation de la Banque mondiale le remplace sur la méthode, pas sur les résultats commentés.
- Le rapport final de l'EDS-CI 2021, dont seule la publication d'indicateurs clés est ici. Les tableaux détaillés et les erreurs de sondage sont dans le rapport final.
- Les rapports thématiques du RGPH 2021 : toujours pas retrouvés chez un ministère co-éditeur. ⟦à chercher⟧
- Les taux de réponse de l'EHCVM, absents de la documentation obtenue. Ne pas supposer qu'ils ressemblent à ceux de l'EDS.
- Les enquêtes d'entreprises et les enquêtes d'audience, qui relèvent d'autres producteurs. Pour l'audience des canaux, voir numerique-ci/.

À recontrôler le 22/03/2027, ou dès que les résultats du RGPH 2021 sont publiés : ils changeront la base de sondage de toutes les enquêtes suivantes.
