#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Icônes des restitutions de modèles prédictifs, dessinées en vecteur. Une icône = un sens, le même dans tout le document :
  depart (personne et flèche qui sort), credit (pièces et flèche qui ne revient pas), calendrier (jours à venir),
  sms (bulle de message), attention (triangle), decision (main qui tranche : balance).
Couleurs passées en paramètre pour suivre la charte de la maison (par défaut : brun, orange, crème du banc d'essai).
    from icones_prediction import dessiner ; dessiner("depart", "/chemin/depart.png", fonce="#2E1C14", accent="#F3711A", fond="#F1E6D2")
"""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Polygon, Rectangle, FancyArrow, Wedge

LW = 5

def _depart(ax, F, A):
    ax.add_patch(Circle((38, 66), 11, fill=False, ec=F, lw=LW))
    ax.add_patch(Wedge((38, 22), 24, 0, 180, fill=False, ec=F, lw=LW))
    ax.add_patch(FancyArrow(60, 44, 24, 0, width=6, head_width=18, head_length=10, length_includes_head=True, color=A))

def _credit(ax, F, A):
    for y in (22, 34, 46):
        ax.add_patch(FancyBboxPatch((18, y), 40, 9, boxstyle="round,pad=0,rounding_size=4.5", fc="none", ec=F, lw=3.5))
    ax.add_patch(FancyArrow(66, 62, 16, 16, width=5, head_width=15, head_length=9, length_includes_head=True, color=A))
    ax.plot([64, 84], [30, 50], color=A, lw=LW, solid_capstyle="round"); ax.plot([64, 84], [50, 30], color=A, lw=LW, solid_capstyle="round")

def _calendrier(ax, F, A):
    ax.add_patch(FancyBboxPatch((20, 18), 60, 56, boxstyle="round,pad=0,rounding_size=4", fill=False, ec=F, lw=LW))
    ax.add_patch(Rectangle((20, 60), 60, 14, color=F))
    for x in (34, 66): ax.plot([x, x], [70, 82], color=F, lw=LW, solid_capstyle="round")
    for i, x in enumerate((30, 44, 58)):
        for j, y in enumerate((46, 30)):
            ax.add_patch(Rectangle((x, y), 9, 9, color=A if (i == 2 and j == 1) else F))

def _sms(ax, F, A):
    ax.add_patch(FancyBboxPatch((16, 34), 68, 44, boxstyle="round,pad=0,rounding_size=10", fill=False, ec=F, lw=LW))
    ax.add_patch(Polygon([(30, 36), (26, 18), (46, 36)], closed=True, fc=F))
    for x in (36, 50, 64): ax.add_patch(Circle((x, 56), 4.5, color=A))

def _attention(ax, F, A):
    ax.add_patch(Polygon([(50, 84), (86, 20), (14, 20)], closed=True, fill=False, ec=A, lw=LW + 1, joinstyle="round"))
    ax.plot([50, 50], [44, 66], color=F, lw=LW + 2, solid_capstyle="round"); ax.add_patch(Circle((50, 32), 4, color=F))

def _decision(ax, F, A):
    ax.plot([50, 50], [20, 78], color=F, lw=LW, solid_capstyle="round"); ax.plot([22, 78], [70, 70], color=F, lw=LW, solid_capstyle="round")
    ax.plot([34, 66], [20, 20], color=F, lw=LW, solid_capstyle="round")
    ax.add_patch(Wedge((26, 50), 12, 180, 360, color=A)); ax.add_patch(Wedge((74, 50), 12, 180, 360, color=F))
    for x in (26, 74): ax.plot([x, x], [50, 70], color=F, lw=2.5)

DESSINS = dict(depart=_depart, credit=_credit, calendrier=_calendrier, sms=_sms, attention=_attention, decision=_decision)

def dessiner(nom, chemin, px=300, fonce="#2E1C14", accent="#F3711A", fond="#F1E6D2"):
    fig = plt.figure(figsize=(1, 1), dpi=px); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
    ax.set_aspect("equal"); ax.add_patch(Circle((50, 50), 48, color=fond, zorder=0)); DESSINS[nom](ax, fonce, accent)
    fig.savefig(chemin, transparent=True); plt.close(fig); return chemin

if __name__ == "__main__":
    import sys, os
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    for n in DESSINS: print(dessiner(n, os.path.join(out, f"icone-{n}.png")))
