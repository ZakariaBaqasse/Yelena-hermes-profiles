#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc d'essai des modèles prédictifs de Nadia, sur jeux FICTIFS générés ici (graine fixe, reproductible).
Créé le 23/09/2026 à la demande du testeur (vocal, identifiant 6140428246 : « fais des essais sur tous les modèles prédictifs »).
Quatre cas, chacun comparé à une règle simple de référence, jugé sur des données qu'il n'a pas vues :
  1. client qui va partir (classement)        2. crédit qui ne sera pas remboursé (classement, tableau des seuils)
  3. recettes des 8 prochaines semaines        4. test A/B d'une campagne SMS (et taille d'échantillon)
    ~/.venv-office/bin/python banc_predictif.py <dossier_sortie>
Sorties : resultats.json (tous les chiffres) + graphiques PNG. Rien n'est inventé dans le texte : il se lit dans resultats.json.
Pour un vrai client : remplacer la génération par ses données, garder tout le reste (découpage, référence, métriques).
"""
import os, sys, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, brier_score_loss
from sklearn.inspection import permutation_importance
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.stats.proportion import proportions_ztest, confint_proportions_2indep
from statsmodels.stats.power import NormalIndPower
from statsmodels.stats.proportion import proportion_effectsize

OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(20260923)
R = {}
BR, OR, CR, GR = "#2E1C14", "#F3711A", "#F1E6D2", "#8A7B72"

def decile_haut(y, p):
    """Part des vrais cas captés en ne contactant que les 10 % jugés les plus à risque, et taux dans ce groupe."""
    k = max(1, int(len(p) * 0.10)); idx = np.argsort(-p)[:k]
    return float(y[idx].sum() / y.sum()), float(y[idx].mean())

def captes(y, p, parts=(0.10, 0.20, 0.30)):
    """Part des vrais cas captés selon la part de clients contactés (les plus à risque d'abord)."""
    o = np.argsort(-p); return {f"{int(q * 100)}pct": float(y[o[:int(len(p) * q)]].sum() / y.sum()) for q in parts}

def classement(nom, X, y, num, cat, regle):
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=1, stratify=y)
    pre = ColumnTransformer([("n", StandardScaler(), num), ("c", OneHotEncoder(handle_unknown="ignore"), cat)])
    mods = {"régression logistique": make_pipeline(pre, LogisticRegression(max_iter=2000)),
            "arbres boostés": make_pipeline(ColumnTransformer([("n", "passthrough", num), ("c", OneHotEncoder(handle_unknown="ignore"), cat)]),
                                             HistGradientBoostingClassifier(max_iter=250, learning_rate=0.05, random_state=1))}
    res = {"n_apprentissage": len(Xtr), "n_test": len(Xte), "taux_reel_test": float(yte.mean())}
    pr = regle(Xte).astype(float); bruit = rng.random(len(pr)) * 1e-6   # départage au hasard les ex æquo de la règle (un seul tirage)
    cap, taux = decile_haut(yte.values, pr + bruit)
    res["regle_simple"] = dict(auc=float(roc_auc_score(yte, pr)), capte_10pct=cap, taux_10pct=taux,
                               captes=captes(yte.values, pr + bruit),
                               part_signalee=float(pr.mean()), capte_si_on_appelle_tous_les_signales=float(yte.values[pr == 1].sum() / yte.sum()))
    best, bauc = None, -1
    for k, m in mods.items():
        m.fit(Xtr, ytr); p = m.predict_proba(Xte)[:, 1]; cap, taux = decile_haut(yte.values, p)
        res[k] = dict(auc=float(roc_auc_score(yte, p)), brier=float(brier_score_loss(yte, p)), capte_10pct=cap, taux_10pct=taux,
                      captes=captes(yte.values, p))
        if res[k]["auc"] > bauc: best, bauc, bp = k, res[k]["auc"], p
    res["meilleur"] = best
    imp = permutation_importance(mods[best], Xte, yte, scoring="roc_auc", n_repeats=8, random_state=1)
    res["facteurs"] = sorted([(c, round(float(v), 4)) for c, v in zip(X.columns, imp.importances_mean)], key=lambda t: -t[1])[:5]
    return res, yte.values, bp

# ── 1. client qui va partir (banque ou mobile money, fictif) ─────────────────────────────────────────────────────
n = 3000
C = pd.DataFrame({"anciennete_mois": rng.integers(1, 96, n), "operations_3_mois": rng.poisson(14, n),
                  "baisse_operations_pct": np.clip(rng.normal(0, 30, n), -80, 100), "solde_moyen_kfcfa": np.round(rng.lognormal(4.5, 1.0, n)),
                  "reclamations_6_mois": rng.poisson(0.4, n), "a_un_credit": rng.integers(0, 2, n),
                  "canal": rng.choice(["appli", "agence", "les deux"], n, p=[.45, .25, .30]), "age": rng.integers(18, 70, n)})
z = (0.2 + 0.035 * C.baisse_operations_pct - 0.08 * C.operations_3_mois + 0.55 * C.reclamations_6_mois - 0.012 * C.anciennete_mois
     - 0.5 * C.a_un_credit + np.where(C.canal == "agence", 0.45, np.where(C.canal == "les deux", -0.5, 0)) - 0.15 * np.log1p(C.solde_moyen_kfcfa))
yC = pd.Series((rng.random(n) < 1 / (1 + np.exp(-z))).astype(int))
R["depart"], yt, pt = classement("depart", C, yC, ["anciennete_mois", "operations_3_mois", "baisse_operations_pct", "solde_moyen_kfcfa",
                                  "reclamations_6_mois", "a_un_credit", "age"], ["canal"], lambda X: (X.baisse_operations_pct > 30).values)
R["depart"]["taux_global"] = float(yC.mean())

# ── 2. crédit qui ne sera pas remboursé (microcrédit ou ardoise, fictif) ─────────────────────────────────────────
n = 2000
K = pd.DataFrame({"montant_kfcfa": np.round(rng.lognormal(5.3, 0.7, n)), "duree_mois": rng.choice([3, 6, 12, 18, 24], n),
                  "retards_passes": rng.poisson(0.6, n), "revenu_mensuel_kfcfa": np.round(rng.lognormal(5.0, 0.6, n)),
                  "anciennete_client_mois": rng.integers(0, 60, n), "secteur": rng.choice(["commerce", "restauration", "transport", "artisanat"], n)})
z = (-3.0 + 0.9 * K.retards_passes + 0.9 * np.log(K.montant_kfcfa / K.revenu_mensuel_kfcfa) + 0.04 * K.duree_mois - 0.02 * K.anciennete_client_mois
     + np.where(K.secteur == "transport", 0.4, 0))
yK = pd.Series((rng.random(n) < 1 / (1 + np.exp(-z))).astype(int))
R["credit"], ytk, ptk = classement("credit", K, yK, ["montant_kfcfa", "duree_mois", "retards_passes", "revenu_mensuel_kfcfa", "anciennete_client_mois"],
                                   ["secteur"], lambda X: (X.retards_passes >= 1).values)
R["credit"]["taux_global"] = float(yK.mean())
seuils = []
for q in (0.05, 0.10, 0.20, 0.30):   # refuser la part q des dossiers jugés les plus risqués
    k = int(len(ptk) * q); idx = np.argsort(-ptk)[:k]
    seuils.append(dict(dossiers_refuses_pct=q, defauts_evites_pct=float(ytk[idx].sum() / ytk.sum()), bons_clients_refuses=int(k - ytk[idx].sum())))
R["credit"]["seuils"] = seuils

# ── 3. recettes des 8 prochaines semaines (maquis fictif, 2 ans de jours) ────────────────────────────────────────
jours = pd.date_range("2024-09-02", periods=735, freq="D")
t = np.arange(len(jours))
hebdo = np.array([0.85, 0.80, 0.88, 0.92, 1.12, 1.35, 1.20])[jours.dayofweek]
mois = pd.Series(jours.month).map({1: .92, 2: .95, 3: 1.0, 4: 1.0, 5: .97, 6: .88, 7: .90, 8: .95, 9: 1.0, 10: 1.02, 11: 1.05, 12: 1.22}).values
rec = 90000 * (1 + 0.0004 * t) * hebdo * mois * rng.lognormal(0, 0.12, len(t))
S = pd.Series(np.round(rec), index=jours); H = 56
tr, te = S.iloc[:-H], S.iloc[-H:]
p_naif = pd.Series(np.tile(tr.iloc[-7:].values, H // 7), index=te.index)
hw = ExponentialSmoothing(tr, trend="add", seasonal="mul", seasonal_periods=7).fit(); p_hw = hw.forecast(H)
cal = lambda idx: pd.DataFrame({"t": np.arange(len(idx)) + (0 if idx[0] == S.index[0] else len(tr)), "jour": idx.dayofweek, "mois": idx.month})
gb = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, random_state=1, categorical_features=[1, 2]).fit(cal(tr.index), tr.values)
p_gb = pd.Series(gb.predict(cal(te.index)), index=te.index)
def wape(a, p): return float(np.abs(a - p).sum() / a.sum())
R["prevision"] = {"jours_historique": len(tr), "jours_testes": H,
                  "erreur_semaine_derniere_repetee": wape(te, p_naif), "erreur_lissage_saisonnier": wape(te, p_hw), "erreur_arbres_calendrier": wape(te, p_gb)}
res = (tr - hw.fittedvalues).dropna(); q10, q90 = np.quantile(res / hw.fittedvalues.loc[res.index], [0.1, 0.9])
R["prevision"]["fourchette_80pct"] = [float(q10), float(q90)]
couvert = ((te >= p_hw * (1 + q10)) & (te <= p_hw * (1 + q90))).mean(); R["prevision"]["jours_dans_la_fourchette"] = float(couvert)
sem = pd.DataFrame({"reel": te, "prevu": p_hw}).resample("W-SUN").sum()
R["prevision"]["erreur_par_semaine"] = wape(sem.reel, sem.prevu)
fig, ax = plt.subplots(figsize=(7, 2.6), dpi=160)
ax.plot(S.index[-H - 56:], S.iloc[-H - 56:], color=GR, lw=1, label="recettes réelles")
ax.plot(te.index, p_hw, color=OR, lw=2, label="prévision")
ax.fill_between(te.index, p_hw * (1 + q10), p_hw * (1 + q90), color=OR, alpha=.18, label="fourchette (8 jours sur 10)")
ax.axvline(te.index[0], color=BR, lw=.8, ls="--"); ax.legend(frameon=False, fontsize=7, loc="upper left"); ax.set_yticks([]); ax.spines[["top", "right", "left"]].set_visible(False)
import matplotlib.dates as mdates
ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=0, interval=2)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%d/%m")); ax.tick_params(labelsize=7)
ax.text(te.index[0], ax.get_ylim()[1], "  jours cachés au modèle", fontsize=7, color=BR, va="top")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "prevision.png")); plt.close(fig)

# ── 4. test A/B d'une campagne SMS (fictif) ─────────────────────────────────────────────────────────────────────
nA, nB = 4000, 4000; xA = int(rng.binomial(nA, 0.031)); xB = int(rng.binomial(nB, 0.042))
zst, pv = proportions_ztest([xB, xA], [nB, nA]); lo, hi = confint_proportions_2indep(xB, nB, xA, nA, method="wald")
es = proportion_effectsize(0.04, 0.03); n_req = NormalIndPower().solve_power(effect_size=es, alpha=0.05, power=0.8, alternative="two-sided")
R["test_ab"] = dict(temoin=dict(n=nA, ouvertures=xA, taux=xA / nA), sms=dict(n=nB, ouvertures=xB, taux=xB / nB), p_valeur=float(pv),
                    ecart_points=[float(lo) * 100, float(hi) * 100], taille_par_groupe_pour_3_vers_4_pct=int(np.ceil(n_req)))

# ── graphiques de classement : part des départs captés selon la part contactée ───────────────────────────────────
fig, ax = plt.subplots(figsize=(7, 2.6), dpi=160)
for (yy, pp, lab, col) in ((yt, pt, "client qui va partir", BR), (ytk, ptk, "crédit non remboursé", OR)):
    o = np.argsort(-pp); cum = np.cumsum(yy[o]) / yy.sum(); x = np.arange(1, len(o) + 1) / len(o)
    ax.plot(x * 100, cum * 100, color=col, lw=2, label=lab)
ax.plot([0, 100], [0, 100], color=GR, lw=1, ls="--", label="au hasard")
ax.set_xlabel("part des clients contactés, les plus à risque d'abord (%)", fontsize=7); ax.set_ylabel("part des cas captés (%)", fontsize=7)
ax.legend(frameon=False, fontsize=7); ax.spines[["top", "right"]].set_visible(False); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "classement.png")); plt.close(fig)

json.dump(R, open(os.path.join(OUT, "resultats.json"), "w"), ensure_ascii=False, indent=1)
print(json.dumps(R, ensure_ascii=False, indent=1))
