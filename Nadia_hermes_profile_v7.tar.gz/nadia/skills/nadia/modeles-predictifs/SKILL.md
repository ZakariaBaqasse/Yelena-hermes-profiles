---
name: modeles-predictifs
description: "À charger dès qu'on demande de prévoir un comportement ou un chiffre : le client qui va partir, le crédit qui ne sera pas remboursé, l'agence qui va décrocher, les recettes des prochaines semaines, ou l'effet d'une campagne testée sur un groupe. Dit comment construire un modèle prédictif honnête (une règle simple de référence d'abord, un test sur des données que le modèle n'a pas vues, des mesures qu'un dirigeant comprend) et comment le restituer à un lecteur non technique. Le seuil d'action reste une décision de l'entreprise. Script éprouvé : references/banc_predictif.py."
bucket: B
tags: [Données, Prédiction, Apprentissage automatique, Nouveau]
version: 1
maj: 2026-09-23
---

<!-- Code Y : non attribué, il se donne au catalogue commun, jamais ici. -->

# Un modèle prédictif se juge sur ce qu'il n'a pas vu, face à une règle simple

Créée le 23/09/2026 après un banc d'essai sur quatre cas (données fictives, graine fixe) :
départ de clients, défaut de crédit, prévision de recettes journalières, test A/B d'une campagne
SMS. Le script `references/banc_predictif.py` fait tout le chemin et sert de point de départ pour
un vrai client : on remplace la génération des données, on garde le découpage, la référence et
les mesures.

    ~/.venv-office/bin/python .claude/skills/modeles-predictifs/references/banc_predictif.py <dossier_sortie>

Sorties : `resultats.json` (tous les chiffres), `classement.png`, `prevision.png`. Aucun chiffre
de la restitution ne s'écrit ailleurs que depuis `resultats.json`.

## 1. Quatre questions avant d'entraîner quoi que ce soit

1. **Quelle décision le modèle éclaire-t-il ?** Appeler 200 clients ce mois-ci, refuser un
   dossier, commander du stock. Sans décision, pas de modèle : un score que personne n'utilise
   est un coût.
2. **Que sait-on au moment où l'on décide ?** Une variable connue seulement après coup (le
   dernier retard de paiement, le motif de clôture) donne un modèle parfait sur le papier et
   inutile en vrai. C'est la fuite d'information, la faute la plus fréquente : on la cherche
   variable par variable, en se demandant « à quelle date cette case est-elle remplie ? ».
3. **Combien de cas positifs ?** Moins d'une centaine de départs ou de défauts dans
   l'historique : on ne construit pas de modèle, on décrit les cas un par un et on propose une
   règle simple.
4. **Données personnelles ?** Un score de risque sur des personnes nommées relève de la liste
   des validations (collecte de données personnelles, conclusion sur une personne). On travaille
   sur un identifiant, jamais sur un nom, et le score ne part pas sans accord.

## 2. Le chemin, toujours le même

| Étape | Classement (départ, défaut) | Prévision de chiffres | Test A/B |
|---|---|---|---|
| Référence | Une règle simple écrite en une phrase (« les clients dont l'activité a baissé de plus de 30 % ») | « La même chose que la semaine dernière » | Le groupe témoin |
| Découpage | 70/30 stratifié, ou mieux : le passé pour apprendre, le dernier trimestre pour juger | Les N derniers jours cachés au modèle, jamais un tirage au hasard | Tirage au sort AVANT l'action |
| Modèles essayés | Régression logistique, puis arbres boostés (HistGradientBoosting) | Lissage saisonnier (Holt-Winters), arbres sur le calendrier | Test de deux proportions |
| Mesure technique | AUC, score de Brier | Erreur absolue pondérée (WAPE) | Valeur p, intervalle de l'écart |
| Mesure pour le client | « En appelant 10 % des clients, on touche X % des départs » | « Erreur moyenne de X % par jour, Y % par semaine » | « L'écart va de A à B points » |

On garde le modèle le plus simple qui bat nettement la référence. Si rien ne bat la règle
simple, **c'est le résultat**, et il se livre : la règle simple devient l'outil, sans honte.

## 3. Ce que le banc du 23/09 a appris (données fictives)

- La régression logistique a battu les arbres boostés sur les deux classements (AUC 0,83 contre
  0,77 pour les départs). Explication : les données fictives étaient générées par une formule
  logistique. Sur de vraies données, l'ordre peut s'inverser : **on essaie toujours les deux**,
  on ne conclut jamais d'un banc fictif.
- Sur les départs, en n'appelant que 1 client sur 10, le modèle fait à peine mieux que la règle
  simple (36 % des départs trouvés contre 34 %) ; à 2 sur 10, l'écart se creuse (59 % contre
  45 %). **On montre le gain à plusieurs niveaux de contact**, jamais à un seul.
- Sur la prévision, le lissage saisonnier et les arbres font presque jeu égal (10,4 % et
  10,7 % d'erreur par jour), les deux battent nettement « la semaine dernière » (14,8 %).
  L'erreur par semaine tombe à 6,4 % : **on annonce la maille où le chiffre sert**.
- La fourchette « 8 jours sur 10 » tirée des erreurs passées a contenu 79 % des jours testés :
  on vérifie toujours la fourchette sur les jours cachés, on ne la suppose pas.
- Le test A/B (3,15 % contre 3,93 %, p = 0,06) n'est pas concluant ; il aurait fallu environ
  5 300 personnes par groupe pour voir un passage de 3 % à 4 %. **La taille d'échantillon se
  calcule avant la campagne**, pas après.

## 4. Le seuil appartient à l'entreprise

Un modèle de classement ne dit pas « refuser » ou « appeler » : il range. Où l'on coupe dépend
de ce que coûte une erreur dans chaque sens, et ce coût, seule la maison le connaît. On livre
donc toujours **le tableau des seuils** et jamais un seuil choisi :

| Dossiers refusés | Défauts évités | Bons clients refusés |
|---|---|---|
| 5 % | … | … |
| 10 % | … | … |
| 20 % | … | … |

La ligne sous le tableau dit qui tranche (direction du crédit, direction commerciale) et ce qu'il
faut savoir pour trancher (perte moyenne sur un défaut, marge moyenne sur un bon client).

## 5. Expliquer les facteurs sans promettre une cause

L'importance par permutation dit **ce qui aide le modèle à ranger**, pas ce qui fait partir le
client. « Les clients dont l'activité baisse sont ceux qui partent le plus » est permis ;
« la baisse d'activité fait partir les clients » ne l'est pas. On nomme trois facteurs au plus,
en mots de tous les jours, avec le sens de l'effet quand il est lisible.

## 6. La restitution, pour un lecteur non technique (réglage par défaut)

- **Une page par modèle**, une icône par idée, le même sens partout.
- Première phrase : ce que le modèle permet de faire, en une action (« appeler 90 clients ce
  mois-ci au lieu de 900 »).
- Le chiffre qui compte en mots simples : « sur 10 clients qui vont partir, on en trouve presque 4 en
  appelant seulement 1 client sur 10 ». Les mots AUC, Brier, WAPE, valeur p restent dans les
  notes de travail ; si l'un d'eux doit apparaître, il porte son nom développé et une phrase
  qui dit ce qu'il mesure.
- Un graphique qui montre le gain face au hasard ou à la règle simple, avant tout tableau.
- Ce que le modèle ne dit pas, en une ligne (« il range les clients, il ne dit pas pourquoi ils
  partent »).
- **Données fictives : écrit en tête, en gros**, dès que le jeu ne vient pas du client.

## 7. Ce qui fait échouer

- Un score livré sans la règle simple à côté : personne ne sait s'il apporte quelque chose.
- Un modèle jugé sur les données qui ont servi à l'apprendre.
- Un tirage au hasard sur une série dans le temps : le modèle voit l'avenir.
- Un seuil fixé par l'analyste.
- Une AUC annoncée à un dirigeant sans traduction.
- Un résultat de banc fictif présenté comme une performance attendue chez le client.
- Un taux de départ, un taux de défaut ou un seuil « habituel du secteur » posé de mémoire :
  il se source ou il ne s'écrit pas.

## Compétences voisines

`prevision-et-tendance` (séries sans modèle), `statistiques-pour-decider` (marges d'erreur),
`concevoir-une-experimentation` (le protocole du test A/B avant l'action),
`restitution-des-donnees` (la mise en page).
