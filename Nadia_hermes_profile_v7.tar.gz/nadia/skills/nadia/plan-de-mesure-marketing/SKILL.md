---
id: Y0394
name: plan-de-mesure-marketing
description: "Construit le plan de mesure d'une activité marketing avant qu'elle soit lancée : objectif commercial par action, indicateurs d'exposition / d'intérêt / de résultat reliés entre eux, seuil de déclenchement ou période de référence si aucun historique n'existe, instrumentation du hors-ligne, et refus des indicateurs qui ne changent aucune décision — sans jamais inventer un seuil, un taux ou une moyenne du secteur."
bucket: B
tags: [Marketing, Pilotage, Horizontal, Nouveau]
version: 1
maj: 2026-08-10
---

# Le plan de mesure — ce qu'on suit, pourquoi, et ce qui déclenche une décision

## Ce qu'il faut avoir sous la main
- **L'objectif commercial** poursuivi : plus de demandes, plus de ventes, un réachat plus fréquent, une notoriété dans une zone donnée — le plus concret possible.
- **Les actions marketing prévues ou en cours** : campagne digitale, radio, affichage, salon, WhatsApp, promotion en point de vente — tout ce qui est réellement lancé ou budgété.
- **Ce que tu mesures déjà** aujourd'hui, canal par canal, même si c'est incomplet ou seulement du digital.
- **Ton historique** : as-tu des chiffres d'une période comparable, ou est-ce la première fois que tu suis cette activité ?
- **Ce qui, pour toi, compterait comme un échec** de la campagne — même formulé de façon approximative, ça donne la direction du seuil.


> ⚡ **Tu n'attends pas d'avoir « tout ».** Si un contexte t'est déjà fourni (même partiel), tu **produis directement le livrable** en étiquetant tes hypothèses (`[hypothèse : …]`) — tu ne redemandes que ce qui est réellement indispensable et impossible à supposer raisonnablement. Un intake complet est l'idéal, pas une condition de démarrage.

## Process
### Étape 1 — Reformuler l'objectif commercial et relier chaque action

Pars de l'objectif commercial déclaré, pas de l'action. « On veut faire une campagne Facebook » n'est pas un objectif, c'est une action en quête d'objectif. Reformule : qu'est-ce que l'entreprise cherche à obtenir en chiffre d'affaires, en clients, en fréquence d'achat — et à quel horizon.

Relie ensuite chaque action marketing annoncée à cet objectif. Une action qui ne se relie à aucun objectif commercial identifiable n'entre pas dans le plan — elle est signalée à part, comme dépense non pilotée.

### Étape 2 — Distinguer les trois étages et exiger qu'ils se répondent

Range les indicateurs disponibles ou envisageables en trois étages :
- **Exposition** — portée, impressions, personnes touchées, audience d'un spot radio.
- **Intérêt** — clics, messages reçus, appels au numéro dédié, visites en boutique attribuables à l'action.
- **Résultat** — demandes qualifiées, ventes, réachats.

Le piège à désamorcer explicitement : une portée qui monte sans que l'étage du dessous bouge n'est pas un succès, c'est une information — quelque chose a été vu et n'a rien produit. Tu ne valides jamais un plan qui ne suit que l'exposition. Si l'entreprise ne peut suivre qu'un seul étage au démarrage, tu le dis, et tu marques les deux autres comme à instrumenter en priorité.

### Étape 3 — Le test de la décision : un indicateur qui ne déclenche rien sort

Pour chaque indicateur candidat, écris la phrase : *« si cet indicateur passe sous ⟦à renseigner⟧, alors on fait ⟦à renseigner⟧ »*. Si cette phrase ne peut pas s'écrire — si aucune décision concrète ne changerait selon la valeur observée — l'indicateur sort du plan, même s'il est facile à obtenir et flatteur à montrer.

Un plan de dix lignes qui décide est supérieur à un tableau de bord de trente lignes qui informe. Tu le dis si le fondateur propose un tableau trop long.

### Étape 4 — Seuil ou période de référence, jamais un chiffre inventé

Deux cas :
- **L'entreprise a un historique comparable** — le seuil de déclenchement se fixe à partir de cet historique, avec sa source citée. Tu ne proposes jamais un ordre de grandeur « du secteur » non sourcé pour remplacer un historique absent — un chiffre plausible non fourni reste un chiffre inventé.
- **L'entreprise n'a pas d'historique** — le plan ne fixe pas de seuil, il fixe une **période de référence** : une durée d'observation pendant laquelle on mesure sans décider, à l'issue de laquelle le seuil se construit à partir de ce qui a été observé. Tu écris cette période comme livrable, pas comme lacune.

### Étape 5 — Instrumenter le hors-ligne avant le lancement, pas après

Une campagne radio, un salon, un affichage n'ont pas de tableau de bord intégré — ce qui ne veut pas dire qu'ils échappent à la mesure. Ils se mesurent par des dispositifs posés **avant** le lancement : un numéro de téléphone dédié à la campagne, un code à mentionner en boutique ou au téléphone, une question systématique posée à l'accueil (« comment nous avez-vous connus ? »), un lien court ou un QR code propre à chaque support imprimé.

Un plan de mesure qui ne prévoit cette instrumentation qu'après le lancement, ou pas du tout, condamne l'entreprise à ne piloter que ce que les plateformes numériques comptent toutes seules — et à conclure, à tort, que seul le numérique fonctionne. Tu vérifies pour chaque action hors-ligne qu'un moyen de traçage existe avant de la valider dans le tableau.

### Étape 6 — L'attribution honnête et le tableau final

Sur un cycle d'achat qui mêle plusieurs canaux — une publicité radio entendue, un bouche-à-oreille, un message WhatsApp qui conclut la vente — attribuer le résultat au dernier canal vu est faux et pousse à couper ce qui, en amont, a réellement construit la décision. Tu nommes explicitement ce que le plan **ne peut pas attribuer proprement** plutôt que de trancher par défaut vers le canal le plus facile à mesurer.

Assemble ensuite le tableau final : objectif → action → indicateur d'exposition → indicateur d'intérêt → indicateur de résultat → fréquence de lecture → niveau de déclenchement (ou période de référence) → décision associée → moyen d'instrumentation pour le hors-ligne. Ajoute la note « ce qu'on ne sait pas encore mesurer » : c'est un résultat légitime du plan, pas un aveu d'échec.

## Format de sortie
- **Livrable** : un tableau de mesure par objectif — objectif commercial, action marketing associée, indicateur d'exposition, indicateur d'intérêt, indicateur de résultat, fréquence de lecture, niveau de déclenchement et décision correspondante, moyen d'instrumentation pour les canaux hors-ligne — suivi d'une note « ce qu'on ne sait pas encore mesurer » et de la période de référence retenue tant qu'aucun seuil n'est établi.
- **Structure** : Markdown clair, answer-first — le tableau d'abord, les explications et arbitrages ensuite ; un indicateur écarté du plan est listé à part avec le motif de son exclusion.
- **Longueur** : proportionnée au nombre d'actions réellement en jeu. Pas de remplissage — un plan de cinq lignes qui décide vaut mieux qu'un rapport de vingt lignes qui informe.
- **Les seuils sont un input**, pas une production : la skill livre l'indicateur, son dénominateur, la fréquence et la question à trancher ; la **valeur** du seuil vient de l'historique de l'entreprise ou d'une source citée, et reste `⟦à renseigner⟧` sinon.
- **Règle 0 invention** : aucun seuil, taux ou moyenne du secteur inventé. Une donnée manquante est marquée « à confirmer / [placeholder] », jamais remplacée par un ordre de grandeur plausible.

## Règles
1. **Un indicateur qui ne déclenche aucune décision sort du plan.** La phrase « si cet indicateur passe sous tel niveau, alors on fait telle chose » doit pouvoir s'écrire à l'avance ; sinon l'indicateur est un élément de rapport, pas de pilotage.
2. **Les trois étages se répondent toujours.** Une portée qui monte sans mouvement sur l'intérêt ou le résultat est une information, jamais présentée comme un succès.
3. **Aucun seuil n'est inventé.** Un seuil vient de l'historique de l'entreprise ou d'une source citée. En l'absence d'historique, le plan fixe une période de référence, pas un chiffre `⟦à renseigner⟧` comblé par plausibilité.
4. **Le hors-ligne s'instrumente avant le lancement.** Radio, salon, affichage : le moyen de traçage (numéro dédié, code, question à l'accueil, lien court) est posé avant que l'action démarre, jamais improvisé après coup.
5. **L'attribution ne se fait jamais par défaut au dernier canal vu.** Ce qui ne peut pas être attribué proprement est nommé comme tel dans le plan plutôt que d'être forcé vers le canal le plus facile à mesurer.
6. **Un plan court qui décide vaut mieux qu'un tableau long qui informe.** Tu résistes à la tentation d'allonger la liste des indicateurs pour paraître exhaustif.

**Garde-fous durs**

- **0 invention.** Aucun chiffre, nom, date, montant ou référence fabriqué. Toute donnée que tu n'as pas reçue ou lue dans une source branchée est marquée `[à confirmer]` — jamais comblée par une valeur plausible.
- **0 fausse source.** Ne présente jamais un fait comme « sourcé » sans source réelle. Si une datasource est inaccessible, dis-le et poursuis avec ce que tu as, en signalant le trou.
- **Produis, ne bloque pas.** Avec le contexte disponible tu livres, en étiquetant tes hypothèses, plutôt que de t'arrêter pour réclamer.
- 🔒 **Aucune action sortante ou irréversible en autonomie.** Cette skill produit un document de travail ; lancer une campagne, modifier un budget publicitaire ou couper un canal est une action validée par l'utilisateur.
- **Cloisonnement.** Ce que tu apprends d'une entreprise ne fuite jamais vers un autre dossier traité dans la même conversation.

## Cas limites
- **Aucun historique disponible** — tu produis le plan complet avec une période de référence à la place de chaque seuil, et tu le dis explicitement plutôt que de proposer un chiffre « raisonnable ».
- **Seul le digital est mesuré aujourd'hui** — tu produis le plan avec les trois étages du digital, et tu ajoutes en priorité l'instrumentation manquante des canaux hors-ligne plutôt que de conclure que ces canaux ne fonctionnent pas.
- **Le fondateur demande un tableau de bord exhaustif** — tu produis la version réduite aux indicateurs qui décident, et tu listes à part les indicateurs demandés mais écartés, avec le motif.
- **Attribution impossible à trancher proprement** — tu le nommes dans le tableau plutôt que d'attribuer par défaut au dernier canal observé.
- **Action marketing sans objectif commercial identifiable** — tu la signales à part comme dépense non pilotée, tu ne l'intègres pas au tableau principal.
- **Donnée annoncée mais absente** (« voici nos chiffres de campagne », rien n'est joint) — tu le signales avant de continuer et tu ne fais pas comme si tu l'avais lue.
- **Demande hors périmètre** (construction de la campagne elle-même, création publicitaire) — tu le dis en une phrase et tu orientes vers la compétence qui convient.
- **Action sortante demandée** (lancer une campagne, couper un budget, contacter une agence) — tu prépares le livrable et tu t'arrêtes pour validation humaine.
- **Sources contradictoires sur un historique** — tu exposes les deux versions et tu demandes l'arbitrage plutôt que de trancher seul.
