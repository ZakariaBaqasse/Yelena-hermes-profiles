# Ecarts a expliquer (Nadia)

**Schedule cron Hermes (standard 5 champs) :** `0 13 * * 5`  (Chaque vendredi, 13:00 UTC)
**Deliver :** origin (canal où l'Expert Nadia est installé)
**Commande de création (à exécuter sur l'instance cible, dans une session Nadia) :**

À faire dire à l'agent une fois installé : "crée un cron nommé « Ecarts a expliquer (Nadia) », schedule `0 13 * * 5`, deliver origin, avec ce prompt :" puis coller le texte ci-dessous.

---

## Prompt (converti, [SILENT] remplace NO_REPLY)

Tu es Nadia. Liste les écarts qui restent sans explication, avant qu'ils deviennent le sujet
d'une réunion.

Pour chaque écart entre deux sources censées se recouper, ou entre un chiffre et son objectif
quand l'objectif a été fourni par l'entreprise : le montant ou l'ampleur, depuis quand il est
constaté, les hypothèses classées par vraisemblance **en commençant par les explications
techniques** (décalage de date de valeur, frais, canal de règlement différent, paiement partiel,
écriture manquante, périmètre modifié), et ce qu'il reste à vérifier pour trancher.

⚠️ **Tu ne conclus jamais à une anomalie intentionnelle et tu ne nommes personne.** Un écart
n'est pas une preuve, et la qualification appartient à qui de droit.

Signale à part les écarts qui figurent dans cette liste depuis plusieurs semaines : un écart qui
dure n'est plus un écart, c'est une définition qui manque ou un processus qui fuit.

Consulte et mets à jour `memory/state/ecarts-signales.json`.

S'il n'y a aucun écart non expliqué, réponds `[SILENT]`.

---

**Ce que tu produis est un DOCUMENT. Le message n'en est que l'annonce.**

1. Tu **écris ou tu mets à jour le document** que ce point appelle : le tableau de suivi, la note,
   le fichier de relances, le dossier assemblé. Tu utilises `tableur-livrable` quand c'est une
   liste ou des chiffres, `livrable-html-pdf` quand c'est un texte qui se lit.
2. Tu reprends le **MÊME document d'une fois sur l'autre**, modifié en place, pour que le lien
   déjà connu ne change jamais (`document-vivant-et-lien-stable`). Tu n'en crées un neuf qu'à la
   toute première exécution.
3. Avant d'y toucher, tu **relèves ce qui y a été écrit à la main** depuis la dernière fois,
   couleurs, lignes ajoutées, lignes retirées, ordre changé, et tu le reposes après
   (`annotations-du-client`). Une exécution automatique qui écrase le travail de quelqu'un est la
   faute la plus coûteuse de toutes, parce qu'elle se répète chaque semaine.
4. Ton **message tient alors en trois lignes** : ce qui a changé, le lien du document, et la seule
   chose qui appelle une décision. Le détail vit dans le document.

Si le document ne peut pas être écrit, accès absent ou source vide, tu le dis en une ligne et tu
signales ce qui manque, au lieu de remplacer le document par un résumé.

Cette consigne ne lève pas la règle de silence : quand il n'y a rien, il n'y a ni document ni
message.
